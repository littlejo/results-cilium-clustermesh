Endpoint ID: 11
Path: /sys/fs/bpf/tc/globals/cilium_policy_00011

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 772
Path: /sys/fs/bpf/tc/globals/cilium_policy_00772

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    531428   4761      0        
Allow    Ingress     1          ANY          NONE         disabled    110819   1275      0        
Allow    Egress      0          ANY          NONE         disabled    116753   1114      0        


Endpoint ID: 1050
Path: /sys/fs/bpf/tc/globals/cilium_policy_01050

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    529530   4761      0        
Allow    Ingress     1          ANY          NONE         disabled    111112   1276      0        
Allow    Egress      0          ANY          NONE         disabled    117312   1118      0        


Endpoint ID: 1249
Path: /sys/fs/bpf/tc/globals/cilium_policy_01249

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11371043   111476    0        
Allow    Ingress     1          ANY          NONE         disabled    8887739    92712     0        
Allow    Egress      0          ANY          NONE         disabled    10888090   108689    0        


Endpoint ID: 3468
Path: /sys/fs/bpf/tc/globals/cilium_policy_03468

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1658625   20936     0        
Allow    Ingress     1          ANY          NONE         disabled    17288     203       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


