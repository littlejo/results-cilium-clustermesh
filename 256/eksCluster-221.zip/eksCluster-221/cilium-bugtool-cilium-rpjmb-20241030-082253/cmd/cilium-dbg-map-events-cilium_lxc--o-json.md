{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:00.447Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.212.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:00.447Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.213.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:00.447Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:05.136Z",
  "value": "id=3468  sec_id=4     flags=0x0000 ifindex=10  mac=CE:8B:1A:7B:D6:78 nodemac=42:4C:54:A1:A2:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:05.139Z",
  "value": "id=772   sec_id=7274570 flags=0x0000 ifindex=12  mac=82:EF:5B:EB:0E:5E nodemac=4E:B4:95:8D:B7:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:05.184Z",
  "value": "id=1050  sec_id=7274570 flags=0x0000 ifindex=14  mac=3E:85:C5:10:D6:A6 nodemac=22:A4:A7:C6:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:05.221Z",
  "value": "id=3468  sec_id=4     flags=0x0000 ifindex=10  mac=CE:8B:1A:7B:D6:78 nodemac=42:4C:54:A1:A2:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:08.073Z",
  "value": "id=3468  sec_id=4     flags=0x0000 ifindex=10  mac=CE:8B:1A:7B:D6:78 nodemac=42:4C:54:A1:A2:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:08.075Z",
  "value": "id=772   sec_id=7274570 flags=0x0000 ifindex=12  mac=82:EF:5B:EB:0E:5E nodemac=4E:B4:95:8D:B7:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:08.075Z",
  "value": "id=1050  sec_id=7274570 flags=0x0000 ifindex=14  mac=3E:85:C5:10:D6:A6 nodemac=22:A4:A7:C6:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:08.106Z",
  "value": "id=345   sec_id=7282897 flags=0x0000 ifindex=16  mac=96:5A:F0:93:CB:61 nodemac=12:BF:F8:92:B4:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:09.074Z",
  "value": "id=1050  sec_id=7274570 flags=0x0000 ifindex=14  mac=3E:85:C5:10:D6:A6 nodemac=22:A4:A7:C6:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:09.074Z",
  "value": "id=772   sec_id=7274570 flags=0x0000 ifindex=12  mac=82:EF:5B:EB:0E:5E nodemac=4E:B4:95:8D:B7:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:09.075Z",
  "value": "id=3468  sec_id=4     flags=0x0000 ifindex=10  mac=CE:8B:1A:7B:D6:78 nodemac=42:4C:54:A1:A2:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:09.075Z",
  "value": "id=345   sec_id=7282897 flags=0x0000 ifindex=16  mac=96:5A:F0:93:CB:61 nodemac=12:BF:F8:92:B4:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.943Z",
  "value": "id=1249  sec_id=7282897 flags=0x0000 ifindex=18  mac=2E:2D:2E:14:F6:D9 nodemac=8A:00:2D:19:9E:62"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.221.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.596Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:20.414Z",
  "value": "id=1249  sec_id=7282897 flags=0x0000 ifindex=18  mac=2E:2D:2E:14:F6:D9 nodemac=8A:00:2D:19:9E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:20.415Z",
  "value": "id=3468  sec_id=4     flags=0x0000 ifindex=10  mac=CE:8B:1A:7B:D6:78 nodemac=42:4C:54:A1:A2:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:20.416Z",
  "value": "id=772   sec_id=7274570 flags=0x0000 ifindex=12  mac=82:EF:5B:EB:0E:5E nodemac=4E:B4:95:8D:B7:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:20.416Z",
  "value": "id=1050  sec_id=7274570 flags=0x0000 ifindex=14  mac=3E:85:C5:10:D6:A6 nodemac=22:A4:A7:C6:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:21.415Z",
  "value": "id=1249  sec_id=7282897 flags=0x0000 ifindex=18  mac=2E:2D:2E:14:F6:D9 nodemac=8A:00:2D:19:9E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:21.415Z",
  "value": "id=1050  sec_id=7274570 flags=0x0000 ifindex=14  mac=3E:85:C5:10:D6:A6 nodemac=22:A4:A7:C6:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:21.417Z",
  "value": "id=3468  sec_id=4     flags=0x0000 ifindex=10  mac=CE:8B:1A:7B:D6:78 nodemac=42:4C:54:A1:A2:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:21.417Z",
  "value": "id=772   sec_id=7274570 flags=0x0000 ifindex=12  mac=82:EF:5B:EB:0E:5E nodemac=4E:B4:95:8D:B7:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:22.415Z",
  "value": "id=3468  sec_id=4     flags=0x0000 ifindex=10  mac=CE:8B:1A:7B:D6:78 nodemac=42:4C:54:A1:A2:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:22.416Z",
  "value": "id=1249  sec_id=7282897 flags=0x0000 ifindex=18  mac=2E:2D:2E:14:F6:D9 nodemac=8A:00:2D:19:9E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:22.416Z",
  "value": "id=1050  sec_id=7274570 flags=0x0000 ifindex=14  mac=3E:85:C5:10:D6:A6 nodemac=22:A4:A7:C6:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:22.416Z",
  "value": "id=772   sec_id=7274570 flags=0x0000 ifindex=12  mac=82:EF:5B:EB:0E:5E nodemac=4E:B4:95:8D:B7:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:23.416Z",
  "value": "id=3468  sec_id=4     flags=0x0000 ifindex=10  mac=CE:8B:1A:7B:D6:78 nodemac=42:4C:54:A1:A2:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:23.416Z",
  "value": "id=1249  sec_id=7282897 flags=0x0000 ifindex=18  mac=2E:2D:2E:14:F6:D9 nodemac=8A:00:2D:19:9E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:23.417Z",
  "value": "id=772   sec_id=7274570 flags=0x0000 ifindex=12  mac=82:EF:5B:EB:0E:5E nodemac=4E:B4:95:8D:B7:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.221.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:23.417Z",
  "value": "id=1050  sec_id=7274570 flags=0x0000 ifindex=14  mac=3E:85:C5:10:D6:A6 nodemac=22:A4:A7:C6:E4:6F"
}

