REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34151     2700320     677    bpf_overlay.c
Interface                 INGRESS     614118    128236128   1132   bpf_host.c
Success                   EGRESS      13901     1088427     1694   bpf_host.c
Success                   EGRESS      19044     3018838     86     l3.h
Success                   EGRESS      257781    32826110    1308   bpf_lxc.c
Success                   EGRESS      32865     2604958     53     encap.h
Success                   INGRESS     297561    33492828    86     l3.h
Success                   INGRESS     337505    38167535    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
