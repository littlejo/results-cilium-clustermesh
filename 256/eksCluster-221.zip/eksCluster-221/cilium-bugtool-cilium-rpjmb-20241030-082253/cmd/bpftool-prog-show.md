32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:55:51+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:56:01+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:04:02+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
482: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:04:02+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 125
483: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:04:02+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
484: sched_cls  name tail_handle_ipv4  tag 813ab625d8bf4318  gpl
	loaded_at 2024-10-30T08:04:02+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
513: sched_cls  name tail_ipv4_ct_egress  tag cfead5dcc5fcb2c7  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 162
514: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 164
515: sched_cls  name cil_from_container  tag 993a7f5c3da11cba  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 165
517: sched_cls  name tail_handle_arp  tag 5ecdce5d8645a2e8  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 167
521: sched_cls  name handle_policy  tag 03050167d44c0e57  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 168
525: sched_cls  name tail_handle_ipv4_cont  tag 24a99b887df67bc1  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 174
526: sched_cls  name __send_drop_notify  tag 794f79cce329eb1d  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 176
529: sched_cls  name tail_handle_ipv4  tag db7d35113ec98705  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 177
533: sched_cls  name tail_ipv4_to_endpoint  tag 8350432c477df02c  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 180
534: sched_cls  name tail_ipv4_ct_ingress  tag d16a643996b1347f  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 183
535: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 187
536: sched_cls  name tail_ipv4_ct_ingress  tag f3ec98e8aacf1220  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 185
537: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 188
539: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,118
	btf_id 191
540: sched_cls  name tail_ipv4_to_endpoint  tag 3d7e543dbcae36c5  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 189
541: sched_cls  name cil_from_container  tag b44bd197876e0855  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 193
542: sched_cls  name tail_ipv4_ct_egress  tag cfead5dcc5fcb2c7  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 194
543: sched_cls  name tail_handle_ipv4_from_host  tag 3eb7d7051d0f9d6d  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 192
545: sched_cls  name __send_drop_notify  tag cbee6e73217e3fc3  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 197
546: sched_cls  name __send_drop_notify  tag cbee6e73217e3fc3  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
547: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 200
548: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 201
551: sched_cls  name tail_handle_ipv4_from_host  tag 3eb7d7051d0f9d6d  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 204
553: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 207
554: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 208
556: sched_cls  name tail_handle_ipv4_from_host  tag 3eb7d7051d0f9d6d  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 210
557: sched_cls  name handle_policy  tag e94a3223d7118d12  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 195
560: sched_cls  name __send_drop_notify  tag 34eacef6d4ed7ea4  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 213
561: sched_cls  name __send_drop_notify  tag cbee6e73217e3fc3  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 214
563: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 215
564: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 219
565: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 220
566: sched_cls  name tail_handle_ipv4_cont  tag 25a8c84904c01c64  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 217
568: sched_cls  name tail_handle_ipv4  tag 41065dd0557e99df  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 222
569: sched_cls  name tail_handle_ipv4_from_host  tag 3eb7d7051d0f9d6d  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 223
570: sched_cls  name tail_handle_arp  tag 151a8cb945f5faed  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 224
572: sched_cls  name __send_drop_notify  tag cbee6e73217e3fc3  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 226
574: sched_cls  name handle_policy  tag a656c0095cdad8da  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,126,82,83,125,41,80,100,39,84,75,40,37,38
	btf_id 229
575: sched_cls  name cil_from_container  tag 0865931017b02b10  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 126,76
	btf_id 230
576: sched_cls  name tail_ipv4_ct_ingress  tag ddb833a6c32edac9  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 231
577: sched_cls  name tail_handle_ipv4_cont  tag f615dccfc848ba59  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,125,41,100,82,83,39,76,74,77,126,40,37,38,81
	btf_id 232
579: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 234
580: sched_cls  name tail_handle_ipv4  tag 2811a919d7bee9ff  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,126
	btf_id 235
581: sched_cls  name tail_ipv4_to_endpoint  tag c9e51e4e62ca0ea9  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,125,41,82,83,80,100,39,126,40,37,38
	btf_id 236
582: sched_cls  name __send_drop_notify  tag 70e8d7c148982035  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 237
583: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,126
	btf_id 238
584: sched_cls  name tail_handle_arp  tag 6ba3da33c3635e3e  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,126
	btf_id 239
585: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
588: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
589: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
592: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:04:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: sched_cls  name handle_policy  tag 9d358ff6322bd24e  gpl
	loaded_at 2024-10-30T08:12:20+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 253
642: sched_cls  name __send_drop_notify  tag 4c864cb6fde85ad8  gpl
	loaded_at 2024-10-30T08:12:20+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 255
643: sched_cls  name tail_handle_ipv4_cont  tag 67529d2357fff7e9  gpl
	loaded_at 2024-10-30T08:12:20+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 256
644: sched_cls  name cil_from_container  tag 92d22dea80c3900c  gpl
	loaded_at 2024-10-30T08:12:20+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 257
645: sched_cls  name tail_ipv4_to_endpoint  tag 56200bf653714c45  gpl
	loaded_at 2024-10-30T08:12:20+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 258
646: sched_cls  name tail_handle_arp  tag bad42fc5ab884d3a  gpl
	loaded_at 2024-10-30T08:12:20+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 259
647: sched_cls  name tail_ipv4_ct_egress  tag 1212cf06eac2d139  gpl
	loaded_at 2024-10-30T08:12:20+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 260
648: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:12:20+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 261
649: sched_cls  name tail_ipv4_ct_ingress  tag 2b084298d951f328  gpl
	loaded_at 2024-10-30T08:12:20+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 262
650: sched_cls  name tail_handle_ipv4  tag ce046dc7913623b8  gpl
	loaded_at 2024-10-30T08:12:20+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 263
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
667: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
670: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
671: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
674: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
