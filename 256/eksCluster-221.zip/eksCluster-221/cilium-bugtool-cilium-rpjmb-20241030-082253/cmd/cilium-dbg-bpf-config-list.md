KEY             VALUE
AgentLiveness   1664008534619
UTimeOffset     3379443246093750
