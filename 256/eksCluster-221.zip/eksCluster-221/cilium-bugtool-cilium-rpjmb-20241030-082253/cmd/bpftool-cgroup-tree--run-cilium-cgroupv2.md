CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod44110a9e_70f1_4511_baf7_cd661785c430.slice/cri-containerd-8447d3aac6ccca1a92d266041d04498d340de568a46b50345829efa0adc2d100.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod44110a9e_70f1_4511_baf7_cd661785c430.slice/cri-containerd-95f26704be64c1df0599fad1751b5f81a2fe8a4888d93d7789b3eba2ff7333f4.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd0e352b_4076_45d3_b6cf_8347883ff52a.slice/cri-containerd-65b1aee2e52dcc71747960f7ada53f0cadb9f3031d3e2014a8429fe278a65ed2.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd0e352b_4076_45d3_b6cf_8347883ff52a.slice/cri-containerd-b76e61c3e0ef2440f66e7664c9f629cf83ff08c857e2784acad13b5645608e17.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod660585ca_5e9f_4ab9_825d_9a043f3b086f.slice/cri-containerd-bd74ecfaf1373fa571af7eaeb0ce91d8ee0d61dda03483abd0122017cfc4c0e5.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod660585ca_5e9f_4ab9_825d_9a043f3b086f.slice/cri-containerd-3fdf9733f30c88b15b7fdcac1c3537648140415c693db3404cd63562869ef56a.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6c2b096e_5221_4539_a675_6f4124a55b2c.slice/cri-containerd-6fcfb3915c8ac7d1c3f76a71b3e048a0a09c2429e4ea5cf227a8bcc1ea87d52a.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6c2b096e_5221_4539_a675_6f4124a55b2c.slice/cri-containerd-3581a2ef5f234f6ba31a18e27d84e24882620c25fe8a5079d98da91afda3e2f9.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8422a666_ddb0_4040_8a74_354799e6d17b.slice/cri-containerd-e7f744258660fab5c8f73620dc66d921b8a6290db898e1c3ae2c72cc4386dc20.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8422a666_ddb0_4040_8a74_354799e6d17b.slice/cri-containerd-25cb427c333a222dcf69f8e826a39a1d39ac7b1010b5fb3da303badb39cedf36.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8422a666_ddb0_4040_8a74_354799e6d17b.slice/cri-containerd-65bfec95792e2634646f116d2b6a4b65f060f98a6ac23b3fefd3474e2ccab1b3.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8422a666_ddb0_4040_8a74_354799e6d17b.slice/cri-containerd-727f46de6ac26b00a19c1f9be0898871c990efc99aedb1a886d356fe17a9e6e0.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod380d4d5c_84db_4131_a63f_05c1dcce145f.slice/cri-containerd-7af5cd80af103c2c25c5f8b24dab463534ea54acd2eaeeea942caba7327289c5.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod380d4d5c_84db_4131_a63f_05c1dcce145f.slice/cri-containerd-0cb8f2d6b8fffcc2f1145f2fb9ad0c75388cdb04f22d45490fc8b79289826ed9.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod51c53e74_89b4_49db_afb0_b7024cd41ee4.slice/cri-containerd-d71fb0ebc0eb5fe927ce99de289ddf905f53e37264c02c89edec6b7e098a0fbd.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod51c53e74_89b4_49db_afb0_b7024cd41ee4.slice/cri-containerd-743bcaf38b941252635e7d74e3e1c804cbb60ad4c43deb0def1524f0f5bac8ca.scope
    102      cgroup_device   multi                                          
