top - 08:22:53 up 30 min,  0 users,  load average: 0.14, 0.17, 0.16
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 33.3 us, 33.3 sy,  0.0 ni, 23.3 id,  0.0 wa,  0.0 hi, 10.0 si,  0.0 st
MiB Mem :   7814.2 total,   4445.1 free,   1222.2 used,   2146.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6406.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    663 root      20   0 1240432  16112  10896 S  13.3   0.2   0:00.04 cilium-+
      1 root      20   0 1606336 405172  79416 S   6.7   5.1   0:51.97 cilium-+
    732 root      20   0 1243764  19048  13888 S   6.7   0.2   0:00.01 hubble
    396 root      20   0 1229744   8116   3840 S   0.0   0.1   0:01.14 cilium-+
    633 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    649 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    659 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    696 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    712 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    727 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
