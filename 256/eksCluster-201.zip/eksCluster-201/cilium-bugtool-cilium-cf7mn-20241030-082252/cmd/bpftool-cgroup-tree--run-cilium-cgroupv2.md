CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa4b3332_b382_4467_a2e8_3398cc07ec23.slice/cri-containerd-d00916b210c379d70c7a4c78dcc27e16d01af83646d821ed3d04924f3d8a8d0e.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa4b3332_b382_4467_a2e8_3398cc07ec23.slice/cri-containerd-9d9a8877ae5795e67bf9a58de768e1553c314cc6cc93c3c485062f25805bfb97.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf1d7991c_3874_42ad_8e25_2e784dcf637b.slice/cri-containerd-38da9e7ef6ce3808c81cb19f1f82c8298008855a9ab72ac22ccd6abc35b44f86.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf1d7991c_3874_42ad_8e25_2e784dcf637b.slice/cri-containerd-493e7028a8b1413ec2648814db7e7564d3977ce818e9eb719eb9e88e8a889fa2.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd680b659_3de2_47d5_811a_f209d93e395a.slice/cri-containerd-55e532c8ecedf610cb5dc25f455ba0f8ea35127f448544510dbb96ceef055b71.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd680b659_3de2_47d5_811a_f209d93e395a.slice/cri-containerd-28a4a9e694508dcaba05900f124127cedd2a853709a5ca2458fb0f4e29e524c0.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod931dbf61_2c5a_40c4_89cc_e0e580d98650.slice/cri-containerd-f1ae49d9fb9b84507ae315255ed8bd9a23558b73f6c490b9546dbb6176cc55f8.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod931dbf61_2c5a_40c4_89cc_e0e580d98650.slice/cri-containerd-a6caca3bb05aaad0b51d5b9518dc3b4995b27ece69c023c162a5f12bc479506c.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9dbf71e5_058d_440a_9873_7a3a8c26c471.slice/cri-containerd-d1df1d65e405dac865b1713426b3ebb9926de928056f2a07b561d219a58d9ae7.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9dbf71e5_058d_440a_9873_7a3a8c26c471.slice/cri-containerd-7b449f7ae5de256647024f9a0f77291b563a56349297f26297da85efa2dfca19.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9dbf71e5_058d_440a_9873_7a3a8c26c471.slice/cri-containerd-50bcbd86cc0b6779481c5ca35b5b35daf310742743ad3845141b09535e826a1e.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9dbf71e5_058d_440a_9873_7a3a8c26c471.slice/cri-containerd-8260dd290b8d3e9ac91e33a010fc4dc712151c2da13d2a19f48a692f86906d97.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda971579e_6466_47b1_bb65_9d5a28ab7109.slice/cri-containerd-a2b8eddaef7be73111ac3f598ffd860dc5020f8596af277d43fb7590236b9643.scope
    113      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda971579e_6466_47b1_bb65_9d5a28ab7109.slice/cri-containerd-2c9932ba3d98056d1ae76a92d7abbcb3073d1042e901d9b5dc78bec22e0e017d.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod24d99a13_44a0_4108_83bd_e5fa0a9942d7.slice/cri-containerd-3a9ccb06a0e35420fb17bf77444d1daa7ee50e739e9d94827e7bdb7a2b8f47f0.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod24d99a13_44a0_4108_83bd_e5fa0a9942d7.slice/cri-containerd-de8f7c4de24aedfdf37d7e4a61c30c6d13b2c5184f21864b6d6bb35e74c4240d.scope
    101      cgroup_device   multi                                          
