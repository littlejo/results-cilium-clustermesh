markdown output at /tmp/cilium-bugtool-20241030-082253.234+0000-UTC-3482642574/cmd/cilium-debuginfo-20241030-082324.197+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082253.234+0000-UTC-3482642574/cmd/cilium-debuginfo-20241030-082324.197+0000-UTC.json
