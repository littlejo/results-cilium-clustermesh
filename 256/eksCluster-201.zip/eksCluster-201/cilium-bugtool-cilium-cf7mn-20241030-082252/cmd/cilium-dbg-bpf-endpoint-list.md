IP ADDRESS         LOCAL ENDPOINT INFO
10.201.0.31:0      id=2739  sec_id=6635839 flags=0x0000 ifindex=18  mac=76:1D:53:67:EB:7C nodemac=56:35:AA:39:B9:C1   
10.201.0.222:0     id=328   sec_id=6634954 flags=0x0000 ifindex=14  mac=6E:8B:F0:FD:37:DB nodemac=4E:C5:59:C7:97:FD   
172.31.224.57:0    (localhost)                                                                                        
10.201.0.254:0     id=738   sec_id=6634954 flags=0x0000 ifindex=12  mac=FA:AB:33:DD:00:A7 nodemac=96:CB:5E:90:87:ED   
172.31.206.174:0   (localhost)                                                                                        
10.201.0.168:0     (localhost)                                                                                        
10.201.0.174:0     id=2434  sec_id=4     flags=0x0000 ifindex=10  mac=AE:AC:6A:F7:6C:CE nodemac=0E:CA:11:4F:A5:3C     
