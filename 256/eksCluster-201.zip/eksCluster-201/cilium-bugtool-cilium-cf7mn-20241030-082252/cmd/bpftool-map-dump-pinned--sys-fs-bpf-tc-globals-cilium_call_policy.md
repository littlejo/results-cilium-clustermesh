key: 48 01 00 00  value: 1c 02 00 00
key: e2 02 00 00  value: 0d 02 00 00
key: 82 09 00 00  value: 29 02 00 00
key: b3 0a 00 00  value: 69 02 00 00
Found 4 elements
