USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         663  0.0  0.1 1240432 15800 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         685  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         686  0.0  0.0   3728   488 ?        R    08:22   0:00  \_ bash -c hostname
root         659  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         649  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         633  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         619  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         604  0.0  0.2 1229640 21148 ?       Rsl  08:22   0:00 /bin/gops stack 1
root           1  4.2  5.0 1606336 404516 ?      Rsl  08:02   0:51 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.1 1229744 8116 ?        Sl   08:02   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
