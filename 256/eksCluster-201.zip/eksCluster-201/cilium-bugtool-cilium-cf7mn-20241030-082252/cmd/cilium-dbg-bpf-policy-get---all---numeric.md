Endpoint ID: 328
Path: /sys/fs/bpf/tc/globals/cilium_policy_00328

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    118051   1356      0        
Allow    Egress      0          ANY          NONE         disabled    16672    180       0        


Endpoint ID: 738
Path: /sys/fs/bpf/tc/globals/cilium_policy_00738

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    117325   1345      0        
Allow    Egress      0          ANY          NONE         disabled    17534    190       0        


Endpoint ID: 1046
Path: /sys/fs/bpf/tc/globals/cilium_policy_01046

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2434
Path: /sys/fs/bpf/tc/globals/cilium_policy_02434

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1650548   20833     0        
Allow    Ingress     1          ANY          NONE         disabled    18360     216       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2739
Path: /sys/fs/bpf/tc/globals/cilium_policy_02739

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11547097   114425    0        
Allow    Ingress     1          ANY          NONE         disabled    10838579   110574    0        
Allow    Egress      0          ANY          NONE         disabled    12093181   119729    0        


