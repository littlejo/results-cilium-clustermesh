REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36677     2905030     677    bpf_overlay.c
Interface                 INGRESS     657811    133565101   1132   bpf_host.c
Success                   EGRESS      16525     1300769     1694   bpf_host.c
Success                   EGRESS      287444    36289459    1308   bpf_lxc.c
Success                   EGRESS      36908     2920754     53     encap.h
Success                   INGRESS     330430    37315934    86     l3.h
Success                   INGRESS     351233    38964241    235    trace.h
Unsupported L3 protocol   EGRESS      42        3132        1492   bpf_lxc.c
