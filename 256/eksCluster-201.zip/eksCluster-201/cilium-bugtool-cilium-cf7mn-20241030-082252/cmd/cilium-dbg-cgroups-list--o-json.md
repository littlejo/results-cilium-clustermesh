[
  {
    "containers": [
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9dbf71e5_058d_440a_9873_7a3a8c26c471.slice/cri-containerd-7b449f7ae5de256647024f9a0f77291b563a56349297f26297da85efa2dfca19.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9dbf71e5_058d_440a_9873_7a3a8c26c471.slice/cri-containerd-8260dd290b8d3e9ac91e33a010fc4dc712151c2da13d2a19f48a692f86906d97.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9dbf71e5_058d_440a_9873_7a3a8c26c471.slice/cri-containerd-d1df1d65e405dac865b1713426b3ebb9926de928056f2a07b561d219a58d9ae7.scope"
      }
    ],
    "ips": [
      "10.201.0.31"
    ],
    "name": "clustermesh-apiserver-5464c98cb4-rdwkj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa4b3332_b382_4467_a2e8_3398cc07ec23.slice/cri-containerd-9d9a8877ae5795e67bf9a58de768e1553c314cc6cc93c3c485062f25805bfb97.scope"
      }
    ],
    "ips": [
      "10.201.0.222"
    ],
    "name": "coredns-cc6ccd49c-49snh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf1d7991c_3874_42ad_8e25_2e784dcf637b.slice/cri-containerd-493e7028a8b1413ec2648814db7e7564d3977ce818e9eb719eb9e88e8a889fa2.scope"
      }
    ],
    "ips": [
      "10.201.0.254"
    ],
    "name": "coredns-cc6ccd49c-6msqq",
    "namespace": "kube-system"
  }
]

