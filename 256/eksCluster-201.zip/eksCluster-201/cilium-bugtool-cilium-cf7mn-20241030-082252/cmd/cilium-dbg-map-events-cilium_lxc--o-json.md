{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:51.918Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.206.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:51.918Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.224.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:51.918Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:56.675Z",
  "value": "id=2434  sec_id=4     flags=0x0000 ifindex=10  mac=AE:AC:6A:F7:6C:CE nodemac=0E:CA:11:4F:A5:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:56.687Z",
  "value": "id=738   sec_id=6634954 flags=0x0000 ifindex=12  mac=FA:AB:33:DD:00:A7 nodemac=96:CB:5E:90:87:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:56.734Z",
  "value": "id=328   sec_id=6634954 flags=0x0000 ifindex=14  mac=6E:8B:F0:FD:37:DB nodemac=4E:C5:59:C7:97:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:56.736Z",
  "value": "id=738   sec_id=6634954 flags=0x0000 ifindex=12  mac=FA:AB:33:DD:00:A7 nodemac=96:CB:5E:90:87:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:56.777Z",
  "value": "id=2434  sec_id=4     flags=0x0000 ifindex=10  mac=AE:AC:6A:F7:6C:CE nodemac=0E:CA:11:4F:A5:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:42.064Z",
  "value": "id=2434  sec_id=4     flags=0x0000 ifindex=10  mac=AE:AC:6A:F7:6C:CE nodemac=0E:CA:11:4F:A5:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:42.066Z",
  "value": "id=328   sec_id=6634954 flags=0x0000 ifindex=14  mac=6E:8B:F0:FD:37:DB nodemac=4E:C5:59:C7:97:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:42.067Z",
  "value": "id=738   sec_id=6634954 flags=0x0000 ifindex=12  mac=FA:AB:33:DD:00:A7 nodemac=96:CB:5E:90:87:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:42.097Z",
  "value": "id=3936  sec_id=6635839 flags=0x0000 ifindex=16  mac=12:45:90:72:3C:80 nodemac=A6:55:F3:55:14:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:42.097Z",
  "value": "id=3936  sec_id=6635839 flags=0x0000 ifindex=16  mac=12:45:90:72:3C:80 nodemac=A6:55:F3:55:14:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.798Z",
  "value": "id=2739  sec_id=6635839 flags=0x0000 ifindex=18  mac=76:1D:53:67:EB:7C nodemac=56:35:AA:39:B9:C1"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.201.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.188Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.241Z",
  "value": "id=328   sec_id=6634954 flags=0x0000 ifindex=14  mac=6E:8B:F0:FD:37:DB nodemac=4E:C5:59:C7:97:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.241Z",
  "value": "id=2434  sec_id=4     flags=0x0000 ifindex=10  mac=AE:AC:6A:F7:6C:CE nodemac=0E:CA:11:4F:A5:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.242Z",
  "value": "id=738   sec_id=6634954 flags=0x0000 ifindex=12  mac=FA:AB:33:DD:00:A7 nodemac=96:CB:5E:90:87:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.242Z",
  "value": "id=2739  sec_id=6635839 flags=0x0000 ifindex=18  mac=76:1D:53:67:EB:7C nodemac=56:35:AA:39:B9:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.242Z",
  "value": "id=2739  sec_id=6635839 flags=0x0000 ifindex=18  mac=76:1D:53:67:EB:7C nodemac=56:35:AA:39:B9:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.250Z",
  "value": "id=2434  sec_id=4     flags=0x0000 ifindex=10  mac=AE:AC:6A:F7:6C:CE nodemac=0E:CA:11:4F:A5:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.250Z",
  "value": "id=738   sec_id=6634954 flags=0x0000 ifindex=12  mac=FA:AB:33:DD:00:A7 nodemac=96:CB:5E:90:87:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.251Z",
  "value": "id=328   sec_id=6634954 flags=0x0000 ifindex=14  mac=6E:8B:F0:FD:37:DB nodemac=4E:C5:59:C7:97:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.242Z",
  "value": "id=2434  sec_id=4     flags=0x0000 ifindex=10  mac=AE:AC:6A:F7:6C:CE nodemac=0E:CA:11:4F:A5:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.242Z",
  "value": "id=2739  sec_id=6635839 flags=0x0000 ifindex=18  mac=76:1D:53:67:EB:7C nodemac=56:35:AA:39:B9:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.243Z",
  "value": "id=738   sec_id=6634954 flags=0x0000 ifindex=12  mac=FA:AB:33:DD:00:A7 nodemac=96:CB:5E:90:87:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.243Z",
  "value": "id=328   sec_id=6634954 flags=0x0000 ifindex=14  mac=6E:8B:F0:FD:37:DB nodemac=4E:C5:59:C7:97:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.243Z",
  "value": "id=328   sec_id=6634954 flags=0x0000 ifindex=14  mac=6E:8B:F0:FD:37:DB nodemac=4E:C5:59:C7:97:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.243Z",
  "value": "id=2434  sec_id=4     flags=0x0000 ifindex=10  mac=AE:AC:6A:F7:6C:CE nodemac=0E:CA:11:4F:A5:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.243Z",
  "value": "id=738   sec_id=6634954 flags=0x0000 ifindex=12  mac=FA:AB:33:DD:00:A7 nodemac=96:CB:5E:90:87:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.201.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.244Z",
  "value": "id=2739  sec_id=6635839 flags=0x0000 ifindex=18  mac=76:1D:53:67:EB:7C nodemac=56:35:AA:39:B9:C1"
}

