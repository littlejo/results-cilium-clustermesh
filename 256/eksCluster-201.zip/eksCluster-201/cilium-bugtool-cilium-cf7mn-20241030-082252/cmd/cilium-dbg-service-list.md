ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.247.26:443 (active)    
                                         2 => 172.31.133.118:443 (active)   
2    10.100.190.236:443   ClusterIP      1 => 172.31.224.57:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.201.0.254:53 (active)      
                                         2 => 10.201.0.222:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.201.0.254:9153 (active)    
                                         2 => 10.201.0.222:9153 (active)    
5    10.100.41.39:2379    ClusterIP      1 => 10.201.0.31:2379 (active)     
