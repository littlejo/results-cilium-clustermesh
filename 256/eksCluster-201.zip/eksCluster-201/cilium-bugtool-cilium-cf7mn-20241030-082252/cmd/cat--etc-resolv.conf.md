search eu-west-3.compute.internal
nameserver 172.31.0.2
