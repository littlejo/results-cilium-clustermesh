filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc4aa0d0c57de7 direct-action not_in_hw id 516 tag b9af409f370f8932 jited 
