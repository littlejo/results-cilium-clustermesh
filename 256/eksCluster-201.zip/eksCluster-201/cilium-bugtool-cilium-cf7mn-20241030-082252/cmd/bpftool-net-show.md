xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 508
ens6(5) clsact/ingress cil_from_netdev-ens6 id 513
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 501
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 490
cilium_host(7) clsact/egress cil_from_host-cilium_host id 491
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 558
lxc4aa0d0c57de7(12) clsact/ingress cil_from_container-lxc4aa0d0c57de7 id 516
lxc4097d3372ea9(14) clsact/ingress cil_from_container-lxc4097d3372ea9 id 541
lxc84ed809e988c(18) clsact/ingress cil_from_container-lxc84ed809e988c id 624

flow_dissector:

netfilter:

