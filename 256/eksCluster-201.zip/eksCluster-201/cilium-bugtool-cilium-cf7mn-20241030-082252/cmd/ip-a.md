1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:fc:02:81:1a:d1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.224.57/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3595sec preferred_lft 3595sec
    inet6 fe80::8fc:2ff:fe81:1ad1/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:47:66:96:cc:f3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.206.174/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::847:66ff:fe96:ccf3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:b0:27:e8:05:bd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d8b0:27ff:fee8:5bd/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:cf:24:49:d8:2f brd ff:ff:ff:ff:ff:ff
    inet 10.201.0.168/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a0cf:24ff:fe49:d82f/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether b2:ee:7b:2c:bb:43 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b0ee:7bff:fe2c:bb43/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:ca:11:4f:a5:3c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::cca:11ff:fe4f:a53c/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc4aa0d0c57de7@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:cb:5e:90:87:ed brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::94cb:5eff:fe90:87ed/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc4097d3372ea9@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:c5:59:c7:97:fd brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::4cc5:59ff:fec7:97fd/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc84ed809e988c@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:35:aa:39:b9:c1 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::5435:aaff:fe39:b9c1/64 scope link 
       valid_lft forever preferred_lft forever
