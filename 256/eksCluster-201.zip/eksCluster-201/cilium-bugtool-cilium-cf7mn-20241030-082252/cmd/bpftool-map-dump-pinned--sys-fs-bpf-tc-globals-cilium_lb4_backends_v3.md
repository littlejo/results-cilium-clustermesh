key: 01 00 00 00  value: ac 1f f7 1a 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f e0 39 10 94 00 00  00 00 00 00
key: 07 00 00 00  value: 0a c9 00 fe 23 c1 00 00  00 00 00 00
key: 08 00 00 00  value: 0a c9 00 de 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f 85 76 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a c9 00 de 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a c9 00 1f 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a c9 00 fe 00 35 00 00  00 00 00 00
Found 8 elements
