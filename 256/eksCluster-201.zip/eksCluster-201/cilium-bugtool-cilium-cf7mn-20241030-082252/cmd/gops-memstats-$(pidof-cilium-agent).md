alloc: 103.38MB (108398184 bytes)
total-alloc: 2.38GB (2560809016 bytes)
sys: 333.02MB (349196644 bytes)
lookups: 0
mallocs: 65118697
frees: 64356615
heap-alloc: 103.38MB (108398184 bytes)
heap-sys: 255.54MB (267952128 bytes)
heap-idle: 87.77MB (92037120 bytes)
heap-in-use: 167.77MB (175915008 bytes)
heap-released: 6.47MB (6782976 bytes)
heap-objects: 762082
stack-in-use: 64.44MB (67567616 bytes)
stack-sys: 64.44MB (67567616 bytes)
stack-mspan-inuse: 2.91MB (3050880 bytes)
stack-mspan-sys: 3.91MB (4096320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.11MB (1164185 bytes)
gc-sys: 6.02MB (6307328 bytes)
next-gc: when heap-alloc >= 218.38MB (228985816 bytes)
last-gc: 2024-10-30 08:23:18.484094543 +0000 UTC
gc-pause-total: 31.932873ms
gc-pause: 100383
gc-pause-end: 1730276598484094543
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0006698999823774693
enable-gc: true
debug-gc: false
