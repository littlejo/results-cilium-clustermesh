KEY             VALUE
AgentLiveness   1847486492578
UTimeOffset     3379442884765625
