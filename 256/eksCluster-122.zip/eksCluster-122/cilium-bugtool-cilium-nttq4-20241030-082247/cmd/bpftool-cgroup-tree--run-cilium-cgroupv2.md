CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9b72f51c_3d2e_4e59_87e0_594bf95b93bc.slice/cri-containerd-063f88ea8c9db6a464e6283fae6e585619665c3cdb7d27d7bab46b7091e35ecd.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9b72f51c_3d2e_4e59_87e0_594bf95b93bc.slice/cri-containerd-43c18d0407b14baa5d9b875ec82d334ba9ed4df9ce73cb183db869022c15d500.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5b89229a_2c71_4d9a_ba96_a77f8fe46279.slice/cri-containerd-96cad253c698595c3369858fa5d82078c007a0e48b4ab74c47440195f3e6647e.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5b89229a_2c71_4d9a_ba96_a77f8fe46279.slice/cri-containerd-bb6176840eb3b8bb66e209af236f454f5aa9a7b9092ed68a0112e7b067e7dce6.scope
    545      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod891055d5_950d_4580_862f_db5832542425.slice/cri-containerd-41c587ffaddc2e7d94409268eca83d826df88621e76dc0098e1335d6bc5eeafd.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod891055d5_950d_4580_862f_db5832542425.slice/cri-containerd-23814437cee85006c7752dc507c19478552fd69272c9e93bc7ad673072fe4255.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod819bd5e2_6682_4cf3_81b6_3c670b88010a.slice/cri-containerd-0f3d7230928552e704c1366cd45926bb33b7f1e8b85b7bd7e0cad4a29fea0fb8.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod819bd5e2_6682_4cf3_81b6_3c670b88010a.slice/cri-containerd-c0e5e9ea6a6ac590eb2f492d90c5541d5c5752a47202c7c988dd13b7e6409b65.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6e320555_a860_4c81_81e4_b6bcffe147b3.slice/cri-containerd-8d01e67217ca209df1d6b056f82c01ce8de61bc315b8cdcc9fbdeaca448b761e.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6e320555_a860_4c81_81e4_b6bcffe147b3.slice/cri-containerd-6dc051cbd7c4ebeb187f3305f06e3899f715e53fff201ae5a714eedbce32e058.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod65b983ae_db7e_411c_a87b_f63fde6d61fd.slice/cri-containerd-bd030719d3f5e1a0b62e7822c45b3ac23bd034108a6a4cbe740b593addf6af01.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod65b983ae_db7e_411c_a87b_f63fde6d61fd.slice/cri-containerd-f7582d290cbf563e2da84aa02fae544fe78146cabce97b68ecd650fa28035a5d.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod65b983ae_db7e_411c_a87b_f63fde6d61fd.slice/cri-containerd-fcada460fbc652ad9595b73e1df0474fb2c834fadaee3283945ca136cf6029f9.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod65b983ae_db7e_411c_a87b_f63fde6d61fd.slice/cri-containerd-d36c2f2f326c36c3d7a5013748d3a3ed0b4fa90fd6f66898431f2bb5ea89bc64.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd293996_1cee_4c2e_be0d_0eab40158817.slice/cri-containerd-652338724cf58428ea2980bfb3817c2030dab136a98c0c43dbb949edd4549e89.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd293996_1cee_4c2e_be0d_0eab40158817.slice/cri-containerd-b75c4889da6e7377daf823c6500f520a1aee64390c7bf42d095d9876fc947638.scope
    105      cgroup_device   multi                                          
