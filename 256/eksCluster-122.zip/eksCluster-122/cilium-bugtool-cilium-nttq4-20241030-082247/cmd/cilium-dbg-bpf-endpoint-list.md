IP ADDRESS         LOCAL ENDPOINT INFO
10.122.0.25:0      id=774   sec_id=4060381 flags=0x0000 ifindex=14  mac=6A:10:FB:D7:F8:52 nodemac=5E:C4:0E:8F:23:DA   
10.122.0.75:0      (localhost)                                                                                        
172.31.138.178:0   (localhost)                                                                                        
10.122.0.136:0     id=450   sec_id=4060381 flags=0x0000 ifindex=12  mac=DA:40:6C:1F:63:E8 nodemac=FA:96:B3:5E:CC:2F   
172.31.142.26:0    (localhost)                                                                                        
10.122.0.221:0     id=109   sec_id=4     flags=0x0000 ifindex=10  mac=06:FD:B8:84:8A:74 nodemac=4E:37:CA:57:87:47     
10.122.0.162:0     id=2412  sec_id=4059428 flags=0x0000 ifindex=18  mac=A2:E8:39:3E:4E:36 nodemac=DE:DD:3E:18:BA:D7   
