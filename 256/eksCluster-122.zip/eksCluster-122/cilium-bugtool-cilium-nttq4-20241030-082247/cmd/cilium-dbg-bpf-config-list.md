KEY             VALUE
AgentLiveness   2084523626543
UTimeOffset     3379442414062500
