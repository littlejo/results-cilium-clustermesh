 08:22:48 up 34 min,  0 users,  load average: 0.20, 0.26, 0.18
