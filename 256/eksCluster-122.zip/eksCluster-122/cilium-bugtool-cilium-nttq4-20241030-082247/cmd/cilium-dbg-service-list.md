ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.210.90:443 (active)     
                                        2 => 172.31.186.170:443 (active)    
2    10.100.182.69:443   ClusterIP      1 => 172.31.138.178:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.122.0.136:53 (active)       
                                        2 => 10.122.0.25:53 (active)        
4    10.100.0.10:9153    ClusterIP      1 => 10.122.0.136:9153 (active)     
                                        2 => 10.122.0.25:9153 (active)      
5    10.100.193.7:2379   ClusterIP      1 => 10.122.0.162:2379 (active)     
