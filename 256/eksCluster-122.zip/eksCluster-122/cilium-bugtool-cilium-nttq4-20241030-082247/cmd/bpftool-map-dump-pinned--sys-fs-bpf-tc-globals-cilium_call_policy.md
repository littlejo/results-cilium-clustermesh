key: 6d 00 00 00  value: 22 02 00 00
key: c2 01 00 00  value: 10 02 00 00
key: 06 03 00 00  value: 02 02 00 00
key: 6c 09 00 00  value: 73 02 00 00
Found 4 elements
