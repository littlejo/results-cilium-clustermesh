REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37588     2983407     677    bpf_overlay.c
Interface                 INGRESS     671364    136382035   1132   bpf_host.c
Success                   EGRESS      17660     1395982     1694   bpf_host.c
Success                   EGRESS      287933    35306655    1308   bpf_lxc.c
Success                   EGRESS      38641     3058745     53     encap.h
Success                   INGRESS     327163    37361465    86     l3.h
Success                   INGRESS     347742    38992936    235    trace.h
Unsupported L3 protocol   EGRESS      40        2976        1492   bpf_lxc.c
