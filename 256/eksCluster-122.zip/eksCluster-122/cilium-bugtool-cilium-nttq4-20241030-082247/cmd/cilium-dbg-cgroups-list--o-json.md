[
  {
    "containers": [
      {
        "cgroup-id": 7746,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5b89229a_2c71_4d9a_ba96_a77f8fe46279.slice/cri-containerd-96cad253c698595c3369858fa5d82078c007a0e48b4ab74c47440195f3e6647e.scope"
      }
    ],
    "ips": [
      "10.122.0.136"
    ],
    "name": "coredns-cc6ccd49c-r6cqs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7830,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod891055d5_950d_4580_862f_db5832542425.slice/cri-containerd-23814437cee85006c7752dc507c19478552fd69272c9e93bc7ad673072fe4255.scope"
      }
    ],
    "ips": [
      "10.122.0.25"
    ],
    "name": "coredns-cc6ccd49c-zh4c8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod65b983ae_db7e_411c_a87b_f63fde6d61fd.slice/cri-containerd-f7582d290cbf563e2da84aa02fae544fe78146cabce97b68ecd650fa28035a5d.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod65b983ae_db7e_411c_a87b_f63fde6d61fd.slice/cri-containerd-bd030719d3f5e1a0b62e7822c45b3ac23bd034108a6a4cbe740b593addf6af01.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod65b983ae_db7e_411c_a87b_f63fde6d61fd.slice/cri-containerd-d36c2f2f326c36c3d7a5013748d3a3ed0b4fa90fd6f66898431f2bb5ea89bc64.scope"
      }
    ],
    "ips": [
      "10.122.0.162"
    ],
    "name": "clustermesh-apiserver-6c789f96b6-4wzn4",
    "namespace": "kube-system"
  }
]

