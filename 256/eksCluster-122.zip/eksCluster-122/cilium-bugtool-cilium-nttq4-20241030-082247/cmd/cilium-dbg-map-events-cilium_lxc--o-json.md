{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:57.963Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.138.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:57.964Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.142.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:57.964Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:02.684Z",
  "value": "id=450   sec_id=4060381 flags=0x0000 ifindex=12  mac=DA:40:6C:1F:63:E8 nodemac=FA:96:B3:5E:CC:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:02.684Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=06:FD:B8:84:8A:74 nodemac=4E:37:CA:57:87:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:02.734Z",
  "value": "id=774   sec_id=4060381 flags=0x0000 ifindex=14  mac=6A:10:FB:D7:F8:52 nodemac=5E:C4:0E:8F:23:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:02.798Z",
  "value": "id=450   sec_id=4060381 flags=0x0000 ifindex=12  mac=DA:40:6C:1F:63:E8 nodemac=FA:96:B3:5E:CC:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:02.893Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=06:FD:B8:84:8A:74 nodemac=4E:37:CA:57:87:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:57.361Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=06:FD:B8:84:8A:74 nodemac=4E:37:CA:57:87:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:57.361Z",
  "value": "id=450   sec_id=4060381 flags=0x0000 ifindex=12  mac=DA:40:6C:1F:63:E8 nodemac=FA:96:B3:5E:CC:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:57.362Z",
  "value": "id=774   sec_id=4060381 flags=0x0000 ifindex=14  mac=6A:10:FB:D7:F8:52 nodemac=5E:C4:0E:8F:23:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:57.394Z",
  "value": "id=3554  sec_id=4059428 flags=0x0000 ifindex=16  mac=96:AA:F2:33:F3:E8 nodemac=6A:77:B5:72:EC:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:58.361Z",
  "value": "id=3554  sec_id=4059428 flags=0x0000 ifindex=16  mac=96:AA:F2:33:F3:E8 nodemac=6A:77:B5:72:EC:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:58.361Z",
  "value": "id=774   sec_id=4060381 flags=0x0000 ifindex=14  mac=6A:10:FB:D7:F8:52 nodemac=5E:C4:0E:8F:23:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:58.362Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=06:FD:B8:84:8A:74 nodemac=4E:37:CA:57:87:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:58.362Z",
  "value": "id=450   sec_id=4060381 flags=0x0000 ifindex=12  mac=DA:40:6C:1F:63:E8 nodemac=FA:96:B3:5E:CC:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:29.898Z",
  "value": "id=2412  sec_id=4059428 flags=0x0000 ifindex=18  mac=A2:E8:39:3E:4E:36 nodemac=DE:DD:3E:18:BA:D7"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.122.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.243Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.008Z",
  "value": "id=2412  sec_id=4059428 flags=0x0000 ifindex=18  mac=A2:E8:39:3E:4E:36 nodemac=DE:DD:3E:18:BA:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.010Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=06:FD:B8:84:8A:74 nodemac=4E:37:CA:57:87:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.010Z",
  "value": "id=450   sec_id=4060381 flags=0x0000 ifindex=12  mac=DA:40:6C:1F:63:E8 nodemac=FA:96:B3:5E:CC:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.011Z",
  "value": "id=774   sec_id=4060381 flags=0x0000 ifindex=14  mac=6A:10:FB:D7:F8:52 nodemac=5E:C4:0E:8F:23:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.011Z",
  "value": "id=2412  sec_id=4059428 flags=0x0000 ifindex=18  mac=A2:E8:39:3E:4E:36 nodemac=DE:DD:3E:18:BA:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.017Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=06:FD:B8:84:8A:74 nodemac=4E:37:CA:57:87:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.040Z",
  "value": "id=450   sec_id=4060381 flags=0x0000 ifindex=12  mac=DA:40:6C:1F:63:E8 nodemac=FA:96:B3:5E:CC:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.040Z",
  "value": "id=774   sec_id=4060381 flags=0x0000 ifindex=14  mac=6A:10:FB:D7:F8:52 nodemac=5E:C4:0E:8F:23:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.008Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=06:FD:B8:84:8A:74 nodemac=4E:37:CA:57:87:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.009Z",
  "value": "id=450   sec_id=4060381 flags=0x0000 ifindex=12  mac=DA:40:6C:1F:63:E8 nodemac=FA:96:B3:5E:CC:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.009Z",
  "value": "id=2412  sec_id=4059428 flags=0x0000 ifindex=18  mac=A2:E8:39:3E:4E:36 nodemac=DE:DD:3E:18:BA:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.010Z",
  "value": "id=774   sec_id=4060381 flags=0x0000 ifindex=14  mac=6A:10:FB:D7:F8:52 nodemac=5E:C4:0E:8F:23:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.009Z",
  "value": "id=774   sec_id=4060381 flags=0x0000 ifindex=14  mac=6A:10:FB:D7:F8:52 nodemac=5E:C4:0E:8F:23:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.009Z",
  "value": "id=2412  sec_id=4059428 flags=0x0000 ifindex=18  mac=A2:E8:39:3E:4E:36 nodemac=DE:DD:3E:18:BA:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.010Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=06:FD:B8:84:8A:74 nodemac=4E:37:CA:57:87:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.010Z",
  "value": "id=450   sec_id=4060381 flags=0x0000 ifindex=12  mac=DA:40:6C:1F:63:E8 nodemac=FA:96:B3:5E:CC:2F"
}

