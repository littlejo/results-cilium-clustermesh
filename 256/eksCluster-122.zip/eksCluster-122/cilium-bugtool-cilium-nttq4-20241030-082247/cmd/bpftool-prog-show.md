35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:38+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:48:38+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:48:39+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:48:39+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:48:39+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:39+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:48:43+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:48:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:48:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:48:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:57:00+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
485: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:57:00+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 125
486: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:57:00+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
487: sched_cls  name tail_handle_ipv4  tag 5690a8f735124827  gpl
	loaded_at 2024-10-30T07:57:00+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
510: sched_cls  name cil_from_container  tag 404ca2651cc95366  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,76
	btf_id 153
512: sched_cls  name tail_ipv4_to_endpoint  tag 1622d9716976f109  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,107,41,82,83,80,106,39,108,40,37,38
	btf_id 155
513: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 156
514: sched_cls  name handle_policy  tag 492b7104a14a6005  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,108,82,83,107,41,80,106,39,84,75,40,37,38
	btf_id 157
515: sched_cls  name tail_handle_ipv4  tag 038d8e512476d000  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 158
516: sched_cls  name __send_drop_notify  tag eafa9001a68f4a15  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 159
517: sched_cls  name tail_ipv4_ct_egress  tag 7f3d0bef924736fd  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 160
518: sched_cls  name tail_handle_arp  tag 0303445e78263bd7  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 161
519: sched_cls  name tail_handle_ipv4_cont  tag 84d7da8913261806  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,107,41,106,82,83,39,76,74,77,108,40,37,38,81
	btf_id 162
520: sched_cls  name tail_ipv4_ct_ingress  tag 755ec00c8008d50c  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 163
521: sched_cls  name tail_ipv4_ct_egress  tag 7f3d0bef924736fd  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 165
523: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 167
524: sched_cls  name tail_ipv4_to_endpoint  tag 99f9362ea3e9fd7b  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,109,41,82,83,80,101,39,110,40,37,38
	btf_id 168
525: sched_cls  name tail_handle_ipv4_cont  tag 0fe64efcfa8bdc0d  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,109,41,101,82,83,39,76,74,77,110,40,37,38,81
	btf_id 169
526: sched_cls  name tail_ipv4_ct_ingress  tag cbf33fe1ef7cfc30  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 170
527: sched_cls  name cil_from_container  tag 26b9944dd94d85b1  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 110,76
	btf_id 171
528: sched_cls  name handle_policy  tag 4e8a27cc776cd46d  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,110,82,83,109,41,80,101,39,84,75,40,37,38
	btf_id 172
529: sched_cls  name tail_handle_ipv4  tag 931642c4d561199d  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 173
530: sched_cls  name __send_drop_notify  tag 6379548fec125699  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 174
531: sched_cls  name tail_handle_arp  tag 0fdc44dad536402a  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 175
533: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 178
534: sched_cls  name cil_from_container  tag 70e5c70c13c0ad1e  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 112,76
	btf_id 179
535: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 180
536: sched_cls  name tail_handle_arp  tag ae61df34a24c5257  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 181
537: sched_cls  name tail_handle_ipv4_cont  tag ace4720c5a733ed6  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,111,41,100,82,83,39,76,74,77,112,40,37,38,81
	btf_id 182
538: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
541: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
542: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
545: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
546: sched_cls  name handle_policy  tag 41aec39a45b54e11  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,112,82,83,111,41,80,100,39,84,75,40,37,38
	btf_id 183
547: sched_cls  name tail_ipv4_ct_ingress  tag 4dc02891926f6f5e  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 184
548: sched_cls  name tail_ipv4_to_endpoint  tag 9c1d78e19ddd420c  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,111,41,82,83,80,100,39,112,40,37,38
	btf_id 185
549: sched_cls  name __send_drop_notify  tag 6bb3b09ea920df7c  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 186
550: sched_cls  name tail_handle_ipv4  tag b646965339e171d1  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 187
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
559: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,117
	btf_id 189
561: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 191
562: sched_cls  name __send_drop_notify  tag f9e11e4883057d0c  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
563: sched_cls  name tail_handle_ipv4_from_host  tag 96e0a88a21f63576  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 193
564: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 194
566: sched_cls  name tail_handle_ipv4_from_host  tag 96e0a88a21f63576  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 197
567: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 198
571: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 202
572: sched_cls  name __send_drop_notify  tag f9e11e4883057d0c  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
573: sched_cls  name tail_handle_ipv4_from_host  tag 96e0a88a21f63576  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 205
575: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 207
578: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 210
579: sched_cls  name __send_drop_notify  tag f9e11e4883057d0c  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 211
580: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 213
581: sched_cls  name __send_drop_notify  tag f9e11e4883057d0c  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 214
582: sched_cls  name tail_handle_ipv4_from_host  tag 96e0a88a21f63576  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 215
584: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:57:03+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 217
626: sched_cls  name cil_from_container  tag 3f1676bdb186c47f  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 233
627: sched_cls  name handle_policy  tag b2e234acddaef9bb  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 234
628: sched_cls  name tail_handle_ipv4  tag 70e452cb3c5be187  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 235
629: sched_cls  name tail_handle_arp  tag f6007ea36ade0ba5  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 236
631: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 238
632: sched_cls  name tail_ipv4_to_endpoint  tag 4ce0fe60d6274d3a  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 239
633: sched_cls  name __send_drop_notify  tag b544a51a67e797b3  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 240
634: sched_cls  name tail_ipv4_ct_ingress  tag 5bfb8b0589c5d6c0  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 241
635: sched_cls  name tail_ipv4_ct_egress  tag 5fbe0d42178d3add  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 242
636: sched_cls  name tail_handle_ipv4_cont  tag 7a22077208c678df  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 243
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
