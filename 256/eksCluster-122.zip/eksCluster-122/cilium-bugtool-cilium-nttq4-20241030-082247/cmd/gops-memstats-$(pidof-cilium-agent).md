alloc: 167.69MB (175839336 bytes)
total-alloc: 2.35GB (2527462920 bytes)
sys: 321.02MB (336613732 bytes)
lookups: 0
mallocs: 65144445
frees: 63590767
heap-alloc: 167.69MB (175839336 bytes)
heap-sys: 243.27MB (255082496 bytes)
heap-idle: 48.20MB (50544640 bytes)
heap-in-use: 195.06MB (204537856 bytes)
heap-released: 2.87MB (3006464 bytes)
heap-objects: 1553678
stack-in-use: 64.69MB (67829760 bytes)
stack-sys: 64.69MB (67829760 bytes)
stack-mspan-inuse: 3.03MB (3177440 bytes)
stack-mspan-sys: 3.78MB (3965760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.28MB (1343761 bytes)
gc-sys: 6.02MB (6313448 bytes)
next-gc: when heap-alloc >= 216.16MB (226662584 bytes)
last-gc: 2024-10-30 08:22:59.642460471 +0000 UTC
gc-pause-total: 20.445325ms
gc-pause: 357067
gc-pause-end: 1730276579642460471
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0004191460752072047
enable-gc: true
debug-gc: false
