xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 575
ens6(5) clsact/ingress cil_from_netdev-ens6 id 584
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 567
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 564
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 534
lxca338faf29869(12) clsact/ingress cil_from_container-lxca338faf29869 id 527
lxc169b91303aba(14) clsact/ingress cil_from_container-lxc169b91303aba id 510
lxce9c3adab03bc(18) clsact/ingress cil_from_container-lxce9c3adab03bc id 626

flow_dissector:

netfilter:

