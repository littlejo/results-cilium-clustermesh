Endpoint ID: 109
Path: /sys/fs/bpf/tc/globals/cilium_policy_00109

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1635133   20625     0        
Allow    Ingress     1          ANY          NONE         disabled    22246     257       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 450
Path: /sys/fs/bpf/tc/globals/cilium_policy_00450

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    151492   1737      0        
Allow    Egress      0          ANY          NONE         disabled    19989    222       0        


Endpoint ID: 774
Path: /sys/fs/bpf/tc/globals/cilium_policy_00774

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    150257   1723      0        
Allow    Egress      0          ANY          NONE         disabled    19715    217       0        


Endpoint ID: 797
Path: /sys/fs/bpf/tc/globals/cilium_policy_00797

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2412
Path: /sys/fs/bpf/tc/globals/cilium_policy_02412

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11443370   115487    0        
Allow    Ingress     1          ANY          NONE         disabled    10628655   111980    0        
Allow    Egress      0          ANY          NONE         disabled    15138615   147635    0        


