key: 2f 01 00 00  value: 32 02 00 00
key: 70 01 00 00  value: 3f 02 00 00
key: d4 01 00 00  value: 83 02 00 00
key: 12 04 00 00  value: 0d 02 00 00
Found 4 elements
