alloc: 171.43MB (179755192 bytes)
total-alloc: 2.31GB (2485371184 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 64420474
frees: 62657094
heap-alloc: 171.43MB (179755192 bytes)
heap-sys: 247.10MB (259104768 bytes)
heap-idle: 47.34MB (49635328 bytes)
heap-in-use: 199.77MB (209469440 bytes)
heap-released: 504.00KB (516096 bytes)
heap-objects: 1763380
stack-in-use: 64.88MB (68026368 bytes)
stack-sys: 64.88MB (68026368 bytes)
stack-mspan-inuse: 3.15MB (3306080 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.17MB (1221993 bytes)
gc-sys: 6.02MB (6309400 bytes)
next-gc: when heap-alloc >= 213.80MB (224189960 bytes)
last-gc: 2024-10-30 08:23:00.246249185 +0000 UTC
gc-pause-total: 20.012282ms
gc-pause: 131426
gc-pause-end: 1730276580246249185
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0004633352428434243
enable-gc: true
debug-gc: false
