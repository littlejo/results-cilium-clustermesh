REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36979     2923903     677    bpf_overlay.c
Interface                 INGRESS     653147    133786449   1132   bpf_host.c
Success                   EGRESS      16542     1301829     1694   bpf_host.c
Success                   EGRESS      276213    34509678    1308   bpf_lxc.c
Success                   EGRESS      37237     2943186     53     encap.h
Success                   INGRESS     319445    36006845    86     l3.h
Success                   INGRESS     340532    37672853    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
