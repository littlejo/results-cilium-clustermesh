CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda3a81072_de81_4c7a_b762_abadd666ade5.slice/cri-containerd-9f01a76e2ac716425011f7e7050ae4bb996e5564f834fb16b55db08ac7a54bbf.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda3a81072_de81_4c7a_b762_abadd666ade5.slice/cri-containerd-daca6017094b216ebfdea57de6a3275b172eb1ba32d0e8e9aba4464e96c95627.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd448dc78_5de9_4789_b960_f69cbed957d5.slice/cri-containerd-f76a88d29ca3b60dfba91b1df26324a34fa40de2a5c23d06f971fc7d608960ca.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd448dc78_5de9_4789_b960_f69cbed957d5.slice/cri-containerd-62b6f6a52a8298da841876c99231bfb480a6a357ca576852823e781f1ad86014.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod067bb7aa_e09d_4783_ac7e_7963c9424ecd.slice/cri-containerd-f7a0463fc65fdb6f85d73c8e9600fd511eccb83d705637b2c5bb8598fbb8fbfc.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod067bb7aa_e09d_4783_ac7e_7963c9424ecd.slice/cri-containerd-9fdc4bd284d5fc76afd83c98ae2b1de4fd05f3a245bfdf1cafd6cb36e13c713e.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podea90ef54_9cd0_4ff6_b0a4_7f7ccaf7b496.slice/cri-containerd-15f7fd6b91dbc22ea9aa676da5fefd4c0bc9269a7bf091b352c58183ea4e4f87.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podea90ef54_9cd0_4ff6_b0a4_7f7ccaf7b496.slice/cri-containerd-1863b2844fd8a510592d22efd7ee7a4783b5e7dd265cf0d6295768e2a01affae.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda696ae57_70d9_40cc_8a59_69af7f717672.slice/cri-containerd-31c9908f9d9e107b9c8b848a9133e90d5bf9d26548c25408cf12ba2b3fde8355.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda696ae57_70d9_40cc_8a59_69af7f717672.slice/cri-containerd-995147920db176c6f6a4bdbbc97d41dc5a9002efb1ee5e70ea112e9526502589.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf0882d8_9512_46ed_b812_84b36a6f9fef.slice/cri-containerd-ec72785e8a48c8fbb66cd4bd328de5647b0167a057b5f77fe093864dad790bb0.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf0882d8_9512_46ed_b812_84b36a6f9fef.slice/cri-containerd-5e7eb055f597e651c50757372102ec400e57592f170e2d49b3d96844e1174a61.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf0882d8_9512_46ed_b812_84b36a6f9fef.slice/cri-containerd-868e0c58e1b691ad1fc6b56f7f5f63171ad9fd7bb7619eb82af2bb40c16705ff.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf0882d8_9512_46ed_b812_84b36a6f9fef.slice/cri-containerd-54d6b467ffa14bafb76c18b87d3b8214ff0a3311c0f728c19f59646d1e03d46f.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f73a335_cc09_4f1e_9de1_46021d6dd56a.slice/cri-containerd-b6b68e4b43369c297d1907a1c10ca7f4f08516f5f44c3bb91feef2ee9fefdefa.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f73a335_cc09_4f1e_9de1_46021d6dd56a.slice/cri-containerd-bb3bb24df09bc768de2885e9a050b1c3e7432056bb3830c48b55f196d77cdb0d.scope
    95       cgroup_device   multi                                          
