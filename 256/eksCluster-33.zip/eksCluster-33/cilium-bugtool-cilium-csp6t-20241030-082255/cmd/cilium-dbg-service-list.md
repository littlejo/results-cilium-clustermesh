ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.180.176:443 (active)   
                                          2 => 172.31.200.83:443 (active)    
2    10.100.101.228:443    ClusterIP      1 => 172.31.250.23:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.33.0.189:53 (active)       
                                          2 => 10.33.0.18:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.33.0.189:9153 (active)     
                                          2 => 10.33.0.18:9153 (active)      
5    10.100.236.237:2379   ClusterIP      1 => 10.33.0.129:2379 (active)     
