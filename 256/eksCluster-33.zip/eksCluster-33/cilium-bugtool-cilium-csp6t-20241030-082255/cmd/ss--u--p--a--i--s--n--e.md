Total: 703
TCP:   1884 (estab 449, closed 1416, orphaned 0, timewait 560)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  468       456       12       
INET	  478       462       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                  Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                           127.0.0.1:39039      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:31979 sk:3fa fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.250.23%ens5:68         0.0.0.0:*    uid:192 ino:68358 sk:3fb cgroup:unreachable:c4e <->                            
UNCONN 0      0                             0.0.0.0:8472       0.0.0.0:*    ino:32101 sk:3fc cgroup:/ <->                                                  
UNCONN 0      0                           127.0.0.1:323        0.0.0.0:*    ino:15460 sk:3fd cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                [::]:8472          [::]:*    ino:32100 sk:3fe cgroup:/ v6only:1 <->                                         
UNCONN 0      0                               [::1]:323           [::]:*    ino:15461 sk:3ff cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::801:96ff:fedc:d2d]%ens5:546           [::]:*    uid:192 ino:15646 sk:400 cgroup:unreachable:c4e v6only:1 <->                   
