{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:47.655Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.245.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:47.655Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.250.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:47.655Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:52.128Z",
  "value": "id=1042  sec_id=1144402 flags=0x0000 ifindex=12  mac=F6:E4:34:CB:A9:46 nodemac=E2:93:41:0E:3A:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:52.150Z",
  "value": "id=368   sec_id=4     flags=0x0000 ifindex=10  mac=CA:A6:BF:F6:DE:13 nodemac=3A:6A:37:66:FD:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:52.173Z",
  "value": "id=303   sec_id=1144402 flags=0x0000 ifindex=14  mac=AE:DF:E9:9A:25:0F nodemac=AE:22:BC:6D:49:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:52.240Z",
  "value": "id=368   sec_id=4     flags=0x0000 ifindex=10  mac=CA:A6:BF:F6:DE:13 nodemac=3A:6A:37:66:FD:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:56.039Z",
  "value": "id=368   sec_id=4     flags=0x0000 ifindex=10  mac=CA:A6:BF:F6:DE:13 nodemac=3A:6A:37:66:FD:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:56.040Z",
  "value": "id=303   sec_id=1144402 flags=0x0000 ifindex=14  mac=AE:DF:E9:9A:25:0F nodemac=AE:22:BC:6D:49:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:56.040Z",
  "value": "id=1042  sec_id=1144402 flags=0x0000 ifindex=12  mac=F6:E4:34:CB:A9:46 nodemac=E2:93:41:0E:3A:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:56.070Z",
  "value": "id=1065  sec_id=1137836 flags=0x0000 ifindex=16  mac=8E:D6:5E:FF:AD:72 nodemac=E2:C2:F9:86:3C:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:57.036Z",
  "value": "id=1042  sec_id=1144402 flags=0x0000 ifindex=12  mac=F6:E4:34:CB:A9:46 nodemac=E2:93:41:0E:3A:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:57.037Z",
  "value": "id=1065  sec_id=1137836 flags=0x0000 ifindex=16  mac=8E:D6:5E:FF:AD:72 nodemac=E2:C2:F9:86:3C:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:57.037Z",
  "value": "id=303   sec_id=1144402 flags=0x0000 ifindex=14  mac=AE:DF:E9:9A:25:0F nodemac=AE:22:BC:6D:49:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:57.037Z",
  "value": "id=368   sec_id=4     flags=0x0000 ifindex=10  mac=CA:A6:BF:F6:DE:13 nodemac=3A:6A:37:66:FD:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:48.228Z",
  "value": "id=468   sec_id=1137836 flags=0x0000 ifindex=18  mac=9E:7C:92:AA:9C:71 nodemac=BE:50:C9:41:3F:63"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.33.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.680Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.234Z",
  "value": "id=303   sec_id=1144402 flags=0x0000 ifindex=14  mac=AE:DF:E9:9A:25:0F nodemac=AE:22:BC:6D:49:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.236Z",
  "value": "id=368   sec_id=4     flags=0x0000 ifindex=10  mac=CA:A6:BF:F6:DE:13 nodemac=3A:6A:37:66:FD:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.236Z",
  "value": "id=1042  sec_id=1144402 flags=0x0000 ifindex=12  mac=F6:E4:34:CB:A9:46 nodemac=E2:93:41:0E:3A:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.238Z",
  "value": "id=468   sec_id=1137836 flags=0x0000 ifindex=18  mac=9E:7C:92:AA:9C:71 nodemac=BE:50:C9:41:3F:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.234Z",
  "value": "id=368   sec_id=4     flags=0x0000 ifindex=10  mac=CA:A6:BF:F6:DE:13 nodemac=3A:6A:37:66:FD:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.234Z",
  "value": "id=468   sec_id=1137836 flags=0x0000 ifindex=18  mac=9E:7C:92:AA:9C:71 nodemac=BE:50:C9:41:3F:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.235Z",
  "value": "id=1042  sec_id=1144402 flags=0x0000 ifindex=12  mac=F6:E4:34:CB:A9:46 nodemac=E2:93:41:0E:3A:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.235Z",
  "value": "id=303   sec_id=1144402 flags=0x0000 ifindex=14  mac=AE:DF:E9:9A:25:0F nodemac=AE:22:BC:6D:49:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.235Z",
  "value": "id=1042  sec_id=1144402 flags=0x0000 ifindex=12  mac=F6:E4:34:CB:A9:46 nodemac=E2:93:41:0E:3A:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.235Z",
  "value": "id=468   sec_id=1137836 flags=0x0000 ifindex=18  mac=9E:7C:92:AA:9C:71 nodemac=BE:50:C9:41:3F:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.236Z",
  "value": "id=303   sec_id=1144402 flags=0x0000 ifindex=14  mac=AE:DF:E9:9A:25:0F nodemac=AE:22:BC:6D:49:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.33.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.236Z",
  "value": "id=368   sec_id=4     flags=0x0000 ifindex=10  mac=CA:A6:BF:F6:DE:13 nodemac=3A:6A:37:66:FD:A4"
}

