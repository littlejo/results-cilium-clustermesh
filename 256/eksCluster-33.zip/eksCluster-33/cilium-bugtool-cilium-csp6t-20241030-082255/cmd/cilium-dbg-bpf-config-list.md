KEY             VALUE
AgentLiveness   2147216085978
UTimeOffset     3379442306640625
