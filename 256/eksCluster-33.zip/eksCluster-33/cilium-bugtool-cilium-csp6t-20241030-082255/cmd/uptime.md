 08:22:56 up 35 min,  0 users,  load average: 0.08, 0.12, 0.11
