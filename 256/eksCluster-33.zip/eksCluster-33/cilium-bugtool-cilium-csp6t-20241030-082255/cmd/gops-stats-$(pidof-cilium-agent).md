goroutines: 10831
OS threads: 24
GOMAXPROCS: 2
num CPU: 2
