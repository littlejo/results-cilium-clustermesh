IP ADDRESS         LOCAL ENDPOINT INFO
172.31.245.175:0   (localhost)                                                                                        
10.33.0.229:0      id=368   sec_id=4     flags=0x0000 ifindex=10  mac=CA:A6:BF:F6:DE:13 nodemac=3A:6A:37:66:FD:A4     
10.33.0.165:0      (localhost)                                                                                        
172.31.250.23:0    (localhost)                                                                                        
10.33.0.129:0      id=468   sec_id=1137836 flags=0x0000 ifindex=18  mac=9E:7C:92:AA:9C:71 nodemac=BE:50:C9:41:3F:63   
10.33.0.189:0      id=1042  sec_id=1144402 flags=0x0000 ifindex=12  mac=F6:E4:34:CB:A9:46 nodemac=E2:93:41:0E:3A:DC   
10.33.0.18:0       id=303   sec_id=1144402 flags=0x0000 ifindex=14  mac=AE:DF:E9:9A:25:0F nodemac=AE:22:BC:6D:49:9D   
