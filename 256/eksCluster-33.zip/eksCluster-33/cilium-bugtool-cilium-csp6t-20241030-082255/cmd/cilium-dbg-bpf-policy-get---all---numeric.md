Endpoint ID: 303
Path: /sys/fs/bpf/tc/globals/cilium_policy_00303

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    164362   1892      0        
Allow    Egress      0          ANY          NONE         disabled    20166    226       0        


Endpoint ID: 368
Path: /sys/fs/bpf/tc/globals/cilium_policy_00368

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1671006   21148     0        
Allow    Ingress     1          ANY          NONE         disabled    23964     278       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 468
Path: /sys/fs/bpf/tc/globals/cilium_policy_00468

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11615502   115998    0        
Allow    Ingress     1          ANY          NONE         disabled    10258154   108044    0        
Allow    Egress      0          ANY          NONE         disabled    13261787   130478    0        


Endpoint ID: 1042
Path: /sys/fs/bpf/tc/globals/cilium_policy_01042

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    164767   1893      0        
Allow    Egress      0          ANY          NONE         disabled    20945    234       0        


Endpoint ID: 1135
Path: /sys/fs/bpf/tc/globals/cilium_policy_01135

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


