USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         678  0.0  0.1 1616008 8304 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         677  0.0  0.1 1616008 8456 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         655  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         654  0.0  0.2 1240176 16020 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         690  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         691  0.0  0.0   3728   484 ?        R    08:22   0:00  \_ bash -c hostname
root         637  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         630  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.1  4.7 1606336 380808 ?      Ssl  07:54   0:53 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.1 1229744 8288 ?        Sl   07:54   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
