1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:01:96:dc:0d:2d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.250.23/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3295sec preferred_lft 3295sec
    inet6 fe80::801:96ff:fedc:d2d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:0f:26:b2:44:99 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.245.175/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::80f:26ff:feb2:4499/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:fc:32:08:84:73 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::84fc:32ff:fe08:8473/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:fb:53:0f:78:e3 brd ff:ff:ff:ff:ff:ff
    inet 10.33.0.165/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::f4fb:53ff:fe0f:78e3/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether b2:12:9c:9c:61:e4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b012:9cff:fe9c:61e4/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:6a:37:66:fd:a4 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::386a:37ff:fe66:fda4/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca7b2c79f7152@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:93:41:0e:3a:dc brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::e093:41ff:fe0e:3adc/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcab53d51e1e33@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:22:bc:6d:49:9d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ac22:bcff:fe6d:499d/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb25260897083@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:50:c9:41:3f:63 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::bc50:c9ff:fe41:3f63/64 scope link 
       valid_lft forever preferred_lft forever
