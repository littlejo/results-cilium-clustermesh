[
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf0882d8_9512_46ed_b812_84b36a6f9fef.slice/cri-containerd-54d6b467ffa14bafb76c18b87d3b8214ff0a3311c0f728c19f59646d1e03d46f.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf0882d8_9512_46ed_b812_84b36a6f9fef.slice/cri-containerd-ec72785e8a48c8fbb66cd4bd328de5647b0167a057b5f77fe093864dad790bb0.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf0882d8_9512_46ed_b812_84b36a6f9fef.slice/cri-containerd-5e7eb055f597e651c50757372102ec400e57592f170e2d49b3d96844e1174a61.scope"
      }
    ],
    "ips": [
      "10.33.0.129"
    ],
    "name": "clustermesh-apiserver-5bb85c95f9-kmrp7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podea90ef54_9cd0_4ff6_b0a4_7f7ccaf7b496.slice/cri-containerd-15f7fd6b91dbc22ea9aa676da5fefd4c0bc9269a7bf091b352c58183ea4e4f87.scope"
      }
    ],
    "ips": [
      "10.33.0.189"
    ],
    "name": "coredns-cc6ccd49c-5lc27",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd448dc78_5de9_4789_b960_f69cbed957d5.slice/cri-containerd-62b6f6a52a8298da841876c99231bfb480a6a357ca576852823e781f1ad86014.scope"
      }
    ],
    "ips": [
      "10.33.0.18"
    ],
    "name": "coredns-cc6ccd49c-wmwnk",
    "namespace": "kube-system"
  }
]

