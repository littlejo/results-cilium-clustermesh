top - 08:22:56 up 35 min,  0 users,  load average: 0.08, 0.12, 0.11
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s):  7.4 us, 33.3 sy,  0.0 ni, 51.9 id,  0.0 wa,  0.0 hi,  7.4 si,  0.0 st
MiB Mem :   7814.2 total,   4483.1 free,   1183.9 used,   2147.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6445.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 380808  78080 S   6.7   4.8   0:53.26 cilium-+
    393 root      20   0 1229744   8288   4032 S   0.0   0.1   0:01.14 cilium-+
    630 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    637 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    654 root      20   0 1240432  16496  11484 S   0.0   0.2   0:00.02 cilium-+
    655 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    677 root      20   0 1228744   3656   2976 S   0.0   0.0   0:00.00 gops
    704 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    722 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
    734 root      20   0 1692104   8780   6284 S   0.0   0.1   0:00.00 runc:[2+
