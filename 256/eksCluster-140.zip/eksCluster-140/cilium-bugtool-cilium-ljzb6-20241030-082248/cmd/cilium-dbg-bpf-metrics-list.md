REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35428     2798534     677    bpf_overlay.c
Interface                 INGRESS     627759    130097576   1132   bpf_host.c
Success                   EGRESS      15345     1203180     1694   bpf_host.c
Success                   EGRESS      265524    33478386    1308   bpf_lxc.c
Success                   EGRESS      35063     2771964     53     encap.h
Success                   INGRESS     306961    34571126    86     l3.h
Success                   INGRESS     327695    36210526    235    trace.h
Unsupported L3 protocol   EGRESS      40        2960        1492   bpf_lxc.c
