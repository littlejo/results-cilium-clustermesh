CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62f859ab_d039_4407_a791_e770f87d8dbe.slice/cri-containerd-3316ac006c65ec11beeff2b557ec3d5d72f31c7809fe29a03b17c53ddf49fc88.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62f859ab_d039_4407_a791_e770f87d8dbe.slice/cri-containerd-b3cb53e56ea99818ad0cd769a6b28229bff3d6ba77d55d4eaff1a24aa65a76ac.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c9ba828_5916_4e34_9c7d_4d648eedfe74.slice/cri-containerd-2d899502c2f79dbcd93c96240db5c6f83a469f10a8bfd88a6996a62354dae599.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c9ba828_5916_4e34_9c7d_4d648eedfe74.slice/cri-containerd-f7267d4e11e1a60c8329de814e1a678c70539d5d4d22873bc1dcb6f9490ecdf4.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod49ded8e9_1d8e_4ead_b5d7_9a211c9d066e.slice/cri-containerd-e11b49fbfd6ff086cac64d168c264ecdb8b4fcaefc66a6b20b63dab7ff130809.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod49ded8e9_1d8e_4ead_b5d7_9a211c9d066e.slice/cri-containerd-ca1b61c22578dd1b0286b81f89af3630f7c50d16b4cebb891fcb1775004906ad.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb4229819_5013_4b2e_a689_14a7f57c4713.slice/cri-containerd-594ff8e7d4373b730852f5c7e80043917bbe53d50d9a24722b95e20224df913e.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb4229819_5013_4b2e_a689_14a7f57c4713.slice/cri-containerd-c778d5c4634d57f79c7dc493e81a4f761691a8d6e6ea28bc392dce1ea894fdb9.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e32aa83_53c4_47dc_99d9_874f210fc0c0.slice/cri-containerd-f549c00fc1ff2fb4e0e351c603c4ed7ffa886047407b25d90b7ec82def61a86e.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e32aa83_53c4_47dc_99d9_874f210fc0c0.slice/cri-containerd-13172b036aa61ee5cf0c15bdb1c2b598051196f541a87606f49b463c3be065ec.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod77f1664c_13a1_4986_9d84_7026c867e604.slice/cri-containerd-73dbeb788ed5200197d32bbb3e64c760006b8b45de3042c6cfbeabc5df1b01a7.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod77f1664c_13a1_4986_9d84_7026c867e604.slice/cri-containerd-cd232c4afe5a5e59589bb731d5ecc14c696c429a5dc2232409842219a1f93deb.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc985bd8_3212_4149_97c8_65a0a3f1ce0c.slice/cri-containerd-dd43553c498ee6828836088122f6ce96d54602dccfeb7c2c08a2ed7e65466da9.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc985bd8_3212_4149_97c8_65a0a3f1ce0c.slice/cri-containerd-de12169861b053e85d5dd1e7cd4b9e25626342085e22b131c5da880f1ae7f7f3.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc985bd8_3212_4149_97c8_65a0a3f1ce0c.slice/cri-containerd-c6d41f82e16143a1caf3e48e221a7ee7950d3e8fbb8984422590f0902a290f56.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc985bd8_3212_4149_97c8_65a0a3f1ce0c.slice/cri-containerd-1917ecfc32f7c7b29e0b031802119e750326105d36151ddc7951096ad7ee31b1.scope
    653      cgroup_device   multi                                          
