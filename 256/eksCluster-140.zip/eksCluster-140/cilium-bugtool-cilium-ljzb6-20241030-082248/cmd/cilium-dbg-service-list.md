ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.135.49:443 (active)     
                                         2 => 172.31.250.110:443 (active)    
2    10.100.152.105:443   ClusterIP      1 => 172.31.184.128:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.140.0.46:53 (active)        
                                         2 => 10.140.0.179:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.140.0.46:9153 (active)      
                                         2 => 10.140.0.179:9153 (active)     
5    10.100.187.59:2379   ClusterIP      1 => 10.140.0.144:2379 (active)     
