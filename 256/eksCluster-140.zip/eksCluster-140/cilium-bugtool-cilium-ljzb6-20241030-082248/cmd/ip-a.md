1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:18:44:6f:67:f5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.184.128/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3511sec preferred_lft 3511sec
    inet6 fe80::418:44ff:fe6f:67f5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:11:a1:52:d3:33 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.184.207/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::411:a1ff:fe52:d333/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:a8:9c:e4:18:cf brd ff:ff:ff:ff:ff:ff
    inet6 fe80::70a8:9cff:fee4:18cf/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:2e:f5:c0:95:43 brd ff:ff:ff:ff:ff:ff
    inet 10.140.0.229/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::302e:f5ff:fec0:9543/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 56:b0:56:ed:8a:f7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::54b0:56ff:feed:8af7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:e5:99:7f:bc:cd brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::ece5:99ff:fe7f:bccd/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcdf1e2f5836e2@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:73:df:94:60:55 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b473:dfff:fe94:6055/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc087dc73dbfde@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:27:6e:fa:b9:19 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d027:6eff:fefa:b919/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcd182453a8993@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:d7:23:22:a6:d0 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::f8d7:23ff:fe22:a6d0/64 scope link 
       valid_lft forever preferred_lft forever
