KEY             VALUE
AgentLiveness   1933674223250
UTimeOffset     3379442708984375
