top - 08:22:49 up 31 min,  0 users,  load average: 0.03, 0.12, 0.14
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 56.7 us, 33.3 sy,  0.0 ni,  6.7 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4481.8 free,   1186.0 used,   2146.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6443.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 393320  78020 S  86.7   4.9   0:46.00 cilium-+
    678 root      20   0 1240432  15564  10576 S   6.7   0.2   0:00.03 cilium-+
    400 root      20   0 1229744   7992   3836 S   0.0   0.1   0:01.11 cilium-+
    651 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    661 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    693 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    730 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    756 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
