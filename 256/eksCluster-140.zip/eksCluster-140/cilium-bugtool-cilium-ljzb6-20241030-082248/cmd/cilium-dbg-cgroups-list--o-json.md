[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc985bd8_3212_4149_97c8_65a0a3f1ce0c.slice/cri-containerd-dd43553c498ee6828836088122f6ce96d54602dccfeb7c2c08a2ed7e65466da9.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc985bd8_3212_4149_97c8_65a0a3f1ce0c.slice/cri-containerd-de12169861b053e85d5dd1e7cd4b9e25626342085e22b131c5da880f1ae7f7f3.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc985bd8_3212_4149_97c8_65a0a3f1ce0c.slice/cri-containerd-1917ecfc32f7c7b29e0b031802119e750326105d36151ddc7951096ad7ee31b1.scope"
      }
    ],
    "ips": [
      "10.140.0.144"
    ],
    "name": "clustermesh-apiserver-867cbbc694-mj67l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62f859ab_d039_4407_a791_e770f87d8dbe.slice/cri-containerd-3316ac006c65ec11beeff2b557ec3d5d72f31c7809fe29a03b17c53ddf49fc88.scope"
      }
    ],
    "ips": [
      "10.140.0.46"
    ],
    "name": "coredns-cc6ccd49c-87lvx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb4229819_5013_4b2e_a689_14a7f57c4713.slice/cri-containerd-594ff8e7d4373b730852f5c7e80043917bbe53d50d9a24722b95e20224df913e.scope"
      }
    ],
    "ips": [
      "10.140.0.179"
    ],
    "name": "coredns-cc6ccd49c-lvtcp",
    "namespace": "kube-system"
  }
]

