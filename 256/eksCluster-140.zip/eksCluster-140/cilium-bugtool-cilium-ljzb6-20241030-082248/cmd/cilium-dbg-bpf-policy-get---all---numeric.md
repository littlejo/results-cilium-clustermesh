Endpoint ID: 151
Path: /sys/fs/bpf/tc/globals/cilium_policy_00151

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    124396   1427      0        
Allow    Egress      0          ANY          NONE         disabled    17899    196       0        


Endpoint ID: 453
Path: /sys/fs/bpf/tc/globals/cilium_policy_00453

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1916
Path: /sys/fs/bpf/tc/globals/cilium_policy_01916

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11420288   113126    0        
Allow    Ingress     1          ANY          NONE         disabled    9763002    102435    0        
Allow    Egress      0          ANY          NONE         disabled    12197751   120477    0        


Endpoint ID: 2900
Path: /sys/fs/bpf/tc/globals/cilium_policy_02900

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1642212   20769     0        
Allow    Ingress     1          ANY          NONE         disabled    19102     225       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3951
Path: /sys/fs/bpf/tc/globals/cilium_policy_03951

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    124339   1430      0        
Allow    Egress      0          ANY          NONE         disabled    16956    184       0        


