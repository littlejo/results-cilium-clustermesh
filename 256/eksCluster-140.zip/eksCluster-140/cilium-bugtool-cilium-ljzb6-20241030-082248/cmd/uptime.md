 08:22:49 up 31 min,  0 users,  load average: 0.03, 0.12, 0.14
