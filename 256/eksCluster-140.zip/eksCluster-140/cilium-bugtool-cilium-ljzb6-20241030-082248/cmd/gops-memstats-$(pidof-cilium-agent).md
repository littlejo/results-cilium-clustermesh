alloc: 134.09MB (140606504 bytes)
total-alloc: 2.21GB (2377407280 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 62893589
frees: 61559867
heap-alloc: 134.09MB (140606504 bytes)
heap-sys: 251.54MB (263757824 bytes)
heap-idle: 84.34MB (88440832 bytes)
heap-in-use: 167.20MB (175316992 bytes)
heap-released: 6.59MB (6905856 bytes)
heap-objects: 1333722
stack-in-use: 64.44MB (67567616 bytes)
stack-sys: 64.44MB (67567616 bytes)
stack-mspan-inuse: 2.83MB (2964800 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1012.30KB (1036593 bytes)
gc-sys: 6.02MB (6307376 bytes)
next-gc: when heap-alloc >= 213.35MB (223718440 bytes)
last-gc: 2024-10-30 08:22:59.652115285 +0000 UTC
gc-pause-total: 19.510277ms
gc-pause: 104953
gc-pause-end: 1730276579652115285
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.00046084903921652856
enable-gc: true
debug-gc: false
