IP ADDRESS         LOCAL ENDPOINT INFO
172.31.184.207:0   (localhost)                                                                                        
172.31.184.128:0   (localhost)                                                                                        
10.140.0.46:0      id=3951  sec_id=4630903 flags=0x0000 ifindex=12  mac=5E:80:5D:54:43:FD nodemac=B6:73:DF:94:60:55   
10.140.0.144:0     id=1916  sec_id=4639216 flags=0x0000 ifindex=18  mac=BE:B3:FD:F4:A8:34 nodemac=FA:D7:23:22:A6:D0   
10.140.0.88:0      id=2900  sec_id=4     flags=0x0000 ifindex=10  mac=DE:85:DA:9B:90:AD nodemac=EE:E5:99:7F:BC:CD     
10.140.0.229:0     (localhost)                                                                                        
10.140.0.179:0     id=151   sec_id=4630903 flags=0x0000 ifindex=14  mac=EE:6B:E5:59:CC:27 nodemac=D2:27:6E:FA:B9:19   
