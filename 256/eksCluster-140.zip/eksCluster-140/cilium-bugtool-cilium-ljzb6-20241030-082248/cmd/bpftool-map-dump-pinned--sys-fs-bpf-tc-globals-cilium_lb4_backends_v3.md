key: 01 00 00 00  value: ac 1f 87 31 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f b8 80 10 94 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f fa 6e 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 8c 00 b3 00 35 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 8c 00 2e 00 35 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 8c 00 90 09 4b 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 8c 00 b3 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 8c 00 2e 23 c1 00 00  00 00 00 00
Found 8 elements
