key: 97 00 00 00  value: 1f 02 00 00
key: 7c 07 00 00  value: 6b 02 00 00
key: 54 0b 00 00  value: 26 02 00 00
key: 6f 0f 00 00  value: 16 02 00 00
Found 4 elements
