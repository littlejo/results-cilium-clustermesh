{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:37.108Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.184.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:37.108Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.184.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:37.108Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.820Z",
  "value": "id=2900  sec_id=4     flags=0x0000 ifindex=10  mac=DE:85:DA:9B:90:AD nodemac=EE:E5:99:7F:BC:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.825Z",
  "value": "id=3951  sec_id=4630903 flags=0x0000 ifindex=12  mac=5E:80:5D:54:43:FD nodemac=B6:73:DF:94:60:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.863Z",
  "value": "id=2900  sec_id=4     flags=0x0000 ifindex=10  mac=DE:85:DA:9B:90:AD nodemac=EE:E5:99:7F:BC:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.883Z",
  "value": "id=151   sec_id=4630903 flags=0x0000 ifindex=14  mac=EE:6B:E5:59:CC:27 nodemac=D2:27:6E:FA:B9:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:36.873Z",
  "value": "id=151   sec_id=4630903 flags=0x0000 ifindex=14  mac=EE:6B:E5:59:CC:27 nodemac=D2:27:6E:FA:B9:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:36.874Z",
  "value": "id=2900  sec_id=4     flags=0x0000 ifindex=10  mac=DE:85:DA:9B:90:AD nodemac=EE:E5:99:7F:BC:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:36.875Z",
  "value": "id=3951  sec_id=4630903 flags=0x0000 ifindex=12  mac=5E:80:5D:54:43:FD nodemac=B6:73:DF:94:60:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:36.903Z",
  "value": "id=263   sec_id=4639216 flags=0x0000 ifindex=16  mac=26:48:20:74:5E:15 nodemac=3E:6E:A0:9E:1C:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:37.873Z",
  "value": "id=3951  sec_id=4630903 flags=0x0000 ifindex=12  mac=5E:80:5D:54:43:FD nodemac=B6:73:DF:94:60:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:37.874Z",
  "value": "id=2900  sec_id=4     flags=0x0000 ifindex=10  mac=DE:85:DA:9B:90:AD nodemac=EE:E5:99:7F:BC:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:37.874Z",
  "value": "id=151   sec_id=4630903 flags=0x0000 ifindex=14  mac=EE:6B:E5:59:CC:27 nodemac=D2:27:6E:FA:B9:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:37.874Z",
  "value": "id=263   sec_id=4639216 flags=0x0000 ifindex=16  mac=26:48:20:74:5E:15 nodemac=3E:6E:A0:9E:1C:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.441Z",
  "value": "id=1916  sec_id=4639216 flags=0x0000 ifindex=18  mac=BE:B3:FD:F4:A8:34 nodemac=FA:D7:23:22:A6:D0"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.140.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:36.124Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.958Z",
  "value": "id=2900  sec_id=4     flags=0x0000 ifindex=10  mac=DE:85:DA:9B:90:AD nodemac=EE:E5:99:7F:BC:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.958Z",
  "value": "id=3951  sec_id=4630903 flags=0x0000 ifindex=12  mac=5E:80:5D:54:43:FD nodemac=B6:73:DF:94:60:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.959Z",
  "value": "id=151   sec_id=4630903 flags=0x0000 ifindex=14  mac=EE:6B:E5:59:CC:27 nodemac=D2:27:6E:FA:B9:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.959Z",
  "value": "id=1916  sec_id=4639216 flags=0x0000 ifindex=18  mac=BE:B3:FD:F4:A8:34 nodemac=FA:D7:23:22:A6:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.887Z",
  "value": "id=1916  sec_id=4639216 flags=0x0000 ifindex=18  mac=BE:B3:FD:F4:A8:34 nodemac=FA:D7:23:22:A6:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.888Z",
  "value": "id=2900  sec_id=4     flags=0x0000 ifindex=10  mac=DE:85:DA:9B:90:AD nodemac=EE:E5:99:7F:BC:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.888Z",
  "value": "id=3951  sec_id=4630903 flags=0x0000 ifindex=12  mac=5E:80:5D:54:43:FD nodemac=B6:73:DF:94:60:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.889Z",
  "value": "id=151   sec_id=4630903 flags=0x0000 ifindex=14  mac=EE:6B:E5:59:CC:27 nodemac=D2:27:6E:FA:B9:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.886Z",
  "value": "id=1916  sec_id=4639216 flags=0x0000 ifindex=18  mac=BE:B3:FD:F4:A8:34 nodemac=FA:D7:23:22:A6:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.887Z",
  "value": "id=2900  sec_id=4     flags=0x0000 ifindex=10  mac=DE:85:DA:9B:90:AD nodemac=EE:E5:99:7F:BC:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.887Z",
  "value": "id=3951  sec_id=4630903 flags=0x0000 ifindex=12  mac=5E:80:5D:54:43:FD nodemac=B6:73:DF:94:60:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.887Z",
  "value": "id=151   sec_id=4630903 flags=0x0000 ifindex=14  mac=EE:6B:E5:59:CC:27 nodemac=D2:27:6E:FA:B9:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.887Z",
  "value": "id=2900  sec_id=4     flags=0x0000 ifindex=10  mac=DE:85:DA:9B:90:AD nodemac=EE:E5:99:7F:BC:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.887Z",
  "value": "id=3951  sec_id=4630903 flags=0x0000 ifindex=12  mac=5E:80:5D:54:43:FD nodemac=B6:73:DF:94:60:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.888Z",
  "value": "id=151   sec_id=4630903 flags=0x0000 ifindex=14  mac=EE:6B:E5:59:CC:27 nodemac=D2:27:6E:FA:B9:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.140.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.888Z",
  "value": "id=1916  sec_id=4639216 flags=0x0000 ifindex=18  mac=BE:B3:FD:F4:A8:34 nodemac=FA:D7:23:22:A6:D0"
}

