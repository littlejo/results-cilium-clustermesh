[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc64f53fe_d1c5_47f6_b14a_ffe171d2c880.slice/cri-containerd-d9d2d11c231be298e02728018093d2b55ec8fe5b24b2bac7cf35037d228d2584.scope"
      }
    ],
    "ips": [
      "10.110.0.230"
    ],
    "name": "coredns-cc6ccd49c-zf2qp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod69f4eb06_6343_4885_b2e0_b76726f8e616.slice/cri-containerd-a4b54992ed1cb1b4cd8ad4acfc03943b91f81bb7cdb54c533d57f04361385d77.scope"
      }
    ],
    "ips": [
      "10.110.0.233"
    ],
    "name": "coredns-cc6ccd49c-z4nkl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b8a8821_4bda_4a7c_b436_9204386cd197.slice/cri-containerd-8af76d0b76001461261f75610f02d30e3370f7712288e31d53eefed4c0d303f0.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b8a8821_4bda_4a7c_b436_9204386cd197.slice/cri-containerd-a869fde5b985c447fe66e68497abe49c4f45be10ad7509a0364b1f7dcf528c00.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b8a8821_4bda_4a7c_b436_9204386cd197.slice/cri-containerd-014f26b22cd99f87c003947e43d2ebcf3b4054e6109991ece2d87bccbf5dd6c1.scope"
      }
    ],
    "ips": [
      "10.110.0.22"
    ],
    "name": "clustermesh-apiserver-c9485d58-jq8l8",
    "namespace": "kube-system"
  }
]

