 08:22:49 up 33 min,  0 users,  load average: 0.52, 0.24, 0.18
