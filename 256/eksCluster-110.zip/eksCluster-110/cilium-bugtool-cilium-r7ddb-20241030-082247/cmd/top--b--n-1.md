top - 08:22:49 up 33 min,  0 users,  load average: 0.52, 0.24, 0.18
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 14.3 us, 25.0 sy,  0.0 ni, 60.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4456.5 free,   1209.5 used,   2148.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6419.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 399240  79220 S   6.7   5.0   0:58.72 cilium-+
    683 root      20   0 1240432  16288  11228 S   6.7   0.2   0:00.03 cilium-+
    398 root      20   0 1229744   8320   3836 S   0.0   0.1   0:01.14 cilium-+
    649 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    662 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    672 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    682 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    725 root      20   0    6576   2420   2096 R   0.0   0.0   0:00.00 top
    743 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
