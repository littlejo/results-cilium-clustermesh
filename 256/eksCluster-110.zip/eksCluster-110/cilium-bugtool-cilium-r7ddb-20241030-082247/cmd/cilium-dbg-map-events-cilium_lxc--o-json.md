{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:14.025Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.136.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:14.025Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.152.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:14.025Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:18.698Z",
  "value": "id=1981  sec_id=4     flags=0x0000 ifindex=10  mac=EE:FC:66:D7:07:46 nodemac=CE:13:58:5A:4F:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:18.704Z",
  "value": "id=1278  sec_id=3638162 flags=0x0000 ifindex=12  mac=42:FF:47:E5:2F:C1 nodemac=A6:D2:B8:67:57:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:18.755Z",
  "value": "id=2866  sec_id=3638162 flags=0x0000 ifindex=14  mac=B2:9F:BF:57:29:6B nodemac=0E:9F:03:74:36:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:18.784Z",
  "value": "id=1981  sec_id=4     flags=0x0000 ifindex=10  mac=EE:FC:66:D7:07:46 nodemac=CE:13:58:5A:4F:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:40.317Z",
  "value": "id=2866  sec_id=3638162 flags=0x0000 ifindex=14  mac=B2:9F:BF:57:29:6B nodemac=0E:9F:03:74:36:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:40.318Z",
  "value": "id=1981  sec_id=4     flags=0x0000 ifindex=10  mac=EE:FC:66:D7:07:46 nodemac=CE:13:58:5A:4F:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:40.318Z",
  "value": "id=1278  sec_id=3638162 flags=0x0000 ifindex=12  mac=42:FF:47:E5:2F:C1 nodemac=A6:D2:B8:67:57:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:40.350Z",
  "value": "id=3466  sec_id=3644259 flags=0x0000 ifindex=16  mac=B2:17:D7:F4:1A:B3 nodemac=7A:B5:FC:9A:5B:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:41.316Z",
  "value": "id=1981  sec_id=4     flags=0x0000 ifindex=10  mac=EE:FC:66:D7:07:46 nodemac=CE:13:58:5A:4F:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:41.316Z",
  "value": "id=1278  sec_id=3638162 flags=0x0000 ifindex=12  mac=42:FF:47:E5:2F:C1 nodemac=A6:D2:B8:67:57:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:41.317Z",
  "value": "id=3466  sec_id=3644259 flags=0x0000 ifindex=16  mac=B2:17:D7:F4:1A:B3 nodemac=7A:B5:FC:9A:5B:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:41.317Z",
  "value": "id=2866  sec_id=3638162 flags=0x0000 ifindex=14  mac=B2:9F:BF:57:29:6B nodemac=0E:9F:03:74:36:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:30.254Z",
  "value": "id=31    sec_id=3644259 flags=0x0000 ifindex=18  mac=4A:CA:31:18:D4:21 nodemac=7A:21:43:B0:63:F1"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.110.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.584Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:42.152Z",
  "value": "id=1278  sec_id=3638162 flags=0x0000 ifindex=12  mac=42:FF:47:E5:2F:C1 nodemac=A6:D2:B8:67:57:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:42.152Z",
  "value": "id=2866  sec_id=3638162 flags=0x0000 ifindex=14  mac=B2:9F:BF:57:29:6B nodemac=0E:9F:03:74:36:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:42.153Z",
  "value": "id=31    sec_id=3644259 flags=0x0000 ifindex=18  mac=4A:CA:31:18:D4:21 nodemac=7A:21:43:B0:63:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:42.154Z",
  "value": "id=1981  sec_id=4     flags=0x0000 ifindex=10  mac=EE:FC:66:D7:07:46 nodemac=CE:13:58:5A:4F:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:43.152Z",
  "value": "id=31    sec_id=3644259 flags=0x0000 ifindex=18  mac=4A:CA:31:18:D4:21 nodemac=7A:21:43:B0:63:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:43.158Z",
  "value": "id=1981  sec_id=4     flags=0x0000 ifindex=10  mac=EE:FC:66:D7:07:46 nodemac=CE:13:58:5A:4F:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:43.158Z",
  "value": "id=1278  sec_id=3638162 flags=0x0000 ifindex=12  mac=42:FF:47:E5:2F:C1 nodemac=A6:D2:B8:67:57:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:43.159Z",
  "value": "id=2866  sec_id=3638162 flags=0x0000 ifindex=14  mac=B2:9F:BF:57:29:6B nodemac=0E:9F:03:74:36:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:44.152Z",
  "value": "id=31    sec_id=3644259 flags=0x0000 ifindex=18  mac=4A:CA:31:18:D4:21 nodemac=7A:21:43:B0:63:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:44.152Z",
  "value": "id=1278  sec_id=3638162 flags=0x0000 ifindex=12  mac=42:FF:47:E5:2F:C1 nodemac=A6:D2:B8:67:57:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:44.152Z",
  "value": "id=2866  sec_id=3638162 flags=0x0000 ifindex=14  mac=B2:9F:BF:57:29:6B nodemac=0E:9F:03:74:36:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:44.153Z",
  "value": "id=1981  sec_id=4     flags=0x0000 ifindex=10  mac=EE:FC:66:D7:07:46 nodemac=CE:13:58:5A:4F:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:45.153Z",
  "value": "id=1981  sec_id=4     flags=0x0000 ifindex=10  mac=EE:FC:66:D7:07:46 nodemac=CE:13:58:5A:4F:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:45.153Z",
  "value": "id=31    sec_id=3644259 flags=0x0000 ifindex=18  mac=4A:CA:31:18:D4:21 nodemac=7A:21:43:B0:63:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:45.154Z",
  "value": "id=1278  sec_id=3638162 flags=0x0000 ifindex=12  mac=42:FF:47:E5:2F:C1 nodemac=A6:D2:B8:67:57:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:45.154Z",
  "value": "id=2866  sec_id=3638162 flags=0x0000 ifindex=14  mac=B2:9F:BF:57:29:6B nodemac=0E:9F:03:74:36:53"
}

