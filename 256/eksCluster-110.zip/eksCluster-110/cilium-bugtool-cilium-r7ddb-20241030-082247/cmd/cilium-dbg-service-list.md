ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.149.231:443 (active)    
                                         2 => 172.31.252.12:443 (active)     
2    10.100.201.243:443   ClusterIP      1 => 172.31.152.250:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.110.0.230:9153 (active)     
                                         2 => 10.110.0.233:9153 (active)     
4    10.100.0.10:53       ClusterIP      1 => 10.110.0.230:53 (active)       
                                         2 => 10.110.0.233:53 (active)       
5    10.100.70.83:2379    ClusterIP      1 => 10.110.0.22:2379 (active)      
