key: 1f 00 00 00  value: 86 02 00 00
key: fe 04 00 00  value: 13 02 00 00
key: bd 07 00 00  value: 3b 02 00 00
key: 32 0b 00 00  value: 37 02 00 00
Found 4 elements
