IP ADDRESS         LOCAL ENDPOINT INFO
10.110.0.230:0     id=2866  sec_id=3638162 flags=0x0000 ifindex=14  mac=B2:9F:BF:57:29:6B nodemac=0E:9F:03:74:36:53   
172.31.152.250:0   (localhost)                                                                                        
10.110.0.102:0     (localhost)                                                                                        
10.110.0.22:0      id=31    sec_id=3644259 flags=0x0000 ifindex=18  mac=4A:CA:31:18:D4:21 nodemac=7A:21:43:B0:63:F1   
10.110.0.183:0     id=1981  sec_id=4     flags=0x0000 ifindex=10  mac=EE:FC:66:D7:07:46 nodemac=CE:13:58:5A:4F:B3     
172.31.136.159:0   (localhost)                                                                                        
10.110.0.233:0     id=1278  sec_id=3638162 flags=0x0000 ifindex=12  mac=42:FF:47:E5:2F:C1 nodemac=A6:D2:B8:67:57:52   
