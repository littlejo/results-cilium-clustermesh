REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37944     3006315     677    bpf_overlay.c
Interface                 INGRESS     698776    139152291   1132   bpf_host.c
Success                   EGRESS      17722     1399415     1694   bpf_host.c
Success                   EGRESS      310056    38189067    1308   bpf_lxc.c
Success                   EGRESS      39217     3094547     53     encap.h
Success                   INGRESS     357399    40721173    86     l3.h
Success                   INGRESS     378272    42372119    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
