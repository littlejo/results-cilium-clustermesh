USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         683  0.0  0.2 1240432 16288 ?       Rsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         708  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         682  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         672  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         662  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         649  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.9  4.9 1606336 399240 ?      Ssl  07:58   0:58 cilium-agent --config-dir=/tmp/cilium/config-map
root         398  0.0  0.1 1229744 8320 ?        Sl   07:58   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
