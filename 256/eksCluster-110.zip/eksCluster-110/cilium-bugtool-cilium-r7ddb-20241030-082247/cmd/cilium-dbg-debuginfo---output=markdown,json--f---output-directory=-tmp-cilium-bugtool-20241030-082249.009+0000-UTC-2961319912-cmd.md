markdown output at /tmp/cilium-bugtool-20241030-082249.009+0000-UTC-2961319912/cmd/cilium-debuginfo-20241030-082320.105+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082249.009+0000-UTC-2961319912/cmd/cilium-debuginfo-20241030-082320.105+0000-UTC.json
