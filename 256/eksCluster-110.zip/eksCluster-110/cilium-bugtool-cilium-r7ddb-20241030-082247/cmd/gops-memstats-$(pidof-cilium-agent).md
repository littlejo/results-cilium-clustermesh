alloc: 107.97MB (113215904 bytes)
total-alloc: 2.55GB (2732829976 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 67758252
frees: 67066851
heap-alloc: 107.97MB (113215904 bytes)
heap-sys: 250.48MB (262643712 bytes)
heap-idle: 71.73MB (75210752 bytes)
heap-in-use: 178.75MB (187432960 bytes)
heap-released: 2.00MB (2097152 bytes)
heap-objects: 691401
stack-in-use: 65.50MB (68681728 bytes)
stack-sys: 65.50MB (68681728 bytes)
stack-mspan-inuse: 2.97MB (3113920 bytes)
stack-mspan-sys: 3.94MB (4128960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.07MB (1120673 bytes)
gc-sys: 6.00MB (6294992 bytes)
next-gc: when heap-alloc >= 228.18MB (239266664 bytes)
last-gc: 2024-10-30 08:23:19.268428635 +0000 UTC
gc-pause-total: 24.384738ms
gc-pause: 109540
gc-pause-end: 1730276599268428635
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.0005704983273501703
enable-gc: true
debug-gc: false
