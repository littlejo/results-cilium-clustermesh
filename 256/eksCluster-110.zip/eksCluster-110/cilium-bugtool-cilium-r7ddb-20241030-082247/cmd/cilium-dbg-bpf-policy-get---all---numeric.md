Endpoint ID: 31
Path: /sys/fs/bpf/tc/globals/cilium_policy_00031

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11493635   116083    0        
Allow    Ingress     1          ANY          NONE         disabled    12358861   127789    0        
Allow    Egress      0          ANY          NONE         disabled    15074904   146652    0        


Endpoint ID: 1124
Path: /sys/fs/bpf/tc/globals/cilium_policy_01124

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1278
Path: /sys/fs/bpf/tc/globals/cilium_policy_01278

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    143986   1652      0        
Allow    Egress      0          ANY          NONE         disabled    19533    215       0        


Endpoint ID: 1981
Path: /sys/fs/bpf/tc/globals/cilium_policy_01981

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1653021   20900     0        
Allow    Ingress     1          ANY          NONE         disabled    22283     262       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2866
Path: /sys/fs/bpf/tc/globals/cilium_policy_02866

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    143524   1645      0        
Allow    Egress      0          ANY          NONE         disabled    18354    202       0        


