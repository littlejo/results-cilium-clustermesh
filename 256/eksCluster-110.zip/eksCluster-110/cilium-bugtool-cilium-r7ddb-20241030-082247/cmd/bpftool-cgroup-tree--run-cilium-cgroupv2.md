CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod69f4eb06_6343_4885_b2e0_b76726f8e616.slice/cri-containerd-134845789dcb53bc79a9cc4b7f28fe543164d5a3f6f85b0302505c54e7af6ae1.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod69f4eb06_6343_4885_b2e0_b76726f8e616.slice/cri-containerd-a4b54992ed1cb1b4cd8ad4acfc03943b91f81bb7cdb54c533d57f04361385d77.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc64f53fe_d1c5_47f6_b14a_ffe171d2c880.slice/cri-containerd-a64feed0764d8f7112f4e844ba13d32823afaf6a802d1a478e014f84934f63f1.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc64f53fe_d1c5_47f6_b14a_ffe171d2c880.slice/cri-containerd-d9d2d11c231be298e02728018093d2b55ec8fe5b24b2bac7cf35037d228d2584.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6de19980_d9c3_4d37_99a5_94eb5a79615b.slice/cri-containerd-4c54d3a6c3a5233067ae4548cbb844a6d2db19252f8832b1957a3e9a1e9d7226.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6de19980_d9c3_4d37_99a5_94eb5a79615b.slice/cri-containerd-5fb876ebe9bc9c7d099a4d5a5cb0a0ce5b3b14c20734dc222137dbbb48ee5a14.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbff073e2_2490_41e4_b1a6_0c0dd047cb00.slice/cri-containerd-b0a70196a257c5614931cf7013e9cc30ee8888f212fbe393c184af50ce32a0c4.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbff073e2_2490_41e4_b1a6_0c0dd047cb00.slice/cri-containerd-9f515e87e91aa3dc47249dbde9a264d6f86161dfd01a8e696e12b0cd4aea57c0.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb076c93e_9cbb_4748_9697_f33164d4e909.slice/cri-containerd-e94198f28ee737bdd70d1738c87a91f28f35421246bcecdf8a8aeff822b0b553.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb076c93e_9cbb_4748_9697_f33164d4e909.slice/cri-containerd-1718ca5156234be3cbf0e9e4517f109b3a8c9e997a081db5f1d01653c9b4b850.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b8a8821_4bda_4a7c_b436_9204386cd197.slice/cri-containerd-a869fde5b985c447fe66e68497abe49c4f45be10ad7509a0364b1f7dcf528c00.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b8a8821_4bda_4a7c_b436_9204386cd197.slice/cri-containerd-8af76d0b76001461261f75610f02d30e3370f7712288e31d53eefed4c0d303f0.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b8a8821_4bda_4a7c_b436_9204386cd197.slice/cri-containerd-e6bfc3b0ae9c63cc8d420bb89ba5cb78b6d73964054ddcf09e1e8f676c3572d4.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b8a8821_4bda_4a7c_b436_9204386cd197.slice/cri-containerd-014f26b22cd99f87c003947e43d2ebcf3b4054e6109991ece2d87bccbf5dd6c1.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0fca2686_357c_4341_ae2a_3ab100012774.slice/cri-containerd-2a9fa7f8b0933e381023eef76e69f815e08a7b627842b7c46254bfb3d933c012.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0fca2686_357c_4341_ae2a_3ab100012774.slice/cri-containerd-4e98428fe93731e9979eceb5ce715a3978cfddbf37fc60ae1f7b0057630b5d2f.scope
    99       cgroup_device   multi                                          
