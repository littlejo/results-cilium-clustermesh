1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:91:c9:fa:dc:77 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.152.250/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3401sec preferred_lft 3401sec
    inet6 fe80::491:c9ff:fefa:dc77/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:33:90:f3:a9:b7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.136.159/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::433:90ff:fef3:a9b7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:ac:6c:99:f2:05 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8ac:6cff:fe99:f205/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:5f:5f:5d:f1:99 brd ff:ff:ff:ff:ff:ff
    inet 10.110.0.102/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a05f:5fff:fe5d:f199/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3e:83:2d:ec:0c:57 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3c83:2dff:feec:c57/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:13:58:5a:4f:b3 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::cc13:58ff:fe5a:4fb3/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc9d76465a8a48@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:d2:b8:67:57:52 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a4d2:b8ff:fe67:5752/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc71ffac29f338@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:9f:03:74:36:53 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c9f:3ff:fe74:3653/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc5256ab95b798@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:21:43:b0:63:f1 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7821:43ff:feb0:63f1/64 scope link 
       valid_lft forever preferred_lft forever
