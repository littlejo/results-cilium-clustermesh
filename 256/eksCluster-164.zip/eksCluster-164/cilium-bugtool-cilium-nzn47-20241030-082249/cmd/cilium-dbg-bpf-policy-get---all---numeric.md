Endpoint ID: 185
Path: /sys/fs/bpf/tc/globals/cilium_policy_00185

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    127552   1468      0        
Allow    Egress      0          ANY          NONE         disabled    17153    186       0        


Endpoint ID: 361
Path: /sys/fs/bpf/tc/globals/cilium_policy_00361

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11567552   116501    0        
Allow    Ingress     1          ANY          NONE         disabled    11151955   117893    0        
Allow    Egress      0          ANY          NONE         disabled    14573249   142382    0        


Endpoint ID: 488
Path: /sys/fs/bpf/tc/globals/cilium_policy_00488

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    127351   1461      0        
Allow    Egress      0          ANY          NONE         disabled    16420    178       0        


Endpoint ID: 754
Path: /sys/fs/bpf/tc/globals/cilium_policy_00754

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1306
Path: /sys/fs/bpf/tc/globals/cilium_policy_01306

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1641925   20711     0        
Allow    Ingress     1          ANY          NONE         disabled    19672     230       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


