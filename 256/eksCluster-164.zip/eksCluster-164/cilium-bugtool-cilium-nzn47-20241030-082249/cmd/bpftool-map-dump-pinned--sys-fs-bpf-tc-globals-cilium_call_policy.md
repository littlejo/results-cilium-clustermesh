key: b9 00 00 00  value: 16 02 00 00
key: 69 01 00 00  value: 73 02 00 00
key: e8 01 00 00  value: 00 02 00 00
key: 1a 05 00 00  value: 09 02 00 00
Found 4 elements
