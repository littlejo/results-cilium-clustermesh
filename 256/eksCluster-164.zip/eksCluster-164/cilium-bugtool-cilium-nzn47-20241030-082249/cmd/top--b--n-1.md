top - 08:22:50 up 32 min,  0 users,  load average: 0.23, 0.22, 0.22
Tasks:   8 total,   2 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 56.7 us, 33.3 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi, 10.0 si,  0.0 st
MiB Mem :   7814.2 total,   4444.1 free,   1222.8 used,   2147.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6406.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 399512  80428 S  53.3   5.0   0:49.47 cilium-+
    733 root      20   0 1244596  21472  14464 S  26.7   0.3   0:00.05 hubble
    694 root      20   0 1240432  16736  11420 S   6.7   0.2   0:00.03 cilium-+
    415 root      20   0 1229488   7040   2924 S   0.0   0.1   0:01.10 cilium-+
    688 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    718 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    751 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    762 root      20   0    3664   2136   1860 R   0.0   0.0   0:00.00 ip6tabl+
