 08:22:50 up 32 min,  0 users,  load average: 0.23, 0.22, 0.22
