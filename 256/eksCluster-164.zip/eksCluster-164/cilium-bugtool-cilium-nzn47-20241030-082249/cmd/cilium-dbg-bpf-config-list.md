KEY             VALUE
AgentLiveness   1977974723100
UTimeOffset     3379442625000000
