1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:4f:1c:5e:7f:a3 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.132.35/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3466sec preferred_lft 3466sec
    inet6 fe80::44f:1cff:fe5e:7fa3/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d1:e3:9e:63:b1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.170.94/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4d1:e3ff:fe9e:63b1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:04:93:14:3c:02 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b804:93ff:fe14:3c02/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:7c:d2:95:ff:da brd ff:ff:ff:ff:ff:ff
    inet 10.164.0.234/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::687c:d2ff:fe95:ffda/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ee:4e:0b:06:28:76 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ec4e:bff:fe06:2876/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:f8:db:c8:3f:a7 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::80f8:dbff:fec8:3fa7/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc4a983b708aff@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:67:b2:60:5a:79 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::6467:b2ff:fe60:5a79/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcd789e721ceb1@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:ad:44:93:ec:3c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::44ad:44ff:fe93:ec3c/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcba5e9245c2cd@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:49:7f:22:15:9a brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::1849:7fff:fe22:159a/64 scope link 
       valid_lft forever preferred_lft forever
