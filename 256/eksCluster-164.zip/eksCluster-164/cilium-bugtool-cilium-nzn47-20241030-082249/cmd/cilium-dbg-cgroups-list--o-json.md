[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc588644b_9892_4916_9415_e884072eea84.slice/cri-containerd-dc0256166ccbc0b85012ce7538a15de49de14cc42753685bbd7cffea3e0ed934.scope"
      }
    ],
    "ips": [
      "10.164.0.59"
    ],
    "name": "coredns-cc6ccd49c-cllw6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod340fcd1a_3fd6_4902_86cd_223a79be24ec.slice/cri-containerd-97bb58f30bfc6e85b30ff70931c1c4f523d5e5d11446a45dcebb9959b0f1bfd8.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod340fcd1a_3fd6_4902_86cd_223a79be24ec.slice/cri-containerd-a86e8b26040d4bdd5ffa583ccc4f066f30103423a87e125749d895df1846b0cf.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod340fcd1a_3fd6_4902_86cd_223a79be24ec.slice/cri-containerd-10f58446669e855e473b70201a34d6e86614d48777396d438f10a1e977a317c1.scope"
      }
    ],
    "ips": [
      "10.164.0.238"
    ],
    "name": "clustermesh-apiserver-7d5bc7987b-jnnhc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode69a4626_857d_49b0_85fd_0bcf19a7f1e6.slice/cri-containerd-211cd36852681821e878c3e6b36504051a84534bdf1b34b268f88b20a5526918.scope"
      }
    ],
    "ips": [
      "10.164.0.126"
    ],
    "name": "coredns-cc6ccd49c-8rj8l",
    "namespace": "kube-system"
  }
]

