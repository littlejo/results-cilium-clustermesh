{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:04.415Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.132.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:04.415Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.170.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:04.415Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:09.042Z",
  "value": "id=1306  sec_id=4     flags=0x0000 ifindex=10  mac=8E:E7:87:A0:F2:69 nodemac=82:F8:DB:C8:3F:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:09.046Z",
  "value": "id=185   sec_id=5429737 flags=0x0000 ifindex=12  mac=62:99:4F:83:51:2C nodemac=66:67:B2:60:5A:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:09.092Z",
  "value": "id=488   sec_id=5429737 flags=0x0000 ifindex=14  mac=C2:F2:E4:BD:76:FC nodemac=46:AD:44:93:EC:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:09.157Z",
  "value": "id=1306  sec_id=4     flags=0x0000 ifindex=10  mac=8E:E7:87:A0:F2:69 nodemac=82:F8:DB:C8:3F:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:09.217Z",
  "value": "id=185   sec_id=5429737 flags=0x0000 ifindex=12  mac=62:99:4F:83:51:2C nodemac=66:67:B2:60:5A:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:58.445Z",
  "value": "id=488   sec_id=5429737 flags=0x0000 ifindex=14  mac=C2:F2:E4:BD:76:FC nodemac=46:AD:44:93:EC:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:58.446Z",
  "value": "id=1306  sec_id=4     flags=0x0000 ifindex=10  mac=8E:E7:87:A0:F2:69 nodemac=82:F8:DB:C8:3F:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:58.446Z",
  "value": "id=185   sec_id=5429737 flags=0x0000 ifindex=12  mac=62:99:4F:83:51:2C nodemac=66:67:B2:60:5A:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:58.476Z",
  "value": "id=1687  sec_id=5426037 flags=0x0000 ifindex=16  mac=16:8C:80:E4:74:CE nodemac=D6:11:A1:E6:89:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:59.446Z",
  "value": "id=1687  sec_id=5426037 flags=0x0000 ifindex=16  mac=16:8C:80:E4:74:CE nodemac=D6:11:A1:E6:89:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:59.446Z",
  "value": "id=185   sec_id=5429737 flags=0x0000 ifindex=12  mac=62:99:4F:83:51:2C nodemac=66:67:B2:60:5A:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:59.446Z",
  "value": "id=1306  sec_id=4     flags=0x0000 ifindex=10  mac=8E:E7:87:A0:F2:69 nodemac=82:F8:DB:C8:3F:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:59.446Z",
  "value": "id=488   sec_id=5429737 flags=0x0000 ifindex=14  mac=C2:F2:E4:BD:76:FC nodemac=46:AD:44:93:EC:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:52.418Z",
  "value": "id=361   sec_id=5426037 flags=0x0000 ifindex=18  mac=3E:02:EA:1A:51:AF nodemac=1A:49:7F:22:15:9A"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.164.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:02.842Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.209Z",
  "value": "id=361   sec_id=5426037 flags=0x0000 ifindex=18  mac=3E:02:EA:1A:51:AF nodemac=1A:49:7F:22:15:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.210Z",
  "value": "id=1306  sec_id=4     flags=0x0000 ifindex=10  mac=8E:E7:87:A0:F2:69 nodemac=82:F8:DB:C8:3F:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.210Z",
  "value": "id=185   sec_id=5429737 flags=0x0000 ifindex=12  mac=62:99:4F:83:51:2C nodemac=66:67:B2:60:5A:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.211Z",
  "value": "id=488   sec_id=5429737 flags=0x0000 ifindex=14  mac=C2:F2:E4:BD:76:FC nodemac=46:AD:44:93:EC:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.214Z",
  "value": "id=1306  sec_id=4     flags=0x0000 ifindex=10  mac=8E:E7:87:A0:F2:69 nodemac=82:F8:DB:C8:3F:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.214Z",
  "value": "id=361   sec_id=5426037 flags=0x0000 ifindex=18  mac=3E:02:EA:1A:51:AF nodemac=1A:49:7F:22:15:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.227Z",
  "value": "id=488   sec_id=5429737 flags=0x0000 ifindex=14  mac=C2:F2:E4:BD:76:FC nodemac=46:AD:44:93:EC:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.227Z",
  "value": "id=185   sec_id=5429737 flags=0x0000 ifindex=12  mac=62:99:4F:83:51:2C nodemac=66:67:B2:60:5A:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:13.209Z",
  "value": "id=361   sec_id=5426037 flags=0x0000 ifindex=18  mac=3E:02:EA:1A:51:AF nodemac=1A:49:7F:22:15:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:13.210Z",
  "value": "id=488   sec_id=5429737 flags=0x0000 ifindex=14  mac=C2:F2:E4:BD:76:FC nodemac=46:AD:44:93:EC:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:13.210Z",
  "value": "id=185   sec_id=5429737 flags=0x0000 ifindex=12  mac=62:99:4F:83:51:2C nodemac=66:67:B2:60:5A:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:13.210Z",
  "value": "id=1306  sec_id=4     flags=0x0000 ifindex=10  mac=8E:E7:87:A0:F2:69 nodemac=82:F8:DB:C8:3F:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:14.210Z",
  "value": "id=185   sec_id=5429737 flags=0x0000 ifindex=12  mac=62:99:4F:83:51:2C nodemac=66:67:B2:60:5A:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:14.210Z",
  "value": "id=361   sec_id=5426037 flags=0x0000 ifindex=18  mac=3E:02:EA:1A:51:AF nodemac=1A:49:7F:22:15:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:14.211Z",
  "value": "id=488   sec_id=5429737 flags=0x0000 ifindex=14  mac=C2:F2:E4:BD:76:FC nodemac=46:AD:44:93:EC:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.164.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:14.211Z",
  "value": "id=1306  sec_id=4     flags=0x0000 ifindex=10  mac=8E:E7:87:A0:F2:69 nodemac=82:F8:DB:C8:3F:A7"
}

