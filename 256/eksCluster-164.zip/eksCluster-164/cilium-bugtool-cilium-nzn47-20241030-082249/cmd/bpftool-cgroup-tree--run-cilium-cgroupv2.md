CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode69a4626_857d_49b0_85fd_0bcf19a7f1e6.slice/cri-containerd-211cd36852681821e878c3e6b36504051a84534bdf1b34b268f88b20a5526918.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode69a4626_857d_49b0_85fd_0bcf19a7f1e6.slice/cri-containerd-246dbcdf02f72fadfaee87680749dd75e94712215d3c0d4f016c6946ebf535be.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc588644b_9892_4916_9415_e884072eea84.slice/cri-containerd-dc0256166ccbc0b85012ce7538a15de49de14cc42753685bbd7cffea3e0ed934.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc588644b_9892_4916_9415_e884072eea84.slice/cri-containerd-47ca7a3e3ed95e49b345641b5ef79d0e2f6da952cd0dba1f70f376eecac08e4d.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbe306b3b_4037_4378_8def_ee73cb888a96.slice/cri-containerd-8b7c08de987a35cb5c8f1d99a6875db83147dd3215e916e29eae8d875b922243.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbe306b3b_4037_4378_8def_ee73cb888a96.slice/cri-containerd-5570ad2a4a6d97bef31db7e7e2da7f959332c7876aa73c1d98baab7f99cf800e.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode94f3116_13f2_41a8_8caf_021f8bc2434a.slice/cri-containerd-2cad8df40d9d9ad5e9f5f45174932768b12a5f5ee5829e10ba925cdda9aa20a5.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode94f3116_13f2_41a8_8caf_021f8bc2434a.slice/cri-containerd-7b42d5d183115d0c521456ec24840847efa09eaa2b5aea4ccf76c7c355c611c0.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2f80447a_20cf_44f7_b433_2a2bef586bdd.slice/cri-containerd-24f27fc8198acea4dbf4726adce929862cb193a9ed349fda80f93b6b4f35f012.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2f80447a_20cf_44f7_b433_2a2bef586bdd.slice/cri-containerd-47a00216b0214972c3802e70e7d8673611e3d4991cba7efd9bd87c57df52f722.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcbc749a8_13f6_435c_a637_ff1d144ec747.slice/cri-containerd-a85da6dd1c3a74a18b38480322f860e4d36bb6a494adb8a768f4430441aef2a1.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcbc749a8_13f6_435c_a637_ff1d144ec747.slice/cri-containerd-af9d9bfa77f94d0168d21c07cc463630994bdb3547c5cbe8053c37fa59ffcb4f.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod340fcd1a_3fd6_4902_86cd_223a79be24ec.slice/cri-containerd-10f58446669e855e473b70201a34d6e86614d48777396d438f10a1e977a317c1.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod340fcd1a_3fd6_4902_86cd_223a79be24ec.slice/cri-containerd-97bb58f30bfc6e85b30ff70931c1c4f523d5e5d11446a45dcebb9959b0f1bfd8.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod340fcd1a_3fd6_4902_86cd_223a79be24ec.slice/cri-containerd-a86e8b26040d4bdd5ffa583ccc4f066f30103423a87e125749d895df1846b0cf.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod340fcd1a_3fd6_4902_86cd_223a79be24ec.slice/cri-containerd-f1456ad7247477c9db86a62b24600870f40d484dc52feff68cb18c777d807d14.scope
    634      cgroup_device   multi                                          
