ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.243.153:443 (active)   
                                        2 => 172.31.139.93:443 (active)    
2    10.100.8.220:443    ClusterIP      1 => 172.31.132.35:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.164.0.126:53 (active)      
                                        2 => 10.164.0.59:53 (active)       
4    10.100.0.10:9153    ClusterIP      1 => 10.164.0.126:9153 (active)    
                                        2 => 10.164.0.59:9153 (active)     
5    10.100.89.12:2379   ClusterIP      1 => 10.164.0.238:2379 (active)    
