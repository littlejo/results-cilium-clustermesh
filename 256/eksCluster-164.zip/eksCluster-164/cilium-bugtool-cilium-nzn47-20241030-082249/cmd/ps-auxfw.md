USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         718  0.0  0.0 1267208 3268 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         694  1.0  0.2 1240432 16324 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         723  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         724  0.0  0.0   1748     4 ?        R    08:22   0:00  \_ bash -c hostname
root         688  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         680  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.7  4.9 1606080 392384 ?      Ssl  08:00   0:49 cilium-agent --config-dir=/tmp/cilium/config-map
root         415  0.0  0.0 1229488 7040 ?        Sl   08:01   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
