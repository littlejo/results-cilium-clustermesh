alloc: 96.74MB (101435704 bytes)
total-alloc: 2.35GB (2519769976 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 65098918
frees: 64429638
heap-alloc: 96.74MB (101435704 bytes)
heap-sys: 255.82MB (268247040 bytes)
heap-idle: 96.08MB (100745216 bytes)
heap-in-use: 159.74MB (167501824 bytes)
heap-released: 17.80MB (18661376 bytes)
heap-objects: 669280
stack-in-use: 60.16MB (63078400 bytes)
stack-sys: 60.16MB (63078400 bytes)
stack-mspan-inuse: 2.75MB (2884960 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 949.06KB (971833 bytes)
gc-sys: 6.04MB (6330024 bytes)
next-gc: when heap-alloc >= 211.94MB (222239992 bytes)
last-gc: 2024-10-30 08:23:20.806414132 +0000 UTC
gc-pause-total: 33.145379ms
gc-pause: 79592
gc-pause-end: 1730276600806414132
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0004727641530426506
enable-gc: true
debug-gc: false
