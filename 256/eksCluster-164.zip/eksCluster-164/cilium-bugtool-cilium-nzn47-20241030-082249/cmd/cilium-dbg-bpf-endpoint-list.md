IP ADDRESS        LOCAL ENDPOINT INFO
10.164.0.126:0    id=488   sec_id=5429737 flags=0x0000 ifindex=14  mac=C2:F2:E4:BD:76:FC nodemac=46:AD:44:93:EC:3C   
10.164.0.238:0    id=361   sec_id=5426037 flags=0x0000 ifindex=18  mac=3E:02:EA:1A:51:AF nodemac=1A:49:7F:22:15:9A   
10.164.0.229:0    id=1306  sec_id=4     flags=0x0000 ifindex=10  mac=8E:E7:87:A0:F2:69 nodemac=82:F8:DB:C8:3F:A7     
172.31.132.35:0   (localhost)                                                                                        
172.31.170.94:0   (localhost)                                                                                        
10.164.0.59:0     id=185   sec_id=5429737 flags=0x0000 ifindex=12  mac=62:99:4F:83:51:2C nodemac=66:67:B2:60:5A:79   
10.164.0.234:0    (localhost)                                                                                        
