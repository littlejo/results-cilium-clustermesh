REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     33127     2619665     677    bpf_overlay.c
Interface                 INGRESS     564406    121158152   1132   bpf_host.c
Success                   EGRESS      13862     1085801     1694   bpf_host.c
Success                   EGRESS      238401    29917223    1308   bpf_lxc.c
Success                   EGRESS      32131     2546835     53     encap.h
Success                   INGRESS     275332    30288204    86     l3.h
Success                   INGRESS     295246    31865974    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
