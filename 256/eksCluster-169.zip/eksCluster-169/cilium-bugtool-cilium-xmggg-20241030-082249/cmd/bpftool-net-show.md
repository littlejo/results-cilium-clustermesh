xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 588
ens6(5) clsact/ingress cil_from_netdev-ens6 id 596
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 580
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 572
cilium_host(7) clsact/egress cil_from_host-cilium_host id 570
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 504
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 505
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 563
lxc0500baa63f8e(12) clsact/ingress cil_from_container-lxc0500baa63f8e id 534
lxc00059c173ae2(14) clsact/ingress cil_from_container-lxc00059c173ae2 id 554
lxcd374d6d8aaa1(18) clsact/ingress cil_from_container-lxcd374d6d8aaa1 id 647

flow_dissector:

netfilter:

