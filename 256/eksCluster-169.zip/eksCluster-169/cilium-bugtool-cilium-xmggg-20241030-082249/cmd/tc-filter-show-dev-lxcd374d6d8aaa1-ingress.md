filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcd374d6d8aaa1 direct-action not_in_hw id 647 tag a24b41d895df045f jited 
