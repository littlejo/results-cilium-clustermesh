CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod124b7f12_a40f_4356_b1fa_87c32036ba18.slice/cri-containerd-7a359a7774eb6cdfb416aead34351b8744c03e696838c5c1f32459a5f5f6ca00.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod124b7f12_a40f_4356_b1fa_87c32036ba18.slice/cri-containerd-38f030f146742f477aa4c893e34d465626cd5663adf944ab40a6bfa04230ae83.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0974971b_7aba_43f6_8d9a_3a2c23d132a5.slice/cri-containerd-4ff603a3634db3f95c21989366e401e6616bd37176c30e0e006c81c95005f001.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0974971b_7aba_43f6_8d9a_3a2c23d132a5.slice/cri-containerd-e6e0cf79f7fee783faf4accb9e8c3c415c5b17bb8a461362cddd6432116625a1.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10aee57d_344a_4d4d_91cd_8acc70454efe.slice/cri-containerd-c709d1db7fc12650087587fa2a45fcebe03c2fe215522f60b67c2b53f91466ac.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10aee57d_344a_4d4d_91cd_8acc70454efe.slice/cri-containerd-d0da957ad7e741a274e4d88ff234e535d638e11725d8729996883e3a18d2807b.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod80b8efa6_f46c_45f4_b2d7_1e3607b38256.slice/cri-containerd-914a23e69c502e73757413606205b9c1d3986469cc38b00321d0a5aa64a6c9ea.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod80b8efa6_f46c_45f4_b2d7_1e3607b38256.slice/cri-containerd-2612f775d73c57bf0f69f68853b25448016d285d66ec7ec603bebdebe003dbe7.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1db03a39_b5a3_466d_b594_63d066c2596c.slice/cri-containerd-753f9c3f16e81926a4127062cf97c3f1a3fe723a21e4db939bed5fe6420995bf.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1db03a39_b5a3_466d_b594_63d066c2596c.slice/cri-containerd-aeaf923507ea213d0c7984dfbb15e9a24902fd6a95759b8f2cb031df75d23533.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc779b09e_7b33_4a03_a3f7_0d6223808939.slice/cri-containerd-7404a917ea62ad67420f178b1490de9d27f1e526b3992faa7ffeb0c67c5aaa2e.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc779b09e_7b33_4a03_a3f7_0d6223808939.slice/cri-containerd-2a298bf9a8232113542ba77ca5d655bca11b2abc3fe1fb94d0af4573d9bb1a0a.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc779b09e_7b33_4a03_a3f7_0d6223808939.slice/cri-containerd-52aeb37decdba354b45fff2a8b4599c85fb8af10c66d0193bb2f4e1475bc1961.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc779b09e_7b33_4a03_a3f7_0d6223808939.slice/cri-containerd-c3f81cb7a8333b3665dec8c355254555b4ad7413070bfb0003ec03dfa9bae090.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6f6276b8_b98b_4afc_ae3e_735e1ff4e2da.slice/cri-containerd-7f5604938e70eb28449efae05dc5436b773874e732cc8120ff1e03c2c64a61f0.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6f6276b8_b98b_4afc_ae3e_735e1ff4e2da.slice/cri-containerd-f88f532e22e0133fabe6398fce85bb9fa76c79995a63e5b167d6fd75e0bc4dbd.scope
    109      cgroup_device   multi                                          
