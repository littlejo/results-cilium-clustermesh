IP ADDRESS         LOCAL ENDPOINT INFO
10.169.0.250:0     id=1889  sec_id=4     flags=0x0000 ifindex=10  mac=56:B6:50:FB:35:F1 nodemac=D2:83:FC:40:31:0D     
172.31.230.34:0    (localhost)                                                                                        
10.169.0.24:0      id=184   sec_id=5596767 flags=0x0000 ifindex=14  mac=1E:EA:2B:24:03:11 nodemac=3A:DD:45:69:21:C7   
172.31.226.127:0   (localhost)                                                                                        
10.169.0.49:0      id=469   sec_id=5589520 flags=0x0000 ifindex=18  mac=CE:69:5C:D8:A7:62 nodemac=72:EA:13:C2:F9:7D   
10.169.0.72:0      id=1320  sec_id=5596767 flags=0x0000 ifindex=12  mac=46:46:DE:C1:8C:AB nodemac=92:40:B5:79:BE:9A   
10.169.0.215:0     (localhost)                                                                                        
