Endpoint ID: 184
Path: /sys/fs/bpf/tc/globals/cilium_policy_00184

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    110819   1275      0        
Allow    Egress      0          ANY          NONE         disabled    16584    179       0        


Endpoint ID: 469
Path: /sys/fs/bpf/tc/globals/cilium_policy_00469

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    10081188   100689    0        
Allow    Ingress     1          ANY          NONE         disabled    8551343    88813     0        
Allow    Egress      0          ANY          NONE         disabled    9594006    98260     0        


Endpoint ID: 937
Path: /sys/fs/bpf/tc/globals/cilium_policy_00937

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1320
Path: /sys/fs/bpf/tc/globals/cilium_policy_01320

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    111149   1280      0        
Allow    Egress      0          ANY          NONE         disabled    15821    170       0        


Endpoint ID: 1889
Path: /sys/fs/bpf/tc/globals/cilium_policy_01889

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1579333   19933     0        
Allow    Ingress     1          ANY          NONE         disabled    16752     195       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


