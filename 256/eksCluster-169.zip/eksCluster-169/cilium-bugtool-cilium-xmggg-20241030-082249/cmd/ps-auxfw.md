USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         645  0.0  0.1 1240432 15920 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         694  0.0  0.0    364     4 ?        R    08:22   0:00  \_ cat /proc/net/xfrm_stat
root         695  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root           1  3.7  4.7 1606080 376548 ?      Ssl  08:03   0:44 cilium-agent --config-dir=/tmp/cilium/config-map
root         417  0.0  0.0 1229744 7032 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
