KEY             VALUE
AgentLiveness   1733190683050
UTimeOffset     3379443050781250
