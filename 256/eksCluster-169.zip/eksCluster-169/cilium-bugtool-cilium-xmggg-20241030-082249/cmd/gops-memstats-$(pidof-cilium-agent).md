alloc: 144.16MB (151158808 bytes)
total-alloc: 2.04GB (2187457088 bytes)
sys: 308.77MB (323768676 bytes)
lookups: 0
mallocs: 60103364
frees: 58712201
heap-alloc: 144.16MB (151158808 bytes)
heap-sys: 231.16MB (242393088 bytes)
heap-idle: 55.44MB (58130432 bytes)
heap-in-use: 175.73MB (184262656 bytes)
heap-released: 3.00MB (3145728 bytes)
heap-objects: 1391163
stack-in-use: 64.81MB (67960832 bytes)
stack-sys: 64.81MB (67960832 bytes)
stack-mspan-inuse: 2.97MB (3110560 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.00MB (1053761 bytes)
gc-sys: 5.99MB (6284704 bytes)
next-gc: when heap-alloc >= 209.77MB (219957672 bytes)
last-gc: 2024-10-30 08:22:27.942147007 +0000 UTC
gc-pause-total: 6.708703ms
gc-pause: 115358
gc-pause-end: 1730276547942147007
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0004756885874480508
enable-gc: true
debug-gc: false
