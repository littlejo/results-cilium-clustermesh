35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:54:05+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:54:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:54:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:54:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:54:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:54:05+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:54:06+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:54:06+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:54:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:54:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:54:06+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:54:06+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:54:11+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:54:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
495: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
498: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
499: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
502: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
503: sched_cls  name tail_handle_ipv4  tag fbeafcec51c86be4  gpl
	loaded_at 2024-10-30T08:03:33+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,104
	btf_id 136
504: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:03:33+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,104
	btf_id 137
505: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:03:33+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 138
506: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:03:33+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 139
529: sched_cls  name tail_handle_arp  tag f807298be8a7503f  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 165
531: sched_cls  name tail_ipv4_ct_egress  tag df5b5006786c678c  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 167
532: sched_cls  name __send_drop_notify  tag 95801c0b6bf15988  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 168
533: sched_cls  name handle_policy  tag 3155a0c8d1c03430  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,111,41,80,91,39,84,75,40,37,38
	btf_id 169
534: sched_cls  name cil_from_container  tag 50c2a4659a677d01  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 170
535: sched_cls  name tail_ipv4_to_endpoint  tag d056f71778fe1cca  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,111,41,82,83,80,91,39,112,40,37,38
	btf_id 171
536: sched_cls  name tail_handle_ipv4  tag a797046bd071cd15  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 172
537: sched_cls  name tail_ipv4_ct_ingress  tag 4d726d826984a46b  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 173
538: sched_cls  name tail_handle_ipv4_cont  tag f2d44568c124d0c9  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,111,41,91,82,83,39,76,74,77,112,40,37,38,81
	btf_id 174
539: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 175
540: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
541: sched_cls  name __send_drop_notify  tag 579acbc4d2289c07  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 177
542: sched_cls  name tail_handle_ipv4_cont  tag 28073ded5c166150  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,113,41,105,82,83,39,76,74,77,114,40,37,38,81
	btf_id 178
544: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,114
	btf_id 180
545: sched_cls  name tail_ipv4_ct_ingress  tag f3c8950a6e92d6d7  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 181
546: sched_cls  name tail_handle_arp  tag 18a3e5a949c7ba71  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,114
	btf_id 182
549: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
550: sched_cls  name tail_handle_ipv4  tag b03158f6d9b0f794  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,114
	btf_id 183
551: sched_cls  name tail_ipv4_ct_egress  tag df5b5006786c678c  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 184
552: sched_cls  name tail_ipv4_to_endpoint  tag e44bb5871a2f6dd6  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,105,39,114,40,37,38
	btf_id 185
553: sched_cls  name handle_policy  tag 6e3c3969800eadee  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,114,82,83,113,41,80,105,39,84,75,40,37,38
	btf_id 186
554: sched_cls  name cil_from_container  tag 38d003640180402b  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 114,76
	btf_id 187
555: sched_cls  name tail_handle_ipv4  tag 2b74dcb1990016f0  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 189
556: sched_cls  name tail_handle_ipv4_cont  tag cac969460b6db736  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,116,41,106,82,83,39,76,74,77,117,40,37,38,81
	btf_id 190
557: sched_cls  name tail_handle_arp  tag 9fa60bc78ff5c8de  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 191
558: sched_cls  name __send_drop_notify  tag 7d3d64da8527642b  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
559: sched_cls  name tail_ipv4_to_endpoint  tag 4c0339b2585024f6  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,116,41,82,83,80,106,39,117,40,37,38
	btf_id 193
560: sched_cls  name tail_ipv4_ct_ingress  tag eb48aead19478bc0  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,116,84
	btf_id 194
561: sched_cls  name handle_policy  tag 5565b182c64522f8  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,117,82,83,116,41,80,106,39,84,75,40,37,38
	btf_id 195
563: sched_cls  name cil_from_container  tag 387ce92f2bc9dfcc  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 117,76
	btf_id 197
564: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,116,84
	btf_id 198
565: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 199
566: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
569: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
570: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,119
	btf_id 201
572: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 203
573: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 204
575: sched_cls  name __send_drop_notify  tag a9e371e9d322327a  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
576: sched_cls  name tail_handle_ipv4_from_host  tag 4a7b1db9078c3c62  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 207
577: sched_cls  name tail_handle_ipv4_from_host  tag 4a7b1db9078c3c62  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 209
580: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 212
581: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 213
583: sched_cls  name __send_drop_notify  tag a9e371e9d322327a  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 215
587: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 220
588: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 221
589: sched_cls  name __send_drop_notify  tag a9e371e9d322327a  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 222
590: sched_cls  name tail_handle_ipv4_from_host  tag 4a7b1db9078c3c62  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 223
591: sched_cls  name tail_handle_ipv4_from_host  tag 4a7b1db9078c3c62  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,126
	btf_id 225
595: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,126
	btf_id 229
596: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,126,75
	btf_id 230
597: sched_cls  name __send_drop_notify  tag a9e371e9d322327a  gpl
	loaded_at 2024-10-30T08:03:37+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 231
637: sched_cls  name tail_handle_arp  tag 6b9f0d9d103dce48  gpl
	loaded_at 2024-10-30T08:12:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,139
	btf_id 245
639: sched_cls  name tail_ipv4_ct_egress  tag ba28d18dc310514c  gpl
	loaded_at 2024-10-30T08:12:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 247
640: sched_cls  name __send_drop_notify  tag 36bf6b2919f894c1  gpl
	loaded_at 2024-10-30T08:12:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 248
641: sched_cls  name tail_ipv4_ct_ingress  tag 807be0b4d63a9c58  gpl
	loaded_at 2024-10-30T08:12:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 249
642: sched_cls  name tail_handle_ipv4_cont  tag 220ac688542cb484  gpl
	loaded_at 2024-10-30T08:12:25+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,138,41,137,82,83,39,76,74,77,139,40,37,38,81
	btf_id 250
643: sched_cls  name tail_handle_ipv4  tag 9c1a346bbda58cd8  gpl
	loaded_at 2024-10-30T08:12:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,139
	btf_id 251
644: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:12:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,139
	btf_id 252
645: sched_cls  name tail_ipv4_to_endpoint  tag f4eb74f67142d30e  gpl
	loaded_at 2024-10-30T08:12:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,138,41,82,83,80,137,39,139,40,37,38
	btf_id 253
646: sched_cls  name handle_policy  tag 7c854b62f7283711  gpl
	loaded_at 2024-10-30T08:12:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,139,82,83,138,41,80,137,39,84,75,40,37,38
	btf_id 254
647: sched_cls  name cil_from_container  tag a24b41d895df045f  gpl
	loaded_at 2024-10-30T08:12:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 139,76
	btf_id 255
648: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
651: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
664: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
667: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
668: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
671: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
