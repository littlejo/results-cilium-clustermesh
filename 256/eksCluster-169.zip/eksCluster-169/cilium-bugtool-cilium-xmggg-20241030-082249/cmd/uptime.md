 08:22:50 up 28 min,  0 users,  load average: 0.04, 0.18, 0.18
