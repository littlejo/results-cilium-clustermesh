{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.627Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.226.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.627Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.230.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.627Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:32.798Z",
  "value": "id=1320  sec_id=5596767 flags=0x0000 ifindex=12  mac=46:46:DE:C1:8C:AB nodemac=92:40:B5:79:BE:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:36.063Z",
  "value": "id=184   sec_id=5596767 flags=0x0000 ifindex=14  mac=1E:EA:2B:24:03:11 nodemac=3A:DD:45:69:21:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:36.115Z",
  "value": "id=1889  sec_id=4     flags=0x0000 ifindex=10  mac=56:B6:50:FB:35:F1 nodemac=D2:83:FC:40:31:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:36.185Z",
  "value": "id=1320  sec_id=5596767 flags=0x0000 ifindex=12  mac=46:46:DE:C1:8C:AB nodemac=92:40:B5:79:BE:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:36.285Z",
  "value": "id=184   sec_id=5596767 flags=0x0000 ifindex=14  mac=1E:EA:2B:24:03:11 nodemac=3A:DD:45:69:21:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:36.330Z",
  "value": "id=1889  sec_id=4     flags=0x0000 ifindex=10  mac=56:B6:50:FB:35:F1 nodemac=D2:83:FC:40:31:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:17.219Z",
  "value": "id=1320  sec_id=5596767 flags=0x0000 ifindex=12  mac=46:46:DE:C1:8C:AB nodemac=92:40:B5:79:BE:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:17.219Z",
  "value": "id=184   sec_id=5596767 flags=0x0000 ifindex=14  mac=1E:EA:2B:24:03:11 nodemac=3A:DD:45:69:21:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:17.220Z",
  "value": "id=1889  sec_id=4     flags=0x0000 ifindex=10  mac=56:B6:50:FB:35:F1 nodemac=D2:83:FC:40:31:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:17.253Z",
  "value": "id=1621  sec_id=5589520 flags=0x0000 ifindex=16  mac=92:9C:DF:2B:21:B3 nodemac=92:6C:82:B3:A2:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:18.220Z",
  "value": "id=1320  sec_id=5596767 flags=0x0000 ifindex=12  mac=46:46:DE:C1:8C:AB nodemac=92:40:B5:79:BE:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:18.220Z",
  "value": "id=184   sec_id=5596767 flags=0x0000 ifindex=14  mac=1E:EA:2B:24:03:11 nodemac=3A:DD:45:69:21:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:18.220Z",
  "value": "id=1889  sec_id=4     flags=0x0000 ifindex=10  mac=56:B6:50:FB:35:F1 nodemac=D2:83:FC:40:31:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:18.221Z",
  "value": "id=1621  sec_id=5589520 flags=0x0000 ifindex=16  mac=92:9C:DF:2B:21:B3 nodemac=92:6C:82:B3:A2:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:25.456Z",
  "value": "id=469   sec_id=5589520 flags=0x0000 ifindex=18  mac=CE:69:5C:D8:A7:62 nodemac=72:EA:13:C2:F9:7D"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.169.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:35.954Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:13.911Z",
  "value": "id=469   sec_id=5589520 flags=0x0000 ifindex=18  mac=CE:69:5C:D8:A7:62 nodemac=72:EA:13:C2:F9:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:13.912Z",
  "value": "id=1889  sec_id=4     flags=0x0000 ifindex=10  mac=56:B6:50:FB:35:F1 nodemac=D2:83:FC:40:31:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:13.912Z",
  "value": "id=1320  sec_id=5596767 flags=0x0000 ifindex=12  mac=46:46:DE:C1:8C:AB nodemac=92:40:B5:79:BE:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:13.912Z",
  "value": "id=184   sec_id=5596767 flags=0x0000 ifindex=14  mac=1E:EA:2B:24:03:11 nodemac=3A:DD:45:69:21:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:14.912Z",
  "value": "id=184   sec_id=5596767 flags=0x0000 ifindex=14  mac=1E:EA:2B:24:03:11 nodemac=3A:DD:45:69:21:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:14.912Z",
  "value": "id=1889  sec_id=4     flags=0x0000 ifindex=10  mac=56:B6:50:FB:35:F1 nodemac=D2:83:FC:40:31:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:14.912Z",
  "value": "id=469   sec_id=5589520 flags=0x0000 ifindex=18  mac=CE:69:5C:D8:A7:62 nodemac=72:EA:13:C2:F9:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:14.913Z",
  "value": "id=1320  sec_id=5596767 flags=0x0000 ifindex=12  mac=46:46:DE:C1:8C:AB nodemac=92:40:B5:79:BE:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:15.912Z",
  "value": "id=1889  sec_id=4     flags=0x0000 ifindex=10  mac=56:B6:50:FB:35:F1 nodemac=D2:83:FC:40:31:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:15.913Z",
  "value": "id=469   sec_id=5589520 flags=0x0000 ifindex=18  mac=CE:69:5C:D8:A7:62 nodemac=72:EA:13:C2:F9:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:15.914Z",
  "value": "id=1320  sec_id=5596767 flags=0x0000 ifindex=12  mac=46:46:DE:C1:8C:AB nodemac=92:40:B5:79:BE:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:15.914Z",
  "value": "id=184   sec_id=5596767 flags=0x0000 ifindex=14  mac=1E:EA:2B:24:03:11 nodemac=3A:DD:45:69:21:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:16.914Z",
  "value": "id=184   sec_id=5596767 flags=0x0000 ifindex=14  mac=1E:EA:2B:24:03:11 nodemac=3A:DD:45:69:21:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:16.914Z",
  "value": "id=1889  sec_id=4     flags=0x0000 ifindex=10  mac=56:B6:50:FB:35:F1 nodemac=D2:83:FC:40:31:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:16.915Z",
  "value": "id=469   sec_id=5589520 flags=0x0000 ifindex=18  mac=CE:69:5C:D8:A7:62 nodemac=72:EA:13:C2:F9:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.169.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:16.915Z",
  "value": "id=1320  sec_id=5596767 flags=0x0000 ifindex=12  mac=46:46:DE:C1:8C:AB nodemac=92:40:B5:79:BE:9A"
}

