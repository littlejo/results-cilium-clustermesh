1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:3e:26:07:0c:2f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.230.34/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1883sec preferred_lft 1883sec
    inet6 fe80::83e:26ff:fe07:c2f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:6e:23:43:fa:67 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.226.127/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::86e:23ff:fe43:fa67/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:53:e6:58:10:92 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c853:e6ff:fe58:1092/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:23:22:8a:4c:b2 brd ff:ff:ff:ff:ff:ff
    inet 10.169.0.215/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d023:22ff:fe8a:4cb2/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether e2:5f:46:ec:4f:6c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e05f:46ff:feec:4f6c/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:83:fc:40:31:0d brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d083:fcff:fe40:310d/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc0500baa63f8e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:40:b5:79:be:9a brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::9040:b5ff:fe79:be9a/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc00059c173ae2@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:dd:45:69:21:c7 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::38dd:45ff:fe69:21c7/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcd374d6d8aaa1@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:ea:13:c2:f9:7d brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::70ea:13ff:fec2:f97d/64 scope link 
       valid_lft forever preferred_lft forever
