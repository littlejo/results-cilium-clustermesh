ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.168.199:443 (active)   
                                         2 => 172.31.213.251:443 (active)   
2    10.100.78.187:443    ClusterIP      1 => 172.31.230.34:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.169.0.72:53 (active)       
                                         2 => 10.169.0.24:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.169.0.72:9153 (active)     
                                         2 => 10.169.0.24:9153 (active)     
5    10.100.224.68:2379   ClusterIP      1 => 10.169.0.49:2379 (active)     
