[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10aee57d_344a_4d4d_91cd_8acc70454efe.slice/cri-containerd-d0da957ad7e741a274e4d88ff234e535d638e11725d8729996883e3a18d2807b.scope"
      }
    ],
    "ips": [
      "10.169.0.24"
    ],
    "name": "coredns-cc6ccd49c-tcrfj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc779b09e_7b33_4a03_a3f7_0d6223808939.slice/cri-containerd-c3f81cb7a8333b3665dec8c355254555b4ad7413070bfb0003ec03dfa9bae090.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc779b09e_7b33_4a03_a3f7_0d6223808939.slice/cri-containerd-7404a917ea62ad67420f178b1490de9d27f1e526b3992faa7ffeb0c67c5aaa2e.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc779b09e_7b33_4a03_a3f7_0d6223808939.slice/cri-containerd-2a298bf9a8232113542ba77ca5d655bca11b2abc3fe1fb94d0af4573d9bb1a0a.scope"
      }
    ],
    "ips": [
      "10.169.0.49"
    ],
    "name": "clustermesh-apiserver-6fccfcf9b8-x6s2j",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7619,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod124b7f12_a40f_4356_b1fa_87c32036ba18.slice/cri-containerd-38f030f146742f477aa4c893e34d465626cd5663adf944ab40a6bfa04230ae83.scope"
      }
    ],
    "ips": [
      "10.169.0.72"
    ],
    "name": "coredns-cc6ccd49c-9hw25",
    "namespace": "kube-system"
  }
]

