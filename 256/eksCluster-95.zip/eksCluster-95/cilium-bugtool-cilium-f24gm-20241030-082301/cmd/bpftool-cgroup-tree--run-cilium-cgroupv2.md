CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaf3e0170_e8fa_4ef4_9723_4262019cf335.slice/cri-containerd-8ac58c08eba3ed2783fca231e6a546c37504a0bb97b141cf5009c8632f74a70b.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaf3e0170_e8fa_4ef4_9723_4262019cf335.slice/cri-containerd-b0eb1e550170194ce523df46a79121cbedda3680468eed51c2a66655ac982659.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod87b52df3_f131_43df_bae6_ddb5c65cde8a.slice/cri-containerd-4ac5404bb8599add039d8b388a02f1e5ae71f56adf2f35bb007ef6131e08910b.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod87b52df3_f131_43df_bae6_ddb5c65cde8a.slice/cri-containerd-8efc9c8792b58f238ca7dcd6e1fb3459f9917919e7bf62e6ff4519ae636b1c8c.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2adf78d1_b544_49c7_8f14_206c18d73306.slice/cri-containerd-6dd11dc64e7c5b2a8054c799cdf4b0cd68d9da6a07c6f77c657e407569d40ba4.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2adf78d1_b544_49c7_8f14_206c18d73306.slice/cri-containerd-05f87dda74e7b598a20f4aaa09704eed318b59e829051982a0b1a2aea87769c1.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod276591d7_94a5_4ee0_a06c_3135fa4b449d.slice/cri-containerd-672f3c6d587896ed3f85f610d00e0e7ad4a5919b989703a5836ae0c7256f8b7e.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod276591d7_94a5_4ee0_a06c_3135fa4b449d.slice/cri-containerd-de8064f7dabc25f5b87de952c9907671d28131888d20584bcf2ba91469ea5bdb.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff910970_63ac_4c8a_982c_f48145aadcd0.slice/cri-containerd-6eb4b6d5974927e259860f6b45957dac497ac6fbe81da009e63d14f41eb80245.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff910970_63ac_4c8a_982c_f48145aadcd0.slice/cri-containerd-7823a86f51c0d9244609e2d55f504dd76a4cfd4f6105a28a752b28a1986cfb83.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff910970_63ac_4c8a_982c_f48145aadcd0.slice/cri-containerd-2b11ecafc60383bc813cb41a7635514bee4e82650d8a6d671871bafdd7dbe4f7.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff910970_63ac_4c8a_982c_f48145aadcd0.slice/cri-containerd-c7b2d4f32a4a853d5e3ce3510df7eb93c12f05e1322a24312bdb9ffd2c616620.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod77d51efa_ec1f_476c_b4a1_b8e4f641c4f4.slice/cri-containerd-ab6e0e01ca6eb8182d5bf9fd1b1b69af6a5e19f99c6901471cc61cef176d9044.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod77d51efa_ec1f_476c_b4a1_b8e4f641c4f4.slice/cri-containerd-fdafe6584b1317fb13aa6844392fadc7d2f884caa1081a50a0360d2538764ecc.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod500aa746_d9b4_4ba6_a4e2_411b4b2f84a2.slice/cri-containerd-68593e858e1fdcff7fb9909480b69eefb260cae6871d578c1713c86ea24ef83c.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod500aa746_d9b4_4ba6_a4e2_411b4b2f84a2.slice/cri-containerd-ff8d0c758b0e14a417a4d9755c875e4d98915e81661e51f78780543b8f8ce8cb.scope
    99       cgroup_device   multi                                          
