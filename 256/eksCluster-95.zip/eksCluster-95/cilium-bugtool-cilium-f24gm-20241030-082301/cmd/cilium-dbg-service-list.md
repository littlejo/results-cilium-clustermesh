ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.151.161:443 (active)   
                                         2 => 172.31.214.20:443 (active)    
2    10.100.230.137:443   ClusterIP      1 => 172.31.214.5:4244 (active)    
3    10.100.0.10:53       ClusterIP      1 => 10.95.0.230:53 (active)       
                                         2 => 10.95.0.177:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.95.0.230:9153 (active)     
                                         2 => 10.95.0.177:9153 (active)     
5    10.100.112.50:2379   ClusterIP      1 => 10.95.0.103:2379 (active)     
