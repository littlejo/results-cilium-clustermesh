KEY             VALUE
AgentLiveness   2118375741579
UTimeOffset     3379442373046875
