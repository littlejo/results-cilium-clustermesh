alloc: 185.58MB (194590784 bytes)
total-alloc: 2.37GB (2539466328 bytes)
sys: 337.09MB (353459572 bytes)
lookups: 0
mallocs: 64697855
frees: 62526901
heap-alloc: 185.58MB (194590784 bytes)
heap-sys: 256.01MB (268443648 bytes)
heap-idle: 41.16MB (43163648 bytes)
heap-in-use: 214.84MB (225280000 bytes)
heap-released: 3.00MB (3145728 bytes)
heap-objects: 2170954
stack-in-use: 67.97MB (71270400 bytes)
stack-sys: 67.97MB (71270400 bytes)
stack-mspan-inuse: 3.70MB (3880800 bytes)
stack-mspan-sys: 4.00MB (4194240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.03MB (1081777 bytes)
gc-sys: 6.07MB (6365736 bytes)
next-gc: when heap-alloc >= 219.73MB (230406536 bytes)
last-gc: 2024-10-30 08:23:03.569377121 +0000 UTC
gc-pause-total: 14.332887ms
gc-pause: 123517
gc-pause-end: 1730276583569377121
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.0005619122320289946
enable-gc: true
debug-gc: false
