key: 3a 02 00 00  value: 23 02 00 00
key: 4e 05 00 00  value: ff 01 00 00
key: d9 0a 00 00  value: 13 02 00 00
key: ab 0f 00 00  value: 68 02 00 00
Found 4 elements
