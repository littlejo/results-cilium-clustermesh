IP ADDRESS        LOCAL ENDPOINT INFO
10.95.0.177:0     id=2777  sec_id=3177945 flags=0x0000 ifindex=14  mac=F2:19:05:99:47:9C nodemac=32:7F:E3:0D:D8:6B   
172.31.199.14:0   (localhost)                                                                                        
172.31.214.5:0    (localhost)                                                                                        
10.95.0.230:0     id=1358  sec_id=3177945 flags=0x0000 ifindex=12  mac=4A:2E:9D:57:EB:A8 nodemac=52:01:01:C4:69:43   
10.95.0.70:0      (localhost)                                                                                        
10.95.0.64:0      id=570   sec_id=4     flags=0x0000 ifindex=10  mac=6A:83:90:90:81:5A nodemac=EE:E0:D8:F5:A3:1C     
10.95.0.103:0     id=4011  sec_id=3164795 flags=0x0000 ifindex=18  mac=D2:08:03:95:02:B2 nodemac=FE:ED:E0:8D:7E:26   
