USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         683  0.0  0.0 1228744 3600 ?        Ssl  08:23   0:00 /bin/gops pprof-cpu 1
root         674  0.0  0.2 1240176 16104 ?       Dsl  08:23   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         700  0.0  0.2 1240176 16104 ?       R    08:23   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         701  0.0  0.0   6408  1652 ?        R    08:23   0:00  \_ ps auxfw
root         668  0.0  0.0 1228744 4040 ?        Ssl  08:23   0:00 /bin/gops pprof-heap 1
root         648  0.0  0.0 1228744 3600 ?        Ssl  08:23   0:00 /bin/gops stack 1
root         642  0.0  0.0 1229000 4056 ?        Ssl  08:23   0:00 /bin/gops memstats 1
root           1  3.5  4.9 1606336 398608 ?      Ssl  07:56   0:57 cilium-agent --config-dir=/tmp/cilium/config-map
root         417  0.0  0.0 1229488 6744 ?        Sl   07:56   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
