[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2adf78d1_b544_49c7_8f14_206c18d73306.slice/cri-containerd-05f87dda74e7b598a20f4aaa09704eed318b59e829051982a0b1a2aea87769c1.scope"
      }
    ],
    "ips": [
      "10.95.0.177"
    ],
    "name": "coredns-cc6ccd49c-97mm5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaf3e0170_e8fa_4ef4_9723_4262019cf335.slice/cri-containerd-b0eb1e550170194ce523df46a79121cbedda3680468eed51c2a66655ac982659.scope"
      }
    ],
    "ips": [
      "10.95.0.230"
    ],
    "name": "coredns-cc6ccd49c-rd8n5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff910970_63ac_4c8a_982c_f48145aadcd0.slice/cri-containerd-2b11ecafc60383bc813cb41a7635514bee4e82650d8a6d671871bafdd7dbe4f7.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff910970_63ac_4c8a_982c_f48145aadcd0.slice/cri-containerd-7823a86f51c0d9244609e2d55f504dd76a4cfd4f6105a28a752b28a1986cfb83.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff910970_63ac_4c8a_982c_f48145aadcd0.slice/cri-containerd-c7b2d4f32a4a853d5e3ce3510df7eb93c12f05e1322a24312bdb9ffd2c616620.scope"
      }
    ],
    "ips": [
      "10.95.0.103"
    ],
    "name": "clustermesh-apiserver-6cb664f999-6j2ct",
    "namespace": "kube-system"
  }
]

