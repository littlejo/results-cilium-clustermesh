REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35744     2822841     677    bpf_overlay.c
Interface                 INGRESS     641812    132004125   1132   bpf_host.c
Success                   EGRESS      15261     1197236     1694   bpf_host.c
Success                   EGRESS      279960    35677029    1308   bpf_lxc.c
Success                   EGRESS      35104     2780379     53     encap.h
Success                   INGRESS     320164    36092461    86     l3.h
Success                   INGRESS     341298    37762112    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
