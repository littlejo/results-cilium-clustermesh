1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:55:ca:70:9f:cd brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.214.5/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3322sec preferred_lft 3322sec
    inet6 fe80::855:caff:fe70:9fcd/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:57:41:d3:a3:07 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.199.14/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::857:41ff:fed3:a307/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:f1:10:9e:d6:a9 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::98f1:10ff:fe9e:d6a9/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:7e:20:1f:28:a6 brd ff:ff:ff:ff:ff:ff
    inet 10.95.0.70/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::747e:20ff:fe1f:28a6/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 0a:4f:78:78:e0:a7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::84f:78ff:fe78:e0a7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:e0:d8:f5:a3:1c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::ece0:d8ff:fef5:a31c/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcc05da53a309c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:01:01:c4:69:43 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::5001:1ff:fec4:6943/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcd52d184cbbd8@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:7f:e3:0d:d8:6b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::307f:e3ff:fe0d:d86b/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc28b03d590a55@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:ed:e0:8d:7e:26 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::fced:e0ff:fe8d:7e26/64 scope link 
       valid_lft forever preferred_lft forever
