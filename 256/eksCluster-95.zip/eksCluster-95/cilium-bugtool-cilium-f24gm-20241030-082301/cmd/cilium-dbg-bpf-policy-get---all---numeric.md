Endpoint ID: 570
Path: /sys/fs/bpf/tc/globals/cilium_policy_00570

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1673763   21187     0        
Allow    Ingress     1          ANY          NONE         disabled    23524     275       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 573
Path: /sys/fs/bpf/tc/globals/cilium_policy_00573

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1358
Path: /sys/fs/bpf/tc/globals/cilium_policy_01358

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    155920   1791      0        
Allow    Egress      0          ANY          NONE         disabled    19276    214       0        


Endpoint ID: 2777
Path: /sys/fs/bpf/tc/globals/cilium_policy_02777

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    156778   1804      0        
Allow    Egress      0          ANY          NONE         disabled    19970    221       0        


Endpoint ID: 4011
Path: /sys/fs/bpf/tc/globals/cilium_policy_04011

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11468655   112601    0        
Allow    Ingress     1          ANY          NONE         disabled    10299842   104537    0        
Allow    Egress      0          ANY          NONE         disabled    10962033   109478    0        


