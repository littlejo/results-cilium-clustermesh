top - 08:22:53 up 28 min,  0 users,  load average: 0.10, 0.16, 0.15
Tasks:   9 total,   2 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 61.3 us, 25.8 sy,  0.0 ni,  6.5 id,  0.0 wa,  0.0 hi,  6.5 si,  0.0 st
MiB Mem :   7814.2 total,   4469.1 free,   1200.4 used,   2144.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6428.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 388820  77956 S  86.7   4.9   0:37.93 cilium-+
    639 root      20   0 1240432  16628  11292 S   6.7   0.2   0:00.03 cilium-+
    394 root      20   0 1229488   7256   2924 S   0.0   0.1   0:01.05 cilium-+
    618 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    621 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    666 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    684 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    690 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    699 root      20   0 1485192   9256   6548 R   0.0   0.1   0:00.00 runc:[2+
