32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:54:12+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:54:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:54:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:54:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:54:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:54:12+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:54:13+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:54:13+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:54:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:54:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:54:13+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:54:13+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:54:16+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:54:26+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name tail_handle_ipv4  tag 5c1574ba992c63c9  gpl
	loaded_at 2024-10-30T08:03:32+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
482: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:03:32+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
483: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:03:32+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 126
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:03:32+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
516: sched_cls  name tail_ipv4_to_endpoint  tag f023bf49d3c0d521  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 164
519: sched_cls  name __send_drop_notify  tag 11a5f64d57b8fc31  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 168
520: sched_cls  name cil_from_container  tag 15ad081b5d769dfa  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 169
521: sched_cls  name tail_handle_arp  tag 6e26a6e4bc1b0c14  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 171
523: sched_cls  name tail_ipv4_ct_egress  tag 40ce6b3e1b5d6b64  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 172
524: sched_cls  name tail_handle_ipv4_cont  tag 3992ba5f7a4fff7b  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 174
526: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 176
529: sched_cls  name tail_handle_ipv4  tag b3d5378e9c0f116b  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 177
530: sched_cls  name tail_ipv4_ct_ingress  tag 59a9e4f2a2443c7d  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 180
534: sched_cls  name tail_handle_arp  tag e6f3c40a11ba40ed  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 185
535: sched_cls  name handle_policy  tag 9ce1ce1d65c50daf  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 181
537: sched_cls  name tail_handle_ipv4_from_host  tag b16e6f682c65bc46  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 189
538: sched_cls  name tail_ipv4_to_endpoint  tag afa1f6576fc70474  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 186
539: sched_cls  name __send_drop_notify  tag 5c63db1e4ef2732a  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 190
540: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 191
541: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 192
542: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,118
	btf_id 193
544: sched_cls  name tail_handle_ipv4_from_host  tag b16e6f682c65bc46  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 196
545: sched_cls  name __send_drop_notify  tag 5c63db1e4ef2732a  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 197
546: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 198
547: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 199
551: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 204
555: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 209
556: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 207
557: sched_cls  name tail_handle_ipv4_from_host  tag b16e6f682c65bc46  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 210
558: sched_cls  name __send_drop_notify  tag 5c63db1e4ef2732a  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 212
559: sched_cls  name tail_handle_ipv4_from_host  tag b16e6f682c65bc46  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 214
560: sched_cls  name __send_drop_notify  tag 5c63db1e4ef2732a  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 215
561: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 216
565: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 220
566: sched_cls  name tail_ipv4_ct_ingress  tag d69a9d04cd443408  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 211
567: sched_cls  name tail_ipv4_ct_egress  tag 40ce6b3e1b5d6b64  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 221
570: sched_cls  name handle_policy  tag fbb4cd4a8235f8a7  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,125,82,83,126,41,80,100,39,84,75,40,37,38
	btf_id 226
571: sched_cls  name handle_policy  tag fd6e16bc8200a8ce  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 223
572: sched_cls  name __send_drop_notify  tag 92bb7357e3705ae8  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 227
573: sched_cls  name tail_handle_ipv4  tag 71b9a09a2b1fde5c  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 228
574: sched_cls  name tail_handle_ipv4_cont  tag ac2d8f61da480cb0  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 230
575: sched_cls  name tail_ipv4_to_endpoint  tag 76f7b397246c5d8c  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,126,41,82,83,80,100,39,125,40,37,38
	btf_id 229
576: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 231
577: sched_cls  name __send_drop_notify  tag ccb8b02f2edfeffe  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 232
578: sched_cls  name tail_handle_arp  tag 9926d23af5dded55  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 233
579: sched_cls  name tail_handle_ipv4_cont  tag 5c90f533735da71e  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,126,41,100,82,83,39,76,74,77,125,40,37,38,81
	btf_id 235
580: sched_cls  name cil_from_container  tag ac92d15ccede53bd  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 125,76
	btf_id 236
581: sched_cls  name tail_ipv4_ct_ingress  tag b06301b394abbf50  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 237
582: sched_cls  name tail_handle_ipv4  tag 78763bc0b4325008  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 234
583: sched_cls  name cil_from_container  tag 20d80d087ff86deb  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 239
584: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 238
585: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
588: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
589: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
592: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: sched_cls  name tail_ipv4_ct_egress  tag 4afed02d5066f87e  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 253
641: sched_cls  name tail_handle_ipv4  tag ac26b0426659a47d  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 254
642: sched_cls  name cil_from_container  tag 67142f2a9fe1103a  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 255
643: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 256
644: sched_cls  name __send_drop_notify  tag 1637518bf225122e  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 257
646: sched_cls  name handle_policy  tag cc8b824c8dcf0edf  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 259
647: sched_cls  name tail_ipv4_to_endpoint  tag 3a2c5a6dba74cf9d  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 260
648: sched_cls  name tail_ipv4_ct_ingress  tag 3f724e626eff5249  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 261
649: sched_cls  name tail_handle_ipv4_cont  tag ee71e883c747c582  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 262
650: sched_cls  name tail_handle_arp  tag 7a787390ece0f5a3  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 263
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
667: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
670: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
671: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
674: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
