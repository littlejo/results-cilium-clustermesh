1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:78:24:56:42:4f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.170.23/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1886sec preferred_lft 1886sec
    inet6 fe80::478:24ff:fe56:424f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:e7:a3:d2:3a:85 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.135.14/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4e7:a3ff:fed2:3a85/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:d4:4a:26:bf:a2 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::38d4:4aff:fe26:bfa2/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:c1:20:37:03:5d brd ff:ff:ff:ff:ff:ff
    inet 10.192.0.153/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::64c1:20ff:fe37:35d/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 2e:6d:bc:7e:2d:30 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2c6d:bcff:fe7e:2d30/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:26:b9:e2:8b:98 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b426:b9ff:fee2:8b98/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc277ebb4c3fbf@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:ab:86:84:c0:59 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::84ab:86ff:fe84:c059/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc6f82b5e21edf@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:56:ff:76:3d:e6 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::3456:ffff:fe76:3de6/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc0cddb5861ce1@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:03:bf:f0:10:4b brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::803:bfff:fef0:104b/64 scope link 
       valid_lft forever preferred_lft forever
