[
  {
    "containers": [
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd9677b7_dceb_4e0d_a2c8_c01e4336b4b0.slice/cri-containerd-3a8bffa83f27442b55afc0c5a502e92b80d61b5f15d1b309d989430eb3fcccbd.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd9677b7_dceb_4e0d_a2c8_c01e4336b4b0.slice/cri-containerd-115cade7289f5294bc719188c7d72dee6479b786b541b2785ff14099afb7f35e.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd9677b7_dceb_4e0d_a2c8_c01e4336b4b0.slice/cri-containerd-d9b26f6e19799f87a7e1413a00a0cedeadfc7ecfcfba94b7a86881cdede02923.scope"
      }
    ],
    "ips": [
      "10.192.0.109"
    ],
    "name": "clustermesh-apiserver-7bcb4667cb-l6zc5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda33a9a3e_4880_4032_9f74_ea6faba576b3.slice/cri-containerd-7905b186ac0d63fcbfa69a06599b2910a6c829052fc5ff7761dc0506b217302b.scope"
      }
    ],
    "ips": [
      "10.192.0.205"
    ],
    "name": "coredns-cc6ccd49c-gdlr2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poded8e9580_b3fc_49fa_bcef_6a77bb3fa4c6.slice/cri-containerd-495b379ee8e5f855bdf8860e898db0649ca1a0f353396d75120d12cfbde1b922.scope"
      }
    ],
    "ips": [
      "10.192.0.215"
    ],
    "name": "coredns-cc6ccd49c-9lqfb",
    "namespace": "kube-system"
  }
]

