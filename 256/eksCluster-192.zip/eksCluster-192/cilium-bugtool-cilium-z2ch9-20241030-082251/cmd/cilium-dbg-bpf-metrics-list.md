REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34117     2694375     677    bpf_overlay.c
Interface                 INGRESS     610561    128035094   1132   bpf_host.c
Success                   EGRESS      13987     1094019     1694   bpf_host.c
Success                   EGRESS      256149    32629707    1308   bpf_lxc.c
Success                   EGRESS      32786     2599064     53     encap.h
Success                   INGRESS     294932    33301520    86     l3.h
Success                   INGRESS     315713    34945922    235    trace.h
Unsupported L3 protocol   EGRESS      41        3062        1492   bpf_lxc.c
