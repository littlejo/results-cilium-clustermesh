Endpoint ID: 767
Path: /sys/fs/bpf/tc/globals/cilium_policy_00767

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11357071   111406    0        
Allow    Ingress     1          ANY          NONE         disabled    8718541    90718     0        
Allow    Egress      0          ANY          NONE         disabled    11223332   111265    0        


Endpoint ID: 1063
Path: /sys/fs/bpf/tc/globals/cilium_policy_01063

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1646134   20805     0        
Allow    Ingress     1          ANY          NONE         disabled    16962     199       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1190
Path: /sys/fs/bpf/tc/globals/cilium_policy_01190

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2183
Path: /sys/fs/bpf/tc/globals/cilium_policy_02183

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113473   1301      0        
Allow    Egress      0          ANY          NONE         disabled    16272    176       0        


Endpoint ID: 2942
Path: /sys/fs/bpf/tc/globals/cilium_policy_02942

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112813   1291      0        
Allow    Egress      0          ANY          NONE         disabled    17071    184       0        


