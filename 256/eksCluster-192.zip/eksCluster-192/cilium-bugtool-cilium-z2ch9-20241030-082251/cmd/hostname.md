ip-172-31-170-23.eu-west-3.compute.internal
