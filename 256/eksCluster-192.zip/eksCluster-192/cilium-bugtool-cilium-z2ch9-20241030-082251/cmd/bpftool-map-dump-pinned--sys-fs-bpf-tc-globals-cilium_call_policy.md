key: ff 02 00 00  value: 86 02 00 00
key: 27 04 00 00  value: 3a 02 00 00
key: 87 08 00 00  value: 3b 02 00 00
key: 7e 0b 00 00  value: 17 02 00 00
Found 4 elements
