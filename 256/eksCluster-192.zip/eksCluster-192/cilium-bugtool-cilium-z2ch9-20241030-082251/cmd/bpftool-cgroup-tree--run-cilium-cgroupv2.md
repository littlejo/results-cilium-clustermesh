CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poded8e9580_b3fc_49fa_bcef_6a77bb3fa4c6.slice/cri-containerd-495b379ee8e5f855bdf8860e898db0649ca1a0f353396d75120d12cfbde1b922.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poded8e9580_b3fc_49fa_bcef_6a77bb3fa4c6.slice/cri-containerd-a119d93d14b911e619d9d32af892ca3423d7586ca46fa367bf5064bb00dcc997.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3a7eacde_5199_40b4_9056_52e71c021e84.slice/cri-containerd-038a6580349c89e578813264d9db3d58b9d70ccf5a43d56119cc891ae9d65846.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3a7eacde_5199_40b4_9056_52e71c021e84.slice/cri-containerd-285f798e9d5cfb448025ed8a586ca39abc1afd9aa820bc9a250f1f63c8a06274.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7220e662_cc23_4547_8850_18973d16c56c.slice/cri-containerd-49b446968286c663e2db779e403ca325dfa52d0acd4a60a3ab2ba3bd8a64fe85.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7220e662_cc23_4547_8850_18973d16c56c.slice/cri-containerd-76d82a8f4239b86df7f37fe73aee0aa6577fc52188d2d26692a1eeb788101a52.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda33a9a3e_4880_4032_9f74_ea6faba576b3.slice/cri-containerd-09b7efbbb1e17bda346c236ad1f1515d12cc727dbd8fe9d5518df8487b7fab78.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda33a9a3e_4880_4032_9f74_ea6faba576b3.slice/cri-containerd-7905b186ac0d63fcbfa69a06599b2910a6c829052fc5ff7761dc0506b217302b.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod529bf826_fb56_49d1_8097_6f125bc0b6bd.slice/cri-containerd-de05ba214acb6b738b622b66feabed2c511357a62eb905e518ead0bb9902a3f5.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod529bf826_fb56_49d1_8097_6f125bc0b6bd.slice/cri-containerd-c119bd71543f1df59d7506661c533e30cccf144431bab2d0d3ef6950ad350025.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8b8dc698_df59_43e0_918b_5492979e8838.slice/cri-containerd-f820a8ef8cd5c51c02fb3df4a44e52c7787e56fb1889e7c7bf58df64902215b0.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8b8dc698_df59_43e0_918b_5492979e8838.slice/cri-containerd-41deb6677d10bb0274dcf63330a49f42d42447ad1b3c6c1e2cd81c5b4277d217.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd9677b7_dceb_4e0d_a2c8_c01e4336b4b0.slice/cri-containerd-a85eccabbed30d285c2ffc59e9a22cbb956eb8a021e00e826547ff8b2d0d2117.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd9677b7_dceb_4e0d_a2c8_c01e4336b4b0.slice/cri-containerd-115cade7289f5294bc719188c7d72dee6479b786b541b2785ff14099afb7f35e.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd9677b7_dceb_4e0d_a2c8_c01e4336b4b0.slice/cri-containerd-3a8bffa83f27442b55afc0c5a502e92b80d61b5f15d1b309d989430eb3fcccbd.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd9677b7_dceb_4e0d_a2c8_c01e4336b4b0.slice/cri-containerd-d9b26f6e19799f87a7e1413a00a0cedeadfc7ecfcfba94b7a86881cdede02923.scope
    670      cgroup_device   multi                                          
