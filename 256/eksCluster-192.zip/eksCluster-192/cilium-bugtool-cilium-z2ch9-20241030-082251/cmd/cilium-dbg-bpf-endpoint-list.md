IP ADDRESS        LOCAL ENDPOINT INFO
10.192.0.205:0    id=2942  sec_id=6324235 flags=0x0000 ifindex=12  mac=8A:9D:A2:E0:96:9D nodemac=86:AB:86:84:C0:59   
172.31.170.23:0   (localhost)                                                                                        
10.192.0.215:0    id=2183  sec_id=6324235 flags=0x0000 ifindex=14  mac=FA:CC:43:D8:04:BC nodemac=36:56:FF:76:3D:E6   
10.192.0.82:0     id=1063  sec_id=4     flags=0x0000 ifindex=10  mac=02:4B:1F:C7:80:8B nodemac=B6:26:B9:E2:8B:98     
172.31.135.14:0   (localhost)                                                                                        
10.192.0.153:0    (localhost)                                                                                        
10.192.0.109:0    id=767   sec_id=6347567 flags=0x0000 ifindex=18  mac=4E:7E:21:19:48:A4 nodemac=0A:03:BF:F0:10:4B   
