markdown output at /tmp/cilium-bugtool-20241030-082252.803+0000-UTC-17101342/cmd/cilium-debuginfo-20241030-082323.938+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082252.803+0000-UTC-17101342/cmd/cilium-debuginfo-20241030-082323.938+0000-UTC.json
