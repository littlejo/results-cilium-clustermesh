 08:22:52 up 28 min,  0 users,  load average: 0.10, 0.16, 0.15
