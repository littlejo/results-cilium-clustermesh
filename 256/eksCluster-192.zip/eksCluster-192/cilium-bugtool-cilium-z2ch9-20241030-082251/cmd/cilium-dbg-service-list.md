ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.222.83:443 (active)    
                                          2 => 172.31.188.110:443 (active)   
2    10.100.195.176:443    ClusterIP      1 => 172.31.170.23:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.192.0.205:53 (active)      
                                          2 => 10.192.0.215:53 (active)      
4    10.100.0.10:9153      ClusterIP      1 => 10.192.0.205:9153 (active)    
                                          2 => 10.192.0.215:9153 (active)    
5    10.100.233.161:2379   ClusterIP      1 => 10.192.0.109:2379 (active)    
