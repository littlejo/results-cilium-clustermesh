key: 02 00 00 00  value: ac 1f bc 6e 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a c0 00 d7 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a c0 00 cd 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a c0 00 cd 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f aa 17 10 94 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a c0 00 6d 09 4b 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f de 53 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a c0 00 d7 23 c1 00 00  00 00 00 00
Found 8 elements
