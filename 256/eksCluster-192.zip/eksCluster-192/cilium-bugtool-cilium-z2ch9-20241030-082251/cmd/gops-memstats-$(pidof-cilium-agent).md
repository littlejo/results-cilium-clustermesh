alloc: 106.54MB (111717496 bytes)
total-alloc: 2.11GB (2269496152 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 61371187
frees: 60537150
heap-alloc: 106.54MB (111717496 bytes)
heap-sys: 251.63MB (263856128 bytes)
heap-idle: 85.79MB (89956352 bytes)
heap-in-use: 165.84MB (173899776 bytes)
heap-released: 2.00MB (2097152 bytes)
heap-objects: 834037
stack-in-use: 60.34MB (63275008 bytes)
stack-sys: 60.34MB (63275008 bytes)
stack-mspan-inuse: 2.84MB (2977280 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 975.31KB (998713 bytes)
gc-sys: 6.01MB (6303280 bytes)
next-gc: when heap-alloc >= 216.25MB (226750184 bytes)
last-gc: 2024-10-30 08:23:16.082752223 +0000 UTC
gc-pause-total: 10.897314ms
gc-pause: 75394
gc-pause-end: 1730276596082752223
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0004555123187173526
enable-gc: true
debug-gc: false
