KEY             VALUE
AgentLiveness   1774539769576
UTimeOffset     3379443031250000
