IP ADDRESS         LOCAL ENDPOINT INFO
10.241.0.17:0      id=4003  sec_id=7930317 flags=0x0000 ifindex=14  mac=9A:64:DF:95:E6:E9 nodemac=D6:29:F4:3A:8F:C7   
172.31.225.246:0   (localhost)                                                                                        
10.241.0.209:0     (localhost)                                                                                        
10.241.0.61:0      id=1575  sec_id=7962303 flags=0x0000 ifindex=18  mac=C2:04:CD:9B:6D:DD nodemac=2A:25:11:23:29:57   
10.241.0.22:0      id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=16:04:26:F9:7A:F4 nodemac=9E:5D:3F:88:D6:BD     
10.241.0.250:0     id=2032  sec_id=7930317 flags=0x0000 ifindex=12  mac=32:F3:5D:6B:9F:8D nodemac=3E:30:27:58:B4:3D   
172.31.244.127:0   (localhost)                                                                                        
