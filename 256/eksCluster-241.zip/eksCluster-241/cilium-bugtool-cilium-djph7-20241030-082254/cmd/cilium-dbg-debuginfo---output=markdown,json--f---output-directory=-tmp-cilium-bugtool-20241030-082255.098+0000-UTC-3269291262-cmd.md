markdown output at /tmp/cilium-bugtool-20241030-082255.098+0000-UTC-3269291262/cmd/cilium-debuginfo-20241030-082326.241+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082255.098+0000-UTC-3269291262/cmd/cilium-debuginfo-20241030-082326.241+0000-UTC.json
