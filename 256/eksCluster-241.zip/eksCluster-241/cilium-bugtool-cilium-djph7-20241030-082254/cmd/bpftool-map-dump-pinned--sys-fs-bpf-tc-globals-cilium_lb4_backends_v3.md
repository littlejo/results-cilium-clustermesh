key: 01 00 00 00  value: ac 1f ba fe 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a f1 00 11 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a f1 00 3d 09 4b 00 00  00 00 00 00
key: 04 00 00 00  value: 0a f1 00 fa 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: 0a f1 00 fa 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: 0a f1 00 11 23 c1 00 00  00 00 00 00
key: 03 00 00 00  value: ac 1f e1 f6 10 94 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f fb 59 01 bb 00 00  00 00 00 00
Found 8 elements
