alloc: 158.72MB (166430976 bytes)
total-alloc: 2.28GB (2449652528 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 64154588
frees: 62419736
heap-alloc: 158.72MB (166430976 bytes)
heap-sys: 243.77MB (255606784 bytes)
heap-idle: 59.96MB (62873600 bytes)
heap-in-use: 183.80MB (192733184 bytes)
heap-released: 2.91MB (3047424 bytes)
heap-objects: 1734852
stack-in-use: 64.19MB (67305472 bytes)
stack-sys: 64.19MB (67305472 bytes)
stack-mspan-inuse: 3.08MB (3232960 bytes)
stack-mspan-sys: 3.74MB (3916800 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.08MB (1137049 bytes)
gc-sys: 6.04MB (6329952 bytes)
next-gc: when heap-alloc >= 213.02MB (223365736 bytes)
last-gc: 2024-10-30 08:22:59.249101351 +0000 UTC
gc-pause-total: 17.201054ms
gc-pause: 118344
gc-pause-end: 1730276579249101351
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005295543593815058
enable-gc: true
debug-gc: false
