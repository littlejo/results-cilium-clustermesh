REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36883     2917319     677    bpf_overlay.c
Interface                 INGRESS     659192    133863415   1132   bpf_host.c
Success                   EGRESS      16573     1304451     1694   bpf_host.c
Success                   EGRESS      283565    35079497    1308   bpf_lxc.c
Success                   EGRESS      37251     2943341     53     encap.h
Success                   INGRESS     324212    36872857    86     l3.h
Success                   INGRESS     345173    38529771    235    trace.h
Unsupported L3 protocol   EGRESS      37        2742        1492   bpf_lxc.c
