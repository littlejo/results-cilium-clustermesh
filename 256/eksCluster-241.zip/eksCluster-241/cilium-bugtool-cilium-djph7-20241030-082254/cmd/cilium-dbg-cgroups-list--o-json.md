[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfcecb7fc_5a7f_40c9_bd3a_c05261157840.slice/cri-containerd-4c3a067509eabcb9ceb1af261da635e262f28e9e84a498955f40f021e7ec2a5d.scope"
      }
    ],
    "ips": [
      "10.241.0.250"
    ],
    "name": "coredns-cc6ccd49c-4ngxc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc00c0172_d681_4f60_8310_670d95c5bb01.slice/cri-containerd-b21f4ea7edc6fa6d8e3895b5ffe17df6810d5f45d6bdfe8a570803e8b68b840c.scope"
      }
    ],
    "ips": [
      "10.241.0.17"
    ],
    "name": "coredns-cc6ccd49c-4978g",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0332d26e_81ba_4251_8bc0_5d4154826da7.slice/cri-containerd-1cba01665e0470fa62a9e95b0ed5e7fb953aa5c04c9acdd6bfef0fc34143e704.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0332d26e_81ba_4251_8bc0_5d4154826da7.slice/cri-containerd-2e9d91013c9fc868348c7ec4f4fa36eef5f06b5750a3d808d6825db6c5fd8085.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0332d26e_81ba_4251_8bc0_5d4154826da7.slice/cri-containerd-0059336e063de7ce5f0c5eae9c0e58079557702233ea0bc66fcffa821f9d7e33.scope"
      }
    ],
    "ips": [
      "10.241.0.61"
    ],
    "name": "clustermesh-apiserver-6fc56c948f-zbj8l",
    "namespace": "kube-system"
  }
]

