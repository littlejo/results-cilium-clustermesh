USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         675  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         654  0.0  0.1 1240432 15820 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         685  0.0  0.1 1240432 15820 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         686  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         632  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         631  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         625  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  4.4  4.6 1606080 373804 ?      Ssl  08:03   0:52 cilium-agent --config-dir=/tmp/cilium/config-map
root         398  0.0  0.1 1229744 8004 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
