ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.186.254:443 (active)    
                                         2 => 172.31.251.89:443 (active)     
2    10.100.35.139:443    ClusterIP      1 => 172.31.225.246:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.241.0.250:9153 (active)     
                                         2 => 10.241.0.17:9153 (active)      
4    10.100.0.10:53       ClusterIP      1 => 10.241.0.250:53 (active)       
                                         2 => 10.241.0.17:53 (active)        
5    10.100.246.23:2379   ClusterIP      1 => 10.241.0.61:2379 (active)      
