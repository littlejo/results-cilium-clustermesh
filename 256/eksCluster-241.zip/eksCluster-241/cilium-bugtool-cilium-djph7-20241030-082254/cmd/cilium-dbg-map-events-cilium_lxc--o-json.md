{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:26.980Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.225.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:26.980Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.244.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:26.980Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:31.709Z",
  "value": "id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=16:04:26:F9:7A:F4 nodemac=9E:5D:3F:88:D6:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:31.711Z",
  "value": "id=2032  sec_id=7930317 flags=0x0000 ifindex=12  mac=32:F3:5D:6B:9F:8D nodemac=3E:30:27:58:B4:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:31.779Z",
  "value": "id=4003  sec_id=7930317 flags=0x0000 ifindex=14  mac=9A:64:DF:95:E6:E9 nodemac=D6:29:F4:3A:8F:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:31.786Z",
  "value": "id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=16:04:26:F9:7A:F4 nodemac=9E:5D:3F:88:D6:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:13.269Z",
  "value": "id=4003  sec_id=7930317 flags=0x0000 ifindex=14  mac=9A:64:DF:95:E6:E9 nodemac=D6:29:F4:3A:8F:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:13.269Z",
  "value": "id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=16:04:26:F9:7A:F4 nodemac=9E:5D:3F:88:D6:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:13.270Z",
  "value": "id=2032  sec_id=7930317 flags=0x0000 ifindex=12  mac=32:F3:5D:6B:9F:8D nodemac=3E:30:27:58:B4:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:13.299Z",
  "value": "id=3183  sec_id=7962303 flags=0x0000 ifindex=16  mac=86:61:CA:29:ED:24 nodemac=22:0A:3E:6B:65:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:14.268Z",
  "value": "id=2032  sec_id=7930317 flags=0x0000 ifindex=12  mac=32:F3:5D:6B:9F:8D nodemac=3E:30:27:58:B4:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:14.269Z",
  "value": "id=4003  sec_id=7930317 flags=0x0000 ifindex=14  mac=9A:64:DF:95:E6:E9 nodemac=D6:29:F4:3A:8F:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:14.269Z",
  "value": "id=3183  sec_id=7962303 flags=0x0000 ifindex=16  mac=86:61:CA:29:ED:24 nodemac=22:0A:3E:6B:65:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:14.269Z",
  "value": "id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=16:04:26:F9:7A:F4 nodemac=9E:5D:3F:88:D6:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:56.596Z",
  "value": "id=1575  sec_id=7962303 flags=0x0000 ifindex=18  mac=C2:04:CD:9B:6D:DD nodemac=2A:25:11:23:29:57"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.241.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:06.985Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:07.770Z",
  "value": "id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=16:04:26:F9:7A:F4 nodemac=9E:5D:3F:88:D6:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:07.771Z",
  "value": "id=2032  sec_id=7930317 flags=0x0000 ifindex=12  mac=32:F3:5D:6B:9F:8D nodemac=3E:30:27:58:B4:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:07.772Z",
  "value": "id=4003  sec_id=7930317 flags=0x0000 ifindex=14  mac=9A:64:DF:95:E6:E9 nodemac=D6:29:F4:3A:8F:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:07.772Z",
  "value": "id=1575  sec_id=7962303 flags=0x0000 ifindex=18  mac=C2:04:CD:9B:6D:DD nodemac=2A:25:11:23:29:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:08.770Z",
  "value": "id=4003  sec_id=7930317 flags=0x0000 ifindex=14  mac=9A:64:DF:95:E6:E9 nodemac=D6:29:F4:3A:8F:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:08.770Z",
  "value": "id=1575  sec_id=7962303 flags=0x0000 ifindex=18  mac=C2:04:CD:9B:6D:DD nodemac=2A:25:11:23:29:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:08.770Z",
  "value": "id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=16:04:26:F9:7A:F4 nodemac=9E:5D:3F:88:D6:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:08.770Z",
  "value": "id=2032  sec_id=7930317 flags=0x0000 ifindex=12  mac=32:F3:5D:6B:9F:8D nodemac=3E:30:27:58:B4:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.770Z",
  "value": "id=2032  sec_id=7930317 flags=0x0000 ifindex=12  mac=32:F3:5D:6B:9F:8D nodemac=3E:30:27:58:B4:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.770Z",
  "value": "id=1575  sec_id=7962303 flags=0x0000 ifindex=18  mac=C2:04:CD:9B:6D:DD nodemac=2A:25:11:23:29:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.771Z",
  "value": "id=4003  sec_id=7930317 flags=0x0000 ifindex=14  mac=9A:64:DF:95:E6:E9 nodemac=D6:29:F4:3A:8F:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.771Z",
  "value": "id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=16:04:26:F9:7A:F4 nodemac=9E:5D:3F:88:D6:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.771Z",
  "value": "id=2032  sec_id=7930317 flags=0x0000 ifindex=12  mac=32:F3:5D:6B:9F:8D nodemac=3E:30:27:58:B4:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.771Z",
  "value": "id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=16:04:26:F9:7A:F4 nodemac=9E:5D:3F:88:D6:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.772Z",
  "value": "id=4003  sec_id=7930317 flags=0x0000 ifindex=14  mac=9A:64:DF:95:E6:E9 nodemac=D6:29:F4:3A:8F:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.241.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.772Z",
  "value": "id=1575  sec_id=7962303 flags=0x0000 ifindex=18  mac=C2:04:CD:9B:6D:DD nodemac=2A:25:11:23:29:57"
}

