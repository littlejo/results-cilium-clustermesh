key: 27 06 00 00  value: 85 02 00 00
key: f0 07 00 00  value: 01 02 00 00
key: ee 0a 00 00  value: 43 02 00 00
key: a3 0f 00 00  value: 42 02 00 00
Found 4 elements
