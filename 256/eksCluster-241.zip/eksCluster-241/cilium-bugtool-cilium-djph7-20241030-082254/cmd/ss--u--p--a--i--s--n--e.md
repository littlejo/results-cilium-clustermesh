Total: 676
TCP:   1878 (estab 443, closed 1416, orphaned 0, timewait 565)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  462       451       11       
INET	  472       457       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:35061      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:34531 sk:3f9 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.225.246%ens5:68         0.0.0.0:*    uid:192 ino:15719 sk:3fa cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:35633 sk:3fb cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15197 sk:3fc cgroup:unreachable:f0c <->                                    
UNCONN 0      0      [fe80::808:acff:fe8f:4377]%ens5:546           [::]:*    uid:192 ino:15711 sk:3fd cgroup:unreachable:c4e v6only:1 <->                   
UNCONN 0      0                                 [::]:8472          [::]:*    ino:35632 sk:3fe cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15198 sk:3ff cgroup:unreachable:f0c v6only:1 <->                           
