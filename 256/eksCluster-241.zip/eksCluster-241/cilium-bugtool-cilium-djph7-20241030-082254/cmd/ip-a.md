1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:08:ac:8f:43:77 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.225.246/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1869sec preferred_lft 1869sec
    inet6 fe80::808:acff:fe8f:4377/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:46:b8:d2:27:41 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.244.127/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::846:b8ff:fed2:2741/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:5c:80:04:72:be brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a45c:80ff:fe04:72be/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:3c:99:92:5f:ca brd ff:ff:ff:ff:ff:ff
    inet 10.241.0.209/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c43c:99ff:fe92:5fca/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether aa:aa:24:f1:6c:90 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a8aa:24ff:fef1:6c90/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:5d:3f:88:d6:bd brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::9c5d:3fff:fe88:d6bd/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca8381f848026@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:30:27:58:b4:3d brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::3c30:27ff:fe58:b43d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc9d33eff46c42@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:29:f4:3a:8f:c7 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d429:f4ff:fe3a:8fc7/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb0b0bfe2e243@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:25:11:23:29:57 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2825:11ff:fe23:2957/64 scope link 
       valid_lft forever preferred_lft forever
