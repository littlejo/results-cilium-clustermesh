Endpoint ID: 1335
Path: /sys/fs/bpf/tc/globals/cilium_policy_01335

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1575
Path: /sys/fs/bpf/tc/globals/cilium_policy_01575

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11610876   116739    0        
Allow    Ingress     1          ANY          NONE         disabled    10468980   110507    0        
Allow    Egress      0          ANY          NONE         disabled    14513296   141915    0        


Endpoint ID: 2032
Path: /sys/fs/bpf/tc/globals/cilium_policy_02032

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112879   1292      0        
Allow    Egress      0          ANY          NONE         disabled    16542    177       0        


Endpoint ID: 2798
Path: /sys/fs/bpf/tc/globals/cilium_policy_02798

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1661316   21017     0        
Allow    Ingress     1          ANY          NONE         disabled    17596     208       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 4003
Path: /sys/fs/bpf/tc/globals/cilium_policy_04003

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113570   1306      0        
Allow    Egress      0          ANY          NONE         disabled    15832    170       0        


