ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.148.164:443 (active)    
                                        2 => 172.31.247.216:443 (active)    
2    10.100.104.73:443   ClusterIP      1 => 172.31.225.122:4244 (active)   
3    10.100.0.10:9153    ClusterIP      1 => 10.89.0.242:9153 (active)      
                                        2 => 10.89.0.222:9153 (active)      
4    10.100.0.10:53      ClusterIP      1 => 10.89.0.242:53 (active)        
                                        2 => 10.89.0.222:53 (active)        
5    10.100.77.9:2379    ClusterIP      1 => 10.89.0.142:2379 (active)      
