Endpoint ID: 811
Path: /sys/fs/bpf/tc/globals/cilium_policy_00811

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    417518   3758      0        
Allow    Ingress     1          ANY          NONE         disabled    162148   1864      0        
Allow    Egress      0          ANY          NONE         disabled    116764   1129      0        


Endpoint ID: 1057
Path: /sys/fs/bpf/tc/globals/cilium_policy_01057

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1674084   21163     0        
Allow    Ingress     1          ANY          NONE         disabled    24640     288       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2146
Path: /sys/fs/bpf/tc/globals/cilium_policy_02146

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11432829   112408    0        
Allow    Ingress     1          ANY          NONE         disabled    9561575    100061    0        
Allow    Egress      0          ANY          NONE         disabled    11239269   111801    0        


Endpoint ID: 2851
Path: /sys/fs/bpf/tc/globals/cilium_policy_02851

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    434542   3892      0        
Allow    Ingress     1          ANY          NONE         disabled    162346   1867      0        
Allow    Egress      0          ANY          NONE         disabled    116960   1126      0        


Endpoint ID: 3215
Path: /sys/fs/bpf/tc/globals/cilium_policy_03215

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


