alloc: 165.08MB (173097648 bytes)
total-alloc: 2.29GB (2462901472 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 64165690
frees: 62405512
heap-alloc: 165.08MB (173097648 bytes)
heap-sys: 251.30MB (263503872 bytes)
heap-idle: 64.90MB (68050944 bytes)
heap-in-use: 186.40MB (195452928 bytes)
heap-released: 640.00KB (655360 bytes)
heap-objects: 1760178
stack-in-use: 64.66MB (67796992 bytes)
stack-sys: 64.66MB (67796992 bytes)
stack-mspan-inuse: 3.13MB (3283360 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 988.62KB (1012345 bytes)
gc-sys: 6.02MB (6313424 bytes)
next-gc: when heap-alloc >= 213.68MB (224057992 bytes)
last-gc: 2024-10-30 08:23:07.014197478 +0000 UTC
gc-pause-total: 14.350282ms
gc-pause: 64736
gc-pause-end: 1730276587014197478
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00036703710400353567
enable-gc: true
debug-gc: false
