[
  {
    "containers": [
      {
        "cgroup-id": 9184,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0142ebbe_8e29_49f1_b27e_719d8f9894f5.slice/cri-containerd-ba8e154923fb44a62d0e9100f6841dbf9b780d7f31928146f57d1ad5c79adfea.scope"
      },
      {
        "cgroup-id": 9352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0142ebbe_8e29_49f1_b27e_719d8f9894f5.slice/cri-containerd-5edc675789ff9022c0c062211c81a9f8de35aef3a369ff80405dfc30ebac539b.scope"
      },
      {
        "cgroup-id": 9268,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0142ebbe_8e29_49f1_b27e_719d8f9894f5.slice/cri-containerd-e73582d95d980e6feb2c0fa40e7b9ac61feb42bd3a57aca56ceebc42348db872.scope"
      }
    ],
    "ips": [
      "10.89.0.142"
    ],
    "name": "clustermesh-apiserver-684848fc97-kmhbc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03f8221e_0520_4cd5_a5a0_46c1032e8668.slice/cri-containerd-5554e0fbd5202ee6f2d8f8fb03d0655220207d95c15ff5793bc57e76036dcb2b.scope"
      }
    ],
    "ips": [
      "10.89.0.222"
    ],
    "name": "coredns-cc6ccd49c-vjdwm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod299033cb_039e_45ea_80c8_e0cdf601fc5c.slice/cri-containerd-661e7e3fd7cd5b84ae34f85392225e550af7d6fcf61e1a45f030cf2a76790203.scope"
      }
    ],
    "ips": [
      "10.89.0.242"
    ],
    "name": "coredns-cc6ccd49c-qxd6b",
    "namespace": "kube-system"
  }
]

