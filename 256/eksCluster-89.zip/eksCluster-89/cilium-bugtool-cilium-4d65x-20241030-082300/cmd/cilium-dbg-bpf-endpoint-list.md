IP ADDRESS         LOCAL ENDPOINT INFO
172.31.220.127:0   (localhost)                                                                                        
10.89.0.222:0      id=811   sec_id=2966966 flags=0x0000 ifindex=14  mac=AA:5E:6D:5A:F2:3D nodemac=EA:03:D3:D4:F6:B1   
10.89.0.242:0      id=2851  sec_id=2966966 flags=0x0000 ifindex=12  mac=EE:13:A8:68:B3:EA nodemac=56:10:AD:23:0E:7B   
10.89.0.142:0      id=2146  sec_id=2949163 flags=0x0000 ifindex=18  mac=96:7B:B7:A5:B1:E2 nodemac=86:67:70:2C:26:A5   
172.31.225.122:0   (localhost)                                                                                        
10.89.0.164:0      (localhost)                                                                                        
10.89.0.159:0      id=1057  sec_id=4     flags=0x0000 ifindex=10  mac=02:14:23:BF:AD:59 nodemac=E2:7E:D0:AC:06:88     
