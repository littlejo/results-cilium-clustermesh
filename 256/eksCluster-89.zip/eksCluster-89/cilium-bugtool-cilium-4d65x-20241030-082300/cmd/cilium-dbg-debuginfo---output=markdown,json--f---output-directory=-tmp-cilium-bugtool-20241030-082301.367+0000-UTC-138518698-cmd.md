markdown output at /tmp/cilium-bugtool-20241030-082301.367+0000-UTC-138518698/cmd/cilium-debuginfo-20241030-082332.314+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082301.367+0000-UTC-138518698/cmd/cilium-debuginfo-20241030-082332.314+0000-UTC.json
