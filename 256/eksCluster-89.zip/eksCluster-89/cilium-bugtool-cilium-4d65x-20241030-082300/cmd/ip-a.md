1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:09:22:b0:58:cd brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.225.122/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3301sec preferred_lft 3301sec
    inet6 fe80::809:22ff:feb0:58cd/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:3a:d4:51:3d:b1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.220.127/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::83a:d4ff:fe51:3db1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:73:0f:31:d7:9b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1c73:fff:fe31:d79b/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:4e:da:db:00:cb brd ff:ff:ff:ff:ff:ff
    inet 10.89.0.164/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::44e:daff:fedb:cb/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether c2:5c:f7:32:c0:fb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c05c:f7ff:fe32:c0fb/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:7e:d0:ac:06:88 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::e07e:d0ff:feac:688/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf48418e9cc15@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:10:ad:23:0e:7b brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::5410:adff:fe23:e7b/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc20da6abf13a5@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:03:d3:d4:f6:b1 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e803:d3ff:fed4:f6b1/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc66c67d5d1e80@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:67:70:2c:26:a5 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::8467:70ff:fe2c:26a5/64 scope link 
       valid_lft forever preferred_lft forever
