CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod046d541b_f10c_4426_96c2_a7960c166ed1.slice/cri-containerd-5e97a1b15dccf9e7ad83c9b8ab7b2a5b3b1cd04c6cc00a8bd2860d7e35e09d75.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod046d541b_f10c_4426_96c2_a7960c166ed1.slice/cri-containerd-9d724967d0259f0d428ac7e07e72fc01c83f6d123f3fd63a4694dc58e4d088fa.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod299033cb_039e_45ea_80c8_e0cdf601fc5c.slice/cri-containerd-bcd72b841ba4ae46371ab12e655ab192b6f887042b4405cc94b272bf158e8c26.scope
    526      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod299033cb_039e_45ea_80c8_e0cdf601fc5c.slice/cri-containerd-661e7e3fd7cd5b84ae34f85392225e550af7d6fcf61e1a45f030cf2a76790203.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03f8221e_0520_4cd5_a5a0_46c1032e8668.slice/cri-containerd-5554e0fbd5202ee6f2d8f8fb03d0655220207d95c15ff5793bc57e76036dcb2b.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03f8221e_0520_4cd5_a5a0_46c1032e8668.slice/cri-containerd-2f84a94ef162ca1f579d56e3b433942c1d382a2fc40312edfdee26f726bcd2cf.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4777a765_172c_4750_b261_2d82f115a5fa.slice/cri-containerd-9c9889d9258f8ee7d4fe13d2581094a6f48238922b46597a789d6b5a397d018b.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4777a765_172c_4750_b261_2d82f115a5fa.slice/cri-containerd-4489a18580d4b6d1339babae02f43d9a311d435b969902770b29ebf60f1bd743.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd57a0c2_a4bc_4bb3_8a5c_b1474e3a1089.slice/cri-containerd-ea997bc5cbe163ddb76f30b34c450aefe7d080dfb0f1a2f4a3812cc60cd92885.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd57a0c2_a4bc_4bb3_8a5c_b1474e3a1089.slice/cri-containerd-aae4e1dcd0a6c0b0614d3f0a3f2188ad9453e86e2f4393535e31ed830ca726eb.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0142ebbe_8e29_49f1_b27e_719d8f9894f5.slice/cri-containerd-3f1cd22b109eb1c148320f32a2e303d4e3912f830f9fb14f49a6427807f63e9e.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0142ebbe_8e29_49f1_b27e_719d8f9894f5.slice/cri-containerd-5edc675789ff9022c0c062211c81a9f8de35aef3a369ff80405dfc30ebac539b.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0142ebbe_8e29_49f1_b27e_719d8f9894f5.slice/cri-containerd-e73582d95d980e6feb2c0fa40e7b9ac61feb42bd3a57aca56ceebc42348db872.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0142ebbe_8e29_49f1_b27e_719d8f9894f5.slice/cri-containerd-ba8e154923fb44a62d0e9100f6841dbf9b780d7f31928146f57d1ad5c79adfea.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda68516db_b19c_4e68_b519_1f97b67d0bac.slice/cri-containerd-a8489f1d0ab835d38a4efac47ffd1f186eaa9864158e8561c4e6f703e80ca408.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda68516db_b19c_4e68_b519_1f97b67d0bac.slice/cri-containerd-4ca7b8862dc85397b8d2a6d4a8dc266b81b0257b05495cb36eb1f98a4f7048c2.scope
    102      cgroup_device   multi                                          
