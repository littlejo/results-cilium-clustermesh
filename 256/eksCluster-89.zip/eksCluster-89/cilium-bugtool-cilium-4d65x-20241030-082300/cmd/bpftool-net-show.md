xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 576
ens6(5) clsact/ingress cil_from_netdev-ens6 id 577
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 565
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 557
cilium_host(7) clsact/egress cil_from_host-cilium_host id 556
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 482
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 535
lxcf48418e9cc15(12) clsact/ingress cil_from_container-lxcf48418e9cc15 id 545
lxc20da6abf13a5(14) clsact/ingress cil_from_container-lxc20da6abf13a5 id 508
lxc66c67d5d1e80(18) clsact/ingress cil_from_container-lxc66c67d5d1e80 id 630

flow_dissector:

netfilter:

