{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:15.878Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.220.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:15.878Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.225.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:15.878Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:20.287Z",
  "value": "id=1057  sec_id=4     flags=0x0000 ifindex=10  mac=02:14:23:BF:AD:59 nodemac=E2:7E:D0:AC:06:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:20.291Z",
  "value": "id=2851  sec_id=2966966 flags=0x0000 ifindex=12  mac=EE:13:A8:68:B3:EA nodemac=56:10:AD:23:0E:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:20.340Z",
  "value": "id=811   sec_id=2966966 flags=0x0000 ifindex=14  mac=AA:5E:6D:5A:F2:3D nodemac=EA:03:D3:D4:F6:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:20.476Z",
  "value": "id=1057  sec_id=4     flags=0x0000 ifindex=10  mac=02:14:23:BF:AD:59 nodemac=E2:7E:D0:AC:06:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:20.533Z",
  "value": "id=2851  sec_id=2966966 flags=0x0000 ifindex=12  mac=EE:13:A8:68:B3:EA nodemac=56:10:AD:23:0E:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:31.389Z",
  "value": "id=1057  sec_id=4     flags=0x0000 ifindex=10  mac=02:14:23:BF:AD:59 nodemac=E2:7E:D0:AC:06:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:31.389Z",
  "value": "id=2851  sec_id=2966966 flags=0x0000 ifindex=12  mac=EE:13:A8:68:B3:EA nodemac=56:10:AD:23:0E:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:31.389Z",
  "value": "id=811   sec_id=2966966 flags=0x0000 ifindex=14  mac=AA:5E:6D:5A:F2:3D nodemac=EA:03:D3:D4:F6:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:31.421Z",
  "value": "id=471   sec_id=2949163 flags=0x0000 ifindex=16  mac=D2:94:82:BD:43:C7 nodemac=B6:33:8E:5E:2B:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:32.389Z",
  "value": "id=471   sec_id=2949163 flags=0x0000 ifindex=16  mac=D2:94:82:BD:43:C7 nodemac=B6:33:8E:5E:2B:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:32.389Z",
  "value": "id=811   sec_id=2966966 flags=0x0000 ifindex=14  mac=AA:5E:6D:5A:F2:3D nodemac=EA:03:D3:D4:F6:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:32.389Z",
  "value": "id=2851  sec_id=2966966 flags=0x0000 ifindex=12  mac=EE:13:A8:68:B3:EA nodemac=56:10:AD:23:0E:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:32.390Z",
  "value": "id=1057  sec_id=4     flags=0x0000 ifindex=10  mac=02:14:23:BF:AD:59 nodemac=E2:7E:D0:AC:06:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.540Z",
  "value": "id=2146  sec_id=2949163 flags=0x0000 ifindex=18  mac=96:7B:B7:A5:B1:E2 nodemac=86:67:70:2C:26:A5"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.89.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:21.093Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.634Z",
  "value": "id=1057  sec_id=4     flags=0x0000 ifindex=10  mac=02:14:23:BF:AD:59 nodemac=E2:7E:D0:AC:06:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.634Z",
  "value": "id=2851  sec_id=2966966 flags=0x0000 ifindex=12  mac=EE:13:A8:68:B3:EA nodemac=56:10:AD:23:0E:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.635Z",
  "value": "id=811   sec_id=2966966 flags=0x0000 ifindex=14  mac=AA:5E:6D:5A:F2:3D nodemac=EA:03:D3:D4:F6:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.670Z",
  "value": "id=2146  sec_id=2949163 flags=0x0000 ifindex=18  mac=96:7B:B7:A5:B1:E2 nodemac=86:67:70:2C:26:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:25.655Z",
  "value": "id=811   sec_id=2966966 flags=0x0000 ifindex=14  mac=AA:5E:6D:5A:F2:3D nodemac=EA:03:D3:D4:F6:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:25.669Z",
  "value": "id=2146  sec_id=2949163 flags=0x0000 ifindex=18  mac=96:7B:B7:A5:B1:E2 nodemac=86:67:70:2C:26:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:25.670Z",
  "value": "id=1057  sec_id=4     flags=0x0000 ifindex=10  mac=02:14:23:BF:AD:59 nodemac=E2:7E:D0:AC:06:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:25.670Z",
  "value": "id=2851  sec_id=2966966 flags=0x0000 ifindex=12  mac=EE:13:A8:68:B3:EA nodemac=56:10:AD:23:0E:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:26.649Z",
  "value": "id=1057  sec_id=4     flags=0x0000 ifindex=10  mac=02:14:23:BF:AD:59 nodemac=E2:7E:D0:AC:06:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:26.649Z",
  "value": "id=2851  sec_id=2966966 flags=0x0000 ifindex=12  mac=EE:13:A8:68:B3:EA nodemac=56:10:AD:23:0E:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:26.649Z",
  "value": "id=811   sec_id=2966966 flags=0x0000 ifindex=14  mac=AA:5E:6D:5A:F2:3D nodemac=EA:03:D3:D4:F6:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:26.649Z",
  "value": "id=2146  sec_id=2949163 flags=0x0000 ifindex=18  mac=96:7B:B7:A5:B1:E2 nodemac=86:67:70:2C:26:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:27.649Z",
  "value": "id=1057  sec_id=4     flags=0x0000 ifindex=10  mac=02:14:23:BF:AD:59 nodemac=E2:7E:D0:AC:06:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:27.649Z",
  "value": "id=2146  sec_id=2949163 flags=0x0000 ifindex=18  mac=96:7B:B7:A5:B1:E2 nodemac=86:67:70:2C:26:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:27.650Z",
  "value": "id=2851  sec_id=2966966 flags=0x0000 ifindex=12  mac=EE:13:A8:68:B3:EA nodemac=56:10:AD:23:0E:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:27.650Z",
  "value": "id=811   sec_id=2966966 flags=0x0000 ifindex=14  mac=AA:5E:6D:5A:F2:3D nodemac=EA:03:D3:D4:F6:B1"
}

