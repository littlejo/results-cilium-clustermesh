KEY             VALUE
AgentLiveness   2141436322600
UTimeOffset     3379442326171875
