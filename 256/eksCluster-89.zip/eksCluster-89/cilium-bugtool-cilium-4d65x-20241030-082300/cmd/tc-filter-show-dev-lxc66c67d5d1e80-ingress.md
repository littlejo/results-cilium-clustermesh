filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc66c67d5d1e80 direct-action not_in_hw id 630 tag 851e8411f2fd3784 jited 
