1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:7e:2b:06:c1:63 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.140.38/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3431sec preferred_lft 3431sec
    inet6 fe80::47e:2bff:fe06:c163/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:7d:c9:88:a2:51 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.177.95/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::47d:c9ff:fe88:a251/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:72:9d:cf:bb:35 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b472:9dff:fecf:bb35/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:fd:e8:91:5f:30 brd ff:ff:ff:ff:ff:ff
    inet 10.136.0.133/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::24fd:e8ff:fe91:5f30/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 7e:bd:8c:f9:3f:31 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7cbd:8cff:fef9:3f31/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:8f:e9:10:c1:76 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d48f:e9ff:fe10:c176/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc19e878e9903f@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:7c:36:0f:59:e9 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a47c:36ff:fe0f:59e9/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc9db76b3bc213@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:a0:ca:72:45:e8 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ca0:caff:fe72:45e8/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc6054c2486dd8@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:2e:85:34:85:81 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a42e:85ff:fe34:8581/64 scope link 
       valid_lft forever preferred_lft forever
