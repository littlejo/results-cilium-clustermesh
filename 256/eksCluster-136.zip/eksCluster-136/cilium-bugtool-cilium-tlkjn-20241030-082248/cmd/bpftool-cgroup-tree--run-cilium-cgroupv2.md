CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod65eadc7b_7779_4658_aa79_2edcdd8fee11.slice/cri-containerd-34d2766478dc8bf99bce24c164a67205f79bf895a8ea4dca88c0d7f4c44d0b81.scope
    537      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod65eadc7b_7779_4658_aa79_2edcdd8fee11.slice/cri-containerd-bcc80a151e61e0eb36da714ca21ba0249bcb52d6d1cc6d02bcacd7287c615cd6.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7fa373ad_f12d_470f_8213_e422c027c675.slice/cri-containerd-f2e52726f4d9516c1c84d47e1c6f4c46ed48051499c649cb8cb599ad5e2e516a.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7fa373ad_f12d_470f_8213_e422c027c675.slice/cri-containerd-fd24402da7d5d10915153f371f0adb3b0cf320cbd421faf6bcb16e87db9b9734.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd607d4cf_ae25_4481_8190_e7ce24f7b3d4.slice/cri-containerd-cab4ec1633e02a4d4ba745477b2178446df3d97bfbbba8c08725ca46f1a8aadc.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd607d4cf_ae25_4481_8190_e7ce24f7b3d4.slice/cri-containerd-c64c97a6b308fa693b67c71d72129a9ad740b8e6124cc318e32d42855a03801e.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod34ff2234_ea07_4969_be8a_4a1976f198d6.slice/cri-containerd-6cd7ba73647579bfa2fab6c294eccbd2226e1e09b775483d85b1d37c236f9c42.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod34ff2234_ea07_4969_be8a_4a1976f198d6.slice/cri-containerd-f6fe0c37b898258161b351023378d0453c9b21c308a7be987780850daad43c34.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83b8b52b_b5fb_40cb_ae1f_d39236aae3d0.slice/cri-containerd-3955c9fbf1d145e047ea777f0966a9623efe7048565636eac143a6106b994cf0.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83b8b52b_b5fb_40cb_ae1f_d39236aae3d0.slice/cri-containerd-6a53847a3c3fca248d2f259b5dbbbff6e0cf191a6956ca548cd596344d1f2d30.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda0366584_60db_48cc_96ea_522407fc9fc4.slice/cri-containerd-a6dcccce4b4b9e88399213443063e1967b54957fb3768622176b7cd8bc131db7.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda0366584_60db_48cc_96ea_522407fc9fc4.slice/cri-containerd-8a339fa0ae0300b04570eeadc8aab8e59f7fe24d3fc06716e16b5b859dbf02f3.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda0366584_60db_48cc_96ea_522407fc9fc4.slice/cri-containerd-0ec3d6253f0c4d224789f1f2f1c05e0ef3e7e06ff0ed61fe57bbb6c60c5cfbf0.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda0366584_60db_48cc_96ea_522407fc9fc4.slice/cri-containerd-38e5c6d93fc32e8967cb542b8fe0e08601471c337f01ba2b0941d46d87258953.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbc1db90d_293e_487f_a92a_0845e7fae600.slice/cri-containerd-4f6e17c9d559e859a69a5c9bee8308dc928209e9d98490a6097f0ae053f56f6e.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbc1db90d_293e_487f_a92a_0845e7fae600.slice/cri-containerd-06fe02f1dfd9a27418845bf5ac290c6ede22bdc0754f15e014a3556c0b8301c0.scope
    105      cgroup_device   multi                                          
