alloc: 175.04MB (183543240 bytes)
total-alloc: 2.22GB (2387860784 bytes)
sys: 324.83MB (340611428 bytes)
lookups: 0
mallocs: 63019451
frees: 61316276
heap-alloc: 175.04MB (183543240 bytes)
heap-sys: 247.36MB (259375104 bytes)
heap-idle: 50.14MB (52576256 bytes)
heap-in-use: 197.22MB (206798848 bytes)
heap-released: 3.53MB (3702784 bytes)
heap-objects: 1703175
stack-in-use: 64.59MB (67731456 bytes)
stack-sys: 64.59MB (67731456 bytes)
stack-mspan-inuse: 3.07MB (3217600 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1057385 bytes)
gc-sys: 6.09MB (6383080 bytes)
next-gc: when heap-alloc >= 212.04MB (222344920 bytes)
last-gc: 2024-10-30 08:22:58.760125677 +0000 UTC
gc-pause-total: 15.860088ms
gc-pause: 115128
gc-pause-end: 1730276578760125677
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0004231142218529873
enable-gc: true
debug-gc: false
