Total: 681
TCP:   1847 (estab 431, closed 1397, orphaned 0, timewait 558)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  450       439       11       
INET	  460       445       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:34661      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:36327 sk:3e6 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.140.38%ens5:68         0.0.0.0:*    uid:192 ino:73671 sk:3e7 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:35694 sk:3e8 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15179 sk:3e9 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:35693 sk:3ea cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15180 sk:3eb cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::47e:2bff:fe06:c163]%ens5:546           [::]:*    uid:192 ino:15665 sk:3ec cgroup:unreachable:c4e v6only:1 <->                   
