key: 2c 01 00 00  value: 05 02 00 00
key: 76 03 00 00  value: 0e 02 00 00
key: 86 05 00 00  value: 23 02 00 00
key: 77 09 00 00  value: 79 02 00 00
Found 4 elements
