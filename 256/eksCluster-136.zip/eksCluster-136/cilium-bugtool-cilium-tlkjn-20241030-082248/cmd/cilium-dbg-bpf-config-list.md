KEY             VALUE
AgentLiveness   2010315181943
UTimeOffset     3379442558593750
