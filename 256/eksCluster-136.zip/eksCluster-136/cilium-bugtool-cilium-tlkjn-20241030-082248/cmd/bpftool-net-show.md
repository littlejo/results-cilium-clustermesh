xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 578
ens6(5) clsact/ingress cil_from_netdev-ens6 id 583
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 569
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 564
cilium_host(7) clsact/egress cil_from_host-cilium_host id 563
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 524
lxc19e878e9903f(12) clsact/ingress cil_from_container-lxc19e878e9903f id 548
lxc9db76b3bc213(14) clsact/ingress cil_from_container-lxc9db76b3bc213 id 510
lxc6054c2486dd8(18) clsact/ingress cil_from_container-lxc6054c2486dd8 id 629

flow_dissector:

netfilter:

