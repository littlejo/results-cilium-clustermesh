markdown output at /tmp/cilium-bugtool-20241030-082248.969+0000-UTC-1175479004/cmd/cilium-debuginfo-20241030-082320.114+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082248.969+0000-UTC-1175479004/cmd/cilium-debuginfo-20241030-082320.114+0000-UTC.json
