ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.197.57:443 (active)    
                                        2 => 172.31.186.222:443 (active)   
2    10.100.82.160:443   ClusterIP      1 => 172.31.140.38:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.136.0.169:53 (active)      
                                        2 => 10.136.0.83:53 (active)       
4    10.100.0.10:9153    ClusterIP      1 => 10.136.0.169:9153 (active)    
                                        2 => 10.136.0.83:9153 (active)     
5    10.100.5.60:2379    ClusterIP      1 => 10.136.0.228:2379 (active)    
