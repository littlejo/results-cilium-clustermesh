IP ADDRESS        LOCAL ENDPOINT INFO
172.31.177.95:0   (localhost)                                                                                        
10.136.0.228:0    id=2423  sec_id=4503876 flags=0x0000 ifindex=18  mac=56:8F:80:60:A1:F8 nodemac=A6:2E:85:34:85:81   
10.136.0.83:0     id=300   sec_id=4501867 flags=0x0000 ifindex=14  mac=D6:DE:0F:D4:4F:43 nodemac=0E:A0:CA:72:45:E8   
10.136.0.169:0    id=1414  sec_id=4501867 flags=0x0000 ifindex=12  mac=EA:96:C6:DD:8F:E7 nodemac=A6:7C:36:0F:59:E9   
10.136.0.133:0    (localhost)                                                                                        
172.31.140.38:0   (localhost)                                                                                        
10.136.0.194:0    id=886   sec_id=4     flags=0x0000 ifindex=10  mac=C2:61:92:36:49:F7 nodemac=D6:8F:E9:10:C1:76     
