{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:57.744Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.140.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:57.744Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.177.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:57.744Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:02.560Z",
  "value": "id=886   sec_id=4     flags=0x0000 ifindex=10  mac=C2:61:92:36:49:F7 nodemac=D6:8F:E9:10:C1:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:02.579Z",
  "value": "id=1414  sec_id=4501867 flags=0x0000 ifindex=12  mac=EA:96:C6:DD:8F:E7 nodemac=A6:7C:36:0F:59:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:02.622Z",
  "value": "id=300   sec_id=4501867 flags=0x0000 ifindex=14  mac=D6:DE:0F:D4:4F:43 nodemac=0E:A0:CA:72:45:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:02.690Z",
  "value": "id=886   sec_id=4     flags=0x0000 ifindex=10  mac=C2:61:92:36:49:F7 nodemac=D6:8F:E9:10:C1:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:02.749Z",
  "value": "id=1414  sec_id=4501867 flags=0x0000 ifindex=12  mac=EA:96:C6:DD:8F:E7 nodemac=A6:7C:36:0F:59:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:26.295Z",
  "value": "id=886   sec_id=4     flags=0x0000 ifindex=10  mac=C2:61:92:36:49:F7 nodemac=D6:8F:E9:10:C1:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:26.295Z",
  "value": "id=300   sec_id=4501867 flags=0x0000 ifindex=14  mac=D6:DE:0F:D4:4F:43 nodemac=0E:A0:CA:72:45:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:26.295Z",
  "value": "id=1414  sec_id=4501867 flags=0x0000 ifindex=12  mac=EA:96:C6:DD:8F:E7 nodemac=A6:7C:36:0F:59:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:26.326Z",
  "value": "id=2526  sec_id=4503876 flags=0x0000 ifindex=16  mac=C2:54:4E:BB:27:F6 nodemac=9E:D7:72:94:C1:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:26.326Z",
  "value": "id=2526  sec_id=4503876 flags=0x0000 ifindex=16  mac=C2:54:4E:BB:27:F6 nodemac=9E:D7:72:94:C1:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:27.295Z",
  "value": "id=886   sec_id=4     flags=0x0000 ifindex=10  mac=C2:61:92:36:49:F7 nodemac=D6:8F:E9:10:C1:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:27.296Z",
  "value": "id=2526  sec_id=4503876 flags=0x0000 ifindex=16  mac=C2:54:4E:BB:27:F6 nodemac=9E:D7:72:94:C1:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:27.296Z",
  "value": "id=1414  sec_id=4501867 flags=0x0000 ifindex=12  mac=EA:96:C6:DD:8F:E7 nodemac=A6:7C:36:0F:59:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:27.296Z",
  "value": "id=300   sec_id=4501867 flags=0x0000 ifindex=14  mac=D6:DE:0F:D4:4F:43 nodemac=0E:A0:CA:72:45:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.615Z",
  "value": "id=2423  sec_id=4503876 flags=0x0000 ifindex=18  mac=56:8F:80:60:A1:F8 nodemac=A6:2E:85:34:85:81"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.136.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.084Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.333Z",
  "value": "id=300   sec_id=4501867 flags=0x0000 ifindex=14  mac=D6:DE:0F:D4:4F:43 nodemac=0E:A0:CA:72:45:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.334Z",
  "value": "id=2423  sec_id=4503876 flags=0x0000 ifindex=18  mac=56:8F:80:60:A1:F8 nodemac=A6:2E:85:34:85:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.334Z",
  "value": "id=886   sec_id=4     flags=0x0000 ifindex=10  mac=C2:61:92:36:49:F7 nodemac=D6:8F:E9:10:C1:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.335Z",
  "value": "id=1414  sec_id=4501867 flags=0x0000 ifindex=12  mac=EA:96:C6:DD:8F:E7 nodemac=A6:7C:36:0F:59:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.293Z",
  "value": "id=886   sec_id=4     flags=0x0000 ifindex=10  mac=C2:61:92:36:49:F7 nodemac=D6:8F:E9:10:C1:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.293Z",
  "value": "id=1414  sec_id=4501867 flags=0x0000 ifindex=12  mac=EA:96:C6:DD:8F:E7 nodemac=A6:7C:36:0F:59:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.293Z",
  "value": "id=300   sec_id=4501867 flags=0x0000 ifindex=14  mac=D6:DE:0F:D4:4F:43 nodemac=0E:A0:CA:72:45:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.294Z",
  "value": "id=2423  sec_id=4503876 flags=0x0000 ifindex=18  mac=56:8F:80:60:A1:F8 nodemac=A6:2E:85:34:85:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.293Z",
  "value": "id=2423  sec_id=4503876 flags=0x0000 ifindex=18  mac=56:8F:80:60:A1:F8 nodemac=A6:2E:85:34:85:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.294Z",
  "value": "id=886   sec_id=4     flags=0x0000 ifindex=10  mac=C2:61:92:36:49:F7 nodemac=D6:8F:E9:10:C1:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.294Z",
  "value": "id=1414  sec_id=4501867 flags=0x0000 ifindex=12  mac=EA:96:C6:DD:8F:E7 nodemac=A6:7C:36:0F:59:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.295Z",
  "value": "id=300   sec_id=4501867 flags=0x0000 ifindex=14  mac=D6:DE:0F:D4:4F:43 nodemac=0E:A0:CA:72:45:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:07.293Z",
  "value": "id=2423  sec_id=4503876 flags=0x0000 ifindex=18  mac=56:8F:80:60:A1:F8 nodemac=A6:2E:85:34:85:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:07.294Z",
  "value": "id=886   sec_id=4     flags=0x0000 ifindex=10  mac=C2:61:92:36:49:F7 nodemac=D6:8F:E9:10:C1:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:07.294Z",
  "value": "id=1414  sec_id=4501867 flags=0x0000 ifindex=12  mac=EA:96:C6:DD:8F:E7 nodemac=A6:7C:36:0F:59:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.136.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:07.294Z",
  "value": "id=300   sec_id=4501867 flags=0x0000 ifindex=14  mac=D6:DE:0F:D4:4F:43 nodemac=0E:A0:CA:72:45:E8"
}

