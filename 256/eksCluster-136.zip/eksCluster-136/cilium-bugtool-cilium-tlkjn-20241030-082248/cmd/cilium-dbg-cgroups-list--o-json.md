[
  {
    "containers": [
      {
        "cgroup-id": 9268,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda0366584_60db_48cc_96ea_522407fc9fc4.slice/cri-containerd-8a339fa0ae0300b04570eeadc8aab8e59f7fe24d3fc06716e16b5b859dbf02f3.scope"
      },
      {
        "cgroup-id": 9184,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda0366584_60db_48cc_96ea_522407fc9fc4.slice/cri-containerd-a6dcccce4b4b9e88399213443063e1967b54957fb3768622176b7cd8bc131db7.scope"
      },
      {
        "cgroup-id": 9352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda0366584_60db_48cc_96ea_522407fc9fc4.slice/cri-containerd-38e5c6d93fc32e8967cb542b8fe0e08601471c337f01ba2b0941d46d87258953.scope"
      }
    ],
    "ips": [
      "10.136.0.228"
    ],
    "name": "clustermesh-apiserver-6f99ff8bc-nv27z",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod34ff2234_ea07_4969_be8a_4a1976f198d6.slice/cri-containerd-6cd7ba73647579bfa2fab6c294eccbd2226e1e09b775483d85b1d37c236f9c42.scope"
      }
    ],
    "ips": [
      "10.136.0.83"
    ],
    "name": "coredns-cc6ccd49c-dsdbl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod65eadc7b_7779_4658_aa79_2edcdd8fee11.slice/cri-containerd-bcc80a151e61e0eb36da714ca21ba0249bcb52d6d1cc6d02bcacd7287c615cd6.scope"
      }
    ],
    "ips": [
      "10.136.0.169"
    ],
    "name": "coredns-cc6ccd49c-x2w4k",
    "namespace": "kube-system"
  }
]

