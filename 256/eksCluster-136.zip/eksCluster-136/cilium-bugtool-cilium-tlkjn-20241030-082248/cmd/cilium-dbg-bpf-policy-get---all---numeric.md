Endpoint ID: 300
Path: /sys/fs/bpf/tc/globals/cilium_policy_00300

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    133751   1537      0        
Allow    Egress      0          ANY          NONE         disabled    17184    186       0        


Endpoint ID: 886
Path: /sys/fs/bpf/tc/globals/cilium_policy_00886

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1644912   20771     0        
Allow    Ingress     1          ANY          NONE         disabled    20390     238       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1414
Path: /sys/fs/bpf/tc/globals/cilium_policy_01414

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    133762   1533      0        
Allow    Egress      0          ANY          NONE         disabled    18160    199       0        


Endpoint ID: 2423
Path: /sys/fs/bpf/tc/globals/cilium_policy_02423

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11433771   113246    0        
Allow    Ingress     1          ANY          NONE         disabled    9696123    101649    0        
Allow    Egress      0          ANY          NONE         disabled    12382988   122077    0        


Endpoint ID: 2467
Path: /sys/fs/bpf/tc/globals/cilium_policy_02467

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


