CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9dc5ea09_f328_4c23_b34f_dbde1c701636.slice/cri-containerd-3f392635632ae5d7c6bec2665a7c2a9413bc2f0077cc4134f34625932fe9ebde.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9dc5ea09_f328_4c23_b34f_dbde1c701636.slice/cri-containerd-555bbe9c4a5f6a4638c93126db36f85f14ea980274f1ba74d6257ee7843bd2f6.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcb41ecb6_8ca3_4221_856f_4e082a4a4a8f.slice/cri-containerd-b92942713b48ac75b99b8523bbb0be0cb782bdbaddebf29bbd7a7f2e2bef63cc.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcb41ecb6_8ca3_4221_856f_4e082a4a4a8f.slice/cri-containerd-e2c9a5a929b59568f2ce8f605b63826944f1139c92a6a0500cdd332ff477e5ad.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e51f532_efbb_49e9_a682_4cd25f1e9672.slice/cri-containerd-2bac8b0989ae19f4782a20967dd64884b81d87306028cae9e5ccc132f40dc796.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e51f532_efbb_49e9_a682_4cd25f1e9672.slice/cri-containerd-7e3d6d750abc17ea5bb7ac63fd69eca379d966e61b4b19292772b0c5c87aaf06.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8523e6ef_4105_4fe7_b536_562605850da6.slice/cri-containerd-bd9c46720d829c10b974f26ca49c1645303772a4783a2a00e37f786973b27e25.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8523e6ef_4105_4fe7_b536_562605850da6.slice/cri-containerd-ece0d667da887ee2677cadc4e45953b457242ab125f46b9fa3bd0b3fa0b57d14.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod27f1091c_f570_4618_9ad5_9150e68cca8d.slice/cri-containerd-8374927828a19c373fb148a7211639c9cb694a9ee6891a0153f96123076ad817.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod27f1091c_f570_4618_9ad5_9150e68cca8d.slice/cri-containerd-dc2930dd2f71df03f7b97f7ff9b38157cb26f839f09d690298dca76388fb4ec7.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9d23f9af_f094_48c1_8773_fdfa23b3ad52.slice/cri-containerd-0c93f25657dd9727885b88243a0f653026ec8e62beb0556fd315760c93184684.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9d23f9af_f094_48c1_8773_fdfa23b3ad52.slice/cri-containerd-f1924b2dc98d954b6b6b24179662dab40c69e4cf18df92bd26698a23179be286.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3589aa5_76b6_461f_81f9_c3815dbd47ab.slice/cri-containerd-64cbd3702ec83d241ed357672edd2877b3a2acb6de9f416c1bdf9bfe4c7eefb0.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3589aa5_76b6_461f_81f9_c3815dbd47ab.slice/cri-containerd-1b12b6add11900c8dd5b5399c94fbd2f656077c5e467f2c90a164c1a0a78c190.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3589aa5_76b6_461f_81f9_c3815dbd47ab.slice/cri-containerd-32c00253e06ef29ae102bf74493fad6b66e2235b8f3c5fca3f8789673e106e92.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3589aa5_76b6_461f_81f9_c3815dbd47ab.slice/cri-containerd-6f74ff0959a613f204193ab946116117d0546e5159b7bd7b77eb46729c971200.scope
    650      cgroup_device   multi                                          
