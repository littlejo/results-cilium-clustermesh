key: 06 00 00 00  value: 0a bf 00 4c 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a bf 00 98 09 4b 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f e9 6c 10 94 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f bc 57 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: 0a bf 00 4c 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a bf 00 a4 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f c1 0c 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a bf 00 a4 00 35 00 00  00 00 00 00
Found 8 elements
