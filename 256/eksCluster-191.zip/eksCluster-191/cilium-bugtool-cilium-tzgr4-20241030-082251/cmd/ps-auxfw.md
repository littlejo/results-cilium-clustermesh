USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         680  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         668  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         660  0.0  0.2 1240432 16052 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         707  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         708  0.0  0.0   2144   248 ?        R    08:22   0:00  \_ cat /proc/net/xfrm_stat
root         651  0.0  0.0   2208   792 ?        Ss   08:22   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         656 10.0  0.2 1244340 21588 ?       Sl   08:22   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root         641  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         627  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         621  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root           1  3.6  4.7 1606080 378844 ?      Ssl  08:01   0:45 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.1 1229744 8184 ?        Sl   08:02   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
