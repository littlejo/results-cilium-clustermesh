KEY             VALUE
AgentLiveness   1902844943006
UTimeOffset     3379442783203125
