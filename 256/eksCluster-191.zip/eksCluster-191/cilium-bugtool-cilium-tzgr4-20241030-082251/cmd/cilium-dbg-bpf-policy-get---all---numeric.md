Endpoint ID: 428
Path: /sys/fs/bpf/tc/globals/cilium_policy_00428

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    121150   1385      0        
Allow    Egress      0          ANY          NONE         disabled    17648    192       0        


Endpoint ID: 1250
Path: /sys/fs/bpf/tc/globals/cilium_policy_01250

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1322
Path: /sys/fs/bpf/tc/globals/cilium_policy_01322

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1669940   21089     0        
Allow    Ingress     1          ANY          NONE         disabled    19358     228       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1447
Path: /sys/fs/bpf/tc/globals/cilium_policy_01447

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11642284   117222    0        
Allow    Ingress     1          ANY          NONE         disabled    10597786   111883    0        
Allow    Egress      0          ANY          NONE         disabled    14546455   142170    0        


Endpoint ID: 3389
Path: /sys/fs/bpf/tc/globals/cilium_policy_03389

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    121889   1400      0        
Allow    Egress      0          ANY          NONE         disabled    17598    192       0        


