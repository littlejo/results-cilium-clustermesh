REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38107     3021838     677    bpf_overlay.c
Interface                 INGRESS     671652    135600968   1132   bpf_host.c
Success                   EGRESS      17704     1398769     1694   bpf_host.c
Success                   EGRESS      284910    35165872    1308   bpf_lxc.c
Success                   EGRESS      39037     3088251     53     encap.h
Success                   INGRESS     326842    37116791    86     l3.h
Success                   INGRESS     347896    38783906    235    trace.h
Unsupported L3 protocol   EGRESS      41        3062        1492   bpf_lxc.c
