Total: 699
TCP:   1884 (estab 462, closed 1403, orphaned 0, timewait 566)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  481       458       23       
INET	  491       464       27       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.233.108%ens5:68         0.0.0.0:*    uid:192 ino:78383 sk:41a cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:36101 sk:41b cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:14228 sk:41c cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:37231      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:37132 sk:41d fwmark:0xb00 cgroup:/ <->
UNCONN 0      0      [fe80::8d6:f8ff:fe97:3c83]%ens5:546           [::]:*    uid:192 ino:16483 sk:41e cgroup:unreachable:c4e v6only:1 <->                   
UNCONN 0      0                                 [::]:8472          [::]:*    ino:36100 sk:41f cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:14229 sk:420 cgroup:unreachable:f0c v6only:1 <->                           
