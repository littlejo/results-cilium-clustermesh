alloc: 159.31MB (167044400 bytes)
total-alloc: 2.31GB (2482765984 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 64591308
frees: 63213479
heap-alloc: 159.31MB (167044400 bytes)
heap-sys: 251.17MB (263372800 bytes)
heap-idle: 58.43MB (61267968 bytes)
heap-in-use: 192.74MB (202104832 bytes)
heap-released: 6.89MB (7225344 bytes)
heap-objects: 1377829
stack-in-use: 64.78MB (67928064 bytes)
stack-sys: 64.78MB (67928064 bytes)
stack-mspan-inuse: 2.99MB (3139520 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1018.72KB (1043169 bytes)
gc-sys: 6.01MB (6301112 bytes)
next-gc: when heap-alloc >= 215.47MB (225939704 bytes)
last-gc: 2024-10-30 08:23:06.729414645 +0000 UTC
gc-pause-total: 17.050999ms
gc-pause: 210881
gc-pause-end: 1730276586729414645
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0005200962672439545
enable-gc: true
debug-gc: false
