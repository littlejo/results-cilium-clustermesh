IP ADDRESS         LOCAL ENDPOINT INFO
10.191.0.239:0     (localhost)                                                                                        
10.191.0.164:0     id=428   sec_id=6307970 flags=0x0000 ifindex=14  mac=82:19:6C:29:0B:4D nodemac=A6:EF:EE:4B:8D:5D   
10.191.0.152:0     id=1447  sec_id=6293326 flags=0x0000 ifindex=18  mac=16:91:7E:95:21:6E nodemac=AE:D5:35:61:47:2C   
10.191.0.76:0      id=3389  sec_id=6307970 flags=0x0000 ifindex=12  mac=1A:24:3F:E3:36:63 nodemac=66:7F:13:47:62:42   
172.31.233.108:0   (localhost)                                                                                        
10.191.0.121:0     id=1322  sec_id=4     flags=0x0000 ifindex=10  mac=22:38:53:95:75:B7 nodemac=56:D7:32:89:D4:64     
172.31.245.159:0   (localhost)                                                                                        
