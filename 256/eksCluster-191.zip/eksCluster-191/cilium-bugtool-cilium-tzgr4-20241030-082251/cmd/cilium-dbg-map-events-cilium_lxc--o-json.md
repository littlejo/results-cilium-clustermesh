{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:04.287Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.233.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:04.287Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.245.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:04.287Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:08.763Z",
  "value": "id=3389  sec_id=6307970 flags=0x0000 ifindex=12  mac=1A:24:3F:E3:36:63 nodemac=66:7F:13:47:62:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:08.774Z",
  "value": "id=1322  sec_id=4     flags=0x0000 ifindex=10  mac=22:38:53:95:75:B7 nodemac=56:D7:32:89:D4:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:08.776Z",
  "value": "id=3389  sec_id=6307970 flags=0x0000 ifindex=12  mac=1A:24:3F:E3:36:63 nodemac=66:7F:13:47:62:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:08.819Z",
  "value": "id=1322  sec_id=4     flags=0x0000 ifindex=10  mac=22:38:53:95:75:B7 nodemac=56:D7:32:89:D4:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:08.831Z",
  "value": "id=428   sec_id=6307970 flags=0x0000 ifindex=14  mac=82:19:6C:29:0B:4D nodemac=A6:EF:EE:4B:8D:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:06.136Z",
  "value": "id=1322  sec_id=4     flags=0x0000 ifindex=10  mac=22:38:53:95:75:B7 nodemac=56:D7:32:89:D4:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:06.136Z",
  "value": "id=428   sec_id=6307970 flags=0x0000 ifindex=14  mac=82:19:6C:29:0B:4D nodemac=A6:EF:EE:4B:8D:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:06.137Z",
  "value": "id=3389  sec_id=6307970 flags=0x0000 ifindex=12  mac=1A:24:3F:E3:36:63 nodemac=66:7F:13:47:62:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:06.172Z",
  "value": "id=4092  sec_id=6293326 flags=0x0000 ifindex=16  mac=92:E6:CD:F0:AA:22 nodemac=7E:08:48:8F:8C:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:07.137Z",
  "value": "id=428   sec_id=6307970 flags=0x0000 ifindex=14  mac=82:19:6C:29:0B:4D nodemac=A6:EF:EE:4B:8D:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:07.137Z",
  "value": "id=3389  sec_id=6307970 flags=0x0000 ifindex=12  mac=1A:24:3F:E3:36:63 nodemac=66:7F:13:47:62:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:07.138Z",
  "value": "id=1322  sec_id=4     flags=0x0000 ifindex=10  mac=22:38:53:95:75:B7 nodemac=56:D7:32:89:D4:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:07.138Z",
  "value": "id=4092  sec_id=6293326 flags=0x0000 ifindex=16  mac=92:E6:CD:F0:AA:22 nodemac=7E:08:48:8F:8C:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.004Z",
  "value": "id=1447  sec_id=6293326 flags=0x0000 ifindex=18  mac=16:91:7E:95:21:6E nodemac=AE:D5:35:61:47:2C"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.191.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.221Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.979Z",
  "value": "id=1447  sec_id=6293326 flags=0x0000 ifindex=18  mac=16:91:7E:95:21:6E nodemac=AE:D5:35:61:47:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.980Z",
  "value": "id=3389  sec_id=6307970 flags=0x0000 ifindex=12  mac=1A:24:3F:E3:36:63 nodemac=66:7F:13:47:62:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.981Z",
  "value": "id=1322  sec_id=4     flags=0x0000 ifindex=10  mac=22:38:53:95:75:B7 nodemac=56:D7:32:89:D4:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.981Z",
  "value": "id=428   sec_id=6307970 flags=0x0000 ifindex=14  mac=82:19:6C:29:0B:4D nodemac=A6:EF:EE:4B:8D:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.959Z",
  "value": "id=1447  sec_id=6293326 flags=0x0000 ifindex=18  mac=16:91:7E:95:21:6E nodemac=AE:D5:35:61:47:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.960Z",
  "value": "id=1322  sec_id=4     flags=0x0000 ifindex=10  mac=22:38:53:95:75:B7 nodemac=56:D7:32:89:D4:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.960Z",
  "value": "id=3389  sec_id=6307970 flags=0x0000 ifindex=12  mac=1A:24:3F:E3:36:63 nodemac=66:7F:13:47:62:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.960Z",
  "value": "id=428   sec_id=6307970 flags=0x0000 ifindex=14  mac=82:19:6C:29:0B:4D nodemac=A6:EF:EE:4B:8D:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.959Z",
  "value": "id=1447  sec_id=6293326 flags=0x0000 ifindex=18  mac=16:91:7E:95:21:6E nodemac=AE:D5:35:61:47:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.959Z",
  "value": "id=3389  sec_id=6307970 flags=0x0000 ifindex=12  mac=1A:24:3F:E3:36:63 nodemac=66:7F:13:47:62:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.959Z",
  "value": "id=1322  sec_id=4     flags=0x0000 ifindex=10  mac=22:38:53:95:75:B7 nodemac=56:D7:32:89:D4:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.960Z",
  "value": "id=428   sec_id=6307970 flags=0x0000 ifindex=14  mac=82:19:6C:29:0B:4D nodemac=A6:EF:EE:4B:8D:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.959Z",
  "value": "id=1322  sec_id=4     flags=0x0000 ifindex=10  mac=22:38:53:95:75:B7 nodemac=56:D7:32:89:D4:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.959Z",
  "value": "id=1447  sec_id=6293326 flags=0x0000 ifindex=18  mac=16:91:7E:95:21:6E nodemac=AE:D5:35:61:47:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.959Z",
  "value": "id=3389  sec_id=6307970 flags=0x0000 ifindex=12  mac=1A:24:3F:E3:36:63 nodemac=66:7F:13:47:62:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.191.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.960Z",
  "value": "id=428   sec_id=6307970 flags=0x0000 ifindex=14  mac=82:19:6C:29:0B:4D nodemac=A6:EF:EE:4B:8D:5D"
}

