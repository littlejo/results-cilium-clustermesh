1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:d6:f8:97:3c:83 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.233.108/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3540sec preferred_lft 3540sec
    inet6 fe80::8d6:f8ff:fe97:3c83/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:6f:a1:12:24:e3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.245.159/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::86f:a1ff:fe12:24e3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:6c:bb:7d:4f:cb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::346c:bbff:fe7d:4fcb/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:7d:26:90:ca:31 brd ff:ff:ff:ff:ff:ff
    inet 10.191.0.239/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::707d:26ff:fe90:ca31/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether e6:0b:cf:96:67:19 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e40b:cfff:fe96:6719/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:d7:32:89:d4:64 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::54d7:32ff:fe89:d464/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc7145ff3b9786@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:7f:13:47:62:42 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::647f:13ff:fe47:6242/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc754445cd1caf@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:ef:ee:4b:8d:5d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a4ef:eeff:fe4b:8d5d/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc2fda763fec44@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:d5:35:61:47:2c brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::acd5:35ff:fe61:472c/64 scope link 
       valid_lft forever preferred_lft forever
