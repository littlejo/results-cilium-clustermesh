ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.188.87:443 (active)     
                                         2 => 172.31.193.12:443 (active)     
2    10.100.250.171:443   ClusterIP      1 => 172.31.233.108:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.191.0.76:53 (active)        
                                         2 => 10.191.0.164:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.191.0.76:9153 (active)      
                                         2 => 10.191.0.164:9153 (active)     
5    10.100.170.26:2379   ClusterIP      1 => 10.191.0.152:2379 (active)     
