markdown output at /tmp/cilium-bugtool-20241030-082257.489+0000-UTC-2527947579/cmd/cilium-debuginfo-20241030-082328.267+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082257.489+0000-UTC-2527947579/cmd/cilium-debuginfo-20241030-082328.267+0000-UTC.json
