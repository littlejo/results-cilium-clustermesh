[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3589aa5_76b6_461f_81f9_c3815dbd47ab.slice/cri-containerd-64cbd3702ec83d241ed357672edd2877b3a2acb6de9f416c1bdf9bfe4c7eefb0.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3589aa5_76b6_461f_81f9_c3815dbd47ab.slice/cri-containerd-1b12b6add11900c8dd5b5399c94fbd2f656077c5e467f2c90a164c1a0a78c190.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3589aa5_76b6_461f_81f9_c3815dbd47ab.slice/cri-containerd-6f74ff0959a613f204193ab946116117d0546e5159b7bd7b77eb46729c971200.scope"
      }
    ],
    "ips": [
      "10.191.0.152"
    ],
    "name": "clustermesh-apiserver-86888db65c-9dkcg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e51f532_efbb_49e9_a682_4cd25f1e9672.slice/cri-containerd-2bac8b0989ae19f4782a20967dd64884b81d87306028cae9e5ccc132f40dc796.scope"
      }
    ],
    "ips": [
      "10.191.0.164"
    ],
    "name": "coredns-cc6ccd49c-sgwvs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8523e6ef_4105_4fe7_b536_562605850da6.slice/cri-containerd-bd9c46720d829c10b974f26ca49c1645303772a4783a2a00e37f786973b27e25.scope"
      }
    ],
    "ips": [
      "10.191.0.76"
    ],
    "name": "coredns-cc6ccd49c-fv9c5",
    "namespace": "kube-system"
  }
]

