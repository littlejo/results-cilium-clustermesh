Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal      0    269     71    104     37     18     19      8      6      5    858 
