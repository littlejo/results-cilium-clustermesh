Endpoint ID: 386
Path: /sys/fs/bpf/tc/globals/cilium_policy_00386

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    114832   1318      0        
Allow    Egress      0          ANY          NONE         disabled    16420    175       0        


Endpoint ID: 1529
Path: /sys/fs/bpf/tc/globals/cilium_policy_01529

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1659558   20994     0        
Allow    Ingress     1          ANY          NONE         disabled    17850     209       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1683
Path: /sys/fs/bpf/tc/globals/cilium_policy_01683

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    114964   1320      0        
Allow    Egress      0          ANY          NONE         disabled    17023    183       0        


Endpoint ID: 3006
Path: /sys/fs/bpf/tc/globals/cilium_policy_03006

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3458
Path: /sys/fs/bpf/tc/globals/cilium_policy_03458

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11594282   116782    0        
Allow    Ingress     1          ANY          NONE         disabled    10272446   108396    0        
Allow    Egress      0          ANY          NONE         disabled    14035281   137514    0        


