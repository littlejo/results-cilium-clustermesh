alloc: 191.85MB (201164992 bytes)
total-alloc: 2.27GB (2435348232 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 63894464
frees: 61910821
heap-alloc: 191.85MB (201164992 bytes)
heap-sys: 243.39MB (255213568 bytes)
heap-idle: 28.48MB (29859840 bytes)
heap-in-use: 214.91MB (225353728 bytes)
heap-released: 840.00KB (860160 bytes)
heap-objects: 1983643
stack-in-use: 64.56MB (67698688 bytes)
stack-sys: 64.56MB (67698688 bytes)
stack-mspan-inuse: 3.37MB (3534400 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 972.73KB (996073 bytes)
gc-sys: 6.03MB (6321640 bytes)
next-gc: when heap-alloc >= 213.29MB (223646360 bytes)
last-gc: 2024-10-30 08:22:58.782131198 +0000 UTC
gc-pause-total: 18.938394ms
gc-pause: 101970
gc-pause-end: 1730276578782131198
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0004718198711030338
enable-gc: true
debug-gc: false
