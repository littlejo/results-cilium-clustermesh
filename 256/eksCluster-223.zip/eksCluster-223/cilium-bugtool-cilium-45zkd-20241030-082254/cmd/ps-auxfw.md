USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         656  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         649  0.0  0.2 1240432 16316 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         678  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         644  0.0  0.0 1228744 3656 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         638  0.0  0.0 1228744 3660 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.3  4.7 1606080 382488 ?      Ssl  08:03   0:40 cilium-agent --config-dir=/tmp/cilium/config-map
root         411  0.0  0.1 1229744 8116 ?        Sl   08:03   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
