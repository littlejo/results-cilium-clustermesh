IP ADDRESS         LOCAL ENDPOINT INFO
10.223.0.64:0      id=3458  sec_id=7370774 flags=0x0000 ifindex=18  mac=2E:21:45:98:15:3D nodemac=8E:7B:58:9B:77:50   
10.223.0.46:0      id=386   sec_id=7355377 flags=0x0000 ifindex=12  mac=8E:C5:92:56:C6:16 nodemac=CE:38:43:84:CC:0F   
10.223.0.84:0      id=1529  sec_id=4     flags=0x0000 ifindex=10  mac=C6:C7:80:73:08:3B nodemac=E6:4F:7E:B0:21:2E     
10.223.0.144:0     (localhost)                                                                                        
172.31.206.159:0   (localhost)                                                                                        
10.223.0.48:0      id=1683  sec_id=7355377 flags=0x0000 ifindex=14  mac=92:9D:DF:49:40:89 nodemac=B2:10:06:F5:F0:04   
172.31.234.57:0    (localhost)                                                                                        
