{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:13.257Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.206.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:13.257Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.234.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:13.257Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:17.495Z",
  "value": "id=1529  sec_id=4     flags=0x0000 ifindex=10  mac=C6:C7:80:73:08:3B nodemac=E6:4F:7E:B0:21:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:17.500Z",
  "value": "id=386   sec_id=7355377 flags=0x0000 ifindex=12  mac=8E:C5:92:56:C6:16 nodemac=CE:38:43:84:CC:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:17.579Z",
  "value": "id=1683  sec_id=7355377 flags=0x0000 ifindex=14  mac=92:9D:DF:49:40:89 nodemac=B2:10:06:F5:F0:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:17.618Z",
  "value": "id=1529  sec_id=4     flags=0x0000 ifindex=10  mac=C6:C7:80:73:08:3B nodemac=E6:4F:7E:B0:21:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:17.663Z",
  "value": "id=386   sec_id=7355377 flags=0x0000 ifindex=12  mac=8E:C5:92:56:C6:16 nodemac=CE:38:43:84:CC:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:54.797Z",
  "value": "id=1529  sec_id=4     flags=0x0000 ifindex=10  mac=C6:C7:80:73:08:3B nodemac=E6:4F:7E:B0:21:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:54.798Z",
  "value": "id=1683  sec_id=7355377 flags=0x0000 ifindex=14  mac=92:9D:DF:49:40:89 nodemac=B2:10:06:F5:F0:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:54.798Z",
  "value": "id=386   sec_id=7355377 flags=0x0000 ifindex=12  mac=8E:C5:92:56:C6:16 nodemac=CE:38:43:84:CC:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:54.826Z",
  "value": "id=3505  sec_id=7370774 flags=0x0000 ifindex=16  mac=DE:45:17:41:9A:9F nodemac=C6:D5:AF:0B:A9:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:55.798Z",
  "value": "id=386   sec_id=7355377 flags=0x0000 ifindex=12  mac=8E:C5:92:56:C6:16 nodemac=CE:38:43:84:CC:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:55.798Z",
  "value": "id=3505  sec_id=7370774 flags=0x0000 ifindex=16  mac=DE:45:17:41:9A:9F nodemac=C6:D5:AF:0B:A9:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:55.798Z",
  "value": "id=1529  sec_id=4     flags=0x0000 ifindex=10  mac=C6:C7:80:73:08:3B nodemac=E6:4F:7E:B0:21:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:55.799Z",
  "value": "id=1683  sec_id=7355377 flags=0x0000 ifindex=14  mac=92:9D:DF:49:40:89 nodemac=B2:10:06:F5:F0:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:13.401Z",
  "value": "id=3458  sec_id=7370774 flags=0x0000 ifindex=18  mac=2E:21:45:98:15:3D nodemac=8E:7B:58:9B:77:50"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.223.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:20.042Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.684Z",
  "value": "id=3458  sec_id=7370774 flags=0x0000 ifindex=18  mac=2E:21:45:98:15:3D nodemac=8E:7B:58:9B:77:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.684Z",
  "value": "id=386   sec_id=7355377 flags=0x0000 ifindex=12  mac=8E:C5:92:56:C6:16 nodemac=CE:38:43:84:CC:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.684Z",
  "value": "id=1529  sec_id=4     flags=0x0000 ifindex=10  mac=C6:C7:80:73:08:3B nodemac=E6:4F:7E:B0:21:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.685Z",
  "value": "id=1683  sec_id=7355377 flags=0x0000 ifindex=14  mac=92:9D:DF:49:40:89 nodemac=B2:10:06:F5:F0:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.685Z",
  "value": "id=1529  sec_id=4     flags=0x0000 ifindex=10  mac=C6:C7:80:73:08:3B nodemac=E6:4F:7E:B0:21:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.686Z",
  "value": "id=1683  sec_id=7355377 flags=0x0000 ifindex=14  mac=92:9D:DF:49:40:89 nodemac=B2:10:06:F5:F0:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.687Z",
  "value": "id=3458  sec_id=7370774 flags=0x0000 ifindex=18  mac=2E:21:45:98:15:3D nodemac=8E:7B:58:9B:77:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.687Z",
  "value": "id=386   sec_id=7355377 flags=0x0000 ifindex=12  mac=8E:C5:92:56:C6:16 nodemac=CE:38:43:84:CC:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:26.685Z",
  "value": "id=386   sec_id=7355377 flags=0x0000 ifindex=12  mac=8E:C5:92:56:C6:16 nodemac=CE:38:43:84:CC:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:26.686Z",
  "value": "id=1529  sec_id=4     flags=0x0000 ifindex=10  mac=C6:C7:80:73:08:3B nodemac=E6:4F:7E:B0:21:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:26.686Z",
  "value": "id=3458  sec_id=7370774 flags=0x0000 ifindex=18  mac=2E:21:45:98:15:3D nodemac=8E:7B:58:9B:77:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:26.686Z",
  "value": "id=1683  sec_id=7355377 flags=0x0000 ifindex=14  mac=92:9D:DF:49:40:89 nodemac=B2:10:06:F5:F0:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:27.685Z",
  "value": "id=1529  sec_id=4     flags=0x0000 ifindex=10  mac=C6:C7:80:73:08:3B nodemac=E6:4F:7E:B0:21:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:27.686Z",
  "value": "id=3458  sec_id=7370774 flags=0x0000 ifindex=18  mac=2E:21:45:98:15:3D nodemac=8E:7B:58:9B:77:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:27.686Z",
  "value": "id=1683  sec_id=7355377 flags=0x0000 ifindex=14  mac=92:9D:DF:49:40:89 nodemac=B2:10:06:F5:F0:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.223.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:27.686Z",
  "value": "id=386   sec_id=7355377 flags=0x0000 ifindex=12  mac=8E:C5:92:56:C6:16 nodemac=CE:38:43:84:CC:0F"
}

