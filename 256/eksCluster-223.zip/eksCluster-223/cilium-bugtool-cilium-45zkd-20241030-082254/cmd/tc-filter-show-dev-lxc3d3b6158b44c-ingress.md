filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc3d3b6158b44c direct-action not_in_hw id 623 tag fb32c4f7fa735ab4 jited 
