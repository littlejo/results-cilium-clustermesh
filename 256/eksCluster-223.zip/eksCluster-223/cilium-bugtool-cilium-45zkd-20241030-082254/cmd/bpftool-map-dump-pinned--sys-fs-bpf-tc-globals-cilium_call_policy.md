key: 82 01 00 00  value: 17 02 00 00
key: f9 05 00 00  value: 07 02 00 00
key: 93 06 00 00  value: fb 01 00 00
key: 82 0d 00 00  value: 72 02 00 00
Found 4 elements
