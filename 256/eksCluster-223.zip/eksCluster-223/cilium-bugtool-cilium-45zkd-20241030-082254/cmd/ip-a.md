1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c7:0d:1b:67:ff brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.234.57/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1847sec preferred_lft 1847sec
    inet6 fe80::8c7:dff:fe1b:67ff/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:d3:19:4a:db:5d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.206.159/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8d3:19ff:fe4a:db5d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:01:f5:81:8b:fb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7401:f5ff:fe81:8bfb/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:e4:e4:5c:bc:1b brd ff:ff:ff:ff:ff:ff
    inet 10.223.0.144/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::18e4:e4ff:fe5c:bc1b/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 4a:57:53:45:66:dc brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4857:53ff:fe45:66dc/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:4f:7e:b0:21:2e brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::e44f:7eff:feb0:212e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca5b1b51a370b@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:38:43:84:cc:0f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::cc38:43ff:fe84:cc0f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc4693e3c28c92@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:10:06:f5:f0:04 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b010:6ff:fef5:f004/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc3d3b6158b44c@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:7b:58:9b:77:50 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::8c7b:58ff:fe9b:7750/64 scope link 
       valid_lft forever preferred_lft forever
