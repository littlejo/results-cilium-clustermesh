[
  {
    "containers": [
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbc473cda_efaf_4778_ab3b_d86460e4429f.slice/cri-containerd-c21c17714f0b45fbd48948b2aa763aac02b41bd6e571e7bbbe88071deb3b75ea.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbc473cda_efaf_4778_ab3b_d86460e4429f.slice/cri-containerd-3d25f8477684c6822f33dc344e3423806d3a2f69fe106a56d988be12aca72679.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbc473cda_efaf_4778_ab3b_d86460e4429f.slice/cri-containerd-6e9f0c86c14f9fecaea40fe0df3f5b6df6ef6e4f76969145be927d266da2c7c6.scope"
      }
    ],
    "ips": [
      "10.223.0.64"
    ],
    "name": "clustermesh-apiserver-7b8f68bc77-rn4n9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5fae0e4a_501e_48af_a35e_a4bcb1ab430f.slice/cri-containerd-60793dc5333bdb14361e94c9824800129124949931310446efcc1c4cc2707196.scope"
      }
    ],
    "ips": [
      "10.223.0.48"
    ],
    "name": "coredns-cc6ccd49c-dxhgm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d8acc82_c4c9_4d5b_b2ab_2bec25d1dfda.slice/cri-containerd-9f68f299e90b0f2cd6710c7a4337e7bc7af83bd4f373fdb29f5b8b0cdaa52a74.scope"
      }
    ],
    "ips": [
      "10.223.0.46"
    ],
    "name": "coredns-cc6ccd49c-45prt",
    "namespace": "kube-system"
  }
]

