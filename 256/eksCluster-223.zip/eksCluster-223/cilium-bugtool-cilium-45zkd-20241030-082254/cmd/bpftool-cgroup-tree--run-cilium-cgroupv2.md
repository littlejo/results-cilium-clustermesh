CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d8acc82_c4c9_4d5b_b2ab_2bec25d1dfda.slice/cri-containerd-9f68f299e90b0f2cd6710c7a4337e7bc7af83bd4f373fdb29f5b8b0cdaa52a74.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d8acc82_c4c9_4d5b_b2ab_2bec25d1dfda.slice/cri-containerd-b17454547ff0276b01c79b4a35315840d7b2e51e196d93137a40e0e12095125b.scope
    525      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod466568df_cb0c_429f_aa25_0bedbfd2a8c8.slice/cri-containerd-98472fb69bc47488fbe1b62cf1bfc98903ec8a79f20c007a7d28b7991d773d4e.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod466568df_cb0c_429f_aa25_0bedbfd2a8c8.slice/cri-containerd-bb54719867452b017c44f62651625ddc2961187197495105fd62a74a546e2944.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6f3736a_1a61_456b_95ec_860f5aff877d.slice/cri-containerd-9fb7e61af7fc94a7df8719a65b54108a547a272b92c6b20b94d0a147fef39302.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6f3736a_1a61_456b_95ec_860f5aff877d.slice/cri-containerd-32aea7ec47053986414461da14a9504679979c9d267827dfee6386e6cb7123b7.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5fae0e4a_501e_48af_a35e_a4bcb1ab430f.slice/cri-containerd-60793dc5333bdb14361e94c9824800129124949931310446efcc1c4cc2707196.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5fae0e4a_501e_48af_a35e_a4bcb1ab430f.slice/cri-containerd-56790e013c37008568399d2420db2c13ef948e4b7a395036a52393780936cd2e.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbc473cda_efaf_4778_ab3b_d86460e4429f.slice/cri-containerd-c21c17714f0b45fbd48948b2aa763aac02b41bd6e571e7bbbe88071deb3b75ea.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbc473cda_efaf_4778_ab3b_d86460e4429f.slice/cri-containerd-47e6ae0dbece546a5faaaeabf694b906adf056aaadec0dcb3afdc9235b240a02.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbc473cda_efaf_4778_ab3b_d86460e4429f.slice/cri-containerd-6e9f0c86c14f9fecaea40fe0df3f5b6df6ef6e4f76969145be927d266da2c7c6.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbc473cda_efaf_4778_ab3b_d86460e4429f.slice/cri-containerd-3d25f8477684c6822f33dc344e3423806d3a2f69fe106a56d988be12aca72679.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ae823d6_ad63_4007_8010_7326b205ffe5.slice/cri-containerd-203571abdb663c456cdb0afe3ab2ef3ff714483f00aa3d33db131fbace52b4eb.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ae823d6_ad63_4007_8010_7326b205ffe5.slice/cri-containerd-a3761f3f1f1b32a7575898f4a07b84864b801917f25db75417cca9b81a3826cd.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod813b057b_80ee_415d_ad3a_1dc524e85120.slice/cri-containerd-c5949541ac9880a971177ed999fd4c8d97958b1f7ac9f045a8bf409bd6e54809.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod813b057b_80ee_415d_ad3a_1dc524e85120.slice/cri-containerd-837028b7ef23ddd1b593f9beac3a7a5a90c0dc61a7b78bf98887bcc1e970372d.scope
    95       cgroup_device   multi                                          
