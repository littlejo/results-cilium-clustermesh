REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36831     2913227     677    bpf_overlay.c
Interface                 INGRESS     650800    132851682   1132   bpf_host.c
Success                   EGRESS      16508     1299231     1694   bpf_host.c
Success                   EGRESS      277712    34311830    1308   bpf_lxc.c
Success                   EGRESS      37008     2927883     53     encap.h
Success                   INGRESS     320249    36252620    86     l3.h
Success                   INGRESS     341223    37910662    235    trace.h
Unsupported L3 protocol   EGRESS      37        2726        1492   bpf_lxc.c
