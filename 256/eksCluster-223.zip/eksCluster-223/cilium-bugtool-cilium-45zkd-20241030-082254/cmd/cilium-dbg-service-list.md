ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.217.1:443 (active)     
                                         2 => 172.31.141.64:443 (active)    
2    10.100.101.92:443    ClusterIP      1 => 172.31.234.57:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.223.0.46:53 (active)       
                                         2 => 10.223.0.48:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.223.0.46:9153 (active)     
                                         2 => 10.223.0.48:9153 (active)     
5    10.100.20.186:2379   ClusterIP      1 => 10.223.0.64:2379 (active)     
