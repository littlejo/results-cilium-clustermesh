1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:97:71:d8:d0:25 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.183.204/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3573sec preferred_lft 3573sec
    inet6 fe80::497:71ff:fed8:d025/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:fe:d7:31:44:4d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.137.156/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4fe:d7ff:fe31:444d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:00:57:1b:40:5a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8c00:57ff:fe1b:405a/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:0c:44:2e:81:ff brd ff:ff:ff:ff:ff:ff
    inet 10.184.0.70/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::940c:44ff:fe2e:81ff/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether be:f5:a1:05:dd:dc brd ff:ff:ff:ff:ff:ff
    inet6 fe80::bcf5:a1ff:fe05:dddc/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:0c:ce:e4:69:91 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::2c0c:ceff:fee4:6991/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcfdf821e6f549@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:89:6e:71:63:63 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::dc89:6eff:fe71:6363/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc15178237e8bd@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:1b:5a:bb:e6:6e brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::581b:5aff:febb:e66e/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcdcf0f9a0bcc1@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:e5:46:fe:6d:23 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::80e5:46ff:fefe:6d23/64 scope link 
       valid_lft forever preferred_lft forever
