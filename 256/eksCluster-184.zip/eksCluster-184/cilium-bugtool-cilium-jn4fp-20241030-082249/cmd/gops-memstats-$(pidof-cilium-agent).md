alloc: 185.56MB (194575024 bytes)
total-alloc: 2.33GB (2501239400 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 64861579
frees: 62869609
heap-alloc: 185.56MB (194575024 bytes)
heap-sys: 247.52MB (259538944 bytes)
heap-idle: 34.29MB (35954688 bytes)
heap-in-use: 213.23MB (223584256 bytes)
heap-released: 2.11MB (2211840 bytes)
heap-objects: 1991970
stack-in-use: 64.44MB (67567616 bytes)
stack-sys: 64.44MB (67567616 bytes)
stack-mspan-inuse: 3.44MB (3612000 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 955.00KB (977921 bytes)
gc-sys: 6.02MB (6309328 bytes)
next-gc: when heap-alloc >= 225.41MB (236363912 bytes)
last-gc: 2024-10-30 08:22:51.225637732 +0000 UTC
gc-pause-total: 20.648894ms
gc-pause: 132933
gc-pause-end: 1730276571225637732
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005653369246667677
enable-gc: true
debug-gc: false
