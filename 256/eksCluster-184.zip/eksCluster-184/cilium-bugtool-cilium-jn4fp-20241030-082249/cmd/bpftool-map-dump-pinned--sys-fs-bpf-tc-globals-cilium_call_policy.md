key: 59 00 00 00  value: 80 02 00 00
key: 87 00 00 00  value: 45 02 00 00
key: d2 03 00 00  value: 20 02 00 00
key: fb 04 00 00  value: 11 02 00 00
Found 4 elements
