[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1208998a_d4f3_455b_be71_33014bb3275a.slice/cri-containerd-9a635b76dbbda6940d7e0aed4d7e61d462b0062dbee84a038fee039525b5d880.scope"
      }
    ],
    "ips": [
      "10.184.0.112"
    ],
    "name": "coredns-cc6ccd49c-bkn9d",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0271d52f_490b_4fe0_9cb7_3a9765e9542a.slice/cri-containerd-67598c78e8203f3eccd22f81f173a93c0f131eb1de6aa80a41d47f0a1d000ad7.scope"
      }
    ],
    "ips": [
      "10.184.0.118"
    ],
    "name": "coredns-cc6ccd49c-6nqsk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04801e1d_37b5_489d_995c_a1d7a1e72a64.slice/cri-containerd-154df7cb3a7fa161a4f7ce14db6e9d008d7928d7d109e831b25266ca3dec2d51.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04801e1d_37b5_489d_995c_a1d7a1e72a64.slice/cri-containerd-79242ca95a96fa5331b17778031dffc35a95e9963e10caa803c71f473069a2bc.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04801e1d_37b5_489d_995c_a1d7a1e72a64.slice/cri-containerd-5e27005630ce029d4e8cb341a3ada501f1aaedbc08f4ad21112f7b350930f4f8.scope"
      }
    ],
    "ips": [
      "10.184.0.241"
    ],
    "name": "clustermesh-apiserver-5bc4d4f9bb-qlhg4",
    "namespace": "kube-system"
  }
]

