KEY             VALUE
AgentLiveness   1867953640820
UTimeOffset     3379442839843750
