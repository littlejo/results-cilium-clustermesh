ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.231.161:443 (active)    
                                         2 => 172.31.143.113:443 (active)    
2    10.100.43.104:443    ClusterIP      1 => 172.31.183.204:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.184.0.118:53 (active)       
                                         2 => 10.184.0.112:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.184.0.118:9153 (active)     
                                         2 => 10.184.0.112:9153 (active)     
5    10.100.144.69:2379   ClusterIP      1 => 10.184.0.241:2379 (active)     
