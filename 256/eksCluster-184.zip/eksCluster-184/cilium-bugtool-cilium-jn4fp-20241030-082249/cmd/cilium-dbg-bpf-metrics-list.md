REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36688     2904881     677    bpf_overlay.c
Interface                 INGRESS     662983    134406591   1132   bpf_host.c
Success                   EGRESS      16530     1301119     1694   bpf_host.c
Success                   EGRESS      285742    35326299    1308   bpf_lxc.c
Success                   EGRESS      37361     2946707     53     encap.h
Success                   INGRESS     330520    37403878    86     l3.h
Success                   INGRESS     351329    39051686    235    trace.h
Unsupported L3 protocol   EGRESS      38        2812        1492   bpf_lxc.c
