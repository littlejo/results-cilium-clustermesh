IP ADDRESS         LOCAL ENDPOINT INFO
172.31.183.204:0   (localhost)                                                                                        
10.184.0.193:0     id=135   sec_id=4     flags=0x0000 ifindex=10  mac=32:4B:F8:11:D5:32 nodemac=2E:0C:CE:E4:69:91     
10.184.0.118:0     id=1275  sec_id=6092417 flags=0x0000 ifindex=12  mac=96:89:25:68:75:78 nodemac=DE:89:6E:71:63:63   
172.31.137.156:0   (localhost)                                                                                        
10.184.0.112:0     id=978   sec_id=6092417 flags=0x0000 ifindex=14  mac=56:5F:5A:D1:98:27 nodemac=5A:1B:5A:BB:E6:6E   
10.184.0.241:0     id=89    sec_id=6067853 flags=0x0000 ifindex=18  mac=5A:38:60:43:A8:DD nodemac=82:E5:46:FE:6D:23   
10.184.0.70:0      (localhost)                                                                                        
