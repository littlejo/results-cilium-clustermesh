CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a944f67_8995_4319_9ab3_1383214c9c06.slice/cri-containerd-2eaa04349011edd8043d398063e451b4a7661bc1d1479328f2fd1b2711dd0c82.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a944f67_8995_4319_9ab3_1383214c9c06.slice/cri-containerd-b1c6c05147f81dda238f9bea413ef3d06b81eaa30f9632250befe0ae070bbaa0.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0271d52f_490b_4fe0_9cb7_3a9765e9542a.slice/cri-containerd-67598c78e8203f3eccd22f81f173a93c0f131eb1de6aa80a41d47f0a1d000ad7.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0271d52f_490b_4fe0_9cb7_3a9765e9542a.slice/cri-containerd-08cf8773fe34bdcc834a275c89a5d488fbdbe4ceee0cb3e8bc0ef27653f7c0b3.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf5848c84_1cd0_49d4_bb11_fbc994952009.slice/cri-containerd-a0630feec9026bb9317e23a229b23d7b91dfd29168e74306475802f52f3c6127.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf5848c84_1cd0_49d4_bb11_fbc994952009.slice/cri-containerd-e0b3af949f6053cd8da8c4ab5335011245b8990aaa10c57ed3292442f3126151.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1208998a_d4f3_455b_be71_33014bb3275a.slice/cri-containerd-9a635b76dbbda6940d7e0aed4d7e61d462b0062dbee84a038fee039525b5d880.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1208998a_d4f3_455b_be71_33014bb3275a.slice/cri-containerd-6f689ca5f46379e5876389b426cc25d5870beedfa0038414f9a8839e18a977f8.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04801e1d_37b5_489d_995c_a1d7a1e72a64.slice/cri-containerd-79242ca95a96fa5331b17778031dffc35a95e9963e10caa803c71f473069a2bc.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04801e1d_37b5_489d_995c_a1d7a1e72a64.slice/cri-containerd-154df7cb3a7fa161a4f7ce14db6e9d008d7928d7d109e831b25266ca3dec2d51.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04801e1d_37b5_489d_995c_a1d7a1e72a64.slice/cri-containerd-5e27005630ce029d4e8cb341a3ada501f1aaedbc08f4ad21112f7b350930f4f8.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04801e1d_37b5_489d_995c_a1d7a1e72a64.slice/cri-containerd-83c9d5c8cbaf533fb8159afbdbc8463ac5bd805f6ca0e2cba5fd4b181bd9e3a4.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddde4482f_dadd_4d0a_a115_0b7326c97b3b.slice/cri-containerd-53473050e2e8882efd14be36af787e74e3ac975e242653baf28af4516cf420d7.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddde4482f_dadd_4d0a_a115_0b7326c97b3b.slice/cri-containerd-c11b33ddad6767c32fde87357956c451a6293911649da4e568c0272639970db9.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda7153cd2_6c60_42f4_9cf0_5a6a15f44bb4.slice/cri-containerd-8d69b48dfb92caf09c51649ab4015bc9d13799abe5171df0a3653e424080bc41.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda7153cd2_6c60_42f4_9cf0_5a6a15f44bb4.slice/cri-containerd-89b201084a5483940cf905407d60c7a0b0ecb13314a5a5feaf78edaab396effd.scope
    103      cgroup_device   multi                                          
