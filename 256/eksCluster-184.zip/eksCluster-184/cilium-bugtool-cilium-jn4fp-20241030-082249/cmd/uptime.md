 08:22:51 up 30 min,  0 users,  load average: 0.49, 0.40, 0.25
