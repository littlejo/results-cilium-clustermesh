2024-10-30T07:52:14,000000+00:00 Booting Linux on physical CPU 0x0000000000 [0x413fd0c1]
2024-10-30T07:52:14,000000+00:00 Linux version 6.1.112-122.189.amzn2023.aarch64 (mockbuild@ip-10-0-39-248) (gcc (GCC) 11.4.1 20230605 (Red Hat 11.4.1-2), GNU ld version 2.39-6.amzn2023.0.10) #1 SMP Tue Oct  8 17:01:34 UTC 2024
2024-10-30T07:52:14,000000+00:00 efi: EFI v2.70 by EDK II
2024-10-30T07:52:14,000000+00:00 efi: SMBIOS=0x7bed0000 SMBIOS 3.0=0x7beb0000 ACPI=0x786e0000 ACPI 2.0=0x786e0014 MEMATTR=0x7aff0a98 RNG=0x74ca0018 MEMRESERVE=0x784d0d98 
2024-10-30T07:52:14,000000+00:00 random: crng init done
2024-10-30T07:52:14,000000+00:00 ACPI: Early table checksum verification disabled
2024-10-30T07:52:14,000000+00:00 ACPI: RSDP 0x00000000786E0014 000024 (v02 AMAZON)
2024-10-30T07:52:14,000000+00:00 ACPI: XSDT 0x00000000786D00E8 000064 (v01 AMAZON AMZNFACP 00000001      01000013)
2024-10-30T07:52:14,000000+00:00 ACPI: FACP 0x00000000786B0000 000114 (v06 AMAZON AMZNFACP 00000001 AMZN 00000001)
2024-10-30T07:52:14,000000+00:00 ACPI: DSDT 0x0000000078640000 00159D (v02 AMAZON AMZNDSDT 00000001 INTL 20160527)
2024-10-30T07:52:14,000000+00:00 ACPI: FACS 0x0000000078630000 000040
2024-10-30T07:52:14,000000+00:00 ACPI: APIC 0x00000000786C0000 000108 (v04 AMAZON AMZNAPIC 00000001 AMZN 00000001)
2024-10-30T07:52:14,000000+00:00 ACPI: SPCR 0x00000000786A0000 000050 (v02 AMAZON AMZNSPCR 00000001 AMZN 00000001)
2024-10-30T07:52:14,000000+00:00 ACPI: GTDT 0x0000000078690000 000060 (v02 AMAZON AMZNGTDT 00000001 AMZN 00000001)
2024-10-30T07:52:14,000000+00:00 ACPI: MCFG 0x0000000078680000 00003C (v02 AMAZON AMZNMCFG 00000001 AMZN 00000001)
2024-10-30T07:52:14,000000+00:00 ACPI: SLIT 0x0000000078670000 00002D (v01 AMAZON AMZNSLIT 00000001 AMZN 00000001)
2024-10-30T07:52:14,000000+00:00 ACPI: IORT 0x0000000078660000 000078 (v01 AMAZON AMZNIORT 00000001 AMZN 00000001)
2024-10-30T07:52:14,000000+00:00 ACPI: PPTT 0x0000000078650000 0000D4 (v02 AMAZON AMZNPPTT 00000001 AMZN 00000001)
2024-10-30T07:52:14,000000+00:00 ACPI: SPCR: console: uart,mmio,0x90a0000,115200
2024-10-30T07:52:14,000000+00:00 NUMA: Failed to initialise from firmware
2024-10-30T07:52:14,000000+00:00 NUMA: Faking a node at [mem 0x0000000040000000-0x00000005b8ffffff]
2024-10-30T07:52:14,000000+00:00 NUMA: NODE_DATA [mem 0x5b802a7c0-0x5b802cfff]
2024-10-30T07:52:14,000000+00:00 Zone ranges:
2024-10-30T07:52:14,000000+00:00   DMA      [mem 0x0000000040000000-0x00000000ffffffff]
2024-10-30T07:52:14,000000+00:00   DMA32    empty
2024-10-30T07:52:14,000000+00:00   Normal   [mem 0x0000000100000000-0x00000005b8ffffff]
2024-10-30T07:52:14,000000+00:00   Device   empty
2024-10-30T07:52:14,000000+00:00 Movable zone start for each node
2024-10-30T07:52:14,000000+00:00 Early memory node ranges
2024-10-30T07:52:14,000000+00:00   node   0: [mem 0x0000000040000000-0x000000007862ffff]
2024-10-30T07:52:14,000000+00:00   node   0: [mem 0x0000000078630000-0x000000007863ffff]
2024-10-30T07:52:14,000000+00:00   node   0: [mem 0x0000000078640000-0x00000000786effff]
2024-10-30T07:52:14,000000+00:00   node   0: [mem 0x00000000786f0000-0x000000007872ffff]
2024-10-30T07:52:14,000000+00:00   node   0: [mem 0x0000000078730000-0x000000007bbfffff]
2024-10-30T07:52:14,000000+00:00   node   0: [mem 0x000000007bc00000-0x000000007bfdffff]
2024-10-30T07:52:14,000000+00:00   node   0: [mem 0x000000007bfe0000-0x000000007fffffff]
2024-10-30T07:52:14,000000+00:00   node   0: [mem 0x0000000400000000-0x00000005b8ffffff]
2024-10-30T07:52:14,000000+00:00 Initmem setup node 0 [mem 0x0000000040000000-0x00000005b8ffffff]
2024-10-30T07:52:14,000000+00:00 On node 0, zone Normal: 28672 pages in unavailable ranges
2024-10-30T07:52:14,000000+00:00 cma: Reserved 64 MiB at 0x000000007c000000 on node -1
2024-10-30T07:52:14,000000+00:00 psci: probing for conduit method from ACPI.
2024-10-30T07:52:14,000000+00:00 psci: PSCIv1.0 detected in firmware.
2024-10-30T07:52:14,000000+00:00 psci: Using standard PSCI v0.2 function IDs
2024-10-30T07:52:14,000000+00:00 psci: Trusted OS migration not required
2024-10-30T07:52:14,000000+00:00 psci: SMC Calling Convention v1.1
2024-10-30T07:52:14,000000+00:00 percpu: Embedded 31 pages/cpu s86440 r8192 d32344 u126976
2024-10-30T07:52:14,000000+00:00 pcpu-alloc: s86440 r8192 d32344 u126976 alloc=31*4096
2024-10-30T07:52:14,000000+00:00 pcpu-alloc: [0] 0 [0] 1 
2024-10-30T07:52:14,000000+00:00 Detected PIPT I-cache on CPU0
2024-10-30T07:52:14,000000+00:00 CPU features: detected: GIC system register CPU interface
2024-10-30T07:52:14,000000+00:00 CPU features: detected: Hardware dirty bit management
2024-10-30T07:52:14,000000+00:00 CPU features: detected: Spectre-v4
2024-10-30T07:52:14,000000+00:00 CPU features: detected: Spectre-BHB
2024-10-30T07:52:14,000000+00:00 CPU features: detected: ARM erratum 1418040
2024-10-30T07:52:14,000000+00:00 CPU features: detected: ARM erratum 1542419 (kernel portion)
2024-10-30T07:52:14,000000+00:00 CPU features: detected: SSBS not fully self-synchronizing
2024-10-30T07:52:14,000000+00:00 alternatives: applying boot alternatives
2024-10-30T07:52:14,000000+00:00 Fallback order for Node 0: 0 
2024-10-30T07:52:14,000000+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 2036160
2024-10-30T07:52:14,000000+00:00 Policy zone: Normal
2024-10-30T07:52:14,000000+00:00 Kernel command line: BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64 root=UUID=b5c7fae5-1de8-4038-8408-06c720e69aff ro console=tty0 console=ttyS0,115200n8 nvme_core.io_timeout=4294967295 rd.emergency=poweroff rd.shell=0 selinux=1 security=selinux quiet numa_cma=1:64M
2024-10-30T07:52:14,000000+00:00 Unknown kernel command line parameters "BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64", will be passed to user space.
2024-10-30T07:52:14,000000+00:00 Dentry cache hash table entries: 1048576 (order: 11, 8388608 bytes, linear)
2024-10-30T07:52:14,000000+00:00 Inode-cache hash table entries: 524288 (order: 10, 4194304 bytes, linear)
2024-10-30T07:52:14,000000+00:00 mem auto-init: stack:off, heap alloc:off, heap free:off
2024-10-30T07:52:14,000000+00:00 software IO TLB: area num 2.
2024-10-30T07:52:14,000000+00:00 software IO TLB: mapped [mem 0x000000006de00000-0x0000000071e00000] (64MB)
2024-10-30T07:52:14,000000+00:00 Memory: 7919828K/8273920K available (12096K kernel code, 8838K rwdata, 8416K rodata, 4480K init, 11359K bss, 288556K reserved, 65536K cma-reserved)
2024-10-30T07:52:14,000000+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=2, Nodes=1
2024-10-30T07:52:14,000000+00:00 ftrace: allocating 40237 entries in 158 pages
2024-10-30T07:52:14,000000+00:00 ftrace: allocated 158 pages with 5 groups
2024-10-30T07:52:14,000000+00:00 trace event string verifier disabled
2024-10-30T07:52:14,000000+00:00 rcu: Hierarchical RCU implementation.
2024-10-30T07:52:14,000000+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=4096 to nr_cpu_ids=2.
2024-10-30T07:52:14,000000+00:00 	Rude variant of Tasks RCU enabled.
2024-10-30T07:52:14,000000+00:00 	Tracing variant of Tasks RCU enabled.
2024-10-30T07:52:14,000000+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 10 jiffies.
2024-10-30T07:52:14,000000+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=2
2024-10-30T07:52:14,000000+00:00 NR_IRQS: 64, nr_irqs: 64, preallocated irqs: 0
2024-10-30T07:52:14,000000+00:00 GICv3: 96 SPIs implemented
2024-10-30T07:52:14,000000+00:00 GICv3: 0 Extended SPIs implemented
2024-10-30T07:52:14,000000+00:00 Root IRQ handler: gic_handle_irq
2024-10-30T07:52:14,000000+00:00 GICv3: GICv3 features: 16 PPIs
2024-10-30T07:52:14,000000+00:00 GICv3: CPU0: found redistributor 0 region 0:0x0000000010200000
2024-10-30T07:52:14,000000+00:00 ITS [mem 0x10080000-0x1009ffff]
2024-10-30T07:52:14,000000+00:00 ITS@0x0000000010080000: allocated 8192 Devices @4001a0000 (indirect, esz 8, psz 64K, shr 1)
2024-10-30T07:52:14,000000+00:00 ITS@0x0000000010080000: allocated 8192 Interrupt Collections @4001b0000 (flat, esz 8, psz 64K, shr 1)
2024-10-30T07:52:14,000000+00:00 GICv3: using LPI property table @0x00000004001c0000
2024-10-30T07:52:14,000000+00:00 ITS: Using hypervisor restricted LPI range [128]
2024-10-30T07:52:14,000000+00:00 GICv3: CPU0: using allocated LPI pending table @0x00000004001d0000
2024-10-30T07:52:14,000000+00:00 rcu: srcu_init: Setting srcu_struct sizes based on contention.
2024-10-30T07:52:14,000000+00:00 arch_timer: Enabling local workaround for ARM erratum 1418040
2024-10-30T07:52:14,000000+00:00 arch_timer: cp15 timer(s) running at 121.87MHz (virt).
2024-10-30T07:52:14,000000+00:00 clocksource: arch_sys_counter: mask: 0x3ffffffffffffff max_cycles: 0x383759f8ff, max_idle_ns: 881590415659 ns
2024-10-30T07:52:14,000000+00:00 sched_clock: 58 bits at 122MHz, resolution 8ns, wraps every 4398046511103ns
2024-10-30T07:52:14,000024+00:00 arm-pv: using stolen time PV
2024-10-30T07:52:14,000087+00:00 Console: colour dummy device 80x25
2024-10-30T07:52:14,000102+00:00 printk: console [tty0] enabled
2024-10-30T07:52:14,000119+00:00 ACPI: Core revision 20220331
2024-10-30T07:52:14,000154+00:00 Calibrating delay loop (skipped), value calculated using timer frequency.. 243.75 BogoMIPS (lpj=1218750)
2024-10-30T07:52:14,000157+00:00 pid_max: default: 32768 minimum: 301
2024-10-30T07:52:14,000177+00:00 LSM: Security Framework initializing
2024-10-30T07:52:14,000195+00:00 Yama: becoming mindful.
2024-10-30T07:52:14,000202+00:00 SELinux:  Initializing.
2024-10-30T07:52:14,000216+00:00 LSM support for eBPF active
2024-10-30T07:52:14,000236+00:00 Mount-cache hash table entries: 16384 (order: 5, 131072 bytes, linear)
2024-10-30T07:52:14,000241+00:00 Mountpoint-cache hash table entries: 16384 (order: 5, 131072 bytes, linear)
2024-10-30T07:52:14,000587+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-10-30T07:52:14,000589+00:00 cblist_init_generic: Setting shift to 1 and lim to 1.
2024-10-30T07:52:14,000603+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-10-30T07:52:14,000604+00:00 cblist_init_generic: Setting shift to 1 and lim to 1.
2024-10-30T07:52:14,000645+00:00 rcu: Hierarchical SRCU implementation.
2024-10-30T07:52:14,000646+00:00 rcu: 	Max phase no-delay instances is 1000.
2024-10-30T07:52:14,000843+00:00 Platform MSI: ITS@0x10080000 domain created
2024-10-30T07:52:14,000848+00:00 PCI/MSI: ITS@0x10080000 domain created
2024-10-30T07:52:14,000852+00:00 Remapping and enabling EFI services.
2024-10-30T07:52:14,000962+00:00 smp: Bringing up secondary CPUs ...
2024-10-30T07:52:14,001123+00:00 Detected PIPT I-cache on CPU1
2024-10-30T07:52:14,001154+00:00 GICv3: CPU1: found redistributor 1 region 0:0x0000000010220000
2024-10-30T07:52:14,001193+00:00 GICv3: CPU1: using allocated LPI pending table @0x00000004001e0000
2024-10-30T07:52:14,001210+00:00 arch_timer: Enabling local workaround for ARM erratum 1418040
2024-10-30T07:52:14,001225+00:00 CPU1: Booted secondary processor 0x0000000001 [0x413fd0c1]
2024-10-30T07:52:14,001334+00:00 smp: Brought up 1 node, 2 CPUs
2024-10-30T07:52:14,001340+00:00 SMP: Total of 2 processors activated.
2024-10-30T07:52:14,001342+00:00 CPU features: detected: 32-bit EL0 Support
2024-10-30T07:52:14,001344+00:00 CPU features: detected: Instruction cache invalidation not required for I/D coherence
2024-10-30T07:52:14,001345+00:00 CPU features: detected: Data cache clean to the PoU not required for I/D coherence
2024-10-30T07:52:14,001346+00:00 CPU features: detected: Common not Private translations
2024-10-30T07:52:14,001347+00:00 CPU features: detected: CRC32 instructions
2024-10-30T07:52:14,001349+00:00 CPU features: detected: RCpc load-acquire (LDAPR)
2024-10-30T07:52:14,001349+00:00 CPU features: detected: LSE atomic instructions
2024-10-30T07:52:14,001350+00:00 CPU features: detected: Privileged Access Never
2024-10-30T07:52:14,001351+00:00 CPU features: detected: RAS Extension Support
2024-10-30T07:52:14,001353+00:00 CPU features: detected: Speculative Store Bypassing Safe (SSBS)
2024-10-30T07:52:14,001404+00:00 CPU: All CPU(s) started at EL1
2024-10-30T07:52:14,001408+00:00 alternatives: applying system-wide alternatives
2024-10-30T07:52:14,003634+00:00 devtmpfs: initialized
2024-10-30T07:52:14,004330+00:00 Registered cp15_barrier emulation handler
2024-10-30T07:52:14,004342+00:00 Registered setend emulation handler
2024-10-30T07:52:14,004379+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 19112604462750000 ns
2024-10-30T07:52:14,004384+00:00 futex hash table entries: 512 (order: 3, 32768 bytes, linear)
2024-10-30T07:52:14,004608+00:00 pinctrl core: initialized pinctrl subsystem
2024-10-30T07:52:14,004653+00:00 SMBIOS 3.0.0 present.
2024-10-30T07:52:14,004656+00:00 DMI: Amazon EC2 t4g.large/, BIOS 1.0 11/1/2018
2024-10-30T07:52:14,004757+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2024-10-30T07:52:14,004951+00:00 DMA: preallocated 1024 KiB GFP_KERNEL pool for atomic allocations
2024-10-30T07:52:14,004987+00:00 DMA: preallocated 1024 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2024-10-30T07:52:14,005046+00:00 DMA: preallocated 1024 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2024-10-30T07:52:14,005055+00:00 audit: initializing netlink subsys (disabled)
2024-10-30T07:52:14,005115+00:00 audit: type=2000 audit(0.000:1): state=initialized audit_enabled=0 res=1
2024-10-30T07:52:14,005163+00:00 thermal_sys: Registered thermal governor 'fair_share'
2024-10-30T07:52:14,005165+00:00 thermal_sys: Registered thermal governor 'step_wise'
2024-10-30T07:52:14,005166+00:00 thermal_sys: Registered thermal governor 'user_space'
2024-10-30T07:52:14,005174+00:00 cpuidle: using governor ladder
2024-10-30T07:52:14,005178+00:00 cpuidle: using governor menu
2024-10-30T07:52:14,005215+00:00 hw-breakpoint: found 6 breakpoint and 4 watchpoint registers.
2024-10-30T07:52:14,005247+00:00 ASID allocator initialised with 65536 entries
2024-10-30T07:52:14,005252+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2024-10-30T07:52:14,005264+00:00 Serial: AMBA PL011 UART driver
2024-10-30T07:52:14,011249+00:00 HugeTLB: registered 1.00 GiB page size, pre-allocated 0 pages
2024-10-30T07:52:14,011252+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 1.00 GiB page
2024-10-30T07:52:14,011253+00:00 HugeTLB: registered 32.0 MiB page size, pre-allocated 0 pages
2024-10-30T07:52:14,011254+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 32.0 MiB page
2024-10-30T07:52:14,011255+00:00 HugeTLB: registered 2.00 MiB page size, pre-allocated 0 pages
2024-10-30T07:52:14,011256+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 2.00 MiB page
2024-10-30T07:52:14,011257+00:00 HugeTLB: registered 64.0 KiB page size, pre-allocated 0 pages
2024-10-30T07:52:14,011258+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 64.0 KiB page
2024-10-30T07:52:14,011708+00:00 ACPI: Added _OSI(Module Device)
2024-10-30T07:52:14,011711+00:00 ACPI: Added _OSI(Processor Device)
2024-10-30T07:52:14,011712+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2024-10-30T07:52:14,011714+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2024-10-30T07:52:14,012290+00:00 ACPI: 1 ACPI AML tables successfully acquired and loaded
2024-10-30T07:52:14,012700+00:00 ACPI: Interpreter enabled
2024-10-30T07:52:14,012703+00:00 ACPI: Using GIC for interrupt routing
2024-10-30T07:52:14,012722+00:00 ACPI: MCFG table detected, 1 entries
2024-10-30T07:52:14,014283+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-0f])
2024-10-30T07:52:14,014294+00:00 acpi PNP0A08:00: _OSC: OS supports [ExtendedConfig ASPM ClockPM Segments MSI HPX-Type3]
2024-10-30T07:52:14,014333+00:00 acpi PNP0A08:00: _OSC: platform does not support [SHPCHotplug LTR]
2024-10-30T07:52:14,014385+00:00 acpi PNP0A08:00: _OSC: OS now controls [PCIeHotplug PME PCIeCapability]
2024-10-30T07:52:14,014461+00:00 acpi PNP0A08:00: ECAM area [mem 0x20000000-0x20ffffff] reserved by PNP0C02:00
2024-10-30T07:52:14,014467+00:00 acpi PNP0A08:00: ECAM at [mem 0x20000000-0x20ffffff] for [bus 00-0f]
2024-10-30T07:52:14,014480+00:00 ACPI: Remapped I/O 0x000000001fff0000 to [io  0x0000-0xffff window]
2024-10-30T07:52:14,014729+00:00 acpiphp: Slot [1] registered
2024-10-30T07:52:14,014740+00:00 acpiphp: Slot [2] registered
2024-10-30T07:52:14,014750+00:00 acpiphp: Slot [3] registered
2024-10-30T07:52:14,014760+00:00 acpiphp: Slot [4] registered
2024-10-30T07:52:14,014770+00:00 acpiphp: Slot [5] registered
2024-10-30T07:52:14,014780+00:00 acpiphp: Slot [6] registered
2024-10-30T07:52:14,014790+00:00 acpiphp: Slot [7] registered
2024-10-30T07:52:14,014799+00:00 acpiphp: Slot [8] registered
2024-10-30T07:52:14,014809+00:00 acpiphp: Slot [9] registered
2024-10-30T07:52:14,014820+00:00 acpiphp: Slot [10] registered
2024-10-30T07:52:14,014830+00:00 acpiphp: Slot [11] registered
2024-10-30T07:52:14,014839+00:00 acpiphp: Slot [12] registered
2024-10-30T07:52:14,014849+00:00 acpiphp: Slot [13] registered
2024-10-30T07:52:14,014858+00:00 acpiphp: Slot [14] registered
2024-10-30T07:52:14,014867+00:00 acpiphp: Slot [15] registered
2024-10-30T07:52:14,014877+00:00 acpiphp: Slot [16] registered
2024-10-30T07:52:14,014887+00:00 acpiphp: Slot [17] registered
2024-10-30T07:52:14,014896+00:00 acpiphp: Slot [18] registered
2024-10-30T07:52:14,014906+00:00 acpiphp: Slot [19] registered
2024-10-30T07:52:14,014917+00:00 acpiphp: Slot [20] registered
2024-10-30T07:52:14,014926+00:00 acpiphp: Slot [21] registered
2024-10-30T07:52:14,014936+00:00 acpiphp: Slot [22] registered
2024-10-30T07:52:14,014950+00:00 acpiphp: Slot [23] registered
2024-10-30T07:52:14,014964+00:00 acpiphp: Slot [24] registered
2024-10-30T07:52:14,014978+00:00 acpiphp: Slot [25] registered
2024-10-30T07:52:14,014989+00:00 acpiphp: Slot [26] registered
2024-10-30T07:52:14,014999+00:00 acpiphp: Slot [27] registered
2024-10-30T07:52:14,015009+00:00 acpiphp: Slot [28] registered
2024-10-30T07:52:14,015020+00:00 acpiphp: Slot [29] registered
2024-10-30T07:52:14,015029+00:00 acpiphp: Slot [30] registered
2024-10-30T07:52:14,015046+00:00 acpiphp: Slot [31] registered
2024-10-30T07:52:14,015062+00:00 PCI host bridge to bus 0000:00
2024-10-30T07:52:14,015063+00:00 pci_bus 0000:00: root bus resource [mem 0x80000000-0xffffffff window]
2024-10-30T07:52:14,015066+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0xffff window]
2024-10-30T07:52:14,015068+00:00 pci_bus 0000:00: root bus resource [mem 0x400000000000-0x407fffffffff window]
2024-10-30T07:52:14,015069+00:00 pci_bus 0000:00: root bus resource [bus 00-0f]
2024-10-30T07:52:14,015108+00:00 pci 0000:00:00.0: [1d0f:0200] type 00 class 0x060000
2024-10-30T07:52:14,015371+00:00 pci 0000:00:01.0: [1d0f:8250] type 00 class 0x070003
2024-10-30T07:52:14,015438+00:00 pci 0000:00:01.0: reg 0x10: [mem 0x80008000-0x80008fff]
2024-10-30T07:52:14,015665+00:00 pci 0000:00:04.0: [1d0f:8061] type 00 class 0x010802
2024-10-30T07:52:14,017238+00:00 pci 0000:00:04.0: reg 0x10: [mem 0x80004000-0x80007fff]
2024-10-30T07:52:14,023328+00:00 pci 0000:00:04.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-30T07:52:14,023527+00:00 pci 0000:00:05.0: [1d0f:ec20] type 00 class 0x020000
2024-10-30T07:52:14,023568+00:00 pci 0000:00:05.0: reg 0x10: [mem 0x80000000-0x80003fff]
2024-10-30T07:52:14,023762+00:00 pci 0000:00:05.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-30T07:52:14,023921+00:00 pci 0000:00:04.0: BAR 0: assigned [mem 0x80000000-0x80003fff]
2024-10-30T07:52:14,024454+00:00 pci 0000:00:05.0: BAR 0: assigned [mem 0x80004000-0x80007fff]
2024-10-30T07:52:14,024463+00:00 pci 0000:00:01.0: BAR 0: assigned [mem 0x80008000-0x80008fff]
2024-10-30T07:52:14,024471+00:00 pci_bus 0000:00: resource 4 [mem 0x80000000-0xffffffff window]
2024-10-30T07:52:14,024473+00:00 pci_bus 0000:00: resource 5 [io  0x0000-0xffff window]
2024-10-30T07:52:14,024475+00:00 pci_bus 0000:00: resource 6 [mem 0x400000000000-0x407fffffffff window]
2024-10-30T07:52:14,024507+00:00 ACPI: PCI: Interrupt link GSI0 configured for IRQ 35
2024-10-30T07:52:14,024513+00:00 ACPI: PCI: Interrupt link GSI1 configured for IRQ 36
2024-10-30T07:52:14,024518+00:00 ACPI: PCI: Interrupt link GSI2 configured for IRQ 37
2024-10-30T07:52:14,024523+00:00 ACPI: PCI: Interrupt link GSI3 configured for IRQ 38
2024-10-30T07:52:14,024897+00:00 iommu: Default domain type: Translated 
2024-10-30T07:52:14,024899+00:00 iommu: DMA domain TLB invalidation policy: lazy mode 
2024-10-30T07:52:14,024935+00:00 pps_core: LinuxPPS API ver. 1 registered
2024-10-30T07:52:14,024936+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2024-10-30T07:52:14,024938+00:00 PTP clock support registered
2024-10-30T07:52:14,024968+00:00 EDAC MC: Ver: 3.0.0
2024-10-30T07:52:14,025141+00:00 Registered efivars operations
2024-10-30T07:52:14,025335+00:00 NetLabel: Initializing
2024-10-30T07:52:14,025337+00:00 NetLabel:  domain hash size = 128
2024-10-30T07:52:14,025338+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2024-10-30T07:52:14,025349+00:00 NetLabel:  unlabeled traffic allowed by default
2024-10-30T07:52:14,025387+00:00 vgaarb: loaded
2024-10-30T07:52:14,025511+00:00 clocksource: Switched to clocksource arch_sys_counter
2024-10-30T07:52:14,025582+00:00 VFS: Disk quotas dquot_6.6.0
2024-10-30T07:52:14,025590+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2024-10-30T07:52:14,025645+00:00 pnp: PnP ACPI init
2024-10-30T07:52:14,025734+00:00 system 00:00: [mem 0x20000000-0x2fffffff] could not be reserved
2024-10-30T07:52:14,025744+00:00 pnp: PnP ACPI: found 1 devices
2024-10-30T07:52:14,030881+00:00 NET: Registered PF_INET protocol family
2024-10-30T07:52:14,030933+00:00 IP idents hash table entries: 131072 (order: 8, 1048576 bytes, linear)
2024-10-30T07:52:14,032361+00:00 tcp_listen_portaddr_hash hash table entries: 4096 (order: 4, 65536 bytes, linear)
2024-10-30T07:52:14,032385+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2024-10-30T07:52:14,032388+00:00 TCP established hash table entries: 65536 (order: 7, 524288 bytes, linear)
2024-10-30T07:52:14,032560+00:00 TCP bind hash table entries: 65536 (order: 9, 2097152 bytes, linear)
2024-10-30T07:52:14,033179+00:00 TCP: Hash tables configured (established 65536 bind 65536)
2024-10-30T07:52:14,033217+00:00 MPTCP token hash table entries: 8192 (order: 5, 196608 bytes, linear)
2024-10-30T07:52:14,033244+00:00 UDP hash table entries: 4096 (order: 5, 131072 bytes, linear)
2024-10-30T07:52:14,033303+00:00 UDP-Lite hash table entries: 4096 (order: 5, 131072 bytes, linear)
2024-10-30T07:52:14,033386+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2024-10-30T07:52:14,033395+00:00 NET: Registered PF_XDP protocol family
2024-10-30T07:52:14,033442+00:00 PCI: CLS 0 bytes, default 64
2024-10-30T07:52:14,033581+00:00 Trying to unpack rootfs image as initramfs...
2024-10-30T07:52:14,045128+00:00 hw perfevents: enabled with armv8_pmuv3_0 PMU driver, 3 counters available
2024-10-30T07:52:14,045154+00:00 kvm [1]: HYP mode not available
2024-10-30T07:52:14,045374+00:00 Initialise system trusted keyrings
2024-10-30T07:52:14,045381+00:00 Key type blacklist registered
2024-10-30T07:52:14,045647+00:00 workingset: timestamp_bits=44 max_order=21 bucket_order=0
2024-10-30T07:52:14,046646+00:00 zbud: loaded
2024-10-30T07:52:14,046806+00:00 SGI XFS with ACLs, security attributes, quota, no debug enabled
2024-10-30T07:52:14,047294+00:00 integrity: Platform Keyring initialized
2024-10-30T07:52:14,054316+00:00 Key type asymmetric registered
2024-10-30T07:52:14,054318+00:00 Asymmetric key parser 'x509' registered
2024-10-30T07:52:14,054338+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 248)
2024-10-30T07:52:14,054383+00:00 io scheduler mq-deadline registered
2024-10-30T07:52:14,054385+00:00 io scheduler kyber registered
2024-10-30T07:52:14,054410+00:00 io scheduler bfq registered
2024-10-30T07:52:14,056162+00:00 pl061_gpio ARMH0061:00: PL061 GPIO chip registered
2024-10-30T07:52:14,056218+00:00 shpchp: Standard Hot Plug PCI Controller Driver version: 0.4
2024-10-30T07:52:14,057639+00:00 Serial: 8250/16550 driver, 4 ports, IRQ sharing disabled
2024-10-30T07:52:14,058168+00:00 ACPI: \_SB_.PCI0.GSI2: Enabled at IRQ 37
2024-10-30T07:52:14,058197+00:00 serial 0000:00:01.0: enabling device (0010 -> 0012)
2024-10-30T07:52:14,058517+00:00 printk: console [ttyS0] disabled
2024-10-30T07:52:14,058694+00:00 0000:00:01.0: ttyS0 at MMIO 0x80008000 (irq = 14, base_baud = 115200) is a 16550A
2024-10-30T07:52:14,058822+00:00 printk: console [ttyS0] enabled
2024-10-30T07:52:14,059991+00:00 ACPI: \_SB_.PCI0.GSI0: Enabled at IRQ 35
2024-10-30T07:52:14,060070+00:00 nvme nvme0: pci function 0000:00:04.0
2024-10-30T07:52:14,060684+00:00 rtc-efi rtc-efi.0: registered as rtc0
2024-10-30T07:52:14,060721+00:00 rtc-efi rtc-efi.0: setting system clock to 2024-10-30T07:52:14 UTC (1730274734)
2024-10-30T07:52:14,060787+00:00 pstore: Registered efi as persistent store backend
2024-10-30T07:52:14,060798+00:00 hid: raw HID events driver (C) Jiri Kosina
2024-10-30T07:52:14,070523+00:00 NET: Registered PF_INET6 protocol family
2024-10-30T07:52:14,072578+00:00 nvme nvme0: 2/0/0 default/read/poll queues
2024-10-30T07:52:14,076872+00:00  nvme0n1: p1 p128
2024-10-30T07:52:14,145558+00:00 Freeing initrd memory: 11908K
2024-10-30T07:52:14,152294+00:00 Segment Routing with IPv6
2024-10-30T07:52:14,152313+00:00 In-situ OAM (IOAM) with IPv6
2024-10-30T07:52:14,152348+00:00 NET: Registered PF_PACKET protocol family
2024-10-30T07:52:14,152563+00:00 registered taskstats version 1
2024-10-30T07:52:14,152571+00:00 Loading compiled-in X.509 certificates
2024-10-30T07:52:14,164364+00:00 Loaded X.509 cert 'Amazon.com: Amazon Linux Kernel Signing Key: 3c3163dcb84c1049cf8b75ca4bcf01c5583dbccb'
2024-10-30T07:52:14,164496+00:00 zswap: loaded using pool lzo/zbud
2024-10-30T07:52:14,164635+00:00 Key type .fscrypt registered
2024-10-30T07:52:14,164637+00:00 Key type fscrypt-provisioning registered
2024-10-30T07:52:14,164831+00:00 pstore: Using crash dump compression: deflate
2024-10-30T07:52:14,165049+00:00 ima: secureboot mode disabled
2024-10-30T07:52:14,165052+00:00 ima: No TPM chip found, activating TPM-bypass!
2024-10-30T07:52:14,165059+00:00 ima: Allocated hash algorithm: sha256
2024-10-30T07:52:14,165069+00:00 ima: No architecture policies found
2024-10-30T07:52:14,307019+00:00 clk: Disabling unused clocks
2024-10-30T07:52:14,308304+00:00 Freeing unused kernel memory: 4480K
2024-10-30T07:52:14,308324+00:00 Run /init as init process
2024-10-30T07:52:14,308325+00:00   with arguments:
2024-10-30T07:52:14,308326+00:00     /init
2024-10-30T07:52:14,308328+00:00   with environment:
2024-10-30T07:52:14,308329+00:00     HOME=/
2024-10-30T07:52:14,308330+00:00     TERM=linux
2024-10-30T07:52:14,308330+00:00     BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64
2024-10-30T07:52:14,334133+00:00 systemd[1]: systemd 252.23-2.amzn2023 running in system mode (+PAM +AUDIT +SELINUX -APPARMOR +IMA +SMACK +SECCOMP -GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN -IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 -BZIP2 -LZ4 +XZ -ZLIB -ZSTD +BPF_FRAMEWORK +XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2024-10-30T07:52:14,334139+00:00 systemd[1]: Detected virtualization amazon.
2024-10-30T07:52:14,334143+00:00 systemd[1]: Detected architecture arm64.
2024-10-30T07:52:14,334144+00:00 systemd[1]: Running in initrd.
2024-10-30T07:52:14,334236+00:00 systemd[1]: No hostname configured, using default hostname.
2024-10-30T07:52:14,334276+00:00 systemd[1]: Hostname set to <localhost>.
2024-10-30T07:52:14,334346+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-10-30T07:52:14,422047+00:00 systemd[1]: Queued start job for default target initrd.target.
2024-10-30T07:52:14,445965+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2024-10-30T07:52:14,446015+00:00 systemd[1]: Expecting device dev-disk-by\x2duuid-b5c7fae5\x2d1de8\x2d4038\x2d8408\x2d06c720e69aff.device - /dev/disk/by-uuid/b5c7fae5-1de8-4038-8408-06c720e69aff...
2024-10-30T07:52:14,446043+00:00 systemd[1]: Reached target initrd-usr-fs.target - Initrd /usr File System.
2024-10-30T07:52:14,446056+00:00 systemd[1]: Reached target local-fs.target - Local File Systems.
2024-10-30T07:52:14,446066+00:00 systemd[1]: Reached target paths.target - Path Units.
2024-10-30T07:52:14,446087+00:00 systemd[1]: Reached target slices.target - Slice Units.
2024-10-30T07:52:14,446100+00:00 systemd[1]: Reached target swap.target - Swaps.
2024-10-30T07:52:14,446114+00:00 systemd[1]: Reached target timers.target - Timer Units.
2024-10-30T07:52:14,446415+00:00 systemd[1]: Listening on systemd-journald-audit.socket - Journal Audit Socket.
2024-10-30T07:52:14,446523+00:00 systemd[1]: Listening on systemd-journald-dev-log.socket - Journal Socket (/dev/log).
2024-10-30T07:52:14,446601+00:00 systemd[1]: Listening on systemd-journald.socket - Journal Socket.
2024-10-30T07:52:14,446687+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2024-10-30T07:52:14,446745+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2024-10-30T07:52:14,446761+00:00 systemd[1]: Reached target sockets.target - Socket Units.
2024-10-30T07:52:14,446813+00:00 systemd[1]: kmod-static-nodes.service - Create List of Static Device Nodes was skipped because of an unmet condition check (ConditionFileNotEmpty=/lib/modules/6.1.112-122.189.amzn2023.aarch64/modules.devname).
2024-10-30T07:52:14,447708+00:00 systemd[1]: Started rngd.service - Hardware RNG Entropy Gatherer Daemon.
2024-10-30T07:52:14,449086+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2024-10-30T07:52:14,449227+00:00 systemd[1]: systemd-modules-load.service - Load Kernel Modules was skipped because no trigger condition checks were met.
2024-10-30T07:52:14,450018+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2024-10-30T07:52:14,450829+00:00 systemd[1]: Starting systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev...
2024-10-30T07:52:14,451607+00:00 systemd[1]: Starting systemd-vconsole-setup.service - Setup Virtual Console...
2024-10-30T07:52:14,459526+00:00 systemd[1]: Finished systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev.
2024-10-30T07:52:14,477752+00:00 systemd[1]: Finished systemd-vconsole-setup.service - Setup Virtual Console.
2024-10-30T07:52:14,477803+00:00 audit: type=1130 audit(1730274734.909:2): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-vconsole-setup comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:52:14,477910+00:00 systemd[1]: dracut-cmdline-ask.service - dracut ask for additional cmdline parameters was skipped because no trigger condition checks were met.
2024-10-30T07:52:14,478777+00:00 systemd[1]: Starting dracut-cmdline.service - dracut cmdline hook...
2024-10-30T07:52:14,479082+00:00 systemd[1]: Finished systemd-sysctl.service - Apply Kernel Variables.
2024-10-30T07:52:14,479146+00:00 audit: type=1130 audit(1730274734.909:3): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-sysctl comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:52:14,482650+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2024-10-30T07:52:14,483766+00:00 audit: type=1130 audit(1730274734.909:4): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-journald comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:52:14,493125+00:00 audit: type=1130 audit(1730274734.919:5): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-tmpfiles-setup comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:52:14,560348+00:00 audit: type=1130 audit(1730274734.989:6): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=dracut-cmdline comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:52:14,560355+00:00 audit: type=1334 audit(1730274734.989:7): prog-id=6 op=LOAD
2024-10-30T07:52:14,560357+00:00 audit: type=1334 audit(1730274734.989:8): prog-id=7 op=LOAD
2024-10-30T07:52:14,612845+00:00 audit: type=1130 audit(1730274735.039:9): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-udevd comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:52:14,672841+00:00 audit: type=1130 audit(1730274735.099:10): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-udev-trigger comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:52:14,826355+00:00 XFS (nvme0n1p1): Mounting V5 Filesystem
2024-10-30T07:52:14,902595+00:00 XFS (nvme0n1p1): Ending clean mount
2024-10-30T07:52:15,197281+00:00 systemd-journald[324]: Received SIGTERM from PID 1 (systemd).
2024-10-30T07:52:15,373707+00:00 SELinux:  Class user_namespace not defined in policy.
2024-10-30T07:52:15,373714+00:00 SELinux: the above unknown classes and permissions will be allowed
2024-10-30T07:52:15,376639+00:00 SELinux:  policy capability network_peer_controls=1
2024-10-30T07:52:15,376644+00:00 SELinux:  policy capability open_perms=1
2024-10-30T07:52:15,376645+00:00 SELinux:  policy capability extended_socket_class=1
2024-10-30T07:52:15,376646+00:00 SELinux:  policy capability always_check_network=0
2024-10-30T07:52:15,376647+00:00 SELinux:  policy capability cgroup_seclabel=1
2024-10-30T07:52:15,376648+00:00 SELinux:  policy capability nnp_nosuid_transition=1
2024-10-30T07:52:15,376649+00:00 SELinux:  policy capability genfs_seclabel_symlinks=1
2024-10-30T07:52:15,376650+00:00 SELinux:  policy capability ioctl_skip_cloexec=0
2024-10-30T07:52:15,481611+00:00 systemd[1]: Successfully loaded SELinux policy in 148.197ms.
2024-10-30T07:52:15,537901+00:00 systemd[1]: Relabelled /dev, /dev/shm, /run, /sys/fs/cgroup in 22.447ms.
2024-10-30T07:52:15,546614+00:00 systemd[1]: systemd 252.23-2.amzn2023 running in system mode (+PAM +AUDIT +SELINUX -APPARMOR +IMA +SMACK +SECCOMP -GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN -IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 -BZIP2 -LZ4 +XZ -ZLIB -ZSTD +BPF_FRAMEWORK +XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2024-10-30T07:52:15,546619+00:00 systemd[1]: Detected virtualization amazon.
2024-10-30T07:52:15,546633+00:00 systemd[1]: Detected architecture arm64.
2024-10-30T07:52:15,549766+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-10-30T07:52:15,549839+00:00 systemd[1]: Installed transient /etc/machine-id file.
2024-10-30T07:52:15,623686+00:00 systemd[1]: bpf-lsm: Failed to link program; assuming BPF LSM is not available
2024-10-30T07:52:15,667521+00:00 zram_generator::config[853]: zram0: system has too much memory (7814MB), limit is 800MB, ignoring.
2024-10-30T07:52:15,766416+00:00 systemd[1]: /usr/lib/systemd/system/update-motd.service:40: Invalid CPU quota '25', ignoring.
2024-10-30T07:52:15,919143+00:00 systemd[1]: initrd-switch-root.service: Deactivated successfully.
2024-10-30T07:52:15,919288+00:00 systemd[1]: Stopped initrd-switch-root.service - Switch Root.
2024-10-30T07:52:15,919797+00:00 systemd[1]: systemd-journald.service: Scheduled restart job, restart counter is at 1.
2024-10-30T07:52:15,920212+00:00 systemd[1]: Created slice system-ebs\x2dinitialize\x2dbin.slice - Slice /system/ebs-initialize-bin.
2024-10-30T07:52:15,920535+00:00 systemd[1]: Created slice system-getty.slice - Slice /system/getty.
2024-10-30T07:52:15,920859+00:00 systemd[1]: Created slice system-modprobe.slice - Slice /system/modprobe.
2024-10-30T07:52:15,921177+00:00 systemd[1]: Created slice system-serial\x2dgetty.slice - Slice /system/serial-getty.
2024-10-30T07:52:15,921496+00:00 systemd[1]: Created slice system-sshd\x2dkeygen.slice - Slice /system/sshd-keygen.
2024-10-30T07:52:15,921828+00:00 systemd[1]: Created slice user.slice - User and Session Slice.
2024-10-30T07:52:15,921967+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2024-10-30T07:52:15,922056+00:00 systemd[1]: Started systemd-ask-password-wall.path - Forward Password Requests to Wall Directory Watch.
2024-10-30T07:52:15,922475+00:00 systemd[1]: Set up automount proc-sys-fs-binfmt_misc.automount - Arbitrary Executable File Formats File System Automount Point.
2024-10-30T07:52:15,922495+00:00 systemd[1]: Expecting device dev-ttyS0.device - /dev/ttyS0...
2024-10-30T07:52:15,922524+00:00 systemd[1]: Reached target cryptsetup.target - Local Encrypted Volumes.
2024-10-30T07:52:15,922558+00:00 systemd[1]: Stopped target initrd-switch-root.target - Switch Root.
2024-10-30T07:52:15,922574+00:00 systemd[1]: Stopped target initrd-fs.target - Initrd File Systems.
2024-10-30T07:52:15,922583+00:00 systemd[1]: Stopped target initrd-root-fs.target - Initrd Root File System.
2024-10-30T07:52:15,922596+00:00 systemd[1]: Reached target integritysetup.target - Local Integrity Protected Volumes.
2024-10-30T07:52:15,922636+00:00 systemd[1]: Reached target paths.target - Path Units.
2024-10-30T07:52:15,922666+00:00 systemd[1]: Reached target slices.target - Slice Units.
2024-10-30T07:52:15,922691+00:00 systemd[1]: Reached target swap.target - Swaps.
2024-10-30T07:52:15,922706+00:00 systemd[1]: Reached target veritysetup.target - Local Verity Protected Volumes.
2024-10-30T07:52:15,923179+00:00 systemd[1]: Listening on dm-event.socket - Device-mapper event daemon FIFOs.
2024-10-30T07:52:15,924764+00:00 systemd[1]: Listening on lvm2-lvmpolld.socket - LVM2 poll daemon socket.
2024-10-30T07:52:15,926469+00:00 systemd[1]: Listening on systemd-coredump.socket - Process Core Dump Socket.
2024-10-30T07:52:15,926597+00:00 systemd[1]: Listening on systemd-initctl.socket - initctl Compatibility Named Pipe.
2024-10-30T07:52:15,926860+00:00 systemd[1]: Listening on systemd-networkd.socket - Network Service Netlink Socket.
2024-10-30T07:52:15,927928+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2024-10-30T07:52:15,928274+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2024-10-30T07:52:15,928579+00:00 systemd[1]: Listening on systemd-userdbd.socket - User Database Manager Socket.
2024-10-30T07:52:15,929894+00:00 systemd[1]: Mounting dev-hugepages.mount - Huge Pages File System...
2024-10-30T07:52:15,931413+00:00 systemd[1]: Mounting dev-mqueue.mount - POSIX Message Queue File System...
2024-10-30T07:52:15,933349+00:00 systemd[1]: Mounting sys-kernel-debug.mount - Kernel Debug File System...
2024-10-30T07:52:15,935980+00:00 systemd[1]: Mounting sys-kernel-tracing.mount - Kernel Trace File System...
2024-10-30T07:52:15,938071+00:00 systemd[1]: Mounting tmp.mount - Temporary Directory /tmp...
2024-10-30T07:52:15,938155+00:00 systemd[1]: auth-rpcgss-module.service - Kernel Module supporting RPCSEC_GSS was skipped because of an unmet condition check (ConditionPathExists=/etc/krb5.keytab).
2024-10-30T07:52:15,940094+00:00 systemd[1]: Starting kmod-static-nodes.service - Create List of Static Device Nodes...
2024-10-30T07:52:15,941208+00:00 systemd[1]: Starting lvm2-monitor.service - Monitoring of LVM2 mirrors, snapshots etc. using dmeventd or progress polling...
2024-10-30T07:52:15,942338+00:00 systemd[1]: Starting modprobe@configfs.service - Load Kernel Module configfs...
2024-10-30T07:52:15,943456+00:00 systemd[1]: Starting modprobe@dm_mod.service - Load Kernel Module dm_mod...
2024-10-30T07:52:15,944592+00:00 systemd[1]: Starting modprobe@drm.service - Load Kernel Module drm...
2024-10-30T07:52:15,947435+00:00 systemd[1]: Starting modprobe@efi_pstore.service - Load Kernel Module efi_pstore...
2024-10-30T07:52:15,948677+00:00 systemd[1]: Starting modprobe@fuse.service - Load Kernel Module fuse...
2024-10-30T07:52:15,949862+00:00 systemd[1]: Starting modprobe@loop.service - Load Kernel Module loop...
2024-10-30T07:52:15,951002+00:00 systemd[1]: Starting nfs-convert.service - Preprocess NFS configuration convertion...
2024-10-30T07:52:15,952273+00:00 systemd[1]: Starting systemd-fsck-root.service - File System Check on Root Device...
2024-10-30T07:52:15,952353+00:00 systemd[1]: Stopped systemd-journald.service - Journal Service.
2024-10-30T07:52:15,954123+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2024-10-30T07:52:15,956429+00:00 systemd[1]: Starting systemd-modules-load.service - Load Kernel Modules...
2024-10-30T07:52:15,957589+00:00 systemd[1]: Starting systemd-network-generator.service - Generate network units from Kernel command line...
2024-10-30T07:52:15,958856+00:00 systemd[1]: Starting systemd-udev-trigger.service - Coldplug All udev Devices...
2024-10-30T07:52:15,960581+00:00 systemd[1]: Mounted dev-hugepages.mount - Huge Pages File System.
2024-10-30T07:52:15,960684+00:00 systemd[1]: Mounted dev-mqueue.mount - POSIX Message Queue File System.
2024-10-30T07:52:15,960752+00:00 systemd[1]: Mounted sys-kernel-debug.mount - Kernel Debug File System.
2024-10-30T07:52:15,960816+00:00 systemd[1]: Mounted sys-kernel-tracing.mount - Kernel Trace File System.
2024-10-30T07:52:15,960878+00:00 systemd[1]: Mounted tmp.mount - Temporary Directory /tmp.
2024-10-30T07:52:15,962758+00:00 systemd[1]: Finished kmod-static-nodes.service - Create List of Static Device Nodes.
2024-10-30T07:52:15,963098+00:00 systemd[1]: modprobe@drm.service: Deactivated successfully.
2024-10-30T07:52:15,963247+00:00 systemd[1]: Finished modprobe@drm.service - Load Kernel Module drm.
2024-10-30T07:52:15,968133+00:00 systemd[1]: nfs-convert.service: Deactivated successfully.
2024-10-30T07:52:15,968288+00:00 systemd[1]: Finished nfs-convert.service - Preprocess NFS configuration convertion.
2024-10-30T07:52:15,971791+00:00 systemd[1]: Finished systemd-network-generator.service - Generate network units from Kernel command line.
2024-10-30T07:52:15,974909+00:00 systemd[1]: Finished systemd-modules-load.service - Load Kernel Modules.
2024-10-30T07:52:15,976338+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2024-10-30T07:52:15,986935+00:00 systemd[1]: modprobe@configfs.service: Deactivated successfully.
2024-10-30T07:52:15,987084+00:00 systemd[1]: Finished modprobe@configfs.service - Load Kernel Module configfs.
2024-10-30T07:52:15,988644+00:00 systemd[1]: Mounting sys-kernel-config.mount - Kernel Configuration File System...
2024-10-30T07:52:15,991898+00:00 systemd[1]: Mounted sys-kernel-config.mount - Kernel Configuration File System.
2024-10-30T07:52:16,000397+00:00 device-mapper: core: CONFIG_IMA_DISABLE_HTABLE is disabled. Duplicate IMA measurements will not be recorded in the IMA log.
2024-10-30T07:52:16,000430+00:00 device-mapper: uevent: version 1.0.3
2024-10-30T07:52:16,003093+00:00 systemd[1]: modprobe@efi_pstore.service: Deactivated successfully.
2024-10-30T07:52:16,003131+00:00 device-mapper: ioctl: 4.47.0-ioctl (2022-07-28) initialised: dm-devel@redhat.com
2024-10-30T07:52:16,003853+00:00 systemd[1]: Finished modprobe@efi_pstore.service - Load Kernel Module efi_pstore.
2024-10-30T07:52:16,020615+00:00 systemd[1]: Finished systemd-fsck-root.service - File System Check on Root Device.
2024-10-30T07:52:16,023115+00:00 systemd[1]: Starting systemd-remount-fs.service - Remount Root and Kernel File Systems...
2024-10-30T07:52:16,024316+00:00 systemd[1]: modprobe@dm_mod.service: Deactivated successfully.
2024-10-30T07:52:16,025088+00:00 systemd[1]: Finished modprobe@dm_mod.service - Load Kernel Module dm_mod.
2024-10-30T07:52:16,027147+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2024-10-30T07:52:16,038277+00:00 fuse: init (API version 7.38)
2024-10-30T07:52:16,044640+00:00 loop: module loaded
2024-10-30T07:52:16,079757+00:00 systemd-journald[875]: Received client request to flush runtime journal.
2024-10-30T07:52:16,326585+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0C:00/input/input0
2024-10-30T07:52:16,331866+00:00 ACPI: button: Power Button [PWRB]
2024-10-30T07:52:16,332303+00:00 input: Sleep Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0E:00/input/input1
2024-10-30T07:52:16,333504+00:00 ACPI: button: Sleep Button [SLPB]
2024-10-30T07:52:16,334248+00:00 ACPI: \_SB_.PCI0.GSI1: Enabled at IRQ 36
2024-10-30T07:52:16,334674+00:00 ena 0000:00:05.0: Elastic Network Adapter (ENA) v2.13.0g
2024-10-30T07:52:16,335213+00:00 ena 0000:00:05.0: enabling device (0010 -> 0012)
2024-10-30T07:52:16,357357+00:00 ena 0000:00:05.0: ENA device version: 0.10
2024-10-30T07:52:16,357815+00:00 ena 0000:00:05.0: ENA controller version: 0.0.1 implementation version 1
2024-10-30T07:52:16,445544+00:00 ena 0000:00:05.0: LLQ is not supported Fallback to host mode policy.
2024-10-30T07:52:16,456881+00:00 ena 0000:00:05.0: Elastic Network Adapter (ENA) found at mem 80004000, mac addr 06:97:71:d8:d0:25
2024-10-30T07:52:16,515641+00:00 ena 0000:00:05.0 ens5: renamed from eth0
2024-10-30T07:52:17,041311+00:00 RPC: Registered named UNIX socket transport module.
2024-10-30T07:52:17,041840+00:00 RPC: Registered udp transport module.
2024-10-30T07:52:17,042225+00:00 RPC: Registered tcp transport module.
2024-10-30T07:52:17,042609+00:00 RPC: Registered tcp NFSv4.1 backchannel transport module.
2024-10-30T07:52:17,263030+00:00 ena 0000:00:05.0 ens5: Local page cache is disabled for less than 16 channels
2024-10-30T07:52:17,264057+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): ens5: link becomes ready
2024-10-30T07:52:38,041469+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-30T07:52:38,086055+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): enid337da96432: link becomes ready
2024-10-30T07:52:38,086678+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-30T07:52:42,036677+00:00 pci 0000:00:06.0: [1d0f:ec20] type 00 class 0x020000
2024-10-30T07:52:42,037269+00:00 pci 0000:00:06.0: reg 0x10: [mem 0x00000000-0x00003fff]
2024-10-30T07:52:42,037998+00:00 pci 0000:00:06.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-30T07:52:42,038695+00:00 pci 0000:00:06.0: BAR 0: assigned [mem 0x8000c000-0x8000ffff]
2024-10-30T07:52:42,039418+00:00 ena 0000:00:06.0: enabling device (0000 -> 0002)
2024-10-30T07:52:42,050985+00:00 ena 0000:00:06.0: ENA device version: 0.10
2024-10-30T07:52:42,051464+00:00 ena 0000:00:06.0: ENA controller version: 0.0.1 implementation version 1
2024-10-30T07:52:42,122842+00:00 ena 0000:00:06.0: LLQ is not supported Fallback to host mode policy.
2024-10-30T07:52:42,134136+00:00 ena 0000:00:06.0: Elastic Network Adapter (ENA) found at mem 8000c000, mac addr 06:fe:d7:31:44:4d
2024-10-30T07:52:42,182988+00:00 ena 0000:00:06.0 ens6: renamed from eth0
2024-10-30T07:52:42,225207+00:00 ena 0000:00:06.0 ens6: Local page cache is disabled for less than 16 channels
2024-10-30T08:02:25,362496+00:00 Initializing XFRM netlink socket
2024-10-30T08:02:25,769519+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): cilium_host: link becomes ready
2024-10-30T08:02:26,751097+00:00 cilium_vxlan: Caught tx_queue_len zero misconfig
2024-10-30T08:02:28,236608+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2024-10-30T08:02:29,474776+00:00 eth0: renamed from tmp08cf8
2024-10-30T08:02:29,515481+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcfdf821e6f549: link becomes ready
2024-10-30T08:02:29,575535+00:00 eth0: renamed from tmp6f689
2024-10-30T08:02:29,634768+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc15178237e8bd: link becomes ready
2024-10-30T08:05:18,243416+00:00 eth0: renamed from tmp1e993
2024-10-30T08:05:18,302542+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-30T08:05:18,303100+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc1b541ac810e3: link becomes ready
2024-10-30T08:09:56,948952+00:00 eth0: renamed from tmp83c9d
2024-10-30T08:09:56,998641+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-30T08:09:56,999209+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcdcf0f9a0bcc1: link becomes ready
2024-10-30T08:22:50,617131+00:00 printk: dmesg (8707): Attempt to access syslog with CAP_SYS_ADMIN but no CAP_SYSLOG (deprecated).
