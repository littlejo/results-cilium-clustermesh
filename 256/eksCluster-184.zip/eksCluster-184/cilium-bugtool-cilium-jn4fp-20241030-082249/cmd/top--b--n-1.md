top - 08:22:51 up 30 min,  0 users,  load average: 0.49, 0.40, 0.25
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 66.7 us, 23.3 sy,  0.0 ni, 10.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4475.1 free,   1192.8 used,   2146.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6436.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 392352  77824 S 106.7   4.9   0:50.26 cilium-+
    621 root      20   0 1229640  11104   4004 S   6.7   0.1   0:00.01 gops
    402 root      20   0 1229488   8020   3836 S   0.0   0.1   0:01.11 cilium-+
    636 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    666 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    676 root      20   0 1240432  16248  11292 S   0.0   0.2   0:00.02 cilium-+
    682 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    713 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    732 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
