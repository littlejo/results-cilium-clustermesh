markdown output at /tmp/cilium-bugtool-20241030-082250.885+0000-UTC-1828962044/cmd/cilium-debuginfo-20241030-082322.039+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082250.885+0000-UTC-1828962044/cmd/cilium-debuginfo-20241030-082322.039+0000-UTC.json
