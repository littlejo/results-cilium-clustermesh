Endpoint ID: 89
Path: /sys/fs/bpf/tc/globals/cilium_policy_00089

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11560492   116388    0        
Allow    Ingress     1          ANY          NONE         disabled    11120102   117543    0        
Allow    Egress      0          ANY          NONE         disabled    14455765   141176    0        


Endpoint ID: 135
Path: /sys/fs/bpf/tc/globals/cilium_policy_00135

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1653236   20879     0        
Allow    Ingress     1          ANY          NONE         disabled    18925     226       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 978
Path: /sys/fs/bpf/tc/globals/cilium_policy_00978

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    119911   1377      0        
Allow    Egress      0          ANY          NONE         disabled    16914    184       0        


Endpoint ID: 1275
Path: /sys/fs/bpf/tc/globals/cilium_policy_01275

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    119449   1370      0        
Allow    Egress      0          ANY          NONE         disabled    17455    189       0        


Endpoint ID: 2087
Path: /sys/fs/bpf/tc/globals/cilium_policy_02087

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


