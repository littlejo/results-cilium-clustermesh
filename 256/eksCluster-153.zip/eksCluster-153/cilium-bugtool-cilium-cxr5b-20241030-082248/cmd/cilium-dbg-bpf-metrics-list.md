REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36420     2884230     677    bpf_overlay.c
Interface                 INGRESS     650742    133052593   1132   bpf_host.c
Success                   EGRESS      16545     1302518     1694   bpf_host.c
Success                   EGRESS      279123    34654555    1308   bpf_lxc.c
Success                   EGRESS      36841     2914501     53     encap.h
Success                   INGRESS     321940    36411158    86     l3.h
Success                   INGRESS     342466    38036916    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
