xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 557
ens6(5) clsact/ingress cil_from_netdev-ens6 id 564
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 550
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 542
cilium_host(7) clsact/egress cil_from_host-cilium_host id 539
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 581
lxc2f087b740930(12) clsact/ingress cil_from_container-lxc2f087b740930 id 524
lxc16e0a97ea5dd(14) clsact/ingress cil_from_container-lxc16e0a97ea5dd id 579
lxccebbb93f55fa(18) clsact/ingress cil_from_container-lxccebbb93f55fa id 649

flow_dissector:

netfilter:

