KEY             VALUE
AgentLiveness   1938256601342
UTimeOffset     3379442699218750
