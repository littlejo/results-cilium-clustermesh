CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod886e928d_446c_4085_ad38_a8e3ab2ee94d.slice/cri-containerd-c2857a6d4f814eb927273ba958c9f20279d700de3617c3dfa25b43c476af1988.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod886e928d_446c_4085_ad38_a8e3ab2ee94d.slice/cri-containerd-d1c153137f978e5f2b36aa5d6ccba8a3cf15bd8fac3df12cf4874ebd469145c8.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a97ba69_9b08_4f64_b1e7_c129eacd1fc3.slice/cri-containerd-17a7628e89ad7c5bf2549b39c2e317bee655b3881a157fca477f2c98beea2991.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a97ba69_9b08_4f64_b1e7_c129eacd1fc3.slice/cri-containerd-1bc454b1fed5dd45881b2f4dd2402acd959137dbeeed469807cff17ee924f853.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b8c4162_b757_4954_ad3f_8364bb9135ad.slice/cri-containerd-6ea2e9693f1782620591bd8760fb60c4fe4b9cd20a580dd01e81ae0e89f4c832.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b8c4162_b757_4954_ad3f_8364bb9135ad.slice/cri-containerd-8e11cdbd00dc216954c2d0fc649bd744605d01b571964edad52307f9f4cb0468.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod120a1ec4_b839_4929_8f5e_fe828adeb379.slice/cri-containerd-ed097e18de1d6858a719ca74519c1e7d26c0ef6e2f62f64bb96b9c85ee81d30c.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod120a1ec4_b839_4929_8f5e_fe828adeb379.slice/cri-containerd-748a431aaf1baac7098cc23cfad973cbc91192a9a222433486a9fe6c51bc3235.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc6342763_900a_4f89_9420_960f8abbd56d.slice/cri-containerd-224e127a31c4b908c356bf626ea08931950258521e296822b2b5f2e49442d570.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc6342763_900a_4f89_9420_960f8abbd56d.slice/cri-containerd-3310e37c9665e6fe510f8fcb14dd336db066b9f87702dce794009fe2054d4fd2.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc6342763_900a_4f89_9420_960f8abbd56d.slice/cri-containerd-f77823c2dac08ad6195be8fd8e08c94d128852a143f717cc6adba97e8fec60fe.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc6342763_900a_4f89_9420_960f8abbd56d.slice/cri-containerd-78fc5fe5cb04603e6287f52f1014eee523cf7641d433c05a60db73f2e2ff7f59.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61a581f7_5952_4aa8_b50c_45d713e21428.slice/cri-containerd-de11155e9287cd7c29b71e86dc8613f571e9dcdecfb7afadbb8c3fa7bfb28036.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61a581f7_5952_4aa8_b50c_45d713e21428.slice/cri-containerd-fe9602491fba2db3ba6bc7aa78747f7e25a11ef31a7f171ed260332786fc2d4d.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd49d69f_45ec_4c84_97ac_f8ea84bb3cb9.slice/cri-containerd-1f88ef4075ee05da7717c732f36ac7bd5dfa31b74af454e3c1d28cf9ab541fec.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd49d69f_45ec_4c84_97ac_f8ea84bb3cb9.slice/cri-containerd-d3562b92f32ead0f0ad8cf245a2ef65ad016d66bf7fcb4356f86356d63d445de.scope
    101      cgroup_device   multi                                          
