[
  {
    "containers": [
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc6342763_900a_4f89_9420_960f8abbd56d.slice/cri-containerd-78fc5fe5cb04603e6287f52f1014eee523cf7641d433c05a60db73f2e2ff7f59.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc6342763_900a_4f89_9420_960f8abbd56d.slice/cri-containerd-f77823c2dac08ad6195be8fd8e08c94d128852a143f717cc6adba97e8fec60fe.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc6342763_900a_4f89_9420_960f8abbd56d.slice/cri-containerd-3310e37c9665e6fe510f8fcb14dd336db066b9f87702dce794009fe2054d4fd2.scope"
      }
    ],
    "ips": [
      "10.153.0.83"
    ],
    "name": "clustermesh-apiserver-6c84d948bd-stvck",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod886e928d_446c_4085_ad38_a8e3ab2ee94d.slice/cri-containerd-c2857a6d4f814eb927273ba958c9f20279d700de3617c3dfa25b43c476af1988.scope"
      }
    ],
    "ips": [
      "10.153.0.180"
    ],
    "name": "coredns-cc6ccd49c-jp8zl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a97ba69_9b08_4f64_b1e7_c129eacd1fc3.slice/cri-containerd-1bc454b1fed5dd45881b2f4dd2402acd959137dbeeed469807cff17ee924f853.scope"
      }
    ],
    "ips": [
      "10.153.0.70"
    ],
    "name": "coredns-cc6ccd49c-294gq",
    "namespace": "kube-system"
  }
]

