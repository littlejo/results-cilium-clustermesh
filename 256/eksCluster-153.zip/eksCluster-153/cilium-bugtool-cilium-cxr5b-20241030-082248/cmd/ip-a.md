1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:18:93:43:c2:7b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.218.179/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3503sec preferred_lft 3503sec
    inet6 fe80::818:93ff:fe43:c27b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:30:c2:4e:ad:83 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.192.13/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::830:c2ff:fe4e:ad83/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:5b:38:1a:34:b0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::585b:38ff:fe1a:34b0/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:8f:71:a9:58:2b brd ff:ff:ff:ff:ff:ff
    inet 10.153.0.134/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::488f:71ff:fea9:582b/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f6:19:59:44:9a:e8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f419:59ff:fe44:9ae8/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:70:7d:d2:01:6a brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c070:7dff:fed2:16a/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc2f087b740930@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:d9:00:77:c4:c6 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a8d9:ff:fe77:c4c6/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc16e0a97ea5dd@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:16:fa:50:01:09 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d416:faff:fe50:109/64 scope link 
       valid_lft forever preferred_lft forever
18: lxccebbb93f55fa@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:d3:78:6a:52:f6 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::24d3:78ff:fe6a:52f6/64 scope link 
       valid_lft forever preferred_lft forever
