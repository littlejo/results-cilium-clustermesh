markdown output at /tmp/cilium-bugtool-20241030-082249.739+0000-UTC-2960495933/cmd/cilium-debuginfo-20241030-082320.764+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082249.739+0000-UTC-2960495933/cmd/cilium-debuginfo-20241030-082320.764+0000-UTC.json
