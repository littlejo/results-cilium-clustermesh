{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:36.689Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.192.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:36.689Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.218.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:36.689Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.566Z",
  "value": "id=1851  sec_id=5071351 flags=0x0000 ifindex=12  mac=EE:90:47:7D:9A:42 nodemac=AA:D9:00:77:C4:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.568Z",
  "value": "id=959   sec_id=4     flags=0x0000 ifindex=10  mac=C6:9C:39:C8:B5:01 nodemac=C2:70:7D:D2:01:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.632Z",
  "value": "id=2546  sec_id=5071351 flags=0x0000 ifindex=14  mac=0A:D8:F2:4C:6A:93 nodemac=D6:16:FA:50:01:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.645Z",
  "value": "id=959   sec_id=4     flags=0x0000 ifindex=10  mac=C6:9C:39:C8:B5:01 nodemac=C2:70:7D:D2:01:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:20.404Z",
  "value": "id=1851  sec_id=5071351 flags=0x0000 ifindex=12  mac=EE:90:47:7D:9A:42 nodemac=AA:D9:00:77:C4:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:20.405Z",
  "value": "id=2546  sec_id=5071351 flags=0x0000 ifindex=14  mac=0A:D8:F2:4C:6A:93 nodemac=D6:16:FA:50:01:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:20.406Z",
  "value": "id=959   sec_id=4     flags=0x0000 ifindex=10  mac=C6:9C:39:C8:B5:01 nodemac=C2:70:7D:D2:01:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:20.436Z",
  "value": "id=1395  sec_id=5047956 flags=0x0000 ifindex=16  mac=CE:16:16:6B:C4:F7 nodemac=8E:E0:CD:18:71:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:21.404Z",
  "value": "id=1395  sec_id=5047956 flags=0x0000 ifindex=16  mac=CE:16:16:6B:C4:F7 nodemac=8E:E0:CD:18:71:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:21.405Z",
  "value": "id=959   sec_id=4     flags=0x0000 ifindex=10  mac=C6:9C:39:C8:B5:01 nodemac=C2:70:7D:D2:01:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:21.405Z",
  "value": "id=2546  sec_id=5071351 flags=0x0000 ifindex=14  mac=0A:D8:F2:4C:6A:93 nodemac=D6:16:FA:50:01:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:21.405Z",
  "value": "id=1851  sec_id=5071351 flags=0x0000 ifindex=12  mac=EE:90:47:7D:9A:42 nodemac=AA:D9:00:77:C4:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.192Z",
  "value": "id=1114  sec_id=5047956 flags=0x0000 ifindex=18  mac=4A:4E:13:82:44:1D nodemac=26:D3:78:6A:52:F6"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.153.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.557Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.538Z",
  "value": "id=959   sec_id=4     flags=0x0000 ifindex=10  mac=C6:9C:39:C8:B5:01 nodemac=C2:70:7D:D2:01:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.538Z",
  "value": "id=1851  sec_id=5071351 flags=0x0000 ifindex=12  mac=EE:90:47:7D:9A:42 nodemac=AA:D9:00:77:C4:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.538Z",
  "value": "id=2546  sec_id=5071351 flags=0x0000 ifindex=14  mac=0A:D8:F2:4C:6A:93 nodemac=D6:16:FA:50:01:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.539Z",
  "value": "id=1114  sec_id=5047956 flags=0x0000 ifindex=18  mac=4A:4E:13:82:44:1D nodemac=26:D3:78:6A:52:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.575Z",
  "value": "id=959   sec_id=4     flags=0x0000 ifindex=10  mac=C6:9C:39:C8:B5:01 nodemac=C2:70:7D:D2:01:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.602Z",
  "value": "id=1851  sec_id=5071351 flags=0x0000 ifindex=12  mac=EE:90:47:7D:9A:42 nodemac=AA:D9:00:77:C4:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.603Z",
  "value": "id=2546  sec_id=5071351 flags=0x0000 ifindex=14  mac=0A:D8:F2:4C:6A:93 nodemac=D6:16:FA:50:01:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.606Z",
  "value": "id=1114  sec_id=5047956 flags=0x0000 ifindex=18  mac=4A:4E:13:82:44:1D nodemac=26:D3:78:6A:52:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.538Z",
  "value": "id=2546  sec_id=5071351 flags=0x0000 ifindex=14  mac=0A:D8:F2:4C:6A:93 nodemac=D6:16:FA:50:01:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.539Z",
  "value": "id=959   sec_id=4     flags=0x0000 ifindex=10  mac=C6:9C:39:C8:B5:01 nodemac=C2:70:7D:D2:01:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.539Z",
  "value": "id=1114  sec_id=5047956 flags=0x0000 ifindex=18  mac=4A:4E:13:82:44:1D nodemac=26:D3:78:6A:52:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.539Z",
  "value": "id=1851  sec_id=5071351 flags=0x0000 ifindex=12  mac=EE:90:47:7D:9A:42 nodemac=AA:D9:00:77:C4:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.539Z",
  "value": "id=1851  sec_id=5071351 flags=0x0000 ifindex=12  mac=EE:90:47:7D:9A:42 nodemac=AA:D9:00:77:C4:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.539Z",
  "value": "id=2546  sec_id=5071351 flags=0x0000 ifindex=14  mac=0A:D8:F2:4C:6A:93 nodemac=D6:16:FA:50:01:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.540Z",
  "value": "id=1114  sec_id=5047956 flags=0x0000 ifindex=18  mac=4A:4E:13:82:44:1D nodemac=26:D3:78:6A:52:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.153.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.540Z",
  "value": "id=959   sec_id=4     flags=0x0000 ifindex=10  mac=C6:9C:39:C8:B5:01 nodemac=C2:70:7D:D2:01:6A"
}

