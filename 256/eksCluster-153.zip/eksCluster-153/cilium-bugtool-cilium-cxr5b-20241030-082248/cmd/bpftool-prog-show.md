35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:51:04+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:04+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:04+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:51:05+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:51:06+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:51:06+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:51:06+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:51:06+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:51:10+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:51:23+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:00:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:00:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:00:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:00:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:01:39+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 124
485: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:01:39+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
486: sched_cls  name tail_handle_ipv4  tag 893d6706427f783a  gpl
	loaded_at 2024-10-30T08:01:39+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
487: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:01:39+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
516: sched_cls  name tail_handle_ipv4_cont  tag 783ea75a560bb0b2  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,111,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 163
517: sched_cls  name __send_drop_notify  tag 2efb80bc8510702f  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 164
520: sched_cls  name handle_policy  tag e9ef4782800357d3  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,111,41,80,109,39,84,75,40,37,38
	btf_id 165
521: sched_cls  name tail_handle_ipv4  tag 387fe0b4b82bdcb5  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 168
523: sched_cls  name tail_ipv4_ct_ingress  tag d2d0e507823cb294  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,111,84
	btf_id 169
524: sched_cls  name cil_from_container  tag ffe10f3d4a457a09  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 171
528: sched_cls  name tail_ipv4_ct_egress  tag 13776c7d670194d9  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,111,84
	btf_id 173
529: sched_cls  name tail_handle_arp  tag 45194570fcfc8cf2  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 176
532: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 177
536: sched_cls  name tail_ipv4_to_endpoint  tag 9dec438eca654464  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,111,41,82,83,80,109,39,113,40,37,38
	btf_id 180
538: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,116
	btf_id 185
539: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,116
	btf_id 186
541: sched_cls  name __send_drop_notify  tag d50a3f011beab68c  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 188
542: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 189
543: sched_cls  name tail_handle_ipv4_from_host  tag ec5ac9de5a483b03  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,116
	btf_id 190
546: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 196
549: sched_cls  name __send_drop_notify  tag d50a3f011beab68c  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
550: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 200
551: sched_cls  name tail_handle_ipv4_from_host  tag ec5ac9de5a483b03  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 201
554: sched_cls  name __send_drop_notify  tag d50a3f011beab68c  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
556: sched_cls  name tail_handle_ipv4_from_host  tag ec5ac9de5a483b03  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 207
557: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 208
558: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 209
561: sched_cls  name __send_drop_notify  tag d50a3f011beab68c  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 213
563: sched_cls  name tail_handle_ipv4_from_host  tag ec5ac9de5a483b03  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 215
564: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 216
565: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 217
566: sched_cls  name handle_policy  tag ade354a71dec7407  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,118,82,83,117,41,80,114,39,84,75,40,37,38
	btf_id 195
567: sched_cls  name __send_drop_notify  tag e860e815ec2b9e9a  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 220
568: sched_cls  name tail_ipv4_ct_egress  tag 13776c7d670194d9  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 221
569: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,118
	btf_id 222
571: sched_cls  name tail_handle_ipv4  tag ef7a0567f1aa6339  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,126
	btf_id 219
573: sched_cls  name __send_drop_notify  tag 8dcdd0ead5f27917  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 226
574: sched_cls  name tail_handle_ipv4  tag e2305e7f23fe16ba  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,118
	btf_id 224
575: sched_cls  name tail_handle_ipv4_cont  tag 5ec1169b281fdc6d  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,117,41,114,82,83,39,76,74,77,118,40,37,38,81
	btf_id 228
576: sched_cls  name tail_handle_arp  tag 04ed508594bffe2c  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,118
	btf_id 229
577: sched_cls  name tail_ipv4_ct_ingress  tag 3f6257022dff3639  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 230
578: sched_cls  name handle_policy  tag b888e90085a56b2b  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,126,82,83,125,41,80,100,39,84,75,40,37,38
	btf_id 227
579: sched_cls  name cil_from_container  tag 11b4361901097121  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 118,76
	btf_id 231
580: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 232
581: sched_cls  name cil_from_container  tag d956819a24be8ddf  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 126,76
	btf_id 234
582: sched_cls  name tail_ipv4_to_endpoint  tag b724ff935792196f  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,117,41,82,83,80,114,39,118,40,37,38
	btf_id 233
583: sched_cls  name tail_ipv4_to_endpoint  tag 08c4c30a2ab063cc  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,125,41,82,83,80,100,39,126,40,37,38
	btf_id 235
584: sched_cls  name tail_ipv4_ct_ingress  tag 4d64188d1e9e67bb  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 236
585: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,126
	btf_id 237
586: sched_cls  name tail_handle_ipv4_cont  tag 481fa20374ff3264  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,125,41,100,82,83,39,76,74,77,126,40,37,38,81
	btf_id 238
587: sched_cls  name tail_handle_arp  tag fc3e9f14eeeb1d64  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,126
	btf_id 239
588: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
591: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
592: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
595: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
596: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
599: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
643: sched_cls  name tail_handle_ipv4  tag a8000bb68c0b15bb  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 253
644: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 254
645: sched_cls  name tail_ipv4_to_endpoint  tag be2c99323abf3ab6  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 255
646: sched_cls  name tail_handle_arp  tag a60287e41f6f8df2  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 256
647: sched_cls  name tail_handle_ipv4_cont  tag a0fc5e05aac9e7af  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 257
648: sched_cls  name __send_drop_notify  tag a65b9eb25484a812  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 258
649: sched_cls  name cil_from_container  tag 74e0989e7627aa3c  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 259
651: sched_cls  name handle_policy  tag bd0a746c1d4b6423  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 261
652: sched_cls  name tail_ipv4_ct_egress  tag 726e8150d0d429da  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 262
653: sched_cls  name tail_ipv4_ct_ingress  tag 1d50fd3fde0aede8  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 263
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
670: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
673: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
674: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
677: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
678: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
681: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
