{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:34.328Z",
  "value": "1 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:34.328Z",
  "value": "2 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:34.328Z",
  "value": "0 2 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.33.65:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:34.328Z",
  "value": "0 0 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:34.328Z",
  "value": "0 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:34.328Z",
  "value": "0 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.33.65:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:37.596Z",
  "value": "3 0 (2) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.33.65:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:37.596Z",
  "value": "0 1 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.879Z",
  "value": "0 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.879Z",
  "value": "0 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.934Z",
  "value": "4 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.934Z",
  "value": "0 1 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.934Z",
  "value": "5 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.934Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.876Z",
  "value": "4 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.876Z",
  "value": "0 1 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.876Z",
  "value": "5 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.876Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.898Z",
  "value": "4 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.898Z",
  "value": "6 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.898Z",
  "value": "0 2 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.898Z",
  "value": "5 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.898Z",
  "value": "7 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.898Z",
  "value": "0 2 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.245.104:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:16.102Z",
  "value": "0 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.245.104:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:27.223Z",
  "value": "0 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.245.104:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:31.237Z",
  "value": "8 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.245.104:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:31.237Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.245.104:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.940Z",
  "value": "8 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.245.104:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.940Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.245.104:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.027Z",
  "value": "8 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.245.104:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.027Z",
  "value": "9 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.245.104:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.027Z",
  "value": "0 2 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.245.104:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.149Z",
  "value": "9 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.245.104:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.149Z",
  "value": "8 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.245.104:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.149Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.245.104:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.652Z",
  "value": "9 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.245.104:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.652Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.245.104:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.652Z",
  "value": "\u003cnil\u003e"
}

