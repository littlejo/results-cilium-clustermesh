alloc: 132.88MB (139331880 bytes)
total-alloc: 2.29GB (2456432144 bytes)
sys: 333.02MB (349196644 bytes)
lookups: 0
mallocs: 64134572
frees: 63105456
heap-alloc: 132.88MB (139331880 bytes)
heap-sys: 255.32MB (267722752 bytes)
heap-idle: 71.80MB (75292672 bytes)
heap-in-use: 183.52MB (192430080 bytes)
heap-released: 7.11MB (7454720 bytes)
heap-objects: 1029116
stack-in-use: 64.66MB (67796992 bytes)
stack-sys: 64.66MB (67796992 bytes)
stack-mspan-inuse: 2.86MB (3003200 bytes)
stack-mspan-sys: 3.89MB (4080000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.17MB (1231217 bytes)
gc-sys: 6.00MB (6295064 bytes)
next-gc: when heap-alloc >= 212.16MB (222469912 bytes)
last-gc: 2024-10-30 08:23:06.138332103 +0000 UTC
gc-pause-total: 10.287404ms
gc-pause: 112560
gc-pause-end: 1730276586138332103
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0005475161264295636
enable-gc: true
debug-gc: false
