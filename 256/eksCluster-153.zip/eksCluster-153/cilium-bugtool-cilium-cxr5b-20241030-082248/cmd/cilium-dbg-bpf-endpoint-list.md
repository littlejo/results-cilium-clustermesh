IP ADDRESS         LOCAL ENDPOINT INFO
10.153.0.134:0     (localhost)                                                                                        
10.153.0.83:0      id=1114  sec_id=5047956 flags=0x0000 ifindex=18  mac=4A:4E:13:82:44:1D nodemac=26:D3:78:6A:52:F6   
172.31.218.179:0   (localhost)                                                                                        
10.153.0.55:0      id=959   sec_id=4     flags=0x0000 ifindex=10  mac=C6:9C:39:C8:B5:01 nodemac=C2:70:7D:D2:01:6A     
172.31.192.13:0    (localhost)                                                                                        
10.153.0.70:0      id=2546  sec_id=5071351 flags=0x0000 ifindex=14  mac=0A:D8:F2:4C:6A:93 nodemac=D6:16:FA:50:01:09   
10.153.0.180:0     id=1851  sec_id=5071351 flags=0x0000 ifindex=12  mac=EE:90:47:7D:9A:42 nodemac=AA:D9:00:77:C4:C6   
