top - 08:22:49 up 31 min,  0 users,  load average: 0.05, 0.22, 0.20
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s):  3.8 us, 26.9 sy,  0.0 ni, 69.2 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4471.9 free,   1195.9 used,   2146.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6433.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 382696  78268 S   6.7   4.8   0:50.20 cilium-+
    642 root      20   0 1240432  16028  11292 S   6.7   0.2   0:00.03 cilium-+
    392 root      20   0 1229488   6916   2864 S   0.0   0.1   0:01.13 cilium-+
    611 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    623 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    641 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    686 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    697 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    715 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
