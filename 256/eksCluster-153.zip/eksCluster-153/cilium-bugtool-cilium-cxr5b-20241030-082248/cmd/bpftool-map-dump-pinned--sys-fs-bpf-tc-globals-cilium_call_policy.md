key: bf 03 00 00  value: 42 02 00 00
key: 5a 04 00 00  value: 8b 02 00 00
key: 3b 07 00 00  value: 08 02 00 00
key: f2 09 00 00  value: 36 02 00 00
Found 4 elements
