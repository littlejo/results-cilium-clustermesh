goroutines: 10827
OS threads: 19
GOMAXPROCS: 2
num CPU: 2
