Endpoint ID: 375
Path: /sys/fs/bpf/tc/globals/cilium_policy_00375

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 959
Path: /sys/fs/bpf/tc/globals/cilium_policy_00959

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1629970   20579     0        
Allow    Ingress     1          ANY          NONE         disabled    19382     229       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1114
Path: /sys/fs/bpf/tc/globals/cilium_policy_01114

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11523228   115477    0        
Allow    Ingress     1          ANY          NONE         disabled    10518072   111097    0        
Allow    Egress      0          ANY          NONE         disabled    13796224   135167    0        


Endpoint ID: 1851
Path: /sys/fs/bpf/tc/globals/cilium_policy_01851

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    124396   1427      0        
Allow    Egress      0          ANY          NONE         disabled    17454    190       0        


Endpoint ID: 2546
Path: /sys/fs/bpf/tc/globals/cilium_policy_02546

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    123877   1423      0        
Allow    Egress      0          ANY          NONE         disabled    17678    193       0        


