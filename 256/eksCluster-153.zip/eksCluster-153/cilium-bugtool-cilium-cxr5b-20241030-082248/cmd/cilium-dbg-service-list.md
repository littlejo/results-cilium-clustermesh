ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.159.143:443 (active)    
                                          2 => 172.31.198.222:443 (active)    
2    10.100.33.65:443      ClusterIP      1 => 172.31.218.179:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.153.0.180:53 (active)       
                                          2 => 10.153.0.70:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.153.0.180:9153 (active)     
                                          2 => 10.153.0.70:9153 (active)      
5    10.100.245.104:2379   ClusterIP      1 => 10.153.0.83:2379 (active)      
