32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:50:42+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:50:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:50:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:50:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:50:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:50:42+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:50:43+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:50:43+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:50:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:50:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:50:43+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:50:43+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:50:47+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:50:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:50:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:51:00+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:00:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:00:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:00:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:00:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:00:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:00:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name tail_handle_ipv4  tag b8fea319cb2bbaa7  gpl
	loaded_at 2024-10-30T08:01:23+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
482: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:01:23+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 125
483: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:01:23+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:01:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
514: sched_cls  name tail_handle_arp  tag 1ee33ef93ddc667d  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 164
515: sched_cls  name tail_ipv4_ct_ingress  tag 78359bdd7a7da9ec  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 165
516: sched_cls  name __send_drop_notify  tag fc933934af9da077  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 166
519: sched_cls  name tail_ipv4_to_endpoint  tag c6f3e8658667ca21  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,111,40,37,38
	btf_id 167
521: sched_cls  name tail_handle_ipv4  tag 1ab0315ab89bb1b1  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 170
526: sched_cls  name handle_policy  tag 2710e1b92098b893  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 172
527: sched_cls  name tail_handle_ipv4_cont  tag b9f1aeffff2b923e  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,111,40,37,38,81
	btf_id 177
528: sched_cls  name cil_from_container  tag 5c6d9aaf4d562368  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 178
529: sched_cls  name tail_ipv4_ct_egress  tag 55aa2af5b1241a28  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 179
530: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 180
535: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 186
536: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,117
	btf_id 187
537: sched_cls  name tail_handle_ipv4_from_host  tag f0c238bb7b9b17f1  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 188
540: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 192
541: sched_cls  name __send_drop_notify  tag 38bba120e56cd430  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 193
544: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 197
545: sched_cls  name __send_drop_notify  tag 38bba120e56cd430  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 198
546: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 199
548: sched_cls  name tail_handle_ipv4_from_host  tag f0c238bb7b9b17f1  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 201
549: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 203
552: sched_cls  name __send_drop_notify  tag 38bba120e56cd430  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
553: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 207
555: sched_cls  name tail_handle_ipv4_from_host  tag f0c238bb7b9b17f1  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 209
556: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 211
558: sched_cls  name tail_handle_ipv4_from_host  tag f0c238bb7b9b17f1  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 213
559: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 214
562: sched_cls  name __send_drop_notify  tag 38bba120e56cd430  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 217
563: sched_cls  name handle_policy  tag 4a945d7535a02da1  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 189
565: sched_cls  name tail_handle_arp  tag f24d0255b50de69f  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 221
566: sched_cls  name cil_from_container  tag ad8c93967061fd29  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 125,76
	btf_id 222
567: sched_cls  name tail_ipv4_ct_ingress  tag aa663ca18ce88beb  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 219
568: sched_cls  name tail_handle_ipv4  tag 8d9fa746552573e5  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 223
569: sched_cls  name tail_handle_ipv4_cont  tag 76f160a6523f7a3a  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,126,41,100,82,83,39,76,74,77,125,40,37,38,81
	btf_id 225
570: sched_cls  name tail_ipv4_to_endpoint  tag e9e0637dd31fea01  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 224
571: sched_cls  name cil_from_container  tag 6a3766f6e69a53c2  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 226
573: sched_cls  name tail_ipv4_to_endpoint  tag 40a47010d39691a2  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,126,41,82,83,80,100,39,125,40,37,38
	btf_id 229
574: sched_cls  name tail_ipv4_ct_egress  tag 55aa2af5b1241a28  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 227
575: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 230
576: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 231
577: sched_cls  name __send_drop_notify  tag 513b4e04b85519b5  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 232
578: sched_cls  name tail_handle_arp  tag 5a7e6cb3b3f67fdd  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 234
579: sched_cls  name tail_handle_ipv4_cont  tag eef9700d6690272b  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 235
580: sched_cls  name tail_ipv4_ct_ingress  tag 33667eac8bd318e0  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 233
581: sched_cls  name tail_handle_ipv4  tag fff33348763df67a  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 236
582: sched_cls  name handle_policy  tag d25180b65b703c94  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,125,82,83,126,41,80,100,39,84,75,40,37,38
	btf_id 237
583: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 238
584: sched_cls  name __send_drop_notify  tag e7d2fb2592ba8c00  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 239
585: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
588: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
589: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
592: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: sched_cls  name cil_from_container  tag b8d48d081a45df33  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 253
641: sched_cls  name tail_ipv4_to_endpoint  tag af00e8a49f08e6b6  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 254
642: sched_cls  name tail_ipv4_ct_ingress  tag 80c4dddcb9ef406c  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 255
643: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 256
644: sched_cls  name tail_handle_ipv4_cont  tag c763b29bc5e432ba  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 257
645: sched_cls  name tail_handle_arp  tag ef9af6764a1c3e58  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 258
646: sched_cls  name handle_policy  tag 7764dc417c6d2ed5  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 259
647: sched_cls  name tail_ipv4_ct_egress  tag 3b1bda0f8d2d1e49  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 260
648: sched_cls  name tail_handle_ipv4  tag 50c29ac65323c4f8  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 261
650: sched_cls  name __send_drop_notify  tag a149e93b22153aa8  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 263
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
667: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
670: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
671: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
674: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
