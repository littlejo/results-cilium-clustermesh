{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:21.305Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.194.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:21.305Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.216.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:21.305Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:26.139Z",
  "value": "id=3823  sec_id=5205008 flags=0x0000 ifindex=12  mac=8A:82:7B:3D:F1:5E nodemac=AA:68:87:55:D9:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:26.143Z",
  "value": "id=1237  sec_id=4     flags=0x0000 ifindex=10  mac=CE:CB:89:ED:37:BF nodemac=EE:C2:1D:C6:9D:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:26.223Z",
  "value": "id=1144  sec_id=5205008 flags=0x0000 ifindex=14  mac=DA:A7:FD:2D:E2:79 nodemac=F2:C4:25:F2:C3:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:26.233Z",
  "value": "id=1237  sec_id=4     flags=0x0000 ifindex=10  mac=CE:CB:89:ED:37:BF nodemac=EE:C2:1D:C6:9D:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:08.599Z",
  "value": "id=1144  sec_id=5205008 flags=0x0000 ifindex=14  mac=DA:A7:FD:2D:E2:79 nodemac=F2:C4:25:F2:C3:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:08.600Z",
  "value": "id=1237  sec_id=4     flags=0x0000 ifindex=10  mac=CE:CB:89:ED:37:BF nodemac=EE:C2:1D:C6:9D:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:08.601Z",
  "value": "id=3823  sec_id=5205008 flags=0x0000 ifindex=12  mac=8A:82:7B:3D:F1:5E nodemac=AA:68:87:55:D9:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:08.629Z",
  "value": "id=398   sec_id=5196468 flags=0x0000 ifindex=16  mac=5E:74:09:81:3B:7C nodemac=0A:6E:40:30:38:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:08.629Z",
  "value": "id=398   sec_id=5196468 flags=0x0000 ifindex=16  mac=5E:74:09:81:3B:7C nodemac=0A:6E:40:30:38:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:09.599Z",
  "value": "id=398   sec_id=5196468 flags=0x0000 ifindex=16  mac=5E:74:09:81:3B:7C nodemac=0A:6E:40:30:38:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:09.599Z",
  "value": "id=1237  sec_id=4     flags=0x0000 ifindex=10  mac=CE:CB:89:ED:37:BF nodemac=EE:C2:1D:C6:9D:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:09.600Z",
  "value": "id=3823  sec_id=5205008 flags=0x0000 ifindex=12  mac=8A:82:7B:3D:F1:5E nodemac=AA:68:87:55:D9:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:09.600Z",
  "value": "id=1144  sec_id=5205008 flags=0x0000 ifindex=14  mac=DA:A7:FD:2D:E2:79 nodemac=F2:C4:25:F2:C3:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.222Z",
  "value": "id=2372  sec_id=5196468 flags=0x0000 ifindex=18  mac=26:20:66:3D:B6:2B nodemac=7A:83:3D:A0:DB:7D"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.157.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.660Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.256Z",
  "value": "id=2372  sec_id=5196468 flags=0x0000 ifindex=18  mac=26:20:66:3D:B6:2B nodemac=7A:83:3D:A0:DB:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.270Z",
  "value": "id=1237  sec_id=4     flags=0x0000 ifindex=10  mac=CE:CB:89:ED:37:BF nodemac=EE:C2:1D:C6:9D:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.271Z",
  "value": "id=3823  sec_id=5205008 flags=0x0000 ifindex=12  mac=8A:82:7B:3D:F1:5E nodemac=AA:68:87:55:D9:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.271Z",
  "value": "id=1144  sec_id=5205008 flags=0x0000 ifindex=14  mac=DA:A7:FD:2D:E2:79 nodemac=F2:C4:25:F2:C3:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.256Z",
  "value": "id=1237  sec_id=4     flags=0x0000 ifindex=10  mac=CE:CB:89:ED:37:BF nodemac=EE:C2:1D:C6:9D:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.256Z",
  "value": "id=3823  sec_id=5205008 flags=0x0000 ifindex=12  mac=8A:82:7B:3D:F1:5E nodemac=AA:68:87:55:D9:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.257Z",
  "value": "id=1144  sec_id=5205008 flags=0x0000 ifindex=14  mac=DA:A7:FD:2D:E2:79 nodemac=F2:C4:25:F2:C3:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.257Z",
  "value": "id=2372  sec_id=5196468 flags=0x0000 ifindex=18  mac=26:20:66:3D:B6:2B nodemac=7A:83:3D:A0:DB:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:33.247Z",
  "value": "id=1237  sec_id=4     flags=0x0000 ifindex=10  mac=CE:CB:89:ED:37:BF nodemac=EE:C2:1D:C6:9D:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:33.248Z",
  "value": "id=1144  sec_id=5205008 flags=0x0000 ifindex=14  mac=DA:A7:FD:2D:E2:79 nodemac=F2:C4:25:F2:C3:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:33.248Z",
  "value": "id=2372  sec_id=5196468 flags=0x0000 ifindex=18  mac=26:20:66:3D:B6:2B nodemac=7A:83:3D:A0:DB:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:33.248Z",
  "value": "id=3823  sec_id=5205008 flags=0x0000 ifindex=12  mac=8A:82:7B:3D:F1:5E nodemac=AA:68:87:55:D9:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:34.249Z",
  "value": "id=1144  sec_id=5205008 flags=0x0000 ifindex=14  mac=DA:A7:FD:2D:E2:79 nodemac=F2:C4:25:F2:C3:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:34.249Z",
  "value": "id=2372  sec_id=5196468 flags=0x0000 ifindex=18  mac=26:20:66:3D:B6:2B nodemac=7A:83:3D:A0:DB:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:34.249Z",
  "value": "id=1237  sec_id=4     flags=0x0000 ifindex=10  mac=CE:CB:89:ED:37:BF nodemac=EE:C2:1D:C6:9D:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.157.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:34.249Z",
  "value": "id=3823  sec_id=5205008 flags=0x0000 ifindex=12  mac=8A:82:7B:3D:F1:5E nodemac=AA:68:87:55:D9:30"
}

