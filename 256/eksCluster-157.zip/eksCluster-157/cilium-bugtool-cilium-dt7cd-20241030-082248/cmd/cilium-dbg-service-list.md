ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.223.186:443 (active)    
                                          2 => 172.31.184.90:443 (active)     
2    10.100.163.244:443    ClusterIP      1 => 172.31.194.176:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.157.0.106:9153 (active)     
                                          2 => 10.157.0.178:9153 (active)     
4    10.100.0.10:53        ClusterIP      1 => 10.157.0.106:53 (active)       
                                          2 => 10.157.0.178:53 (active)       
5    10.100.228.250:2379   ClusterIP      1 => 10.157.0.73:2379 (active)      
