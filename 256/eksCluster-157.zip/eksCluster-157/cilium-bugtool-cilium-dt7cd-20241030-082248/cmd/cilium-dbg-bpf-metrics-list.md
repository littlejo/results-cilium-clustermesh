REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34021     2686539     677    bpf_overlay.c
Interface                 INGRESS     621696    129327822   1132   bpf_host.c
Success                   EGRESS      13982     1093697     1694   bpf_host.c
Success                   EGRESS      263987    33243402    1308   bpf_lxc.c
Success                   EGRESS      32998     2610682     53     encap.h
Success                   INGRESS     303946    34248562    86     l3.h
Success                   INGRESS     324636    35885450    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
