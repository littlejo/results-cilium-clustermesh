filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf84af438b20c direct-action not_in_hw id 571 tag 6a3766f6e69a53c2 jited 
