IP ADDRESS         LOCAL ENDPOINT INFO
10.157.0.73:0      id=2372  sec_id=5196468 flags=0x0000 ifindex=18  mac=26:20:66:3D:B6:2B nodemac=7A:83:3D:A0:DB:7D   
10.157.0.165:0     (localhost)                                                                                        
10.157.0.178:0     id=1144  sec_id=5205008 flags=0x0000 ifindex=14  mac=DA:A7:FD:2D:E2:79 nodemac=F2:C4:25:F2:C3:D0   
172.31.194.176:0   (localhost)                                                                                        
172.31.216.238:0   (localhost)                                                                                        
10.157.0.106:0     id=3823  sec_id=5205008 flags=0x0000 ifindex=12  mac=8A:82:7B:3D:F1:5E nodemac=AA:68:87:55:D9:30   
10.157.0.50:0      id=1237  sec_id=4     flags=0x0000 ifindex=10  mac=CE:CB:89:ED:37:BF nodemac=EE:C2:1D:C6:9D:65     
