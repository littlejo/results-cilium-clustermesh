CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3a40770d_a08f_473e_9d7b_b24c2cc02ea1.slice/cri-containerd-619f907e72f799976b849917374241db1020ccc23140decf314cad6ec8df4ed8.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3a40770d_a08f_473e_9d7b_b24c2cc02ea1.slice/cri-containerd-f86db8419089a1695a11018d884fbb71393b249c573295f5f1dceba4319e4d58.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56c2d299_cff2_42e7_83ef_0a684bdadc89.slice/cri-containerd-fe5dda0879e49b83fdf84792dab1f4225ef2f8bea4ea5ee7d1a558ccb8a61b73.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56c2d299_cff2_42e7_83ef_0a684bdadc89.slice/cri-containerd-97186f64dbb3e105832216b2a0b20097b4b280b5a5eade4c7968c234c4debde2.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8060d1e6_57cb_47a5_81a5_ab7ac415ee56.slice/cri-containerd-cd99457c5abb6b1c02b2006007bb413e4606cebd3cf617f383dc79ef4c49b3a0.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8060d1e6_57cb_47a5_81a5_ab7ac415ee56.slice/cri-containerd-4e80a125142cd13ebfe9b59ee8b666aa37fa7010e00781cadb312e246b1c908c.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf702c329_770c_48fd_b9ab_f75a224347bc.slice/cri-containerd-a1f3c261415074d6e2a86f25c1c59c5755dfbf6a11f0e68579fabb3031cee984.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf702c329_770c_48fd_b9ab_f75a224347bc.slice/cri-containerd-92fd5e8ecb584e3415f70a3ca6d140d6a2d6c96bbb8bac63a764cf210e84bcdb.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod353dcf6b_1fd7_4cd8_8f66_95851e21b120.slice/cri-containerd-d1ca473bd58103b43d72ca04edaeceac5e3918ca71a2759c93b070737cea16b1.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod353dcf6b_1fd7_4cd8_8f66_95851e21b120.slice/cri-containerd-d52713b3a9d71465d8af0782bf988167f010b5ac80040ce50c194447386eeee0.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2cd7f7ba_9325_4ff4_a811_5f29496fcd7e.slice/cri-containerd-b88909539069593b7748152f46a0de6196de539c93c5c05e584f6023efdaff2a.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2cd7f7ba_9325_4ff4_a811_5f29496fcd7e.slice/cri-containerd-b91890230999b1e25127057e312b56c3a4e71e8f77907a662ec025489ba5236a.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2cd7f7ba_9325_4ff4_a811_5f29496fcd7e.slice/cri-containerd-1e2febe85129c00130d7c98e127e676813ccf8015799ec996dfacabce4d1c249.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2cd7f7ba_9325_4ff4_a811_5f29496fcd7e.slice/cri-containerd-80d38ddef49e6bf0fe5f10ca546e06287d5a2fa4cb2ace677d5d83a9a0fed2d9.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda74de3f4_15db_409b_8eab_9ce2447b40af.slice/cri-containerd-b316078983caceb14cdc80ea8ef4ac6a4653badf8ebc4bed53e0e2004e1eeecc.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda74de3f4_15db_409b_8eab_9ce2447b40af.slice/cri-containerd-d6eaf15f0f659318c26a9216358a165dd2b4a16955412d3d4741d2a759df2825.scope
    102      cgroup_device   multi                                          
