1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:f0:e4:33:3d:c5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.194.176/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3480sec preferred_lft 3480sec
    inet6 fe80::8f0:e4ff:fe33:3dc5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:cd:19:9e:06:37 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.216.238/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8cd:19ff:fe9e:637/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:60:1d:eb:33:3b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6060:1dff:feeb:333b/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:98:a0:19:95:49 brd ff:ff:ff:ff:ff:ff
    inet 10.157.0.165/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::8098:a0ff:fe19:9549/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 86:db:1f:de:4a:60 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::84db:1fff:fede:4a60/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:c2:1d:c6:9d:65 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::ecc2:1dff:fec6:9d65/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc9a69e2dc1a3d@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:68:87:55:d9:30 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a868:87ff:fe55:d930/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcf84af438b20c@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:c4:25:f2:c3:d0 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::f0c4:25ff:fef2:c3d0/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc5a238ee4bd37@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:83:3d:a0:db:7d brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7883:3dff:fea0:db7d/64 scope link 
       valid_lft forever preferred_lft forever
