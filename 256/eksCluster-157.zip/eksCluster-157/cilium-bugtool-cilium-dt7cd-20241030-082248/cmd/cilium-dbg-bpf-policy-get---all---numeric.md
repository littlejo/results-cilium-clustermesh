Endpoint ID: 72
Path: /sys/fs/bpf/tc/globals/cilium_policy_00072

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1144
Path: /sys/fs/bpf/tc/globals/cilium_policy_01144

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    124963   1432      0        
Allow    Egress      0          ANY          NONE         disabled    16061    174       0        


Endpoint ID: 1237
Path: /sys/fs/bpf/tc/globals/cilium_policy_01237

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1641614   20749     0        
Allow    Ingress     1          ANY          NONE         disabled    18550     217       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2372
Path: /sys/fs/bpf/tc/globals/cilium_policy_02372

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11448155   113139    0        
Allow    Ingress     1          ANY          NONE         disabled    9406146    98448     0        
Allow    Egress      0          ANY          NONE         disabled    11864904   117516    0        


Endpoint ID: 3823
Path: /sys/fs/bpf/tc/globals/cilium_policy_03823

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    124435   1424      0        
Allow    Egress      0          ANY          NONE         disabled    17296    188       0        


