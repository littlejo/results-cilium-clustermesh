alloc: 192.73MB (202089280 bytes)
total-alloc: 2.18GB (2340776744 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 62326812
frees: 60326168
heap-alloc: 192.73MB (202089280 bytes)
heap-sys: 251.67MB (263897088 bytes)
heap-idle: 33.37MB (34988032 bytes)
heap-in-use: 218.30MB (228909056 bytes)
heap-released: 632.00KB (647168 bytes)
heap-objects: 2000644
stack-in-use: 64.28MB (67403776 bytes)
stack-sys: 64.28MB (67403776 bytes)
stack-mspan-inuse: 3.41MB (3572960 bytes)
stack-mspan-sys: 3.94MB (4128960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.15MB (1204345 bytes)
gc-sys: 6.02MB (6317568 bytes)
next-gc: when heap-alloc >= 225.06MB (235991064 bytes)
last-gc: 2024-10-30 08:22:49.744405551 +0000 UTC
gc-pause-total: 13.524632ms
gc-pause: 98496
gc-pause-end: 1730276569744405551
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005381898064834205
enable-gc: true
debug-gc: false
