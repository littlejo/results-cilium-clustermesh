USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         672  0.0  0.2 1240432 16448 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         687  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         688  0.0  0.2 1240432 16448 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         650  0.0  0.0 1228744 3776 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         649  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.5  4.8 1606336 388432 ?      Ssl  08:01   0:46 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.0  0.1 1229744 8148 ?        Sl   08:01   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
