[
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2cd7f7ba_9325_4ff4_a811_5f29496fcd7e.slice/cri-containerd-b88909539069593b7748152f46a0de6196de539c93c5c05e584f6023efdaff2a.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2cd7f7ba_9325_4ff4_a811_5f29496fcd7e.slice/cri-containerd-b91890230999b1e25127057e312b56c3a4e71e8f77907a662ec025489ba5236a.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2cd7f7ba_9325_4ff4_a811_5f29496fcd7e.slice/cri-containerd-1e2febe85129c00130d7c98e127e676813ccf8015799ec996dfacabce4d1c249.scope"
      }
    ],
    "ips": [
      "10.157.0.73"
    ],
    "name": "clustermesh-apiserver-7bcc8c7c66-f4zxs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7830,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56c2d299_cff2_42e7_83ef_0a684bdadc89.slice/cri-containerd-97186f64dbb3e105832216b2a0b20097b4b280b5a5eade4c7968c234c4debde2.scope"
      }
    ],
    "ips": [
      "10.157.0.178"
    ],
    "name": "coredns-cc6ccd49c-29678",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7746,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3a40770d_a08f_473e_9d7b_b24c2cc02ea1.slice/cri-containerd-f86db8419089a1695a11018d884fbb71393b249c573295f5f1dceba4319e4d58.scope"
      }
    ],
    "ips": [
      "10.157.0.106"
    ],
    "name": "coredns-cc6ccd49c-xgwhx",
    "namespace": "kube-system"
  }
]

