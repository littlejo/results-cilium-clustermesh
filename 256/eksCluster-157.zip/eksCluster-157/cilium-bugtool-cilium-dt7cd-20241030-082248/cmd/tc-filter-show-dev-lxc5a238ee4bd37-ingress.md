filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc5a238ee4bd37 direct-action not_in_hw id 640 tag b8d48d081a45df33 jited 
