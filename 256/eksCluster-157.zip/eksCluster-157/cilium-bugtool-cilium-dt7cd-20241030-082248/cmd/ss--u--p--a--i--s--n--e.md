Total: 661
TCP:   1841 (estab 423, closed 1399, orphaned 0, timewait 561)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  442       432       10       
INET	  452       438       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:42907      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=39)) ino:36196 sk:3eb fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.194.176%ens5:68         0.0.0.0:*    uid:192 ino:75156 sk:3ec cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:37461 sk:3ed cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15582 sk:3ee cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:37460 sk:3ef cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15583 sk:3f0 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::8f0:e4ff:fe33:3dc5]%ens5:546           [::]:*    uid:192 ino:15669 sk:3f1 cgroup:unreachable:c4e v6only:1 <->                   
