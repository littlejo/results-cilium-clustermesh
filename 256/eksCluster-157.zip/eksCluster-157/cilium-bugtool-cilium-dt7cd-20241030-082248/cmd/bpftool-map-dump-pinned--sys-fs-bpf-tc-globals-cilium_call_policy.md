key: 78 04 00 00  value: 33 02 00 00
key: d5 04 00 00  value: 46 02 00 00
key: 44 09 00 00  value: 86 02 00 00
key: ef 0e 00 00  value: 0e 02 00 00
Found 4 elements
