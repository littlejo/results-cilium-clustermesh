markdown output at /tmp/cilium-bugtool-20241030-082259.14+0000-UTC-2321691188/cmd/cilium-debuginfo-20241030-082301.282+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082259.14+0000-UTC-2321691188/cmd/cilium-debuginfo-20241030-082301.282+0000-UTC.json
