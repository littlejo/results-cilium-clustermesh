top - 08:22:59 up 37 min,  0 users,  load average: 0.52, 0.38, 0.24
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 70.0 us, 16.7 sy,  0.0 ni, 13.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4516.2 free,   1181.7 used,   2116.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6447.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606144 380796  78968 S  93.3   4.8   0:47.61 cilium-+
    662 root      20   0 1240432  16584  11292 S   6.7   0.2   0:00.03 cilium-+
    407 root      20   0 1229488   7168   3052 S   0.0   0.1   0:01.08 cilium-+
    638 root      20   0 1228744   3656   2976 S   0.0   0.0   0:00.00 gops
    645 root      20   0 1229000   3776   3104 S   0.0   0.0   0:00.00 gops
    688 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    706 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    707 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
