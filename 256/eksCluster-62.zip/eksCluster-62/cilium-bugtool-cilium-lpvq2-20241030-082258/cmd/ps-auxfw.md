USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         662  0.0  0.2 1240432 16368 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         676  0.0  0.0   3852  1292 ?        R    08:22   0:00  \_ bash -c cat /proc/net/xfrm_stat
root         677  0.0  0.0   6408  1644 ?        R    08:22   0:00  \_ ps auxfw
root         645  0.0  0.0 1229000 3776 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         638  0.0  0.0 1228744 3656 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  2.5  4.7 1606144 378728 ?      Ssl  07:52   0:47 cilium-agent --config-dir=/tmp/cilium/config-map
root         407  0.0  0.0 1229488 7168 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
