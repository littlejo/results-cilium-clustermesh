CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod31343e8d_ef96_4796_852b_be4262500dd7.slice/cri-containerd-b80d5c4e86f89d8351c6e16d7f9435d121bdeeba393585e7e74cb39ac6352daa.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod31343e8d_ef96_4796_852b_be4262500dd7.slice/cri-containerd-210b1dd723e673093da3f4171313c58fc94a50943184790aafb32d3da54271b1.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod39ae7ade_31fd_428b_baab_78b120928e8e.slice/cri-containerd-752c99e1a6e0b3e44161f8567ed569fcff369da9fb7a1c3cb4255b9af22ac2b4.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod39ae7ade_31fd_428b_baab_78b120928e8e.slice/cri-containerd-6aa71051363c44fc2e23c5d17ca93e8e32b96db7f0580b48e7779de514aef792.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0f7ed4a_0ff2_4b00_850b_faf7e21f14fc.slice/cri-containerd-5ff65f2ec00b83fb25f2dbe4af0f7b9713d9fd238bbb62fe991ec2f0bfd74551.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0f7ed4a_0ff2_4b00_850b_faf7e21f14fc.slice/cri-containerd-92983ce201c19abd177df314177af4519543eab9558782533be9e2b069e4f0cd.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e266f0c_2805_40c7_9395_5616bbb825c3.slice/cri-containerd-b2bdb1d3f92ef6cc2d1a3459c8446b73a4c8c135b18a453eb41e9022f009476c.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e266f0c_2805_40c7_9395_5616bbb825c3.slice/cri-containerd-0813ca8885876fffaec2c064c470f40f131a3d806fd916edd2ab42055deb90c6.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod126b85b3_8d22_40a6_b95f_73ace2669132.slice/cri-containerd-ca1a5728b5ac3af5a31d85623a7067b7ceaadb867face90338780ec5df4e9fc4.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod126b85b3_8d22_40a6_b95f_73ace2669132.slice/cri-containerd-c7ea07b155af1a57269c22bc76fe78cff7e50bfdc300f2990280a5a4e65005b7.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod764f54ad_7d20_4bd8_92f9_93865286c334.slice/cri-containerd-e16e5f93a0b793c5793e8df1f93ca563fb5d109d1ceae12f7c8e9ed6e401adbd.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod764f54ad_7d20_4bd8_92f9_93865286c334.slice/cri-containerd-41eb8216aa7812a34e3221a0a329e16f30fa957cc9ff36b63f0385a23025cb3c.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod764f54ad_7d20_4bd8_92f9_93865286c334.slice/cri-containerd-4f6a3c8fa9291042d881e41d9597229da5d24c0ac6b24bd601418cc916557140.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod764f54ad_7d20_4bd8_92f9_93865286c334.slice/cri-containerd-bcdbc3b15ea60811c41b8108f13ee3ac9f68970873ce2e34b4573a8f949a9717.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56b2c061_62f8_4ce5_a2d8_4fbf6089366c.slice/cri-containerd-7ee7559d774be7b3b19d8a7096fa623a8369087e241ed10271202b1c8334ad4c.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56b2c061_62f8_4ce5_a2d8_4fbf6089366c.slice/cri-containerd-4dd655f9deddf1cf59988a465bfefef43be7a2f70441dfc45de19480fd274963.scope
    94       cgroup_device   multi                                          
