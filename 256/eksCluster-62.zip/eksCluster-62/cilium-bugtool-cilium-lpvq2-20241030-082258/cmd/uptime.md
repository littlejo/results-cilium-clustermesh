 08:22:59 up 37 min,  0 users,  load average: 0.52, 0.38, 0.24
