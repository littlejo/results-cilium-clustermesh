Endpoint ID: 936
Path: /sys/fs/bpf/tc/globals/cilium_policy_00936

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1600992   20254     0        
Allow    Ingress     1          ANY          NONE         disabled    26500     310       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1008
Path: /sys/fs/bpf/tc/globals/cilium_policy_01008

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174179   2000      0        
Allow    Egress      0          ANY          NONE         disabled    21565    241       0        


Endpoint ID: 1606
Path: /sys/fs/bpf/tc/globals/cilium_policy_01606

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    10447850   107255    0        
Allow    Ingress     1          ANY          NONE         disabled    10152394   106827    0        
Allow    Egress      0          ANY          NONE         disabled    12098661   121767    0        


Endpoint ID: 3681
Path: /sys/fs/bpf/tc/globals/cilium_policy_03681

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174876   2016      0        
Allow    Egress      0          ANY          NONE         disabled    22240    250       0        


Endpoint ID: 3896
Path: /sys/fs/bpf/tc/globals/cilium_policy_03896

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


