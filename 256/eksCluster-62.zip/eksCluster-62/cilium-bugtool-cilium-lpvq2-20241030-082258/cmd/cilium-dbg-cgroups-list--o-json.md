[
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod764f54ad_7d20_4bd8_92f9_93865286c334.slice/cri-containerd-bcdbc3b15ea60811c41b8108f13ee3ac9f68970873ce2e34b4573a8f949a9717.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod764f54ad_7d20_4bd8_92f9_93865286c334.slice/cri-containerd-41eb8216aa7812a34e3221a0a329e16f30fa957cc9ff36b63f0385a23025cb3c.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod764f54ad_7d20_4bd8_92f9_93865286c334.slice/cri-containerd-4f6a3c8fa9291042d881e41d9597229da5d24c0ac6b24bd601418cc916557140.scope"
      }
    ],
    "ips": [
      "10.62.0.13"
    ],
    "name": "clustermesh-apiserver-6f5c6fd745-jr74h",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0f7ed4a_0ff2_4b00_850b_faf7e21f14fc.slice/cri-containerd-5ff65f2ec00b83fb25f2dbe4af0f7b9713d9fd238bbb62fe991ec2f0bfd74551.scope"
      }
    ],
    "ips": [
      "10.62.0.121"
    ],
    "name": "coredns-cc6ccd49c-7grfb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod31343e8d_ef96_4796_852b_be4262500dd7.slice/cri-containerd-b80d5c4e86f89d8351c6e16d7f9435d121bdeeba393585e7e74cb39ac6352daa.scope"
      }
    ],
    "ips": [
      "10.62.0.35"
    ],
    "name": "coredns-cc6ccd49c-nqhht",
    "namespace": "kube-system"
  }
]

