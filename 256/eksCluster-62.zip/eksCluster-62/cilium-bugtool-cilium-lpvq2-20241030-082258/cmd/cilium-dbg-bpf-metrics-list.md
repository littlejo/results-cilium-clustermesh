REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35994     2848629     677    bpf_overlay.c
Interface                 INGRESS     608282    127402967   1132   bpf_host.c
Success                   EGRESS      16312     1286203     1694   bpf_host.c
Success                   EGRESS      259583    31832400    1308   bpf_lxc.c
Success                   EGRESS      36544     2889517     53     encap.h
Success                   INGRESS     302422    33345476    86     l3.h
Success                   INGRESS     322629    34942620    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
