ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.146.193:443 (active)    
                                         2 => 172.31.234.235:443 (active)    
2    10.100.108.140:443   ClusterIP      1 => 172.31.146.191:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.62.0.121:9153 (active)      
                                         2 => 10.62.0.35:9153 (active)       
4    10.100.0.10:53       ClusterIP      1 => 10.62.0.121:53 (active)        
                                         2 => 10.62.0.35:53 (active)         
5    10.100.65.235:2379   ClusterIP      1 => 10.62.0.13:2379 (active)       
