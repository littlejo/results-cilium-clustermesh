xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 572
ens6(5) clsact/ingress cil_from_netdev-ens6 id 577
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 565
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 562
cilium_host(7) clsact/egress cil_from_host-cilium_host id 557
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 517
lxc5a169a94b161(12) clsact/ingress cil_from_container-lxc5a169a94b161 id 530
lxcc04ad7f8410c(14) clsact/ingress cil_from_container-lxcc04ad7f8410c id 538
lxc6fdd4bce0cf8(18) clsact/ingress cil_from_container-lxc6fdd4bce0cf8 id 633

flow_dissector:

netfilter:

