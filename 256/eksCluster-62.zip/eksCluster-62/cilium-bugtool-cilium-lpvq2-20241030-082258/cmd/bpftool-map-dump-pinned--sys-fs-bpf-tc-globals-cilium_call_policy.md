key: a8 03 00 00  value: 04 02 00 00
key: f0 03 00 00  value: 1e 02 00 00
key: 46 06 00 00  value: 74 02 00 00
key: 61 0e 00 00  value: 15 02 00 00
Found 4 elements
