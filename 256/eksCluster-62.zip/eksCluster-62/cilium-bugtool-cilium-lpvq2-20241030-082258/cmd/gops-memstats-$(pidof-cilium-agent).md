alloc: 175.51MB (184033824 bytes)
total-alloc: 2.27GB (2434636152 bytes)
sys: 316.83MB (332222820 bytes)
lookups: 0
mallocs: 63513731
frees: 61772106
heap-alloc: 175.51MB (184033824 bytes)
heap-sys: 239.25MB (250871808 bytes)
heap-idle: 43.34MB (45441024 bytes)
heap-in-use: 195.91MB (205430784 bytes)
heap-released: 3.38MB (3538944 bytes)
heap-objects: 1741625
stack-in-use: 64.75MB (67895296 bytes)
stack-sys: 64.75MB (67895296 bytes)
stack-mspan-inuse: 3.08MB (3229440 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.03MB (1081601 bytes)
gc-sys: 6.02MB (6313352 bytes)
next-gc: when heap-alloc >= 212.06MB (222356280 bytes)
last-gc: 2024-10-30 08:22:22.42933285 +0000 UTC
gc-pause-total: 12.244548ms
gc-pause: 117501
gc-pause-end: 1730276542429332850
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.00030668769032673565
enable-gc: true
debug-gc: false
