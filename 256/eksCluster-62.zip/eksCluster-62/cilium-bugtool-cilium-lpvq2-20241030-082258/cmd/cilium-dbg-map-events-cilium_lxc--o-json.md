{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:35.921Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.146.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:35.921Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.189.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:35.921Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:40.284Z",
  "value": "id=3681  sec_id=2067804 flags=0x0000 ifindex=12  mac=22:D4:34:B4:22:98 nodemac=2E:C9:C7:65:DD:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:40.290Z",
  "value": "id=1008  sec_id=2067804 flags=0x0000 ifindex=14  mac=6E:13:17:F6:75:F8 nodemac=FA:4E:D9:B9:85:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:40.360Z",
  "value": "id=936   sec_id=4     flags=0x0000 ifindex=10  mac=E2:C7:5A:2C:FC:41 nodemac=6E:C4:93:56:B1:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:40.453Z",
  "value": "id=3681  sec_id=2067804 flags=0x0000 ifindex=12  mac=22:D4:34:B4:22:98 nodemac=2E:C9:C7:65:DD:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:40.508Z",
  "value": "id=1008  sec_id=2067804 flags=0x0000 ifindex=14  mac=6E:13:17:F6:75:F8 nodemac=FA:4E:D9:B9:85:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:54.976Z",
  "value": "id=936   sec_id=4     flags=0x0000 ifindex=10  mac=E2:C7:5A:2C:FC:41 nodemac=6E:C4:93:56:B1:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:54.976Z",
  "value": "id=1008  sec_id=2067804 flags=0x0000 ifindex=14  mac=6E:13:17:F6:75:F8 nodemac=FA:4E:D9:B9:85:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:54.976Z",
  "value": "id=3681  sec_id=2067804 flags=0x0000 ifindex=12  mac=22:D4:34:B4:22:98 nodemac=2E:C9:C7:65:DD:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:55.010Z",
  "value": "id=605   sec_id=2093476 flags=0x0000 ifindex=16  mac=76:A6:09:EC:56:BD nodemac=BA:52:6F:91:CB:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:55.976Z",
  "value": "id=936   sec_id=4     flags=0x0000 ifindex=10  mac=E2:C7:5A:2C:FC:41 nodemac=6E:C4:93:56:B1:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:55.976Z",
  "value": "id=3681  sec_id=2067804 flags=0x0000 ifindex=12  mac=22:D4:34:B4:22:98 nodemac=2E:C9:C7:65:DD:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:55.976Z",
  "value": "id=605   sec_id=2093476 flags=0x0000 ifindex=16  mac=76:A6:09:EC:56:BD nodemac=BA:52:6F:91:CB:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:55.977Z",
  "value": "id=1008  sec_id=2067804 flags=0x0000 ifindex=14  mac=6E:13:17:F6:75:F8 nodemac=FA:4E:D9:B9:85:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:48.598Z",
  "value": "id=1606  sec_id=2093476 flags=0x0000 ifindex=18  mac=2A:49:6A:BA:A7:4A nodemac=3A:4F:A1:8F:8C:F0"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.62.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.881Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.825Z",
  "value": "id=1606  sec_id=2093476 flags=0x0000 ifindex=18  mac=2A:49:6A:BA:A7:4A nodemac=3A:4F:A1:8F:8C:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.830Z",
  "value": "id=3681  sec_id=2067804 flags=0x0000 ifindex=12  mac=22:D4:34:B4:22:98 nodemac=2E:C9:C7:65:DD:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.831Z",
  "value": "id=1008  sec_id=2067804 flags=0x0000 ifindex=14  mac=6E:13:17:F6:75:F8 nodemac=FA:4E:D9:B9:85:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.831Z",
  "value": "id=936   sec_id=4     flags=0x0000 ifindex=10  mac=E2:C7:5A:2C:FC:41 nodemac=6E:C4:93:56:B1:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.759Z",
  "value": "id=1606  sec_id=2093476 flags=0x0000 ifindex=18  mac=2A:49:6A:BA:A7:4A nodemac=3A:4F:A1:8F:8C:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.759Z",
  "value": "id=3681  sec_id=2067804 flags=0x0000 ifindex=12  mac=22:D4:34:B4:22:98 nodemac=2E:C9:C7:65:DD:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.759Z",
  "value": "id=1008  sec_id=2067804 flags=0x0000 ifindex=14  mac=6E:13:17:F6:75:F8 nodemac=FA:4E:D9:B9:85:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.760Z",
  "value": "id=936   sec_id=4     flags=0x0000 ifindex=10  mac=E2:C7:5A:2C:FC:41 nodemac=6E:C4:93:56:B1:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.760Z",
  "value": "id=936   sec_id=4     flags=0x0000 ifindex=10  mac=E2:C7:5A:2C:FC:41 nodemac=6E:C4:93:56:B1:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.760Z",
  "value": "id=1606  sec_id=2093476 flags=0x0000 ifindex=18  mac=2A:49:6A:BA:A7:4A nodemac=3A:4F:A1:8F:8C:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.760Z",
  "value": "id=3681  sec_id=2067804 flags=0x0000 ifindex=12  mac=22:D4:34:B4:22:98 nodemac=2E:C9:C7:65:DD:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.761Z",
  "value": "id=1008  sec_id=2067804 flags=0x0000 ifindex=14  mac=6E:13:17:F6:75:F8 nodemac=FA:4E:D9:B9:85:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.760Z",
  "value": "id=1008  sec_id=2067804 flags=0x0000 ifindex=14  mac=6E:13:17:F6:75:F8 nodemac=FA:4E:D9:B9:85:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.760Z",
  "value": "id=936   sec_id=4     flags=0x0000 ifindex=10  mac=E2:C7:5A:2C:FC:41 nodemac=6E:C4:93:56:B1:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.760Z",
  "value": "id=3681  sec_id=2067804 flags=0x0000 ifindex=12  mac=22:D4:34:B4:22:98 nodemac=2E:C9:C7:65:DD:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.761Z",
  "value": "id=1606  sec_id=2093476 flags=0x0000 ifindex=18  mac=2A:49:6A:BA:A7:4A nodemac=3A:4F:A1:8F:8C:F0"
}

