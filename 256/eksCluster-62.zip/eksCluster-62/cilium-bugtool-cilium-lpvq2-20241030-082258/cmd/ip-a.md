1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ff:ca:be:7e:97 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.146.191/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3151sec preferred_lft 3151sec
    inet6 fe80::4ff:caff:febe:7e97/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:64:b4:89:5c:35 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.189.191/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::464:b4ff:fe89:5c35/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:17:03:5d:a4:d9 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1417:3ff:fe5d:a4d9/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:b0:dd:a1:96:d0 brd ff:ff:ff:ff:ff:ff
    inet 10.62.0.174/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::6cb0:ddff:fea1:96d0/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 16:a4:7e:fb:07:79 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::14a4:7eff:fefb:779/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:c4:93:56:b1:f9 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::6cc4:93ff:fe56:b1f9/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc5a169a94b161@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:c9:c7:65:dd:4c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::2cc9:c7ff:fe65:dd4c/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcc04ad7f8410c@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:4e:d9:b9:85:ee brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::f84e:d9ff:feb9:85ee/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc6fdd4bce0cf8@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:4f:a1:8f:8c:f0 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::384f:a1ff:fe8f:8cf0/64 scope link 
       valid_lft forever preferred_lft forever
