Total: 670
TCP:   1835 (estab 419, closed 1397, orphaned 0, timewait 569)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  438       426       12       
INET	  448       432       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:43999      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:31915 sk:3f0 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.146.191%ens5:68         0.0.0.0:*    uid:192 ino:64874 sk:3f1 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:32025 sk:3f2 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15327 sk:3f3 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:32024 sk:3f4 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15328 sk:3f5 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::4ff:caff:febe:7e97]%ens5:546           [::]:*    uid:192 ino:16508 sk:3f6 cgroup:unreachable:c4e v6only:1 <->                   
