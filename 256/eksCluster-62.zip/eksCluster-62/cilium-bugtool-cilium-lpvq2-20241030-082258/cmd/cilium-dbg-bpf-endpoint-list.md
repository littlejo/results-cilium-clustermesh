IP ADDRESS         LOCAL ENDPOINT INFO
10.62.0.121:0      id=1008  sec_id=2067804 flags=0x0000 ifindex=14  mac=6E:13:17:F6:75:F8 nodemac=FA:4E:D9:B9:85:EE   
10.62.0.35:0       id=3681  sec_id=2067804 flags=0x0000 ifindex=12  mac=22:D4:34:B4:22:98 nodemac=2E:C9:C7:65:DD:4C   
172.31.189.191:0   (localhost)                                                                                        
10.62.0.188:0      id=936   sec_id=4     flags=0x0000 ifindex=10  mac=E2:C7:5A:2C:FC:41 nodemac=6E:C4:93:56:B1:F9     
10.62.0.13:0       id=1606  sec_id=2093476 flags=0x0000 ifindex=18  mac=2A:49:6A:BA:A7:4A nodemac=3A:4F:A1:8F:8C:F0   
172.31.146.191:0   (localhost)                                                                                        
10.62.0.174:0      (localhost)                                                                                        
