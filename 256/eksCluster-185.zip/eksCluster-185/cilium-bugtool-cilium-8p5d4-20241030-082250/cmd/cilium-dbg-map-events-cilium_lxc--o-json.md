{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:06.498Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.223.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:06.498Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.238.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:06.498Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:10.865Z",
  "value": "id=2312  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:86:CD:2E:2E nodemac=06:A4:8F:C9:4B:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:10.869Z",
  "value": "id=353   sec_id=6116657 flags=0x0000 ifindex=12  mac=7A:83:86:95:58:1B nodemac=4E:2D:46:E0:AB:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:10.928Z",
  "value": "id=2249  sec_id=6116657 flags=0x0000 ifindex=14  mac=62:1F:3A:1B:6E:BF nodemac=D2:C6:35:DC:DF:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:10.966Z",
  "value": "id=2312  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:86:CD:2E:2E nodemac=06:A4:8F:C9:4B:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:11.062Z",
  "value": "id=353   sec_id=6116657 flags=0x0000 ifindex=12  mac=7A:83:86:95:58:1B nodemac=4E:2D:46:E0:AB:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:45.669Z",
  "value": "id=2312  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:86:CD:2E:2E nodemac=06:A4:8F:C9:4B:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:45.670Z",
  "value": "id=353   sec_id=6116657 flags=0x0000 ifindex=12  mac=7A:83:86:95:58:1B nodemac=4E:2D:46:E0:AB:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:45.671Z",
  "value": "id=2249  sec_id=6116657 flags=0x0000 ifindex=14  mac=62:1F:3A:1B:6E:BF nodemac=D2:C6:35:DC:DF:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:45.701Z",
  "value": "id=1747  sec_id=6103824 flags=0x0000 ifindex=16  mac=92:44:96:87:18:DA nodemac=C2:7C:33:09:D9:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:46.670Z",
  "value": "id=2312  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:86:CD:2E:2E nodemac=06:A4:8F:C9:4B:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:46.670Z",
  "value": "id=1747  sec_id=6103824 flags=0x0000 ifindex=16  mac=92:44:96:87:18:DA nodemac=C2:7C:33:09:D9:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:46.670Z",
  "value": "id=353   sec_id=6116657 flags=0x0000 ifindex=12  mac=7A:83:86:95:58:1B nodemac=4E:2D:46:E0:AB:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:46.671Z",
  "value": "id=2249  sec_id=6116657 flags=0x0000 ifindex=14  mac=62:1F:3A:1B:6E:BF nodemac=D2:C6:35:DC:DF:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.848Z",
  "value": "id=3266  sec_id=6103824 flags=0x0000 ifindex=18  mac=26:2C:DE:5F:D3:3B nodemac=06:9D:3C:0B:09:DF"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.185.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.244Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:22.879Z",
  "value": "id=3266  sec_id=6103824 flags=0x0000 ifindex=18  mac=26:2C:DE:5F:D3:3B nodemac=06:9D:3C:0B:09:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:22.880Z",
  "value": "id=2312  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:86:CD:2E:2E nodemac=06:A4:8F:C9:4B:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:22.881Z",
  "value": "id=353   sec_id=6116657 flags=0x0000 ifindex=12  mac=7A:83:86:95:58:1B nodemac=4E:2D:46:E0:AB:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:22.881Z",
  "value": "id=2249  sec_id=6116657 flags=0x0000 ifindex=14  mac=62:1F:3A:1B:6E:BF nodemac=D2:C6:35:DC:DF:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.879Z",
  "value": "id=2249  sec_id=6116657 flags=0x0000 ifindex=14  mac=62:1F:3A:1B:6E:BF nodemac=D2:C6:35:DC:DF:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.880Z",
  "value": "id=353   sec_id=6116657 flags=0x0000 ifindex=12  mac=7A:83:86:95:58:1B nodemac=4E:2D:46:E0:AB:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.886Z",
  "value": "id=2312  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:86:CD:2E:2E nodemac=06:A4:8F:C9:4B:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.886Z",
  "value": "id=3266  sec_id=6103824 flags=0x0000 ifindex=18  mac=26:2C:DE:5F:D3:3B nodemac=06:9D:3C:0B:09:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.880Z",
  "value": "id=3266  sec_id=6103824 flags=0x0000 ifindex=18  mac=26:2C:DE:5F:D3:3B nodemac=06:9D:3C:0B:09:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.880Z",
  "value": "id=353   sec_id=6116657 flags=0x0000 ifindex=12  mac=7A:83:86:95:58:1B nodemac=4E:2D:46:E0:AB:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.880Z",
  "value": "id=2312  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:86:CD:2E:2E nodemac=06:A4:8F:C9:4B:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.880Z",
  "value": "id=2249  sec_id=6116657 flags=0x0000 ifindex=14  mac=62:1F:3A:1B:6E:BF nodemac=D2:C6:35:DC:DF:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.880Z",
  "value": "id=2312  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:86:CD:2E:2E nodemac=06:A4:8F:C9:4B:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.880Z",
  "value": "id=3266  sec_id=6103824 flags=0x0000 ifindex=18  mac=26:2C:DE:5F:D3:3B nodemac=06:9D:3C:0B:09:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.880Z",
  "value": "id=353   sec_id=6116657 flags=0x0000 ifindex=12  mac=7A:83:86:95:58:1B nodemac=4E:2D:46:E0:AB:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.185.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.880Z",
  "value": "id=2249  sec_id=6116657 flags=0x0000 ifindex=14  mac=62:1F:3A:1B:6E:BF nodemac=D2:C6:35:DC:DF:39"
}

