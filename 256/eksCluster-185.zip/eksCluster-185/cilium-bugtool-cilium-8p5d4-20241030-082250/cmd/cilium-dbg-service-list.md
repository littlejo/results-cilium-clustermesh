ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.159.245:443 (active)   
                                          2 => 172.31.247.143:443 (active)   
2    10.100.239.159:443    ClusterIP      1 => 172.31.238.57:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.185.0.104:53 (active)      
                                          2 => 10.185.0.208:53 (active)      
4    10.100.0.10:9153      ClusterIP      1 => 10.185.0.104:9153 (active)    
                                          2 => 10.185.0.208:9153 (active)    
5    10.100.162.184:2379   ClusterIP      1 => 10.185.0.5:2379 (active)      
