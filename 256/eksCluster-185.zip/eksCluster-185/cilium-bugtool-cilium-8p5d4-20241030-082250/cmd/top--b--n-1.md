top - 08:22:51 up 29 min,  0 users,  load average: 0.20, 0.25, 0.20
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 26.7 us, 33.3 sy,  0.0 ni, 36.7 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4481.3 free,   1185.8 used,   2147.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6443.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 388916  78012 S   6.7   4.9   0:51.21 cilium-+
    671 root      20   0 1240432  16336  11228 S   6.7   0.2   0:00.03 cilium-+
    395 root      20   0 1229744   7180   2864 S   0.0   0.1   0:01.13 cilium-+
    659 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    665 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    688 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    713 root      20   0    6576   2420   2096 R   0.0   0.0   0:00.00 top
    731 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
