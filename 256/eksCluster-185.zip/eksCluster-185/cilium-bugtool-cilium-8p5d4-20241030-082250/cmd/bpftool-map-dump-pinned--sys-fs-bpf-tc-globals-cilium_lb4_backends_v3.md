key: 07 00 00 00  value: 0a b9 00 68 00 35 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a b9 00 05 09 4b 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 9f f5 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a b9 00 68 23 c1 00 00  00 00 00 00
key: 08 00 00 00  value: 0a b9 00 d0 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a b9 00 d0 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f f7 8f 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f ee 39 10 94 00 00  00 00 00 00
Found 8 elements
