alloc: 176.23MB (184786408 bytes)
total-alloc: 2.33GB (2500511848 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 64854004
frees: 62773467
heap-alloc: 176.23MB (184786408 bytes)
heap-sys: 247.23MB (259235840 bytes)
heap-idle: 48.38MB (50724864 bytes)
heap-in-use: 198.85MB (208510976 bytes)
heap-released: 3.74MB (3923968 bytes)
heap-objects: 2080537
stack-in-use: 64.75MB (67895296 bytes)
stack-sys: 64.75MB (67895296 bytes)
stack-mspan-inuse: 3.42MB (3585440 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.00MB (1052625 bytes)
gc-sys: 6.00MB (6292920 bytes)
next-gc: when heap-alloc >= 212.04MB (222343704 bytes)
last-gc: 2024-10-30 08:22:53.045779419 +0000 UTC
gc-pause-total: 7.204466ms
gc-pause: 81912
gc-pause-end: 1730276573045779419
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0004625108977741009
enable-gc: true
debug-gc: false
