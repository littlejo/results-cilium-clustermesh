CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1d41cd5a_02e4_4327_9742_ac83e0bfe98b.slice/cri-containerd-99fec20e4b9aead75b75cef03eefafcb5e062029d4b078ac2745f8f26d8b5171.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1d41cd5a_02e4_4327_9742_ac83e0bfe98b.slice/cri-containerd-a3b238fd2da42becc303dbf9a5cede2f89ec643b73eadae3b1de0df93828448f.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod11f96d25_b836_453e_b5c9_fccfee5f407d.slice/cri-containerd-11f73ad51979571ff122d263fda540a9d24af6891ccec294f309d0d52ba0138c.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod11f96d25_b836_453e_b5c9_fccfee5f407d.slice/cri-containerd-a2dc71f446eaefc8b120efc1b208125d94fb3cd41f702c7b80a691d88058d7f9.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcad4bc96_a084_4d20_ae98_d8b0bfe9eb23.slice/cri-containerd-26626f27badccd45308a603634fb2c4c9c0771c634a4144c6b29df60135b57cd.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcad4bc96_a084_4d20_ae98_d8b0bfe9eb23.slice/cri-containerd-4a3d479e2355aa1f0b1a38498829184d9e14d8c6babade1024a4e320322d763c.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaabeeb8a_c1f5_48a0_ba20_9ce1ecfda3ab.slice/cri-containerd-fe9e225c7c93bb1b1b76e051a8034bb6f69807844e48743d9869dc86e6a6d1cd.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaabeeb8a_c1f5_48a0_ba20_9ce1ecfda3ab.slice/cri-containerd-5b4542a61769d8361b0561c4e279c30c80ddc4e889e5232007eedec46d38c5c8.scope
    545      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3eda2f14_5d85_43ab_abbc_9d606b7ab66e.slice/cri-containerd-a73b2a0ac1ba05ab7dfb42108ae79dc6af731db596fbfd94792fb8b6e2d63fc7.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3eda2f14_5d85_43ab_abbc_9d606b7ab66e.slice/cri-containerd-8ccf5605fc84cfd2774ec7f2b9c373ed95eff85536e0c7d50038ce6be3ea5f7f.scope
    110      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3cf5ce0_f96f_4634_a89d_87f0ed5fe11f.slice/cri-containerd-959a214de65d67fb3588b59ddc0424b94ae8e9bcfea90c10d663d8b34b3f99ba.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3cf5ce0_f96f_4634_a89d_87f0ed5fe11f.slice/cri-containerd-e996956f542594b6ecd50c8da2ea0c1a0998af06b1529f15cf14a348fc8db8c8.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3cf5ce0_f96f_4634_a89d_87f0ed5fe11f.slice/cri-containerd-d2416fe2066b29a3152aa1e42ce0a69dc0681a9cd3b3397bb90b0082dcdb7b16.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3cf5ce0_f96f_4634_a89d_87f0ed5fe11f.slice/cri-containerd-18834142c3e218a28e32210a4ded3231c1890ab7354492fd708ee6210db75b27.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1d996cb2_cfd4_4545_8a19_87536a4eda1f.slice/cri-containerd-4c41a4b37c622d9710febfdafde05ab9f8af6b1b6d0dbdee8a5047da0f01cde3.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1d996cb2_cfd4_4545_8a19_87536a4eda1f.slice/cri-containerd-cf748958edbafea87b822cf21ab548db467198b37dabea9b91b4bf4c4fde0b1e.scope
    94       cgroup_device   multi                                          
