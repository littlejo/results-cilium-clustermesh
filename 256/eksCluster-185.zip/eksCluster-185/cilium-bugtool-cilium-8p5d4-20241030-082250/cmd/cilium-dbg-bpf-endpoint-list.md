IP ADDRESS        LOCAL ENDPOINT INFO
10.185.0.59:0     id=2312  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:86:CD:2E:2E nodemac=06:A4:8F:C9:4B:82     
10.185.0.104:0    id=353   sec_id=6116657 flags=0x0000 ifindex=12  mac=7A:83:86:95:58:1B nodemac=4E:2D:46:E0:AB:BF   
10.185.0.208:0    id=2249  sec_id=6116657 flags=0x0000 ifindex=14  mac=62:1F:3A:1B:6E:BF nodemac=D2:C6:35:DC:DF:39   
172.31.223.47:0   (localhost)                                                                                        
10.185.0.5:0      id=3266  sec_id=6103824 flags=0x0000 ifindex=18  mac=26:2C:DE:5F:D3:3B nodemac=06:9D:3C:0B:09:DF   
10.185.0.231:0    (localhost)                                                                                        
172.31.238.57:0   (localhost)                                                                                        
