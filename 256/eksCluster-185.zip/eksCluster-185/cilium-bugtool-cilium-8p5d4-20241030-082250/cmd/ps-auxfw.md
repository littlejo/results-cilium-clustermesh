USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         688  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         671  2.0  0.2 1240432 16108 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         701  0.0  0.0   3852  1292 ?        R    08:22   0:00  \_ bash -c cat /proc/net/xfrm_stat
root         702  0.0  0.0   6408  1632 ?        R    08:22   0:00  \_ ps auxfw
root         665  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         659  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         645  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         639  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  4.2  4.8 1606080 386804 ?      Ssl  08:02   0:51 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.0  0.0 1229744 7180 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
