[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3cf5ce0_f96f_4634_a89d_87f0ed5fe11f.slice/cri-containerd-d2416fe2066b29a3152aa1e42ce0a69dc0681a9cd3b3397bb90b0082dcdb7b16.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3cf5ce0_f96f_4634_a89d_87f0ed5fe11f.slice/cri-containerd-e996956f542594b6ecd50c8da2ea0c1a0998af06b1529f15cf14a348fc8db8c8.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3cf5ce0_f96f_4634_a89d_87f0ed5fe11f.slice/cri-containerd-959a214de65d67fb3588b59ddc0424b94ae8e9bcfea90c10d663d8b34b3f99ba.scope"
      }
    ],
    "ips": [
      "10.185.0.5"
    ],
    "name": "clustermesh-apiserver-78b9d5c9b6-vmrfl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod11f96d25_b836_453e_b5c9_fccfee5f407d.slice/cri-containerd-a2dc71f446eaefc8b120efc1b208125d94fb3cd41f702c7b80a691d88058d7f9.scope"
      }
    ],
    "ips": [
      "10.185.0.104"
    ],
    "name": "coredns-cc6ccd49c-cfdzs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaabeeb8a_c1f5_48a0_ba20_9ce1ecfda3ab.slice/cri-containerd-fe9e225c7c93bb1b1b76e051a8034bb6f69807844e48743d9869dc86e6a6d1cd.scope"
      }
    ],
    "ips": [
      "10.185.0.208"
    ],
    "name": "coredns-cc6ccd49c-bstrm",
    "namespace": "kube-system"
  }
]

