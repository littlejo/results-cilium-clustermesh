KEY             VALUE
AgentLiveness   1813054578212
UTimeOffset     3379442947265625
