#### Read-only configurations ####
ARPPingKernelManaged              : true
ARPPingRefreshPeriod              : 30000000000
AddressScopeMax                   : 252
AgentHealthPort                   : 9879
AgentLabels                       : []
AgentNotReadyNodeTaintKey         : node.cilium.io/agent-not-ready
AllocatorListTimeout              : 180000000000
AllowICMPFragNeeded               : true
AllowLocalhost                    : always
AnnotateK8sNode                   : false
AuthMapEntries                    : 524288
AutoCreateCiliumNodeResource      : true
BGPAnnounceLBIP                   : false
BGPAnnouncePodCIDR                : false
BGPConfigPath                     : /var/lib/cilium/bgp/config.yaml
BGPSecretsNamespace               : 
BPFCompileDebug                   : 
BPFEventsDropEnabled              : true
BPFEventsPolicyVerdictEnabled     : true
BPFEventsTraceEnabled             : true
BPFMapEventBuffers                : <nil>
BPFMapsDynamicSizeRatio           : 0.0025
BPFRoot                           : /sys/fs/bpf
BPFSocketLBHostnsOnly             : false
BpfDir                            : /var/lib/cilium/bpf
BypassIPAvailabilityUponRestore   : false
CGroupRoot                        : /run/cilium/cgroupv2
CRDWaitTimeout                    : 300000000000
CTMapEntriesGlobalAny             : 65536
CTMapEntriesGlobalTCP             : 131072
CTMapEntriesTimeoutAny            : 60000000000
CTMapEntriesTimeoutFIN            : 10000000000
CTMapEntriesTimeoutSVCAny         : 60000000000
CTMapEntriesTimeoutSVCTCP         : 8000000000000
CTMapEntriesTimeoutSVCTCPGrace    : 60000000000
CTMapEntriesTimeoutSYN            : 60000000000
CTMapEntriesTimeoutTCP            : 8000000000000
CgroupPathMKE                     : 
ClockSource                       : 0
ClusterHealthPort                 : 4240
ClusterID                         : 186
ClusterMeshHealthPort             : 0
ClusterName                       : cmesh186
CompilerFlags                     : []
ConfigDir                         : /tmp/cilium/config-map
ConfigFile                        : 
ConntrackGCInterval               : 0
ConntrackGCMaxInterval            : 0
ContainerIPLocalReservedPorts     : auto
CreationTime                      : 2024-10-30T08:02:57.98994121Z
DNSMaxIPsPerRestoredRule          : 1000
DNSPolicyUnloadOnShutdown         : false
DNSProxyConcurrencyLimit          : 0
DNSProxyConcurrencyProcessingGracePeriod: 0
DNSProxyEnableTransparentMode     : true
DNSProxyInsecureSkipTransparentModeCheck: false
DNSProxyLockCount                 : 131
DNSProxyLockTimeout               : 500000000
DNSProxySocketLingerTimeout       : 10
DatapathMode                      : veth
Debug                             : false
DebugVerbose                      : []
Devices                           : [ens5 ens6]
DirectRoutingDevice               : ens5
DirectRoutingSkipUnreachable      : false
DisableCiliumEndpointCRD          : false
DisableExternalIPMitigation       : false
DryMode                           : false
EgressMasqueradeInterfaces        : ens+
EgressMultiHomeIPRuleCompat       : false
EnableAutoDirectRouting           : false
EnableAutoProtectNodePortRange    : true
EnableBGPControlPlane             : false
EnableBPFClockProbe               : false
EnableBPFMasquerade               : false
EnableBPFTProxy                   : false
EnableCiliumEndpointSlice         : false
EnableCustomCalls                 : false
EnableEncryptionStrictMode        : false
EnableEndpointHealthChecking      : true
EnableEndpointRoutes              : false
EnableEnvoyConfig                 : false
EnableExternalIPs                 : false
EnableHealthCheckLoadBalancerIP   : false
EnableHealthCheckNodePort         : true
EnableHealthChecking              : true
EnableHealthDatapath              : false
EnableHighScaleIPcache            : false
EnableHostFirewall                : false
EnableHostLegacyRouting           : true
EnableHostPort                    : false
EnableHubble                      : true
EnableHubbleOpenMetrics           : false
EnableHubbleRecorderAPI           : true
EnableICMPRules                   : true
EnableIPIPTermination             : false
EnableIPMasqAgent                 : false
EnableIPSec                       : false
EnableIPSecEncryptedOverlay       : false
EnableIPSecXfrmStateCaching       : true
EnableIPsecKeyWatcher             : true
EnableIPv4                        : true
EnableIPv4EgressGateway           : false
EnableIPv4FragmentsTracking       : true
EnableIPv4Masquerade              : true
EnableIPv6                        : false
EnableIPv6Masquerade              : false
EnableIPv6NDP                     : false
EnableIdentityMark                : true
EnableK8sNetworkPolicy            : true
EnableK8sTerminatingEndpoint      : true
EnableL2Announcements             : false
EnableL2NeighDiscovery            : true
EnableL7Proxy                     : true
EnableLocalNodeRoute              : true
EnableLocalRedirectPolicy         : false
EnableMKE                         : false
EnableMasqueradeRouteSource       : false
EnableNat46X64Gateway             : false
EnableNodePort                    : false
EnableNodeSelectorLabels          : false
EnablePMTUDiscovery               : false
EnablePolicy                      : default
EnableRecorder                    : false
EnableRuntimeDeviceDetection      : true
EnableSCTP                        : false
EnableSRv6                        : false
EnableSVCSourceRangeCheck         : false
EnableSessionAffinity             : false
EnableSocketLB                    : false
EnableSocketLBPeer                : false
EnableSocketLBPodConnectionTermination: false
EnableSocketLBTracing             : false
EnableTCX                         : true
EnableTracing                     : false
EnableUnreachableRoutes           : false
EnableVTEP                        : false
EnableWellKnownIdentities         : false
EnableWireguard                   : false
EnableWireguardUserspaceFallback  : false
EnableXDPPrefilter                : false
EnableXTSocketFallback            : true
EncryptInterface                  : []
EncryptNode                       : false
EncryptionStrictModeAllowRemoteNodeIdentities: false
EncryptionStrictModeCIDR          : 
EndpointQueueSize                 : 25
ExcludeLocalAddresses             : <nil>
ExcludeNodeLabelPatterns          : <nil>
ExternalClusterIP                 : false
ExternalEnvoyProxy                : true
FQDNProxyResponseMaxDelay         : 100000000
FQDNRegexCompileLRUSize           : 1024
FQDNRejectResponse                : refused
FixedIdentityMapping
FixedZoneMapping                  : <nil>
ForceDeviceRequired               : false
FragmentsMapEntries               : 8192
HTTP403Message                    : 
HostV4Addr                        : 
HostV6Addr                        : 
HubbleDropEvents                  : false
HubbleDropEventsInterval          : 120000000000
HubbleDropEventsReasons           : [auth_required,policy_denied]
HubbleEventBufferCapacity         : 4095
HubbleEventQueueSize              : 2048
HubbleExportAllowlist             : <nil>
HubbleExportDenylist              : <nil>
HubbleExportFieldmask             : <nil>
HubbleExportFileCompress          : false
HubbleExportFileMaxBackups        : 5
HubbleExportFileMaxSizeMB         : 10
HubbleExportFilePath              : 
HubbleFlowlogsConfigFilePath      : 
HubbleListenAddress               : :4244
HubbleMetrics                     : []
HubbleMetricsServer               : 
HubbleMetricsServerTLSCertFile    : 
HubbleMetricsServerTLSClientCAFiles: <nil>
HubbleMetricsServerTLSEnabled     : false
HubbleMetricsServerTLSKeyFile     : 
HubbleMonitorEvents               : []
HubblePreferIpv6                  : false
HubbleRecorderSinkQueueSize       : 1024
HubbleRecorderStoragePath         : /var/run/cilium/pcaps
HubbleRedactEnabled               : false
HubbleRedactHttpHeadersAllow      : []
HubbleRedactHttpHeadersDeny       : []
HubbleRedactHttpURLQuery          : false
HubbleRedactHttpUserInfo          : true
HubbleRedactKafkaApiKey           : false
HubbleSkipUnknownCGroupIDs        : true
HubbleSocketPath                  : /var/run/cilium/hubble.sock
HubbleTLSCertFile                 : /var/lib/cilium/tls/hubble/server.crt
HubbleTLSClientCAFiles            : [/var/lib/cilium/tls/hubble/client-ca.crt]
HubbleTLSDisabled                 : false
HubbleTLSKeyFile                  : /var/lib/cilium/tls/hubble/server.key
IPAM                              : cluster-pool
IPAMCiliumNodeUpdateRate          : 15000000000
IPAMDefaultIPPool                 : default
IPAMMultiPoolPreAllocation
	default                   : 8
IPMasqAgentConfigPath             : /etc/config/ip-masq-agent
IPSecKeyFile                      : 
IPsecKeyRotationDuration          : 300000000000
IPv4NativeRoutingCIDR             : <nil>
IPv4NodeAddr                      : auto
IPv4PodSubnets                    : []
IPv4Range                         : auto
IPv4ServiceRange                  : auto
IPv6ClusterAllocCIDR              : f00d::/64
IPv6ClusterAllocCIDRBase          : f00d::
IPv6MCastDevice                   : 
IPv6NAT46x64CIDR                  : 64:ff9b::/96
IPv6NAT46x64CIDRBase              : 64:ff9b::
IPv6NativeRoutingCIDR             : <nil>
IPv6NodeAddr                      : auto
IPv6PodSubnets                    : []
IPv6Range                         : auto
IPv6ServiceRange                  : auto
IdentityAllocationMode            : crd
IdentityChangeGracePeriod         : 5000000000
IdentityRestoreGracePeriod        : 30000000000
InstallIptRules                   : true
InstallNoConntrackIptRules        : false
JoinCluster                       : false
K8sEnableLeasesFallbackDiscovery  : false
K8sNamespace                      : kube-system
K8sRequireIPv4PodCIDR             : true
K8sRequireIPv6PodCIDR             : false
K8sServiceCacheSize               : 128
K8sSyncTimeout                    : 180000000000
K8sWatcherEndpointSelector        : metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
KVStore                           : 
KVStoreOpt
KVstoreConnectivityTimeout        : 120000000000
KVstoreKeepAliveInterval          : 300000000000
KVstoreLeaseTTL                   : 900000000000
KVstoreMaxConsecutiveQuorumErrors : 2
KVstorePeriodicSync               : 300000000000
KeepConfig                        : false
KernelHz                          : 100
KubeProxyReplacement              : false
KubeProxyReplacementHealthzBindAddr: 
L2AnnouncerLeaseDuration          : 15000000000
L2AnnouncerRenewDeadline          : 5000000000
L2AnnouncerRetryPeriod            : 2000000000
LBAffinityMapEntries              : 0
LBBackendMapEntries               : 0
LBDevInheritIPAddr                : 
LBMaglevMapEntries                : 0
LBMapEntries                      : 65536
LBRevNatEntries                   : 0
LBServiceMapEntries               : 0
LBSourceRangeMapEntries           : 0
LabelPrefixFile                   : 
Labels                            : []
LibDir                            : /var/lib/cilium
LoadBalancerDSRDispatch           : opt
LoadBalancerDSRL4Xlate            : frontend
LoadBalancerRSSv4
	IP                        : 
	Mask                      : <nil>
LoadBalancerRSSv4CIDR             : 
LoadBalancerRSSv6
	IP                        : 
	Mask                      : <nil>
LoadBalancerRSSv6CIDR             : 
LocalRouterIPv4                   : 
LocalRouterIPv6                   : 
LogDriver                         : []
LogOpt
LogSystemLoadConfig               : false
Logstash                          : false
LoopbackIPv4                      : 169.254.42.1
MTU                               : 0
MaglevHashSeed                    : JLfvgnHc2kaSUFaI
MaglevTableSize                   : 16381
MasqueradeInterfaces              : [ens+]
MaxConnectedClusters              : 511
MaxControllerInterval             : 0
MaxInternalTimerDelay             : 0
Monitor
	cpus                      : 2
	npages                    : 64
	pagesize                  : 4096
MonitorAggregation                : medium
MonitorAggregationFlags           : 255
MonitorAggregationInterval        : 5000000000
NATMapEntriesGlobal               : 131072
NeighMapEntriesGlobal             : 131072
NodeEncryptionOptOutLabels        : [map[]]
NodeEncryptionOptOutLabelsString  : node-role.kubernetes.io/control-plane
NodeLabels                        : []
NodePortAcceleration              : disabled
NodePortAlg                       : random
NodePortBindProtection            : true
NodePortMax                       : 32767
NodePortMin                       : 30000
NodePortMode                      : snat
NodePortNat46X64                  : false
PolicyAccounting                  : true
PolicyAuditMode                   : false
PolicyCIDRMatchMode               : []
PolicyMapEntries                  : 16384
PolicyMapFullReconciliationInterval: 900000000000
PolicyQueueSize                   : 100
PolicyTriggerInterval             : 1000000000
PreAllocateMaps                   : false
ProcFs                            : /host/proc
PrometheusServeAddr               : 
RestoreState                      : true
ReverseFixedZoneMapping           : <nil>
RouteMetric                       : 0
RoutingMode                       : tunnel
RunDir                            : /var/run/cilium
SRv6EncapMode                     : reduced
ServiceNoBackendResponse          : reject
SizeofCTElement                   : 94
SizeofNATElement                  : 94
SizeofNeighElement                : 24
SizeofSockRevElement              : 52
SockRevNatEntries                 : 65536
SocketPath                        : /var/run/cilium/cilium.sock
StateDir                          : /var/run/cilium/state
TCFilterPriority                  : 1
ToFQDNsEnableDNSCompression       : true
ToFQDNsIdleConnectionGracePeriod  : 0
ToFQDNsMaxDeferredConnectionDeletes: 10000
ToFQDNsMaxIPsPerHost              : 50
ToFQDNsMinTTL                     : 0
ToFQDNsPreCache                   : 
ToFQDNsProxyPort                  : 0
TracePayloadlen                   : 128
UseCiliumInternalIPForIPsec       : false
VLANBPFBypass                     : []
Version                           : false
VtepCIDRs                         : <nil>
VtepCidrMask                      : 
VtepEndpoints                     : <nil>
VtepMACs                          : <nil>
WireguardPersistentKeepalive      : 0
XDPMode                           : disabled
k8s-configuration                 : 
k8s-endpoint                      : 
##### Read-write configurations #####
ConntrackAccounting               : Disabled
ConntrackLocal                    : Disabled
Debug                             : Disabled
DebugLB                           : Disabled
DropNotification                  : Enabled
MonitorAggregationLevel           : Medium
PolicyAccounting                  : Enabled
PolicyAuditMode                   : Disabled
PolicyTracing                     : Disabled
PolicyVerdictNotification         : Enabled
SourceIPVerification              : Enabled
TraceNotification                 : Enabled
MonitorNumPages                   : 64
PolicyEnforcement                 : default
