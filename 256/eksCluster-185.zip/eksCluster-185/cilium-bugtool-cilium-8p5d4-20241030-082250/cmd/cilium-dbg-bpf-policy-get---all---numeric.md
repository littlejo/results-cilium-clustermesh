Endpoint ID: 353
Path: /sys/fs/bpf/tc/globals/cilium_policy_00353

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    115597   1326      0        
Allow    Egress      0          ANY          NONE         disabled    16959    183       0        


Endpoint ID: 1898
Path: /sys/fs/bpf/tc/globals/cilium_policy_01898

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2249
Path: /sys/fs/bpf/tc/globals/cilium_policy_02249

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    115663   1327      0        
Allow    Egress      0          ANY          NONE         disabled    16489    178       0        


Endpoint ID: 2312
Path: /sys/fs/bpf/tc/globals/cilium_policy_02312

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1645150   20795     0        
Allow    Ingress     1          ANY          NONE         disabled    18378     217       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3266
Path: /sys/fs/bpf/tc/globals/cilium_policy_03266

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11597496   116677    0        
Allow    Ingress     1          ANY          NONE         disabled    11005266   116198    0        
Allow    Egress      0          ANY          NONE         disabled    14492049   141698    0        


