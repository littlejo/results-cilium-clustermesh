1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:82:2e:51:9f:c7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.238.57/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1830sec preferred_lft 1830sec
    inet6 fe80::882:2eff:fe51:9fc7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:7b:82:42:69:cd brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.223.47/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::87b:82ff:fe42:69cd/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:ea:51:fd:44:2a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a4ea:51ff:fefd:442a/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:b5:07:4f:c4:40 brd ff:ff:ff:ff:ff:ff
    inet 10.185.0.231/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::60b5:7ff:fe4f:c440/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 46:55:12:53:2c:04 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4455:12ff:fe53:2c04/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:a4:8f:c9:4b:82 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::4a4:8fff:fec9:4b82/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc0120dcf3403c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:2d:46:e0:ab:bf brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4c2d:46ff:fee0:abbf/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcef0d9ed8ad27@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:c6:35:dc:df:39 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d0c6:35ff:fedc:df39/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc16ff1bce9606@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:9d:3c:0b:09:df brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::49d:3cff:fe0b:9df/64 scope link 
       valid_lft forever preferred_lft forever
