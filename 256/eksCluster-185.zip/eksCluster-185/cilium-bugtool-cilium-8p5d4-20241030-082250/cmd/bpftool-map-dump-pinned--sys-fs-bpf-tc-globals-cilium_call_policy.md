key: 61 01 00 00  value: 22 02 00 00
key: c9 08 00 00  value: fc 01 00 00
key: 08 09 00 00  value: 07 02 00 00
key: c2 0c 00 00  value: 70 02 00 00
Found 4 elements
