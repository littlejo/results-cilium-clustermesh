KEY             VALUE
AgentLiveness   1998829634322
UTimeOffset     3379442582031250
