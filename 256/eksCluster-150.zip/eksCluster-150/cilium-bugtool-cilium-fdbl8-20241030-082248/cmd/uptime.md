 08:22:49 up 32 min,  0 users,  load average: 0.17, 0.24, 0.18
