ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.182.59:443 (active)     
                                         2 => 172.31.196.8:443 (active)      
2    10.100.20.57:443     ClusterIP      1 => 172.31.190.101:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.150.0.166:9153 (active)     
                                         2 => 10.150.0.174:9153 (active)     
4    10.100.0.10:53       ClusterIP      1 => 10.150.0.166:53 (active)       
                                         2 => 10.150.0.174:53 (active)       
5    10.100.65.152:2379   ClusterIP      1 => 10.150.0.210:2379 (active)     
