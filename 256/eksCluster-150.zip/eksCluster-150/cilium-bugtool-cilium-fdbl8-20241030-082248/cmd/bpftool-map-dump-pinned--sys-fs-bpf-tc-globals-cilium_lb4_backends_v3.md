key: 02 00 00 00  value: ac 1f c4 08 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 96 00 a6 23 c1 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f b6 3b 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 96 00 d2 09 4b 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 96 00 ae 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 96 00 ae 00 35 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 96 00 a6 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f be 65 10 94 00 00  00 00 00 00
Found 8 elements
