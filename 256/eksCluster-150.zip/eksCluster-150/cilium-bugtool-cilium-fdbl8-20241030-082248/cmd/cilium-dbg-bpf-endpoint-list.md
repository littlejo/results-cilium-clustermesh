IP ADDRESS         LOCAL ENDPOINT INFO
10.150.0.209:0     id=3034  sec_id=4     flags=0x0000 ifindex=10  mac=A6:6A:9A:39:66:85 nodemac=C6:1A:1E:30:DD:F5     
10.150.0.174:0     id=1968  sec_id=4979502 flags=0x0000 ifindex=14  mac=86:BF:72:A8:08:BB nodemac=56:9D:EF:96:49:34   
172.31.152.126:0   (localhost)                                                                                        
10.150.0.7:0       (localhost)                                                                                        
10.150.0.166:0     id=3403  sec_id=4979502 flags=0x0000 ifindex=12  mac=FE:BC:18:4E:53:F4 nodemac=4E:B8:B5:0F:41:4A   
172.31.190.101:0   (localhost)                                                                                        
10.150.0.210:0     id=3250  sec_id=4965434 flags=0x0000 ifindex=18  mac=3A:F2:81:F4:19:EE nodemac=9A:7D:0C:E9:DB:B5   
