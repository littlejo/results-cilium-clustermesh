1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:af:e9:ee:e2:f9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.190.101/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3443sec preferred_lft 3443sec
    inet6 fe80::4af:e9ff:feee:e2f9/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:2c:b1:69:46:17 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.152.126/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::42c:b1ff:fe69:4617/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:4d:69:6e:65:37 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b84d:69ff:fe6e:6537/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:ec:6c:41:e1:ee brd ff:ff:ff:ff:ff:ff
    inet 10.150.0.7/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b4ec:6cff:fe41:e1ee/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6a:57:fe:14:d2:d3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6857:feff:fe14:d2d3/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:1a:1e:30:dd:f5 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c41a:1eff:fe30:ddf5/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc2ddc9ad565e9@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:b8:b5:0f:41:4a brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::4cb8:b5ff:fe0f:414a/64 scope link 
       valid_lft forever preferred_lft forever
14: lxca8833fb80cf7@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:9d:ef:96:49:34 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::549d:efff:fe96:4934/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc8eaa507fa692@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:7d:0c:e9:db:b5 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::987d:cff:fee9:dbb5/64 scope link 
       valid_lft forever preferred_lft forever
