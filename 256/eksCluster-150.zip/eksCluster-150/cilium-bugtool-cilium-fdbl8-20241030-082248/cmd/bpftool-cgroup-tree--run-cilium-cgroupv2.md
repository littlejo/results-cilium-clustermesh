CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1e83170_393d_4f27_b529_d027c1784729.slice/cri-containerd-dda328839626dc1d358046267d6fe550e0e022eea9aa11917d83ab90ed245cce.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1e83170_393d_4f27_b529_d027c1784729.slice/cri-containerd-535f7087e87f6b2f3badb702335a6ccbf57b5945b9c9aba07351518df36ffa7d.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08181517_e1e4_44b4_ae56_feaa52086a3a.slice/cri-containerd-3c1133062ddd899421140607aebe35a8694c64bac7a38331fbb9cb2d504139a7.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08181517_e1e4_44b4_ae56_feaa52086a3a.slice/cri-containerd-271fb2827f0eb7a8487d06f30da584e5a79d3a9149f5d4dfd664609dd95609b3.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6243f1a8_ba4b_459a_84e9_b6138c252490.slice/cri-containerd-3112e61446562931704ee80087620267427bfebc4ddd87e8bc60b8f0350dff64.scope
    527      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6243f1a8_ba4b_459a_84e9_b6138c252490.slice/cri-containerd-80c2ca1764bd22a91253548784f41c237ec0e77207f6ee5572f18845130707ab.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f3b058f_a9eb_4ef1_a0fe_46f84aaaa89b.slice/cri-containerd-fef9b259e1846684fb68a7009fa88e57375cbdc4cce69d580f57b3f17e120f46.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f3b058f_a9eb_4ef1_a0fe_46f84aaaa89b.slice/cri-containerd-99fff20de4fae27c9a5b4bb566d8a47ae8c36071ad7af40ba84c3c1e43c29478.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2b066f70_ae9e_4ace_a470_b8f1926c6d21.slice/cri-containerd-285597f6a4a528a213417b8185f8ae2883c49a16d853d13491c6a908457069b0.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2b066f70_ae9e_4ace_a470_b8f1926c6d21.slice/cri-containerd-2e1983be49f14f616eeb1139988223b76f72fbf977e4f90fb08c6500cc70c347.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29cf753c_d80c_4d45_b8ba_01094e8bf77b.slice/cri-containerd-6eff07fef6457d10480755313a1e1d31c8dd1b8399a7cd0eb90d9645e78bd8e6.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29cf753c_d80c_4d45_b8ba_01094e8bf77b.slice/cri-containerd-a4cb9a05b75e18992078169fdd2eb324c5a6776475d72857694b2c4e814d1d11.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29cf753c_d80c_4d45_b8ba_01094e8bf77b.slice/cri-containerd-4f86e31e1702426c9422d6fe500bd3470d38329dff82fff5b6c578ed08365e72.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29cf753c_d80c_4d45_b8ba_01094e8bf77b.slice/cri-containerd-ebddffe0fe64b4fe72d5d3c1c7b02713ede6aae69f3681ec345281268b277cb6.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8680ea3b_4c52_4dbe_893d_7f07d5c241c1.slice/cri-containerd-eb2c794c7882a84841fcca73b31f40ea2fd20d91cb14422f3e6553a9dd480a49.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8680ea3b_4c52_4dbe_893d_7f07d5c241c1.slice/cri-containerd-f35669b25fcc0f58af32d25ce7bc6053e21ffc7c46e539ac937b3d668928a00d.scope
    95       cgroup_device   multi                                          
