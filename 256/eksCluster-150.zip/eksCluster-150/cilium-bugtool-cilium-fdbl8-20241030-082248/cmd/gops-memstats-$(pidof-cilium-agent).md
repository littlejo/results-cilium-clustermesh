alloc: 103.54MB (108568832 bytes)
total-alloc: 2.40GB (2575950968 bytes)
sys: 333.27MB (349458788 bytes)
lookups: 0
mallocs: 65346911
frees: 64545045
heap-alloc: 103.54MB (108568832 bytes)
heap-sys: 251.76MB (263987200 bytes)
heap-idle: 77.91MB (81690624 bytes)
heap-in-use: 173.85MB (182296576 bytes)
heap-released: 336.00KB (344064 bytes)
heap-objects: 801866
stack-in-use: 68.22MB (71532544 bytes)
stack-sys: 68.22MB (71532544 bytes)
stack-mspan-inuse: 3.04MB (3187360 bytes)
stack-mspan-sys: 4.02MB (4210560 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.24MB (1300129 bytes)
gc-sys: 6.02MB (6313496 bytes)
next-gc: when heap-alloc >= 217.66MB (228236024 bytes)
last-gc: 2024-10-30 08:23:15.827473364 +0000 UTC
gc-pause-total: 12.248727ms
gc-pause: 82586
gc-pause-end: 1730276595827473364
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0005686192014645771
enable-gc: true
debug-gc: false
