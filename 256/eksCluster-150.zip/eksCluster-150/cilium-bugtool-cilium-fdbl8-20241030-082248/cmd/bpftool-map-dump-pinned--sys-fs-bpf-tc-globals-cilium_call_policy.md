key: b0 07 00 00  value: 1e 02 00 00
key: da 0b 00 00  value: 02 02 00 00
key: b2 0c 00 00  value: 70 02 00 00
key: 4b 0d 00 00  value: 10 02 00 00
Found 4 elements
