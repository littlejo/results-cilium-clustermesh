[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6243f1a8_ba4b_459a_84e9_b6138c252490.slice/cri-containerd-80c2ca1764bd22a91253548784f41c237ec0e77207f6ee5572f18845130707ab.scope"
      }
    ],
    "ips": [
      "10.150.0.166"
    ],
    "name": "coredns-cc6ccd49c-t4t57",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08181517_e1e4_44b4_ae56_feaa52086a3a.slice/cri-containerd-271fb2827f0eb7a8487d06f30da584e5a79d3a9149f5d4dfd664609dd95609b3.scope"
      }
    ],
    "ips": [
      "10.150.0.174"
    ],
    "name": "coredns-cc6ccd49c-7n4wx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29cf753c_d80c_4d45_b8ba_01094e8bf77b.slice/cri-containerd-a4cb9a05b75e18992078169fdd2eb324c5a6776475d72857694b2c4e814d1d11.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29cf753c_d80c_4d45_b8ba_01094e8bf77b.slice/cri-containerd-4f86e31e1702426c9422d6fe500bd3470d38329dff82fff5b6c578ed08365e72.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29cf753c_d80c_4d45_b8ba_01094e8bf77b.slice/cri-containerd-6eff07fef6457d10480755313a1e1d31c8dd1b8399a7cd0eb90d9645e78bd8e6.scope"
      }
    ],
    "ips": [
      "10.150.0.210"
    ],
    "name": "clustermesh-apiserver-75b9c74749-42b9r",
    "namespace": "kube-system"
  }
]

