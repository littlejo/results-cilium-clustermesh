top - 08:22:49 up 32 min,  0 users,  load average: 0.17, 0.24, 0.18
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 65.5 us, 27.6 sy,  0.0 ni,  3.4 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   7814.2 total,   4463.2 free,   1203.8 used,   2147.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6425.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 402388  79356 S  73.3   5.0   0:54.07 cilium-+
    678 root      20   0 1240432  16680  11484 S   6.7   0.2   0:00.03 cilium-+
    416 root      20   0 1229488   8120   3836 S   0.0   0.1   0:01.14 cilium-+
    648 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    682 root      20   0    2208    784    704 S   0.0   0.0   0:00.00 timeout
    689 root      20   0 1243508  17716  12680 S   0.0   0.2   0:00.01 hubble
    701 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    738 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    763 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
