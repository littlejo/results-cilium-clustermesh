Endpoint ID: 1529
Path: /sys/fs/bpf/tc/globals/cilium_policy_01529

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1968
Path: /sys/fs/bpf/tc/globals/cilium_policy_01968

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    130081   1488      0        
Allow    Egress      0          ANY          NONE         disabled    18521    203       0        


Endpoint ID: 3034
Path: /sys/fs/bpf/tc/globals/cilium_policy_03034

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1645601   20780     0        
Allow    Ingress     1          ANY          NONE         disabled    19400     226       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3250
Path: /sys/fs/bpf/tc/globals/cilium_policy_03250

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11638877   115836    0        
Allow    Ingress     1          ANY          NONE         disabled    11033402   112719    0        
Allow    Egress      0          ANY          NONE         disabled    12484794   122939    0        


Endpoint ID: 3403
Path: /sys/fs/bpf/tc/globals/cilium_policy_03403

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    130345   1492      0        
Allow    Egress      0          ANY          NONE         disabled    17461    190       0        


