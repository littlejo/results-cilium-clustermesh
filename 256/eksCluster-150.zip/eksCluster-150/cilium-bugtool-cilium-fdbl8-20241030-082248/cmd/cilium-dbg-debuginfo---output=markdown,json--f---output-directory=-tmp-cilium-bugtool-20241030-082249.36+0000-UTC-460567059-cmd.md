markdown output at /tmp/cilium-bugtool-20241030-082249.36+0000-UTC-460567059/cmd/cilium-debuginfo-20241030-082320.604+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082249.36+0000-UTC-460567059/cmd/cilium-debuginfo-20241030-082320.604+0000-UTC.json
