KEY             VALUE
AgentLiveness   2287281914600
UTimeOffset     3379441976562500
