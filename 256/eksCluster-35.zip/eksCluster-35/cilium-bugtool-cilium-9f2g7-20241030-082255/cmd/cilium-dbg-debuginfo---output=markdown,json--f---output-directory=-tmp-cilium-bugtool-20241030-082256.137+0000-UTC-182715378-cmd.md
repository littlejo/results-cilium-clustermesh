markdown output at /tmp/cilium-bugtool-20241030-082256.137+0000-UTC-182715378/cmd/cilium-debuginfo-20241030-082258.251+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082256.137+0000-UTC-182715378/cmd/cilium-debuginfo-20241030-082258.251+0000-UTC.json
