ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.235.42:443 (active)     
                                          2 => 172.31.153.249:443 (active)    
2    10.100.143.68:443     ClusterIP      1 => 172.31.202.120:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.35.0.144:53 (active)        
                                          2 => 10.35.0.9:53 (active)          
4    10.100.0.10:9153      ClusterIP      1 => 10.35.0.144:9153 (active)      
                                          2 => 10.35.0.9:9153 (active)        
5    10.100.124.183:2379   ClusterIP      1 => 10.35.0.1:2379 (active)        
