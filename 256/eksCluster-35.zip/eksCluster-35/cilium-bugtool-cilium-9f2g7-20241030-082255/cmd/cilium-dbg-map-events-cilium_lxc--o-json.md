{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:36.706Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.202.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:36.706Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.227.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:36.706Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.525Z",
  "value": "id=136   sec_id=1186529 flags=0x0000 ifindex=12  mac=C6:74:2F:A1:DD:44 nodemac=6A:B5:51:7B:F6:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.528Z",
  "value": "id=3285  sec_id=4     flags=0x0000 ifindex=10  mac=66:C2:CB:8D:A8:AB nodemac=1E:64:43:18:66:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.595Z",
  "value": "id=1351  sec_id=1186529 flags=0x0000 ifindex=14  mac=1A:12:C4:5B:53:28 nodemac=AE:49:81:07:EF:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.602Z",
  "value": "id=3285  sec_id=4     flags=0x0000 ifindex=10  mac=66:C2:CB:8D:A8:AB nodemac=1E:64:43:18:66:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:58.418Z",
  "value": "id=3285  sec_id=4     flags=0x0000 ifindex=10  mac=66:C2:CB:8D:A8:AB nodemac=1E:64:43:18:66:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:58.419Z",
  "value": "id=136   sec_id=1186529 flags=0x0000 ifindex=12  mac=C6:74:2F:A1:DD:44 nodemac=6A:B5:51:7B:F6:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:58.420Z",
  "value": "id=1351  sec_id=1186529 flags=0x0000 ifindex=14  mac=1A:12:C4:5B:53:28 nodemac=AE:49:81:07:EF:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:58.450Z",
  "value": "id=2041  sec_id=1189774 flags=0x0000 ifindex=16  mac=36:8C:16:47:80:15 nodemac=7A:05:A4:77:FF:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:59.419Z",
  "value": "id=136   sec_id=1186529 flags=0x0000 ifindex=12  mac=C6:74:2F:A1:DD:44 nodemac=6A:B5:51:7B:F6:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:59.420Z",
  "value": "id=3285  sec_id=4     flags=0x0000 ifindex=10  mac=66:C2:CB:8D:A8:AB nodemac=1E:64:43:18:66:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:59.420Z",
  "value": "id=1351  sec_id=1186529 flags=0x0000 ifindex=14  mac=1A:12:C4:5B:53:28 nodemac=AE:49:81:07:EF:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:59.420Z",
  "value": "id=2041  sec_id=1189774 flags=0x0000 ifindex=16  mac=36:8C:16:47:80:15 nodemac=7A:05:A4:77:FF:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.803Z",
  "value": "id=3078  sec_id=1189774 flags=0x0000 ifindex=18  mac=EE:21:BC:0D:29:0A nodemac=4E:67:45:15:C8:A1"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.35.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.471Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.971Z",
  "value": "id=3285  sec_id=4     flags=0x0000 ifindex=10  mac=66:C2:CB:8D:A8:AB nodemac=1E:64:43:18:66:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.972Z",
  "value": "id=136   sec_id=1186529 flags=0x0000 ifindex=12  mac=C6:74:2F:A1:DD:44 nodemac=6A:B5:51:7B:F6:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.972Z",
  "value": "id=1351  sec_id=1186529 flags=0x0000 ifindex=14  mac=1A:12:C4:5B:53:28 nodemac=AE:49:81:07:EF:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.972Z",
  "value": "id=3078  sec_id=1189774 flags=0x0000 ifindex=18  mac=EE:21:BC:0D:29:0A nodemac=4E:67:45:15:C8:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.971Z",
  "value": "id=3285  sec_id=4     flags=0x0000 ifindex=10  mac=66:C2:CB:8D:A8:AB nodemac=1E:64:43:18:66:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.971Z",
  "value": "id=136   sec_id=1186529 flags=0x0000 ifindex=12  mac=C6:74:2F:A1:DD:44 nodemac=6A:B5:51:7B:F6:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.972Z",
  "value": "id=1351  sec_id=1186529 flags=0x0000 ifindex=14  mac=1A:12:C4:5B:53:28 nodemac=AE:49:81:07:EF:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.972Z",
  "value": "id=3078  sec_id=1189774 flags=0x0000 ifindex=18  mac=EE:21:BC:0D:29:0A nodemac=4E:67:45:15:C8:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.972Z",
  "value": "id=1351  sec_id=1186529 flags=0x0000 ifindex=14  mac=1A:12:C4:5B:53:28 nodemac=AE:49:81:07:EF:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.973Z",
  "value": "id=3078  sec_id=1189774 flags=0x0000 ifindex=18  mac=EE:21:BC:0D:29:0A nodemac=4E:67:45:15:C8:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.973Z",
  "value": "id=3285  sec_id=4     flags=0x0000 ifindex=10  mac=66:C2:CB:8D:A8:AB nodemac=1E:64:43:18:66:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.974Z",
  "value": "id=136   sec_id=1186529 flags=0x0000 ifindex=12  mac=C6:74:2F:A1:DD:44 nodemac=6A:B5:51:7B:F6:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.973Z",
  "value": "id=136   sec_id=1186529 flags=0x0000 ifindex=12  mac=C6:74:2F:A1:DD:44 nodemac=6A:B5:51:7B:F6:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.973Z",
  "value": "id=1351  sec_id=1186529 flags=0x0000 ifindex=14  mac=1A:12:C4:5B:53:28 nodemac=AE:49:81:07:EF:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.973Z",
  "value": "id=3285  sec_id=4     flags=0x0000 ifindex=10  mac=66:C2:CB:8D:A8:AB nodemac=1E:64:43:18:66:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.973Z",
  "value": "id=3078  sec_id=1189774 flags=0x0000 ifindex=18  mac=EE:21:BC:0D:29:0A nodemac=4E:67:45:15:C8:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.973Z",
  "value": "id=3285  sec_id=4     flags=0x0000 ifindex=10  mac=66:C2:CB:8D:A8:AB nodemac=1E:64:43:18:66:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.973Z",
  "value": "id=3078  sec_id=1189774 flags=0x0000 ifindex=18  mac=EE:21:BC:0D:29:0A nodemac=4E:67:45:15:C8:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.974Z",
  "value": "id=136   sec_id=1186529 flags=0x0000 ifindex=12  mac=C6:74:2F:A1:DD:44 nodemac=6A:B5:51:7B:F6:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.974Z",
  "value": "id=1351  sec_id=1186529 flags=0x0000 ifindex=14  mac=1A:12:C4:5B:53:28 nodemac=AE:49:81:07:EF:F1"
}

