[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1d40ae7_097b_4d3d_bd43_4fe436e73987.slice/cri-containerd-4c14f1d4c8de98fa1d94c03d0fbf288199afc5c13d97aed1c285499225b12cfd.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1d40ae7_097b_4d3d_bd43_4fe436e73987.slice/cri-containerd-b017517153de70fb9069bb1e910b7f5220fa2ebdfe460574bf7664d8c5af9cd9.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1d40ae7_097b_4d3d_bd43_4fe436e73987.slice/cri-containerd-29fac05219020d083fb9ad74d7f863c94f0e071dd1a4031dfb48f37c1abb44ba.scope"
      }
    ],
    "ips": [
      "10.35.0.1"
    ],
    "name": "clustermesh-apiserver-567f8c4568-nqxrq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda90b54b_4ad3_49f7_a0e9_f7e62a3daf47.slice/cri-containerd-71f841daf4b800c3fb35a8b05b209a22ad8f41f194571d30e1e5839fc52d0ee3.scope"
      }
    ],
    "ips": [
      "10.35.0.144"
    ],
    "name": "coredns-cc6ccd49c-22v5d",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcce3a18a_9191_467f_b216_45f9bb3c4eac.slice/cri-containerd-08ef44574ba8e025a8e7396c6c113d343a2a37f08b3021bb1cd4669203ce2820.scope"
      }
    ],
    "ips": [
      "10.35.0.9"
    ],
    "name": "coredns-cc6ccd49c-2wmlm",
    "namespace": "kube-system"
  }
]

