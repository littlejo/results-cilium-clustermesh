CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6f857ef_a03f_40f6_8332_6600ca4f21ce.slice/cri-containerd-5b3a86356bb8f4566db90ee0ebf5b26bc34d335e822d6893190e7cbb43ce0ed6.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6f857ef_a03f_40f6_8332_6600ca4f21ce.slice/cri-containerd-fb7e49c6ff79c465160d3b9e8bac100149b02c0146bdd838b025ee48398e81a7.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcce3a18a_9191_467f_b216_45f9bb3c4eac.slice/cri-containerd-86c50ada284a0526305e6e2f3a619ad19ee247df7a1b6fee643445b65674e55c.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcce3a18a_9191_467f_b216_45f9bb3c4eac.slice/cri-containerd-08ef44574ba8e025a8e7396c6c113d343a2a37f08b3021bb1cd4669203ce2820.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod52a5ff63_7eac_4a65_81df_124e810b5a41.slice/cri-containerd-1131202af8ac8a89c66b8a1ffa9c334c101ef86ed394a4b88af0cb51e5ad1529.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod52a5ff63_7eac_4a65_81df_124e810b5a41.slice/cri-containerd-8a429c72dff1b2775c20eb01051a912f1e7352e4fbffd71798b3306da8531658.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda90b54b_4ad3_49f7_a0e9_f7e62a3daf47.slice/cri-containerd-71f841daf4b800c3fb35a8b05b209a22ad8f41f194571d30e1e5839fc52d0ee3.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda90b54b_4ad3_49f7_a0e9_f7e62a3daf47.slice/cri-containerd-2b6d8536b6742eb0af519aaa2e8a731fec449f522c6832b0de6e4f78b7eaf8c4.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1d40ae7_097b_4d3d_bd43_4fe436e73987.slice/cri-containerd-51346094babdf9a720445d14399ccb1ceb44a2cabb9a2df30483ffdcbe9456b0.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1d40ae7_097b_4d3d_bd43_4fe436e73987.slice/cri-containerd-29fac05219020d083fb9ad74d7f863c94f0e071dd1a4031dfb48f37c1abb44ba.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1d40ae7_097b_4d3d_bd43_4fe436e73987.slice/cri-containerd-b017517153de70fb9069bb1e910b7f5220fa2ebdfe460574bf7664d8c5af9cd9.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1d40ae7_097b_4d3d_bd43_4fe436e73987.slice/cri-containerd-4c14f1d4c8de98fa1d94c03d0fbf288199afc5c13d97aed1c285499225b12cfd.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod648eddc1_bb38_411b_9da8_0d174306e065.slice/cri-containerd-277123cae19b069773c3e62821aaf93d7a2728fbef11ed1c10199bb0cbb70254.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod648eddc1_bb38_411b_9da8_0d174306e065.slice/cri-containerd-aff480407289735cebfda1ea0455b0208a26f05b73dd17770846160dc98aa634.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8bf24703_1eb5_45c1_9eae_87e355c49296.slice/cri-containerd-473265edc4fb23e68dfd0e29450ea603667dbec05a6b13b61a7999f6960b2e96.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8bf24703_1eb5_45c1_9eae_87e355c49296.slice/cri-containerd-81dc0ccd12bad0b55d8657bd7235412b2853d49495b8ef304123e8dab21a7157.scope
    102      cgroup_device   multi                                          
