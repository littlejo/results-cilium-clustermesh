key: 88 00 00 00  value: 07 02 00 00
key: 47 05 00 00  value: 38 02 00 00
key: 06 0c 00 00  value: 88 02 00 00
key: d5 0c 00 00  value: 3d 02 00 00
Found 4 elements
