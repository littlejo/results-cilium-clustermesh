REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     33288     2626325     677    bpf_overlay.c
Interface                 INGRESS     598623    125466386   1132   bpf_host.c
Success                   EGRESS      13857     1085439     1694   bpf_host.c
Success                   EGRESS      263945    32977134    1308   bpf_lxc.c
Success                   EGRESS      32409     2565371     53     encap.h
Success                   INGRESS     303297    33289383    86     l3.h
Success                   INGRESS     323379    34874315    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
