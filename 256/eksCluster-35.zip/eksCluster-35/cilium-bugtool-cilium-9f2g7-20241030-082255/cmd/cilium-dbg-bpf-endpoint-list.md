IP ADDRESS         LOCAL ENDPOINT INFO
172.31.227.63:0    (localhost)                                                                                        
172.31.202.120:0   (localhost)                                                                                        
10.35.0.147:0      (localhost)                                                                                        
10.35.0.1:0        id=3078  sec_id=1189774 flags=0x0000 ifindex=18  mac=EE:21:BC:0D:29:0A nodemac=4E:67:45:15:C8:A1   
10.35.0.9:0        id=1351  sec_id=1186529 flags=0x0000 ifindex=14  mac=1A:12:C4:5B:53:28 nodemac=AE:49:81:07:EF:F1   
10.35.0.58:0       id=3285  sec_id=4     flags=0x0000 ifindex=10  mac=66:C2:CB:8D:A8:AB nodemac=1E:64:43:18:66:C0     
10.35.0.144:0      id=136   sec_id=1186529 flags=0x0000 ifindex=12  mac=C6:74:2F:A1:DD:44 nodemac=6A:B5:51:7B:F6:BE   
