top - 08:22:56 up 38 min,  0 users,  load average: 0.26, 0.20, 0.13
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 56.7 us, 43.3 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4462.6 free,   1205.0 used,   2146.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6424.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 396452  78396 S  53.3   5.0   0:54.02 cilium-+
    404 root      20   0 1229744   7284   3052 S   0.0   0.1   0:01.17 cilium-+
    621 root      20   0 1240432  16340  11228 S   0.0   0.2   0:00.03 cilium-+
    625 root      20   0 1228744   3604   2912 S   0.0   0.0   0:00.00 gops
    661 root      20   0    6576   2416   2092 R   0.0   0.0   0:00.00 top
    670 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    683 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    684 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
