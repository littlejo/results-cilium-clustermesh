filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf362165ca669 direct-action not_in_hw id 576 tag 8e66fe00e91b08e6 jited 
