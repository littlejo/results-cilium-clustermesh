Endpoint ID: 136
Path: /sys/fs/bpf/tc/globals/cilium_policy_00136

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174179   2000      0        
Allow    Egress      0          ANY          NONE         disabled    20910    234       0        


Endpoint ID: 714
Path: /sys/fs/bpf/tc/globals/cilium_policy_00714

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1351
Path: /sys/fs/bpf/tc/globals/cilium_policy_01351

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174121   2010      0        
Allow    Egress      0          ANY          NONE         disabled    20914    234       0        


Endpoint ID: 3078
Path: /sys/fs/bpf/tc/globals/cilium_policy_03078

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    10237982   103106    0        
Allow    Ingress     1          ANY          NONE         disabled    9876359    99807     0        
Allow    Egress      0          ANY          NONE         disabled    9221571    95883     0        


Endpoint ID: 3285
Path: /sys/fs/bpf/tc/globals/cilium_policy_03285

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1590213   20148     0        
Allow    Ingress     1          ANY          NONE         disabled    25336     294       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


