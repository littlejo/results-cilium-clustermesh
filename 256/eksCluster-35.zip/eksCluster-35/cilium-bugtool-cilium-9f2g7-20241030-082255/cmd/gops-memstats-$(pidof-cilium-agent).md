alloc: 162.82MB (170731304 bytes)
total-alloc: 2.30GB (2469845256 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 63341509
frees: 61872563
heap-alloc: 162.82MB (170731304 bytes)
heap-sys: 247.48MB (259497984 bytes)
heap-idle: 51.06MB (53542912 bytes)
heap-in-use: 196.41MB (205955072 bytes)
heap-released: 2.00MB (2097152 bytes)
heap-objects: 1468946
stack-in-use: 68.50MB (71827456 bytes)
stack-sys: 68.50MB (71827456 bytes)
stack-mspan-inuse: 3.08MB (3234720 bytes)
stack-mspan-sys: 3.89MB (4080000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 922.51KB (944649 bytes)
gc-sys: 5.99MB (6280608 bytes)
next-gc: when heap-alloc >= 209.15MB (219305128 bytes)
last-gc: 2024-10-30 08:22:31.988995424 +0000 UTC
gc-pause-total: 21.509732ms
gc-pause: 111304
gc-pause-end: 1730276551988995424
num-gc: 87
num-forced-gc: 0
gc-cpu-fraction: 0.00040899096671072896
enable-gc: true
debug-gc: false
