USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         625  0.0  0.0 1228744 3604 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         621  0.0  0.2 1240432 16340 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         650  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         651  0.0  0.2 1240432 16340 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  2.9  4.9 1606080 392720 ?      Ssl  07:52   0:53 cilium-agent --config-dir=/tmp/cilium/config-map
root         404  0.0  0.0 1229744 7284 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
