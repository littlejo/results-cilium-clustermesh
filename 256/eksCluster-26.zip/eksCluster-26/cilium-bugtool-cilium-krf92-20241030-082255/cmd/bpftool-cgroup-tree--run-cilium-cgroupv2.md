CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd00d1b6d_9de1_4c71_b334_7b5bf4cfe9d8.slice/cri-containerd-604f88a558b9b1889f822e48ab1ec6011bb02b7050b220da72ffe7e2b40331e3.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd00d1b6d_9de1_4c71_b334_7b5bf4cfe9d8.slice/cri-containerd-908fff6bb4fdd8f7874cee8801d7044c82199685e0ff52eaea0204493bd2cb4d.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeaf3c739_3e69_4989_a2eb_c735c2538c10.slice/cri-containerd-7aad1d6ffba2176904e7f893c69fbb5ef2cb11700e3c5d6d0175cf0981762bb8.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeaf3c739_3e69_4989_a2eb_c735c2538c10.slice/cri-containerd-af871936baa86d2fd56611a30de009b1b3abb6483468427bf4e4e7b6a115ee80.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod70393d22_309f_4fb7_a5b0_34d5380c34d0.slice/cri-containerd-301ece94a0057255d28ff7f7ab5e4c3e93c543ad0f74f8727bc70102b61d32da.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod70393d22_309f_4fb7_a5b0_34d5380c34d0.slice/cri-containerd-41bace047a06ae307634a45117f840b454015aaa9deae11f65da10e7d6e86052.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03befe21_9387_4986_97fb_8414dd7e2629.slice/cri-containerd-28a01e3c0e82c1989f2a375ba9c1fbf6836700637a9c9bb5525abc2241411955.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03befe21_9387_4986_97fb_8414dd7e2629.slice/cri-containerd-ed84b0164d0a6f6d6a0b1154da85aff2db3bd65ed18b7222f41166ad58077cb3.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3ab54c2_4822_4995_8591_725704afec6b.slice/cri-containerd-0dd0d411fe4b9a9b888f59e62a500b24ceb2420cf290f59bc4757551aeae6dce.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3ab54c2_4822_4995_8591_725704afec6b.slice/cri-containerd-745cda9be7e502338d05419c163455033dd397d1d5775fd359b0344f2d03218d.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3ab54c2_4822_4995_8591_725704afec6b.slice/cri-containerd-81c0d26bb5158e456f08ed20e7f4b907e1caec3244328a5a5f6a495236db499c.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3ab54c2_4822_4995_8591_725704afec6b.slice/cri-containerd-bfdd667fe4150da9d60015fd69745be2eb025c04eebebdae02ae1736c9d70dcf.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9ec3daa_eada_45e2_ae07_10e550956ee1.slice/cri-containerd-282c908c36c7d4c47dfeadc744f470d3eb3c0995294c2920be45ba3535aaae9c.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9ec3daa_eada_45e2_ae07_10e550956ee1.slice/cri-containerd-2cd6889b944fbf1790e3d9dfbb8307960b2ece9446899d60176ae5ef3e123821.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd78a6924_7ea1_40bb_b302_e2ab6e98d708.slice/cri-containerd-bc2b3bbdceff221df3f942892315d41ee7b14598bffbad9d7ca5f60ad3de7b71.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd78a6924_7ea1_40bb_b302_e2ab6e98d708.slice/cri-containerd-340faa36748aed60fa7d25742cbd31d8ef37d99baafdf33f182adc4b5406ed84.scope
    91       cgroup_device   multi                                          
