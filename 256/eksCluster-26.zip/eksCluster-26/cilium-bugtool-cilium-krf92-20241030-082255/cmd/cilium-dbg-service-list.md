ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.144.112:443 (active)    
                                        2 => 172.31.199.13:443 (active)     
2    10.100.77.16:443    ClusterIP      1 => 172.31.155.250:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.26.0.4:53 (active)          
                                        2 => 10.26.0.25:53 (active)         
4    10.100.0.10:9153    ClusterIP      1 => 10.26.0.4:9153 (active)        
                                        2 => 10.26.0.25:9153 (active)       
5    10.100.99.13:2379   ClusterIP      1 => 10.26.0.162:2379 (active)      
