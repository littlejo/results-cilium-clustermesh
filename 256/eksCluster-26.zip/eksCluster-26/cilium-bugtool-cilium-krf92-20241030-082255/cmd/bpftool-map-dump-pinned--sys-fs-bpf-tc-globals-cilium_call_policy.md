key: 3d 00 00 00  value: 03 02 00 00
key: 34 01 00 00  value: 86 02 00 00
key: 96 0a 00 00  value: 23 02 00 00
key: eb 0b 00 00  value: 3e 02 00 00
Found 4 elements
