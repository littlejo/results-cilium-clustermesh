[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd00d1b6d_9de1_4c71_b334_7b5bf4cfe9d8.slice/cri-containerd-908fff6bb4fdd8f7874cee8801d7044c82199685e0ff52eaea0204493bd2cb4d.scope"
      }
    ],
    "ips": [
      "10.26.0.4"
    ],
    "name": "coredns-cc6ccd49c-5ks56",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod70393d22_309f_4fb7_a5b0_34d5380c34d0.slice/cri-containerd-41bace047a06ae307634a45117f840b454015aaa9deae11f65da10e7d6e86052.scope"
      }
    ],
    "ips": [
      "10.26.0.25"
    ],
    "name": "coredns-cc6ccd49c-8r69c",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3ab54c2_4822_4995_8591_725704afec6b.slice/cri-containerd-0dd0d411fe4b9a9b888f59e62a500b24ceb2420cf290f59bc4757551aeae6dce.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3ab54c2_4822_4995_8591_725704afec6b.slice/cri-containerd-745cda9be7e502338d05419c163455033dd397d1d5775fd359b0344f2d03218d.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3ab54c2_4822_4995_8591_725704afec6b.slice/cri-containerd-81c0d26bb5158e456f08ed20e7f4b907e1caec3244328a5a5f6a495236db499c.scope"
      }
    ],
    "ips": [
      "10.26.0.162"
    ],
    "name": "clustermesh-apiserver-5d75cc485f-w2qbj",
    "namespace": "kube-system"
  }
]

