IP ADDRESS         LOCAL ENDPOINT INFO
10.26.0.25:0       id=2710  sec_id=886133 flags=0x0000 ifindex=14  mac=C2:56:3B:CD:D7:36 nodemac=02:3D:04:D6:B0:61   
172.31.191.127:0   (localhost)                                                                                       
10.26.0.58:0       id=3051  sec_id=4     flags=0x0000 ifindex=10  mac=EE:8C:EF:66:B5:EE nodemac=3E:91:2B:6E:E9:96    
172.31.155.250:0   (localhost)                                                                                       
10.26.0.162:0      id=308   sec_id=896531 flags=0x0000 ifindex=18  mac=86:BD:F8:D4:7C:6F nodemac=0A:12:0B:E6:74:59   
10.26.0.38:0       (localhost)                                                                                       
10.26.0.4:0        id=61    sec_id=886133 flags=0x0000 ifindex=12  mac=1A:60:A9:9B:02:C5 nodemac=22:52:42:13:D7:C3   
