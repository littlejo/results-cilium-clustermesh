{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:17.824Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.155.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:17.824Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.191.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:17.824Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:22.337Z",
  "value": "id=3051  sec_id=4     flags=0x0000 ifindex=10  mac=EE:8C:EF:66:B5:EE nodemac=3E:91:2B:6E:E9:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:22.342Z",
  "value": "id=61    sec_id=886133 flags=0x0000 ifindex=12  mac=1A:60:A9:9B:02:C5 nodemac=22:52:42:13:D7:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:22.385Z",
  "value": "id=2710  sec_id=886133 flags=0x0000 ifindex=14  mac=C2:56:3B:CD:D7:36 nodemac=02:3D:04:D6:B0:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:22.421Z",
  "value": "id=3051  sec_id=4     flags=0x0000 ifindex=10  mac=EE:8C:EF:66:B5:EE nodemac=3E:91:2B:6E:E9:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:25.653Z",
  "value": "id=61    sec_id=886133 flags=0x0000 ifindex=12  mac=1A:60:A9:9B:02:C5 nodemac=22:52:42:13:D7:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:25.654Z",
  "value": "id=3051  sec_id=4     flags=0x0000 ifindex=10  mac=EE:8C:EF:66:B5:EE nodemac=3E:91:2B:6E:E9:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:25.654Z",
  "value": "id=2710  sec_id=886133 flags=0x0000 ifindex=14  mac=C2:56:3B:CD:D7:36 nodemac=02:3D:04:D6:B0:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:25.683Z",
  "value": "id=2138  sec_id=896531 flags=0x0000 ifindex=16  mac=1E:DD:5D:8D:67:AF nodemac=A6:26:93:AC:B9:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:25.684Z",
  "value": "id=2138  sec_id=896531 flags=0x0000 ifindex=16  mac=1E:DD:5D:8D:67:AF nodemac=A6:26:93:AC:B9:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:26.653Z",
  "value": "id=2138  sec_id=896531 flags=0x0000 ifindex=16  mac=1E:DD:5D:8D:67:AF nodemac=A6:26:93:AC:B9:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:26.653Z",
  "value": "id=61    sec_id=886133 flags=0x0000 ifindex=12  mac=1A:60:A9:9B:02:C5 nodemac=22:52:42:13:D7:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:26.654Z",
  "value": "id=3051  sec_id=4     flags=0x0000 ifindex=10  mac=EE:8C:EF:66:B5:EE nodemac=3E:91:2B:6E:E9:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:26.654Z",
  "value": "id=2710  sec_id=886133 flags=0x0000 ifindex=14  mac=C2:56:3B:CD:D7:36 nodemac=02:3D:04:D6:B0:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.673Z",
  "value": "id=308   sec_id=896531 flags=0x0000 ifindex=18  mac=86:BD:F8:D4:7C:6F nodemac=0A:12:0B:E6:74:59"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.26.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.040Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.300Z",
  "value": "id=3051  sec_id=4     flags=0x0000 ifindex=10  mac=EE:8C:EF:66:B5:EE nodemac=3E:91:2B:6E:E9:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.300Z",
  "value": "id=61    sec_id=886133 flags=0x0000 ifindex=12  mac=1A:60:A9:9B:02:C5 nodemac=22:52:42:13:D7:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.301Z",
  "value": "id=2710  sec_id=886133 flags=0x0000 ifindex=14  mac=C2:56:3B:CD:D7:36 nodemac=02:3D:04:D6:B0:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.301Z",
  "value": "id=308   sec_id=896531 flags=0x0000 ifindex=18  mac=86:BD:F8:D4:7C:6F nodemac=0A:12:0B:E6:74:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.303Z",
  "value": "id=308   sec_id=896531 flags=0x0000 ifindex=18  mac=86:BD:F8:D4:7C:6F nodemac=0A:12:0B:E6:74:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.306Z",
  "value": "id=3051  sec_id=4     flags=0x0000 ifindex=10  mac=EE:8C:EF:66:B5:EE nodemac=3E:91:2B:6E:E9:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.306Z",
  "value": "id=61    sec_id=886133 flags=0x0000 ifindex=12  mac=1A:60:A9:9B:02:C5 nodemac=22:52:42:13:D7:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.307Z",
  "value": "id=2710  sec_id=886133 flags=0x0000 ifindex=14  mac=C2:56:3B:CD:D7:36 nodemac=02:3D:04:D6:B0:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.300Z",
  "value": "id=61    sec_id=886133 flags=0x0000 ifindex=12  mac=1A:60:A9:9B:02:C5 nodemac=22:52:42:13:D7:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.300Z",
  "value": "id=2710  sec_id=886133 flags=0x0000 ifindex=14  mac=C2:56:3B:CD:D7:36 nodemac=02:3D:04:D6:B0:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.301Z",
  "value": "id=308   sec_id=896531 flags=0x0000 ifindex=18  mac=86:BD:F8:D4:7C:6F nodemac=0A:12:0B:E6:74:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.301Z",
  "value": "id=3051  sec_id=4     flags=0x0000 ifindex=10  mac=EE:8C:EF:66:B5:EE nodemac=3E:91:2B:6E:E9:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.300Z",
  "value": "id=2710  sec_id=886133 flags=0x0000 ifindex=14  mac=C2:56:3B:CD:D7:36 nodemac=02:3D:04:D6:B0:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.301Z",
  "value": "id=308   sec_id=896531 flags=0x0000 ifindex=18  mac=86:BD:F8:D4:7C:6F nodemac=0A:12:0B:E6:74:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.301Z",
  "value": "id=3051  sec_id=4     flags=0x0000 ifindex=10  mac=EE:8C:EF:66:B5:EE nodemac=3E:91:2B:6E:E9:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.301Z",
  "value": "id=61    sec_id=886133 flags=0x0000 ifindex=12  mac=1A:60:A9:9B:02:C5 nodemac=22:52:42:13:D7:C3"
}

