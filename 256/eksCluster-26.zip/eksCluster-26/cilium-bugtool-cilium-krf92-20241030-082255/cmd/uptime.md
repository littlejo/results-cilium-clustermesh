 08:22:56 up 38 min,  0 users,  load average: 0.11, 0.17, 0.11
