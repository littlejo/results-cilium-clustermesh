top - 08:22:56 up 38 min,  0 users,  load average: 0.11, 0.17, 0.11
Tasks:  12 total,   1 running,  11 sleeping,   0 stopped,   0 zombie
%Cpu(s): 56.7 us, 23.3 sy,  0.0 ni, 16.7 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4483.3 free,   1185.0 used,   2145.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6444.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 385372  78012 S  93.3   4.8   0:54.97 cilium-+
    663 root      20   0 1240432  16696  11484 S   6.7   0.2   0:00.03 cilium-+
    726 root      20   0 1243764  18104  13120 S   6.7   0.2   0:00.01 hubble
    414 root      20   0 1229744   8296   3836 S   0.0   0.1   0:01.17 cilium-+
    629 root      20   0 1228744   3604   2912 S   0.0   0.0   0:00.00 gops
    653 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    654 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
    678 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    698 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    717 root      20   0    2208    784    704 S   0.0   0.0   0:00.00 timeout
    723 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    747 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
