Endpoint ID: 61
Path: /sys/fs/bpf/tc/globals/cilium_policy_00061

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    177223   2043      0        
Allow    Egress      0          ANY          NONE         disabled    24703    267       0        


Endpoint ID: 308
Path: /sys/fs/bpf/tc/globals/cilium_policy_00308

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11433792   112805    0        
Allow    Ingress     1          ANY          NONE         disabled    9757733    102564    0        
Allow    Egress      0          ANY          NONE         disabled    11622874   115484    0        


Endpoint ID: 2710
Path: /sys/fs/bpf/tc/globals/cilium_policy_02710

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    178118   2051      0        
Allow    Egress      0          ANY          NONE         disabled    21376    240       0        


Endpoint ID: 3051
Path: /sys/fs/bpf/tc/globals/cilium_policy_03051

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1660935   21035     0        
Allow    Ingress     1          ANY          NONE         disabled    26264     305       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3139
Path: /sys/fs/bpf/tc/globals/cilium_policy_03139

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


