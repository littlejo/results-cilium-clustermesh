REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36949     2918965     677    bpf_overlay.c
Interface                 INGRESS     640516    131908096   1132   bpf_host.c
Success                   EGRESS      16627     1307093     1694   bpf_host.c
Success                   EGRESS      266771    33696664    1308   bpf_lxc.c
Success                   EGRESS      37010     2929303     53     encap.h
Success                   INGRESS     309944    34664340    86     l3.h
Success                   INGRESS     330917    36320258    235    trace.h
Unsupported L3 protocol   EGRESS      42        3132        1492   bpf_lxc.c
