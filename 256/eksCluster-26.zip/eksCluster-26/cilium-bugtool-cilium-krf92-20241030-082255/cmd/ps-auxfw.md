USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         698  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         678  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         663  0.0  0.1 1240432 15764 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         697  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         654  0.0  0.0 1228744 3776 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         653  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         629  0.0  0.0 1228744 3604 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  2.9  4.7 1606080 376396 ?      Ssl  07:52   0:54 cilium-agent --config-dir=/tmp/cilium/config-map
root         414  0.0  0.1 1229744 8296 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
