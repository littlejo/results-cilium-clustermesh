KEY             VALUE
AgentLiveness   2352383273773
UTimeOffset     3379441904296875
