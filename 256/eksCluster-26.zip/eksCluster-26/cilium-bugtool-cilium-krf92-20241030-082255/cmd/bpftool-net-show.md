xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 552
ens6(5) clsact/ingress cil_from_netdev-ens6 id 567
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 541
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 536
cilium_host(7) clsact/egress cil_from_host-cilium_host id 537
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 571
lxcd7bd20ac5011(12) clsact/ingress cil_from_container-lxcd7bd20ac5011 id 517
lxc6ada484b10e6(14) clsact/ingress cil_from_container-lxc6ada484b10e6 id 566
lxcda3e4187c533(18) clsact/ingress cil_from_container-lxcda3e4187c533 id 645

flow_dissector:

netfilter:

