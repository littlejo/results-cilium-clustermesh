alloc: 169.97MB (178228888 bytes)
total-alloc: 2.29GB (2456827632 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63832860
frees: 61880084
heap-alloc: 169.97MB (178228888 bytes)
heap-sys: 247.26MB (259268608 bytes)
heap-idle: 57.91MB (60719104 bytes)
heap-in-use: 189.35MB (198549504 bytes)
heap-released: 2.97MB (3112960 bytes)
heap-objects: 1952776
stack-in-use: 64.72MB (67862528 bytes)
stack-sys: 64.72MB (67862528 bytes)
stack-mspan-inuse: 3.25MB (3402720 bytes)
stack-mspan-sys: 3.77MB (3949440 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.04MB (1085489 bytes)
gc-sys: 6.02MB (6315616 bytes)
next-gc: when heap-alloc >= 213.07MB (223418024 bytes)
last-gc: 2024-10-30 08:23:01.174546732 +0000 UTC
gc-pause-total: 25.122654ms
gc-pause: 112110
gc-pause-end: 1730276581174546732
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.0003509366572046423
enable-gc: true
debug-gc: false
