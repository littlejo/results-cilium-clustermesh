[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ada7295_85d4_4c25_818b_c64075763912.slice/cri-containerd-aaae1fe7a842273798e45a9209929abc767460aad3d793287157533c1408dba9.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ada7295_85d4_4c25_818b_c64075763912.slice/cri-containerd-d3c8ac963fb2f89a9c5971cb44201b7039d69bbc7e2b943379da3039006c9f0e.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ada7295_85d4_4c25_818b_c64075763912.slice/cri-containerd-872a1ac72a44c7bfca02985a253544586329aa42eba02321f244e3b53ca81895.scope"
      }
    ],
    "ips": [
      "10.88.0.223"
    ],
    "name": "clustermesh-apiserver-956bf8fff-qs8tb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddd5874c7_aac2_47c4_beaa_84e062762f49.slice/cri-containerd-555653e746685e4153bd33c3d2bcb0820d4d77e93e9505cbd499d26077ddf2f2.scope"
      }
    ],
    "ips": [
      "10.88.0.232"
    ],
    "name": "coredns-cc6ccd49c-7tfc8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod24ff7f20_daa9_40cd_b149_d5ad1a9bc9d5.slice/cri-containerd-34fbf3642e4ede3100b6aa4f4bb9a32f0bebaf7cc693bed5645e05ea6e296c54.scope"
      }
    ],
    "ips": [
      "10.88.0.206"
    ],
    "name": "coredns-cc6ccd49c-jpfgc",
    "namespace": "kube-system"
  }
]

