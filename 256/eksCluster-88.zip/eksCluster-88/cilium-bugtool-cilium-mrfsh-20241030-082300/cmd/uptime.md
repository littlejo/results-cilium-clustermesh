 08:23:01 up 36 min,  0 users,  load average: 0.26, 0.31, 0.18
