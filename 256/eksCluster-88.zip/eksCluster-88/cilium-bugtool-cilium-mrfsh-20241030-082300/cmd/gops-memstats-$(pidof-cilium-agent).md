alloc: 180.38MB (189137096 bytes)
total-alloc: 2.30GB (2469025336 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 64075121
frees: 61940831
heap-alloc: 180.38MB (189137096 bytes)
heap-sys: 246.95MB (258940928 bytes)
heap-idle: 43.67MB (45793280 bytes)
heap-in-use: 203.27MB (213147648 bytes)
heap-released: 4.23MB (4440064 bytes)
heap-objects: 2134290
stack-in-use: 65.03MB (68190208 bytes)
stack-sys: 65.03MB (68190208 bytes)
stack-mspan-inuse: 3.49MB (3661760 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.19MB (1246969 bytes)
gc-sys: 6.02MB (6315640 bytes)
next-gc: when heap-alloc >= 215.84MB (226327912 bytes)
last-gc: 2024-10-30 08:23:03.18341659 +0000 UTC
gc-pause-total: 14.940683ms
gc-pause: 110852
gc-pause-end: 1730276583183416590
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00043031334028975166
enable-gc: true
debug-gc: false
