ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.142.24:443 (active)    
                                          2 => 172.31.208.242:443 (active)   
2    10.100.75.138:443     ClusterIP      1 => 172.31.166.5:4244 (active)    
3    10.100.0.10:53        ClusterIP      1 => 10.88.0.206:53 (active)       
                                          2 => 10.88.0.232:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.88.0.206:9153 (active)     
                                          2 => 10.88.0.232:9153 (active)     
5    10.100.213.129:2379   ClusterIP      1 => 10.88.0.223:2379 (active)     
