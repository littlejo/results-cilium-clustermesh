Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal      1      1      2    571    254     94     27     13      6      4    856 
