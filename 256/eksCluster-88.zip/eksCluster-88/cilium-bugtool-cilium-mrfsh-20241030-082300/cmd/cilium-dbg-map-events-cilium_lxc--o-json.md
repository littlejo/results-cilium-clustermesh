{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:15.973Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.134.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:15.973Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.166.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:15.973Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:20.348Z",
  "value": "id=324   sec_id=4     flags=0x0000 ifindex=10  mac=7E:A7:AE:F6:DE:8A nodemac=C2:5B:E9:06:A4:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:20.354Z",
  "value": "id=2112  sec_id=2916999 flags=0x0000 ifindex=12  mac=0A:69:FB:09:7C:C3 nodemac=02:1E:22:C8:7A:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:20.417Z",
  "value": "id=3637  sec_id=2916999 flags=0x0000 ifindex=14  mac=AE:0A:35:0E:02:70 nodemac=2A:56:4D:8C:B9:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:20.499Z",
  "value": "id=324   sec_id=4     flags=0x0000 ifindex=10  mac=7E:A7:AE:F6:DE:8A nodemac=C2:5B:E9:06:A4:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:20.558Z",
  "value": "id=2112  sec_id=2916999 flags=0x0000 ifindex=12  mac=0A:69:FB:09:7C:C3 nodemac=02:1E:22:C8:7A:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:55.319Z",
  "value": "id=324   sec_id=4     flags=0x0000 ifindex=10  mac=7E:A7:AE:F6:DE:8A nodemac=C2:5B:E9:06:A4:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:55.319Z",
  "value": "id=2112  sec_id=2916999 flags=0x0000 ifindex=12  mac=0A:69:FB:09:7C:C3 nodemac=02:1E:22:C8:7A:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:55.319Z",
  "value": "id=3637  sec_id=2916999 flags=0x0000 ifindex=14  mac=AE:0A:35:0E:02:70 nodemac=2A:56:4D:8C:B9:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:55.350Z",
  "value": "id=398   sec_id=2925869 flags=0x0000 ifindex=16  mac=E2:65:47:0A:AA:91 nodemac=A6:AC:06:AC:DA:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:56.319Z",
  "value": "id=324   sec_id=4     flags=0x0000 ifindex=10  mac=7E:A7:AE:F6:DE:8A nodemac=C2:5B:E9:06:A4:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:56.319Z",
  "value": "id=398   sec_id=2925869 flags=0x0000 ifindex=16  mac=E2:65:47:0A:AA:91 nodemac=A6:AC:06:AC:DA:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:56.319Z",
  "value": "id=2112  sec_id=2916999 flags=0x0000 ifindex=12  mac=0A:69:FB:09:7C:C3 nodemac=02:1E:22:C8:7A:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:56.320Z",
  "value": "id=3637  sec_id=2916999 flags=0x0000 ifindex=14  mac=AE:0A:35:0E:02:70 nodemac=2A:56:4D:8C:B9:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.522Z",
  "value": "id=2460  sec_id=2925869 flags=0x0000 ifindex=18  mac=8E:B3:40:45:58:3D nodemac=6E:F8:20:AD:9D:25"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.88.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:49.870Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.724Z",
  "value": "id=2460  sec_id=2925869 flags=0x0000 ifindex=18  mac=8E:B3:40:45:58:3D nodemac=6E:F8:20:AD:9D:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.725Z",
  "value": "id=324   sec_id=4     flags=0x0000 ifindex=10  mac=7E:A7:AE:F6:DE:8A nodemac=C2:5B:E9:06:A4:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.726Z",
  "value": "id=2112  sec_id=2916999 flags=0x0000 ifindex=12  mac=0A:69:FB:09:7C:C3 nodemac=02:1E:22:C8:7A:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.734Z",
  "value": "id=3637  sec_id=2916999 flags=0x0000 ifindex=14  mac=AE:0A:35:0E:02:70 nodemac=2A:56:4D:8C:B9:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.719Z",
  "value": "id=2460  sec_id=2925869 flags=0x0000 ifindex=18  mac=8E:B3:40:45:58:3D nodemac=6E:F8:20:AD:9D:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.723Z",
  "value": "id=324   sec_id=4     flags=0x0000 ifindex=10  mac=7E:A7:AE:F6:DE:8A nodemac=C2:5B:E9:06:A4:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.725Z",
  "value": "id=2112  sec_id=2916999 flags=0x0000 ifindex=12  mac=0A:69:FB:09:7C:C3 nodemac=02:1E:22:C8:7A:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.726Z",
  "value": "id=3637  sec_id=2916999 flags=0x0000 ifindex=14  mac=AE:0A:35:0E:02:70 nodemac=2A:56:4D:8C:B9:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.715Z",
  "value": "id=2112  sec_id=2916999 flags=0x0000 ifindex=12  mac=0A:69:FB:09:7C:C3 nodemac=02:1E:22:C8:7A:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.716Z",
  "value": "id=3637  sec_id=2916999 flags=0x0000 ifindex=14  mac=AE:0A:35:0E:02:70 nodemac=2A:56:4D:8C:B9:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.716Z",
  "value": "id=324   sec_id=4     flags=0x0000 ifindex=10  mac=7E:A7:AE:F6:DE:8A nodemac=C2:5B:E9:06:A4:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.716Z",
  "value": "id=2460  sec_id=2925869 flags=0x0000 ifindex=18  mac=8E:B3:40:45:58:3D nodemac=6E:F8:20:AD:9D:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.716Z",
  "value": "id=324   sec_id=4     flags=0x0000 ifindex=10  mac=7E:A7:AE:F6:DE:8A nodemac=C2:5B:E9:06:A4:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.716Z",
  "value": "id=3637  sec_id=2916999 flags=0x0000 ifindex=14  mac=AE:0A:35:0E:02:70 nodemac=2A:56:4D:8C:B9:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.716Z",
  "value": "id=2460  sec_id=2925869 flags=0x0000 ifindex=18  mac=8E:B3:40:45:58:3D nodemac=6E:F8:20:AD:9D:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.716Z",
  "value": "id=2112  sec_id=2916999 flags=0x0000 ifindex=12  mac=0A:69:FB:09:7C:C3 nodemac=02:1E:22:C8:7A:36"
}

