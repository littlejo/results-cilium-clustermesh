IP ADDRESS         LOCAL ENDPOINT INFO
10.88.0.223:0      id=2460  sec_id=2925869 flags=0x0000 ifindex=18  mac=8E:B3:40:45:58:3D nodemac=6E:F8:20:AD:9D:25   
172.31.134.207:0   (localhost)                                                                                        
172.31.166.5:0     (localhost)                                                                                        
10.88.0.228:0      (localhost)                                                                                        
10.88.0.232:0      id=3637  sec_id=2916999 flags=0x0000 ifindex=14  mac=AE:0A:35:0E:02:70 nodemac=2A:56:4D:8C:B9:FF   
10.88.0.77:0       id=324   sec_id=4     flags=0x0000 ifindex=10  mac=7E:A7:AE:F6:DE:8A nodemac=C2:5B:E9:06:A4:CE     
10.88.0.206:0      id=2112  sec_id=2916999 flags=0x0000 ifindex=12  mac=0A:69:FB:09:7C:C3 nodemac=02:1E:22:C8:7A:36   
