key: 44 01 00 00  value: 0b 02 00 00
key: 40 08 00 00  value: 1c 02 00 00
key: 9c 09 00 00  value: 72 02 00 00
key: 35 0e 00 00  value: fd 01 00 00
Found 4 elements
