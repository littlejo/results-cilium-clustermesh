Endpoint ID: 324
Path: /sys/fs/bpf/tc/globals/cilium_policy_00324

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1665431   21067     0        
Allow    Ingress     1          ANY          NONE         disabled    26094     305       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2112
Path: /sys/fs/bpf/tc/globals/cilium_policy_02112

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    175330   2021      0        
Allow    Egress      0          ANY          NONE         disabled    21038    236       0        


Endpoint ID: 2460
Path: /sys/fs/bpf/tc/globals/cilium_policy_02460

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11491468   113543    0        
Allow    Ingress     1          ANY          NONE         disabled    9960971    104789    0        
Allow    Egress      0          ANY          NONE         disabled    12020375   119133    0        


Endpoint ID: 3201
Path: /sys/fs/bpf/tc/globals/cilium_policy_03201

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3637
Path: /sys/fs/bpf/tc/globals/cilium_policy_03637

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174604   2010      0        
Allow    Egress      0          ANY          NONE         disabled    21801    244       0        


