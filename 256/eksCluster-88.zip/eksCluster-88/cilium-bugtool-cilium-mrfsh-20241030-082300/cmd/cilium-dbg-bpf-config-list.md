KEY             VALUE
AgentLiveness   2213532191073
UTimeOffset     3379442185546875
