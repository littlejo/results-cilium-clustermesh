markdown output at /tmp/cilium-bugtool-20241030-082301.657+0000-UTC-430796673/cmd/cilium-debuginfo-20241030-082332.88+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082301.657+0000-UTC-430796673/cmd/cilium-debuginfo-20241030-082332.88+0000-UTC.json
