REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36963     2922071     677    bpf_overlay.c
Interface                 INGRESS     646206    132265613   1132   bpf_host.c
Success                   EGRESS      16628     1307175     1694   bpf_host.c
Success                   EGRESS      268841    33942821    1308   bpf_lxc.c
Success                   EGRESS      37029     2931975     53     encap.h
Success                   INGRESS     313284    35119874    86     l3.h
Success                   INGRESS     334270    36778816    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
