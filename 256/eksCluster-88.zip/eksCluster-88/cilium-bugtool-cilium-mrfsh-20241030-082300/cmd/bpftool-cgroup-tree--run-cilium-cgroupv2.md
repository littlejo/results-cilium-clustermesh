CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddd5874c7_aac2_47c4_beaa_84e062762f49.slice/cri-containerd-fd51627c1510f0b7633a42087fb642f14cab4dd71a4cc71a4e86e76b0c53c152.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddd5874c7_aac2_47c4_beaa_84e062762f49.slice/cri-containerd-555653e746685e4153bd33c3d2bcb0820d4d77e93e9505cbd499d26077ddf2f2.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e1ce4e6_6ba9_4858_a68f_3221ee6a1ae6.slice/cri-containerd-e3e96d65e8b7b5dfb89ad3f7c24e60b686b01ce98dd7f9b5abd9f7c484e4ccd4.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e1ce4e6_6ba9_4858_a68f_3221ee6a1ae6.slice/cri-containerd-c8dee20eeedefbb4211facd84dacf5e1df86eb592a4ace640f602107af78b12f.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod24ff7f20_daa9_40cd_b149_d5ad1a9bc9d5.slice/cri-containerd-34fbf3642e4ede3100b6aa4f4bb9a32f0bebaf7cc693bed5645e05ea6e296c54.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod24ff7f20_daa9_40cd_b149_d5ad1a9bc9d5.slice/cri-containerd-4c0b1c61f539ef3bcc26cd8006c2d8e198e40042088fc768f1a13835a6ba8773.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbcca731a_c60b_46c5_810e_abf8e14c0149.slice/cri-containerd-852bbe68a59c769957bfaac38a0d468dce4729237af00e594b16a8256e2524a2.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbcca731a_c60b_46c5_810e_abf8e14c0149.slice/cri-containerd-913b577e1580638fca8ba718374c9ce93ab2638ff76748cead58b71c0216c1d6.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2196c704_985f_48d5_9e34_c980afcb63f3.slice/cri-containerd-df42ec5b6c8007703ba2168c19e725b0e755869f412804c7288abce5662c6f0f.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2196c704_985f_48d5_9e34_c980afcb63f3.slice/cri-containerd-74cd36a744738427cbb15168e51ec2d192e6589ac1aa906cf58ca5de81f068a6.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod622d397d_e6da_4eb6_aaad_3b9b51016c7d.slice/cri-containerd-2b8f1d4cdceb73af18bba7569b68347cbbd6774ecd588524a8e202dca0438b4d.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod622d397d_e6da_4eb6_aaad_3b9b51016c7d.slice/cri-containerd-7a75721590d6e79c32a693bb451c627e8c90168a157b68edfad2306f57bf552e.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ada7295_85d4_4c25_818b_c64075763912.slice/cri-containerd-d3c8ac963fb2f89a9c5971cb44201b7039d69bbc7e2b943379da3039006c9f0e.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ada7295_85d4_4c25_818b_c64075763912.slice/cri-containerd-aaae1fe7a842273798e45a9209929abc767460aad3d793287157533c1408dba9.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ada7295_85d4_4c25_818b_c64075763912.slice/cri-containerd-b422aced24c0c0c01163bdbc7df839bdc1f03e85ddd8c82057f7822c8e11841d.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ada7295_85d4_4c25_818b_c64075763912.slice/cri-containerd-872a1ac72a44c7bfca02985a253544586329aa42eba02321f244e3b53ca81895.scope
    658      cgroup_device   multi                                          
