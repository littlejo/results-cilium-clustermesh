 08:22:48 up 36 min,  0 users,  load average: 0.58, 0.42, 0.23
