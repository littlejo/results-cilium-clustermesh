REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36568     2895362     677    bpf_overlay.c
Interface                 INGRESS     650924    133832739   1132   bpf_host.c
Success                   EGRESS      16546     1301971     1694   bpf_host.c
Success                   EGRESS      277249    34357922    1308   bpf_lxc.c
Success                   EGRESS      36847     2914798     53     encap.h
Success                   INGRESS     319566    36216728    86     l3.h
Success                   INGRESS     340239    37854165    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
