1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:76:ab:e4:ec:5b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.181.183/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3209sec preferred_lft 3209sec
    inet6 fe80::476:abff:fee4:ec5b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:df:57:78:5f:c3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.134.76/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4df:57ff:fe78:5fc3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:25:47:b3:96:a8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::25:47ff:feb3:96a8/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:43:b2:5f:34:51 brd ff:ff:ff:ff:ff:ff
    inet 10.106.0.34/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::6443:b2ff:fe5f:3451/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 7e:be:11:08:56:64 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7cbe:11ff:fe08:5664/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:fc:e8:85:3b:1f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d8fc:e8ff:fe85:3b1f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxceee7124607aa@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:54:97:82:dd:28 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::fc54:97ff:fe82:dd28/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc5b8383666fe9@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:32:27:da:a2:72 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::5c32:27ff:feda:a272/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc4484a9f3697c@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:8c:4b:41:01:6f brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::808c:4bff:fe41:16f/64 scope link 
       valid_lft forever preferred_lft forever
