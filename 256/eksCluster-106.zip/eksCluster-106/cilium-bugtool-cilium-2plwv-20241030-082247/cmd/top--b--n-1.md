top - 08:22:49 up 36 min,  0 users,  load average: 0.58, 0.42, 0.23
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 69.0 us, 20.7 sy,  0.0 ni,  6.9 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   7814.2 total,   4488.1 free,   1179.8 used,   2146.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6449.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 385772  78332 S  86.7   4.8   0:53.90 cilium-+
    705 root      20   0 1240432  16624  11292 S   6.7   0.2   0:00.03 cilium-+
    772 root      20   0 1243764  17944  12992 S   6.7   0.2   0:00.01 hubble
    419 root      20   0 1229744   7268   3052 S   0.0   0.1   0:01.16 cilium-+
    671 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    680 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    690 root      20   0 1228744   3604   2912 S   0.0   0.0   0:00.00 gops
    710 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    740 root      20   0    6576   2420   2096 R   0.0   0.0   0:00.00 top
    753 root      20   0    2208    776    696 S   0.0   0.0   0:00.00 timeout
    766 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
