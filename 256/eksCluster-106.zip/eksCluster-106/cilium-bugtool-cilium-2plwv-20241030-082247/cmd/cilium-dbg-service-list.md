ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.145.19:443 (active)     
                                          2 => 172.31.202.130:443 (active)    
2    10.100.175.210:443    ClusterIP      1 => 172.31.181.183:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.106.0.63:53 (active)        
                                          2 => 10.106.0.60:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.106.0.63:9153 (active)      
                                          2 => 10.106.0.60:9153 (active)      
5    10.100.103.223:2379   ClusterIP      1 => 10.106.0.35:2379 (active)      
