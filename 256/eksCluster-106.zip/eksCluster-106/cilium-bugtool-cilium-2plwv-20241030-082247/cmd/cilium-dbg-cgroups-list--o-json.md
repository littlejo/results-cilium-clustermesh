[
  {
    "containers": [
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95f675ed_a558_49d2_be42_c9d9592ceb4c.slice/cri-containerd-dd907cd1e13f1a7ed5e2645e2a8fd489457446485be128c9bd28961183370700.scope"
      },
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95f675ed_a558_49d2_be42_c9d9592ceb4c.slice/cri-containerd-05c3ee304347524159ea26a414ed5be0d9f9630fa0961ad3bedfb46ad9c4568c.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95f675ed_a558_49d2_be42_c9d9592ceb4c.slice/cri-containerd-ea28562d2764bd53910d70d676578fb10b67583960ab3e9765c9c8d81e4c9264.scope"
      }
    ],
    "ips": [
      "10.106.0.35"
    ],
    "name": "clustermesh-apiserver-55fccf5fc4-rtnh6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7662,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5cef7086_5a8e_484f_8e61_ccea68de5754.slice/cri-containerd-e30d6f4dd430a44f1cd1e035381bc9792ad52905c93457a593aa5dc59e7513ab.scope"
      }
    ],
    "ips": [
      "10.106.0.63"
    ],
    "name": "coredns-cc6ccd49c-tscj4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7830,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf00316a4_f434_4ccb_9641_3aec435c727f.slice/cri-containerd-76678fb293dd4ab16a6ad148d824f9646f2165b0d5d3811b532cb960ce5b0672.scope"
      }
    ],
    "ips": [
      "10.106.0.60"
    ],
    "name": "coredns-cc6ccd49c-22r5v",
    "namespace": "kube-system"
  }
]

