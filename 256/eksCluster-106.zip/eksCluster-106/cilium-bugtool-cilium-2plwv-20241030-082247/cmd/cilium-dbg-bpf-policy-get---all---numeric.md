Endpoint ID: 962
Path: /sys/fs/bpf/tc/globals/cilium_policy_00962

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174208   2004      0        
Allow    Egress      0          ANY          NONE         disabled    20899    235       0        


Endpoint ID: 2014
Path: /sys/fs/bpf/tc/globals/cilium_policy_02014

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11528874   115524    0        
Allow    Ingress     1          ANY          NONE         disabled    10171514   106988    0        
Allow    Egress      0          ANY          NONE         disabled    13767021   134709    0        


Endpoint ID: 2230
Path: /sys/fs/bpf/tc/globals/cilium_policy_02230

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    173680   1996      0        
Allow    Egress      0          ANY          NONE         disabled    21118    236       0        


Endpoint ID: 2344
Path: /sys/fs/bpf/tc/globals/cilium_policy_02344

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1640814   20713     0        
Allow    Ingress     1          ANY          NONE         disabled    26000     302       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2504
Path: /sys/fs/bpf/tc/globals/cilium_policy_02504

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


