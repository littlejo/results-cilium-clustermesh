key: c2 03 00 00  value: 1f 02 00 00
key: de 07 00 00  value: 7d 02 00 00
key: b6 08 00 00  value: 19 02 00 00
key: 28 09 00 00  value: 2b 02 00 00
Found 4 elements
