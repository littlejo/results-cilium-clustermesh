IP ADDRESS         LOCAL ENDPOINT INFO
10.106.0.34:0      (localhost)                                                                                        
10.106.0.35:0      id=2014  sec_id=3507584 flags=0x0000 ifindex=18  mac=26:EA:87:E7:CE:74 nodemac=82:8C:4B:41:01:6F   
172.31.181.183:0   (localhost)                                                                                        
10.106.0.63:0      id=2230  sec_id=3513676 flags=0x0000 ifindex=12  mac=66:F9:42:73:24:99 nodemac=FE:54:97:82:DD:28   
10.106.0.60:0      id=962   sec_id=3513676 flags=0x0000 ifindex=14  mac=EA:16:CA:2D:83:18 nodemac=5E:32:27:DA:A2:72   
10.106.0.165:0     id=2344  sec_id=4     flags=0x0000 ifindex=10  mac=FA:FA:F9:00:9B:7B nodemac=DA:FC:E8:85:3B:1F     
172.31.134.76:0    (localhost)                                                                                        
