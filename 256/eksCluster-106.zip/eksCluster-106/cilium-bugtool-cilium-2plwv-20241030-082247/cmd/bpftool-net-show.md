xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 588
ens6(5) clsact/ingress cil_from_netdev-ens6 id 592
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 579
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 572
cilium_host(7) clsact/egress cil_from_host-cilium_host id 573
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 506
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 505
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 563
lxceee7124607aa(12) clsact/ingress cil_from_container-lxceee7124607aa id 532
lxc5b8383666fe9(14) clsact/ingress cil_from_container-lxc5b8383666fe9 id 547
lxc4484a9f3697c(18) clsact/ingress cil_from_container-lxc4484a9f3697c id 639

flow_dissector:

netfilter:

