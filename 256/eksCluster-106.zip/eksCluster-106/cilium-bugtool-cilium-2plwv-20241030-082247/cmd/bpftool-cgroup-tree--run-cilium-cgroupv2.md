CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf00316a4_f434_4ccb_9641_3aec435c727f.slice/cri-containerd-76678fb293dd4ab16a6ad148d824f9646f2165b0d5d3811b532cb960ce5b0672.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf00316a4_f434_4ccb_9641_3aec435c727f.slice/cri-containerd-572923d6155c213245e0c111730e93e087c1e1822fba5413d3612ca18b20196c.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb3a5bbed_3568_4ab0_85bc_6fbc3c9e991a.slice/cri-containerd-ca8b0f0f908f8689aba07774aaf76c94b1cc77d0244c47816509048f5438f662.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb3a5bbed_3568_4ab0_85bc_6fbc3c9e991a.slice/cri-containerd-aa05834c6f9b0d64888f272c1751d36feb7bff0d227de1f05bf2df9013a65aee.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6b699c8_668a_47e7_af0f_7130d43b97d2.slice/cri-containerd-ea020f0a2e35360d7102dbbdfc2bcbbc80acf7d89a3f9ffcd3a8a07bdbcf9b3a.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6b699c8_668a_47e7_af0f_7130d43b97d2.slice/cri-containerd-dac122627cb4f96031bd17fe95b0edb25768b3ab8526c93e4913c0618bc830fc.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5cef7086_5a8e_484f_8e61_ccea68de5754.slice/cri-containerd-e30d6f4dd430a44f1cd1e035381bc9792ad52905c93457a593aa5dc59e7513ab.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5cef7086_5a8e_484f_8e61_ccea68de5754.slice/cri-containerd-b04ec1a0329f6790cc3646f0c511d0d70a2a191e0223286a607e7b359c1b7414.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb19a4d50_4364_4ef3_b66f_f23094a6227c.slice/cri-containerd-c9661267b5bf112d3d33c544e093d6a101bb481cac7426691427998df98af12f.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb19a4d50_4364_4ef3_b66f_f23094a6227c.slice/cri-containerd-e25c40df5536e10903889fd46cb0ebd184e1b065db982afd6735d3f4bf79616d.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbff64cc9_f2f0_40f5_94af_f55ad9079b7f.slice/cri-containerd-866a4138a267d48a37c597a67f55dbda7c0aa0565891760f2767ba18e9831bfa.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbff64cc9_f2f0_40f5_94af_f55ad9079b7f.slice/cri-containerd-5ad2b0133de9057cd8c4bd8b671ba03b7500caacd64f29f621d3ec5bfaa30d76.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95f675ed_a558_49d2_be42_c9d9592ceb4c.slice/cri-containerd-b790160357a4bebb2d54ab35ded538eec397b9bbc4324c806300486b5b722f66.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95f675ed_a558_49d2_be42_c9d9592ceb4c.slice/cri-containerd-dd907cd1e13f1a7ed5e2645e2a8fd489457446485be128c9bd28961183370700.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95f675ed_a558_49d2_be42_c9d9592ceb4c.slice/cri-containerd-ea28562d2764bd53910d70d676578fb10b67583960ab3e9765c9c8d81e4c9264.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95f675ed_a558_49d2_be42_c9d9592ceb4c.slice/cri-containerd-05c3ee304347524159ea26a414ed5be0d9f9630fa0961ad3bedfb46ad9c4568c.scope
    671      cgroup_device   multi                                          
