USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         710  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         705  0.0  0.2 1240432 16624 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         729  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         690  0.0  0.0 1228744 3604 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         680  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         671  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  2.9  4.7 1606080 378788 ?      Ssl  07:52   0:53 cilium-agent --config-dir=/tmp/cilium/config-map
root         419  0.0  0.0 1229744 7268 ?        Sl   07:53   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
