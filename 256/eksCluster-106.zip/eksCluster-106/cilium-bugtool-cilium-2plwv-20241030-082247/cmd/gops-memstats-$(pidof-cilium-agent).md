alloc: 126.50MB (132649240 bytes)
total-alloc: 2.33GB (2498075968 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 64530894
frees: 63458180
heap-alloc: 126.50MB (132649240 bytes)
heap-sys: 251.61MB (263831552 bytes)
heap-idle: 83.27MB (87310336 bytes)
heap-in-use: 168.34MB (176521216 bytes)
heap-released: 12.72MB (13336576 bytes)
heap-objects: 1072714
stack-in-use: 64.34MB (67469312 bytes)
stack-sys: 64.34MB (67469312 bytes)
stack-mspan-inuse: 2.83MB (2971520 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.02MB (1068865 bytes)
gc-sys: 6.04MB (6329904 bytes)
next-gc: when heap-alloc >= 212.65MB (222983912 bytes)
last-gc: 2024-10-30 08:23:06.842523786 +0000 UTC
gc-pause-total: 15.691921ms
gc-pause: 100064
gc-pause-end: 1730276586842523786
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.000332553130541532
enable-gc: true
debug-gc: false
