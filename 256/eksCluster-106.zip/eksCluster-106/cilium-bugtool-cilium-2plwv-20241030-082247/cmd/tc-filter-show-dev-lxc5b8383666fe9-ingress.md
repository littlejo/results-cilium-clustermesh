filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc5b8383666fe9 direct-action not_in_hw id 547 tag 995e09035fcf72b1 jited 
