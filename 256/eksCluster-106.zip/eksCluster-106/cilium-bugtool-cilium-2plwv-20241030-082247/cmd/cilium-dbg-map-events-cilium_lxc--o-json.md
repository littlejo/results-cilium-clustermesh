{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:04.066Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.134.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:04.066Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.181.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:04.066Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:07.353Z",
  "value": "id=2230  sec_id=3513676 flags=0x0000 ifindex=12  mac=66:F9:42:73:24:99 nodemac=FE:54:97:82:DD:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:10.573Z",
  "value": "id=962   sec_id=3513676 flags=0x0000 ifindex=14  mac=EA:16:CA:2D:83:18 nodemac=5E:32:27:DA:A2:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:10.582Z",
  "value": "id=2344  sec_id=4     flags=0x0000 ifindex=10  mac=FA:FA:F9:00:9B:7B nodemac=DA:FC:E8:85:3B:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:10.631Z",
  "value": "id=2230  sec_id=3513676 flags=0x0000 ifindex=12  mac=66:F9:42:73:24:99 nodemac=FE:54:97:82:DD:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:10.671Z",
  "value": "id=962   sec_id=3513676 flags=0x0000 ifindex=14  mac=EA:16:CA:2D:83:18 nodemac=5E:32:27:DA:A2:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:10.725Z",
  "value": "id=2344  sec_id=4     flags=0x0000 ifindex=10  mac=FA:FA:F9:00:9B:7B nodemac=DA:FC:E8:85:3B:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:37.917Z",
  "value": "id=2230  sec_id=3513676 flags=0x0000 ifindex=12  mac=66:F9:42:73:24:99 nodemac=FE:54:97:82:DD:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:37.918Z",
  "value": "id=962   sec_id=3513676 flags=0x0000 ifindex=14  mac=EA:16:CA:2D:83:18 nodemac=5E:32:27:DA:A2:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:37.918Z",
  "value": "id=2344  sec_id=4     flags=0x0000 ifindex=10  mac=FA:FA:F9:00:9B:7B nodemac=DA:FC:E8:85:3B:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:37.951Z",
  "value": "id=934   sec_id=3507584 flags=0x0000 ifindex=16  mac=26:BC:C7:8E:C5:3A nodemac=86:54:E7:41:F1:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:37.952Z",
  "value": "id=934   sec_id=3507584 flags=0x0000 ifindex=16  mac=26:BC:C7:8E:C5:3A nodemac=86:54:E7:41:F1:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:38.918Z",
  "value": "id=2230  sec_id=3513676 flags=0x0000 ifindex=12  mac=66:F9:42:73:24:99 nodemac=FE:54:97:82:DD:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:38.918Z",
  "value": "id=934   sec_id=3507584 flags=0x0000 ifindex=16  mac=26:BC:C7:8E:C5:3A nodemac=86:54:E7:41:F1:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:38.919Z",
  "value": "id=962   sec_id=3513676 flags=0x0000 ifindex=14  mac=EA:16:CA:2D:83:18 nodemac=5E:32:27:DA:A2:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:38.919Z",
  "value": "id=2344  sec_id=4     flags=0x0000 ifindex=10  mac=FA:FA:F9:00:9B:7B nodemac=DA:FC:E8:85:3B:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.144Z",
  "value": "id=2014  sec_id=3507584 flags=0x0000 ifindex=18  mac=26:EA:87:E7:CE:74 nodemac=82:8C:4B:41:01:6F"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.106.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.569Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.038Z",
  "value": "id=2014  sec_id=3507584 flags=0x0000 ifindex=18  mac=26:EA:87:E7:CE:74 nodemac=82:8C:4B:41:01:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.039Z",
  "value": "id=2344  sec_id=4     flags=0x0000 ifindex=10  mac=FA:FA:F9:00:9B:7B nodemac=DA:FC:E8:85:3B:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.039Z",
  "value": "id=2230  sec_id=3513676 flags=0x0000 ifindex=12  mac=66:F9:42:73:24:99 nodemac=FE:54:97:82:DD:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.040Z",
  "value": "id=962   sec_id=3513676 flags=0x0000 ifindex=14  mac=EA:16:CA:2D:83:18 nodemac=5E:32:27:DA:A2:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.052Z",
  "value": "id=2230  sec_id=3513676 flags=0x0000 ifindex=12  mac=66:F9:42:73:24:99 nodemac=FE:54:97:82:DD:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.053Z",
  "value": "id=962   sec_id=3513676 flags=0x0000 ifindex=14  mac=EA:16:CA:2D:83:18 nodemac=5E:32:27:DA:A2:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.053Z",
  "value": "id=2344  sec_id=4     flags=0x0000 ifindex=10  mac=FA:FA:F9:00:9B:7B nodemac=DA:FC:E8:85:3B:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.053Z",
  "value": "id=2014  sec_id=3507584 flags=0x0000 ifindex=18  mac=26:EA:87:E7:CE:74 nodemac=82:8C:4B:41:01:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.041Z",
  "value": "id=2014  sec_id=3507584 flags=0x0000 ifindex=18  mac=26:EA:87:E7:CE:74 nodemac=82:8C:4B:41:01:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.041Z",
  "value": "id=2344  sec_id=4     flags=0x0000 ifindex=10  mac=FA:FA:F9:00:9B:7B nodemac=DA:FC:E8:85:3B:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.041Z",
  "value": "id=2230  sec_id=3513676 flags=0x0000 ifindex=12  mac=66:F9:42:73:24:99 nodemac=FE:54:97:82:DD:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.041Z",
  "value": "id=962   sec_id=3513676 flags=0x0000 ifindex=14  mac=EA:16:CA:2D:83:18 nodemac=5E:32:27:DA:A2:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.042Z",
  "value": "id=962   sec_id=3513676 flags=0x0000 ifindex=14  mac=EA:16:CA:2D:83:18 nodemac=5E:32:27:DA:A2:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.042Z",
  "value": "id=2344  sec_id=4     flags=0x0000 ifindex=10  mac=FA:FA:F9:00:9B:7B nodemac=DA:FC:E8:85:3B:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.042Z",
  "value": "id=2014  sec_id=3507584 flags=0x0000 ifindex=18  mac=26:EA:87:E7:CE:74 nodemac=82:8C:4B:41:01:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.043Z",
  "value": "id=2230  sec_id=3513676 flags=0x0000 ifindex=12  mac=66:F9:42:73:24:99 nodemac=FE:54:97:82:DD:28"
}

