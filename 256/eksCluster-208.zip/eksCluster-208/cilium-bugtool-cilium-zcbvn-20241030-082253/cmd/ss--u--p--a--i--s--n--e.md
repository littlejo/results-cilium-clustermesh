Total: 666
TCP:   1837 (estab 419, closed 1399, orphaned 0, timewait 566)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  438       427       11       
INET	  448       433       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.171.115%ens5:68         0.0.0.0:*    uid:192 ino:15719 sk:3e2 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:36431 sk:3e3 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15539 sk:3e4 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:39157      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=41)) ino:36279 sk:3e5 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:36430 sk:3e6 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15540 sk:3e7 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::4d6:85ff:fe90:fc95]%ens5:546           [::]:*    uid:192 ino:15716 sk:3e8 cgroup:unreachable:c4e v6only:1 <->                   
