REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37864     3004383     677    bpf_overlay.c
Interface                 INGRESS     674663    136309136   1132   bpf_host.c
Success                   EGRESS      15300     2424690     86     l3.h
Success                   EGRESS      17672     1396555     1694   bpf_host.c
Success                   EGRESS      292174    35827200    1308   bpf_lxc.c
Success                   EGRESS      38850     3074507     53     encap.h
Success                   INGRESS     333875    38118298    86     l3.h
Success                   INGRESS     370018    42194862    235    trace.h
Unsupported L3 protocol   EGRESS      39        2902        1492   bpf_lxc.c
