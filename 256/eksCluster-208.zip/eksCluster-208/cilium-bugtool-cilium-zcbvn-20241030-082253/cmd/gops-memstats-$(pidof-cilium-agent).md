alloc: 127.83MB (134043080 bytes)
total-alloc: 2.38GB (2560819672 bytes)
sys: 333.02MB (349196644 bytes)
lookups: 0
mallocs: 65984095
frees: 65277015
heap-alloc: 127.83MB (134043080 bytes)
heap-sys: 259.44MB (272039936 bytes)
heap-idle: 70.75MB (74186752 bytes)
heap-in-use: 188.69MB (197853184 bytes)
heap-released: 11.68MB (12247040 bytes)
heap-objects: 707080
stack-in-use: 60.16MB (63078400 bytes)
stack-sys: 60.16MB (63078400 bytes)
stack-mspan-inuse: 3.08MB (3229600 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.24MB (1301521 bytes)
gc-sys: 6.39MB (6704688 bytes)
next-gc: when heap-alloc >= 232.53MB (243823144 bytes)
last-gc: 2024-10-30 08:23:25.117595019 +0000 UTC
gc-pause-total: 17.147252ms
gc-pause: 587414
gc-pause-end: 1730276605117595019
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0006030276485114603
enable-gc: true
debug-gc: false
