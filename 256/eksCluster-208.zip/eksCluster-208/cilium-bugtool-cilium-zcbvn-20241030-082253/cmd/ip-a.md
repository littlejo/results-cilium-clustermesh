1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d6:85:90:fc:95 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.171.115/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1816sec preferred_lft 1816sec
    inet6 fe80::4d6:85ff:fe90:fc95/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:17:0f:c0:a5:97 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.158.79/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::417:fff:fec0:a597/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:ff:cd:8c:24:41 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a8ff:cdff:fe8c:2441/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:af:a6:dc:80:94 brd ff:ff:ff:ff:ff:ff
    inet 10.208.0.96/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::8caf:a6ff:fedc:8094/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 4e:2c:12:b6:aa:4b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4c2c:12ff:feb6:aa4b/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:1a:2a:37:e7:81 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b81a:2aff:fe37:e781/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb7b4430dbcf6@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:48:5c:cf:e0:5b brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::848:5cff:fecf:e05b/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcd0c3b0556bd7@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:d4:55:0e:22:0b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::34d4:55ff:fe0e:220b/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc069e3434439a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:31:91:75:31:1d brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::5831:91ff:fe75:311d/64 scope link 
       valid_lft forever preferred_lft forever
