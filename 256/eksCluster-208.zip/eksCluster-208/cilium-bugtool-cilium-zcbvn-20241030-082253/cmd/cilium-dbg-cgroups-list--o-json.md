[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62fe99ba_8d57_4d21_8d1a_a6fad9fd4ed9.slice/cri-containerd-2d5bb5803fe68fc81f26a0896078b9b68ab69d8362142e41b88fd47b155e2710.scope"
      }
    ],
    "ips": [
      "10.208.0.215"
    ],
    "name": "coredns-cc6ccd49c-xpqzq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod249c1792_3d55_4d95_8f67_59c28693998d.slice/cri-containerd-22d2ff5d5777d4e2c879267785938ee65a23af2b344174d0c79c9070c64994d6.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod249c1792_3d55_4d95_8f67_59c28693998d.slice/cri-containerd-f91eed29b4a205b58215e5aa32859a2221de224baf59e18ad95395d26cf7f6ce.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod249c1792_3d55_4d95_8f67_59c28693998d.slice/cri-containerd-02eaa0abc5aa1fbea91c7309cf10bf5763433ccf3c8639f6d3da262e29836174.scope"
      }
    ],
    "ips": [
      "10.208.0.160"
    ],
    "name": "clustermesh-apiserver-6f9986d47f-szszl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf7b5bf3c_172d_4021_b093_b4d3af2a5e19.slice/cri-containerd-ee992026d44cc9cf10c3c7819b5c6a1daea2c6a26be9d24befd1a3116c18eeb4.scope"
      }
    ],
    "ips": [
      "10.208.0.59"
    ],
    "name": "coredns-cc6ccd49c-4zcvk",
    "namespace": "kube-system"
  }
]

