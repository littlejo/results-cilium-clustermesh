ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.164.91:443 (active)     
                                         2 => 172.31.214.107:443 (active)    
2    10.100.164.159:443   ClusterIP      1 => 172.31.171.115:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.208.0.59:53 (active)        
                                         2 => 10.208.0.215:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.208.0.59:9153 (active)      
                                         2 => 10.208.0.215:9153 (active)     
5    10.100.43.21:2379    ClusterIP      1 => 10.208.0.160:2379 (active)     
