Endpoint ID: 298
Path: /sys/fs/bpf/tc/globals/cilium_policy_00298

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    422820   3792      0        
Allow    Ingress     1          ANY          NONE         disabled    116692   1339      0        
Allow    Egress      0          ANY          NONE         disabled    109224   1044      0        


Endpoint ID: 1313
Path: /sys/fs/bpf/tc/globals/cilium_policy_01313

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1346
Path: /sys/fs/bpf/tc/globals/cilium_policy_01346

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1655578   20890     0        
Allow    Ingress     1          ANY          NONE         disabled    18434     217       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3257
Path: /sys/fs/bpf/tc/globals/cilium_policy_03257

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11514866   116322    0        
Allow    Ingress     1          ANY          NONE         disabled    11017359   116520    0        
Allow    Egress      0          ANY          NONE         disabled    15209818   148331    0        


Endpoint ID: 3739
Path: /sys/fs/bpf/tc/globals/cilium_policy_03739

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    429210   3858      0        
Allow    Ingress     1          ANY          NONE         disabled    116453   1339      0        
Allow    Egress      0          ANY          NONE         disabled    113579   1084      0        


