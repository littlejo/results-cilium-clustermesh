key: 05 00 00 00  value: ac 1f ab 73 10 94 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f a4 5b 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a d0 00 3b 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f d6 6b 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: 0a d0 00 3b 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a d0 00 a0 09 4b 00 00  00 00 00 00
key: 08 00 00 00  value: 0a d0 00 d7 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a d0 00 d7 23 c1 00 00  00 00 00 00
Found 8 elements
