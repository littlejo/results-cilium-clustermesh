CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8f17126f_ff3b_40ce_86d1_6a0d1995e362.slice/cri-containerd-79dbfede468616d043663c280bb4a6c68418048cabec9e6834420e6b9a89ad6a.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8f17126f_ff3b_40ce_86d1_6a0d1995e362.slice/cri-containerd-06c374b552872ad9e8f676ff0744f3841675ed56e73e1d96bbaef3e07f97a38c.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62fe99ba_8d57_4d21_8d1a_a6fad9fd4ed9.slice/cri-containerd-2d5bb5803fe68fc81f26a0896078b9b68ab69d8362142e41b88fd47b155e2710.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62fe99ba_8d57_4d21_8d1a_a6fad9fd4ed9.slice/cri-containerd-30314f67b707616b576d9c56bf5df33f9389dbcee799b5821a90a5243b413a37.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod48301357_d055_44ae_8815_9ff395609222.slice/cri-containerd-914eb2b8f564143e48c22b7979d66d79671ac77f003573efe00b5d3039083548.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod48301357_d055_44ae_8815_9ff395609222.slice/cri-containerd-2023fa96f5439a9cd1d8f4ab3b9d43488eed1ca47d98a997105d7e7ede70f77f.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf7b5bf3c_172d_4021_b093_b4d3af2a5e19.slice/cri-containerd-e0391cd40d86943b2d48cf318cbe7fd0b5f5c0d1da57d01290d0ee00878745ac.scope
    547      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf7b5bf3c_172d_4021_b093_b4d3af2a5e19.slice/cri-containerd-ee992026d44cc9cf10c3c7819b5c6a1daea2c6a26be9d24befd1a3116c18eeb4.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podad5d5570_9d37_479a_93f7_c9e35b7e6f4b.slice/cri-containerd-8279f5240dc8f4e73207c6e9a89729e2ee3af461512c6d27cde583a74c456ed6.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podad5d5570_9d37_479a_93f7_c9e35b7e6f4b.slice/cri-containerd-6c94e136e0bd836acebb4cac20c1ba7558000e6bf36cafbce405cae37786acb6.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod249c1792_3d55_4d95_8f67_59c28693998d.slice/cri-containerd-02eaa0abc5aa1fbea91c7309cf10bf5763433ccf3c8639f6d3da262e29836174.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod249c1792_3d55_4d95_8f67_59c28693998d.slice/cri-containerd-22d2ff5d5777d4e2c879267785938ee65a23af2b344174d0c79c9070c64994d6.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod249c1792_3d55_4d95_8f67_59c28693998d.slice/cri-containerd-938d7c2f3525e4988589375aed92050a7fb62e4f91c90fad0e6bf2b431fb7691.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod249c1792_3d55_4d95_8f67_59c28693998d.slice/cri-containerd-f91eed29b4a205b58215e5aa32859a2221de224baf59e18ad95395d26cf7f6ce.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5aaf002c_12b7_4092_aae4_b0e65ac5cbd3.slice/cri-containerd-fc45b961b0d1598ca691dd9af316170660e10bad3ee2924de5e18618a90e41a0.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5aaf002c_12b7_4092_aae4_b0e65ac5cbd3.slice/cri-containerd-1a129626403de1fa7af015f7e7a7341026902c7c004328045408922ba9c827fc.scope
    98       cgroup_device   multi                                          
