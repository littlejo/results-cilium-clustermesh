KEY             VALUE
AgentLiveness   1824497062309
UTimeOffset     3379442931640625
