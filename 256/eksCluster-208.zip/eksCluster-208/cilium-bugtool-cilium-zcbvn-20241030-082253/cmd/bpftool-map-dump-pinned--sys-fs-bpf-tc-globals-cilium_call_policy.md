key: 2a 01 00 00  value: 16 02 00 00
key: 42 05 00 00  value: 0b 02 00 00
key: b9 0c 00 00  value: 74 02 00 00
key: 9b 0e 00 00  value: 05 02 00 00
Found 4 elements
