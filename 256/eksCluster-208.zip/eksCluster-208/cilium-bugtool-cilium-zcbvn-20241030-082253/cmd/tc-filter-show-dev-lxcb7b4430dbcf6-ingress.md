filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcb7b4430dbcf6 direct-action not_in_hw id 544 tag f4678304563c5d60 jited 
