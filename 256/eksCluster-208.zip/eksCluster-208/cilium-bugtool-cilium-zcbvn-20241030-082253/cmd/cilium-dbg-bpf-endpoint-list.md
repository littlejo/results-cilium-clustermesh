IP ADDRESS         LOCAL ENDPOINT INFO
172.31.171.115:0   (localhost)                                                                                        
10.208.0.59:0      id=3739  sec_id=6857121 flags=0x0000 ifindex=14  mac=3E:D6:F2:C1:9E:D7 nodemac=36:D4:55:0E:22:0B   
10.208.0.96:0      (localhost)                                                                                        
10.208.0.131:0     id=1346  sec_id=4     flags=0x0000 ifindex=10  mac=62:BE:B3:66:05:59 nodemac=BA:1A:2A:37:E7:81     
172.31.158.79:0    (localhost)                                                                                        
10.208.0.160:0     id=3257  sec_id=6849082 flags=0x0000 ifindex=18  mac=FE:B7:87:8F:C7:59 nodemac=5A:31:91:75:31:1D   
10.208.0.215:0     id=298   sec_id=6857121 flags=0x0000 ifindex=12  mac=B6:C6:D6:90:41:9E nodemac=0A:48:5C:CF:E0:5B   
