filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc0873777bd485 direct-action not_in_hw id 636 tag 585ff7e636588986 jited 
