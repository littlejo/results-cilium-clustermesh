Endpoint ID: 318
Path: /sys/fs/bpf/tc/globals/cilium_policy_00318

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1632086   20616     0        
Allow    Ingress     1          ANY          NONE         disabled    22772     266       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 381
Path: /sys/fs/bpf/tc/globals/cilium_policy_00381

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1124
Path: /sys/fs/bpf/tc/globals/cilium_policy_01124

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    152208   1749      0        
Allow    Egress      0          ANY          NONE         disabled    19606    216       0        


Endpoint ID: 1565
Path: /sys/fs/bpf/tc/globals/cilium_policy_01565

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    151729   1737      0        
Allow    Egress      0          ANY          NONE         disabled    19939    221       0        


Endpoint ID: 2424
Path: /sys/fs/bpf/tc/globals/cilium_policy_02424

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11099162   107946    0        
Allow    Ingress     1          ANY          NONE         disabled    8970663    93744     0        
Allow    Egress      0          ANY          NONE         disabled    10422153   104125    0        


