xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 573
ens6(5) clsact/ingress cil_from_netdev-ens6 id 582
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 571
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 565
cilium_host(7) clsact/egress cil_from_host-cilium_host id 563
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 518
lxc0a1a50707298(12) clsact/ingress cil_from_container-lxc0a1a50707298 id 526
lxc7488f42fa2b8(14) clsact/ingress cil_from_container-lxc7488f42fa2b8 id 548
lxc0873777bd485(18) clsact/ingress cil_from_container-lxc0873777bd485 id 636

flow_dissector:

netfilter:

