35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:29+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:29+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:29+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:29+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:29+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:48:29+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:48:30+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:48:30+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:30+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:30+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:48:30+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:30+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:48:34+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:48:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:48:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:48:45+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
485: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 125
486: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
487: sched_cls  name tail_handle_ipv4  tag 9384700404769b77  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
509: sched_cls  name __send_drop_notify  tag 3003ab2356ccd38d  gpl
	loaded_at 2024-10-30T07:56:47+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 153
510: sched_cls  name tail_handle_arp  tag 8753d9492ed4d701  gpl
	loaded_at 2024-10-30T07:56:47+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 154
512: sched_cls  name tail_ipv4_to_endpoint  tag 87fbbff92c57505e  gpl
	loaded_at 2024-10-30T07:56:47+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 155
514: sched_cls  name tail_handle_ipv4_cont  tag 30be7951f1fb6bcf  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 157
515: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 158
516: sched_cls  name handle_policy  tag 70006eb363aea0eb  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 159
517: sched_cls  name tail_ipv4_ct_ingress  tag 134ebfd166485523  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 160
518: sched_cls  name cil_from_container  tag 5596c599e1010308  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 107,76
	btf_id 161
519: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 162
520: sched_cls  name tail_handle_ipv4  tag 3f1a69809e206246  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 163
521: sched_cls  name tail_ipv4_ct_egress  tag 06473b5f30e47b34  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 165
522: sched_cls  name tail_handle_arp  tag 301389dcc940ad41  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 166
524: sched_cls  name tail_handle_ipv4  tag 3337dd1df52ceddc  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 168
525: sched_cls  name tail_ipv4_ct_ingress  tag 65e6db54ca1073b7  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 169
526: sched_cls  name cil_from_container  tag aca6ae9e38497593  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 110,76
	btf_id 170
527: sched_cls  name tail_ipv4_to_endpoint  tag 4e884ab7effdec96  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,109,41,82,83,80,101,39,110,40,37,38
	btf_id 171
528: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 172
529: sched_cls  name tail_handle_ipv4_cont  tag 83bad221486b9e13  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,109,41,101,82,83,39,76,74,77,110,40,37,38,81
	btf_id 173
530: sched_cls  name __send_drop_notify  tag 7226d17e2335c7a8  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 174
531: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
534: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
535: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
538: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
539: sched_cls  name handle_policy  tag 8d8a1ff1bd5ab0bb  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,110,82,83,109,41,80,101,39,84,75,40,37,38
	btf_id 175
540: sched_cls  name tail_handle_arp  tag dc53eecda61cb9c5  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 177
541: sched_cls  name tail_ipv4_ct_ingress  tag 9058b63f4a2e9b82  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,114,84
	btf_id 178
542: sched_cls  name tail_handle_ipv4_cont  tag 3fb58f75bf1f2cf4  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,114,41,100,82,83,39,76,74,77,113,40,37,38,81
	btf_id 179
543: sched_cls  name tail_ipv4_ct_egress  tag 06473b5f30e47b34  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,114,84
	btf_id 180
544: sched_cls  name handle_policy  tag 3da7a19d8b29426e  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,114,41,80,100,39,84,75,40,37,38
	btf_id 181
545: sched_cls  name tail_ipv4_to_endpoint  tag 315b66e0213491fc  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,114,41,82,83,80,100,39,113,40,37,38
	btf_id 182
546: sched_cls  name tail_handle_ipv4  tag c21ab948a0915f7a  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 183
547: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 184
548: sched_cls  name cil_from_container  tag 5feff3cb437cb156  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 185
550: sched_cls  name __send_drop_notify  tag b4e078b02d2a4ce0  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 187
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
559: sched_cls  name tail_handle_ipv4_from_host  tag d612a862774d9b2a  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 189
560: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 190
562: sched_cls  name __send_drop_notify  tag c60ba9b367a46833  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
563: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,118
	btf_id 193
565: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 195
566: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 197
568: sched_cls  name __send_drop_notify  tag c60ba9b367a46833  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
571: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 202
572: sched_cls  name tail_handle_ipv4_from_host  tag d612a862774d9b2a  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 203
573: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 205
574: sched_cls  name __send_drop_notify  tag c60ba9b367a46833  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
578: sched_cls  name tail_handle_ipv4_from_host  tag d612a862774d9b2a  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 210
579: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 211
580: sched_cls  name tail_handle_ipv4_from_host  tag d612a862774d9b2a  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 213
581: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 214
582: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 215
583: sched_cls  name __send_drop_notify  tag c60ba9b367a46833  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 216
626: sched_cls  name tail_ipv4_to_endpoint  tag 351bbb83b76f006b  gpl
	loaded_at 2024-10-30T08:12:37+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,136,41,82,83,80,135,39,137,40,37,38
	btf_id 233
628: sched_cls  name tail_ipv4_ct_ingress  tag 42da5ac107c02993  gpl
	loaded_at 2024-10-30T08:12:37+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 235
629: sched_cls  name handle_policy  tag 831816bd899be2c7  gpl
	loaded_at 2024-10-30T08:12:37+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,137,82,83,136,41,80,135,39,84,75,40,37,38
	btf_id 236
630: sched_cls  name tail_ipv4_ct_egress  tag 88688463b804b71a  gpl
	loaded_at 2024-10-30T08:12:37+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 237
631: sched_cls  name tail_handle_arp  tag bd6c38c0e1e917cf  gpl
	loaded_at 2024-10-30T08:12:37+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,137
	btf_id 238
632: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:12:37+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,137
	btf_id 239
633: sched_cls  name tail_handle_ipv4_cont  tag 8fed73d189da7e3c  gpl
	loaded_at 2024-10-30T08:12:37+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,136,41,135,82,83,39,76,74,77,137,40,37,38,81
	btf_id 240
634: sched_cls  name __send_drop_notify  tag 974459d87b633cc4  gpl
	loaded_at 2024-10-30T08:12:37+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 241
635: sched_cls  name tail_handle_ipv4  tag 4c14f2484cbf74f7  gpl
	loaded_at 2024-10-30T08:12:37+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,137
	btf_id 242
636: sched_cls  name cil_from_container  tag 585ff7e636588986  gpl
	loaded_at 2024-10-30T08:12:37+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 137,76
	btf_id 243
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
