1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:fd:ad:03:0e:7b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.177.69/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3347sec preferred_lft 3347sec
    inet6 fe80::4fd:adff:fe03:e7b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:e4:af:5f:f3:0d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.159.159/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4e4:afff:fe5f:f30d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:b2:60:32:05:c4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::24b2:60ff:fe32:5c4/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:87:1e:c8:68:c5 brd ff:ff:ff:ff:ff:ff
    inet 10.104.0.194/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::f887:1eff:fec8:68c5/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ee:33:f8:37:80:c0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ec33:f8ff:fe37:80c0/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:89:73:4f:d4:8e brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::7089:73ff:fe4f:d48e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc0a1a50707298@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:03:7a:8f:ae:10 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::6803:7aff:fe8f:ae10/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc7488f42fa2b8@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:42:04:2c:8f:96 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ac42:4ff:fe2c:8f96/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc0873777bd485@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:d5:29:0c:7c:c4 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::40d5:29ff:fe0c:7cc4/64 scope link 
       valid_lft forever preferred_lft forever
