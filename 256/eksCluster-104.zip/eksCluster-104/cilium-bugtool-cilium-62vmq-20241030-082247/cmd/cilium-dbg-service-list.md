ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.249.168:443 (active)   
                                          2 => 172.31.188.75:443 (active)    
2    10.100.69.7:443       ClusterIP      1 => 172.31.177.69:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.104.0.71:53 (active)       
                                          2 => 10.104.0.197:53 (active)      
4    10.100.0.10:9153      ClusterIP      1 => 10.104.0.71:9153 (active)     
                                          2 => 10.104.0.197:9153 (active)    
5    10.100.223.152:2379   ClusterIP      1 => 10.104.0.205:2379 (active)    
