KEY             VALUE
AgentLiveness   2093924219410
UTimeOffset     3379442394531250
