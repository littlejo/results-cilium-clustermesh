{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:43.366Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.159.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:43.366Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.177.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:43.366Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:47.994Z",
  "value": "id=1124  sec_id=3440764 flags=0x0000 ifindex=12  mac=F2:AD:B7:C6:88:09 nodemac=6A:03:7A:8F:AE:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:48.004Z",
  "value": "id=1565  sec_id=3440764 flags=0x0000 ifindex=14  mac=A6:83:CB:E2:5F:B4 nodemac=AE:42:04:2C:8F:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:48.087Z",
  "value": "id=318   sec_id=4     flags=0x0000 ifindex=10  mac=FA:7A:E4:F7:8C:63 nodemac=72:89:73:4F:D4:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:48.145Z",
  "value": "id=1124  sec_id=3440764 flags=0x0000 ifindex=12  mac=F2:AD:B7:C6:88:09 nodemac=6A:03:7A:8F:AE:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:48.235Z",
  "value": "id=1565  sec_id=3440764 flags=0x0000 ifindex=14  mac=A6:83:CB:E2:5F:B4 nodemac=AE:42:04:2C:8F:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:35.099Z",
  "value": "id=318   sec_id=4     flags=0x0000 ifindex=10  mac=FA:7A:E4:F7:8C:63 nodemac=72:89:73:4F:D4:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:35.104Z",
  "value": "id=1565  sec_id=3440764 flags=0x0000 ifindex=14  mac=A6:83:CB:E2:5F:B4 nodemac=AE:42:04:2C:8F:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:35.104Z",
  "value": "id=1124  sec_id=3440764 flags=0x0000 ifindex=12  mac=F2:AD:B7:C6:88:09 nodemac=6A:03:7A:8F:AE:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:35.135Z",
  "value": "id=1164  sec_id=3454557 flags=0x0000 ifindex=16  mac=66:DC:E0:75:71:09 nodemac=E2:0B:8C:D6:85:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:35.136Z",
  "value": "id=1164  sec_id=3454557 flags=0x0000 ifindex=16  mac=66:DC:E0:75:71:09 nodemac=E2:0B:8C:D6:85:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.651Z",
  "value": "id=2424  sec_id=3454557 flags=0x0000 ifindex=18  mac=9A:F7:B5:98:35:27 nodemac=42:D5:29:0C:7C:C4"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.104.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.055Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:03.427Z",
  "value": "id=1124  sec_id=3440764 flags=0x0000 ifindex=12  mac=F2:AD:B7:C6:88:09 nodemac=6A:03:7A:8F:AE:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:03.428Z",
  "value": "id=1565  sec_id=3440764 flags=0x0000 ifindex=14  mac=A6:83:CB:E2:5F:B4 nodemac=AE:42:04:2C:8F:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:03.428Z",
  "value": "id=318   sec_id=4     flags=0x0000 ifindex=10  mac=FA:7A:E4:F7:8C:63 nodemac=72:89:73:4F:D4:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:03.429Z",
  "value": "id=2424  sec_id=3454557 flags=0x0000 ifindex=18  mac=9A:F7:B5:98:35:27 nodemac=42:D5:29:0C:7C:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:04.428Z",
  "value": "id=2424  sec_id=3454557 flags=0x0000 ifindex=18  mac=9A:F7:B5:98:35:27 nodemac=42:D5:29:0C:7C:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:04.429Z",
  "value": "id=1124  sec_id=3440764 flags=0x0000 ifindex=12  mac=F2:AD:B7:C6:88:09 nodemac=6A:03:7A:8F:AE:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:04.430Z",
  "value": "id=1565  sec_id=3440764 flags=0x0000 ifindex=14  mac=A6:83:CB:E2:5F:B4 nodemac=AE:42:04:2C:8F:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:04.430Z",
  "value": "id=318   sec_id=4     flags=0x0000 ifindex=10  mac=FA:7A:E4:F7:8C:63 nodemac=72:89:73:4F:D4:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:05.428Z",
  "value": "id=2424  sec_id=3454557 flags=0x0000 ifindex=18  mac=9A:F7:B5:98:35:27 nodemac=42:D5:29:0C:7C:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:05.428Z",
  "value": "id=1124  sec_id=3440764 flags=0x0000 ifindex=12  mac=F2:AD:B7:C6:88:09 nodemac=6A:03:7A:8F:AE:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:05.428Z",
  "value": "id=1565  sec_id=3440764 flags=0x0000 ifindex=14  mac=A6:83:CB:E2:5F:B4 nodemac=AE:42:04:2C:8F:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:05.429Z",
  "value": "id=318   sec_id=4     flags=0x0000 ifindex=10  mac=FA:7A:E4:F7:8C:63 nodemac=72:89:73:4F:D4:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:06.428Z",
  "value": "id=318   sec_id=4     flags=0x0000 ifindex=10  mac=FA:7A:E4:F7:8C:63 nodemac=72:89:73:4F:D4:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:06.428Z",
  "value": "id=1124  sec_id=3440764 flags=0x0000 ifindex=12  mac=F2:AD:B7:C6:88:09 nodemac=6A:03:7A:8F:AE:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:06.428Z",
  "value": "id=2424  sec_id=3454557 flags=0x0000 ifindex=18  mac=9A:F7:B5:98:35:27 nodemac=42:D5:29:0C:7C:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:06.429Z",
  "value": "id=1565  sec_id=3440764 flags=0x0000 ifindex=14  mac=A6:83:CB:E2:5F:B4 nodemac=AE:42:04:2C:8F:96"
}

