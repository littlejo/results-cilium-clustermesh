Total: 693
TCP:   1866 (estab 436, closed 1411, orphaned 0, timewait 563)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  455       444       11       
INET	  465       450       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                  Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.177.69%ens5:68         0.0.0.0:*    uid:192 ino:69871 sk:3f0 cgroup:unreachable:c4e <->                            
UNCONN 0      0                             0.0.0.0:8472       0.0.0.0:*    ino:34158 sk:3f1 cgroup:/ <->                                                  
UNCONN 0      0                           127.0.0.1:323        0.0.0.0:*    ino:15556 sk:3f2 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                           127.0.0.1:41323      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:33945 sk:3f3 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                [::]:8472          [::]:*    ino:34157 sk:3f4 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                               [::1]:323           [::]:*    ino:15557 sk:3f5 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::4fd:adff:fe03:e7b]%ens5:546           [::]:*    uid:192 ino:15263 sk:3f6 cgroup:unreachable:c4e v6only:1 <->                   
