key: 3e 01 00 00  value: 04 02 00 00
key: 64 04 00 00  value: 1b 02 00 00
key: 1d 06 00 00  value: 20 02 00 00
key: 78 09 00 00  value: 75 02 00 00
Found 4 elements
