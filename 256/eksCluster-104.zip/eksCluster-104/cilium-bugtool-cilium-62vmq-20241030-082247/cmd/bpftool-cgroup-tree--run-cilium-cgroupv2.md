CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2cc36962_224d_4614_80fc_130d412d45e7.slice/cri-containerd-79afe4c9b03117e95008303a01e3d32556eb0de13969c09a9c9ce17e16da7d53.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2cc36962_224d_4614_80fc_130d412d45e7.slice/cri-containerd-816c5571ecbdb2372b3bad7938be1709fa4b425174986575a484d06514ecb473.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod896e9dce_cf9d_48a9_9a76_2518c535ea2e.slice/cri-containerd-093b754894ced8dfcee8168f656db344fac8e3df8b2e14cca081956450457c26.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod896e9dce_cf9d_48a9_9a76_2518c535ea2e.slice/cri-containerd-517fa48e7cb2a42cc827dc82f32d6be0962476f044529cd2a2f772dc70e26c76.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7fad9950_f6f0_45d5_bc7e_d290fd0216b2.slice/cri-containerd-7fd888f9ec927ea847f15dd466fa5ff1368712ef5d1ca77f1fbf1e012e646b67.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7fad9950_f6f0_45d5_bc7e_d290fd0216b2.slice/cri-containerd-d5257460a735947e4eedce24e65ae9f6cb6787090b41953e578a3cfc8e7856b5.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod28dc6dde_2464_4deb_a28f_d1f5b9da5af6.slice/cri-containerd-9c4a5916af5ab837ab3ac5be1010a17357421ccbad2b090fb75607e8fd012370.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod28dc6dde_2464_4deb_a28f_d1f5b9da5af6.slice/cri-containerd-9bc6ab647d033ab0f3e48021d8dd202dde9fb16833fc70baa7858c82657f9208.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3d04254_4781_4e6e_8290_d403c36e0c19.slice/cri-containerd-b2246f21fc7f53ac6eb705f6df41a116a70d5640ee2fb53f393c3e0f2609ebb4.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3d04254_4781_4e6e_8290_d403c36e0c19.slice/cri-containerd-8b468bda193a6c3f09153323151226fcb4e387ef9b907dd96d4d82cb99593bde.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3d04254_4781_4e6e_8290_d403c36e0c19.slice/cri-containerd-d99f216dd098ccd542609b97e3279afb3c339a07928050e7a3317a2440ded659.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3d04254_4781_4e6e_8290_d403c36e0c19.slice/cri-containerd-0b805a36874e2e3a3a7b94de0af7bb4726e77db3658587ed65b96b93e870dc0a.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode8837b09_8510_46a5_ae4e_82bb5583a185.slice/cri-containerd-f51b8174de0b5937e1cfc941d424a5a924715fb072ec35f483d10aa7537fb48b.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode8837b09_8510_46a5_ae4e_82bb5583a185.slice/cri-containerd-4b382776dd0881d684b349c612795923ee8749987a8837ce562146d3e5dc47ae.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb6c11444_8a6c_43e7_982b_a72ace59ae94.slice/cri-containerd-8a4f5fd85fc8c37a63e62d4786e7243f92dda631e8f41b3a67e774e400f4a1a4.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb6c11444_8a6c_43e7_982b_a72ace59ae94.slice/cri-containerd-6b48aba195416095a0def956277cc8fd483f59d38734f821279135724c3a2ebc.scope
    97       cgroup_device   multi                                          
