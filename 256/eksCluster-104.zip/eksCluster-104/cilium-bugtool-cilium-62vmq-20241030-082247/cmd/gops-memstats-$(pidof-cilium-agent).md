alloc: 132.66MB (139106784 bytes)
total-alloc: 2.17GB (2332168600 bytes)
sys: 324.83MB (340611428 bytes)
lookups: 0
mallocs: 62031562
frees: 60730995
heap-alloc: 132.66MB (139106784 bytes)
heap-sys: 247.57MB (259596288 bytes)
heap-idle: 83.93MB (88006656 bytes)
heap-in-use: 163.64MB (171589632 bytes)
heap-released: 5.75MB (6029312 bytes)
heap-objects: 1300567
stack-in-use: 64.41MB (67534848 bytes)
stack-sys: 64.41MB (67534848 bytes)
stack-mspan-inuse: 2.76MB (2894720 bytes)
stack-mspan-sys: 3.75MB (3933120 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.09MB (1144017 bytes)
gc-sys: 6.04MB (6333856 bytes)
next-gc: when heap-alloc >= 214.17MB (224578312 bytes)
last-gc: 2024-10-30 08:22:59.626106346 +0000 UTC
gc-pause-total: 17.049052ms
gc-pause: 143149
gc-pause-end: 1730276579626106346
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.0004064897900057015
enable-gc: true
debug-gc: false
