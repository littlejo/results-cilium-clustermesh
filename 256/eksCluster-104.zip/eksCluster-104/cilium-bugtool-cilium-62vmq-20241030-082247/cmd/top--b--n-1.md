top - 08:22:48 up 34 min,  0 users,  load average: 0.13, 0.16, 0.13
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 60.0 us, 26.7 sy,  0.0 ni, 13.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4486.7 free,   1182.0 used,   2145.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6447.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606144 381540  78620 S  93.3   4.8   0:46.40 cilium-+
    410 root      20   0 1229488   8080   3900 S   0.0   0.1   0:01.19 cilium-+
    667 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    673 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    674 root      20   0 1240432  16344  11356 S   0.0   0.2   0:00.03 cilium-+
    720 root      20   0    2208    788    708 S   0.0   0.0   0:00.00 timeout
    738 root      20   0 1243764  17936  12996 S   0.0   0.2   0:00.01 hubble
    745 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    771 root      20   0 1229000   4016   3356 S   0.0   0.1   0:00.00 gops
