IP ADDRESS         LOCAL ENDPOINT INFO
172.31.159.159:0   (localhost)                                                                                        
10.104.0.194:0     (localhost)                                                                                        
172.31.177.69:0    (localhost)                                                                                        
10.104.0.197:0     id=1565  sec_id=3440764 flags=0x0000 ifindex=14  mac=A6:83:CB:E2:5F:B4 nodemac=AE:42:04:2C:8F:96   
10.104.0.71:0      id=1124  sec_id=3440764 flags=0x0000 ifindex=12  mac=F2:AD:B7:C6:88:09 nodemac=6A:03:7A:8F:AE:10   
10.104.0.205:0     id=2424  sec_id=3454557 flags=0x0000 ifindex=18  mac=9A:F7:B5:98:35:27 nodemac=42:D5:29:0C:7C:C4   
10.104.0.83:0      id=318   sec_id=4     flags=0x0000 ifindex=10  mac=FA:7A:E4:F7:8C:63 nodemac=72:89:73:4F:D4:8E     
