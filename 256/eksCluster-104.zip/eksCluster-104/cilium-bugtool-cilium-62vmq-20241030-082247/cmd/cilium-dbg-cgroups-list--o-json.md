[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7fad9950_f6f0_45d5_bc7e_d290fd0216b2.slice/cri-containerd-7fd888f9ec927ea847f15dd466fa5ff1368712ef5d1ca77f1fbf1e012e646b67.scope"
      }
    ],
    "ips": [
      "10.104.0.71"
    ],
    "name": "coredns-cc6ccd49c-w79dp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3d04254_4781_4e6e_8290_d403c36e0c19.slice/cri-containerd-d99f216dd098ccd542609b97e3279afb3c339a07928050e7a3317a2440ded659.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3d04254_4781_4e6e_8290_d403c36e0c19.slice/cri-containerd-b2246f21fc7f53ac6eb705f6df41a116a70d5640ee2fb53f393c3e0f2609ebb4.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3d04254_4781_4e6e_8290_d403c36e0c19.slice/cri-containerd-0b805a36874e2e3a3a7b94de0af7bb4726e77db3658587ed65b96b93e870dc0a.scope"
      }
    ],
    "ips": [
      "10.104.0.205"
    ],
    "name": "clustermesh-apiserver-9546ddd7d-kvxcm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod28dc6dde_2464_4deb_a28f_d1f5b9da5af6.slice/cri-containerd-9c4a5916af5ab837ab3ac5be1010a17357421ccbad2b090fb75607e8fd012370.scope"
      }
    ],
    "ips": [
      "10.104.0.197"
    ],
    "name": "coredns-cc6ccd49c-fs7vf",
    "namespace": "kube-system"
  }
]

