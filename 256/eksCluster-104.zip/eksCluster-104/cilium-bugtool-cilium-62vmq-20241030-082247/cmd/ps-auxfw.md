USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         674  0.0  0.1 1240432 15528 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         715  0.0  0.1 1240432 15528 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         716  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         673  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         667  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  2.9  4.6 1606144 375144 ?      Ssl  07:56   0:46 cilium-agent --config-dir=/tmp/cilium/config-map
root         410  0.0  0.1 1229488 8080 ?        Sl   07:56   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
