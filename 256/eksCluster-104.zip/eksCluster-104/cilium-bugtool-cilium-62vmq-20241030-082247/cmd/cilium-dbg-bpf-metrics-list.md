REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     33867     2675883     677    bpf_overlay.c
Interface                 INGRESS     610288    127803075   1132   bpf_host.c
Success                   EGRESS      13938     1090713     1694   bpf_host.c
Success                   EGRESS      254776    32562345    1308   bpf_lxc.c
Success                   EGRESS      32709     2592022     53     encap.h
Success                   INGRESS     296600    33145326    86     l3.h
Success                   INGRESS     317180    34774542    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
