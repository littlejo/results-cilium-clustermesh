key: 79 00 00 00  value: 75 02 00 00
key: e4 01 00 00  value: 01 02 00 00
key: 26 05 00 00  value: 1e 02 00 00
key: e4 06 00 00  value: 0c 02 00 00
Found 4 elements
