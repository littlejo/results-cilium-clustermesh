filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc66f224108fde direct-action not_in_hw id 531 tag e32843d8bccd5460 jited 
