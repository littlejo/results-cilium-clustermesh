USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         636  0.0  0.2 1240432 16036 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         651  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         653  0.0  0.0      0     0 ?        R    08:22   0:00  \_ [hostname]
root         626  0.0  0.0 1228744 3716 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         602  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.5  4.9 1606336 394808 ?      Ssl  08:01   0:46 cilium-agent --config-dir=/tmp/cilium/config-map
root         404  0.0  0.0 1229744 7976 ?        Sl   08:01   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
