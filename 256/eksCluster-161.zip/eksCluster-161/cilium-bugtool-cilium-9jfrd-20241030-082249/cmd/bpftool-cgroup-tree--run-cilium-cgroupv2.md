CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04ba5ac4_fdae_4bb5_88c1_5c5c57d570ca.slice/cri-containerd-319c8dbad0af9162ef60eaf98eeddb46d4fea024b60588d55cc1343824e2b9ce.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04ba5ac4_fdae_4bb5_88c1_5c5c57d570ca.slice/cri-containerd-52eb353c41635cc58d464708ceb0dfb74c1b6ba1f1d72513818ded0114cc7903.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod970c49f2_2768_4b2a_b3a2_e2978fe2c54d.slice/cri-containerd-baf8839db3acc95b18a150c66ff6c29b5610c0630501fd056bf115010cded36d.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod970c49f2_2768_4b2a_b3a2_e2978fe2c54d.slice/cri-containerd-84abba21e9e6c6b6529f6a343255c7b603095119b7687ae55aaf03c0d61fc5ef.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4906cb51_4d7a_4949_b359_997523f67f2d.slice/cri-containerd-8a03cd9ffa14460496611c9cb98eb2d2838e2dfdeebccaad3100edc7de94b111.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4906cb51_4d7a_4949_b359_997523f67f2d.slice/cri-containerd-dd2bf9406039771606d68b03a526371d2945f7e59bd4e8ae833e52338f407ebb.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb250f60b_3b05_4f09_b4f4_f5a1d7d61cdd.slice/cri-containerd-8097ba216ce68a70b65a21703fd51e8973a8c8268bc5841f5cca7cda79c29505.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb250f60b_3b05_4f09_b4f4_f5a1d7d61cdd.slice/cri-containerd-e88b9953cbeb71635769d870cd3c428c43b33d1878c2dad9dda1d04789cd5976.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95e34608_052b_4d8e_824c_ba9666806922.slice/cri-containerd-9deec1a09109841f98e0e77def5519af5329007127e518d48e1a87aa93145b5b.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95e34608_052b_4d8e_824c_ba9666806922.slice/cri-containerd-b621b3aa0075ac42f8935adfb3f41a0f6517231b74b7d72ccdcc8175bfa2a593.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95e34608_052b_4d8e_824c_ba9666806922.slice/cri-containerd-e3ab4e40921d4cb1c42dce76e905134741df2cb1835b768934c1214629de1c04.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95e34608_052b_4d8e_824c_ba9666806922.slice/cri-containerd-30e3c38d1275b33207607efafff06520dfbbf3f49c1f0f4edb53257e56bb26d0.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d71d1d8_2f76_4ed3_b044_919db8584f58.slice/cri-containerd-1075ade7b4427f49f1ed239eeb7981396d279efa359defd1b34a52b19097208a.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d71d1d8_2f76_4ed3_b044_919db8584f58.slice/cri-containerd-f0b7d556a339f59795cb863cd177ac9640f74d99160f7221486ec2b9f1148999.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8d921b7e_d676_4a46_a0ef_f1a761e37262.slice/cri-containerd-128fcfeb1c9ab0e1929695ab96626aa56e6b9e2ccbed84f60ad5a54d4757a982.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8d921b7e_d676_4a46_a0ef_f1a761e37262.slice/cri-containerd-e4d24ae8eed48987aae3ad5f97c42086142d4c237885eeccf363dac8c0c4cc7e.scope
    97       cgroup_device   multi                                          
