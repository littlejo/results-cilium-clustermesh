ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.176.255:443 (active)   
                                         2 => 172.31.194.38:443 (active)    
2    10.100.68.245:443    ClusterIP      1 => 172.31.233.29:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.161.0.137:53 (active)      
                                         2 => 10.161.0.170:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.161.0.137:9153 (active)    
                                         2 => 10.161.0.170:9153 (active)    
5    10.100.57.168:2379   ClusterIP      1 => 10.161.0.81:2379 (active)     
