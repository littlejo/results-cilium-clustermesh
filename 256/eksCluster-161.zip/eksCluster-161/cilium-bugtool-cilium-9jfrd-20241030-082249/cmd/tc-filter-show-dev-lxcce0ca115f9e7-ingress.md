filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcce0ca115f9e7 direct-action not_in_hw id 514 tag 70e385b95c8c693e jited 
