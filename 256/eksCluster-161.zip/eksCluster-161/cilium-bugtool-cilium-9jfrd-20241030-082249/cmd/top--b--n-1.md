top - 08:22:50 up 31 min,  0 users,  load average: 0.09, 0.18, 0.17
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 17.2 us, 41.4 sy,  0.0 ni, 41.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4468.0 free,   1198.8 used,   2147.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6430.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    636 root      20   0 1240432  16036  11292 S  13.3   0.2   0:00.03 cilium-+
      1 root      20   0 1606336 394808  77564 S   0.0   4.9   0:46.04 cilium-+
    404 root      20   0 1229744   7976   3836 S   0.0   0.1   0:01.09 cilium-+
    602 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    626 root      20   0 1228744   3716   3040 S   0.0   0.0   0:00.00 gops
    663 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    689 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    712 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
