REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35693     2819451     677    bpf_overlay.c
Interface                 INGRESS     656616    133394654   1132   bpf_host.c
Success                   EGRESS      15617     1223901     1694   bpf_host.c
Success                   EGRESS      290271    36528885    1308   bpf_lxc.c
Success                   EGRESS      35496     2804078     53     encap.h
Success                   INGRESS     332374    37668370    86     l3.h
Success                   INGRESS     353101    39307966    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
