{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:26.160Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.226.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:26.160Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.233.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:26.160Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:30.622Z",
  "value": "id=1764  sec_id=5326649 flags=0x0000 ifindex=12  mac=2A:A3:3C:7C:A6:D2 nodemac=2A:B7:B8:9E:85:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:30.627Z",
  "value": "id=1318  sec_id=4     flags=0x0000 ifindex=10  mac=7E:B9:09:F1:CA:8E nodemac=22:79:2F:6A:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:30.674Z",
  "value": "id=484   sec_id=5326649 flags=0x0000 ifindex=14  mac=06:99:96:54:36:92 nodemac=22:BA:54:43:DB:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:30.727Z",
  "value": "id=1764  sec_id=5326649 flags=0x0000 ifindex=12  mac=2A:A3:3C:7C:A6:D2 nodemac=2A:B7:B8:9E:85:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:30.823Z",
  "value": "id=1318  sec_id=4     flags=0x0000 ifindex=10  mac=7E:B9:09:F1:CA:8E nodemac=22:79:2F:6A:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:09.259Z",
  "value": "id=1318  sec_id=4     flags=0x0000 ifindex=10  mac=7E:B9:09:F1:CA:8E nodemac=22:79:2F:6A:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:09.259Z",
  "value": "id=1764  sec_id=5326649 flags=0x0000 ifindex=12  mac=2A:A3:3C:7C:A6:D2 nodemac=2A:B7:B8:9E:85:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:09.259Z",
  "value": "id=484   sec_id=5326649 flags=0x0000 ifindex=14  mac=06:99:96:54:36:92 nodemac=22:BA:54:43:DB:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:09.288Z",
  "value": "id=3898  sec_id=5324870 flags=0x0000 ifindex=16  mac=DE:64:28:36:B0:B8 nodemac=9A:F4:75:7A:36:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.258Z",
  "value": "id=484   sec_id=5326649 flags=0x0000 ifindex=14  mac=06:99:96:54:36:92 nodemac=22:BA:54:43:DB:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.259Z",
  "value": "id=3898  sec_id=5324870 flags=0x0000 ifindex=16  mac=DE:64:28:36:B0:B8 nodemac=9A:F4:75:7A:36:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.259Z",
  "value": "id=1318  sec_id=4     flags=0x0000 ifindex=10  mac=7E:B9:09:F1:CA:8E nodemac=22:79:2F:6A:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.259Z",
  "value": "id=1764  sec_id=5326649 flags=0x0000 ifindex=12  mac=2A:A3:3C:7C:A6:D2 nodemac=2A:B7:B8:9E:85:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.729Z",
  "value": "id=121   sec_id=5324870 flags=0x0000 ifindex=18  mac=F6:91:4B:8B:19:CC nodemac=06:2B:B2:EA:89:86"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.161.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:26.435Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.374Z",
  "value": "id=484   sec_id=5326649 flags=0x0000 ifindex=14  mac=06:99:96:54:36:92 nodemac=22:BA:54:43:DB:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.374Z",
  "value": "id=121   sec_id=5324870 flags=0x0000 ifindex=18  mac=F6:91:4B:8B:19:CC nodemac=06:2B:B2:EA:89:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.375Z",
  "value": "id=1318  sec_id=4     flags=0x0000 ifindex=10  mac=7E:B9:09:F1:CA:8E nodemac=22:79:2F:6A:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.375Z",
  "value": "id=1764  sec_id=5326649 flags=0x0000 ifindex=12  mac=2A:A3:3C:7C:A6:D2 nodemac=2A:B7:B8:9E:85:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.375Z",
  "value": "id=121   sec_id=5324870 flags=0x0000 ifindex=18  mac=F6:91:4B:8B:19:CC nodemac=06:2B:B2:EA:89:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.375Z",
  "value": "id=1318  sec_id=4     flags=0x0000 ifindex=10  mac=7E:B9:09:F1:CA:8E nodemac=22:79:2F:6A:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.375Z",
  "value": "id=1764  sec_id=5326649 flags=0x0000 ifindex=12  mac=2A:A3:3C:7C:A6:D2 nodemac=2A:B7:B8:9E:85:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.376Z",
  "value": "id=484   sec_id=5326649 flags=0x0000 ifindex=14  mac=06:99:96:54:36:92 nodemac=22:BA:54:43:DB:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.375Z",
  "value": "id=1318  sec_id=4     flags=0x0000 ifindex=10  mac=7E:B9:09:F1:CA:8E nodemac=22:79:2F:6A:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.375Z",
  "value": "id=121   sec_id=5324870 flags=0x0000 ifindex=18  mac=F6:91:4B:8B:19:CC nodemac=06:2B:B2:EA:89:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.375Z",
  "value": "id=1764  sec_id=5326649 flags=0x0000 ifindex=12  mac=2A:A3:3C:7C:A6:D2 nodemac=2A:B7:B8:9E:85:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.375Z",
  "value": "id=484   sec_id=5326649 flags=0x0000 ifindex=14  mac=06:99:96:54:36:92 nodemac=22:BA:54:43:DB:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.375Z",
  "value": "id=1318  sec_id=4     flags=0x0000 ifindex=10  mac=7E:B9:09:F1:CA:8E nodemac=22:79:2F:6A:C8:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.375Z",
  "value": "id=484   sec_id=5326649 flags=0x0000 ifindex=14  mac=06:99:96:54:36:92 nodemac=22:BA:54:43:DB:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.376Z",
  "value": "id=121   sec_id=5324870 flags=0x0000 ifindex=18  mac=F6:91:4B:8B:19:CC nodemac=06:2B:B2:EA:89:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.161.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.376Z",
  "value": "id=1764  sec_id=5326649 flags=0x0000 ifindex=12  mac=2A:A3:3C:7C:A6:D2 nodemac=2A:B7:B8:9E:85:26"
}

