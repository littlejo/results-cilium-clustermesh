alloc: 202.46MB (212298176 bytes)
total-alloc: 2.37GB (2550040176 bytes)
sys: 317.02MB (332419428 bytes)
lookups: 0
mallocs: 65268445
frees: 62856912
heap-alloc: 202.46MB (212298176 bytes)
heap-sys: 235.80MB (247250944 bytes)
heap-idle: 9.80MB (10280960 bytes)
heap-in-use: 225.99MB (236969984 bytes)
heap-released: 752.00KB (770048 bytes)
heap-objects: 2411533
stack-in-use: 68.16MB (71467008 bytes)
stack-sys: 68.16MB (71467008 bytes)
stack-mspan-inuse: 3.79MB (3976960 bytes)
stack-mspan-sys: 3.94MB (4128960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.08MB (1132177 bytes)
gc-sys: 6.03MB (6327856 bytes)
next-gc: when heap-alloc >= 211.15MB (221403272 bytes)
last-gc: 2024-10-30 08:22:32.945076225 +0000 UTC
gc-pause-total: 14.662281ms
gc-pause: 92849
gc-pause-end: 1730276552945076225
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0005308782366458811
enable-gc: true
debug-gc: false
