Endpoint ID: 121
Path: /sys/fs/bpf/tc/globals/cilium_policy_00121

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11620618   115560    0        
Allow    Ingress     1          ANY          NONE         disabled    10955015   111867    0        
Allow    Egress      0          ANY          NONE         disabled    12517385   123384    0        


Endpoint ID: 484
Path: /sys/fs/bpf/tc/globals/cilium_policy_00484

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    125161   1435      0        
Allow    Egress      0          ANY          NONE         disabled    17832    194       0        


Endpoint ID: 898
Path: /sys/fs/bpf/tc/globals/cilium_policy_00898

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1318
Path: /sys/fs/bpf/tc/globals/cilium_policy_01318

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1643274   20775     0        
Allow    Ingress     1          ANY          NONE         disabled    19456     230       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1764
Path: /sys/fs/bpf/tc/globals/cilium_policy_01764

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    125161   1435      0        
Allow    Egress      0          ANY          NONE         disabled    16777    181       0        


