KEY             VALUE
AgentLiveness   1946720729606
UTimeOffset     3379442685546875
