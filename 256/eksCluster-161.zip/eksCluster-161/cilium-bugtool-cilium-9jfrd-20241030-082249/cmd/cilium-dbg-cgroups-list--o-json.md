[
  {
    "containers": [
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95e34608_052b_4d8e_824c_ba9666806922.slice/cri-containerd-9deec1a09109841f98e0e77def5519af5329007127e518d48e1a87aa93145b5b.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95e34608_052b_4d8e_824c_ba9666806922.slice/cri-containerd-b621b3aa0075ac42f8935adfb3f41a0f6517231b74b7d72ccdcc8175bfa2a593.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95e34608_052b_4d8e_824c_ba9666806922.slice/cri-containerd-e3ab4e40921d4cb1c42dce76e905134741df2cb1835b768934c1214629de1c04.scope"
      }
    ],
    "ips": [
      "10.161.0.81"
    ],
    "name": "clustermesh-apiserver-68498cc74d-fshzb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4906cb51_4d7a_4949_b359_997523f67f2d.slice/cri-containerd-dd2bf9406039771606d68b03a526371d2945f7e59bd4e8ae833e52338f407ebb.scope"
      }
    ],
    "ips": [
      "10.161.0.137"
    ],
    "name": "coredns-cc6ccd49c-shz8b",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb250f60b_3b05_4f09_b4f4_f5a1d7d61cdd.slice/cri-containerd-8097ba216ce68a70b65a21703fd51e8973a8c8268bc5841f5cca7cda79c29505.scope"
      }
    ],
    "ips": [
      "10.161.0.170"
    ],
    "name": "coredns-cc6ccd49c-99xrx",
    "namespace": "kube-system"
  }
]

