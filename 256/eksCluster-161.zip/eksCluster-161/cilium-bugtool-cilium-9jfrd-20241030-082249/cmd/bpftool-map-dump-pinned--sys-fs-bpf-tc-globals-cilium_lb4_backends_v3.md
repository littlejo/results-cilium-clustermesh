key: 04 00 00 00  value: 0a a1 00 89 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f b0 ff 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a a1 00 51 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a a1 00 aa 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f c2 26 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: 0a a1 00 89 23 c1 00 00  00 00 00 00
key: 03 00 00 00  value: ac 1f e9 1d 10 94 00 00  00 00 00 00
key: 07 00 00 00  value: 0a a1 00 aa 23 c1 00 00  00 00 00 00
Found 8 elements
