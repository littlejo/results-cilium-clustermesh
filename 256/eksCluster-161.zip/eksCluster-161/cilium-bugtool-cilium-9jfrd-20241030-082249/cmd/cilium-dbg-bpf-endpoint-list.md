IP ADDRESS         LOCAL ENDPOINT INFO
10.161.0.137:0     id=1764  sec_id=5326649 flags=0x0000 ifindex=12  mac=2A:A3:3C:7C:A6:D2 nodemac=2A:B7:B8:9E:85:26   
10.161.0.81:0      id=121   sec_id=5324870 flags=0x0000 ifindex=18  mac=F6:91:4B:8B:19:CC nodemac=06:2B:B2:EA:89:86   
172.31.233.29:0    (localhost)                                                                                        
172.31.226.175:0   (localhost)                                                                                        
10.161.0.125:0     (localhost)                                                                                        
10.161.0.56:0      id=1318  sec_id=4     flags=0x0000 ifindex=10  mac=7E:B9:09:F1:CA:8E nodemac=22:79:2F:6A:C8:B9     
10.161.0.170:0     id=484   sec_id=5326649 flags=0x0000 ifindex=14  mac=06:99:96:54:36:92 nodemac=22:BA:54:43:DB:18   
