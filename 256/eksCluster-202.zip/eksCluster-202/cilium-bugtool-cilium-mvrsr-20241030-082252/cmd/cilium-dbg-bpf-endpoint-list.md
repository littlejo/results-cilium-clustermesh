IP ADDRESS        LOCAL ENDPOINT INFO
10.202.0.241:0    (localhost)                                                                                        
10.202.0.94:0     id=3833  sec_id=6652165 flags=0x0000 ifindex=14  mac=C2:22:6C:A0:EA:1B nodemac=1E:A6:2F:0C:64:A2   
10.202.0.27:0     id=1408  sec_id=6683838 flags=0x0000 ifindex=18  mac=0E:C4:02:5E:50:CA nodemac=2A:F0:89:B4:FB:32   
172.31.153.30:0   (localhost)                                                                                        
172.31.143.84:0   (localhost)                                                                                        
10.202.0.217:0    id=2771  sec_id=6652165 flags=0x0000 ifindex=12  mac=F6:1B:67:06:D7:51 nodemac=3A:3E:15:84:71:37   
10.202.0.160:0    id=1798  sec_id=4     flags=0x0000 ifindex=10  mac=B2:D4:30:30:57:5C nodemac=AE:E6:A9:78:09:7E     
