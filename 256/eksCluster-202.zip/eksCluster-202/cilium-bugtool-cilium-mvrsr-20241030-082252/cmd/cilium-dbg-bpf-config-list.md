KEY             VALUE
AgentLiveness   1786364714850
UTimeOffset     3379443005859375
