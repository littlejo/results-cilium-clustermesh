xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 506
ens6(5) clsact/ingress cil_from_netdev-ens6 id 512
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 497
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 494
cilium_host(7) clsact/egress cil_from_host-cilium_host id 492
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 545
lxcf3125b653fa5(12) clsact/ingress cil_from_container-lxcf3125b653fa5 id 529
lxce3dc582da4eb(14) clsact/ingress cil_from_container-lxce3dc582da4eb id 556
lxceb2b12b7b4a2(18) clsact/ingress cil_from_container-lxceb2b12b7b4a2 id 618

flow_dissector:

netfilter:

