markdown output at /tmp/cilium-bugtool-20241030-082254.196+0000-UTC-233692122/cmd/cilium-debuginfo-20241030-082325.231+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082254.196+0000-UTC-233692122/cmd/cilium-debuginfo-20241030-082325.231+0000-UTC.json
