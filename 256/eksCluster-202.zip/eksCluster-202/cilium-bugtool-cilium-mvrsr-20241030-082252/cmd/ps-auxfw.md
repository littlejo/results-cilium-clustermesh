USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         685  0.0  0.0   2208   796 ?        Ss   08:22   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         692  0.0  0.1 1242676 15956 ?       Rl   08:22   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root         659  0.0  0.0 1228744 4044 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         655  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         649  0.0  0.0 1228744 4044 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         643  0.0  0.1 1240432 15672 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         698  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         700  0.0  0.1 1240432 15672 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  4.3  4.9 1606080 392840 ?      Ssl  08:03   0:51 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.0 1229744 7740 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
