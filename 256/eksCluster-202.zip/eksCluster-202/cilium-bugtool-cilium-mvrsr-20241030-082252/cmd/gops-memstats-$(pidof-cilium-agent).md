alloc: 147.78MB (154953480 bytes)
total-alloc: 2.33GB (2504676336 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 64982173
frees: 63555895
heap-alloc: 147.78MB (154953480 bytes)
heap-sys: 243.11MB (254918656 bytes)
heap-idle: 58.80MB (61652992 bytes)
heap-in-use: 184.31MB (193265664 bytes)
heap-released: 424.00KB (434176 bytes)
heap-objects: 1426278
stack-in-use: 64.84MB (67993600 bytes)
stack-sys: 64.84MB (67993600 bytes)
stack-mspan-inuse: 3.10MB (3255360 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1057425 bytes)
gc-sys: 6.00MB (6292848 bytes)
next-gc: when heap-alloc >= 216.23MB (226735048 bytes)
last-gc: 2024-10-30 08:23:05.121002472 +0000 UTC
gc-pause-total: 14.520654ms
gc-pause: 80469
gc-pause-end: 1730276585121002472
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005140818388055734
enable-gc: true
debug-gc: false
