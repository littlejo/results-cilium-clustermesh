REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38102     3019445     677    bpf_overlay.c
Interface                 INGRESS     670223    136033710   1132   bpf_host.c
Success                   EGRESS      17767     1402487     1694   bpf_host.c
Success                   EGRESS      288738    35492128    1308   bpf_lxc.c
Success                   EGRESS      39021     3085651     53     encap.h
Success                   INGRESS     330926    37712728    86     l3.h
Success                   INGRESS     351912    39373732    235    trace.h
Unsupported L3 protocol   EGRESS      42        3152        1492   bpf_lxc.c
