35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:53:42+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:53:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:53:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:53:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:53:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:53:42+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:53:43+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:53:43+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:53:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:53:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:53:43+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:53:43+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:53:47+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:53:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name tail_handle_ipv4  tag ceec10a48100c14a  gpl
	loaded_at 2024-10-30T08:03:20+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
485: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:03:20+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
486: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:03:20+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 126
487: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:03:20+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
488: sched_cls  name __send_drop_notify  tag 42b6ab93580f73be  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 129
489: sched_cls  name tail_handle_ipv4_from_host  tag 37c10ea2f985d59b  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,102
	btf_id 130
490: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,102
	btf_id 131
492: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,102
	btf_id 133
494: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 135
497: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 139
498: sched_cls  name __send_drop_notify  tag 42b6ab93580f73be  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 140
499: sched_cls  name tail_handle_ipv4_from_host  tag 37c10ea2f985d59b  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,103
	btf_id 141
500: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,103
	btf_id 142
503: sched_cls  name __send_drop_notify  tag 42b6ab93580f73be  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 146
504: sched_cls  name tail_handle_ipv4_from_host  tag 37c10ea2f985d59b  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,106
	btf_id 147
505: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,106
	btf_id 148
506: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,106,75
	btf_id 149
509: sched_cls  name __send_drop_notify  tag 42b6ab93580f73be  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 153
510: sched_cls  name tail_handle_ipv4_from_host  tag 37c10ea2f985d59b  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,108
	btf_id 154
511: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,108
	btf_id 155
512: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:03:22+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,108,75
	btf_id 156
518: sched_cls  name tail_handle_ipv4  tag 7eb1fbdf358ca8e5  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 164
520: sched_cls  name tail_ipv4_ct_egress  tag 7724f69aa71d36e0  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 166
523: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 169
524: sched_cls  name tail_handle_arp  tag 1384843240e12aea  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 171
527: sched_cls  name tail_ipv4_ct_ingress  tag 6035410146548406  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 172
529: sched_cls  name cil_from_container  tag fbc91be3d5b9d7b0  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 176
530: sched_cls  name __send_drop_notify  tag 4950dd77b1eef8c1  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 177
531: sched_cls  name tail_handle_ipv4_cont  tag 1d43618609dea43d  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 178
535: sched_cls  name handle_policy  tag 6411d64c637cfd9a  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 179
537: sched_cls  name handle_policy  tag eb3f0283d045112b  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 185
538: sched_cls  name __send_drop_notify  tag e658dbe6f0f0bc8c  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 186
539: sched_cls  name tail_ipv4_to_endpoint  tag e3c093821852728f  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 183
540: sched_cls  name __send_drop_notify  tag 0d47c7b262c4c7df  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 189
541: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 190
543: sched_cls  name tail_ipv4_ct_ingress  tag 6653abea8e82f9fd  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 192
544: sched_cls  name tail_handle_ipv4  tag 7e5fe121af9db123  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 187
545: sched_cls  name cil_from_container  tag d1d542d5dd6e923d  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 118,76
	btf_id 193
546: sched_cls  name tail_ipv4_ct_ingress  tag f77fbefba9cb9013  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 194
547: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,118
	btf_id 195
548: sched_cls  name tail_ipv4_to_endpoint  tag 42b6b903f61520ea  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 196
549: sched_cls  name tail_handle_ipv4_cont  tag 95f7ecc0c85aa605  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,117,41,100,82,83,39,76,74,77,118,40,37,38,81
	btf_id 197
550: sched_cls  name tail_handle_arp  tag 7a9f551fc0fcdadf  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 198
551: sched_cls  name tail_ipv4_ct_egress  tag 7724f69aa71d36e0  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 200
552: sched_cls  name tail_handle_ipv4_cont  tag be8a39e60e9e82f6  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 201
553: sched_cls  name tail_handle_ipv4  tag 1daf1a7ac6d36e8b  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,118
	btf_id 199
554: sched_cls  name tail_handle_arp  tag b5bd29d68bbae115  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,118
	btf_id 203
555: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 202
556: sched_cls  name cil_from_container  tag eb8a9881d77bdda5  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 205
558: sched_cls  name handle_policy  tag 6e073abef308687f  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,118,82,83,117,41,80,100,39,84,75,40,37,38
	btf_id 204
559: sched_cls  name tail_ipv4_to_endpoint  tag b9a5bf6098c63aa8  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,117,41,82,83,80,100,39,118,40,37,38
	btf_id 207
560: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
563: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
564: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
567: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
568: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
571: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
572: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
575: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
615: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:09:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,134
	btf_id 221
616: sched_cls  name tail_ipv4_to_endpoint  tag 3e4176f2c1b3ba71  gpl
	loaded_at 2024-10-30T08:09:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,135,41,82,83,80,133,39,134,40,37,38
	btf_id 222
618: sched_cls  name cil_from_container  tag 5f4c5f786218357d  gpl
	loaded_at 2024-10-30T08:09:30+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 134,76
	btf_id 224
619: sched_cls  name tail_ipv4_ct_egress  tag a019ced8b8a65831  gpl
	loaded_at 2024-10-30T08:09:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 225
620: sched_cls  name tail_handle_arp  tag 41582ad07cd3470b  gpl
	loaded_at 2024-10-30T08:09:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,134
	btf_id 226
621: sched_cls  name tail_handle_ipv4  tag 8073f0b6425ff140  gpl
	loaded_at 2024-10-30T08:09:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,134
	btf_id 227
622: sched_cls  name tail_ipv4_ct_ingress  tag c376477e369888e4  gpl
	loaded_at 2024-10-30T08:09:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 228
623: sched_cls  name tail_handle_ipv4_cont  tag 15712b4ec8631756  gpl
	loaded_at 2024-10-30T08:09:30+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,135,41,133,82,83,39,76,74,77,134,40,37,38,81
	btf_id 229
624: sched_cls  name handle_policy  tag 7de1ef9b387b320e  gpl
	loaded_at 2024-10-30T08:09:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,134,82,83,135,41,80,133,39,84,75,40,37,38
	btf_id 230
625: sched_cls  name __send_drop_notify  tag b877dfc45d4e95b5  gpl
	loaded_at 2024-10-30T08:09:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 231
626: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
629: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
642: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
645: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
646: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
649: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
