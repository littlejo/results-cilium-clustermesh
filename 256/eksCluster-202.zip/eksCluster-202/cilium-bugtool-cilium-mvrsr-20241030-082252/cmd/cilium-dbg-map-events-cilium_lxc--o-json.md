{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.804Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.143.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.805Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.153.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.805Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:23.191Z",
  "value": "id=1798  sec_id=4     flags=0x0000 ifindex=10  mac=B2:D4:30:30:57:5C nodemac=AE:E6:A9:78:09:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:23.210Z",
  "value": "id=2771  sec_id=6652165 flags=0x0000 ifindex=12  mac=F6:1B:67:06:D7:51 nodemac=3A:3E:15:84:71:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:23.254Z",
  "value": "id=3833  sec_id=6652165 flags=0x0000 ifindex=14  mac=C2:22:6C:A0:EA:1B nodemac=1E:A6:2F:0C:64:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:23.255Z",
  "value": "id=2771  sec_id=6652165 flags=0x0000 ifindex=12  mac=F6:1B:67:06:D7:51 nodemac=3A:3E:15:84:71:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:23.272Z",
  "value": "id=1798  sec_id=4     flags=0x0000 ifindex=10  mac=B2:D4:30:30:57:5C nodemac=AE:E6:A9:78:09:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:59.770Z",
  "value": "id=3833  sec_id=6652165 flags=0x0000 ifindex=14  mac=C2:22:6C:A0:EA:1B nodemac=1E:A6:2F:0C:64:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:59.771Z",
  "value": "id=1798  sec_id=4     flags=0x0000 ifindex=10  mac=B2:D4:30:30:57:5C nodemac=AE:E6:A9:78:09:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:59.771Z",
  "value": "id=2771  sec_id=6652165 flags=0x0000 ifindex=12  mac=F6:1B:67:06:D7:51 nodemac=3A:3E:15:84:71:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:59.800Z",
  "value": "id=1973  sec_id=6683838 flags=0x0000 ifindex=16  mac=42:F3:21:B8:0D:E2 nodemac=D2:DE:2A:6B:9F:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:30.196Z",
  "value": "id=1408  sec_id=6683838 flags=0x0000 ifindex=18  mac=0E:C4:02:5E:50:CA nodemac=2A:F0:89:B4:FB:32"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.202.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.435Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.042Z",
  "value": "id=2771  sec_id=6652165 flags=0x0000 ifindex=12  mac=F6:1B:67:06:D7:51 nodemac=3A:3E:15:84:71:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.043Z",
  "value": "id=3833  sec_id=6652165 flags=0x0000 ifindex=14  mac=C2:22:6C:A0:EA:1B nodemac=1E:A6:2F:0C:64:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.043Z",
  "value": "id=1408  sec_id=6683838 flags=0x0000 ifindex=18  mac=0E:C4:02:5E:50:CA nodemac=2A:F0:89:B4:FB:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.044Z",
  "value": "id=1798  sec_id=4     flags=0x0000 ifindex=10  mac=B2:D4:30:30:57:5C nodemac=AE:E6:A9:78:09:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:26.056Z",
  "value": "id=1798  sec_id=4     flags=0x0000 ifindex=10  mac=B2:D4:30:30:57:5C nodemac=AE:E6:A9:78:09:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:26.057Z",
  "value": "id=2771  sec_id=6652165 flags=0x0000 ifindex=12  mac=F6:1B:67:06:D7:51 nodemac=3A:3E:15:84:71:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:26.057Z",
  "value": "id=3833  sec_id=6652165 flags=0x0000 ifindex=14  mac=C2:22:6C:A0:EA:1B nodemac=1E:A6:2F:0C:64:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:26.057Z",
  "value": "id=1408  sec_id=6683838 flags=0x0000 ifindex=18  mac=0E:C4:02:5E:50:CA nodemac=2A:F0:89:B4:FB:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.055Z",
  "value": "id=1408  sec_id=6683838 flags=0x0000 ifindex=18  mac=0E:C4:02:5E:50:CA nodemac=2A:F0:89:B4:FB:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.055Z",
  "value": "id=2771  sec_id=6652165 flags=0x0000 ifindex=12  mac=F6:1B:67:06:D7:51 nodemac=3A:3E:15:84:71:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.055Z",
  "value": "id=1798  sec_id=4     flags=0x0000 ifindex=10  mac=B2:D4:30:30:57:5C nodemac=AE:E6:A9:78:09:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.055Z",
  "value": "id=3833  sec_id=6652165 flags=0x0000 ifindex=14  mac=C2:22:6C:A0:EA:1B nodemac=1E:A6:2F:0C:64:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:28.055Z",
  "value": "id=1798  sec_id=4     flags=0x0000 ifindex=10  mac=B2:D4:30:30:57:5C nodemac=AE:E6:A9:78:09:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:28.055Z",
  "value": "id=1408  sec_id=6683838 flags=0x0000 ifindex=18  mac=0E:C4:02:5E:50:CA nodemac=2A:F0:89:B4:FB:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:28.055Z",
  "value": "id=2771  sec_id=6652165 flags=0x0000 ifindex=12  mac=F6:1B:67:06:D7:51 nodemac=3A:3E:15:84:71:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.202.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:28.056Z",
  "value": "id=3833  sec_id=6652165 flags=0x0000 ifindex=14  mac=C2:22:6C:A0:EA:1B nodemac=1E:A6:2F:0C:64:A2"
}

