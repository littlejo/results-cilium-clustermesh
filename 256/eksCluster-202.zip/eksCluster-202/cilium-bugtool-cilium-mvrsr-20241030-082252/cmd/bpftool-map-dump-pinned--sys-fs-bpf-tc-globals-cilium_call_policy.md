key: 80 05 00 00  value: 70 02 00 00
key: 06 07 00 00  value: 2e 02 00 00
key: d3 0a 00 00  value: 17 02 00 00
key: f9 0e 00 00  value: 19 02 00 00
Found 4 elements
