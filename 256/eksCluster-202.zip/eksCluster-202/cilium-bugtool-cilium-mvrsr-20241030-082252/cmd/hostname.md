ip-172-31-143-84.eu-west-3.compute.internal
