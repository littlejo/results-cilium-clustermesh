1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:23:96:e5:31:07 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.143.84/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1855sec preferred_lft 1855sec
    inet6 fe80::423:96ff:fee5:3107/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:92:50:76:cc:fd brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.153.30/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::492:50ff:fe76:ccfd/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:3a:0a:17:aa:e2 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::543a:aff:fe17:aae2/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:aa:f5:20:a9:c5 brd ff:ff:ff:ff:ff:ff
    inet 10.202.0.241/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d8aa:f5ff:fe20:a9c5/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 52:71:05:da:43:f1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5071:5ff:feda:43f1/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:e6:a9:78:09:7e brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::ace6:a9ff:fe78:97e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf3125b653fa5@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:3e:15:84:71:37 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::383e:15ff:fe84:7137/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce3dc582da4eb@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:a6:2f:0c:64:a2 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::1ca6:2fff:fe0c:64a2/64 scope link 
       valid_lft forever preferred_lft forever
18: lxceb2b12b7b4a2@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:f0:89:b4:fb:32 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::28f0:89ff:feb4:fb32/64 scope link 
       valid_lft forever preferred_lft forever
