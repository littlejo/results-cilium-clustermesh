[
  {
    "containers": [
      {
        "cgroup-id": 9268,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2caa8350_c0df_4d30_87fb_a1ea2e401493.slice/cri-containerd-60f6abf35c497ca708702e4b00623c22b3f6dcbcca36d0767004de80b6370c21.scope"
      },
      {
        "cgroup-id": 9184,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2caa8350_c0df_4d30_87fb_a1ea2e401493.slice/cri-containerd-ba73cbeb75b898a44b5743a086eb71f6d17e6461f8e7422da99f1f36057c3064.scope"
      },
      {
        "cgroup-id": 9352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2caa8350_c0df_4d30_87fb_a1ea2e401493.slice/cri-containerd-c4f7a287284f71be8765fe25c36c1cf906bf359fada78f1af892dc409b4f2973.scope"
      }
    ],
    "ips": [
      "10.202.0.27"
    ],
    "name": "clustermesh-apiserver-f649c455-2lxf6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56cdb6a2_c326_4f7a_a0c4_4456f33bfbb7.slice/cri-containerd-c5e564f4f8f18d8d4f762f7c35f03274615adf68760e878494bc131d7e598107.scope"
      }
    ],
    "ips": [
      "10.202.0.94"
    ],
    "name": "coredns-cc6ccd49c-whf9f",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8331bca7_9d66_4747_a21f_cabd337a07e9.slice/cri-containerd-368fc5dbe25ceb1dc9ece3c18570a3d748f11a33b3d6dbdb906ae238a6e0e096.scope"
      }
    ],
    "ips": [
      "10.202.0.217"
    ],
    "name": "coredns-cc6ccd49c-4c92z",
    "namespace": "kube-system"
  }
]

