CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1a204d4_6971_42af_8dea_9dcbd0c7008b.slice/cri-containerd-652f9beeb440fa9c161092815bb1fb3ecdfd9cb29561b69d8eda71acf936f893.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1a204d4_6971_42af_8dea_9dcbd0c7008b.slice/cri-containerd-b6abbecef9f37b1bc22e4f5afe6a25ffadeb64741d0aed318001a934758b1547.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56cdb6a2_c326_4f7a_a0c4_4456f33bfbb7.slice/cri-containerd-c5e564f4f8f18d8d4f762f7c35f03274615adf68760e878494bc131d7e598107.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56cdb6a2_c326_4f7a_a0c4_4456f33bfbb7.slice/cri-containerd-af4e7b0110623941527ff5cf1aba1da32989632491b4f6c14c2d663162463e5e.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8331bca7_9d66_4747_a21f_cabd337a07e9.slice/cri-containerd-368fc5dbe25ceb1dc9ece3c18570a3d748f11a33b3d6dbdb906ae238a6e0e096.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8331bca7_9d66_4747_a21f_cabd337a07e9.slice/cri-containerd-6d757e6de73d1e4bd9364b942cc44ea9c2d22b37ddbc2c0b0baf42b57a973faa.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod54bfbc1d_7b39_40cd_9a23_ce92ec4f692a.slice/cri-containerd-3d11f2b24f700cfb227a997ded62313fea27e596190673f671fc39d63e4b1a39.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod54bfbc1d_7b39_40cd_9a23_ce92ec4f692a.slice/cri-containerd-57094087fcd816471bcdfaf9ad65197cfba7304fbe6f6703164440f57cf2dd16.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd53420b1_4e9f_4e88_80b5_308147b6be58.slice/cri-containerd-10a4431c131f849eeaf1b964bb7766c0009de2081b10b8a0a0438e70c3743038.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd53420b1_4e9f_4e88_80b5_308147b6be58.slice/cri-containerd-68f110772b13894a8857fa9f81c4e11f547359bb3e08082e4eab7f87f03518e5.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod375f69d7_feec_458a_b017_7fcc060166e9.slice/cri-containerd-d01fe4909a396dd772ded14fb4adc9679ba685dc14fb32df57a2fe73da35551a.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod375f69d7_feec_458a_b017_7fcc060166e9.slice/cri-containerd-be911774a10a93ec5233fdaf35a4a02aeac6ffe53732640d8985bebc7f915e1e.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2caa8350_c0df_4d30_87fb_a1ea2e401493.slice/cri-containerd-c4f7a287284f71be8765fe25c36c1cf906bf359fada78f1af892dc409b4f2973.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2caa8350_c0df_4d30_87fb_a1ea2e401493.slice/cri-containerd-ba73cbeb75b898a44b5743a086eb71f6d17e6461f8e7422da99f1f36057c3064.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2caa8350_c0df_4d30_87fb_a1ea2e401493.slice/cri-containerd-60f6abf35c497ca708702e4b00623c22b3f6dcbcca36d0767004de80b6370c21.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2caa8350_c0df_4d30_87fb_a1ea2e401493.slice/cri-containerd-89ca3dda11c99ca438f8393574ddb0fae3bdb177bbb503fd2bfc3c9bfc91c424.scope
    629      cgroup_device   multi                                          
