Endpoint ID: 1408
Path: /sys/fs/bpf/tc/globals/cilium_policy_01408

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11506437   116255    0        
Allow    Ingress     1          ANY          NONE         disabled    10932924   115461    0        
Allow    Egress      0          ANY          NONE         disabled    15183447   147866    0        


Endpoint ID: 1575
Path: /sys/fs/bpf/tc/globals/cilium_policy_01575

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1798
Path: /sys/fs/bpf/tc/globals/cilium_policy_01798

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1665078   21038     0        
Allow    Ingress     1          ANY          NONE         disabled    18978     225       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2771
Path: /sys/fs/bpf/tc/globals/cilium_policy_02771

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113116   1292      0        
Allow    Egress      0          ANY          NONE         disabled    16906    182       0        


Endpoint ID: 3833
Path: /sys/fs/bpf/tc/globals/cilium_policy_03833

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113805   1306      0        
Allow    Egress      0          ANY          NONE         disabled    16750    181       0        


