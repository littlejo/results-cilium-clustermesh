Total: 671
TCP:   1866 (estab 434, closed 1413, orphaned 0, timewait 567)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  453       442       11       
INET	  463       448       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                   172.31.143.84%ens5:68         0.0.0.0:*    uid:192 ino:15742 sk:1 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:34573 sk:2 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15511 sk:3 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:38529      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:35649 sk:4 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:34572 sk:314 cgroup:/ v6only:1 <->                                       
UNCONN 0      0                                [::1]:323           [::]:*    ino:15512 sk:315 cgroup:unreachable:f0c v6only:1 <->                         
UNCONN 0      0      [fe80::423:96ff:fee5:3107]%ens5:546           [::]:*    uid:192 ino:15733 sk:316 cgroup:unreachable:c4e v6only:1 <->                 
