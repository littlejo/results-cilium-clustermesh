Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal    138    206     67      3      1    111     51     31     11      5    851 
