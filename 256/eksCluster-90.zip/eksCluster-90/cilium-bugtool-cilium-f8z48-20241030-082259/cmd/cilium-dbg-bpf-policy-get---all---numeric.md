Endpoint ID: 596
Path: /sys/fs/bpf/tc/globals/cilium_policy_00596

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    195129   1751      0        
Allow    Ingress     1          ANY          NONE         disabled    167056   1917      0        
Allow    Egress      0          ANY          NONE         disabled    84962    832       0        


Endpoint ID: 1112
Path: /sys/fs/bpf/tc/globals/cilium_policy_01112

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    198300   1778      0        
Allow    Ingress     1          ANY          NONE         disabled    166000   1901      0        
Allow    Egress      0          ANY          NONE         disabled    86309    845       0        


Endpoint ID: 1656
Path: /sys/fs/bpf/tc/globals/cilium_policy_01656

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11546768   116506    0        
Allow    Ingress     1          ANY          NONE         disabled    11198835   118526    0        
Allow    Egress      0          ANY          NONE         disabled    15270753   149062    0        


Endpoint ID: 2002
Path: /sys/fs/bpf/tc/globals/cilium_policy_02002

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1668164   21074     0        
Allow    Ingress     1          ANY          NONE         disabled    24982     292       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3988
Path: /sys/fs/bpf/tc/globals/cilium_policy_03988

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


