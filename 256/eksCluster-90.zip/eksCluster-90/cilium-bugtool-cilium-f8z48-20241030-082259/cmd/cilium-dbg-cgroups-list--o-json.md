[
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod961b0b75_f8cd_484d_a651_c452b4cae4a4.slice/cri-containerd-468f7ea70ed4a1ddc1c310ee859247b53ca94478b1cfea6adafb03ec7bd4113c.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod961b0b75_f8cd_484d_a651_c452b4cae4a4.slice/cri-containerd-ea8c8f421f85d4bd7dcd5525bb126c6b7aaa21fbf37cb8ab749b3c2c51c5e403.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod961b0b75_f8cd_484d_a651_c452b4cae4a4.slice/cri-containerd-6cccf3d17c4780383c3a826ed8f42ac7b4516eeca70e5fa0711fa46fd165a4de.scope"
      }
    ],
    "ips": [
      "10.90.0.55"
    ],
    "name": "clustermesh-apiserver-9f564c4b4-xsxf5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7751,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e571507_860c_4cbb_b1b5_35c74ab77546.slice/cri-containerd-a183f5db025808de11e6b4f730cad7003c02e6aa8b6cb70f4a0f9c034e7c1e04.scope"
      }
    ],
    "ips": [
      "10.90.0.251"
    ],
    "name": "coredns-cc6ccd49c-mzjlm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7835,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podadd9ec14_069d_4bad_a341_c60f7615a92a.slice/cri-containerd-11d77bfa69f81624e7c8c95c7978068fc41d885e816913164135f244f0ed362e.scope"
      }
    ],
    "ips": [
      "10.90.0.168"
    ],
    "name": "coredns-cc6ccd49c-2sz64",
    "namespace": "kube-system"
  }
]

