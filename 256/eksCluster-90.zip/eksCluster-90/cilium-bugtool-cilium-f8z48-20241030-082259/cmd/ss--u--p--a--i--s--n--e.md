Total: 678
TCP:   1837 (estab 427, closed 1391, orphaned 0, timewait 561)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  446       434       12       
INET	  456       440       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:39837      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:31923 sk:3e4 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.155.193%ens5:68         0.0.0.0:*    uid:192 ino:71335 sk:3e5 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:32779 sk:3e6 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:14953 sk:3e7 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:32778 sk:3e8 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:14954 sk:3e9 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::4ce:c0ff:febd:1e8b]%ens5:546           [::]:*    uid:192 ino:15879 sk:3ea cgroup:unreachable:c4e v6only:1 <->                   
