CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podadd9ec14_069d_4bad_a341_c60f7615a92a.slice/cri-containerd-11d77bfa69f81624e7c8c95c7978068fc41d885e816913164135f244f0ed362e.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podadd9ec14_069d_4bad_a341_c60f7615a92a.slice/cri-containerd-e5d06f3efd0f36ff6c5b5f1b8fe08479ebdc5969d2a3d7179d1004c1441dd3b6.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e571507_860c_4cbb_b1b5_35c74ab77546.slice/cri-containerd-a183f5db025808de11e6b4f730cad7003c02e6aa8b6cb70f4a0f9c034e7c1e04.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e571507_860c_4cbb_b1b5_35c74ab77546.slice/cri-containerd-268d60b94baad22469e8ebb42a4b9a97fa046bd0f92ee4d512f4a5a18cece229.scope
    530      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0884ba52_15e1_4d39_8fb6_b0214f83681b.slice/cri-containerd-0962339aea6f03be4255d98c16f292203dad35e347607784c44eaf3056d85c45.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0884ba52_15e1_4d39_8fb6_b0214f83681b.slice/cri-containerd-104b6c900d691397899e7e96c611a8acd7c2799a126821b9a32b688ff43f4e19.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6c0ec52_a8d5_4bda_a771_b9366a0d6e29.slice/cri-containerd-761d3534fe32ccb57d7e73b46b71484ad2602a5073568f4402744d4de17db330.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6c0ec52_a8d5_4bda_a771_b9366a0d6e29.slice/cri-containerd-2fc98e37078ec229b5f1014c962a55c430d3cb615ebfd8e2aa8218bdc2c34718.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71549dbd_4aa9_4fc7_9368_d4025e4ffc3d.slice/cri-containerd-d2529a6aec26cb259322ec2b4003c4d6956171bec336f26ea81b05829abeb834.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71549dbd_4aa9_4fc7_9368_d4025e4ffc3d.slice/cri-containerd-9e58f41ede249d2e114044ea0df73015f8893021a6179158ad92835ef020f5bc.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda0eae494_6670_4de6_bba2_fdc713a34612.slice/cri-containerd-8d3fd1361a3010ab9c8adae30d05bb777368336151bb184277b460d43f748692.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda0eae494_6670_4de6_bba2_fdc713a34612.slice/cri-containerd-aac39eaccf1bc7c5a335f5a6ac1c7b71b7dc3671687c8c04739c4527d6a92b12.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod961b0b75_f8cd_484d_a651_c452b4cae4a4.slice/cri-containerd-ea8c8f421f85d4bd7dcd5525bb126c6b7aaa21fbf37cb8ab749b3c2c51c5e403.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod961b0b75_f8cd_484d_a651_c452b4cae4a4.slice/cri-containerd-6cccf3d17c4780383c3a826ed8f42ac7b4516eeca70e5fa0711fa46fd165a4de.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod961b0b75_f8cd_484d_a651_c452b4cae4a4.slice/cri-containerd-4a383c6e53cd226a5f2b153f42a83f35b33ce85bfbb524a7e5c4d2c856327783.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod961b0b75_f8cd_484d_a651_c452b4cae4a4.slice/cri-containerd-468f7ea70ed4a1ddc1c310ee859247b53ca94478b1cfea6adafb03ec7bd4113c.scope
    654      cgroup_device   multi                                          
