USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         667  0.0  0.0 1228744 3600 ?        Ssl  08:23   0:00 /bin/gops stats 1
root         656  0.0  0.0 1229000 4056 ?        Ssl  08:23   0:00 /bin/gops pprof-cpu 1
root         655  0.0  0.0 1228744 4036 ?        Ssl  08:23   0:00 /bin/gops memstats 1
root         643  0.0  0.2 1240432 16488 ?       Ssl  08:23   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         701  0.0  0.0   6408  1652 ?        R    08:23   0:00  \_ ps auxfw
root         702  0.0  0.2 1240432 16488 ?       R    08:23   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         639  0.0  0.0 1229000 4052 ?        Ssl  08:23   0:00 /bin/gops stack 1
root         638  0.0  0.0 1229000 4056 ?        Ssl  08:23   0:00 /bin/gops pprof-heap 1
root           1  3.0  4.7 1606272 381056 ?      Ssl  07:54   0:52 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.0 1229488 7060 ?        Sl   07:54   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
