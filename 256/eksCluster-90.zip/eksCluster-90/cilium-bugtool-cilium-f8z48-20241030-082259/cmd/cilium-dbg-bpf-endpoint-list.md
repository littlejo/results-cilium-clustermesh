IP ADDRESS         LOCAL ENDPOINT INFO
172.31.155.193:0   (localhost)                                                                                        
172.31.163.255:0   (localhost)                                                                                        
10.90.0.251:0      id=1112  sec_id=3010069 flags=0x0000 ifindex=12  mac=92:00:E3:FA:19:1D nodemac=3A:65:85:58:8D:A8   
10.90.0.168:0      id=596   sec_id=3010069 flags=0x0000 ifindex=14  mac=46:AA:00:61:38:3B nodemac=56:55:1B:13:84:B6   
10.90.0.55:0       id=1656  sec_id=3012980 flags=0x0000 ifindex=18  mac=2A:48:FE:62:6C:94 nodemac=2E:F4:0D:C7:28:B0   
10.90.0.197:0      id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=8E:C4:1A:84:CA:58 nodemac=42:87:F8:7B:BD:6B     
10.90.0.170:0      (localhost)                                                                                        
