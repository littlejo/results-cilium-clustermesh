REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38124     3020595     677    bpf_overlay.c
Interface                 INGRESS     684477    137994167   1132   bpf_host.c
Success                   EGRESS      17786     1403319     1694   bpf_host.c
Success                   EGRESS      296276    36296010    1308   bpf_lxc.c
Success                   EGRESS      39232     3099483     53     encap.h
Success                   EGRESS      7058      1119339     86     l3.h
Success                   INGRESS     337886    38472568    86     l3.h
Success                   INGRESS     365933    41253229    235    trace.h
Unsupported L3 protocol   EGRESS      40        2956        1492   bpf_lxc.c
