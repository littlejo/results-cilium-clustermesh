{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:21.565Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.155.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:21.565Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.163.255:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:21.565Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:26.155Z",
  "value": "id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=8E:C4:1A:84:CA:58 nodemac=42:87:F8:7B:BD:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:26.159Z",
  "value": "id=1112  sec_id=3010069 flags=0x0000 ifindex=12  mac=92:00:E3:FA:19:1D nodemac=3A:65:85:58:8D:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:26.222Z",
  "value": "id=596   sec_id=3010069 flags=0x0000 ifindex=14  mac=46:AA:00:61:38:3B nodemac=56:55:1B:13:84:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:26.275Z",
  "value": "id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=8E:C4:1A:84:CA:58 nodemac=42:87:F8:7B:BD:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:26.370Z",
  "value": "id=1112  sec_id=3010069 flags=0x0000 ifindex=12  mac=92:00:E3:FA:19:1D nodemac=3A:65:85:58:8D:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:37.418Z",
  "value": "id=596   sec_id=3010069 flags=0x0000 ifindex=14  mac=46:AA:00:61:38:3B nodemac=56:55:1B:13:84:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:37.419Z",
  "value": "id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=8E:C4:1A:84:CA:58 nodemac=42:87:F8:7B:BD:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:37.419Z",
  "value": "id=1112  sec_id=3010069 flags=0x0000 ifindex=12  mac=92:00:E3:FA:19:1D nodemac=3A:65:85:58:8D:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:37.451Z",
  "value": "id=1745  sec_id=3012980 flags=0x0000 ifindex=16  mac=96:B6:D6:D8:15:B0 nodemac=36:38:49:6F:70:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:38.418Z",
  "value": "id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=8E:C4:1A:84:CA:58 nodemac=42:87:F8:7B:BD:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:38.419Z",
  "value": "id=1745  sec_id=3012980 flags=0x0000 ifindex=16  mac=96:B6:D6:D8:15:B0 nodemac=36:38:49:6F:70:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:38.419Z",
  "value": "id=596   sec_id=3010069 flags=0x0000 ifindex=14  mac=46:AA:00:61:38:3B nodemac=56:55:1B:13:84:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:38.419Z",
  "value": "id=1112  sec_id=3010069 flags=0x0000 ifindex=12  mac=92:00:E3:FA:19:1D nodemac=3A:65:85:58:8D:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:29.280Z",
  "value": "id=1656  sec_id=3012980 flags=0x0000 ifindex=18  mac=2A:48:FE:62:6C:94 nodemac=2E:F4:0D:C7:28:B0"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.90.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:39.867Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:17.225Z",
  "value": "id=1112  sec_id=3010069 flags=0x0000 ifindex=12  mac=92:00:E3:FA:19:1D nodemac=3A:65:85:58:8D:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:17.226Z",
  "value": "id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=8E:C4:1A:84:CA:58 nodemac=42:87:F8:7B:BD:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:17.226Z",
  "value": "id=596   sec_id=3010069 flags=0x0000 ifindex=14  mac=46:AA:00:61:38:3B nodemac=56:55:1B:13:84:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:17.226Z",
  "value": "id=1656  sec_id=3012980 flags=0x0000 ifindex=18  mac=2A:48:FE:62:6C:94 nodemac=2E:F4:0D:C7:28:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:18.207Z",
  "value": "id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=8E:C4:1A:84:CA:58 nodemac=42:87:F8:7B:BD:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:18.207Z",
  "value": "id=1656  sec_id=3012980 flags=0x0000 ifindex=18  mac=2A:48:FE:62:6C:94 nodemac=2E:F4:0D:C7:28:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:18.207Z",
  "value": "id=1112  sec_id=3010069 flags=0x0000 ifindex=12  mac=92:00:E3:FA:19:1D nodemac=3A:65:85:58:8D:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:18.208Z",
  "value": "id=596   sec_id=3010069 flags=0x0000 ifindex=14  mac=46:AA:00:61:38:3B nodemac=56:55:1B:13:84:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:19.207Z",
  "value": "id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=8E:C4:1A:84:CA:58 nodemac=42:87:F8:7B:BD:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:19.207Z",
  "value": "id=1656  sec_id=3012980 flags=0x0000 ifindex=18  mac=2A:48:FE:62:6C:94 nodemac=2E:F4:0D:C7:28:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:19.207Z",
  "value": "id=1112  sec_id=3010069 flags=0x0000 ifindex=12  mac=92:00:E3:FA:19:1D nodemac=3A:65:85:58:8D:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:19.208Z",
  "value": "id=596   sec_id=3010069 flags=0x0000 ifindex=14  mac=46:AA:00:61:38:3B nodemac=56:55:1B:13:84:B6"
}

