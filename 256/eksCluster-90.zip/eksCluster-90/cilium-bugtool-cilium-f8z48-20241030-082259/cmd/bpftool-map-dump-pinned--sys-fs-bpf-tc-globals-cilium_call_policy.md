key: 54 02 00 00  value: 02 02 00 00
key: 58 04 00 00  value: 17 02 00 00
key: 78 06 00 00  value: 6d 02 00 00
key: d2 07 00 00  value: 07 02 00 00
Found 4 elements
