KEY             VALUE
AgentLiveness   2171123969529
UTimeOffset     3379442267578125
