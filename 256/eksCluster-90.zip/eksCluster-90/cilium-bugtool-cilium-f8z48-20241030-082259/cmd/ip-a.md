1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ce:c0:bd:1e:8b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.155.193/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3270sec preferred_lft 3270sec
    inet6 fe80::4ce:c0ff:febd:1e8b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:e8:a0:6e:7d:67 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.163.255/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4e8:a0ff:fe6e:7d67/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:2c:97:97:49:29 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::502c:97ff:fe97:4929/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:de:45:15:26:82 brd ff:ff:ff:ff:ff:ff
    inet 10.90.0.170/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::48de:45ff:fe15:2682/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether fa:bc:e9:33:91:cf brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f8bc:e9ff:fe33:91cf/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:87:f8:7b:bd:6b brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4087:f8ff:fe7b:bd6b/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc1cb1101c626d@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:65:85:58:8d:a8 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::3865:85ff:fe58:8da8/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcdc3e4b012c5b@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:55:1b:13:84:b6 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::5455:1bff:fe13:84b6/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc0921de5a5513@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:f4:0d:c7:28:b0 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2cf4:dff:fec7:28b0/64 scope link 
       valid_lft forever preferred_lft forever
