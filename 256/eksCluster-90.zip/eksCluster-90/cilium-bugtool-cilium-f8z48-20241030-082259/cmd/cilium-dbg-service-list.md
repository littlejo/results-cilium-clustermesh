ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.202.237:443 (active)    
                                         2 => 172.31.167.83:443 (active)     
2    10.100.68.33:443     ClusterIP      1 => 172.31.155.193:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.90.0.168:53 (active)        
                                         2 => 10.90.0.251:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.90.0.168:9153 (active)      
                                         2 => 10.90.0.251:9153 (active)      
5    10.100.84.252:2379   ClusterIP      1 => 10.90.0.55:2379 (active)       
