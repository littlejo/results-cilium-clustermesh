alloc: 150.89MB (158217160 bytes)
total-alloc: 2.43GB (2612105048 bytes)
sys: 328.96MB (344936804 bytes)
lookups: 0
mallocs: 66500623
frees: 64923486
heap-alloc: 150.89MB (158217160 bytes)
heap-sys: 251.23MB (263430144 bytes)
heap-idle: 69.64MB (73023488 bytes)
heap-in-use: 181.59MB (190406656 bytes)
heap-released: 3.30MB (3457024 bytes)
heap-objects: 1577137
stack-in-use: 64.75MB (67895296 bytes)
stack-sys: 64.75MB (67895296 bytes)
stack-mspan-inuse: 3.08MB (3232800 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.25MB (1307209 bytes)
gc-sys: 5.93MB (6215072 bytes)
next-gc: when heap-alloc >= 211.91MB (222204632 bytes)
last-gc: 2024-10-30 08:23:08.068973318 +0000 UTC
gc-pause-total: 11.480472ms
gc-pause: 146536
gc-pause-end: 1730276588068973318
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00034234384436532055
enable-gc: true
debug-gc: false
