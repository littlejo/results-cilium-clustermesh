markdown output at /tmp/cilium-bugtool-20241030-082300.767+0000-UTC-361536445/cmd/cilium-debuginfo-20241030-082331.981+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082300.767+0000-UTC-361536445/cmd/cilium-debuginfo-20241030-082331.981+0000-UTC.json
