REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36945     2922956     677    bpf_overlay.c
Interface                 INGRESS     646752    133199413   1132   bpf_host.c
Success                   EGRESS      16509     1299934     1694   bpf_host.c
Success                   EGRESS      272924    34255663    1308   bpf_lxc.c
Success                   EGRESS      37160     2939216     53     encap.h
Success                   INGRESS     318236    35690544    86     l3.h
Success                   INGRESS     339323    37357612    235    trace.h
Unsupported L3 protocol   EGRESS      47        3522        1492   bpf_lxc.c
