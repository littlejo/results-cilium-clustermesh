KEY             VALUE
AgentLiveness   2285017918232
UTimeOffset     3379442039062500
