{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.459Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.152.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.460Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.172.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.460Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:46.124Z",
  "value": "id=1804  sec_id=4     flags=0x0000 ifindex=10  mac=E2:B3:34:08:0C:7F nodemac=02:DE:E7:55:4F:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:46.126Z",
  "value": "id=516   sec_id=1085271 flags=0x0000 ifindex=14  mac=2E:95:92:E1:C1:21 nodemac=46:FE:76:47:85:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:46.182Z",
  "value": "id=900   sec_id=1085271 flags=0x0000 ifindex=12  mac=A6:D9:F0:B9:32:C2 nodemac=E6:55:50:28:D0:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:46.183Z",
  "value": "id=516   sec_id=1085271 flags=0x0000 ifindex=14  mac=2E:95:92:E1:C1:21 nodemac=46:FE:76:47:85:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:46.184Z",
  "value": "id=1804  sec_id=4     flags=0x0000 ifindex=10  mac=E2:B3:34:08:0C:7F nodemac=02:DE:E7:55:4F:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:06.050Z",
  "value": "id=516   sec_id=1085271 flags=0x0000 ifindex=14  mac=2E:95:92:E1:C1:21 nodemac=46:FE:76:47:85:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:06.051Z",
  "value": "id=900   sec_id=1085271 flags=0x0000 ifindex=12  mac=A6:D9:F0:B9:32:C2 nodemac=E6:55:50:28:D0:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:06.051Z",
  "value": "id=1804  sec_id=4     flags=0x0000 ifindex=10  mac=E2:B3:34:08:0C:7F nodemac=02:DE:E7:55:4F:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:06.084Z",
  "value": "id=537   sec_id=1105469 flags=0x0000 ifindex=16  mac=2A:A6:6D:A3:E0:E9 nodemac=52:52:03:E6:02:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:07.051Z",
  "value": "id=516   sec_id=1085271 flags=0x0000 ifindex=14  mac=2E:95:92:E1:C1:21 nodemac=46:FE:76:47:85:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:07.051Z",
  "value": "id=537   sec_id=1105469 flags=0x0000 ifindex=16  mac=2A:A6:6D:A3:E0:E9 nodemac=52:52:03:E6:02:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:07.052Z",
  "value": "id=900   sec_id=1085271 flags=0x0000 ifindex=12  mac=A6:D9:F0:B9:32:C2 nodemac=E6:55:50:28:D0:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:07.052Z",
  "value": "id=1804  sec_id=4     flags=0x0000 ifindex=10  mac=E2:B3:34:08:0C:7F nodemac=02:DE:E7:55:4F:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:16.242Z",
  "value": "id=292   sec_id=1105469 flags=0x0000 ifindex=18  mac=FA:1B:08:BE:E8:92 nodemac=86:72:E6:B0:8F:43"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.32.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:26.617Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.179Z",
  "value": "id=516   sec_id=1085271 flags=0x0000 ifindex=14  mac=2E:95:92:E1:C1:21 nodemac=46:FE:76:47:85:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.179Z",
  "value": "id=900   sec_id=1085271 flags=0x0000 ifindex=12  mac=A6:D9:F0:B9:32:C2 nodemac=E6:55:50:28:D0:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.180Z",
  "value": "id=292   sec_id=1105469 flags=0x0000 ifindex=18  mac=FA:1B:08:BE:E8:92 nodemac=86:72:E6:B0:8F:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.181Z",
  "value": "id=1804  sec_id=4     flags=0x0000 ifindex=10  mac=E2:B3:34:08:0C:7F nodemac=02:DE:E7:55:4F:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.193Z",
  "value": "id=292   sec_id=1105469 flags=0x0000 ifindex=18  mac=FA:1B:08:BE:E8:92 nodemac=86:72:E6:B0:8F:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.194Z",
  "value": "id=1804  sec_id=4     flags=0x0000 ifindex=10  mac=E2:B3:34:08:0C:7F nodemac=02:DE:E7:55:4F:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.195Z",
  "value": "id=516   sec_id=1085271 flags=0x0000 ifindex=14  mac=2E:95:92:E1:C1:21 nodemac=46:FE:76:47:85:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.195Z",
  "value": "id=900   sec_id=1085271 flags=0x0000 ifindex=12  mac=A6:D9:F0:B9:32:C2 nodemac=E6:55:50:28:D0:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.180Z",
  "value": "id=1804  sec_id=4     flags=0x0000 ifindex=10  mac=E2:B3:34:08:0C:7F nodemac=02:DE:E7:55:4F:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.180Z",
  "value": "id=292   sec_id=1105469 flags=0x0000 ifindex=18  mac=FA:1B:08:BE:E8:92 nodemac=86:72:E6:B0:8F:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.180Z",
  "value": "id=516   sec_id=1085271 flags=0x0000 ifindex=14  mac=2E:95:92:E1:C1:21 nodemac=46:FE:76:47:85:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.180Z",
  "value": "id=900   sec_id=1085271 flags=0x0000 ifindex=12  mac=A6:D9:F0:B9:32:C2 nodemac=E6:55:50:28:D0:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.180Z",
  "value": "id=292   sec_id=1105469 flags=0x0000 ifindex=18  mac=FA:1B:08:BE:E8:92 nodemac=86:72:E6:B0:8F:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.181Z",
  "value": "id=900   sec_id=1085271 flags=0x0000 ifindex=12  mac=A6:D9:F0:B9:32:C2 nodemac=E6:55:50:28:D0:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.181Z",
  "value": "id=516   sec_id=1085271 flags=0x0000 ifindex=14  mac=2E:95:92:E1:C1:21 nodemac=46:FE:76:47:85:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.181Z",
  "value": "id=1804  sec_id=4     flags=0x0000 ifindex=10  mac=E2:B3:34:08:0C:7F nodemac=02:DE:E7:55:4F:97"
}

