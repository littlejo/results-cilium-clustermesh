CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68dc6631_d985_4d3b_84a2_26919d3cbae8.slice/cri-containerd-24e3fa5302a7d331aa7efda209eab3f52d519c9dd7b90547b508f9741dab4286.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68dc6631_d985_4d3b_84a2_26919d3cbae8.slice/cri-containerd-d3be857a2b042f443e6e811c634560047335cc673fa76c6f6a956d7dc51c5f5e.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5a6c42be_f616_431d_a502_f3d23b87ca24.slice/cri-containerd-2f64ac1a39e1d43fa2d7b9bbc3a59672e7161331cf4838cad3ca96f6da380b13.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5a6c42be_f616_431d_a502_f3d23b87ca24.slice/cri-containerd-0d96c0c025c5e5605aadb3aa69642a2814a0cd4f8da1f127cc3ab9ad71966295.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a44aa2b_e515_4f3a_a469_bf38606c8a5b.slice/cri-containerd-57faa581be4a47e3dc3dec5344ee594c7d4b5c6ea8a6bc4e37e925016c1bc9a3.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a44aa2b_e515_4f3a_a469_bf38606c8a5b.slice/cri-containerd-1ef4387cb20aebffb0d8ba7c99e4b5de1ce03d4456fd76a791e1f7dae8b3c74f.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9371e6e_cd04_4fe9_94ee_3b1f060abadb.slice/cri-containerd-ec2e981588e35d5fdb2c860da8cdab6dd460b3918b90de65e8111b972b4e8606.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9371e6e_cd04_4fe9_94ee_3b1f060abadb.slice/cri-containerd-b45858c7683ea4760c572ba3c94a73b7e61a842421dc4eeb1a79b8b1ea6ef9e9.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode5dba579_7461_4db6_9a58_596a45c727c8.slice/cri-containerd-0ba97082da33bed1e34e51fafc688e8deca0a35edced0b122860b82f8be28493.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode5dba579_7461_4db6_9a58_596a45c727c8.slice/cri-containerd-d19899c9f5f3103a2cb65dd2db757b14da1a97e86381b0bc1257e9cb38369b40.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd89302da_2653_4a8f_aeaa_fe7a3547e573.slice/cri-containerd-ba1cd2633602a7520df264608b1ecb880f1ecf7279c714a653f5743f9663a215.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd89302da_2653_4a8f_aeaa_fe7a3547e573.slice/cri-containerd-2fa277e83636423fd363ce071c3c2128545ceb73819df74c68a17e0d2040075c.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e19ca32_0ac2_4d04_9c56_efc0fe42811c.slice/cri-containerd-bba5d3c4311b61d69373c3faef4897200e4ffb4b4a13b179d12524f1ac68f508.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e19ca32_0ac2_4d04_9c56_efc0fe42811c.slice/cri-containerd-7b49cc120f570ce1ca95353c76a1aa00e95b842ef6028482324f5de6a59eee78.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e19ca32_0ac2_4d04_9c56_efc0fe42811c.slice/cri-containerd-c7d35644c018961d6102f27b8416f965fb6cf87ce28f98c6fb2062bd95e58e7c.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e19ca32_0ac2_4d04_9c56_efc0fe42811c.slice/cri-containerd-8fbf5e4eeb020fac89299f880e3aad7e1a390408bb43df95d915dccb4bf7639c.scope
    642      cgroup_device   multi                                          
