alloc: 178.60MB (187270912 bytes)
total-alloc: 2.32GB (2488103944 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 64364073
frees: 62853045
heap-alloc: 178.60MB (187270912 bytes)
heap-sys: 251.34MB (263553024 bytes)
heap-idle: 39.55MB (41476096 bytes)
heap-in-use: 211.79MB (222076928 bytes)
heap-released: 1.87MB (1957888 bytes)
heap-objects: 1511028
stack-in-use: 60.25MB (63176704 bytes)
stack-sys: 60.25MB (63176704 bytes)
stack-mspan-inuse: 3.56MB (3737760 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 975.59KB (999001 bytes)
gc-sys: 6.36MB (6667656 bytes)
next-gc: when heap-alloc >= 219.65MB (230315784 bytes)
last-gc: 2024-10-30 08:23:28.237391933 +0000 UTC
gc-pause-total: 20.616906ms
gc-pause: 1033371
gc-pause-end: 1730276608237391933
num-gc: 87
num-forced-gc: 0
gc-cpu-fraction: 0.0004154313584130574
enable-gc: true
debug-gc: false
