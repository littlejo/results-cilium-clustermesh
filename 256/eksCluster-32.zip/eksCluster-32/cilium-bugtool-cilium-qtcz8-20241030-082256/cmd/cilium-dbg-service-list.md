ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.164.226:443 (active)    
                                         2 => 172.31.192.42:443 (active)     
2    10.100.240.56:443    ClusterIP      1 => 172.31.172.199:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.32.0.24:53 (active)         
                                         2 => 10.32.0.150:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.32.0.24:9153 (active)       
                                         2 => 10.32.0.150:9153 (active)      
5    10.100.181.91:2379   ClusterIP      1 => 10.32.0.202:2379 (active)      
