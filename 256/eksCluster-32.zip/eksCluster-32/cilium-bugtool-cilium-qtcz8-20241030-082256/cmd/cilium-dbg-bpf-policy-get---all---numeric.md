Endpoint ID: 292
Path: /sys/fs/bpf/tc/globals/cilium_policy_00292

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11616277   115556    0        
Allow    Ingress     1          ANY          NONE         disabled    10217191   107878    0        
Allow    Egress      0          ANY          NONE         disabled    12569599   123993    0        


Endpoint ID: 516
Path: /sys/fs/bpf/tc/globals/cilium_policy_00516

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    175705   2016      0        
Allow    Egress      0          ANY          NONE         disabled    21661    244       0        


Endpoint ID: 900
Path: /sys/fs/bpf/tc/globals/cilium_policy_00900

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    175738   2022      0        
Allow    Egress      0          ANY          NONE         disabled    20389    228       0        


Endpoint ID: 1804
Path: /sys/fs/bpf/tc/globals/cilium_policy_01804

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1669882   21120     0        
Allow    Ingress     1          ANY          NONE         disabled    26772     314       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2246
Path: /sys/fs/bpf/tc/globals/cilium_policy_02246

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


