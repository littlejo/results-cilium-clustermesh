key: 24 01 00 00  value: 6a 02 00 00
key: 04 02 00 00  value: 07 02 00 00
key: 84 03 00 00  value: 28 02 00 00
key: 0c 07 00 00  value: 1a 02 00 00
Found 4 elements
