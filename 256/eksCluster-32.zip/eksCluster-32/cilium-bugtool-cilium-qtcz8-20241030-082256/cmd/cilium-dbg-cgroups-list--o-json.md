[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5a6c42be_f616_431d_a502_f3d23b87ca24.slice/cri-containerd-0d96c0c025c5e5605aadb3aa69642a2814a0cd4f8da1f127cc3ab9ad71966295.scope"
      }
    ],
    "ips": [
      "10.32.0.24"
    ],
    "name": "coredns-cc6ccd49c-rclt4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e19ca32_0ac2_4d04_9c56_efc0fe42811c.slice/cri-containerd-7b49cc120f570ce1ca95353c76a1aa00e95b842ef6028482324f5de6a59eee78.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e19ca32_0ac2_4d04_9c56_efc0fe42811c.slice/cri-containerd-c7d35644c018961d6102f27b8416f965fb6cf87ce28f98c6fb2062bd95e58e7c.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e19ca32_0ac2_4d04_9c56_efc0fe42811c.slice/cri-containerd-8fbf5e4eeb020fac89299f880e3aad7e1a390408bb43df95d915dccb4bf7639c.scope"
      }
    ],
    "ips": [
      "10.32.0.202"
    ],
    "name": "clustermesh-apiserver-7485fbbc95-nsc9n",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9371e6e_cd04_4fe9_94ee_3b1f060abadb.slice/cri-containerd-ec2e981588e35d5fdb2c860da8cdab6dd460b3918b90de65e8111b972b4e8606.scope"
      }
    ],
    "ips": [
      "10.32.0.150"
    ],
    "name": "coredns-cc6ccd49c-xlvbh",
    "namespace": "kube-system"
  }
]

