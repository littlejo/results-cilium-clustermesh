top - 08:22:58 up 37 min,  0 users,  load average: 0.23, 0.19, 0.18
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 17.2 us, 34.5 sy,  0.0 ni, 48.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4509.5 free,   1189.1 used,   2115.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6440.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 381460  78392 S  13.3   4.8   0:55.96 cilium-+
    416 root      20   0 1229488   8088   3836 S   0.0   0.1   0:01.18 cilium-+
    639 root      20   0 1240432  15896  11164 S   0.0   0.2   0:00.02 cilium-+
    641 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    642 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    693 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    699 root      20   0    6576   2420   2096 R   0.0   0.0   0:00.00 top
    706 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    730 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
