IP ADDRESS         LOCAL ENDPOINT INFO
10.32.0.160:0      id=1804  sec_id=4     flags=0x0000 ifindex=10  mac=E2:B3:34:08:0C:7F nodemac=02:DE:E7:55:4F:97     
10.32.0.150:0      id=516   sec_id=1085271 flags=0x0000 ifindex=14  mac=2E:95:92:E1:C1:21 nodemac=46:FE:76:47:85:AC   
172.31.152.254:0   (localhost)                                                                                        
10.32.0.221:0      (localhost)                                                                                        
172.31.172.199:0   (localhost)                                                                                        
10.32.0.202:0      id=292   sec_id=1105469 flags=0x0000 ifindex=18  mac=FA:1B:08:BE:E8:92 nodemac=86:72:E6:B0:8F:43   
10.32.0.24:0       id=900   sec_id=1085271 flags=0x0000 ifindex=12  mac=A6:D9:F0:B9:32:C2 nodemac=E6:55:50:28:D0:E3   
