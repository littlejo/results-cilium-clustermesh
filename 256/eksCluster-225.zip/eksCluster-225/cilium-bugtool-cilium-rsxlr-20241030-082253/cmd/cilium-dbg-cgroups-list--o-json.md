[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb993a918_63b5_410b_86c5_9df00a8b55cf.slice/cri-containerd-49d92d0e863681e7bcb7ad9fbc48bdb44df927714b26c946ce82dc049b55a505.scope"
      }
    ],
    "ips": [
      "10.225.0.110"
    ],
    "name": "coredns-cc6ccd49c-jxz99",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb8a3b25a_f296_4f70_bee5_32d77ef29b2b.slice/cri-containerd-61d0d0440affaf8d2607e91c452c56e1db8a4ee90a28be05f9214949ff83824c.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb8a3b25a_f296_4f70_bee5_32d77ef29b2b.slice/cri-containerd-25fe4bc5a6d15ad2f4171c24b51bace862b92b2f4816988d06ceb25b2a07c49c.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb8a3b25a_f296_4f70_bee5_32d77ef29b2b.slice/cri-containerd-0b1ad7fc9803431a940c173ba46441dc8fa2224bf186f1a31ca79af3b9885174.scope"
      }
    ],
    "ips": [
      "10.225.0.238"
    ],
    "name": "clustermesh-apiserver-684469cfb7-stzsr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod12c9df32_a036_401d_b361_857c542b67ff.slice/cri-containerd-e5342f2df56dce6ec3a6c99a2ac19ef03ecf51b0ece2347059630fc2d164ebb8.scope"
      }
    ],
    "ips": [
      "10.225.0.242"
    ],
    "name": "coredns-cc6ccd49c-lwpjb",
    "namespace": "kube-system"
  }
]

