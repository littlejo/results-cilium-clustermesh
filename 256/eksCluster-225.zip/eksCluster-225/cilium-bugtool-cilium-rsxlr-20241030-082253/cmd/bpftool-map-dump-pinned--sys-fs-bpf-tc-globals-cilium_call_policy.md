key: 1d 02 00 00  value: fb 01 00 00
key: 8c 03 00 00  value: 1e 02 00 00
key: 27 05 00 00  value: 75 02 00 00
key: 98 0b 00 00  value: 11 02 00 00
Found 4 elements
