USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         719  0.0  0.1 1616008 8324 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         682  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         674  0.0  0.0 1228744 3656 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         645  0.0  0.2 1240176 16076 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         720  0.0  0.0   6408  1632 ?        R    08:22   0:00  \_ ps auxfw
root         725  0.0  0.0   2020   400 ?        R    08:22   0:00  \_ bash -c ip a
root         644  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         639  0.0  0.0   2208   792 ?        Ss   08:22   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         690  0.0  0.2 1244340 21104 ?       Sl   08:22   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root           1  4.3  4.7 1606080 377268 ?      Ssl  08:03   0:51 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.1  0.1 1229488 8236 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
