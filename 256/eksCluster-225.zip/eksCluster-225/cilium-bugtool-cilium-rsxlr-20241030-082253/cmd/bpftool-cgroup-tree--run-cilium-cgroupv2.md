CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36e0366a_3551_408a_a9a8_58160eb7b9d8.slice/cri-containerd-1af3b800316505269625b547e9e0a2fc81fc1d33763f01ea91778164d7012370.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36e0366a_3551_408a_a9a8_58160eb7b9d8.slice/cri-containerd-141cd8367ea0e6d487f6acbabe1e2d695090a5317a11eb5aba291bd6d36148c0.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod12c9df32_a036_401d_b361_857c542b67ff.slice/cri-containerd-e5342f2df56dce6ec3a6c99a2ac19ef03ecf51b0ece2347059630fc2d164ebb8.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod12c9df32_a036_401d_b361_857c542b67ff.slice/cri-containerd-6ba774165109f56fbf5da4cbb656116645219747d58a2d517d95b7afaf82b52e.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4439577_9b54_45ba_90fe_fd0c9e156ce9.slice/cri-containerd-97754be7183af1266e7d52886f9a59fac87b7a6f7177ecc5fe62ada6cef7fc4d.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4439577_9b54_45ba_90fe_fd0c9e156ce9.slice/cri-containerd-af0685f0ea787f8a86176cb9d08576f930d8674bb94dc921e8dbd118f287559f.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb993a918_63b5_410b_86c5_9df00a8b55cf.slice/cri-containerd-49d92d0e863681e7bcb7ad9fbc48bdb44df927714b26c946ce82dc049b55a505.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb993a918_63b5_410b_86c5_9df00a8b55cf.slice/cri-containerd-9a5c58949dc560cf2ae3c5292d0ce5783990e9df14323efe5924eb76123f3eea.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0045869d_e2f6_48f4_8840_dafa23aeaec5.slice/cri-containerd-0764024b7f4d94b1e75f33b41d20e17644928d169977e180f735b1d2b6d9cb6b.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0045869d_e2f6_48f4_8840_dafa23aeaec5.slice/cri-containerd-4f94d0ccf76647fc530aacf4aaa5a2b7d606074820ae4de48298a3a996604dae.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbff92bb9_f2cf_4e8e_a703_82f138fb4077.slice/cri-containerd-f6bab3efac24240c076b3c8d75229caa1f6be1fc9deb96118792c02bdcc25d81.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbff92bb9_f2cf_4e8e_a703_82f138fb4077.slice/cri-containerd-bdb973aa74f9f23f18c43dc0569200287c5ddb0389af8c4ec4be287480fee30c.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb8a3b25a_f296_4f70_bee5_32d77ef29b2b.slice/cri-containerd-0b1ad7fc9803431a940c173ba46441dc8fa2224bf186f1a31ca79af3b9885174.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb8a3b25a_f296_4f70_bee5_32d77ef29b2b.slice/cri-containerd-97cd86f8d6901bc18d23cb65c3d2979605766f20dbb1f7b7d48a75325de82f2e.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb8a3b25a_f296_4f70_bee5_32d77ef29b2b.slice/cri-containerd-61d0d0440affaf8d2607e91c452c56e1db8a4ee90a28be05f9214949ff83824c.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb8a3b25a_f296_4f70_bee5_32d77ef29b2b.slice/cri-containerd-25fe4bc5a6d15ad2f4171c24b51bace862b92b2f4816988d06ceb25b2a07c49c.scope
    650      cgroup_device   multi                                          
