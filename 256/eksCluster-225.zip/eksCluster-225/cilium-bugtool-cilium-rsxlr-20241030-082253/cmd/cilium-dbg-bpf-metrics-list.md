REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34146     2700303     677    bpf_overlay.c
Interface                 INGRESS     610515    127694531   1132   bpf_host.c
Success                   EGRESS      13928     1090041     1694   bpf_host.c
Success                   EGRESS      257126    32732396    1308   bpf_lxc.c
Success                   EGRESS      32888     2606529     53     encap.h
Success                   INGRESS     296323    33404051    86     l3.h
Success                   INGRESS     317191    35058289    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
