IP ADDRESS         LOCAL ENDPOINT INFO
10.225.0.144:0     (localhost)                                                                                        
10.225.0.150:0     id=2968  sec_id=4     flags=0x0000 ifindex=10  mac=32:E5:7E:E0:18:89 nodemac=12:8A:F6:A9:A2:A9     
10.225.0.238:0     id=1319  sec_id=7431803 flags=0x0000 ifindex=18  mac=22:77:CE:E4:40:DA nodemac=8E:2D:45:B4:26:2E   
10.225.0.242:0     id=908   sec_id=7426220 flags=0x0000 ifindex=12  mac=26:F8:4C:BD:89:A1 nodemac=CA:6D:70:F1:94:3A   
10.225.0.110:0     id=541   sec_id=7426220 flags=0x0000 ifindex=14  mac=3E:6A:62:2E:42:F9 nodemac=BA:51:AE:DF:D5:B4   
172.31.237.223:0   (localhost)                                                                                        
172.31.212.55:0    (localhost)                                                                                        
