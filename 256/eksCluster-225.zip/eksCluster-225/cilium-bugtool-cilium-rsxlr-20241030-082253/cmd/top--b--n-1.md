top - 08:22:55 up 28 min,  0 users,  load average: 0.32, 0.23, 0.17
Tasks:  11 total,   3 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 50.0 us, 46.9 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.1 si,  0.0 st
MiB Mem :   7814.2 total,   4470.8 free,   1197.7 used,   2145.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6431.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    690 root      20   0 1244340  23768  14716 S  60.0   0.3   0:00.21 hubble
      1 root      20   0 1606080 377268  78524 S   6.7   4.7   0:51.24 cilium-+
    395 root      20   0 1229488   8236   4032 S   0.0   0.1   0:01.21 cilium-+
    639 root      20   0    2208    792    716 S   0.0   0.0   0:00.00 timeout
    644 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    645 root      20   0 1240432  16296  11228 S   0.0   0.2   0:00.03 cilium-+
    674 root      20   0 1228744   3656   2976 S   0.0   0.0   0:00.00 gops
    682 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    736 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    749 root      20   0    3132   1000    880 R   0.0   0.0   0:00.00 bpftool
    750 root      20   0    3284   1012    884 R   0.0   0.0   0:00.00 iptable+
