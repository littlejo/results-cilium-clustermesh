alloc: 171.14MB (179451520 bytes)
total-alloc: 2.13GB (2291409576 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 61630245
frees: 59893160
heap-alloc: 171.14MB (179451520 bytes)
heap-sys: 251.98MB (264216576 bytes)
heap-idle: 56.19MB (58916864 bytes)
heap-in-use: 195.79MB (205299712 bytes)
heap-released: 11.59MB (12156928 bytes)
heap-objects: 1737085
stack-in-use: 64.00MB (67108864 bytes)
stack-sys: 64.00MB (67108864 bytes)
stack-mspan-inuse: 3.05MB (3202240 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.03MB (1080257 bytes)
gc-sys: 6.00MB (6292968 bytes)
next-gc: when heap-alloc >= 212.83MB (223168408 bytes)
last-gc: 2024-10-30 08:22:59.38543267 +0000 UTC
gc-pause-total: 11.521564ms
gc-pause: 92232
gc-pause-end: 1730276579385432670
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005481021722164325
enable-gc: true
debug-gc: false
