Endpoint ID: 541
Path: /sys/fs/bpf/tc/globals/cilium_policy_00541

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112906   1296      0        
Allow    Egress      0          ANY          NONE         disabled    15445    165       0        


Endpoint ID: 625
Path: /sys/fs/bpf/tc/globals/cilium_policy_00625

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 908
Path: /sys/fs/bpf/tc/globals/cilium_policy_00908

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112312   1287      0        
Allow    Egress      0          ANY          NONE         disabled    16536    178       0        


Endpoint ID: 1319
Path: /sys/fs/bpf/tc/globals/cilium_policy_01319

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11349586   111382    0        
Allow    Ingress     1          ANY          NONE         disabled    8934465    93177     0        
Allow    Egress      0          ANY          NONE         disabled    11272160   112055    0        


Endpoint ID: 2968
Path: /sys/fs/bpf/tc/globals/cilium_policy_02968

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1658647   20924     0        
Allow    Ingress     1          ANY          NONE         disabled    16876     197       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


