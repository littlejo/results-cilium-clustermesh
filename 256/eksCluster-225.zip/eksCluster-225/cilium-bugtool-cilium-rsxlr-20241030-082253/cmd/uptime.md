 08:22:55 up 28 min,  0 users,  load average: 0.32, 0.23, 0.17
