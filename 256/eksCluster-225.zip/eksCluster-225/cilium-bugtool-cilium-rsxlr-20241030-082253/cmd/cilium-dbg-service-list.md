ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.238.140:443 (active)   
                                        2 => 172.31.189.179:443 (active)   
2    10.100.92.144:443   ClusterIP      1 => 172.31.212.55:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.225.0.242:53 (active)      
                                        2 => 10.225.0.110:53 (active)      
4    10.100.0.10:9153    ClusterIP      1 => 10.225.0.242:9153 (active)    
                                        2 => 10.225.0.110:9153 (active)    
5    10.100.169.3:2379   ClusterIP      1 => 10.225.0.238:2379 (active)    
