{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:38.658Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.212.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:38.658Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.237.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:38.658Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:43.310Z",
  "value": "id=2968  sec_id=4     flags=0x0000 ifindex=10  mac=32:E5:7E:E0:18:89 nodemac=12:8A:F6:A9:A2:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:43.316Z",
  "value": "id=908   sec_id=7426220 flags=0x0000 ifindex=12  mac=26:F8:4C:BD:89:A1 nodemac=CA:6D:70:F1:94:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:43.378Z",
  "value": "id=541   sec_id=7426220 flags=0x0000 ifindex=14  mac=3E:6A:62:2E:42:F9 nodemac=BA:51:AE:DF:D5:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:43.460Z",
  "value": "id=2968  sec_id=4     flags=0x0000 ifindex=10  mac=32:E5:7E:E0:18:89 nodemac=12:8A:F6:A9:A2:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:43.539Z",
  "value": "id=908   sec_id=7426220 flags=0x0000 ifindex=12  mac=26:F8:4C:BD:89:A1 nodemac=CA:6D:70:F1:94:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:40.639Z",
  "value": "id=2968  sec_id=4     flags=0x0000 ifindex=10  mac=32:E5:7E:E0:18:89 nodemac=12:8A:F6:A9:A2:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:40.639Z",
  "value": "id=908   sec_id=7426220 flags=0x0000 ifindex=12  mac=26:F8:4C:BD:89:A1 nodemac=CA:6D:70:F1:94:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:40.640Z",
  "value": "id=541   sec_id=7426220 flags=0x0000 ifindex=14  mac=3E:6A:62:2E:42:F9 nodemac=BA:51:AE:DF:D5:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:40.669Z",
  "value": "id=126   sec_id=7431803 flags=0x0000 ifindex=16  mac=D2:DA:BA:D3:32:32 nodemac=76:DB:B2:33:D2:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:40.670Z",
  "value": "id=126   sec_id=7431803 flags=0x0000 ifindex=16  mac=D2:DA:BA:D3:32:32 nodemac=76:DB:B2:33:D2:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:07.153Z",
  "value": "id=1319  sec_id=7431803 flags=0x0000 ifindex=18  mac=22:77:CE:E4:40:DA nodemac=8E:2D:45:B4:26:2E"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.225.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.646Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:13.432Z",
  "value": "id=541   sec_id=7426220 flags=0x0000 ifindex=14  mac=3E:6A:62:2E:42:F9 nodemac=BA:51:AE:DF:D5:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:13.435Z",
  "value": "id=1319  sec_id=7431803 flags=0x0000 ifindex=18  mac=22:77:CE:E4:40:DA nodemac=8E:2D:45:B4:26:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:13.436Z",
  "value": "id=2968  sec_id=4     flags=0x0000 ifindex=10  mac=32:E5:7E:E0:18:89 nodemac=12:8A:F6:A9:A2:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:13.437Z",
  "value": "id=908   sec_id=7426220 flags=0x0000 ifindex=12  mac=26:F8:4C:BD:89:A1 nodemac=CA:6D:70:F1:94:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:14.321Z",
  "value": "id=2968  sec_id=4     flags=0x0000 ifindex=10  mac=32:E5:7E:E0:18:89 nodemac=12:8A:F6:A9:A2:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:14.321Z",
  "value": "id=541   sec_id=7426220 flags=0x0000 ifindex=14  mac=3E:6A:62:2E:42:F9 nodemac=BA:51:AE:DF:D5:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:14.321Z",
  "value": "id=1319  sec_id=7431803 flags=0x0000 ifindex=18  mac=22:77:CE:E4:40:DA nodemac=8E:2D:45:B4:26:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:14.322Z",
  "value": "id=908   sec_id=7426220 flags=0x0000 ifindex=12  mac=26:F8:4C:BD:89:A1 nodemac=CA:6D:70:F1:94:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:15.321Z",
  "value": "id=541   sec_id=7426220 flags=0x0000 ifindex=14  mac=3E:6A:62:2E:42:F9 nodemac=BA:51:AE:DF:D5:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:15.322Z",
  "value": "id=1319  sec_id=7431803 flags=0x0000 ifindex=18  mac=22:77:CE:E4:40:DA nodemac=8E:2D:45:B4:26:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:15.322Z",
  "value": "id=2968  sec_id=4     flags=0x0000 ifindex=10  mac=32:E5:7E:E0:18:89 nodemac=12:8A:F6:A9:A2:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:15.322Z",
  "value": "id=908   sec_id=7426220 flags=0x0000 ifindex=12  mac=26:F8:4C:BD:89:A1 nodemac=CA:6D:70:F1:94:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:16.322Z",
  "value": "id=1319  sec_id=7431803 flags=0x0000 ifindex=18  mac=22:77:CE:E4:40:DA nodemac=8E:2D:45:B4:26:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:16.322Z",
  "value": "id=908   sec_id=7426220 flags=0x0000 ifindex=12  mac=26:F8:4C:BD:89:A1 nodemac=CA:6D:70:F1:94:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:16.322Z",
  "value": "id=2968  sec_id=4     flags=0x0000 ifindex=10  mac=32:E5:7E:E0:18:89 nodemac=12:8A:F6:A9:A2:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.225.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:16.322Z",
  "value": "id=541   sec_id=7426220 flags=0x0000 ifindex=14  mac=3E:6A:62:2E:42:F9 nodemac=BA:51:AE:DF:D5:B4"
}

