1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:af:09:92:af:3d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.129.213/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3291sec preferred_lft 3291sec
    inet6 fe80::4af:9ff:fe92:af3d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:bf:04:af:ca:ef brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.189.190/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4bf:4ff:feaf:caef/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:2b:01:97:f9:ce brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ac2b:1ff:fe97:f9ce/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:c3:88:13:73:1b brd ff:ff:ff:ff:ff:ff
    inet 10.42.0.108/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c3:88ff:fe13:731b/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 2a:c9:45:91:1f:5c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::28c9:45ff:fe91:1f5c/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:c4:40:ac:2d:98 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a0c4:40ff:feac:2d98/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcc629658d67ea@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:b9:a9:4d:2e:08 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::70b9:a9ff:fe4d:2e08/64 scope link 
       valid_lft forever preferred_lft forever
14: lxca1efed512740@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:e6:0e:d0:95:ef brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e6:eff:fed0:95ef/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc12619066a5b6@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:e7:41:64:2a:48 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c4e7:41ff:fe64:2a48/64 scope link 
       valid_lft forever preferred_lft forever
