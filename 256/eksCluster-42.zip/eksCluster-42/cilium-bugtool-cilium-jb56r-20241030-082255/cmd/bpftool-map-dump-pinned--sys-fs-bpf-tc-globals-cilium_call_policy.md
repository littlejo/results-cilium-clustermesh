key: 44 00 00 00  value: 1b 02 00 00
key: 00 01 00 00  value: 3f 02 00 00
key: a5 01 00 00  value: 85 02 00 00
key: 99 0a 00 00  value: 40 02 00 00
Found 4 elements
