KEY             VALUE
AgentLiveness   2149326358967
UTimeOffset     3379442302734375
