REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35673     2817836     677    bpf_overlay.c
Interface                 INGRESS     627610    130390870   1132   bpf_host.c
Success                   EGRESS      15348     1203130     1694   bpf_host.c
Success                   EGRESS      263085    33333839    1308   bpf_lxc.c
Success                   EGRESS      35088     2777012     53     encap.h
Success                   INGRESS     304754    34306099    86     l3.h
Success                   INGRESS     325730    35964851    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
