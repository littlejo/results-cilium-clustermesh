alloc: 195.14MB (204614232 bytes)
total-alloc: 2.25GB (2416797848 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 63098993
frees: 61115537
heap-alloc: 195.14MB (204614232 bytes)
heap-sys: 251.66MB (263888896 bytes)
heap-idle: 31.48MB (33013760 bytes)
heap-in-use: 220.18MB (230875136 bytes)
heap-released: 1.51MB (1581056 bytes)
heap-objects: 1983456
stack-in-use: 64.31MB (67436544 bytes)
stack-sys: 64.31MB (67436544 bytes)
stack-mspan-inuse: 3.35MB (3514880 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 985.01KB (1008649 bytes)
gc-sys: 6.02MB (6309424 bytes)
next-gc: when heap-alloc >= 227.97MB (239045192 bytes)
last-gc: 2024-10-30 08:22:57.33412546 +0000 UTC
gc-pause-total: 9.595584ms
gc-pause: 172072
gc-pause-end: 1730276577334125460
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0003750803669622698
enable-gc: true
debug-gc: false
