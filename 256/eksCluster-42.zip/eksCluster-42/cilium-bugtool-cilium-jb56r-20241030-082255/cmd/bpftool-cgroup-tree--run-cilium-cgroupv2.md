CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e3f48ba_0eb7_438a_8565_f22ec036f415.slice/cri-containerd-2eea59616746fe327285bef647702ee93023239b8fa37851cbdcc62faab78e28.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e3f48ba_0eb7_438a_8565_f22ec036f415.slice/cri-containerd-3c75eaf124abbd81609f24055762e443fdaa3ea89b916f40408cf228a4c1e2bf.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod00a46d7e_c5fa_4038_81c9_f257df286f11.slice/cri-containerd-72f72b80ffc3d8b8e7339d26e7cdc5bb0b82ae517d3a2cd480926ff6bf981c89.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod00a46d7e_c5fa_4038_81c9_f257df286f11.slice/cri-containerd-8eae3b81a933192d7a1d3a2e4ded9f541cd1f83eefb96a6ab04b09c633456b80.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod144e430c_78d5_4f52_9c4a_631ac4a7b40a.slice/cri-containerd-33da1ea5d6eb4859801a4682dba8d1b8898d0cb4d3029cdc14b5a11d89f292b1.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod144e430c_78d5_4f52_9c4a_631ac4a7b40a.slice/cri-containerd-8ed5594aa889c480f402d12337f86886cbcabf7d8cc88310bb50d5d2314adbfd.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f18ae7b_e141_4ea6_9b38_0dbeeb3322cc.slice/cri-containerd-554a075ca512822b9b4cc417b5b3e962ad0a76ffd83b516546877364d95b2984.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f18ae7b_e141_4ea6_9b38_0dbeeb3322cc.slice/cri-containerd-ce81cea38e1c8c4145a59dce91a8e6f0a1a2a82463ce3a3bc9466dcd37db00d2.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod875eea67_2dbb_4b03_af91_9229283349ab.slice/cri-containerd-d0981c43d89882f856988b4cd7a8d42824c5c9d8715b780ea0feba09bb630ac4.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod875eea67_2dbb_4b03_af91_9229283349ab.slice/cri-containerd-1ea7a4149c8952bf26efe12444691e86ea13ca13ac65ca584b836921ad40b8d0.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde50ebdb_310e_4d0f_8a16_cdb78d486d6e.slice/cri-containerd-d67b58e35cba7f65bfcbce2245a57c13b08bbf7edfb3bc4bade4c7310ca38a22.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde50ebdb_310e_4d0f_8a16_cdb78d486d6e.slice/cri-containerd-d3e56decca659bf76a88032d1ed87d56451f2ee1ea069bd075b26704c2b1961a.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod421f349a_7803_421b_a87d_aabea454d3c5.slice/cri-containerd-6771068f05a869b780101d66c8d5b11ef46fba745ba879eaa7f064c381751f75.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod421f349a_7803_421b_a87d_aabea454d3c5.slice/cri-containerd-adeee47db77efc3b1020779ff896ffd3a4d7b53517e0bed867a2449f30b0a10d.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod421f349a_7803_421b_a87d_aabea454d3c5.slice/cri-containerd-9d0f96e7e6a481427bb817e58479fc51757ab5b884a66e10755ce1bba9dcdf89.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod421f349a_7803_421b_a87d_aabea454d3c5.slice/cri-containerd-0ab2c87e9bf00b076002302beef3b12029bb637afd649d1c090072862bc54c4a.scope
    681      cgroup_device   multi                                          
