[
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod421f349a_7803_421b_a87d_aabea454d3c5.slice/cri-containerd-9d0f96e7e6a481427bb817e58479fc51757ab5b884a66e10755ce1bba9dcdf89.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod421f349a_7803_421b_a87d_aabea454d3c5.slice/cri-containerd-6771068f05a869b780101d66c8d5b11ef46fba745ba879eaa7f064c381751f75.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod421f349a_7803_421b_a87d_aabea454d3c5.slice/cri-containerd-0ab2c87e9bf00b076002302beef3b12029bb637afd649d1c090072862bc54c4a.scope"
      }
    ],
    "ips": [
      "10.42.0.126"
    ],
    "name": "clustermesh-apiserver-87dd4999-2zftm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7751,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f18ae7b_e141_4ea6_9b38_0dbeeb3322cc.slice/cri-containerd-ce81cea38e1c8c4145a59dce91a8e6f0a1a2a82463ce3a3bc9466dcd37db00d2.scope"
      }
    ],
    "ips": [
      "10.42.0.94"
    ],
    "name": "coredns-cc6ccd49c-c2m7n",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7835,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod00a46d7e_c5fa_4038_81c9_f257df286f11.slice/cri-containerd-72f72b80ffc3d8b8e7339d26e7cdc5bb0b82ae517d3a2cd480926ff6bf981c89.scope"
      }
    ],
    "ips": [
      "10.42.0.174"
    ],
    "name": "coredns-cc6ccd49c-d4wkj",
    "namespace": "kube-system"
  }
]

