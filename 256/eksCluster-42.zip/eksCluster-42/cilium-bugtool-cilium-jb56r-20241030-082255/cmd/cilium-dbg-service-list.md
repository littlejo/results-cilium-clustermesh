ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.135.211:443 (active)    
                                         2 => 172.31.194.154:443 (active)    
2    10.100.198.69:443    ClusterIP      1 => 172.31.129.213:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.42.0.174:53 (active)        
                                         2 => 10.42.0.94:53 (active)         
4    10.100.0.10:9153     ClusterIP      1 => 10.42.0.174:9153 (active)      
                                         2 => 10.42.0.94:9153 (active)       
5    10.100.86.210:2379   ClusterIP      1 => 10.42.0.126:2379 (active)      
