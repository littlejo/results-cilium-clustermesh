USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         693  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         665  0.0  0.2 1240432 16356 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         708  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         709  0.0  0.2 1240432 16356 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         656  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.0  4.7 1606080 381448 ?      Ssl  07:54   0:51 cilium-agent --config-dir=/tmp/cilium/config-map
root         404  0.0  0.0 1229744 6804 ?        Sl   07:54   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
