xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 562
ens6(5) clsact/ingress cil_from_netdev-ens6 id 569
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 552
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 547
cilium_host(7) clsact/egress cil_from_host-cilium_host id 543
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 581
lxcc629658d67ea(12) clsact/ingress cil_from_container-lxcc629658d67ea id 520
lxca1efed512740(14) clsact/ingress cil_from_container-lxca1efed512740 id 560
lxc12619066a5b6(18) clsact/ingress cil_from_container-lxc12619066a5b6 id 643

flow_dissector:

netfilter:

