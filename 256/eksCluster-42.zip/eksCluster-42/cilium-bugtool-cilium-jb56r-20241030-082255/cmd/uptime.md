 08:22:56 up 35 min,  0 users,  load average: 0.13, 0.21, 0.18
