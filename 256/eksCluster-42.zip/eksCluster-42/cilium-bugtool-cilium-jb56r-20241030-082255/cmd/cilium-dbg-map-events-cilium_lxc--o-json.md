{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:47.763Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.129.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:47.763Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.189.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:47.763Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:52.296Z",
  "value": "id=2713  sec_id=4     flags=0x0000 ifindex=10  mac=AE:77:FC:2C:54:E8 nodemac=A2:C4:40:AC:2D:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:52.312Z",
  "value": "id=68    sec_id=1440326 flags=0x0000 ifindex=12  mac=1E:EC:50:4A:37:03 nodemac=72:B9:A9:4D:2E:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:52.369Z",
  "value": "id=256   sec_id=1440326 flags=0x0000 ifindex=14  mac=6E:D2:B2:E2:1D:A1 nodemac=02:E6:0E:D0:95:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:52.403Z",
  "value": "id=2713  sec_id=4     flags=0x0000 ifindex=10  mac=AE:77:FC:2C:54:E8 nodemac=A2:C4:40:AC:2D:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:01.058Z",
  "value": "id=2713  sec_id=4     flags=0x0000 ifindex=10  mac=AE:77:FC:2C:54:E8 nodemac=A2:C4:40:AC:2D:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:01.059Z",
  "value": "id=68    sec_id=1440326 flags=0x0000 ifindex=12  mac=1E:EC:50:4A:37:03 nodemac=72:B9:A9:4D:2E:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:01.060Z",
  "value": "id=256   sec_id=1440326 flags=0x0000 ifindex=14  mac=6E:D2:B2:E2:1D:A1 nodemac=02:E6:0E:D0:95:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:01.090Z",
  "value": "id=50    sec_id=1425195 flags=0x0000 ifindex=16  mac=46:52:A3:E5:FF:91 nodemac=A2:9C:6B:76:0C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:02.058Z",
  "value": "id=50    sec_id=1425195 flags=0x0000 ifindex=16  mac=46:52:A3:E5:FF:91 nodemac=A2:9C:6B:76:0C:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:02.058Z",
  "value": "id=256   sec_id=1440326 flags=0x0000 ifindex=14  mac=6E:D2:B2:E2:1D:A1 nodemac=02:E6:0E:D0:95:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:02.058Z",
  "value": "id=2713  sec_id=4     flags=0x0000 ifindex=10  mac=AE:77:FC:2C:54:E8 nodemac=A2:C4:40:AC:2D:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:02.058Z",
  "value": "id=68    sec_id=1440326 flags=0x0000 ifindex=12  mac=1E:EC:50:4A:37:03 nodemac=72:B9:A9:4D:2E:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.195Z",
  "value": "id=421   sec_id=1425195 flags=0x0000 ifindex=18  mac=9E:B7:8F:36:56:6B nodemac=C6:E7:41:64:2A:48"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.42.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.614Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.468Z",
  "value": "id=256   sec_id=1440326 flags=0x0000 ifindex=14  mac=6E:D2:B2:E2:1D:A1 nodemac=02:E6:0E:D0:95:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.468Z",
  "value": "id=421   sec_id=1425195 flags=0x0000 ifindex=18  mac=9E:B7:8F:36:56:6B nodemac=C6:E7:41:64:2A:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.469Z",
  "value": "id=2713  sec_id=4     flags=0x0000 ifindex=10  mac=AE:77:FC:2C:54:E8 nodemac=A2:C4:40:AC:2D:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.469Z",
  "value": "id=68    sec_id=1440326 flags=0x0000 ifindex=12  mac=1E:EC:50:4A:37:03 nodemac=72:B9:A9:4D:2E:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.461Z",
  "value": "id=256   sec_id=1440326 flags=0x0000 ifindex=14  mac=6E:D2:B2:E2:1D:A1 nodemac=02:E6:0E:D0:95:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.461Z",
  "value": "id=421   sec_id=1425195 flags=0x0000 ifindex=18  mac=9E:B7:8F:36:56:6B nodemac=C6:E7:41:64:2A:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.464Z",
  "value": "id=2713  sec_id=4     flags=0x0000 ifindex=10  mac=AE:77:FC:2C:54:E8 nodemac=A2:C4:40:AC:2D:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.466Z",
  "value": "id=68    sec_id=1440326 flags=0x0000 ifindex=12  mac=1E:EC:50:4A:37:03 nodemac=72:B9:A9:4D:2E:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.460Z",
  "value": "id=421   sec_id=1425195 flags=0x0000 ifindex=18  mac=9E:B7:8F:36:56:6B nodemac=C6:E7:41:64:2A:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.460Z",
  "value": "id=2713  sec_id=4     flags=0x0000 ifindex=10  mac=AE:77:FC:2C:54:E8 nodemac=A2:C4:40:AC:2D:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.461Z",
  "value": "id=68    sec_id=1440326 flags=0x0000 ifindex=12  mac=1E:EC:50:4A:37:03 nodemac=72:B9:A9:4D:2E:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.461Z",
  "value": "id=256   sec_id=1440326 flags=0x0000 ifindex=14  mac=6E:D2:B2:E2:1D:A1 nodemac=02:E6:0E:D0:95:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.461Z",
  "value": "id=2713  sec_id=4     flags=0x0000 ifindex=10  mac=AE:77:FC:2C:54:E8 nodemac=A2:C4:40:AC:2D:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.461Z",
  "value": "id=421   sec_id=1425195 flags=0x0000 ifindex=18  mac=9E:B7:8F:36:56:6B nodemac=C6:E7:41:64:2A:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.462Z",
  "value": "id=68    sec_id=1440326 flags=0x0000 ifindex=12  mac=1E:EC:50:4A:37:03 nodemac=72:B9:A9:4D:2E:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.462Z",
  "value": "id=256   sec_id=1440326 flags=0x0000 ifindex=14  mac=6E:D2:B2:E2:1D:A1 nodemac=02:E6:0E:D0:95:EF"
}

