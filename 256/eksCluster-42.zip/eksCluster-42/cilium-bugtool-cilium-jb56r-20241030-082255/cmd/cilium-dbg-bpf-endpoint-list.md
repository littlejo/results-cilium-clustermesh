IP ADDRESS         LOCAL ENDPOINT INFO
10.42.0.174:0      id=256   sec_id=1440326 flags=0x0000 ifindex=14  mac=6E:D2:B2:E2:1D:A1 nodemac=02:E6:0E:D0:95:EF   
10.42.0.126:0      id=421   sec_id=1425195 flags=0x0000 ifindex=18  mac=9E:B7:8F:36:56:6B nodemac=C6:E7:41:64:2A:48   
172.31.129.213:0   (localhost)                                                                                        
10.42.0.94:0       id=68    sec_id=1440326 flags=0x0000 ifindex=12  mac=1E:EC:50:4A:37:03 nodemac=72:B9:A9:4D:2E:08   
10.42.0.221:0      id=2713  sec_id=4     flags=0x0000 ifindex=10  mac=AE:77:FC:2C:54:E8 nodemac=A2:C4:40:AC:2D:98     
10.42.0.108:0      (localhost)                                                                                        
172.31.189.190:0   (localhost)                                                                                        
