Endpoint ID: 3
Path: /sys/fs/bpf/tc/globals/cilium_policy_00003

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 68
Path: /sys/fs/bpf/tc/globals/cilium_policy_00068

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    165286   1906      0        
Allow    Egress      0          ANY          NONE         disabled    20968    235       0        


Endpoint ID: 256
Path: /sys/fs/bpf/tc/globals/cilium_policy_00256

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    164965   1896      0        
Allow    Egress      0          ANY          NONE         disabled    21927    247       0        


Endpoint ID: 421
Path: /sys/fs/bpf/tc/globals/cilium_policy_00421

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11431033   112869    0        
Allow    Ingress     1          ANY          NONE         disabled    9386769    98305     0        
Allow    Egress      0          ANY          NONE         disabled    11816278   116718    0        


Endpoint ID: 2713
Path: /sys/fs/bpf/tc/globals/cilium_policy_02713

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1664320   21043     0        
Allow    Ingress     1          ANY          NONE         disabled    24896     292       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


