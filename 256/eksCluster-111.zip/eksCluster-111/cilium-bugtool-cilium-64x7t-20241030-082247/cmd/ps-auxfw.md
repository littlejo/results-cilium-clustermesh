USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         707  0.0  0.0 1228744 3780 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         701  0.0  0.2 1240432 16588 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         737  0.0  0.0   6408  1648 ?        R    08:22   0:00  \_ ps auxfw
root         739  0.0  0.2 1240432 16588 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         695  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         689  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         683  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  2.5  4.7 1606144 377304 ?      Ssl  07:56   0:40 cilium-agent --config-dir=/tmp/cilium/config-map
root         416  0.0  0.1 1229744 8328 ?        Sl   07:56   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
