[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c5813ac_6b9f_4883_8e3d_3d0e580a0be1.slice/cri-containerd-3709382439e2ca639c6b37641d46d3a8a7703364757a8939e28fc3dbd8cc627b.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c5813ac_6b9f_4883_8e3d_3d0e580a0be1.slice/cri-containerd-b7aacd228571757ec6e4a60561bf57fd45aa058d8838a2adafcc0d40e1208619.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c5813ac_6b9f_4883_8e3d_3d0e580a0be1.slice/cri-containerd-4f2104da45dd079ddbf1a1241c8e761e2a489c3d0914b9fb9db8834ddca2b1ea.scope"
      }
    ],
    "ips": [
      "10.111.0.68"
    ],
    "name": "clustermesh-apiserver-689fb97fb4-8mdd2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7614,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod477ebafd_31e4_4f2c_9cf3_2b989b2d4c21.slice/cri-containerd-c75319a0f9aa9090d92cbf521680ebc73c63575e454821bb86ea8cd5ba5c0499.scope"
      }
    ],
    "ips": [
      "10.111.0.177"
    ],
    "name": "coredns-cc6ccd49c-c8nsw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf1fd14e9_268e_4b00_a537_df10f6d14be7.slice/cri-containerd-a2e007277eaac722106fab458edc84e640c563079d675158b5e23d1234c8b647.scope"
      }
    ],
    "ips": [
      "10.111.0.127"
    ],
    "name": "coredns-cc6ccd49c-ffq4j",
    "namespace": "kube-system"
  }
]

