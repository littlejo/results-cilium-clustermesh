key: cf 00 00 00  value: 30 02 00 00
key: 7e 01 00 00  value: 1d 02 00 00
key: b8 01 00 00  value: 85 02 00 00
key: 69 08 00 00  value: 16 02 00 00
Found 4 elements
