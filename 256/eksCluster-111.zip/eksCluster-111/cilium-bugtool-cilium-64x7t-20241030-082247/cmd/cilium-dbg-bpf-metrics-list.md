REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     33927     2682076     677    bpf_overlay.c
Interface                 INGRESS     611381    128444742   1132   bpf_host.c
Success                   EGRESS      13894     1086945     1694   bpf_host.c
Success                   EGRESS      256813    32729223    1308   bpf_lxc.c
Success                   EGRESS      32727     2593226     53     encap.h
Success                   INGRESS     295687    33310678    86     l3.h
Success                   INGRESS     316244    34940457    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
