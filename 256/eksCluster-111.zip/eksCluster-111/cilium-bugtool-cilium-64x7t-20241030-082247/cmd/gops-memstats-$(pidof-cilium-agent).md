alloc: 163.57MB (171514688 bytes)
total-alloc: 2.17GB (2332471328 bytes)
sys: 324.83MB (340611428 bytes)
lookups: 0
mallocs: 62046327
frees: 60153664
heap-alloc: 163.57MB (171514688 bytes)
heap-sys: 247.48MB (259497984 bytes)
heap-idle: 61.19MB (64159744 bytes)
heap-in-use: 186.29MB (195338240 bytes)
heap-released: 6.08MB (6373376 bytes)
heap-objects: 1892663
stack-in-use: 64.50MB (67633152 bytes)
stack-sys: 64.50MB (67633152 bytes)
stack-mspan-inuse: 3.18MB (3329760 bytes)
stack-mspan-sys: 3.77MB (3949440 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.06MB (1114089 bytes)
gc-sys: 6.06MB (6352336 bytes)
next-gc: when heap-alloc >= 214.30MB (224713848 bytes)
last-gc: 2024-10-30 08:22:49.98653496 +0000 UTC
gc-pause-total: 20.259898ms
gc-pause: 65354
gc-pause-end: 1730276569986534960
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.0003954837542611018
enable-gc: true
debug-gc: false
