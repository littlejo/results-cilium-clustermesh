IP ADDRESS         LOCAL ENDPOINT INFO
10.111.0.127:0     id=207   sec_id=3679902 flags=0x0000 ifindex=14  mac=DA:AC:1B:2B:84:29 nodemac=3A:3F:FA:1D:B1:66   
10.111.0.155:0     (localhost)                                                                                        
10.111.0.228:0     id=382   sec_id=4     flags=0x0000 ifindex=10  mac=2A:34:B7:14:D6:DE nodemac=D6:23:75:A0:54:AF     
10.111.0.177:0     id=2153  sec_id=3679902 flags=0x0000 ifindex=12  mac=8E:7D:64:95:36:1D nodemac=5A:B2:BC:5B:65:CF   
172.31.230.30:0    (localhost)                                                                                        
10.111.0.68:0      id=440   sec_id=3670776 flags=0x0000 ifindex=18  mac=F2:3B:1B:28:1C:60 nodemac=4E:4F:B8:CA:AD:41   
172.31.199.216:0   (localhost)                                                                                        
