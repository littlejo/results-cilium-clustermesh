CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod477ebafd_31e4_4f2c_9cf3_2b989b2d4c21.slice/cri-containerd-9fe3ad54e96b8378230af9b97a5ab965a7f23c8c8d8fe4509bdb51b2770d0a0f.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod477ebafd_31e4_4f2c_9cf3_2b989b2d4c21.slice/cri-containerd-c75319a0f9aa9090d92cbf521680ebc73c63575e454821bb86ea8cd5ba5c0499.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf21c8e6b_2858_4cda_a31a_7f838decc0c1.slice/cri-containerd-efe82d55d59f528b258c4c271195c483591210c647310086afc388f76ed6f394.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf21c8e6b_2858_4cda_a31a_7f838decc0c1.slice/cri-containerd-fb47797bdfafeead08e901c2141eb3f9eb415bc5c3d1b5076aef38f2c3a882bb.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod484a6b12_d524_4ce6_9ff5_f91cc0fd838a.slice/cri-containerd-4ad915c52c9e83ead1e61ca143ca819f67c0763dd46f390660633d567f8272da.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod484a6b12_d524_4ce6_9ff5_f91cc0fd838a.slice/cri-containerd-e7587bfefe8312ac5459c848ea330e8d8daa207b056178a5c12ec61edfbcc125.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf1fd14e9_268e_4b00_a537_df10f6d14be7.slice/cri-containerd-aea8e96bcbc38c3d421c87754b2d41b7e7a2afa8a68769541514a78c783465d6.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf1fd14e9_268e_4b00_a537_df10f6d14be7.slice/cri-containerd-a2e007277eaac722106fab458edc84e640c563079d675158b5e23d1234c8b647.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b44861e_f460_482d_8960_bfce1dbf24d8.slice/cri-containerd-22b113a44b5bf2e54b33594332e2edc2c3aa3e949a9e06bec428008d98f43553.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b44861e_f460_482d_8960_bfce1dbf24d8.slice/cri-containerd-2e40b39187d5b507da5af75d8ee7729f4b01002a793dfd9ea0a167a93c525bf4.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb25454b8_3932_422a_b040_63a8260158f7.slice/cri-containerd-88e05f2c280b9de65f51c1a950edcdea70d56b6329ad7657f6b9e32ae60a8472.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb25454b8_3932_422a_b040_63a8260158f7.slice/cri-containerd-5adc71d4b2d0b33cbd90c066337be53e7ba6aa4b7b55961814d8df675acb7dc8.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c5813ac_6b9f_4883_8e3d_3d0e580a0be1.slice/cri-containerd-4f2104da45dd079ddbf1a1241c8e761e2a489c3d0914b9fb9db8834ddca2b1ea.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c5813ac_6b9f_4883_8e3d_3d0e580a0be1.slice/cri-containerd-b7aacd228571757ec6e4a60561bf57fd45aa058d8838a2adafcc0d40e1208619.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c5813ac_6b9f_4883_8e3d_3d0e580a0be1.slice/cri-containerd-25e851b4113c4921369465ddfdd37fa0d96364e34fc51b8adb23a22970b6d171.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c5813ac_6b9f_4883_8e3d_3d0e580a0be1.slice/cri-containerd-3709382439e2ca639c6b37641d46d3a8a7703364757a8939e28fc3dbd8cc627b.scope
    671      cgroup_device   multi                                          
