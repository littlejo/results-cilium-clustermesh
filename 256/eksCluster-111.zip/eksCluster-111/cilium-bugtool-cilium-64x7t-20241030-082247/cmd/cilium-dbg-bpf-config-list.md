KEY             VALUE
AgentLiveness   2104680133052
UTimeOffset     3379442373046875
