ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.164.79:443 (active)     
                                          2 => 172.31.205.178:443 (active)    
2    10.100.124.5:443      ClusterIP      1 => 172.31.199.216:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.111.0.177:53 (active)       
                                          2 => 10.111.0.127:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.111.0.177:9153 (active)     
                                          2 => 10.111.0.127:9153 (active)     
5    10.100.189.184:2379   ClusterIP      1 => 10.111.0.68:2379 (active)      
