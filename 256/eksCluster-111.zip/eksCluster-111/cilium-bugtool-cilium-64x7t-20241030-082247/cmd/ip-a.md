1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:89:00:1c:39:53 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.199.216/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3336sec preferred_lft 3336sec
    inet6 fe80::889:ff:fe1c:3953/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:26:4c:89:51:a9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.230.30/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::826:4cff:fe89:51a9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:df:f2:10:be:dd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2cdf:f2ff:fe10:bedd/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:b4:f1:96:4f:ed brd ff:ff:ff:ff:ff:ff
    inet 10.111.0.155/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::38b4:f1ff:fe96:4fed/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 4e:a2:91:ec:dc:dd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4ca2:91ff:feec:dcdd/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:23:75:a0:54:af brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d423:75ff:fea0:54af/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb3b213313dcc@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:b2:bc:5b:65:cf brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::58b2:bcff:fe5b:65cf/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc8e0ad3521fe7@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:3f:fa:1d:b1:66 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::383f:faff:fe1d:b166/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc440ec10af554@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:4f:b8:ca:ad:41 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::4c4f:b8ff:feca:ad41/64 scope link 
       valid_lft forever preferred_lft forever
