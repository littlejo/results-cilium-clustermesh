top - 08:22:48 up 34 min,  0 users,  load average: 0.06, 0.09, 0.09
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 55.2 us, 31.0 sy,  0.0 ni, 13.8 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4489.2 free,   1179.5 used,   2145.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6449.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606144 383940  77948 S 100.0   4.8   0:40.94 cilium-+
    701 root      20   0 1240432  16588  11484 S   6.7   0.2   0:00.03 cilium-+
    416 root      20   0 1229744   8328   3964 S   0.0   0.1   0:01.08 cilium-+
    683 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    689 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    695 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    707 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
    749 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    750 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    758 root      20   0 1243508  18292  13188 S   0.0   0.2   0:00.00 hubble
    778 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
