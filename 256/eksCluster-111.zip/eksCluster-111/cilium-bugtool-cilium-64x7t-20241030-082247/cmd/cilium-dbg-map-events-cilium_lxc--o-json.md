{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:23.120Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.199.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:23.120Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.230.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:23.120Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:26.285Z",
  "value": "id=2153  sec_id=3679902 flags=0x0000 ifindex=12  mac=8E:7D:64:95:36:1D nodemac=5A:B2:BC:5B:65:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:29.432Z",
  "value": "id=382   sec_id=4     flags=0x0000 ifindex=10  mac=2A:34:B7:14:D6:DE nodemac=D6:23:75:A0:54:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:29.448Z",
  "value": "id=207   sec_id=3679902 flags=0x0000 ifindex=14  mac=DA:AC:1B:2B:84:29 nodemac=3A:3F:FA:1D:B1:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:29.489Z",
  "value": "id=2153  sec_id=3679902 flags=0x0000 ifindex=12  mac=8E:7D:64:95:36:1D nodemac=5A:B2:BC:5B:65:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:29.537Z",
  "value": "id=382   sec_id=4     flags=0x0000 ifindex=10  mac=2A:34:B7:14:D6:DE nodemac=D6:23:75:A0:54:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:29.570Z",
  "value": "id=207   sec_id=3679902 flags=0x0000 ifindex=14  mac=DA:AC:1B:2B:84:29 nodemac=3A:3F:FA:1D:B1:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:11.857Z",
  "value": "id=207   sec_id=3679902 flags=0x0000 ifindex=14  mac=DA:AC:1B:2B:84:29 nodemac=3A:3F:FA:1D:B1:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:11.857Z",
  "value": "id=382   sec_id=4     flags=0x0000 ifindex=10  mac=2A:34:B7:14:D6:DE nodemac=D6:23:75:A0:54:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:11.858Z",
  "value": "id=2153  sec_id=3679902 flags=0x0000 ifindex=12  mac=8E:7D:64:95:36:1D nodemac=5A:B2:BC:5B:65:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:11.887Z",
  "value": "id=364   sec_id=3670776 flags=0x0000 ifindex=16  mac=AA:54:4E:EC:39:27 nodemac=82:28:16:34:21:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:11.887Z",
  "value": "id=364   sec_id=3670776 flags=0x0000 ifindex=16  mac=AA:54:4E:EC:39:27 nodemac=82:28:16:34:21:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.277Z",
  "value": "id=440   sec_id=3670776 flags=0x0000 ifindex=18  mac=F2:3B:1B:28:1C:60 nodemac=4E:4F:B8:CA:AD:41"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.111.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.641Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:16.902Z",
  "value": "id=2153  sec_id=3679902 flags=0x0000 ifindex=12  mac=8E:7D:64:95:36:1D nodemac=5A:B2:BC:5B:65:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:16.903Z",
  "value": "id=207   sec_id=3679902 flags=0x0000 ifindex=14  mac=DA:AC:1B:2B:84:29 nodemac=3A:3F:FA:1D:B1:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:16.903Z",
  "value": "id=382   sec_id=4     flags=0x0000 ifindex=10  mac=2A:34:B7:14:D6:DE nodemac=D6:23:75:A0:54:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:16.903Z",
  "value": "id=440   sec_id=3670776 flags=0x0000 ifindex=18  mac=F2:3B:1B:28:1C:60 nodemac=4E:4F:B8:CA:AD:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:17.926Z",
  "value": "id=440   sec_id=3670776 flags=0x0000 ifindex=18  mac=F2:3B:1B:28:1C:60 nodemac=4E:4F:B8:CA:AD:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:17.940Z",
  "value": "id=2153  sec_id=3679902 flags=0x0000 ifindex=12  mac=8E:7D:64:95:36:1D nodemac=5A:B2:BC:5B:65:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:17.941Z",
  "value": "id=207   sec_id=3679902 flags=0x0000 ifindex=14  mac=DA:AC:1B:2B:84:29 nodemac=3A:3F:FA:1D:B1:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:17.941Z",
  "value": "id=382   sec_id=4     flags=0x0000 ifindex=10  mac=2A:34:B7:14:D6:DE nodemac=D6:23:75:A0:54:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:18.903Z",
  "value": "id=440   sec_id=3670776 flags=0x0000 ifindex=18  mac=F2:3B:1B:28:1C:60 nodemac=4E:4F:B8:CA:AD:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:18.903Z",
  "value": "id=2153  sec_id=3679902 flags=0x0000 ifindex=12  mac=8E:7D:64:95:36:1D nodemac=5A:B2:BC:5B:65:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:18.904Z",
  "value": "id=207   sec_id=3679902 flags=0x0000 ifindex=14  mac=DA:AC:1B:2B:84:29 nodemac=3A:3F:FA:1D:B1:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:18.904Z",
  "value": "id=382   sec_id=4     flags=0x0000 ifindex=10  mac=2A:34:B7:14:D6:DE nodemac=D6:23:75:A0:54:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:19.903Z",
  "value": "id=382   sec_id=4     flags=0x0000 ifindex=10  mac=2A:34:B7:14:D6:DE nodemac=D6:23:75:A0:54:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:19.904Z",
  "value": "id=2153  sec_id=3679902 flags=0x0000 ifindex=12  mac=8E:7D:64:95:36:1D nodemac=5A:B2:BC:5B:65:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:19.904Z",
  "value": "id=440   sec_id=3670776 flags=0x0000 ifindex=18  mac=F2:3B:1B:28:1C:60 nodemac=4E:4F:B8:CA:AD:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:19.904Z",
  "value": "id=207   sec_id=3679902 flags=0x0000 ifindex=14  mac=DA:AC:1B:2B:84:29 nodemac=3A:3F:FA:1D:B1:66"
}

