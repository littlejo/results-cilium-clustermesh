Endpoint ID: 207
Path: /sys/fs/bpf/tc/globals/cilium_policy_00207

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    154579   1773      0        
Allow    Egress      0          ANY          NONE         disabled    19992    221       0        


Endpoint ID: 382
Path: /sys/fs/bpf/tc/globals/cilium_policy_00382

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1631582   20580     0        
Allow    Ingress     1          ANY          NONE         disabled    22832     266       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 434
Path: /sys/fs/bpf/tc/globals/cilium_policy_00434

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 440
Path: /sys/fs/bpf/tc/globals/cilium_policy_00440

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11288149   110722    0        
Allow    Ingress     1          ANY          NONE         disabled    8789169    91750     0        
Allow    Egress      0          ANY          NONE         disabled    11180968   110909    0        


Endpoint ID: 2153
Path: /sys/fs/bpf/tc/globals/cilium_policy_02153

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    154711   1775      0        
Allow    Egress      0          ANY          NONE         disabled    20463    226       0        


