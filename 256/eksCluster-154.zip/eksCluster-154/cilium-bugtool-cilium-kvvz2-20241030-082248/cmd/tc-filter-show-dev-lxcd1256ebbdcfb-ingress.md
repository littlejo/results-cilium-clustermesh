filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcd1256ebbdcfb direct-action not_in_hw id 513 tag d41478c9c41a2f5e jited 
