CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddf70471b_9c66_4bfa_8ba8_f62b21f0641d.slice/cri-containerd-a794e34fda904d65d0ebb55a863ae3685b24c5aecd5ac7569e8fa5aa1b675f5a.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddf70471b_9c66_4bfa_8ba8_f62b21f0641d.slice/cri-containerd-d6ccbb86a1c08292a87e8f35f009a9906c720b8cbd1e7f3f26401822520f06cf.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod54a84148_e16d_4414_839b_5fff1bd80534.slice/cri-containerd-df7bc2dc1d37da10f41b4ac3007eb83b74945dc167eabe42dbd827a2d1fcba88.scope
    547      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod54a84148_e16d_4414_839b_5fff1bd80534.slice/cri-containerd-acbb1d7457bd4666ebb87a747553014b259cb14fc48f20d9db430dd00ebce929.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a64b418_e4e4_4c95_b53a_b01851e3a12a.slice/cri-containerd-55b504284a1bef03545e1d18b7b6ade92a0d6dde61d3389fbce2b4085e6aa9ca.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a64b418_e4e4_4c95_b53a_b01851e3a12a.slice/cri-containerd-8ae79ed6d531f7e656a2042262601da3c34dc2add683b6dbc840a42638124ad9.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb7cddfde_b205_4208_bb72_ea64cfc761a3.slice/cri-containerd-6bf86226b36ca37cff5008f0309883ade50e6419349325fa1fe2a2a0cc8f076e.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb7cddfde_b205_4208_bb72_ea64cfc761a3.slice/cri-containerd-0d7ca7ddb3a629c440f04ae6f30747307d59fa9adec9357d24e47dd73c68fe69.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb4bf67f2_00f0_45a3_b66c_7d617057a78b.slice/cri-containerd-12db1e4d95e8892931f69e22f3a2a4f5b38d45f784bac139dc28d86e1936c9b3.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb4bf67f2_00f0_45a3_b66c_7d617057a78b.slice/cri-containerd-a1377354937ac11906ec2d01189266ec9385708c50283df7530aeea11e738ef8.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58de768d_731d_4dce_b9d1_479d53c81eb2.slice/cri-containerd-697db9b8fcf324dec09d5514e932ad26a6d81cf5eac50b95c64925e749b9c2af.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58de768d_731d_4dce_b9d1_479d53c81eb2.slice/cri-containerd-9aeb13cd5506e4cdffb0f391c66d1aaf88d9217c1d2ddafcc14f14c793c4b8ef.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58de768d_731d_4dce_b9d1_479d53c81eb2.slice/cri-containerd-01144d3fa99b99465b528f7e01468b18fe594ac0163e69d4431dbd518f4cb3ad.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58de768d_731d_4dce_b9d1_479d53c81eb2.slice/cri-containerd-f28c60cb250a5fe7634627709a4089c0fae3362b492a837ffdda5956d6d0d00b.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15de66a8_4873_4857_b294_d0b0d920e17b.slice/cri-containerd-99e952159ffd4f8ce06244ddc7b0c23a364a385c3589e6c6433f9eaa87b6f265.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15de66a8_4873_4857_b294_d0b0d920e17b.slice/cri-containerd-aef48ebaa2d19a723c465ca0948da4e34efff784af4aca59a090cc1bc09dcc04.scope
    106      cgroup_device   multi                                          
