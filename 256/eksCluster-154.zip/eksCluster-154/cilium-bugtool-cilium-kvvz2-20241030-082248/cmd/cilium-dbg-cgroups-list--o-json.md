[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb7cddfde_b205_4208_bb72_ea64cfc761a3.slice/cri-containerd-0d7ca7ddb3a629c440f04ae6f30747307d59fa9adec9357d24e47dd73c68fe69.scope"
      }
    ],
    "ips": [
      "10.154.0.117"
    ],
    "name": "coredns-cc6ccd49c-nxs75",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58de768d_731d_4dce_b9d1_479d53c81eb2.slice/cri-containerd-697db9b8fcf324dec09d5514e932ad26a6d81cf5eac50b95c64925e749b9c2af.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58de768d_731d_4dce_b9d1_479d53c81eb2.slice/cri-containerd-01144d3fa99b99465b528f7e01468b18fe594ac0163e69d4431dbd518f4cb3ad.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58de768d_731d_4dce_b9d1_479d53c81eb2.slice/cri-containerd-9aeb13cd5506e4cdffb0f391c66d1aaf88d9217c1d2ddafcc14f14c793c4b8ef.scope"
      }
    ],
    "ips": [
      "10.154.0.219"
    ],
    "name": "clustermesh-apiserver-697ff5b65c-rd7mw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod54a84148_e16d_4414_839b_5fff1bd80534.slice/cri-containerd-acbb1d7457bd4666ebb87a747553014b259cb14fc48f20d9db430dd00ebce929.scope"
      }
    ],
    "ips": [
      "10.154.0.53"
    ],
    "name": "coredns-cc6ccd49c-jwwcl",
    "namespace": "kube-system"
  }
]

