Endpoint ID: 1416
Path: /sys/fs/bpf/tc/globals/cilium_policy_01416

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    125122   1438      0        
Allow    Egress      0          ANY          NONE         disabled    17977    196       0        


Endpoint ID: 1667
Path: /sys/fs/bpf/tc/globals/cilium_policy_01667

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    125395   1446      0        
Allow    Egress      0          ANY          NONE         disabled    17578    193       0        


Endpoint ID: 1704
Path: /sys/fs/bpf/tc/globals/cilium_policy_01704

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11582407   116541    0        
Allow    Ingress     1          ANY          NONE         disabled    11743358   121014    0        
Allow    Egress      0          ANY          NONE         disabled    14055624   137706    0        


Endpoint ID: 3361
Path: /sys/fs/bpf/tc/globals/cilium_policy_03361

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3953
Path: /sys/fs/bpf/tc/globals/cilium_policy_03953

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1642280   20766     0        
Allow    Ingress     1          ANY          NONE         disabled    18868     223       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


