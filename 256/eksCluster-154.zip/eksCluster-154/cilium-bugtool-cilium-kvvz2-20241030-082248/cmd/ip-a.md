1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:67:c9:41:5f:75 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.143.150/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3506sec preferred_lft 3506sec
    inet6 fe80::467:c9ff:fe41:5f75/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:75:c8:da:f9:7f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.150.63/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::475:c8ff:feda:f97f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:40:68:28:5c:5e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5840:68ff:fe28:5c5e/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:b3:f6:4f:5d:a1 brd ff:ff:ff:ff:ff:ff
    inet 10.154.0.45/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::5cb3:f6ff:fe4f:5da1/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 16:99:6c:4b:a3:ad brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1499:6cff:fe4b:a3ad/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:fc:fc:ad:41:69 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b8fc:fcff:fead:4169/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcd1256ebbdcfb@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:72:b7:d4:f5:06 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::fc72:b7ff:fed4:f506/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc19b12bd91edb@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:2f:60:d6:0e:5d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::642f:60ff:fed6:e5d/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc758ea62ba2a2@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:0a:78:c7:14:d2 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::ec0a:78ff:fec7:14d2/64 scope link 
       valid_lft forever preferred_lft forever
