REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36757     2905868     677    bpf_overlay.c
Interface                 INGRESS     679151    136041701   1132   bpf_host.c
Success                   EGRESS      16694     1311898     1694   bpf_host.c
Success                   EGRESS      300143    37323975    1308   bpf_lxc.c
Success                   EGRESS      37433     2951040     53     encap.h
Success                   INGRESS     344898    39143574    86     l3.h
Success                   INGRESS     365612    40781590    235    trace.h
Unsupported L3 protocol   EGRESS      39        2886        1492   bpf_lxc.c
