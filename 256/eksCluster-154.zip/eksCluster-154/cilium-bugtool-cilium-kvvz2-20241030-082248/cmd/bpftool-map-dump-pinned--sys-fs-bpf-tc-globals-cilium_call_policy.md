key: 88 05 00 00  value: 09 02 00 00
key: 83 06 00 00  value: fe 01 00 00
key: a8 06 00 00  value: 75 02 00 00
key: 71 0f 00 00  value: 1f 02 00 00
Found 4 elements
