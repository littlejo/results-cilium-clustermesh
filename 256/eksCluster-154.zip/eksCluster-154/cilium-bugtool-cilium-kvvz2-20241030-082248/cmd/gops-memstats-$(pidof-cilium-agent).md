alloc: 203.90MB (213805976 bytes)
total-alloc: 2.46GB (2644786208 bytes)
sys: 328.71MB (344674660 bytes)
lookups: 0
mallocs: 66538614
frees: 64372097
heap-alloc: 203.90MB (213805976 bytes)
heap-sys: 248.58MB (260653056 bytes)
heap-idle: 14.92MB (15646720 bytes)
heap-in-use: 233.66MB (245006336 bytes)
heap-released: 1.27MB (1335296 bytes)
heap-objects: 2166517
stack-in-use: 67.38MB (70647808 bytes)
stack-sys: 67.38MB (70647808 bytes)
stack-mspan-inuse: 3.69MB (3873120 bytes)
stack-mspan-sys: 3.95MB (4145280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 839.38KB (859529 bytes)
gc-sys: 5.98MB (6270584 bytes)
next-gc: when heap-alloc >= 212.04MB (222338888 bytes)
last-gc: 2024-10-30 08:22:44.254484377 +0000 UTC
gc-pause-total: 11.742845ms
gc-pause: 98586
gc-pause-end: 1730276564254484377
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0006227763556809692
enable-gc: true
debug-gc: false
