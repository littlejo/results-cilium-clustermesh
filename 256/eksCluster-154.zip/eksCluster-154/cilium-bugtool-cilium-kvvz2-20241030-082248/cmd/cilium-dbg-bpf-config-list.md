KEY             VALUE
AgentLiveness   1934464104258
UTimeOffset     3379442707031250
