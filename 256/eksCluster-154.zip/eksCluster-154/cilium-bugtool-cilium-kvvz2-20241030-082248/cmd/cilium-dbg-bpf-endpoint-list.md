IP ADDRESS         LOCAL ENDPOINT INFO
10.154.0.91:0      id=3953  sec_id=4     flags=0x0000 ifindex=10  mac=DE:47:6E:3F:EE:87 nodemac=BA:FC:FC:AD:41:69     
10.154.0.45:0      (localhost)                                                                                        
172.31.150.63:0    (localhost)                                                                                        
172.31.143.150:0   (localhost)                                                                                        
10.154.0.117:0     id=1416  sec_id=5108984 flags=0x0000 ifindex=14  mac=82:A5:7C:AA:63:FD nodemac=66:2F:60:D6:0E:5D   
10.154.0.53:0      id=1667  sec_id=5108984 flags=0x0000 ifindex=12  mac=62:AB:D6:88:60:29 nodemac=FE:72:B7:D4:F5:06   
10.154.0.219:0     id=1704  sec_id=5092500 flags=0x0000 ifindex=18  mac=F2:12:C2:AF:F3:D6 nodemac=EE:0A:78:C7:14:D2   
