top - 08:22:49 up 31 min,  0 users,  load average: 0.20, 0.21, 0.18
Tasks:  10 total,   3 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 66.7 us, 33.3 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4462.5 free,   1206.0 used,   2145.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6423.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606016 397980  78524 S  66.7   5.0   0:52.70 cilium-+
    393 root      20   0 1229744   7000   2864 S   0.0   0.1   0:01.10 cilium-+
    664 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    684 root      20   0 1240432  16676  11292 S   0.0   0.2   0:00.03 cilium-+
    710 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    714 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    724 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    725 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
    745 root      20   0 1242676  15956  11884 R   0.0   0.2   0:00.00 hubble
    752 root      20   0 1240432  16676  11292 R   0.0   0.2   0:00.00 cilium-+
