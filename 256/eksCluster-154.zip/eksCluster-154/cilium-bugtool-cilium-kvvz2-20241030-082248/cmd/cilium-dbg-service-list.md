ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.155.235:443 (active)    
                                         2 => 172.31.232.175:443 (active)    
2    10.100.148.23:443    ClusterIP      1 => 172.31.143.150:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.154.0.117:53 (active)       
                                         2 => 10.154.0.53:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.154.0.117:9153 (active)     
                                         2 => 10.154.0.53:9153 (active)      
5    10.100.70.249:2379   ClusterIP      1 => 10.154.0.219:2379 (active)     
