ip-172-31-143-150.eu-west-3.compute.internal
