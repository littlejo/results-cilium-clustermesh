1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00 promiscuity 0 minmtu 0 maxmtu 0 addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       2499416   11640      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       2499416   11640      0       0       0       0 
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP mode DEFAULT group default qlen 1000
    link/ether 06:67:c9:41:5f:75 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 128 maxmtu 9216 addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 parentbus pci parentdev 0000:00:05.0 
    RX:  bytes packets errors dropped  missed   mcast           
     585852721  620308      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      35666253  297314      0       0       0       0 
    altname enp0s5
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP mode DEFAULT group default qlen 1000
    link/ether 06:75:c8:da:f9:7f brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 128 maxmtu 9216 addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 parentbus pci parentdev 0000:00:06.0 
    RX:  bytes packets errors dropped  missed   mcast           
           868      31      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
          2378      45      0       0       0       0 
    altname enp0s6
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 5a:40:68:28:5c:5e brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         43990     649      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       1259140   15909      0       0       0       0 
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 5e:b3:f6:4f:5d:a1 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       1259140   15909      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
         43990     649      0       0       0       0 
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000
    link/ether 16:99:6c:4b:a3:ad brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    vxlan external id 0 srcport 0 0 dstport 8472 nolearning ttl auto ageing 300 udpcsum noudp6zerocsumtx noudp6zerocsumrx addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       2319478   35627      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       2371642   36553      0       0       0       0 
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ba:fc:fc:ad:41:69 brd ff:ff:ff:ff:ff:ff link-netnsid 0 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       1174775   14895      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       1580272   19975      0       0       0       0 
12: lxcd1256ebbdcfb@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether fe:72:b7:d4:f5:06 brd ff:ff:ff:ff:ff:ff link-netnsid 1 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        126741    1298      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        184924    1588      0       0       0       0 
14: lxc19b12bd91edb@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 66:2f:60:d6:0e:5d brd ff:ff:ff:ff:ff:ff link-netnsid 2 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        127497    1307      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        185474    1586      0       0       0       0 
18: lxc758ea62ba2a2@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ee:0a:78:c7:14:d2 brd ff:ff:ff:ff:ff:ff link-netnsid 4 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      31329355  259590      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      33208572  300356      0       0       0       0 
