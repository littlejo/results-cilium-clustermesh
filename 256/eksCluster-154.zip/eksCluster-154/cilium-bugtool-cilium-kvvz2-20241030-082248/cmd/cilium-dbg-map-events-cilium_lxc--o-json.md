{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:34.905Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.143.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:34.905Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.150.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:34.905Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:39.410Z",
  "value": "id=1416  sec_id=5108984 flags=0x0000 ifindex=14  mac=82:A5:7C:AA:63:FD nodemac=66:2F:60:D6:0E:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:39.410Z",
  "value": "id=3953  sec_id=4     flags=0x0000 ifindex=10  mac=DE:47:6E:3F:EE:87 nodemac=BA:FC:FC:AD:41:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:39.496Z",
  "value": "id=1667  sec_id=5108984 flags=0x0000 ifindex=12  mac=62:AB:D6:88:60:29 nodemac=FE:72:B7:D4:F5:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:39.548Z",
  "value": "id=1416  sec_id=5108984 flags=0x0000 ifindex=14  mac=82:A5:7C:AA:63:FD nodemac=66:2F:60:D6:0E:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:39.599Z",
  "value": "id=3953  sec_id=4     flags=0x0000 ifindex=10  mac=DE:47:6E:3F:EE:87 nodemac=BA:FC:FC:AD:41:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:27.675Z",
  "value": "id=3953  sec_id=4     flags=0x0000 ifindex=10  mac=DE:47:6E:3F:EE:87 nodemac=BA:FC:FC:AD:41:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:27.676Z",
  "value": "id=1416  sec_id=5108984 flags=0x0000 ifindex=14  mac=82:A5:7C:AA:63:FD nodemac=66:2F:60:D6:0E:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:27.676Z",
  "value": "id=1667  sec_id=5108984 flags=0x0000 ifindex=12  mac=62:AB:D6:88:60:29 nodemac=FE:72:B7:D4:F5:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:27.704Z",
  "value": "id=449   sec_id=5092500 flags=0x0000 ifindex=16  mac=DA:ED:A2:84:7E:A2 nodemac=FA:3F:F3:16:C8:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:28.675Z",
  "value": "id=3953  sec_id=4     flags=0x0000 ifindex=10  mac=DE:47:6E:3F:EE:87 nodemac=BA:FC:FC:AD:41:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:28.675Z",
  "value": "id=1416  sec_id=5108984 flags=0x0000 ifindex=14  mac=82:A5:7C:AA:63:FD nodemac=66:2F:60:D6:0E:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:28.675Z",
  "value": "id=1667  sec_id=5108984 flags=0x0000 ifindex=12  mac=62:AB:D6:88:60:29 nodemac=FE:72:B7:D4:F5:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:28.675Z",
  "value": "id=449   sec_id=5092500 flags=0x0000 ifindex=16  mac=DA:ED:A2:84:7E:A2 nodemac=FA:3F:F3:16:C8:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.685Z",
  "value": "id=1704  sec_id=5092500 flags=0x0000 ifindex=18  mac=F2:12:C2:AF:F3:D6 nodemac=EE:0A:78:C7:14:D2"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.154.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:22.242Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.241Z",
  "value": "id=1667  sec_id=5108984 flags=0x0000 ifindex=12  mac=62:AB:D6:88:60:29 nodemac=FE:72:B7:D4:F5:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.241Z",
  "value": "id=1704  sec_id=5092500 flags=0x0000 ifindex=18  mac=F2:12:C2:AF:F3:D6 nodemac=EE:0A:78:C7:14:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.242Z",
  "value": "id=3953  sec_id=4     flags=0x0000 ifindex=10  mac=DE:47:6E:3F:EE:87 nodemac=BA:FC:FC:AD:41:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.243Z",
  "value": "id=1416  sec_id=5108984 flags=0x0000 ifindex=14  mac=82:A5:7C:AA:63:FD nodemac=66:2F:60:D6:0E:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.234Z",
  "value": "id=1416  sec_id=5108984 flags=0x0000 ifindex=14  mac=82:A5:7C:AA:63:FD nodemac=66:2F:60:D6:0E:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.236Z",
  "value": "id=1667  sec_id=5108984 flags=0x0000 ifindex=12  mac=62:AB:D6:88:60:29 nodemac=FE:72:B7:D4:F5:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.236Z",
  "value": "id=1704  sec_id=5092500 flags=0x0000 ifindex=18  mac=F2:12:C2:AF:F3:D6 nodemac=EE:0A:78:C7:14:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.237Z",
  "value": "id=3953  sec_id=4     flags=0x0000 ifindex=10  mac=DE:47:6E:3F:EE:87 nodemac=BA:FC:FC:AD:41:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.249Z",
  "value": "id=1667  sec_id=5108984 flags=0x0000 ifindex=12  mac=62:AB:D6:88:60:29 nodemac=FE:72:B7:D4:F5:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.250Z",
  "value": "id=3953  sec_id=4     flags=0x0000 ifindex=10  mac=DE:47:6E:3F:EE:87 nodemac=BA:FC:FC:AD:41:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.250Z",
  "value": "id=1416  sec_id=5108984 flags=0x0000 ifindex=14  mac=82:A5:7C:AA:63:FD nodemac=66:2F:60:D6:0E:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.256Z",
  "value": "id=1704  sec_id=5092500 flags=0x0000 ifindex=18  mac=F2:12:C2:AF:F3:D6 nodemac=EE:0A:78:C7:14:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:26.233Z",
  "value": "id=1416  sec_id=5108984 flags=0x0000 ifindex=14  mac=82:A5:7C:AA:63:FD nodemac=66:2F:60:D6:0E:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:26.234Z",
  "value": "id=3953  sec_id=4     flags=0x0000 ifindex=10  mac=DE:47:6E:3F:EE:87 nodemac=BA:FC:FC:AD:41:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:26.234Z",
  "value": "id=1667  sec_id=5108984 flags=0x0000 ifindex=12  mac=62:AB:D6:88:60:29 nodemac=FE:72:B7:D4:F5:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:26.234Z",
  "value": "id=1704  sec_id=5092500 flags=0x0000 ifindex=18  mac=F2:12:C2:AF:F3:D6 nodemac=EE:0A:78:C7:14:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.234Z",
  "value": "id=1416  sec_id=5108984 flags=0x0000 ifindex=14  mac=82:A5:7C:AA:63:FD nodemac=66:2F:60:D6:0E:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.234Z",
  "value": "id=1704  sec_id=5092500 flags=0x0000 ifindex=18  mac=F2:12:C2:AF:F3:D6 nodemac=EE:0A:78:C7:14:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.235Z",
  "value": "id=1667  sec_id=5108984 flags=0x0000 ifindex=12  mac=62:AB:D6:88:60:29 nodemac=FE:72:B7:D4:F5:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.154.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.235Z",
  "value": "id=3953  sec_id=4     flags=0x0000 ifindex=10  mac=DE:47:6E:3F:EE:87 nodemac=BA:FC:FC:AD:41:69"
}

