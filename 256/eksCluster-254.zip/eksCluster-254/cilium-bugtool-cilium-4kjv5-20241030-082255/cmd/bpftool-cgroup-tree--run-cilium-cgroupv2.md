CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcdbbc591_9f82_454c_9444_ff498b492653.slice/cri-containerd-9b905fe529b5db208222349740bffadd0feda010ff5008c08c567d4ee3b5b016.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcdbbc591_9f82_454c_9444_ff498b492653.slice/cri-containerd-cbf32f680c0bf14a67a9c490696cf64d26ce0ed0d137236b6de53cb93c6edc80.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2c79bb71_cfd6_441e_b7e1_bba04dc13c16.slice/cri-containerd-27f11ee94815a8c0a1299d76446060047d3b3b8861630040783ace6ebc5a75b0.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2c79bb71_cfd6_441e_b7e1_bba04dc13c16.slice/cri-containerd-0ffde4be7cac1bb5c62ee57abbb79db6adf390f2194074d4cf42d6da48dba0b2.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode81beecf_70eb_4dc7_a0a8_efe7b4095c33.slice/cri-containerd-b0fef311fbfd2381faf2ba79a64f93ce2314b1dacf0d6ad7914087c6c930d31c.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode81beecf_70eb_4dc7_a0a8_efe7b4095c33.slice/cri-containerd-6cf4fd2e4186cca2a2c60e236b1075d1f452d59630e8c80231f6f815d6a08109.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb56719bb_2fd1_4eb6_a6be_23504d89268d.slice/cri-containerd-b7f5870c961ff4703b0807f5e9f07700b6f11161f946e12c0fdf14697507c3c7.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb56719bb_2fd1_4eb6_a6be_23504d89268d.slice/cri-containerd-660d9c65d0238e9207f626ce34f645ac63a04ff80b2be0ace7b43dbd51b5b5cf.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5aec600_0502_46b9_b11e_7140b590bfe7.slice/cri-containerd-cded18f00f405a86b738b3bfcc875a8c07118e85ef3631a35a2e2e67d0412f91.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5aec600_0502_46b9_b11e_7140b590bfe7.slice/cri-containerd-827db42abf8a7fbcf9f10cbe35f9284507a551e03ebfd7ee05553d02453be8e5.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod20bbed80_338a_424d_addb_d54f4e15dbf3.slice/cri-containerd-c955a6bfb2adb21a027ce6b5de53e69bcc167c9b4e1e30046779d967c4d1cd16.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod20bbed80_338a_424d_addb_d54f4e15dbf3.slice/cri-containerd-f8e35eb391fda150fbe1f5416fff1aba483986ccf33ed7c613b087f357ba7dc4.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod313d33b8_99b1_4d7f_bcb9_7846a54160c9.slice/cri-containerd-80dd51fee9916d0ead7240df46f52e3bb6d39558c05364fa9443cf857b635ef8.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod313d33b8_99b1_4d7f_bcb9_7846a54160c9.slice/cri-containerd-625c760c0ee6c0aa573c04a9799d7073e106a6e2813561e9492a186c95f61d5e.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod313d33b8_99b1_4d7f_bcb9_7846a54160c9.slice/cri-containerd-04601079297b2b1b894c423af29e7a6d56dd8b906c8ed07722145ddd69aa48e5.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod313d33b8_99b1_4d7f_bcb9_7846a54160c9.slice/cri-containerd-67c4069793a0b41baea4c840aa080f7a18fdd605506aa9ea64d1b3d6ea8505f2.scope
    623      cgroup_device   multi                                          
