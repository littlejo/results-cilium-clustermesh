1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ce:0a:d4:61:ef brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.158.156/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1988sec preferred_lft 1988sec
    inet6 fe80::4ce:aff:fed4:61ef/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ff:81:b6:5d:5d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.146.127/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4ff:81ff:feb6:5d5d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:70:81:96:4a:a8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::bc70:81ff:fe96:4aa8/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:a8:46:e7:1b:70 brd ff:ff:ff:ff:ff:ff
    inet 10.254.0.159/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::24a8:46ff:fee7:1b70/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 1a:9d:06:e6:92:bc brd ff:ff:ff:ff:ff:ff
    inet6 fe80::189d:6ff:fee6:92bc/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:75:57:11:7d:85 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a875:57ff:fe11:7d85/64 scope link 
       valid_lft forever preferred_lft forever
12: lxccb4d7f6762f3@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:a4:bf:bf:13:79 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f8a4:bfff:febf:1379/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce45498f58248@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:7a:86:ac:b8:63 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a87a:86ff:feac:b863/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc6afa6cfe8182@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:b1:b0:61:c0:2b brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::f8b1:b0ff:fe61:c02b/64 scope link 
       valid_lft forever preferred_lft forever
