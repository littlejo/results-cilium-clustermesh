Endpoint ID: 221
Path: /sys/fs/bpf/tc/globals/cilium_policy_00221

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1664964   21013     0        
Allow    Ingress     1          ANY          NONE         disabled    17362     204       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 728
Path: /sys/fs/bpf/tc/globals/cilium_policy_00728

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    109462   1251      0        
Allow    Egress      0          ANY          NONE         disabled    16123    173       0        


Endpoint ID: 777
Path: /sys/fs/bpf/tc/globals/cilium_policy_00777

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11578027   114943    0        
Allow    Ingress     1          ANY          NONE         disabled    9814621    102958    0        
Allow    Egress      0          ANY          NONE         disabled    12416118   122666    0        


Endpoint ID: 1113
Path: /sys/fs/bpf/tc/globals/cilium_policy_01113

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1415
Path: /sys/fs/bpf/tc/globals/cilium_policy_01415

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    110592   1268      0        
Allow    Egress      0          ANY          NONE         disabled    15676    168       0        


