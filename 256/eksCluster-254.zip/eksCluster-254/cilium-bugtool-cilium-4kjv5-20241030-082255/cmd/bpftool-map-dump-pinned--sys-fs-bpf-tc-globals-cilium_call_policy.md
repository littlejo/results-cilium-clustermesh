key: dd 00 00 00  value: 24 02 00 00
key: d8 02 00 00  value: 18 02 00 00
key: 09 03 00 00  value: 65 02 00 00
key: 87 05 00 00  value: 06 02 00 00
Found 4 elements
