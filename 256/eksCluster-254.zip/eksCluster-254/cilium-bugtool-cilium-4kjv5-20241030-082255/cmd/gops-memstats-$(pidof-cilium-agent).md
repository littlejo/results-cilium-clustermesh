alloc: 205.56MB (215545368 bytes)
total-alloc: 2.22GB (2381142176 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63041105
frees: 60841506
heap-alloc: 205.56MB (215545368 bytes)
heap-sys: 247.27MB (259276800 bytes)
heap-idle: 20.87MB (21880832 bytes)
heap-in-use: 226.40MB (237395968 bytes)
heap-released: 2.36MB (2473984 bytes)
heap-objects: 2199599
stack-in-use: 64.69MB (67829760 bytes)
stack-sys: 64.69MB (67829760 bytes)
stack-mspan-inuse: 3.57MB (3744160 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1053849 bytes)
gc-sys: 6.04MB (6329928 bytes)
next-gc: when heap-alloc >= 236.75MB (248247416 bytes)
last-gc: 2024-10-30 08:22:57.093185656 +0000 UTC
gc-pause-total: 29.261246ms
gc-pause: 5629768
gc-pause-end: 1730276577093185656
num-gc: 79
num-forced-gc: 0
gc-cpu-fraction: 0.0006176388543746336
enable-gc: true
debug-gc: false
