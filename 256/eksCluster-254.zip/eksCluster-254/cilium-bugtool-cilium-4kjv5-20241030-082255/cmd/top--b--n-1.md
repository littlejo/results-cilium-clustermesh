top - 08:22:57 up 27 min,  0 users,  load average: 0.16, 0.20, 0.17
Tasks:   9 total,   3 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 25.8 us, 58.1 sy,  0.0 ni,  3.2 id,  0.0 wa,  0.0 hi, 12.9 si,  0.0 st
MiB Mem :   7814.2 total,   4475.3 free,   1193.1 used,   2145.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6436.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    697 root      20   0 1244340  21988  14524 S  31.2   0.3   0:00.05 hubble
      1 root      20   0 1606080 393608  78652 S  18.8   4.9   0:48.85 cilium-+
    394 root      20   0 1229488   6588   2924 S   0.0   0.1   0:01.14 cilium-+
    626 root      20   0 1240432  16252  11484 S   0.0   0.2   0:00.02 cilium-+
    669 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    690 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    692 root      20   0    2208    776    696 S   0.0   0.0   0:00.00 timeout
    710 root      20   0    3800   2244   1868 R   0.0   0.0   0:00.00 iptable+
    712 root      20   0    1548      4      0 R   0.0   0.0   0:00.00 bash
