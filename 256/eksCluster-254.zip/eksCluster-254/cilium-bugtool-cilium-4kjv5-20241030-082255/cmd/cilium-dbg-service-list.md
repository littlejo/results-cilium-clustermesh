ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.128.97:443 (active)     
                                         2 => 172.31.197.79:443 (active)     
2    10.100.202.186:443   ClusterIP      1 => 172.31.158.156:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.254.0.158:9153 (active)     
                                         2 => 10.254.0.163:9153 (active)     
4    10.100.0.10:53       ClusterIP      1 => 10.254.0.158:53 (active)       
                                         2 => 10.254.0.163:53 (active)       
5    10.100.20.136:2379   ClusterIP      1 => 10.254.0.34:2379 (active)      
