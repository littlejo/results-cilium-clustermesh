IP ADDRESS         LOCAL ENDPOINT INFO
10.254.0.158:0     id=1415  sec_id=8362809 flags=0x0000 ifindex=12  mac=3E:30:E3:B7:90:CD nodemac=FA:A4:BF:BF:13:79   
10.254.0.163:0     id=728   sec_id=8362809 flags=0x0000 ifindex=14  mac=EA:34:ED:AA:61:7D nodemac=AA:7A:86:AC:B8:63   
172.31.146.127:0   (localhost)                                                                                        
10.254.0.114:0     id=221   sec_id=4     flags=0x0000 ifindex=10  mac=06:78:2B:B9:9F:5C nodemac=AA:75:57:11:7D:85     
10.254.0.34:0      id=777   sec_id=8379784 flags=0x0000 ifindex=18  mac=A2:51:E6:27:34:68 nodemac=FA:B1:B0:61:C0:2B   
10.254.0.159:0     (localhost)                                                                                        
172.31.158.156:0   (localhost)                                                                                        
