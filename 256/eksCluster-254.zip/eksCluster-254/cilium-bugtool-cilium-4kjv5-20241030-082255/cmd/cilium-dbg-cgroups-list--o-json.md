[
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod313d33b8_99b1_4d7f_bcb9_7846a54160c9.slice/cri-containerd-04601079297b2b1b894c423af29e7a6d56dd8b906c8ed07722145ddd69aa48e5.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod313d33b8_99b1_4d7f_bcb9_7846a54160c9.slice/cri-containerd-80dd51fee9916d0ead7240df46f52e3bb6d39558c05364fa9443cf857b635ef8.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod313d33b8_99b1_4d7f_bcb9_7846a54160c9.slice/cri-containerd-625c760c0ee6c0aa573c04a9799d7073e106a6e2813561e9492a186c95f61d5e.scope"
      }
    ],
    "ips": [
      "10.254.0.34"
    ],
    "name": "clustermesh-apiserver-7c5bcdc598-qwq4l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcdbbc591_9f82_454c_9444_ff498b492653.slice/cri-containerd-9b905fe529b5db208222349740bffadd0feda010ff5008c08c567d4ee3b5b016.scope"
      }
    ],
    "ips": [
      "10.254.0.158"
    ],
    "name": "coredns-cc6ccd49c-zwj5w",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode81beecf_70eb_4dc7_a0a8_efe7b4095c33.slice/cri-containerd-6cf4fd2e4186cca2a2c60e236b1075d1f452d59630e8c80231f6f815d6a08109.scope"
      }
    ],
    "ips": [
      "10.254.0.163"
    ],
    "name": "coredns-cc6ccd49c-r6hw7",
    "namespace": "kube-system"
  }
]

