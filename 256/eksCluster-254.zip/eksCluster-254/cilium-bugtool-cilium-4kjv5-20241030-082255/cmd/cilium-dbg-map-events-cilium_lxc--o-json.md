{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:06.750Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.146.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:06.750Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.158.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:06.750Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:11.519Z",
  "value": "id=1415  sec_id=8362809 flags=0x0000 ifindex=12  mac=3E:30:E3:B7:90:CD nodemac=FA:A4:BF:BF:13:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:11.519Z",
  "value": "id=221   sec_id=4     flags=0x0000 ifindex=10  mac=06:78:2B:B9:9F:5C nodemac=AA:75:57:11:7D:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:11.530Z",
  "value": "id=1415  sec_id=8362809 flags=0x0000 ifindex=12  mac=3E:30:E3:B7:90:CD nodemac=FA:A4:BF:BF:13:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:11.599Z",
  "value": "id=728   sec_id=8362809 flags=0x0000 ifindex=14  mac=EA:34:ED:AA:61:7D nodemac=AA:7A:86:AC:B8:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:11.605Z",
  "value": "id=221   sec_id=4     flags=0x0000 ifindex=10  mac=06:78:2B:B9:9F:5C nodemac=AA:75:57:11:7D:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:11.602Z",
  "value": "id=221   sec_id=4     flags=0x0000 ifindex=10  mac=06:78:2B:B9:9F:5C nodemac=AA:75:57:11:7D:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:11.602Z",
  "value": "id=1415  sec_id=8362809 flags=0x0000 ifindex=12  mac=3E:30:E3:B7:90:CD nodemac=FA:A4:BF:BF:13:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:11.602Z",
  "value": "id=728   sec_id=8362809 flags=0x0000 ifindex=14  mac=EA:34:ED:AA:61:7D nodemac=AA:7A:86:AC:B8:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:11.641Z",
  "value": "id=1064  sec_id=8379784 flags=0x0000 ifindex=16  mac=CA:12:50:53:D3:1C nodemac=16:3C:40:AF:E6:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:12.602Z",
  "value": "id=1415  sec_id=8362809 flags=0x0000 ifindex=12  mac=3E:30:E3:B7:90:CD nodemac=FA:A4:BF:BF:13:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:12.603Z",
  "value": "id=221   sec_id=4     flags=0x0000 ifindex=10  mac=06:78:2B:B9:9F:5C nodemac=AA:75:57:11:7D:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:12.603Z",
  "value": "id=728   sec_id=8362809 flags=0x0000 ifindex=14  mac=EA:34:ED:AA:61:7D nodemac=AA:7A:86:AC:B8:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:12.603Z",
  "value": "id=1064  sec_id=8379784 flags=0x0000 ifindex=16  mac=CA:12:50:53:D3:1C nodemac=16:3C:40:AF:E6:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.582Z",
  "value": "id=777   sec_id=8379784 flags=0x0000 ifindex=18  mac=A2:51:E6:27:34:68 nodemac=FA:B1:B0:61:C0:2B"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.254.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.995Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.791Z",
  "value": "id=728   sec_id=8362809 flags=0x0000 ifindex=14  mac=EA:34:ED:AA:61:7D nodemac=AA:7A:86:AC:B8:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.791Z",
  "value": "id=777   sec_id=8379784 flags=0x0000 ifindex=18  mac=A2:51:E6:27:34:68 nodemac=FA:B1:B0:61:C0:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.792Z",
  "value": "id=221   sec_id=4     flags=0x0000 ifindex=10  mac=06:78:2B:B9:9F:5C nodemac=AA:75:57:11:7D:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.793Z",
  "value": "id=1415  sec_id=8362809 flags=0x0000 ifindex=12  mac=3E:30:E3:B7:90:CD nodemac=FA:A4:BF:BF:13:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.823Z",
  "value": "id=221   sec_id=4     flags=0x0000 ifindex=10  mac=06:78:2B:B9:9F:5C nodemac=AA:75:57:11:7D:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.824Z",
  "value": "id=1415  sec_id=8362809 flags=0x0000 ifindex=12  mac=3E:30:E3:B7:90:CD nodemac=FA:A4:BF:BF:13:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.829Z",
  "value": "id=728   sec_id=8362809 flags=0x0000 ifindex=14  mac=EA:34:ED:AA:61:7D nodemac=AA:7A:86:AC:B8:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.830Z",
  "value": "id=777   sec_id=8379784 flags=0x0000 ifindex=18  mac=A2:51:E6:27:34:68 nodemac=FA:B1:B0:61:C0:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.794Z",
  "value": "id=728   sec_id=8362809 flags=0x0000 ifindex=14  mac=EA:34:ED:AA:61:7D nodemac=AA:7A:86:AC:B8:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.794Z",
  "value": "id=777   sec_id=8379784 flags=0x0000 ifindex=18  mac=A2:51:E6:27:34:68 nodemac=FA:B1:B0:61:C0:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.795Z",
  "value": "id=221   sec_id=4     flags=0x0000 ifindex=10  mac=06:78:2B:B9:9F:5C nodemac=AA:75:57:11:7D:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.795Z",
  "value": "id=1415  sec_id=8362809 flags=0x0000 ifindex=12  mac=3E:30:E3:B7:90:CD nodemac=FA:A4:BF:BF:13:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.795Z",
  "value": "id=728   sec_id=8362809 flags=0x0000 ifindex=14  mac=EA:34:ED:AA:61:7D nodemac=AA:7A:86:AC:B8:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.795Z",
  "value": "id=777   sec_id=8379784 flags=0x0000 ifindex=18  mac=A2:51:E6:27:34:68 nodemac=FA:B1:B0:61:C0:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.796Z",
  "value": "id=221   sec_id=4     flags=0x0000 ifindex=10  mac=06:78:2B:B9:9F:5C nodemac=AA:75:57:11:7D:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.254.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.796Z",
  "value": "id=1415  sec_id=8362809 flags=0x0000 ifindex=12  mac=3E:30:E3:B7:90:CD nodemac=FA:A4:BF:BF:13:79"
}

