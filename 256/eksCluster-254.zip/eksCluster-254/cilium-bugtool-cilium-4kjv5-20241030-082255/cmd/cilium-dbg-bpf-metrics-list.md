REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36871     2919749     677    bpf_overlay.c
Interface                 INGRESS     637888    130915616   1132   bpf_host.c
Success                   EGRESS      16564     1303079     1694   bpf_host.c
Success                   EGRESS      267433    33700844    1308   bpf_lxc.c
Success                   EGRESS      36980     2927441     53     encap.h
Success                   INGRESS     310385    34941323    86     l3.h
Success                   INGRESS     331343    36602039    235    trace.h
Unsupported L3 protocol   EGRESS      41        3062        1492   bpf_lxc.c
