{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:58.065Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.145.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:58.065Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.185.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:58.065Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:02.547Z",
  "value": "id=703   sec_id=4     flags=0x0000 ifindex=10  mac=52:E6:5C:7C:A3:08 nodemac=7E:23:AB:FC:D2:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:02.550Z",
  "value": "id=3901  sec_id=513120 flags=0x0000 ifindex=14  mac=EE:F9:BC:F1:90:7E nodemac=86:C9:38:7C:E5:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:02.593Z",
  "value": "id=703   sec_id=4     flags=0x0000 ifindex=10  mac=52:E6:5C:7C:A3:08 nodemac=7E:23:AB:FC:D2:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:02.594Z",
  "value": "id=1297  sec_id=513120 flags=0x0000 ifindex=12  mac=CE:F6:A1:E7:0E:01 nodemac=8E:C1:E4:71:9E:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:15.647Z",
  "value": "id=703   sec_id=4     flags=0x0000 ifindex=10  mac=52:E6:5C:7C:A3:08 nodemac=7E:23:AB:FC:D2:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:15.648Z",
  "value": "id=1297  sec_id=513120 flags=0x0000 ifindex=12  mac=CE:F6:A1:E7:0E:01 nodemac=8E:C1:E4:71:9E:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:15.648Z",
  "value": "id=3901  sec_id=513120 flags=0x0000 ifindex=14  mac=EE:F9:BC:F1:90:7E nodemac=86:C9:38:7C:E5:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:15.678Z",
  "value": "id=2530  sec_id=494570 flags=0x0000 ifindex=16  mac=92:B7:6C:49:BA:70 nodemac=1E:FA:6A:2D:35:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:16.648Z",
  "value": "id=1297  sec_id=513120 flags=0x0000 ifindex=12  mac=CE:F6:A1:E7:0E:01 nodemac=8E:C1:E4:71:9E:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:16.648Z",
  "value": "id=3901  sec_id=513120 flags=0x0000 ifindex=14  mac=EE:F9:BC:F1:90:7E nodemac=86:C9:38:7C:E5:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:16.648Z",
  "value": "id=2530  sec_id=494570 flags=0x0000 ifindex=16  mac=92:B7:6C:49:BA:70 nodemac=1E:FA:6A:2D:35:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:16.648Z",
  "value": "id=703   sec_id=4     flags=0x0000 ifindex=10  mac=52:E6:5C:7C:A3:08 nodemac=7E:23:AB:FC:D2:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:30.028Z",
  "value": "id=695   sec_id=494570 flags=0x0000 ifindex=18  mac=26:05:EB:EA:4A:1F nodemac=56:9F:FA:38:44:2E"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.14.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.334Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:46.150Z",
  "value": "id=695   sec_id=494570 flags=0x0000 ifindex=18  mac=26:05:EB:EA:4A:1F nodemac=56:9F:FA:38:44:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:46.151Z",
  "value": "id=703   sec_id=4     flags=0x0000 ifindex=10  mac=52:E6:5C:7C:A3:08 nodemac=7E:23:AB:FC:D2:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:46.152Z",
  "value": "id=3901  sec_id=513120 flags=0x0000 ifindex=14  mac=EE:F9:BC:F1:90:7E nodemac=86:C9:38:7C:E5:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:46.152Z",
  "value": "id=1297  sec_id=513120 flags=0x0000 ifindex=12  mac=CE:F6:A1:E7:0E:01 nodemac=8E:C1:E4:71:9E:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:47.150Z",
  "value": "id=1297  sec_id=513120 flags=0x0000 ifindex=12  mac=CE:F6:A1:E7:0E:01 nodemac=8E:C1:E4:71:9E:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:47.151Z",
  "value": "id=695   sec_id=494570 flags=0x0000 ifindex=18  mac=26:05:EB:EA:4A:1F nodemac=56:9F:FA:38:44:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:47.152Z",
  "value": "id=703   sec_id=4     flags=0x0000 ifindex=10  mac=52:E6:5C:7C:A3:08 nodemac=7E:23:AB:FC:D2:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:47.153Z",
  "value": "id=3901  sec_id=513120 flags=0x0000 ifindex=14  mac=EE:F9:BC:F1:90:7E nodemac=86:C9:38:7C:E5:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:48.152Z",
  "value": "id=703   sec_id=4     flags=0x0000 ifindex=10  mac=52:E6:5C:7C:A3:08 nodemac=7E:23:AB:FC:D2:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:48.152Z",
  "value": "id=1297  sec_id=513120 flags=0x0000 ifindex=12  mac=CE:F6:A1:E7:0E:01 nodemac=8E:C1:E4:71:9E:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:48.152Z",
  "value": "id=3901  sec_id=513120 flags=0x0000 ifindex=14  mac=EE:F9:BC:F1:90:7E nodemac=86:C9:38:7C:E5:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:48.152Z",
  "value": "id=695   sec_id=494570 flags=0x0000 ifindex=18  mac=26:05:EB:EA:4A:1F nodemac=56:9F:FA:38:44:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:49.152Z",
  "value": "id=1297  sec_id=513120 flags=0x0000 ifindex=12  mac=CE:F6:A1:E7:0E:01 nodemac=8E:C1:E4:71:9E:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:49.153Z",
  "value": "id=703   sec_id=4     flags=0x0000 ifindex=10  mac=52:E6:5C:7C:A3:08 nodemac=7E:23:AB:FC:D2:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:49.153Z",
  "value": "id=3901  sec_id=513120 flags=0x0000 ifindex=14  mac=EE:F9:BC:F1:90:7E nodemac=86:C9:38:7C:E5:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:49.153Z",
  "value": "id=695   sec_id=494570 flags=0x0000 ifindex=18  mac=26:05:EB:EA:4A:1F nodemac=56:9F:FA:38:44:2E"
}

