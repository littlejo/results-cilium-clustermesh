[
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9dba2620_8685_4a53_8b15_141c9751cd25.slice/cri-containerd-2585c701befeca8e98b13942531079ea4bd15ecfaf10a479b8a7ea89db28d147.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9dba2620_8685_4a53_8b15_141c9751cd25.slice/cri-containerd-256cd24445ffcd1e03a44d49a0b0838f95e830acb86c78ee576ec04ffb011265.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9dba2620_8685_4a53_8b15_141c9751cd25.slice/cri-containerd-71144cb68691a3f681b3ff306419c37c204341a75953c85265c722c47a2e17bc.scope"
      }
    ],
    "ips": [
      "10.14.0.115"
    ],
    "name": "clustermesh-apiserver-7b68d5d7c9-ndr2d",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae60225e_862c_48c2_8093_9d8f946f78ed.slice/cri-containerd-70a5618b709ea6e19874a3430e75651ea6c6906a9df9dadb8940f014181c88a2.scope"
      }
    ],
    "ips": [
      "10.14.0.243"
    ],
    "name": "coredns-cc6ccd49c-qddc7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3b35bd0_ed5b_4475_8151_976e3cbc0f20.slice/cri-containerd-26888cd6cb4b2f6b904c3e013a63ba960a0a39646b3f3cd7123ee96e634e320c.scope"
      }
    ],
    "ips": [
      "10.14.0.84"
    ],
    "name": "coredns-cc6ccd49c-fb4br",
    "namespace": "kube-system"
  }
]

