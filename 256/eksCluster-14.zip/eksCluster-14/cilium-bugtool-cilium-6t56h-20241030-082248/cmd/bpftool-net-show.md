xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 507
ens6(5) clsact/ingress cil_from_netdev-ens6 id 513
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 496
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 493
cilium_host(7) clsact/egress cil_from_host-cilium_host id 488
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 557
lxc9481e8fe82ab(12) clsact/ingress cil_from_container-lxc9481e8fe82ab id 538
lxc12f3eb963756(14) clsact/ingress cil_from_container-lxc12f3eb963756 id 521
lxc6e10dd3c1751(18) clsact/ingress cil_from_container-lxc6e10dd3c1751 id 616

flow_dissector:

netfilter:

