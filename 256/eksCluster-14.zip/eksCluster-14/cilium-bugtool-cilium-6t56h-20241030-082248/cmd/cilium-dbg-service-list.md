ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.168.224:443 (active)   
                                          2 => 172.31.194.146:443 (active)   
2    10.100.9.126:443      ClusterIP      1 => 172.31.145.58:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.14.0.84:53 (active)        
                                          2 => 10.14.0.243:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.14.0.84:9153 (active)      
                                          2 => 10.14.0.243:9153 (active)     
5    10.100.198.195:2379   ClusterIP      1 => 10.14.0.115:2379 (active)     
