Endpoint ID: 234
Path: /sys/fs/bpf/tc/globals/cilium_policy_00234

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 695
Path: /sys/fs/bpf/tc/globals/cilium_policy_00695

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11444554   115599    0        
Allow    Ingress     1          ANY          NONE         disabled    11370424   120231    0        
Allow    Egress      0          ANY          NONE         disabled    15138027   147435    0        


Endpoint ID: 703
Path: /sys/fs/bpf/tc/globals/cilium_policy_00703

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1633362   20638     0        
Allow    Ingress     1          ANY          NONE         disabled    26522     312       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1297
Path: /sys/fs/bpf/tc/globals/cilium_policy_01297

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    173556   1996      0        
Allow    Egress      0          ANY          NONE         disabled    21268    236       0        


Endpoint ID: 3901
Path: /sys/fs/bpf/tc/globals/cilium_policy_03901

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    173783   1994      0        
Allow    Egress      0          ANY          NONE         disabled    20382    228       0        


