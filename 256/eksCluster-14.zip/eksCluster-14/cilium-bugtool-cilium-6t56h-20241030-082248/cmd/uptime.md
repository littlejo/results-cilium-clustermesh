 08:22:49 up 36 min,  0 users,  load average: 0.14, 0.17, 0.12
