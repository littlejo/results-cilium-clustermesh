KEY             VALUE
AgentLiveness   2249629677344
UTimeOffset     3379442089843750
