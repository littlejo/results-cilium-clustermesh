CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0ad505c6_c1bb_41eb_b9e4_d90c3d424173.slice/cri-containerd-b43deae93bbf97a3b23698caecb6664df9a26a98068237e699a317e023c3d0cc.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0ad505c6_c1bb_41eb_b9e4_d90c3d424173.slice/cri-containerd-f5f4478926a4992eb4fb971aaa8ce37f476c93574a971970379ddbfac850e610.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcae9661c_01ae_42b5_ac5c_fe11c29ccfc3.slice/cri-containerd-0a810efe4532f87ce5aec4b73bddfa66ce6bdef9f35a039f6ebc4956831a8fc2.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcae9661c_01ae_42b5_ac5c_fe11c29ccfc3.slice/cri-containerd-5d6fc12769a7734a1f33be58b4674175bb814a89b130f16916e35963917324d9.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3b35bd0_ed5b_4475_8151_976e3cbc0f20.slice/cri-containerd-26888cd6cb4b2f6b904c3e013a63ba960a0a39646b3f3cd7123ee96e634e320c.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3b35bd0_ed5b_4475_8151_976e3cbc0f20.slice/cri-containerd-007de0bb9665c1081d72ec44cb769956fa371eb3080f9f714a2e306492734f22.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae60225e_862c_48c2_8093_9d8f946f78ed.slice/cri-containerd-c829d6c5a61e15de9394069b2d52a61abdf59b5dc8771bae64a3e60da436c6d1.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae60225e_862c_48c2_8093_9d8f946f78ed.slice/cri-containerd-70a5618b709ea6e19874a3430e75651ea6c6906a9df9dadb8940f014181c88a2.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8dfde0a1_4b36_46e0_be8c_49f3c560aa93.slice/cri-containerd-05db0da3e49da440fc3aeb228fe44f42fcd728def9908145b60c5544fed57a50.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8dfde0a1_4b36_46e0_be8c_49f3c560aa93.slice/cri-containerd-c3fd05cf5c9c71f3bc316145a76c2fc9ee7e2968e6b27c2efbca3f4dff43bc33.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc53196a1_cbe7_42b8_b1d3_6bc33f20cdac.slice/cri-containerd-2f9deab6124a8583b2da124f14d1c728ce5c884765c6b7f32add64b14ebf2baa.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc53196a1_cbe7_42b8_b1d3_6bc33f20cdac.slice/cri-containerd-68af54f7dff210d96bfa717ef9fa4e1c9869bf135d8eeeaecf5b002540fd1ca2.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9dba2620_8685_4a53_8b15_141c9751cd25.slice/cri-containerd-8b943f6ec6a26d417a06cde88d992ac139c28df454cb857fd8a76f5557ff6380.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9dba2620_8685_4a53_8b15_141c9751cd25.slice/cri-containerd-2585c701befeca8e98b13942531079ea4bd15ecfaf10a479b8a7ea89db28d147.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9dba2620_8685_4a53_8b15_141c9751cd25.slice/cri-containerd-71144cb68691a3f681b3ff306419c37c204341a75953c85265c722c47a2e17bc.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9dba2620_8685_4a53_8b15_141c9751cd25.slice/cri-containerd-256cd24445ffcd1e03a44d49a0b0838f95e830acb86c78ee576ec04ffb011265.scope
    649      cgroup_device   multi                                          
