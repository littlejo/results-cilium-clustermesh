top - 08:22:49 up 36 min,  0 users,  load average: 0.14, 0.17, 0.12
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 55.2 us, 37.9 sy,  0.0 ni,  3.4 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   7814.2 total,   4473.8 free,   1193.9 used,   2146.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6435.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 387680  78980 S  80.0   4.8   0:50.02 cilium-+
    666 root      20   0 1240432  16380  11164 S   6.7   0.2   0:00.03 cilium-+
    734 root      20   0 1243508  17480  12680 S   6.7   0.2   0:00.01 hubble
    391 root      20   0 1229744   8128   3840 S   0.0   0.1   0:01.05 cilium-+
    644 root      20   0 1228744   3652   2976 S   0.0   0.0   0:00.00 gops
    657 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    697 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    713 root      20   0    2208    776    696 S   0.0   0.0   0:00.00 timeout
    727 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
