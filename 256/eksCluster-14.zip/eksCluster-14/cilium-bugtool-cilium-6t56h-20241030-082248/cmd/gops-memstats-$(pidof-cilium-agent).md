alloc: 133.65MB (140143112 bytes)
total-alloc: 2.42GB (2602804472 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 66195725
frees: 64890600
heap-alloc: 133.65MB (140143112 bytes)
heap-sys: 247.66MB (259694592 bytes)
heap-idle: 77.41MB (81166336 bytes)
heap-in-use: 170.26MB (178528256 bytes)
heap-released: 96.00KB (98304 bytes)
heap-objects: 1305125
stack-in-use: 64.31MB (67436544 bytes)
stack-sys: 64.31MB (67436544 bytes)
stack-mspan-inuse: 2.91MB (3049280 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1006.34KB (1030497 bytes)
gc-sys: 6.01MB (6303208 bytes)
next-gc: when heap-alloc >= 214.49MB (224905624 bytes)
last-gc: 2024-10-30 08:23:01.106393224 +0000 UTC
gc-pause-total: 16.954105ms
gc-pause: 567832
gc-pause-end: 1730276581106393224
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00031794614194062207
enable-gc: true
debug-gc: false
