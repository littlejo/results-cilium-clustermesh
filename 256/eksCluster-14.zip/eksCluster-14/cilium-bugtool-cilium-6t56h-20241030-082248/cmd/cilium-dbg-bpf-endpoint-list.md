IP ADDRESS         LOCAL ENDPOINT INFO
10.14.0.84:0       id=1297  sec_id=513120 flags=0x0000 ifindex=12  mac=CE:F6:A1:E7:0E:01 nodemac=8E:C1:E4:71:9E:2C   
10.14.0.115:0      id=695   sec_id=494570 flags=0x0000 ifindex=18  mac=26:05:EB:EA:4A:1F nodemac=56:9F:FA:38:44:2E   
172.31.145.58:0    (localhost)                                                                                       
10.14.0.25:0       (localhost)                                                                                       
10.14.0.121:0      id=703   sec_id=4     flags=0x0000 ifindex=10  mac=52:E6:5C:7C:A3:08 nodemac=7E:23:AB:FC:D2:2C    
10.14.0.243:0      id=3901  sec_id=513120 flags=0x0000 ifindex=14  mac=EE:F9:BC:F1:90:7E nodemac=86:C9:38:7C:E5:5E   
172.31.185.191:0   (localhost)                                                                                       
