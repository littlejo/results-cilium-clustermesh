key: b7 02 00 00  value: 6a 02 00 00
key: bf 02 00 00  value: 27 02 00 00
key: 11 05 00 00  value: 2e 02 00 00
key: 3d 0f 00 00  value: 18 02 00 00
Found 4 elements
