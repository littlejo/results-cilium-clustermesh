REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37561     2978719     677    bpf_overlay.c
Interface                 INGRESS     679564    137611353   1132   bpf_host.c
Success                   EGRESS      17622     1393191     1694   bpf_host.c
Success                   EGRESS      292448    35973638    1308   bpf_lxc.c
Success                   EGRESS      38874     3071831     53     encap.h
Success                   INGRESS     337019    38264329    86     l3.h
Success                   INGRESS     357609    39893903    235    trace.h
Unsupported L3 protocol   EGRESS      42        3132        1492   bpf_lxc.c
