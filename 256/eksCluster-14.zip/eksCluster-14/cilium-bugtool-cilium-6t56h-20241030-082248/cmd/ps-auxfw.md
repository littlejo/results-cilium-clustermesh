USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         666  0.0  0.2 1240432 16124 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         685  0.0  0.0   2204   792 ?        R    08:22   0:00  \_ cat /proc/net/xfrm_stat
root         686  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         657  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         644  0.0  0.0 1228744 3652 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  2.7  4.7 1606080 381080 ?      Ssl  07:52   0:49 cilium-agent --config-dir=/tmp/cilium/config-map
root         391  0.0  0.1 1229744 8128 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
