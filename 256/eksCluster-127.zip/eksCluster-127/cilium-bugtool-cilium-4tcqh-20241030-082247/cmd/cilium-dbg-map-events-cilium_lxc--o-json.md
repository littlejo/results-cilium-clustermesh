{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.492Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.197.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.493Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.225.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.493Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:56.994Z",
  "value": "id=726   sec_id=4211982 flags=0x0000 ifindex=12  mac=AA:32:76:60:41:AC nodemac=82:4A:37:DA:12:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:57.034Z",
  "value": "id=481   sec_id=4211982 flags=0x0000 ifindex=14  mac=86:76:9B:DC:90:B5 nodemac=AE:7F:93:F9:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:57.088Z",
  "value": "id=49    sec_id=4     flags=0x0000 ifindex=10  mac=72:11:A1:66:9F:97 nodemac=7A:0B:A2:38:BD:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:57.169Z",
  "value": "id=726   sec_id=4211982 flags=0x0000 ifindex=12  mac=AA:32:76:60:41:AC nodemac=82:4A:37:DA:12:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:57.236Z",
  "value": "id=481   sec_id=4211982 flags=0x0000 ifindex=14  mac=86:76:9B:DC:90:B5 nodemac=AE:7F:93:F9:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:29.347Z",
  "value": "id=726   sec_id=4211982 flags=0x0000 ifindex=12  mac=AA:32:76:60:41:AC nodemac=82:4A:37:DA:12:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:29.348Z",
  "value": "id=481   sec_id=4211982 flags=0x0000 ifindex=14  mac=86:76:9B:DC:90:B5 nodemac=AE:7F:93:F9:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:29.348Z",
  "value": "id=49    sec_id=4     flags=0x0000 ifindex=10  mac=72:11:A1:66:9F:97 nodemac=7A:0B:A2:38:BD:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:29.377Z",
  "value": "id=1486  sec_id=4226818 flags=0x0000 ifindex=16  mac=66:28:EF:DA:70:15 nodemac=F2:D5:85:7A:4F:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:29.378Z",
  "value": "id=1486  sec_id=4226818 flags=0x0000 ifindex=16  mac=66:28:EF:DA:70:15 nodemac=F2:D5:85:7A:4F:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:16.302Z",
  "value": "id=320   sec_id=4226818 flags=0x0000 ifindex=18  mac=9E:7E:1D:AF:0F:07 nodemac=AE:22:D5:63:DE:69"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.127.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:26.795Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.533Z",
  "value": "id=726   sec_id=4211982 flags=0x0000 ifindex=12  mac=AA:32:76:60:41:AC nodemac=82:4A:37:DA:12:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.533Z",
  "value": "id=481   sec_id=4211982 flags=0x0000 ifindex=14  mac=86:76:9B:DC:90:B5 nodemac=AE:7F:93:F9:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.533Z",
  "value": "id=49    sec_id=4     flags=0x0000 ifindex=10  mac=72:11:A1:66:9F:97 nodemac=7A:0B:A2:38:BD:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.534Z",
  "value": "id=320   sec_id=4226818 flags=0x0000 ifindex=18  mac=9E:7E:1D:AF:0F:07 nodemac=AE:22:D5:63:DE:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:18.542Z",
  "value": "id=481   sec_id=4211982 flags=0x0000 ifindex=14  mac=86:76:9B:DC:90:B5 nodemac=AE:7F:93:F9:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:18.542Z",
  "value": "id=49    sec_id=4     flags=0x0000 ifindex=10  mac=72:11:A1:66:9F:97 nodemac=7A:0B:A2:38:BD:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:18.545Z",
  "value": "id=320   sec_id=4226818 flags=0x0000 ifindex=18  mac=9E:7E:1D:AF:0F:07 nodemac=AE:22:D5:63:DE:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:18.545Z",
  "value": "id=726   sec_id=4211982 flags=0x0000 ifindex=12  mac=AA:32:76:60:41:AC nodemac=82:4A:37:DA:12:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.540Z",
  "value": "id=481   sec_id=4211982 flags=0x0000 ifindex=14  mac=86:76:9B:DC:90:B5 nodemac=AE:7F:93:F9:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.540Z",
  "value": "id=726   sec_id=4211982 flags=0x0000 ifindex=12  mac=AA:32:76:60:41:AC nodemac=82:4A:37:DA:12:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.540Z",
  "value": "id=320   sec_id=4226818 flags=0x0000 ifindex=18  mac=9E:7E:1D:AF:0F:07 nodemac=AE:22:D5:63:DE:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.541Z",
  "value": "id=49    sec_id=4     flags=0x0000 ifindex=10  mac=72:11:A1:66:9F:97 nodemac=7A:0B:A2:38:BD:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.540Z",
  "value": "id=49    sec_id=4     flags=0x0000 ifindex=10  mac=72:11:A1:66:9F:97 nodemac=7A:0B:A2:38:BD:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.541Z",
  "value": "id=320   sec_id=4226818 flags=0x0000 ifindex=18  mac=9E:7E:1D:AF:0F:07 nodemac=AE:22:D5:63:DE:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.541Z",
  "value": "id=726   sec_id=4211982 flags=0x0000 ifindex=12  mac=AA:32:76:60:41:AC nodemac=82:4A:37:DA:12:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.541Z",
  "value": "id=481   sec_id=4211982 flags=0x0000 ifindex=14  mac=86:76:9B:DC:90:B5 nodemac=AE:7F:93:F9:E4:6F"
}

