IP ADDRESS         LOCAL ENDPOINT INFO
10.127.0.4:0       id=726   sec_id=4211982 flags=0x0000 ifindex=12  mac=AA:32:76:60:41:AC nodemac=82:4A:37:DA:12:9B   
10.127.0.163:0     id=49    sec_id=4     flags=0x0000 ifindex=10  mac=72:11:A1:66:9F:97 nodemac=7A:0B:A2:38:BD:A5     
10.127.0.36:0      id=481   sec_id=4211982 flags=0x0000 ifindex=14  mac=86:76:9B:DC:90:B5 nodemac=AE:7F:93:F9:E4:6F   
10.127.0.95:0      (localhost)                                                                                        
10.127.0.31:0      id=320   sec_id=4226818 flags=0x0000 ifindex=18  mac=9E:7E:1D:AF:0F:07 nodemac=AE:22:D5:63:DE:69   
172.31.197.3:0     (localhost)                                                                                        
172.31.225.190:0   (localhost)                                                                                        
