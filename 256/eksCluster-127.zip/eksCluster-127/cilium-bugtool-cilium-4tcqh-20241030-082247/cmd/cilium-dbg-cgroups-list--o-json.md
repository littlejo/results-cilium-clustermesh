[
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbb2b8367_c796_4d71_9e59_4ec3ec97a1ab.slice/cri-containerd-904d96560f853ab9065743d54004674df2e45542bbd849b7751cd2c116ef6248.scope"
      }
    ],
    "ips": [
      "10.127.0.4"
    ],
    "name": "coredns-cc6ccd49c-lp7g9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd5630120_e8b2_49c5_8a8d_847f1d486ec5.slice/cri-containerd-251744f9218c5ec842af3d25dbf513357572bbe23bd22abba887d89795faa280.scope"
      }
    ],
    "ips": [
      "10.127.0.36"
    ],
    "name": "coredns-cc6ccd49c-8jnxk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd585574e_c9de_4443_a08b_74bbf6b77720.slice/cri-containerd-b5f1a9fe7486a7db64924b1f17e7766957ad7ad92902f26ba2ff7e449691b78c.scope"
      },
      {
        "cgroup-id": 9268,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd585574e_c9de_4443_a08b_74bbf6b77720.slice/cri-containerd-3d7cc59559fb15b804b9bc0147a8b19f34a1de450c773ba4c5c8af246363dad0.scope"
      },
      {
        "cgroup-id": 9184,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd585574e_c9de_4443_a08b_74bbf6b77720.slice/cri-containerd-e8cd4b3e2805c79e667e7da05f98ce8aac09ffe85ce87b4babca5ed5f94fef4e.scope"
      }
    ],
    "ips": [
      "10.127.0.31"
    ],
    "name": "clustermesh-apiserver-6b68ff948c-wfc2n",
    "namespace": "kube-system"
  }
]

