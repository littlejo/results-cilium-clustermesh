USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         685  0.0  0.1 1616008 8400 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         678  0.0  0.1 1616264 8840 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         666  0.0  0.2 1240432 16236 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         692  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         693  0.0  0.0      4     4 ?        R    08:22   0:00  \_ [bash]
root           1  3.4  4.7 1606336 382140 ?      Ssl  07:53   1:00 cilium-agent --config-dir=/tmp/cilium/config-map
root         406  0.0  0.0 1229744 6724 ?        Sl   07:53   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
