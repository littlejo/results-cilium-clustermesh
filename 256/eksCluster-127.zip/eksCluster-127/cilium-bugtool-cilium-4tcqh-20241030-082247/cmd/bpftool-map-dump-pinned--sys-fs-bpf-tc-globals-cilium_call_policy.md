key: 31 00 00 00  value: 05 02 00 00
key: 40 01 00 00  value: 74 02 00 00
key: e1 01 00 00  value: 1f 02 00 00
key: d6 02 00 00  value: 0b 02 00 00
Found 4 elements
