top - 08:22:49 up 35 min,  0 users,  load average: 0.31, 0.30, 0.20
Tasks:  10 total,   2 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 60.0 us, 36.7 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4462.2 free,   1205.7 used,   2146.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6423.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 384308  78072 S  73.3   4.8   1:00.23 cilium-+
    666 root      20   0 1240432  16236  11292 S   6.7   0.2   0:00.03 cilium-+
    737 root      20   0 1243508  18032  13120 S   6.7   0.2   0:00.01 hubble
    406 root      20   0 1229744   6724   2924 S   0.0   0.1   0:01.20 cilium-+
    678 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    685 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    710 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    717 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    731 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    762 root      20   0    2548    916    764 R   0.0   0.0   0:00.00 ipset
