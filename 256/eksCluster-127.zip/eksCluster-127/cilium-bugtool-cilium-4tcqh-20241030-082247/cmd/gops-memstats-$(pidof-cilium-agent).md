alloc: 102.08MB (107036776 bytes)
total-alloc: 2.30GB (2471891800 bytes)
sys: 337.09MB (353459572 bytes)
lookups: 0
mallocs: 64316453
frees: 63556232
heap-alloc: 102.08MB (107036776 bytes)
heap-sys: 263.76MB (276570112 bytes)
heap-idle: 104.39MB (109461504 bytes)
heap-in-use: 159.37MB (167108608 bytes)
heap-released: 12.73MB (13352960 bytes)
heap-objects: 760221
stack-in-use: 60.22MB (63143936 bytes)
stack-sys: 60.22MB (63143936 bytes)
stack-mspan-inuse: 2.74MB (2869760 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.17MB (1227305 bytes)
gc-sys: 6.11MB (6406912 bytes)
next-gc: when heap-alloc >= 211.98MB (222276664 bytes)
last-gc: 2024-10-30 08:23:15.375811944 +0000 UTC
gc-pause-total: 7.897523ms
gc-pause: 114196
gc-pause-end: 1730276595375811944
num-gc: 87
num-forced-gc: 0
gc-cpu-fraction: 0.00036473526036425244
enable-gc: true
debug-gc: false
