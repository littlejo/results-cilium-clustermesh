CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56b6a5ae_1e3e_415d_9ca4_0de1fbb7198a.slice/cri-containerd-5e752ac99ec26808f20d82e20b546c2ffe69b5251c860d9557fae163aab523ab.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56b6a5ae_1e3e_415d_9ca4_0de1fbb7198a.slice/cri-containerd-04a180a3a79cc85c1669eb4d68e6623009d88c34b271a56e33a50e3670f12c89.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd3ee5f5d_0a96_4655_87db_d60cc874031d.slice/cri-containerd-30b28ccf4ddfa0ca2e152195de005c266b2e6edc2426386dcf183b5287c34a46.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd3ee5f5d_0a96_4655_87db_d60cc874031d.slice/cri-containerd-b9648cf1f6bbc32ddeed89a7675ed1a39282177ef6f3cdcc25aee304853bc963.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbb2b8367_c796_4d71_9e59_4ec3ec97a1ab.slice/cri-containerd-a0c71a12f3913141e3453699be059c480aa7e2f61218befda16a8389c5fc1bef.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbb2b8367_c796_4d71_9e59_4ec3ec97a1ab.slice/cri-containerd-904d96560f853ab9065743d54004674df2e45542bbd849b7751cd2c116ef6248.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd5630120_e8b2_49c5_8a8d_847f1d486ec5.slice/cri-containerd-a2d22c87536d210dc5ac32ef935ae360992133a954ebbd60181c6d25a51732c6.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd5630120_e8b2_49c5_8a8d_847f1d486ec5.slice/cri-containerd-251744f9218c5ec842af3d25dbf513357572bbe23bd22abba887d89795faa280.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd585574e_c9de_4443_a08b_74bbf6b77720.slice/cri-containerd-e8cd4b3e2805c79e667e7da05f98ce8aac09ffe85ce87b4babca5ed5f94fef4e.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd585574e_c9de_4443_a08b_74bbf6b77720.slice/cri-containerd-b5f1a9fe7486a7db64924b1f17e7766957ad7ad92902f26ba2ff7e449691b78c.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd585574e_c9de_4443_a08b_74bbf6b77720.slice/cri-containerd-3d7cc59559fb15b804b9bc0147a8b19f34a1de450c773ba4c5c8af246363dad0.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd585574e_c9de_4443_a08b_74bbf6b77720.slice/cri-containerd-03274951e2628e02a916f6bf9c4acb82700acdfe2d0c731e4e52c59a94040ba7.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0aead7f2_0035_4ad5_ba7e_9a42ac2c1d7f.slice/cri-containerd-541db73d34f7bcb7b5b35763b42f362efe71f31e367c7346b87accc82a97e7b7.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0aead7f2_0035_4ad5_ba7e_9a42ac2c1d7f.slice/cri-containerd-1474ec44f41fa3d5cf9b5ef8936f1c547c26acba98eb73996672a21159a06fa9.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod775cb9f3_3d4f_412f_b554_3257d197c635.slice/cri-containerd-e3d126d1ca488b561d97ad2d5cd5852632e00b8d1781b828a7603711f7a5d3fd.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod775cb9f3_3d4f_412f_b554_3257d197c635.slice/cri-containerd-b3ec9233213be2fb73d59f94e0fd561aded0ff500b2a46204b3b0ffba5e5d6dd.scope
    102      cgroup_device   multi                                          
