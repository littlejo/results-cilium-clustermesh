{
  "action": "update",
  "desired-action": "sync",
  "key": "1",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:50.232Z",
  "value": "ANY://172.31.169.42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "2",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:50.232Z",
  "value": "ANY://172.31.233.203"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:53.140Z",
  "value": "ANY://172.31.197.3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:57.580Z",
  "value": "ANY://10.127.0.36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "5",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:57.581Z",
  "value": "ANY://10.127.0.36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:57.604Z",
  "value": "ANY://10.127.0.4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:57.604Z",
  "value": "ANY://10.127.0.4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:39.195Z",
  "value": "ANY://10.127.0.190"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "9",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:26.192Z",
  "value": "ANY://10.127.0.31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:26.303Z",
  "value": "ANY://10.127.0.190"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:27.011Z",
  "value": "\u003cnil\u003e"
}

