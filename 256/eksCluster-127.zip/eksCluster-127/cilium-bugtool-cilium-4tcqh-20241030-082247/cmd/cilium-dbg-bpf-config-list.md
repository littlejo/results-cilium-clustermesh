KEY             VALUE
AgentLiveness   2184056788565
UTimeOffset     3379442220703125
