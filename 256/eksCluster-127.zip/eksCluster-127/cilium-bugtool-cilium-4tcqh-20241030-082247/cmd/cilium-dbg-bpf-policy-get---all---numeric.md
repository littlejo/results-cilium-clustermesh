Endpoint ID: 49
Path: /sys/fs/bpf/tc/globals/cilium_policy_00049

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1636109   20638     0        
Allow    Ingress     1          ANY          NONE         disabled    25480     297       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 320
Path: /sys/fs/bpf/tc/globals/cilium_policy_00320

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11509505   114288    0        
Allow    Ingress     1          ANY          NONE         disabled    9696826    101916    0        
Allow    Egress      0          ANY          NONE         disabled    12467425   123001    0        


Endpoint ID: 481
Path: /sys/fs/bpf/tc/globals/cilium_policy_00481

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    421643   3792      0        
Allow    Ingress     1          ANY          NONE         disabled    168941   1942      0        
Allow    Egress      0          ANY          NONE         disabled    115098   1117      0        


Endpoint ID: 726
Path: /sys/fs/bpf/tc/globals/cilium_policy_00726

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    430387   3858      0        
Allow    Ingress     1          ANY          NONE         disabled    168858   1946      0        
Allow    Egress      0          ANY          NONE         disabled    118389   1146      0        


Endpoint ID: 2593
Path: /sys/fs/bpf/tc/globals/cilium_policy_02593

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


