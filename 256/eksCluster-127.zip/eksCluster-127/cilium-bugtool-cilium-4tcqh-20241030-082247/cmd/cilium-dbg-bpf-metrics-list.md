REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35241     2788451     677    bpf_overlay.c
Interface                 INGRESS     632488    131452335   1132   bpf_host.c
Success                   EGRESS      15299     1199968     1694   bpf_host.c
Success                   EGRESS      15300     2424690     86     l3.h
Success                   EGRESS      269598    33753602    1308   bpf_lxc.c
Success                   EGRESS      34814     2755781     53     encap.h
Success                   INGRESS     309677    35068921    86     l3.h
Success                   INGRESS     345570    39126140    235    trace.h
Unsupported L3 protocol   EGRESS      39        2866        1492   bpf_lxc.c
