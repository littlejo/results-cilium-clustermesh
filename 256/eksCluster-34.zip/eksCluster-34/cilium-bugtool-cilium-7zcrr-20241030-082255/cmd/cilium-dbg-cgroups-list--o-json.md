[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4dcca6b_767a_4951_9a30_78f620ab6a1e.slice/cri-containerd-b247b8e579903c3f4b7990714b0e438be6098a66a2351a94ba3855f2fd450b5b.scope"
      }
    ],
    "ips": [
      "10.34.0.178"
    ],
    "name": "coredns-cc6ccd49c-26dxf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1703bafa_c20a_4174_a4a0_0fd7f70cc3d8.slice/cri-containerd-cc867ed77b6b29b2468d0a7b60603be189ef73d7d6be78051fce005a8e8db104.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1703bafa_c20a_4174_a4a0_0fd7f70cc3d8.slice/cri-containerd-bfed00d21d38090ab553e8f369b4a353e75df91a5c998bf22d0ea4afdf6a713a.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1703bafa_c20a_4174_a4a0_0fd7f70cc3d8.slice/cri-containerd-130a31ed7b8f5be6e55820359c3a3ea9fe5964a546d96bbc49c7442d29aabc76.scope"
      }
    ],
    "ips": [
      "10.34.0.93"
    ],
    "name": "clustermesh-apiserver-85f6d6b965-slx9x",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod39784adb_cad9_479b_9987_981de1f56d28.slice/cri-containerd-918e1e0be57b7f3d4c65663413a6d350d62bbc84ac277c33428680f1760dd332.scope"
      }
    ],
    "ips": [
      "10.34.0.95"
    ],
    "name": "coredns-cc6ccd49c-299jr",
    "namespace": "kube-system"
  }
]

