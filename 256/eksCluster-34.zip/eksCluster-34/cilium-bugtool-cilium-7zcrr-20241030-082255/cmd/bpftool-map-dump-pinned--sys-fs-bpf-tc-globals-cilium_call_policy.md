key: 06 00 00 00  value: 06 02 00 00
key: b8 07 00 00  value: 23 02 00 00
key: 08 09 00 00  value: 1d 02 00 00
key: c8 0d 00 00  value: 65 02 00 00
Found 4 elements
