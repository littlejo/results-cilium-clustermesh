CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a0d9f3d_7fe6_47ba_8530_974df76dcb13.slice/cri-containerd-c0491a824649b8e2d39d4ed858d1f98dc92d976b236ff0fcbf7474e3f363a07a.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a0d9f3d_7fe6_47ba_8530_974df76dcb13.slice/cri-containerd-3f9c91acb95292f3faed7b8050f5fb05604f65643ba57ab15eb7e33a7c23f10d.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod39784adb_cad9_479b_9987_981de1f56d28.slice/cri-containerd-a6b5b0b161fa99520576716dd5f5f12152cade3854d6c9936872a657d07ae6b0.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod39784adb_cad9_479b_9987_981de1f56d28.slice/cri-containerd-918e1e0be57b7f3d4c65663413a6d350d62bbc84ac277c33428680f1760dd332.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4dcca6b_767a_4951_9a30_78f620ab6a1e.slice/cri-containerd-b247b8e579903c3f4b7990714b0e438be6098a66a2351a94ba3855f2fd450b5b.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4dcca6b_767a_4951_9a30_78f620ab6a1e.slice/cri-containerd-e0d1e758a75109da1d639df30dc5b22980bc254b35d008fa84b2913eef73bf2f.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod21a65ddb_5493_4423_b985_894d9b9209d6.slice/cri-containerd-5faa0744947df858aee906e4ff33d000f7e77feb5837b80fef9c1b69b280ada2.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod21a65ddb_5493_4423_b985_894d9b9209d6.slice/cri-containerd-20d76f3bf92b8db8c019e6725892195ebf9ad7feb43539148c163788f0d4d2ac.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddc2f3ed1_7c13_49f0_9d03_8ffa1b3f2fd2.slice/cri-containerd-0f065332919cdf2a07de7b48ce02a420444c334c9c0eaff7edcf79885b86ef73.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddc2f3ed1_7c13_49f0_9d03_8ffa1b3f2fd2.slice/cri-containerd-29f133b05cb5f160ab9a99c155d829c79cbc9e2b12e94fcc672c2b616f079c9f.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1703bafa_c20a_4174_a4a0_0fd7f70cc3d8.slice/cri-containerd-cc867ed77b6b29b2468d0a7b60603be189ef73d7d6be78051fce005a8e8db104.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1703bafa_c20a_4174_a4a0_0fd7f70cc3d8.slice/cri-containerd-130a31ed7b8f5be6e55820359c3a3ea9fe5964a546d96bbc49c7442d29aabc76.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1703bafa_c20a_4174_a4a0_0fd7f70cc3d8.slice/cri-containerd-bfed00d21d38090ab553e8f369b4a353e75df91a5c998bf22d0ea4afdf6a713a.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1703bafa_c20a_4174_a4a0_0fd7f70cc3d8.slice/cri-containerd-855816679ef43ddb5e3ae13fdb32f70b7afdab1d72ca327790128efa93685c08.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9fe6976_c66b_43e1_818f_02729b3a4857.slice/cri-containerd-464ee0e7981ebc1d353b9814cd972af5b90f93c11c90a3b87df12eb2c568404c.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9fe6976_c66b_43e1_818f_02729b3a4857.slice/cri-containerd-e69e53f51a3d0ecda0cadad939357802f7e780ad091a010698e01b7046d80517.scope
    95       cgroup_device   multi                                          
