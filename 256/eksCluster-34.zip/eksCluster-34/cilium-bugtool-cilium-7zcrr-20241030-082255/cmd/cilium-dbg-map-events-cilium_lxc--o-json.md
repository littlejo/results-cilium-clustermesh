{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:46.465Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.172.255:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:46.465Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.186.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:46.465Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:51.237Z",
  "value": "id=1976  sec_id=4     flags=0x0000 ifindex=10  mac=92:17:82:98:6E:D9 nodemac=CA:FC:D4:97:AB:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:51.248Z",
  "value": "id=6     sec_id=1148848 flags=0x0000 ifindex=12  mac=86:26:B0:B3:DB:32 nodemac=C2:93:38:3D:C1:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:51.282Z",
  "value": "id=2312  sec_id=1148848 flags=0x0000 ifindex=14  mac=66:DA:01:89:2E:93 nodemac=26:D9:0C:E3:F2:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:51.284Z",
  "value": "id=6     sec_id=1148848 flags=0x0000 ifindex=12  mac=86:26:B0:B3:DB:32 nodemac=C2:93:38:3D:C1:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:51.284Z",
  "value": "id=2312  sec_id=1148848 flags=0x0000 ifindex=14  mac=66:DA:01:89:2E:93 nodemac=26:D9:0C:E3:F2:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:51.306Z",
  "value": "id=1976  sec_id=4     flags=0x0000 ifindex=10  mac=92:17:82:98:6E:D9 nodemac=CA:FC:D4:97:AB:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:51.306Z",
  "value": "id=1976  sec_id=4     flags=0x0000 ifindex=10  mac=92:17:82:98:6E:D9 nodemac=CA:FC:D4:97:AB:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:10.897Z",
  "value": "id=6     sec_id=1148848 flags=0x0000 ifindex=12  mac=86:26:B0:B3:DB:32 nodemac=C2:93:38:3D:C1:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:10.898Z",
  "value": "id=2312  sec_id=1148848 flags=0x0000 ifindex=14  mac=66:DA:01:89:2E:93 nodemac=26:D9:0C:E3:F2:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:10.898Z",
  "value": "id=1976  sec_id=4     flags=0x0000 ifindex=10  mac=92:17:82:98:6E:D9 nodemac=CA:FC:D4:97:AB:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:10.929Z",
  "value": "id=882   sec_id=1172719 flags=0x0000 ifindex=16  mac=92:02:73:59:EC:B8 nodemac=16:97:38:A2:A1:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:11.898Z",
  "value": "id=6     sec_id=1148848 flags=0x0000 ifindex=12  mac=86:26:B0:B3:DB:32 nodemac=C2:93:38:3D:C1:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:11.898Z",
  "value": "id=882   sec_id=1172719 flags=0x0000 ifindex=16  mac=92:02:73:59:EC:B8 nodemac=16:97:38:A2:A1:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:11.899Z",
  "value": "id=2312  sec_id=1148848 flags=0x0000 ifindex=14  mac=66:DA:01:89:2E:93 nodemac=26:D9:0C:E3:F2:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:11.899Z",
  "value": "id=1976  sec_id=4     flags=0x0000 ifindex=10  mac=92:17:82:98:6E:D9 nodemac=CA:FC:D4:97:AB:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:29.851Z",
  "value": "id=3528  sec_id=1172719 flags=0x0000 ifindex=18  mac=FA:DC:3E:0B:83:D9 nodemac=42:C9:D8:18:30:DB"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.34.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.185Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:21.141Z",
  "value": "id=3528  sec_id=1172719 flags=0x0000 ifindex=18  mac=FA:DC:3E:0B:83:D9 nodemac=42:C9:D8:18:30:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:21.143Z",
  "value": "id=1976  sec_id=4     flags=0x0000 ifindex=10  mac=92:17:82:98:6E:D9 nodemac=CA:FC:D4:97:AB:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:21.143Z",
  "value": "id=6     sec_id=1148848 flags=0x0000 ifindex=12  mac=86:26:B0:B3:DB:32 nodemac=C2:93:38:3D:C1:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:21.144Z",
  "value": "id=2312  sec_id=1148848 flags=0x0000 ifindex=14  mac=66:DA:01:89:2E:93 nodemac=26:D9:0C:E3:F2:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:22.189Z",
  "value": "id=6     sec_id=1148848 flags=0x0000 ifindex=12  mac=86:26:B0:B3:DB:32 nodemac=C2:93:38:3D:C1:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:22.227Z",
  "value": "id=2312  sec_id=1148848 flags=0x0000 ifindex=14  mac=66:DA:01:89:2E:93 nodemac=26:D9:0C:E3:F2:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:22.227Z",
  "value": "id=3528  sec_id=1172719 flags=0x0000 ifindex=18  mac=FA:DC:3E:0B:83:D9 nodemac=42:C9:D8:18:30:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:22.228Z",
  "value": "id=1976  sec_id=4     flags=0x0000 ifindex=10  mac=92:17:82:98:6E:D9 nodemac=CA:FC:D4:97:AB:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.142Z",
  "value": "id=1976  sec_id=4     flags=0x0000 ifindex=10  mac=92:17:82:98:6E:D9 nodemac=CA:FC:D4:97:AB:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.142Z",
  "value": "id=6     sec_id=1148848 flags=0x0000 ifindex=12  mac=86:26:B0:B3:DB:32 nodemac=C2:93:38:3D:C1:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.142Z",
  "value": "id=3528  sec_id=1172719 flags=0x0000 ifindex=18  mac=FA:DC:3E:0B:83:D9 nodemac=42:C9:D8:18:30:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.142Z",
  "value": "id=2312  sec_id=1148848 flags=0x0000 ifindex=14  mac=66:DA:01:89:2E:93 nodemac=26:D9:0C:E3:F2:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.143Z",
  "value": "id=2312  sec_id=1148848 flags=0x0000 ifindex=14  mac=66:DA:01:89:2E:93 nodemac=26:D9:0C:E3:F2:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.143Z",
  "value": "id=3528  sec_id=1172719 flags=0x0000 ifindex=18  mac=FA:DC:3E:0B:83:D9 nodemac=42:C9:D8:18:30:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.143Z",
  "value": "id=1976  sec_id=4     flags=0x0000 ifindex=10  mac=92:17:82:98:6E:D9 nodemac=CA:FC:D4:97:AB:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.143Z",
  "value": "id=6     sec_id=1148848 flags=0x0000 ifindex=12  mac=86:26:B0:B3:DB:32 nodemac=C2:93:38:3D:C1:3C"
}

