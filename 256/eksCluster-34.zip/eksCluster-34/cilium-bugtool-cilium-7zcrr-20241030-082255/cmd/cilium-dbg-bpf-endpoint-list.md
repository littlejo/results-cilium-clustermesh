IP ADDRESS         LOCAL ENDPOINT INFO
10.34.0.94:0       id=1976  sec_id=4     flags=0x0000 ifindex=10  mac=92:17:82:98:6E:D9 nodemac=CA:FC:D4:97:AB:89     
10.34.0.95:0       id=2312  sec_id=1148848 flags=0x0000 ifindex=14  mac=66:DA:01:89:2E:93 nodemac=26:D9:0C:E3:F2:EA   
172.31.172.255:0   (localhost)                                                                                        
10.34.0.93:0       id=3528  sec_id=1172719 flags=0x0000 ifindex=18  mac=FA:DC:3E:0B:83:D9 nodemac=42:C9:D8:18:30:DB   
10.34.0.178:0      id=6     sec_id=1148848 flags=0x0000 ifindex=12  mac=86:26:B0:B3:DB:32 nodemac=C2:93:38:3D:C1:3C   
10.34.0.70:0       (localhost)                                                                                        
172.31.186.233:0   (localhost)                                                                                        
