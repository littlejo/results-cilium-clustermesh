USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         657  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         656  0.0  0.2 1240432 16676 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         699  0.0  0.0   6408  1644 ?        R    08:22   0:00  \_ ps auxfw
root         700  0.0  0.2 1240432 16676 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         654  0.0  0.0 1229000 3992 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.2  4.7 1606080 379584 ?      Ssl  07:52   0:58 cilium-agent --config-dir=/tmp/cilium/config-map
root         416  0.0  0.0 1229744 7100 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
