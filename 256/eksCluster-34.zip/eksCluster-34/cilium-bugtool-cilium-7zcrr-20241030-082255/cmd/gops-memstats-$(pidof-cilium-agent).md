alloc: 181.04MB (189835344 bytes)
total-alloc: 2.40GB (2574906000 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 65824399
frees: 63827738
heap-alloc: 181.04MB (189835344 bytes)
heap-sys: 243.38MB (255205376 bytes)
heap-idle: 40.09MB (42033152 bytes)
heap-in-use: 203.30MB (213172224 bytes)
heap-released: 1.02MB (1073152 bytes)
heap-objects: 1996661
stack-in-use: 64.59MB (67731456 bytes)
stack-sys: 64.59MB (67731456 bytes)
stack-mspan-inuse: 3.32MB (3477280 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.00MB (1052441 bytes)
gc-sys: 6.00MB (6290968 bytes)
next-gc: when heap-alloc >= 224.00MB (234877032 bytes)
last-gc: 2024-10-30 08:22:57.596932154 +0000 UTC
gc-pause-total: 25.380036ms
gc-pause: 2008073
gc-pause-end: 1730276577596932154
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00042628027427998037
enable-gc: true
debug-gc: false
