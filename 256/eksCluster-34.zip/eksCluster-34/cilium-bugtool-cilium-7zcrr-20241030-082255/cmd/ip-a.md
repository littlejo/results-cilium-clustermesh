1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:6b:e9:26:8c:9d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.186.233/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3166sec preferred_lft 3166sec
    inet6 fe80::46b:e9ff:fe26:8c9d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:1e:ed:cc:ee:d3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.172.255/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::41e:edff:fecc:eed3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:2b:99:9b:93:5d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::802b:99ff:fe9b:935d/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:6f:9f:28:6b:69 brd ff:ff:ff:ff:ff:ff
    inet 10.34.0.70/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::146f:9fff:fe28:6b69/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f2:3a:47:74:b9:22 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f03a:47ff:fe74:b922/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:fc:d4:97:ab:89 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c8fc:d4ff:fe97:ab89/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc9130d5acbbbe@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:93:38:3d:c1:3c brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c093:38ff:fe3d:c13c/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc520657ac6975@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:d9:0c:e3:f2:ea brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::24d9:cff:fee3:f2ea/64 scope link 
       valid_lft forever preferred_lft forever
18: lxced1f35778e78@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:c9:d8:18:30:db brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::40c9:d8ff:fe18:30db/64 scope link 
       valid_lft forever preferred_lft forever
