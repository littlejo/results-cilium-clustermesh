REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37150     2932463     677    bpf_overlay.c
Interface                 INGRESS     678083    137509211   1132   bpf_host.c
Success                   EGRESS      16624     1305811     1694   bpf_host.c
Success                   EGRESS      292432    35935989    1308   bpf_lxc.c
Success                   EGRESS      37689     2970636     53     encap.h
Success                   INGRESS     335156    38127394    86     l3.h
Success                   INGRESS     356206    39788694    235    trace.h
Unsupported L3 protocol   EGRESS      46        3452        1492   bpf_lxc.c
