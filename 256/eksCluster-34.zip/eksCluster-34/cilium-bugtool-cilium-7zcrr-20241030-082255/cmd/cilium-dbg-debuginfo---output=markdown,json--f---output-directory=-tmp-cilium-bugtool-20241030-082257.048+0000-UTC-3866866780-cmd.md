markdown output at /tmp/cilium-bugtool-20241030-082257.048+0000-UTC-3866866780/cmd/cilium-debuginfo-20241030-082328.34+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082257.048+0000-UTC-3866866780/cmd/cilium-debuginfo-20241030-082328.34+0000-UTC.json
