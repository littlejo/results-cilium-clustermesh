ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.138.204:443 (active)    
                                         2 => 172.31.217.225:443 (active)    
2    10.100.253.167:443   ClusterIP      1 => 172.31.186.233:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.34.0.178:9153 (active)      
                                         2 => 10.34.0.95:9153 (active)       
4    10.100.0.10:53       ClusterIP      1 => 10.34.0.178:53 (active)        
                                         2 => 10.34.0.95:53 (active)         
5    10.100.69.17:2379    ClusterIP      1 => 10.34.0.93:2379 (active)       
