Endpoint ID: 6
Path: /sys/fs/bpf/tc/globals/cilium_policy_00006

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176167   2023      0        
Allow    Egress      0          ANY          NONE         disabled    21648    242       0        


Endpoint ID: 1976
Path: /sys/fs/bpf/tc/globals/cilium_policy_01976

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1665125   21097     0        
Allow    Ingress     1          ANY          NONE         disabled    26463     312       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2312
Path: /sys/fs/bpf/tc/globals/cilium_policy_02312

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    177256   2045      0        
Allow    Egress      0          ANY          NONE         disabled    20821    234       0        


Endpoint ID: 3528
Path: /sys/fs/bpf/tc/globals/cilium_policy_03528

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11502424   116084    0        
Allow    Ingress     1          ANY          NONE         disabled    11085084   117284    0        
Allow    Egress      0          ANY          NONE         disabled    15250849   148759    0        


Endpoint ID: 4025
Path: /sys/fs/bpf/tc/globals/cilium_policy_04025

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


