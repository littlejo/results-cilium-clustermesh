Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal      1    104     16     44     32     18     12      4      2      2    863 
