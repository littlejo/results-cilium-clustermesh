1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:a5:36:32:94:d5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.238.97/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3311sec preferred_lft 3311sec
    inet6 fe80::8a5:36ff:fe32:94d5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:03:fb:22:3e:b3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.239.191/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::803:fbff:fe22:3eb3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:3b:03:be:05:3b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::483b:3ff:febe:53b/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:10:86:25:23:df brd ff:ff:ff:ff:ff:ff
    inet 10.85.0.29/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a410:86ff:fe25:23df/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 56:c0:2a:8e:de:bc brd ff:ff:ff:ff:ff:ff
    inet6 fe80::54c0:2aff:fe8e:debc/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:32:34:f3:98:e2 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::4832:34ff:fef3:98e2/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc202d39511193@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:07:54:7c:66:6f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b007:54ff:fe7c:666f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxca1c5e6a6d6fb@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:56:22:ee:11:c3 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::2c56:22ff:feee:11c3/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc9819938450a0@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:86:b6:c4:fb:63 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::5086:b6ff:fec4:fb63/64 scope link 
       valid_lft forever preferred_lft forever
