Endpoint ID: 403
Path: /sys/fs/bpf/tc/globals/cilium_policy_00403

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11649132   116134    0        
Allow    Ingress     1          ANY          NONE         disabled    9825880    103350    0        
Allow    Egress      0          ANY          NONE         disabled    12940089   127695    0        


Endpoint ID: 2327
Path: /sys/fs/bpf/tc/globals/cilium_policy_02327

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1680450   21256     0        
Allow    Ingress     1          ANY          NONE         disabled    23026     267       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3108
Path: /sys/fs/bpf/tc/globals/cilium_policy_03108

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    161612   1863      0        
Allow    Egress      0          ANY          NONE         disabled    19581    217       0        


Endpoint ID: 3213
Path: /sys/fs/bpf/tc/globals/cilium_policy_03213

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3543
Path: /sys/fs/bpf/tc/globals/cilium_policy_03543

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    159896   1837      0        
Allow    Egress      0          ANY          NONE         disabled    20631    231       0        


