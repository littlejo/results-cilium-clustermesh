key: 93 01 00 00  value: 82 02 00 00
key: 17 09 00 00  value: 2a 02 00 00
key: 24 0c 00 00  value: 1b 02 00 00
key: d7 0d 00 00  value: 11 02 00 00
Found 4 elements
