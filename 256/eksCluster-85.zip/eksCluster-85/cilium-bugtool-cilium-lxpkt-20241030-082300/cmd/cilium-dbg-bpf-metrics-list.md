REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35872     2833108     677    bpf_overlay.c
Interface                 INGRESS     642851    132261879   1132   bpf_host.c
Success                   EGRESS      15360     1204066     1694   bpf_host.c
Success                   EGRESS      274393    34063063    1308   bpf_lxc.c
Success                   EGRESS      35353     2795231     53     encap.h
Success                   INGRESS     313906    35398362    86     l3.h
Success                   INGRESS     335069    37071450    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
