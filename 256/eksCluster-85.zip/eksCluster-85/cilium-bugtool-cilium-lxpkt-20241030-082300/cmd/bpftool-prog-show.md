32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:04+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:04+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:04+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:04+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:04+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:48:04+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:48:05+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:48:05+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:48:05+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:05+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:48:10+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:48:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:48:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:48:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
492: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
495: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
496: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
499: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
500: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:55:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 136
501: sched_cls  name tail_handle_ipv4  tag 3cb14759b95e5df4  gpl
	loaded_at 2024-10-30T07:55:42+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,104
	btf_id 137
502: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:55:42+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,104
	btf_id 138
503: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:55:42+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 139
526: sched_cls  name __send_drop_notify  tag e774ff2a091df2fe  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 165
528: sched_cls  name tail_handle_ipv4  tag d6d8c5e62161a0e9  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 167
529: sched_cls  name handle_policy  tag 221a9bbf774c1174  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,112,41,80,91,39,84,75,40,37,38
	btf_id 168
530: sched_cls  name tail_ipv4_ct_ingress  tag 6cdc3c6d0aa5bfd8  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 169
531: sched_cls  name cil_from_container  tag ab90252faf63a89b  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 170
532: sched_cls  name tail_handle_arp  tag bde164123ebed3a1  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 171
533: sched_cls  name tail_ipv4_ct_egress  tag 5ec7d9b77bb40bc4  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 172
534: sched_cls  name tail_ipv4_to_endpoint  tag 746e72c3b4c443e5  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,91,39,111,40,37,38
	btf_id 173
535: sched_cls  name tail_handle_ipv4_cont  tag ac5e2d81a8412c37  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,112,41,91,82,83,39,76,74,77,111,40,37,38,81
	btf_id 174
536: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 175
537: sched_cls  name cil_from_container  tag c81791c0a9f00398  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 114,76
	btf_id 177
538: sched_cls  name tail_handle_arp  tag fd47691933bb0734  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,114
	btf_id 178
539: sched_cls  name handle_policy  tag bce04ecf30ae4716  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,114,82,83,113,41,80,105,39,84,75,40,37,38
	btf_id 179
540: sched_cls  name __send_drop_notify  tag e4164f0be5837378  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 180
542: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,114
	btf_id 182
543: sched_cls  name tail_ipv4_ct_egress  tag 5ec7d9b77bb40bc4  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 183
544: sched_cls  name tail_handle_ipv4  tag 24da4d5e02201010  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,114
	btf_id 184
545: sched_cls  name tail_ipv4_to_endpoint  tag 4063d6bc3f6d7e32  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,105,39,114,40,37,38
	btf_id 185
546: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
549: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
550: sched_cls  name tail_handle_ipv4_cont  tag 95bd82dfd228d19d  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,113,41,105,82,83,39,76,74,77,114,40,37,38,81
	btf_id 186
551: sched_cls  name tail_ipv4_ct_ingress  tag 501963c75bf231fb  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 187
552: sched_cls  name tail_ipv4_ct_ingress  tag 47b2c8c54d38f19f  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,116,84
	btf_id 189
553: sched_cls  name tail_ipv4_to_endpoint  tag 3420bff4569cdca3  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,116,41,82,83,80,106,39,117,40,37,38
	btf_id 190
554: sched_cls  name handle_policy  tag ecb79859905c39de  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,117,82,83,116,41,80,106,39,84,75,40,37,38
	btf_id 191
555: sched_cls  name tail_handle_arp  tag 33c9157eba6a0341  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 192
556: sched_cls  name tail_handle_ipv4_cont  tag dce22d2c20bf0cd1  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,116,41,106,82,83,39,76,74,77,117,40,37,38,81
	btf_id 193
557: sched_cls  name cil_from_container  tag e8c2c097ed428f32  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 117,76
	btf_id 194
558: sched_cls  name __send_drop_notify  tag bcdbfd16fbb82cb4  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 195
559: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,116,84
	btf_id 196
561: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 198
562: sched_cls  name tail_handle_ipv4  tag c700a0132a9f1d7b  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 199
563: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
566: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
568: sched_cls  name __send_drop_notify  tag e1a8a126658f42e6  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 202
570: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,120
	btf_id 204
571: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 205
572: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 206
573: sched_cls  name tail_handle_ipv4_from_host  tag f701c122c08e0fac  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 207
574: sched_cls  name tail_handle_ipv4_from_host  tag f701c122c08e0fac  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 209
576: sched_cls  name __send_drop_notify  tag e1a8a126658f42e6  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 211
579: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 214
580: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 215
581: sched_cls  name __send_drop_notify  tag e1a8a126658f42e6  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 217
582: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 218
584: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 220
586: sched_cls  name tail_handle_ipv4_from_host  tag f701c122c08e0fac  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 222
588: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,125
	btf_id 225
590: sched_cls  name tail_handle_ipv4_from_host  tag f701c122c08e0fac  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,125
	btf_id 227
592: sched_cls  name __send_drop_notify  tag e1a8a126658f42e6  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 229
593: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:55:45+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,125,75
	btf_id 230
634: sched_cls  name tail_ipv4_to_endpoint  tag 1f774d43b867a853  gpl
	loaded_at 2024-10-30T08:11:00+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,138,41,82,83,80,137,39,139,40,37,38
	btf_id 245
635: sched_cls  name tail_handle_ipv4_cont  tag 71c691c9b4797592  gpl
	loaded_at 2024-10-30T08:11:00+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,138,41,137,82,83,39,76,74,77,139,40,37,38,81
	btf_id 246
636: sched_cls  name __send_drop_notify  tag f2e56162424d1d40  gpl
	loaded_at 2024-10-30T08:11:00+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 247
638: sched_cls  name tail_ipv4_ct_ingress  tag 69299dac558deada  gpl
	loaded_at 2024-10-30T08:11:00+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 249
639: sched_cls  name tail_handle_arp  tag d721b2f76c7276a6  gpl
	loaded_at 2024-10-30T08:11:00+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,139
	btf_id 250
640: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:11:00+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,139
	btf_id 251
641: sched_cls  name tail_ipv4_ct_egress  tag d84bbb16be4762d6  gpl
	loaded_at 2024-10-30T08:11:00+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 252
642: sched_cls  name handle_policy  tag aff510e4d6f4ce27  gpl
	loaded_at 2024-10-30T08:11:00+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,139,82,83,138,41,80,137,39,84,75,40,37,38
	btf_id 253
643: sched_cls  name cil_from_container  tag 5b04578b189f6544  gpl
	loaded_at 2024-10-30T08:11:00+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 139,76
	btf_id 254
644: sched_cls  name tail_handle_ipv4  tag a9d1cca9fb119462  gpl
	loaded_at 2024-10-30T08:11:00+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,139
	btf_id 255
645: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
648: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
665: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
668: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
669: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
672: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
