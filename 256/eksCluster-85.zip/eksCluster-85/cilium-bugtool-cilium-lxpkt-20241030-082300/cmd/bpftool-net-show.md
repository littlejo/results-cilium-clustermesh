xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 582
ens6(5) clsact/ingress cil_from_netdev-ens6 id 593
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 580
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 572
cilium_host(7) clsact/egress cil_from_host-cilium_host id 570
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 502
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 503
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 557
lxc202d39511193(12) clsact/ingress cil_from_container-lxc202d39511193 id 531
lxca1c5e6a6d6fb(14) clsact/ingress cil_from_container-lxca1c5e6a6d6fb id 537
lxc9819938450a0(18) clsact/ingress cil_from_container-lxc9819938450a0 id 643

flow_dissector:

netfilter:

