top - 08:23:01 up 34 min,  0 users,  load average: 0.71, 0.37, 0.23
Tasks:   9 total,   2 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 50.0 us, 31.2 sy,  0.0 ni, 18.8 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4456.2 free,   1211.6 used,   2146.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6417.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 391820  78656 S  80.0   4.9   1:00.68 cilium-+
    650 root      20   0 1229384  27072   4004 S  20.0   0.3   0:00.03 gops
    417 root      20   0 1229744   7228   2864 S   0.0   0.1   0:01.22 cilium-+
    662 root      20   0 1240432  16596  11484 S   0.0   0.2   0:00.02 cilium-+
    673 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    685 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    711 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    732 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    750 root      20   0    3852   1288   1136 R   0.0   0.0   0:00.00 bash
