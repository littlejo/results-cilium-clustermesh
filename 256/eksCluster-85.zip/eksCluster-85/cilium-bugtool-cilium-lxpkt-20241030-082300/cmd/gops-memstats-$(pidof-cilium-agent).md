alloc: 198.76MB (208412800 bytes)
total-alloc: 2.27GB (2438384192 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 63714028
frees: 61645928
heap-alloc: 198.76MB (208412800 bytes)
heap-sys: 243.89MB (255737856 bytes)
heap-idle: 18.82MB (19734528 bytes)
heap-in-use: 225.07MB (236003328 bytes)
heap-released: 192.00KB (196608 bytes)
heap-objects: 2068100
stack-in-use: 64.06MB (67174400 bytes)
stack-sys: 64.06MB (67174400 bytes)
stack-mspan-inuse: 3.52MB (3688800 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 961.84KB (984929 bytes)
gc-sys: 6.03MB (6319568 bytes)
next-gc: when heap-alloc >= 212.43MB (222752072 bytes)
last-gc: 2024-10-30 08:22:58.665081841 +0000 UTC
gc-pause-total: 20.694587ms
gc-pause: 115739
gc-pause-end: 1730276578665081841
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.00035144945692628976
enable-gc: true
debug-gc: false
