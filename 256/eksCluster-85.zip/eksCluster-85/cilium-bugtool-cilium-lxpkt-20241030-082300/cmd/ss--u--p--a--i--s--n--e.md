Total: 678
TCP:   1878 (estab 445, closed 1414, orphaned 0, timewait 568)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  464       452       12       
INET	  474       458       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                   172.31.238.97%ens5:68         0.0.0.0:*    uid:192 ino:69140 sk:3fd cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:32644 sk:3fe cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15429 sk:3ff cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:38117      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:32539 sk:400 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:32643 sk:401 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15430 sk:402 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::8a5:36ff:fe32:94d5]%ens5:546           [::]:*    uid:192 ino:16490 sk:403 cgroup:unreachable:c4e v6only:1 <->                   
