CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ef57c2a_671b_4ada_a9e6_9ccdabb9c58f.slice/cri-containerd-893fc5ba7cf5efb23df939be7bf4d41afefb29633cc80570dc817c79f87b76e0.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ef57c2a_671b_4ada_a9e6_9ccdabb9c58f.slice/cri-containerd-bfc84c90d96b6d431f8602b708504b934d0e93ad1f652942f47cd3af103b00d9.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9a1058c_bbde_4136_8ff0_aaccc972d8dc.slice/cri-containerd-a29ca070c567b304af125305a794193933cd582219858354a56cdd9638abd723.scope
    495      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9a1058c_bbde_4136_8ff0_aaccc972d8dc.slice/cri-containerd-32a752ce5d299e7c9f2d3dfe5e5194b95196ff3cf0b48d1718f74d77b5e8aef7.scope
    499      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod59b6ddbd_1504_4747_b622_2497574c88ca.slice/cri-containerd-e27ac672c2c9c2354c1409f968633208ebc3d5d232aae2b66cdcf05a8af90a18.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod59b6ddbd_1504_4747_b622_2497574c88ca.slice/cri-containerd-dbb00e2b890ecf014a1c01a754f51fa9269fd1da527bb0cede65df493036e13c.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca330551_5067_4244_8e5b_ff1aa6df24a7.slice/cri-containerd-9f599ff422f834e7402269e56e026192d2fb8a91efd721a7062d9a822bae7fce.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca330551_5067_4244_8e5b_ff1aa6df24a7.slice/cri-containerd-0bb7c50c905a32c92805351fc81c8bfa5f77959d0cd02e66d98d60292e529e04.scope
    566      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3857c5c_c90b_45c0_821d_7d9aa7ed7291.slice/cri-containerd-dbb76984dd3c565192a5dd1e8b8ce5833f76c75b646d0b46b192ae16fdcb386e.scope
    648      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3857c5c_c90b_45c0_821d_7d9aa7ed7291.slice/cri-containerd-5385b110fa798d9e204dd345954c67461be1e467a3861937a6ff97998e8815ef.scope
    668      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3857c5c_c90b_45c0_821d_7d9aa7ed7291.slice/cri-containerd-4a8e3494eb5af38362985686f501e32994820feb801620b6c80ac9b49606a836.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3857c5c_c90b_45c0_821d_7d9aa7ed7291.slice/cri-containerd-465a24cba301d97c0b2cc271299b7bbdc9df9d9756329577e0eda143c010c4c0.scope
    672      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56b25742_9cfa_4bc8_a36a_71a9924b420a.slice/cri-containerd-eaaecc857e2dad0a14afedbf1b42655f088d7c88d30c8ec45a672b3befbaac14.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56b25742_9cfa_4bc8_a36a_71a9924b420a.slice/cri-containerd-69438e565e3fc32670ae4806cda64cb003b670a7e9d668803cbfdfb90e8241e3.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55763134_2500_4416_99f7_7d4403e69bb2.slice/cri-containerd-22df426a3d52b1295dda1c18b3ae323e1a16595a0e687e853ee84f391bf8a02c.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55763134_2500_4416_99f7_7d4403e69bb2.slice/cri-containerd-d247b3ae86b6f9fae9b384c31640f5eea5b36ff2a4a703caefb2adb0e27a5760.scope
    106      cgroup_device   multi                                          
