IP ADDRESS         LOCAL ENDPOINT INFO
10.85.0.246:0      id=3543  sec_id=2821347 flags=0x0000 ifindex=12  mac=AA:63:97:88:0E:F6 nodemac=B2:07:54:7C:66:6F   
10.85.0.120:0      id=3108  sec_id=2821347 flags=0x0000 ifindex=14  mac=46:22:0D:00:23:98 nodemac=2E:56:22:EE:11:C3   
10.85.0.69:0       id=403   sec_id=2819486 flags=0x0000 ifindex=18  mac=52:40:D7:C5:11:C1 nodemac=52:86:B6:C4:FB:63   
172.31.238.97:0    (localhost)                                                                                        
172.31.239.191:0   (localhost)                                                                                        
10.85.0.116:0      id=2327  sec_id=4     flags=0x0000 ifindex=10  mac=06:03:0C:2C:40:E4 nodemac=4A:32:34:F3:98:E2     
10.85.0.29:0       (localhost)                                                                                        
