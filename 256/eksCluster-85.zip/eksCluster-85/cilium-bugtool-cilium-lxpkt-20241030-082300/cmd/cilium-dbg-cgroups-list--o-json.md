[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca330551_5067_4244_8e5b_ff1aa6df24a7.slice/cri-containerd-0bb7c50c905a32c92805351fc81c8bfa5f77959d0cd02e66d98d60292e529e04.scope"
      }
    ],
    "ips": [
      "10.85.0.120"
    ],
    "name": "coredns-cc6ccd49c-2kjwj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3857c5c_c90b_45c0_821d_7d9aa7ed7291.slice/cri-containerd-465a24cba301d97c0b2cc271299b7bbdc9df9d9756329577e0eda143c010c4c0.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3857c5c_c90b_45c0_821d_7d9aa7ed7291.slice/cri-containerd-5385b110fa798d9e204dd345954c67461be1e467a3861937a6ff97998e8815ef.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3857c5c_c90b_45c0_821d_7d9aa7ed7291.slice/cri-containerd-4a8e3494eb5af38362985686f501e32994820feb801620b6c80ac9b49606a836.scope"
      }
    ],
    "ips": [
      "10.85.0.69"
    ],
    "name": "clustermesh-apiserver-778f7f487f-j2m66",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7619,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9a1058c_bbde_4136_8ff0_aaccc972d8dc.slice/cri-containerd-32a752ce5d299e7c9f2d3dfe5e5194b95196ff3cf0b48d1718f74d77b5e8aef7.scope"
      }
    ],
    "ips": [
      "10.85.0.246"
    ],
    "name": "coredns-cc6ccd49c-zmkrh",
    "namespace": "kube-system"
  }
]

