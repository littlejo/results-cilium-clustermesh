USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         711  0.0  0.1 1616264 8772 ?        Ssl  08:23   0:00 /usr/sbin/runc init
root         685  0.0  0.0 1228744 3600 ?        Ssl  08:23   0:00 /bin/gops pprof-heap 1
root         673  0.0  0.0 1228744 3600 ?        Ssl  08:23   0:00 /bin/gops pprof-cpu 1
root         667  0.0  0.0 1229000 4052 ?        Ssl  08:23   0:00 /bin/gops stats 1
root         662  0.0  0.2 1240432 16596 ?       Ssl  08:23   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         717  0.0  0.0   6408  1652 ?        R    08:23   0:00  \_ ps auxfw
root         720  0.0  0.0   4104   740 ?        R    08:23   0:00  \_ ip a
root         650  0.0  0.0 1228744 3776 ?        Ssl  08:23   0:00 /bin/gops stack 1
root           1  3.6  4.8 1606080 384692 ?      Rsl  07:55   1:00 cilium-agent --config-dir=/tmp/cilium/config-map
root         417  0.0  0.0 1229744 7228 ?        Sl   07:55   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
