{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:38.188Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.238.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:38.188Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.239.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:38.188Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:41.231Z",
  "value": "id=3543  sec_id=2821347 flags=0x0000 ifindex=12  mac=AA:63:97:88:0E:F6 nodemac=B2:07:54:7C:66:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:44.406Z",
  "value": "id=3108  sec_id=2821347 flags=0x0000 ifindex=14  mac=46:22:0D:00:23:98 nodemac=2E:56:22:EE:11:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:44.407Z",
  "value": "id=2327  sec_id=4     flags=0x0000 ifindex=10  mac=06:03:0C:2C:40:E4 nodemac=4A:32:34:F3:98:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:44.476Z",
  "value": "id=3543  sec_id=2821347 flags=0x0000 ifindex=12  mac=AA:63:97:88:0E:F6 nodemac=B2:07:54:7C:66:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:44.551Z",
  "value": "id=3108  sec_id=2821347 flags=0x0000 ifindex=14  mac=46:22:0D:00:23:98 nodemac=2E:56:22:EE:11:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:44.616Z",
  "value": "id=2327  sec_id=4     flags=0x0000 ifindex=10  mac=06:03:0C:2C:40:E4 nodemac=4A:32:34:F3:98:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:35.839Z",
  "value": "id=3108  sec_id=2821347 flags=0x0000 ifindex=14  mac=46:22:0D:00:23:98 nodemac=2E:56:22:EE:11:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:35.839Z",
  "value": "id=3543  sec_id=2821347 flags=0x0000 ifindex=12  mac=AA:63:97:88:0E:F6 nodemac=B2:07:54:7C:66:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:35.840Z",
  "value": "id=2327  sec_id=4     flags=0x0000 ifindex=10  mac=06:03:0C:2C:40:E4 nodemac=4A:32:34:F3:98:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:35.878Z",
  "value": "id=1172  sec_id=2819486 flags=0x0000 ifindex=16  mac=F6:60:34:21:F6:F4 nodemac=C2:10:34:F8:BA:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:35.878Z",
  "value": "id=1172  sec_id=2819486 flags=0x0000 ifindex=16  mac=F6:60:34:21:F6:F4 nodemac=C2:10:34:F8:BA:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.162Z",
  "value": "id=403   sec_id=2819486 flags=0x0000 ifindex=18  mac=52:40:D7:C5:11:C1 nodemac=52:86:B6:C4:FB:63"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.85.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.487Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.295Z",
  "value": "id=3108  sec_id=2821347 flags=0x0000 ifindex=14  mac=46:22:0D:00:23:98 nodemac=2E:56:22:EE:11:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.296Z",
  "value": "id=2327  sec_id=4     flags=0x0000 ifindex=10  mac=06:03:0C:2C:40:E4 nodemac=4A:32:34:F3:98:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.296Z",
  "value": "id=403   sec_id=2819486 flags=0x0000 ifindex=18  mac=52:40:D7:C5:11:C1 nodemac=52:86:B6:C4:FB:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.297Z",
  "value": "id=3543  sec_id=2821347 flags=0x0000 ifindex=12  mac=AA:63:97:88:0E:F6 nodemac=B2:07:54:7C:66:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.297Z",
  "value": "id=2327  sec_id=4     flags=0x0000 ifindex=10  mac=06:03:0C:2C:40:E4 nodemac=4A:32:34:F3:98:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.297Z",
  "value": "id=403   sec_id=2819486 flags=0x0000 ifindex=18  mac=52:40:D7:C5:11:C1 nodemac=52:86:B6:C4:FB:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.299Z",
  "value": "id=3543  sec_id=2821347 flags=0x0000 ifindex=12  mac=AA:63:97:88:0E:F6 nodemac=B2:07:54:7C:66:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.300Z",
  "value": "id=3108  sec_id=2821347 flags=0x0000 ifindex=14  mac=46:22:0D:00:23:98 nodemac=2E:56:22:EE:11:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.297Z",
  "value": "id=3543  sec_id=2821347 flags=0x0000 ifindex=12  mac=AA:63:97:88:0E:F6 nodemac=B2:07:54:7C:66:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.297Z",
  "value": "id=3108  sec_id=2821347 flags=0x0000 ifindex=14  mac=46:22:0D:00:23:98 nodemac=2E:56:22:EE:11:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.297Z",
  "value": "id=2327  sec_id=4     flags=0x0000 ifindex=10  mac=06:03:0C:2C:40:E4 nodemac=4A:32:34:F3:98:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.298Z",
  "value": "id=403   sec_id=2819486 flags=0x0000 ifindex=18  mac=52:40:D7:C5:11:C1 nodemac=52:86:B6:C4:FB:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.298Z",
  "value": "id=403   sec_id=2819486 flags=0x0000 ifindex=18  mac=52:40:D7:C5:11:C1 nodemac=52:86:B6:C4:FB:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.298Z",
  "value": "id=3543  sec_id=2821347 flags=0x0000 ifindex=12  mac=AA:63:97:88:0E:F6 nodemac=B2:07:54:7C:66:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.299Z",
  "value": "id=3108  sec_id=2821347 flags=0x0000 ifindex=14  mac=46:22:0D:00:23:98 nodemac=2E:56:22:EE:11:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.85.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.299Z",
  "value": "id=2327  sec_id=4     flags=0x0000 ifindex=10  mac=06:03:0C:2C:40:E4 nodemac=4A:32:34:F3:98:E2"
}

