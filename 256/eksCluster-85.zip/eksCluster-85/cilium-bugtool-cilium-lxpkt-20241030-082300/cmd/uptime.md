 08:23:01 up 34 min,  0 users,  load average: 0.71, 0.37, 0.23
