KEY             VALUE
AgentLiveness   2131746349105
UTimeOffset     3379442345703125
