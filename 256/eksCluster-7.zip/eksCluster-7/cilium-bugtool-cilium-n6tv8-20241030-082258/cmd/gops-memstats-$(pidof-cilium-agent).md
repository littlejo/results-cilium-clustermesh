alloc: 151.86MB (159232000 bytes)
total-alloc: 2.29GB (2461097184 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 64035137
frees: 62452362
heap-alloc: 151.86MB (159232000 bytes)
heap-sys: 251.55MB (263766016 bytes)
heap-idle: 68.47MB (71794688 bytes)
heap-in-use: 183.08MB (191971328 bytes)
heap-released: 7.34MB (7692288 bytes)
heap-objects: 1582775
stack-in-use: 64.41MB (67534848 bytes)
stack-sys: 64.41MB (67534848 bytes)
stack-mspan-inuse: 3.06MB (3212160 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1009.27KB (1033489 bytes)
gc-sys: 6.02MB (6315520 bytes)
next-gc: when heap-alloc >= 213.51MB (223882904 bytes)
last-gc: 2024-10-30 08:23:05.789095766 +0000 UTC
gc-pause-total: 17.670162ms
gc-pause: 89877
gc-pause-end: 1730276585789095766
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00038393769512374084
enable-gc: true
debug-gc: false
