[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod911b8f5f_af7c_47df_ab63_2303ca0375a7.slice/cri-containerd-40341096060a3035564d70c11716b3ef2a4731287eee00bb5e3db12416b70dc4.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod911b8f5f_af7c_47df_ab63_2303ca0375a7.slice/cri-containerd-f84f5bc4c21f4fd91be4fe9fc54edc82730fd46732bdd904d3d1e6c7df26a221.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod911b8f5f_af7c_47df_ab63_2303ca0375a7.slice/cri-containerd-6622a8a7d533c7b714b9b99179e27d4a54944c68e1467d015f068ee5bb850a36.scope"
      }
    ],
    "ips": [
      "10.7.0.89"
    ],
    "name": "clustermesh-apiserver-5d985cb5c8-rr2p4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5f8a1234_3819_4e37_ab29_fdcb129a9923.slice/cri-containerd-7c5ac4d8b34435362e3684318d292bdb751a9cf4989902a79fb16ba5f8521370.scope"
      }
    ],
    "ips": [
      "10.7.0.147"
    ],
    "name": "coredns-cc6ccd49c-4rsfh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbca957ab_9382_4df8_880f_d217dc12035d.slice/cri-containerd-886a11951ae62ac012c51346547eb3a9803abbb6e6712d82442f22f84057fb08.scope"
      }
    ],
    "ips": [
      "10.7.0.114"
    ],
    "name": "coredns-cc6ccd49c-z2k76",
    "namespace": "kube-system"
  }
]

