CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbca957ab_9382_4df8_880f_d217dc12035d.slice/cri-containerd-886a11951ae62ac012c51346547eb3a9803abbb6e6712d82442f22f84057fb08.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbca957ab_9382_4df8_880f_d217dc12035d.slice/cri-containerd-36a6f16a8cb825d4455f2d151c93934e159de65e770faf65ea89fd9833a62ee8.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda3fb1b19_2a33_4691_953c_5f52b8b22619.slice/cri-containerd-7dbc39e67dde123be62561601ecca27ac2e42f5181a6f4d274a4c8df869ed095.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda3fb1b19_2a33_4691_953c_5f52b8b22619.slice/cri-containerd-143eb3ca64c3ef5f1a507c2eda713439dcd914d7495235b1f67d8b17df414727.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d9d9a3f_3731_4229_8961_87b54ee2dd0e.slice/cri-containerd-c936eee6d6378a9cbffa02578d9812c38252d1d7a9a2e70ca69d4108fb9ecb00.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d9d9a3f_3731_4229_8961_87b54ee2dd0e.slice/cri-containerd-68c7f0950f40a3d9f7be4d5e861852cab7605e8d4c03570f97be0b420dbb4f15.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5f8a1234_3819_4e37_ab29_fdcb129a9923.slice/cri-containerd-ec539033a4da063c5b992333f8515d28ef8657d3620b5333692f01e5abdd250b.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5f8a1234_3819_4e37_ab29_fdcb129a9923.slice/cri-containerd-7c5ac4d8b34435362e3684318d292bdb751a9cf4989902a79fb16ba5f8521370.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddc348bb9_5696_47d2_8675_bdfb7bd00daf.slice/cri-containerd-c6b900915898bd4e51035f514bfca26d91a45e4a4f3854501ecd9bb639898313.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddc348bb9_5696_47d2_8675_bdfb7bd00daf.slice/cri-containerd-a0b227ebfab61030de8fa2eeb10940e377fa25fc78ba31575bec67d29af8238b.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a302784_a517_43fe_aaac_b5f21a5900a1.slice/cri-containerd-2408a5b647aa621444fa838d2184d00b9876adedd0e899c6019f34d58dcaee50.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a302784_a517_43fe_aaac_b5f21a5900a1.slice/cri-containerd-8c25d8d84d6ba5186db4ee983f1a5da6f25206fd80a79aee28421a5a8e430b91.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod911b8f5f_af7c_47df_ab63_2303ca0375a7.slice/cri-containerd-392394eb648c30fd068e0d13c624e5d6e80f7a4b65b28f40ebcc65532f8112b6.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod911b8f5f_af7c_47df_ab63_2303ca0375a7.slice/cri-containerd-f84f5bc4c21f4fd91be4fe9fc54edc82730fd46732bdd904d3d1e6c7df26a221.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod911b8f5f_af7c_47df_ab63_2303ca0375a7.slice/cri-containerd-6622a8a7d533c7b714b9b99179e27d4a54944c68e1467d015f068ee5bb850a36.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod911b8f5f_af7c_47df_ab63_2303ca0375a7.slice/cri-containerd-40341096060a3035564d70c11716b3ef2a4731287eee00bb5e3db12416b70dc4.scope
    657      cgroup_device   multi                                          
