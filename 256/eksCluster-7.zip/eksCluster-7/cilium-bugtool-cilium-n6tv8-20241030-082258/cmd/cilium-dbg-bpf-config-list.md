KEY             VALUE
AgentLiveness   2200807513849
UTimeOffset     3379442207031250
