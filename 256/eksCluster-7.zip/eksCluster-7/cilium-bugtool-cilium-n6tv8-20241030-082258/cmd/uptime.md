 08:23:00 up 36 min,  0 users,  load average: 2.15, 0.52, 0.23
