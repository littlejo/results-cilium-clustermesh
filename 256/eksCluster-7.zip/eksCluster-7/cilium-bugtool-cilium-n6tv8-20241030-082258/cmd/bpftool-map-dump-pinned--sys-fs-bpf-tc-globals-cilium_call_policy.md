key: 6b 00 00 00  value: 06 02 00 00
key: 9a 01 00 00  value: 73 02 00 00
key: c7 09 00 00  value: 01 02 00 00
key: 0d 0c 00 00  value: 1b 02 00 00
Found 4 elements
