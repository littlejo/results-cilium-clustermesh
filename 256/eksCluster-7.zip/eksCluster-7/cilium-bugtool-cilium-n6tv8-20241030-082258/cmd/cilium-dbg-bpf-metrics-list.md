REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35779     2824246     677    bpf_overlay.c
Interface                 INGRESS     641209    132627405   1132   bpf_host.c
Success                   EGRESS      15299     1199152     1694   bpf_host.c
Success                   EGRESS      274757    34236657    1308   bpf_lxc.c
Success                   EGRESS      35324     2793100     53     encap.h
Success                   INGRESS     315754    35704584    86     l3.h
Success                   INGRESS     336758    37364326    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
