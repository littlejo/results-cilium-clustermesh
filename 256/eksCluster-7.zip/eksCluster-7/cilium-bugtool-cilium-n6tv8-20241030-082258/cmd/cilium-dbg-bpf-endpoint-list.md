IP ADDRESS         LOCAL ENDPOINT INFO
10.7.0.89:0        id=410   sec_id=294025 flags=0x0000 ifindex=18  mac=BE:77:CD:17:F9:90 nodemac=CA:FD:9D:DD:9F:34   
172.31.250.177:0   (localhost)                                                                                       
10.7.0.157:0       id=2503  sec_id=4     flags=0x0000 ifindex=10  mac=F6:E0:CC:44:E4:4B nodemac=C2:CE:75:45:D3:FB    
10.7.0.216:0       (localhost)                                                                                       
10.7.0.147:0       id=3085  sec_id=285073 flags=0x0000 ifindex=14  mac=8E:7F:46:A7:AD:A6 nodemac=26:93:21:D3:15:4F   
10.7.0.114:0       id=107   sec_id=285073 flags=0x0000 ifindex=12  mac=4E:76:8F:10:40:92 nodemac=5E:F6:A4:FF:9B:5A   
172.31.206.63:0    (localhost)                                                                                       
