USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         698  0.0  0.0   2208   796 ?        Ss   08:22   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         708  0.0  0.2 1244340 22140 ?       Sl   08:22   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root         688  0.0  0.2 1240432 16756 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         718  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         720  0.0  0.2 1240432 16756 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         678  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         658  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  2.9  4.8 1606080 391792 ?      Ssl  07:53   0:52 cilium-agent --config-dir=/tmp/cilium/config-map
root         404  0.0  0.0 1229744 7864 ?        Sl   07:53   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
