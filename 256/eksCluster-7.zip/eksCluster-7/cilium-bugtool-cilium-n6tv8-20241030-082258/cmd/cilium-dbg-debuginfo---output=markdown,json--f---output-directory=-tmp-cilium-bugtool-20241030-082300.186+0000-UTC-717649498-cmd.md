markdown output at /tmp/cilium-bugtool-20241030-082300.186+0000-UTC-717649498/cmd/cilium-debuginfo-20241030-082331.067+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082300.186+0000-UTC-717649498/cmd/cilium-debuginfo-20241030-082331.067+0000-UTC.json
