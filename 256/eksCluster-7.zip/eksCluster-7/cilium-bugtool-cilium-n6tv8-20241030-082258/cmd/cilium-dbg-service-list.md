ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.188.253:443 (active)    
                                         2 => 172.31.249.143:443 (active)    
2    10.100.77.239:443    ClusterIP      1 => 172.31.250.177:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.7.0.114:53 (active)         
                                         2 => 10.7.0.147:53 (active)         
4    10.100.0.10:9153     ClusterIP      1 => 10.7.0.114:9153 (active)       
                                         2 => 10.7.0.147:9153 (active)       
5    10.100.254.52:2379   ClusterIP      1 => 10.7.0.89:2379 (active)        
