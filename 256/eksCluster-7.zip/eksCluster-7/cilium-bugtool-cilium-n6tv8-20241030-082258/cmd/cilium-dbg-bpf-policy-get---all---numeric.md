Endpoint ID: 107
Path: /sys/fs/bpf/tc/globals/cilium_policy_00107

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    172395   1989      0        
Allow    Egress      0          ANY          NONE         disabled    20219    225       0        


Endpoint ID: 410
Path: /sys/fs/bpf/tc/globals/cilium_policy_00410

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11616021   116035    0        
Allow    Ingress     1          ANY          NONE         disabled    9859568    103436    0        
Allow    Egress      0          ANY          NONE         disabled    13283110   130742    0        


Endpoint ID: 1102
Path: /sys/fs/bpf/tc/globals/cilium_policy_01102

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2503
Path: /sys/fs/bpf/tc/globals/cilium_policy_02503

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1660801   21019     0        
Allow    Ingress     1          ANY          NONE         disabled    25092     293       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3085
Path: /sys/fs/bpf/tc/globals/cilium_policy_03085

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    171207   1971      0        
Allow    Egress      0          ANY          NONE         disabled    22254    249       0        


