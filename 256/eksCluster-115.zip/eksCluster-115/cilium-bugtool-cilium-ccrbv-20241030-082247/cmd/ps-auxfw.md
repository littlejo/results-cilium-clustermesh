USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         628  0.0  0.2 1240176 16368 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         672  0.0  0.0   6408  1636 ?        R    08:22   0:00  \_ ps auxfw
root         675  0.0  0.0   4220   828 ?        R    08:22   0:00  \_ ip -4 r
root           1  3.4  4.7 1606336 379528 ?      Ssl  07:53   1:00 cilium-agent --config-dir=/tmp/cilium/config-map
root         420  0.0  0.0 1229744 7972 ?        Sl   07:53   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
