xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 506
ens6(5) clsact/ingress cil_from_netdev-ens6 id 515
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 498
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 493
cilium_host(7) clsact/egress cil_from_host-cilium_host id 489
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 546
lxc436c0fc8ed0f(12) clsact/ingress cil_from_container-lxc436c0fc8ed0f id 539
lxc51f371385de3(14) clsact/ingress cil_from_container-lxc51f371385de3 id 534
lxc3c827579de33(18) clsact/ingress cil_from_container-lxc3c827579de33 id 616

flow_dissector:

netfilter:

