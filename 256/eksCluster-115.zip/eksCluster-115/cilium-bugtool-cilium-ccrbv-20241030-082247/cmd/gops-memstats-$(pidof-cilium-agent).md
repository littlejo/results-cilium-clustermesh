alloc: 115.03MB (120614536 bytes)
total-alloc: 2.35GB (2523889736 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 64991515
frees: 64269419
heap-alloc: 115.03MB (120614536 bytes)
heap-sys: 251.29MB (263495680 bytes)
heap-idle: 68.91MB (72253440 bytes)
heap-in-use: 182.38MB (191242240 bytes)
heap-released: 696.00KB (712704 bytes)
heap-objects: 722096
stack-in-use: 60.69MB (63635456 bytes)
stack-sys: 60.69MB (63635456 bytes)
stack-mspan-inuse: 2.89MB (3033760 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.21MB (1267569 bytes)
gc-sys: 5.99MB (6276512 bytes)
next-gc: when heap-alloc >= 212.08MB (222381656 bytes)
last-gc: 2024-10-30 08:23:18.398453179 +0000 UTC
gc-pause-total: 14.734005ms
gc-pause: 112379
gc-pause-end: 1730276598398453179
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00036401090431787314
enable-gc: true
debug-gc: false
