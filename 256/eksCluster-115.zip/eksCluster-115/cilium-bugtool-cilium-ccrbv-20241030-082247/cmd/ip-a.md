1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:da:0c:ec:98:87 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.254.132/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3256sec preferred_lft 3256sec
    inet6 fe80::8da:cff:feec:9887/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:e3:dd:cc:cd:59 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.218.239/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8e3:ddff:fecc:cd59/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:33:f4:aa:da:3d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8433:f4ff:feaa:da3d/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:e1:2a:54:95:fb brd ff:ff:ff:ff:ff:ff
    inet 10.115.0.3/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c4e1:2aff:fe54:95fb/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 9a:a0:99:7f:98:6e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::98a0:99ff:fe7f:986e/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:ca:ae:84:26:04 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::8cca:aeff:fe84:2604/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc436c0fc8ed0f@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:37:26:ea:86:da brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::bc37:26ff:feea:86da/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc51f371385de3@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:01:db:0d:26:da brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c401:dbff:fe0d:26da/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc3c827579de33@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:87:4b:95:0c:f7 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d087:4bff:fe95:cf7/64 scope link 
       valid_lft forever preferred_lft forever
