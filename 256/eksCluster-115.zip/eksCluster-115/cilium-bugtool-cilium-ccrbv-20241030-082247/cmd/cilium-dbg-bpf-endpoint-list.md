IP ADDRESS         LOCAL ENDPOINT INFO
10.115.0.241:0     id=141   sec_id=4     flags=0x0000 ifindex=10  mac=F6:4C:0F:E3:94:91 nodemac=8E:CA:AE:84:26:04     
10.115.0.3:0       (localhost)                                                                                        
10.115.0.26:0      id=3239  sec_id=3808679 flags=0x0000 ifindex=18  mac=1E:88:6B:28:35:62 nodemac=D2:87:4B:95:0C:F7   
10.115.0.226:0     id=3341  sec_id=3812883 flags=0x0000 ifindex=12  mac=FA:95:3D:DA:C2:A0 nodemac=BE:37:26:EA:86:DA   
10.115.0.100:0     id=198   sec_id=3812883 flags=0x0000 ifindex=14  mac=7E:E6:C3:80:D5:93 nodemac=C6:01:DB:0D:26:DA   
172.31.254.132:0   (localhost)                                                                                        
172.31.218.239:0   (localhost)                                                                                        
