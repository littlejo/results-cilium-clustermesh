[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1452e7f4_d4a1_4e12_ae6d_6d5cbe27bd17.slice/cri-containerd-c05bc4c800018f9e09708c10a80e991823297c40f9307e21882ea4ab0000de5e.scope"
      }
    ],
    "ips": [
      "10.115.0.100"
    ],
    "name": "coredns-cc6ccd49c-c9kb9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa0266f1_7780_4339_81d4_672b49005299.slice/cri-containerd-c99217312c6fa51bf14a4583566b38f811ea9bf39fb3a518b6d5c84a399dcafc.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa0266f1_7780_4339_81d4_672b49005299.slice/cri-containerd-a211b10b2b6885f8ac2848c0cf8a0b4b270437fc69328f5db8a91b0fa3fe592a.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa0266f1_7780_4339_81d4_672b49005299.slice/cri-containerd-3d6f68ea518aeabd6a605f58a07519a79fafa47097922966e4e7fe177f532934.scope"
      }
    ],
    "ips": [
      "10.115.0.26"
    ],
    "name": "clustermesh-apiserver-655587d97-xswr6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf718024f_0840_407d_b0a0_de08490e1940.slice/cri-containerd-45c51842a0bc499634fbee2ce75a03eb000595c22727d209e67d790e0456004a.scope"
      }
    ],
    "ips": [
      "10.115.0.226"
    ],
    "name": "coredns-cc6ccd49c-trqcj",
    "namespace": "kube-system"
  }
]

