{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:46.709Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.218.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:46.710Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.254.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:46.710Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:51.425Z",
  "value": "id=141   sec_id=4     flags=0x0000 ifindex=10  mac=F6:4C:0F:E3:94:91 nodemac=8E:CA:AE:84:26:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:51.435Z",
  "value": "id=3341  sec_id=3812883 flags=0x0000 ifindex=12  mac=FA:95:3D:DA:C2:A0 nodemac=BE:37:26:EA:86:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:51.510Z",
  "value": "id=141   sec_id=4     flags=0x0000 ifindex=10  mac=F6:4C:0F:E3:94:91 nodemac=8E:CA:AE:84:26:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:51.511Z",
  "value": "id=3341  sec_id=3812883 flags=0x0000 ifindex=12  mac=FA:95:3D:DA:C2:A0 nodemac=BE:37:26:EA:86:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:51.523Z",
  "value": "id=198   sec_id=3812883 flags=0x0000 ifindex=14  mac=7E:E6:C3:80:D5:93 nodemac=C6:01:DB:0D:26:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:20.790Z",
  "value": "id=141   sec_id=4     flags=0x0000 ifindex=10  mac=F6:4C:0F:E3:94:91 nodemac=8E:CA:AE:84:26:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:20.791Z",
  "value": "id=3341  sec_id=3812883 flags=0x0000 ifindex=12  mac=FA:95:3D:DA:C2:A0 nodemac=BE:37:26:EA:86:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:20.791Z",
  "value": "id=198   sec_id=3812883 flags=0x0000 ifindex=14  mac=7E:E6:C3:80:D5:93 nodemac=C6:01:DB:0D:26:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:20.822Z",
  "value": "id=2266  sec_id=3808679 flags=0x0000 ifindex=16  mac=5E:C1:90:F5:48:8E nodemac=16:BA:FF:C2:73:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:21.791Z",
  "value": "id=141   sec_id=4     flags=0x0000 ifindex=10  mac=F6:4C:0F:E3:94:91 nodemac=8E:CA:AE:84:26:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:21.792Z",
  "value": "id=2266  sec_id=3808679 flags=0x0000 ifindex=16  mac=5E:C1:90:F5:48:8E nodemac=16:BA:FF:C2:73:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:21.792Z",
  "value": "id=3341  sec_id=3812883 flags=0x0000 ifindex=12  mac=FA:95:3D:DA:C2:A0 nodemac=BE:37:26:EA:86:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:21.792Z",
  "value": "id=198   sec_id=3812883 flags=0x0000 ifindex=14  mac=7E:E6:C3:80:D5:93 nodemac=C6:01:DB:0D:26:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.365Z",
  "value": "id=3239  sec_id=3808679 flags=0x0000 ifindex=18  mac=1E:88:6B:28:35:62 nodemac=D2:87:4B:95:0C:F7"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.115.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.685Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.067Z",
  "value": "id=3341  sec_id=3812883 flags=0x0000 ifindex=12  mac=FA:95:3D:DA:C2:A0 nodemac=BE:37:26:EA:86:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.067Z",
  "value": "id=198   sec_id=3812883 flags=0x0000 ifindex=14  mac=7E:E6:C3:80:D5:93 nodemac=C6:01:DB:0D:26:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.067Z",
  "value": "id=3239  sec_id=3808679 flags=0x0000 ifindex=18  mac=1E:88:6B:28:35:62 nodemac=D2:87:4B:95:0C:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.067Z",
  "value": "id=141   sec_id=4     flags=0x0000 ifindex=10  mac=F6:4C:0F:E3:94:91 nodemac=8E:CA:AE:84:26:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.069Z",
  "value": "id=198   sec_id=3812883 flags=0x0000 ifindex=14  mac=7E:E6:C3:80:D5:93 nodemac=C6:01:DB:0D:26:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.074Z",
  "value": "id=3239  sec_id=3808679 flags=0x0000 ifindex=18  mac=1E:88:6B:28:35:62 nodemac=D2:87:4B:95:0C:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.075Z",
  "value": "id=141   sec_id=4     flags=0x0000 ifindex=10  mac=F6:4C:0F:E3:94:91 nodemac=8E:CA:AE:84:26:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.075Z",
  "value": "id=3341  sec_id=3812883 flags=0x0000 ifindex=12  mac=FA:95:3D:DA:C2:A0 nodemac=BE:37:26:EA:86:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.068Z",
  "value": "id=3239  sec_id=3808679 flags=0x0000 ifindex=18  mac=1E:88:6B:28:35:62 nodemac=D2:87:4B:95:0C:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.068Z",
  "value": "id=198   sec_id=3812883 flags=0x0000 ifindex=14  mac=7E:E6:C3:80:D5:93 nodemac=C6:01:DB:0D:26:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.068Z",
  "value": "id=3341  sec_id=3812883 flags=0x0000 ifindex=12  mac=FA:95:3D:DA:C2:A0 nodemac=BE:37:26:EA:86:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.068Z",
  "value": "id=141   sec_id=4     flags=0x0000 ifindex=10  mac=F6:4C:0F:E3:94:91 nodemac=8E:CA:AE:84:26:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.068Z",
  "value": "id=141   sec_id=4     flags=0x0000 ifindex=10  mac=F6:4C:0F:E3:94:91 nodemac=8E:CA:AE:84:26:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.068Z",
  "value": "id=3239  sec_id=3808679 flags=0x0000 ifindex=18  mac=1E:88:6B:28:35:62 nodemac=D2:87:4B:95:0C:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.069Z",
  "value": "id=198   sec_id=3812883 flags=0x0000 ifindex=14  mac=7E:E6:C3:80:D5:93 nodemac=C6:01:DB:0D:26:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.069Z",
  "value": "id=3341  sec_id=3812883 flags=0x0000 ifindex=12  mac=FA:95:3D:DA:C2:A0 nodemac=BE:37:26:EA:86:DA"
}

