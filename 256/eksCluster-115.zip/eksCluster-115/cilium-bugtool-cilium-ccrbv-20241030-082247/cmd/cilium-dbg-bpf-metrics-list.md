REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36454     2888443     677    bpf_overlay.c
Interface                 INGRESS     661530    135367532   1132   bpf_host.c
Success                   EGRESS      16479     1297735     1694   bpf_host.c
Success                   EGRESS      284362    35083717    1308   bpf_lxc.c
Success                   EGRESS      36846     2914294     53     encap.h
Success                   INGRESS     325673    36942376    86     l3.h
Success                   INGRESS     346299    38577130    235    trace.h
Unsupported L3 protocol   EGRESS      41        3046        1492   bpf_lxc.c
