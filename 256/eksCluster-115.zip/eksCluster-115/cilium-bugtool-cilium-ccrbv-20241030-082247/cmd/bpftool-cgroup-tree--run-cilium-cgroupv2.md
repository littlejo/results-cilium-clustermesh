CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1452e7f4_d4a1_4e12_ae6d_6d5cbe27bd17.slice/cri-containerd-51c59018af5bb504e17e5186b88d5035144144a8fe175ba67843d2879a6b8f83.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1452e7f4_d4a1_4e12_ae6d_6d5cbe27bd17.slice/cri-containerd-c05bc4c800018f9e09708c10a80e991823297c40f9307e21882ea4ab0000de5e.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod15d16321_63c9_4401_beea_826ea0b4f045.slice/cri-containerd-5bfe4a93e1a05db2b3bdd0f2286fc06b266363fd37fef238a89287f25c9799f9.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod15d16321_63c9_4401_beea_826ea0b4f045.slice/cri-containerd-23819cbfae818389edea2a06355f6b7091ab80a3764ea1293df6ec4b0c14e1e0.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1768b514_2ef7_4c3b_9a2b_a72e33fe4c5d.slice/cri-containerd-1025c7e3a012f03520004e72c3e6bdc14b8245f0aeea5070253ef56080bd374c.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1768b514_2ef7_4c3b_9a2b_a72e33fe4c5d.slice/cri-containerd-6d1061ac30dd6fa542db3d7627876b7fe66fbcc50a6151976281a5c7f9df9b54.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf718024f_0840_407d_b0a0_de08490e1940.slice/cri-containerd-45c51842a0bc499634fbee2ce75a03eb000595c22727d209e67d790e0456004a.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf718024f_0840_407d_b0a0_de08490e1940.slice/cri-containerd-92d8245b4b02204f60060082eb809c871e5bec1b2f187e047f0103b7c928d06a.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod803306be_31e8_49db_b651_8564635be2f3.slice/cri-containerd-7692889fbaf9c9d6f634c70a40be13d23faba517715b9601c0cad6349a5264df.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod803306be_31e8_49db_b651_8564635be2f3.slice/cri-containerd-e05593f45643a66acbbdee171b244c72c599705f42ed1e4aa456adc8cb95be93.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1088697e_7971_41dd_bf89_341be37cda89.slice/cri-containerd-9914738632df6cec08f343c79d753c99480de658a28a50dd22a5e94abdda91c8.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1088697e_7971_41dd_bf89_341be37cda89.slice/cri-containerd-ef23127b57b245042e9621a18af9f9abead44b566d6cccfcca785453401570e0.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa0266f1_7780_4339_81d4_672b49005299.slice/cri-containerd-56a8618ea723f530c27d2e90199b3d5eb4c57f7b6d1e011ba196e368cf4f328c.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa0266f1_7780_4339_81d4_672b49005299.slice/cri-containerd-c99217312c6fa51bf14a4583566b38f811ea9bf39fb3a518b6d5c84a399dcafc.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa0266f1_7780_4339_81d4_672b49005299.slice/cri-containerd-3d6f68ea518aeabd6a605f58a07519a79fafa47097922966e4e7fe177f532934.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa0266f1_7780_4339_81d4_672b49005299.slice/cri-containerd-a211b10b2b6885f8ac2848c0cf8a0b4b270437fc69328f5db8a91b0fa3fe592a.scope
    645      cgroup_device   multi                                          
