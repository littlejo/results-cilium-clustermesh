KEY             VALUE
AgentLiveness   2185268004125
UTimeOffset     3379442216796875
