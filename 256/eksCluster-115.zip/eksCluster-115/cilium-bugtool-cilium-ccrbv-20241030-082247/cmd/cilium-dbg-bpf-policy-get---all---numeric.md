Endpoint ID: 141
Path: /sys/fs/bpf/tc/globals/cilium_policy_00141

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1636850   20655     0        
Allow    Ingress     1          ANY          NONE         disabled    25496     297       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 198
Path: /sys/fs/bpf/tc/globals/cilium_policy_00198

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    169591   1943      0        
Allow    Egress      0          ANY          NONE         disabled    21637    243       0        


Endpoint ID: 3239
Path: /sys/fs/bpf/tc/globals/cilium_policy_03239

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11539726   116168    0        
Allow    Ingress     1          ANY          NONE         disabled    10541059   111190    0        
Allow    Egress      0          ANY          NONE         disabled    14439705   141180    0        


Endpoint ID: 3341
Path: /sys/fs/bpf/tc/globals/cilium_policy_03341

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    169195   1937      0        
Allow    Egress      0          ANY          NONE         disabled    21454    240       0        


Endpoint ID: 3644
Path: /sys/fs/bpf/tc/globals/cilium_policy_03644

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


