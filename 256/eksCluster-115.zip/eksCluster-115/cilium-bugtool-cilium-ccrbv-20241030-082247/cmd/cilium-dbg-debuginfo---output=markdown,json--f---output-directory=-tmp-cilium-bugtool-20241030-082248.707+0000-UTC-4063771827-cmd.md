markdown output at /tmp/cilium-bugtool-20241030-082248.707+0000-UTC-4063771827/cmd/cilium-debuginfo-20241030-082320.146+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082248.707+0000-UTC-4063771827/cmd/cilium-debuginfo-20241030-082320.146+0000-UTC.json
