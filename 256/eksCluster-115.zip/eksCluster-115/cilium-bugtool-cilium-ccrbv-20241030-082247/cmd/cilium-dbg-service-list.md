ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.137.160:443 (active)    
                                         2 => 172.31.237.168:443 (active)    
2    10.100.66.84:443     ClusterIP      1 => 172.31.254.132:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.115.0.226:53 (active)       
                                         2 => 10.115.0.100:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.115.0.226:9153 (active)     
                                         2 => 10.115.0.100:9153 (active)     
5    10.100.11.219:2379   ClusterIP      1 => 10.115.0.26:2379 (active)      
