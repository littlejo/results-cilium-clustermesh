key: 01 00 00 00  value: ac 1f 86 e6 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: 0a bc 00 25 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a bc 00 71 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f bd 2e 10 94 00 00  00 00 00 00
key: 08 00 00 00  value: 0a bc 00 71 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f d3 d8 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a bc 00 ab 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a bc 00 25 00 35 00 00  00 00 00 00
Found 8 elements
