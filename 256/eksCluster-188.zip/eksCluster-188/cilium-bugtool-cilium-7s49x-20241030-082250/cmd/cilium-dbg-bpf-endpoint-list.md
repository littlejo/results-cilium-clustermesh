IP ADDRESS         LOCAL ENDPOINT INFO
10.188.0.113:0     id=3221  sec_id=6194486 flags=0x0000 ifindex=12  mac=8A:73:43:16:13:22 nodemac=86:BF:F4:5C:7D:27   
10.188.0.171:0     id=3313  sec_id=6203850 flags=0x0000 ifindex=18  mac=62:3E:16:BB:CA:E5 nodemac=AE:3A:98:4D:43:7C   
172.31.189.46:0    (localhost)                                                                                        
172.31.175.157:0   (localhost)                                                                                        
10.188.0.102:0     id=1202  sec_id=4     flags=0x0000 ifindex=10  mac=6A:1B:31:F8:AC:17 nodemac=1A:4C:38:98:3D:EB     
10.188.0.47:0      (localhost)                                                                                        
10.188.0.37:0      id=2256  sec_id=6194486 flags=0x0000 ifindex=14  mac=3A:51:48:C7:59:A7 nodemac=6A:F4:17:34:A8:5F   
