{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:55.107Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.175.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:55.107Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.189.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:55.107Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:59.768Z",
  "value": "id=1202  sec_id=4     flags=0x0000 ifindex=10  mac=6A:1B:31:F8:AC:17 nodemac=1A:4C:38:98:3D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:59.772Z",
  "value": "id=3221  sec_id=6194486 flags=0x0000 ifindex=12  mac=8A:73:43:16:13:22 nodemac=86:BF:F4:5C:7D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:59.810Z",
  "value": "id=2256  sec_id=6194486 flags=0x0000 ifindex=14  mac=3A:51:48:C7:59:A7 nodemac=6A:F4:17:34:A8:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:59.814Z",
  "value": "id=3221  sec_id=6194486 flags=0x0000 ifindex=12  mac=8A:73:43:16:13:22 nodemac=86:BF:F4:5C:7D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:59.843Z",
  "value": "id=1202  sec_id=4     flags=0x0000 ifindex=10  mac=6A:1B:31:F8:AC:17 nodemac=1A:4C:38:98:3D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:11.645Z",
  "value": "id=3221  sec_id=6194486 flags=0x0000 ifindex=12  mac=8A:73:43:16:13:22 nodemac=86:BF:F4:5C:7D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:11.645Z",
  "value": "id=1202  sec_id=4     flags=0x0000 ifindex=10  mac=6A:1B:31:F8:AC:17 nodemac=1A:4C:38:98:3D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:11.645Z",
  "value": "id=2256  sec_id=6194486 flags=0x0000 ifindex=14  mac=3A:51:48:C7:59:A7 nodemac=6A:F4:17:34:A8:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:11.678Z",
  "value": "id=1393  sec_id=6203850 flags=0x0000 ifindex=16  mac=66:25:73:E9:E2:83 nodemac=6E:F4:FD:94:49:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:12.645Z",
  "value": "id=3221  sec_id=6194486 flags=0x0000 ifindex=12  mac=8A:73:43:16:13:22 nodemac=86:BF:F4:5C:7D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:12.645Z",
  "value": "id=2256  sec_id=6194486 flags=0x0000 ifindex=14  mac=3A:51:48:C7:59:A7 nodemac=6A:F4:17:34:A8:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:12.646Z",
  "value": "id=1393  sec_id=6203850 flags=0x0000 ifindex=16  mac=66:25:73:E9:E2:83 nodemac=6E:F4:FD:94:49:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:12.646Z",
  "value": "id=1202  sec_id=4     flags=0x0000 ifindex=10  mac=6A:1B:31:F8:AC:17 nodemac=1A:4C:38:98:3D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.675Z",
  "value": "id=3313  sec_id=6203850 flags=0x0000 ifindex=18  mac=62:3E:16:BB:CA:E5 nodemac=AE:3A:98:4D:43:7C"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.188.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.065Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.502Z",
  "value": "id=2256  sec_id=6194486 flags=0x0000 ifindex=14  mac=3A:51:48:C7:59:A7 nodemac=6A:F4:17:34:A8:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.503Z",
  "value": "id=3313  sec_id=6203850 flags=0x0000 ifindex=18  mac=62:3E:16:BB:CA:E5 nodemac=AE:3A:98:4D:43:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.504Z",
  "value": "id=1202  sec_id=4     flags=0x0000 ifindex=10  mac=6A:1B:31:F8:AC:17 nodemac=1A:4C:38:98:3D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.505Z",
  "value": "id=3221  sec_id=6194486 flags=0x0000 ifindex=12  mac=8A:73:43:16:13:22 nodemac=86:BF:F4:5C:7D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.503Z",
  "value": "id=3313  sec_id=6203850 flags=0x0000 ifindex=18  mac=62:3E:16:BB:CA:E5 nodemac=AE:3A:98:4D:43:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.508Z",
  "value": "id=1202  sec_id=4     flags=0x0000 ifindex=10  mac=6A:1B:31:F8:AC:17 nodemac=1A:4C:38:98:3D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.509Z",
  "value": "id=3221  sec_id=6194486 flags=0x0000 ifindex=12  mac=8A:73:43:16:13:22 nodemac=86:BF:F4:5C:7D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.510Z",
  "value": "id=2256  sec_id=6194486 flags=0x0000 ifindex=14  mac=3A:51:48:C7:59:A7 nodemac=6A:F4:17:34:A8:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.502Z",
  "value": "id=3313  sec_id=6203850 flags=0x0000 ifindex=18  mac=62:3E:16:BB:CA:E5 nodemac=AE:3A:98:4D:43:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.503Z",
  "value": "id=1202  sec_id=4     flags=0x0000 ifindex=10  mac=6A:1B:31:F8:AC:17 nodemac=1A:4C:38:98:3D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.503Z",
  "value": "id=3221  sec_id=6194486 flags=0x0000 ifindex=12  mac=8A:73:43:16:13:22 nodemac=86:BF:F4:5C:7D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.503Z",
  "value": "id=2256  sec_id=6194486 flags=0x0000 ifindex=14  mac=3A:51:48:C7:59:A7 nodemac=6A:F4:17:34:A8:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.503Z",
  "value": "id=3313  sec_id=6203850 flags=0x0000 ifindex=18  mac=62:3E:16:BB:CA:E5 nodemac=AE:3A:98:4D:43:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.503Z",
  "value": "id=3221  sec_id=6194486 flags=0x0000 ifindex=12  mac=8A:73:43:16:13:22 nodemac=86:BF:F4:5C:7D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.504Z",
  "value": "id=1202  sec_id=4     flags=0x0000 ifindex=10  mac=6A:1B:31:F8:AC:17 nodemac=1A:4C:38:98:3D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.188.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.504Z",
  "value": "id=2256  sec_id=6194486 flags=0x0000 ifindex=14  mac=3A:51:48:C7:59:A7 nodemac=6A:F4:17:34:A8:5F"
}

