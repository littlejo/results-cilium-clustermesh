Endpoint ID: 1202
Path: /sys/fs/bpf/tc/globals/cilium_policy_01202

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1652217   20859     0        
Allow    Ingress     1          ANY          NONE         disabled    19226     226       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2256
Path: /sys/fs/bpf/tc/globals/cilium_policy_02256

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    120437   1378      0        
Allow    Egress      0          ANY          NONE         disabled    17031    185       0        


Endpoint ID: 3221
Path: /sys/fs/bpf/tc/globals/cilium_policy_03221

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    121150   1385      0        
Allow    Egress      0          ANY          NONE         disabled    16088    173       0        


Endpoint ID: 3313
Path: /sys/fs/bpf/tc/globals/cilium_policy_03313

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11559994   114852    0        
Allow    Ingress     1          ANY          NONE         disabled    10112648   106689    0        
Allow    Egress      0          ANY          NONE         disabled    12590824   124149    0        


Endpoint ID: 3666
Path: /sys/fs/bpf/tc/globals/cilium_policy_03666

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


