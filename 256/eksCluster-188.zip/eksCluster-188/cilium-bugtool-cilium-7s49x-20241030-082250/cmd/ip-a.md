1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:26:78:06:90:a5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.189.46/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3535sec preferred_lft 3535sec
    inet6 fe80::426:78ff:fe06:90a5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:2f:08:17:e7:8f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.175.157/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::42f:8ff:fe17:e78f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:00:67:90:bd:b4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::dc00:67ff:fe90:bdb4/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:ea:e0:d7:c0:06 brd ff:ff:ff:ff:ff:ff
    inet 10.188.0.47/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::84ea:e0ff:fed7:c006/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 7a:a8:12:89:fa:a1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::78a8:12ff:fe89:faa1/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:4c:38:98:3d:eb brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::184c:38ff:fe98:3deb/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc0bac8b0a6867@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:bf:f4:5c:7d:27 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::84bf:f4ff:fe5c:7d27/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc44192e1adcdb@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:f4:17:34:a8:5f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::68f4:17ff:fe34:a85f/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc745fb8a69ff1@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:3a:98:4d:43:7c brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::ac3a:98ff:fe4d:437c/64 scope link 
       valid_lft forever preferred_lft forever
