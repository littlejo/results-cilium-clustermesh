markdown output at /tmp/cilium-bugtool-20241030-082251.775+0000-UTC-95369004/cmd/cilium-debuginfo-20241030-082323.047+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082251.775+0000-UTC-95369004/cmd/cilium-debuginfo-20241030-082323.047+0000-UTC.json
