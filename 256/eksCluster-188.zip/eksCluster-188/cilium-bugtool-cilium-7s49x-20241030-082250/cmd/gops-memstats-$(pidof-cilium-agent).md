alloc: 210.26MB (220477280 bytes)
total-alloc: 2.25GB (2412416208 bytes)
sys: 324.71MB (340480356 bytes)
lookups: 0
mallocs: 63445176
frees: 60997103
heap-alloc: 210.26MB (220477280 bytes)
heap-sys: 251.45MB (263659520 bytes)
heap-idle: 23.83MB (24985600 bytes)
heap-in-use: 227.62MB (238673920 bytes)
heap-released: 944.00KB (966656 bytes)
heap-objects: 2448073
stack-in-use: 60.19MB (63111168 bytes)
stack-sys: 60.19MB (63111168 bytes)
stack-mspan-inuse: 3.62MB (3793280 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1013.88KB (1038209 bytes)
gc-sys: 6.28MB (6587880 bytes)
next-gc: when heap-alloc >= 220.93MB (231660856 bytes)
last-gc: 2024-10-30 08:23:22.004856259 +0000 UTC
gc-pause-total: 10.446147ms
gc-pause: 989495
gc-pause-end: 1730276602004856259
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005750917146783104
enable-gc: true
debug-gc: false
