[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod37135044_f27d_4dc4_80bf_39b1d7ee67f9.slice/cri-containerd-3a37a8c788987b3dd64172e1a62f3bddad1f27b7a7103923b9e6e573cfb91072.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod37135044_f27d_4dc4_80bf_39b1d7ee67f9.slice/cri-containerd-32a32426a19000d430fc1efd9bbda11da26b34935b0a40865e86618f5f0cbf5d.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod37135044_f27d_4dc4_80bf_39b1d7ee67f9.slice/cri-containerd-08aa9b6ebb1cdcbebb647568c228fb253aa6f6da516e4cd3c76054d203dbf03b.scope"
      }
    ],
    "ips": [
      "10.188.0.171"
    ],
    "name": "clustermesh-apiserver-7c89478fc6-gs8vq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod24e92216_80f7_412b_a38e_50ec9770d566.slice/cri-containerd-800f3841e82d02444a95795b82ae7ca1c20fa3455d86a602b08c60137ddbd22f.scope"
      }
    ],
    "ips": [
      "10.188.0.37"
    ],
    "name": "coredns-cc6ccd49c-4qllk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod26dbd9e6_e9f3_40ab_8443_a31c99cda00f.slice/cri-containerd-c68510d848f5c27cc123475b12eac45af76093ea11dedde898d8734d6d539864.scope"
      }
    ],
    "ips": [
      "10.188.0.113"
    ],
    "name": "coredns-cc6ccd49c-vfdhh",
    "namespace": "kube-system"
  }
]

