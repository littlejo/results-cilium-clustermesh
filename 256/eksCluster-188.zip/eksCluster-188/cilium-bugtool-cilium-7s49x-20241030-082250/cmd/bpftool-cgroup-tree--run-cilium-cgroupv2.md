CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod26dbd9e6_e9f3_40ab_8443_a31c99cda00f.slice/cri-containerd-f9cbde7ba3cfb53a03b10952b32fc3576ada6e0dda3d759aa2c385b44e7837b3.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod26dbd9e6_e9f3_40ab_8443_a31c99cda00f.slice/cri-containerd-c68510d848f5c27cc123475b12eac45af76093ea11dedde898d8734d6d539864.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod24e92216_80f7_412b_a38e_50ec9770d566.slice/cri-containerd-800f3841e82d02444a95795b82ae7ca1c20fa3455d86a602b08c60137ddbd22f.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod24e92216_80f7_412b_a38e_50ec9770d566.slice/cri-containerd-0dc5de5f14fe23ff5596ac05f4fd910b2851aad58d72a10b1aedbdae9dec02b7.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod910b7875_e809_438b_bd35_7edb1748238a.slice/cri-containerd-0574a495da973ba0c699c3d9f56932ced1c3bfce4cd1720e573cb55f762aae74.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod910b7875_e809_438b_bd35_7edb1748238a.slice/cri-containerd-31e9c3d73e238959d35e5428c02c6b62c2feeac1423e8167bf9f804f860f2744.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda0f795ea_84e2_4c3f_af23_953763570ade.slice/cri-containerd-f9823e829420297bda5f1b85972778349bd7dc71c1550bbe3fa6edd906678b19.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda0f795ea_84e2_4c3f_af23_953763570ade.slice/cri-containerd-2b63f19aba6a87a955e948801f6cf094b44983d0d2b84bcab17d1e845ccc061a.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod37135044_f27d_4dc4_80bf_39b1d7ee67f9.slice/cri-containerd-3a37a8c788987b3dd64172e1a62f3bddad1f27b7a7103923b9e6e573cfb91072.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod37135044_f27d_4dc4_80bf_39b1d7ee67f9.slice/cri-containerd-32a32426a19000d430fc1efd9bbda11da26b34935b0a40865e86618f5f0cbf5d.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod37135044_f27d_4dc4_80bf_39b1d7ee67f9.slice/cri-containerd-08aa9b6ebb1cdcbebb647568c228fb253aa6f6da516e4cd3c76054d203dbf03b.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod37135044_f27d_4dc4_80bf_39b1d7ee67f9.slice/cri-containerd-a3ddeb6c91a24c6ea70348d8ed42bc795f43ebe2a2f4dc1bd72d0184e2fecebc.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod684831e5_5f83_4167_8dba_c66d00a540b6.slice/cri-containerd-bdf2d47f3d9034644f71f0c76770c7137610dbebb670be508aa5e79ec924ce12.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod684831e5_5f83_4167_8dba_c66d00a540b6.slice/cri-containerd-5df06deb8994d56194ea1acf935784279e6849ab2d99bd1eade72db849c7e1c1.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod254886dd_4de0_435e_aab8_19c7529bba3e.slice/cri-containerd-064cc673524f512f9030fb7d683ebe36d3aad55b8c1cbfc814e5e2af3a3ab020.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod254886dd_4de0_435e_aab8_19c7529bba3e.slice/cri-containerd-3290fdc69c67b9391d898cd8939f980ab514937b80f72aa92a88ed56e3b87acf.scope
    105      cgroup_device   multi                                          
