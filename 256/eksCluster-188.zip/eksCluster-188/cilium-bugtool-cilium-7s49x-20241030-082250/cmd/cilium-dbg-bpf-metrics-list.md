REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36634     2901439     677    bpf_overlay.c
Interface                 INGRESS     645663    131986564   1132   bpf_host.c
Success                   EGRESS      16473     1297123     1694   bpf_host.c
Success                   EGRESS      271228    34013688    1308   bpf_lxc.c
Success                   EGRESS      36870     2917530     53     encap.h
Success                   INGRESS     314535    35367472    86     l3.h
Success                   INGRESS     335347    37015834    235    trace.h
Unsupported L3 protocol   EGRESS      40        2972        1492   bpf_lxc.c
