top - 08:22:52 up 31 min,  0 users,  load average: 0.15, 0.23, 0.18
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 17.2 us, 24.1 sy,  0.0 ni, 55.2 id,  0.0 wa,  0.0 hi,  0.0 si,  3.4 st
MiB Mem :   7814.2 total,   4489.8 free,   1178.0 used,   2146.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6451.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1605760 376168  77676 S   6.7   4.7   0:51.41 cilium-+
    393 root      20   0 1229744   7120   2924 S   0.0   0.1   0:01.14 cilium-+
    605 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    611 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    617 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    645 root      20   0 1240432  16340  11356 S   0.0   0.2   0:00.02 cilium-+
    671 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    686 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    687 root      20   0 1229000   4040   3392 S   0.0   0.1   0:00.00 gops
    713 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
