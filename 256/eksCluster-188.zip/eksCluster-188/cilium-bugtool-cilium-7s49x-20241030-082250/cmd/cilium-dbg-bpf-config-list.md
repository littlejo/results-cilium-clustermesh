KEY             VALUE
AgentLiveness   1905667685185
UTimeOffset     3379442767578125
