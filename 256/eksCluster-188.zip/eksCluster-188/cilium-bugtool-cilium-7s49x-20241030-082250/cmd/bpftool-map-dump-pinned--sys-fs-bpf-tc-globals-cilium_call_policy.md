key: b2 04 00 00  value: 2e 02 00 00
key: d0 08 00 00  value: 27 02 00 00
key: 95 0c 00 00  value: 11 02 00 00
key: f1 0c 00 00  value: 67 02 00 00
Found 4 elements
