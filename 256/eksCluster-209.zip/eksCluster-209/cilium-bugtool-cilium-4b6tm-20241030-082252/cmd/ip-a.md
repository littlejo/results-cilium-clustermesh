1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:42:91:80:36:37 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.230.218/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1810sec preferred_lft 1810sec
    inet6 fe80::842:91ff:fe80:3637/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:a5:05:c9:48:4f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.193.30/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8a5:5ff:fec9:484f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:b9:3a:ff:f7:d6 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::18b9:3aff:feff:f7d6/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:41:b4:9d:de:11 brd ff:ff:ff:ff:ff:ff
    inet 10.209.0.226/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::5441:b4ff:fe9d:de11/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 36:43:94:f9:8a:b7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3443:94ff:fef9:8ab7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:2d:03:f6:ff:dd brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d82d:3ff:fef6:ffdd/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc99eae1c6e25b@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:32:4e:f8:b0:a5 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::5c32:4eff:fef8:b0a5/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc98ad2bb19ba4@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:e9:fb:f2:bd:7d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ece9:fbff:fef2:bd7d/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc7f65f201c280@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:b6:95:a4:5e:7e brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9cb6:95ff:fea4:5e7e/64 scope link 
       valid_lft forever preferred_lft forever
