{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:07.008Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.193.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:07.008Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.230.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:07.008Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:11.623Z",
  "value": "id=473   sec_id=4     flags=0x0000 ifindex=10  mac=6E:15:FF:E8:8A:28 nodemac=DA:2D:03:F6:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:11.624Z",
  "value": "id=664   sec_id=6891850 flags=0x0000 ifindex=12  mac=BA:9F:7C:B4:51:F6 nodemac=5E:32:4E:F8:B0:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:11.690Z",
  "value": "id=1074  sec_id=6891850 flags=0x0000 ifindex=14  mac=42:70:11:3F:1C:B6 nodemac=EE:E9:FB:F2:BD:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:11.787Z",
  "value": "id=664   sec_id=6891850 flags=0x0000 ifindex=12  mac=BA:9F:7C:B4:51:F6 nodemac=5E:32:4E:F8:B0:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:11.846Z",
  "value": "id=473   sec_id=4     flags=0x0000 ifindex=10  mac=6E:15:FF:E8:8A:28 nodemac=DA:2D:03:F6:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:39.276Z",
  "value": "id=473   sec_id=4     flags=0x0000 ifindex=10  mac=6E:15:FF:E8:8A:28 nodemac=DA:2D:03:F6:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:39.276Z",
  "value": "id=664   sec_id=6891850 flags=0x0000 ifindex=12  mac=BA:9F:7C:B4:51:F6 nodemac=5E:32:4E:F8:B0:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:39.277Z",
  "value": "id=1074  sec_id=6891850 flags=0x0000 ifindex=14  mac=42:70:11:3F:1C:B6 nodemac=EE:E9:FB:F2:BD:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:39.307Z",
  "value": "id=39    sec_id=6898023 flags=0x0000 ifindex=16  mac=3A:CE:4E:4E:8B:22 nodemac=B6:7A:6E:A3:10:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:40.276Z",
  "value": "id=39    sec_id=6898023 flags=0x0000 ifindex=16  mac=3A:CE:4E:4E:8B:22 nodemac=B6:7A:6E:A3:10:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:40.276Z",
  "value": "id=664   sec_id=6891850 flags=0x0000 ifindex=12  mac=BA:9F:7C:B4:51:F6 nodemac=5E:32:4E:F8:B0:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:40.277Z",
  "value": "id=1074  sec_id=6891850 flags=0x0000 ifindex=14  mac=42:70:11:3F:1C:B6 nodemac=EE:E9:FB:F2:BD:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:40.277Z",
  "value": "id=473   sec_id=4     flags=0x0000 ifindex=10  mac=6E:15:FF:E8:8A:28 nodemac=DA:2D:03:F6:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.994Z",
  "value": "id=1709  sec_id=6898023 flags=0x0000 ifindex=18  mac=06:1D:FC:21:6B:ED nodemac=9E:B6:95:A4:5E:7E"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.209.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.397Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:07.801Z",
  "value": "id=473   sec_id=4     flags=0x0000 ifindex=10  mac=6E:15:FF:E8:8A:28 nodemac=DA:2D:03:F6:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:07.801Z",
  "value": "id=1074  sec_id=6891850 flags=0x0000 ifindex=14  mac=42:70:11:3F:1C:B6 nodemac=EE:E9:FB:F2:BD:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:07.801Z",
  "value": "id=664   sec_id=6891850 flags=0x0000 ifindex=12  mac=BA:9F:7C:B4:51:F6 nodemac=5E:32:4E:F8:B0:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:07.801Z",
  "value": "id=1709  sec_id=6898023 flags=0x0000 ifindex=18  mac=06:1D:FC:21:6B:ED nodemac=9E:B6:95:A4:5E:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:08.817Z",
  "value": "id=473   sec_id=4     flags=0x0000 ifindex=10  mac=6E:15:FF:E8:8A:28 nodemac=DA:2D:03:F6:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:08.817Z",
  "value": "id=664   sec_id=6891850 flags=0x0000 ifindex=12  mac=BA:9F:7C:B4:51:F6 nodemac=5E:32:4E:F8:B0:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:08.818Z",
  "value": "id=1074  sec_id=6891850 flags=0x0000 ifindex=14  mac=42:70:11:3F:1C:B6 nodemac=EE:E9:FB:F2:BD:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:08.818Z",
  "value": "id=1709  sec_id=6898023 flags=0x0000 ifindex=18  mac=06:1D:FC:21:6B:ED nodemac=9E:B6:95:A4:5E:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.813Z",
  "value": "id=473   sec_id=4     flags=0x0000 ifindex=10  mac=6E:15:FF:E8:8A:28 nodemac=DA:2D:03:F6:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.814Z",
  "value": "id=664   sec_id=6891850 flags=0x0000 ifindex=12  mac=BA:9F:7C:B4:51:F6 nodemac=5E:32:4E:F8:B0:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.814Z",
  "value": "id=1074  sec_id=6891850 flags=0x0000 ifindex=14  mac=42:70:11:3F:1C:B6 nodemac=EE:E9:FB:F2:BD:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.814Z",
  "value": "id=1709  sec_id=6898023 flags=0x0000 ifindex=18  mac=06:1D:FC:21:6B:ED nodemac=9E:B6:95:A4:5E:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.814Z",
  "value": "id=473   sec_id=4     flags=0x0000 ifindex=10  mac=6E:15:FF:E8:8A:28 nodemac=DA:2D:03:F6:FF:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.814Z",
  "value": "id=1709  sec_id=6898023 flags=0x0000 ifindex=18  mac=06:1D:FC:21:6B:ED nodemac=9E:B6:95:A4:5E:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.814Z",
  "value": "id=664   sec_id=6891850 flags=0x0000 ifindex=12  mac=BA:9F:7C:B4:51:F6 nodemac=5E:32:4E:F8:B0:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.209.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.815Z",
  "value": "id=1074  sec_id=6891850 flags=0x0000 ifindex=14  mac=42:70:11:3F:1C:B6 nodemac=EE:E9:FB:F2:BD:7D"
}

