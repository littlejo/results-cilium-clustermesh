REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36579     2898884     677    bpf_overlay.c
Interface                 INGRESS     641794    131499279   1132   bpf_host.c
Success                   EGRESS      16555     1302545     1694   bpf_host.c
Success                   EGRESS      269929    33836343    1308   bpf_lxc.c
Success                   EGRESS      36720     2909180     53     encap.h
Success                   INGRESS     311241    35064589    86     l3.h
Success                   INGRESS     331915    36704904    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
