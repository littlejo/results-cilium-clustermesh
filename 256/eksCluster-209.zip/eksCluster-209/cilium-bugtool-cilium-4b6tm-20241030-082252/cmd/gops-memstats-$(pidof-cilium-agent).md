alloc: 115.68MB (121303352 bytes)
total-alloc: 2.22GB (2387462336 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63080803
frees: 62182422
heap-alloc: 115.68MB (121303352 bytes)
heap-sys: 247.61MB (259637248 bytes)
heap-idle: 76.36MB (80068608 bytes)
heap-in-use: 171.25MB (179568640 bytes)
heap-released: 1.00MB (1048576 bytes)
heap-objects: 898381
stack-in-use: 64.34MB (67469312 bytes)
stack-sys: 64.34MB (67469312 bytes)
stack-mspan-inuse: 2.88MB (3022400 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 993.96KB (1017817 bytes)
gc-sys: 6.03MB (6321688 bytes)
next-gc: when heap-alloc >= 215.78MB (226260456 bytes)
last-gc: 2024-10-30 08:23:15.171048753 +0000 UTC
gc-pause-total: 11.091664ms
gc-pause: 95546
gc-pause-end: 1730276595171048753
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0006181062497849285
enable-gc: true
debug-gc: false
