key: d9 01 00 00  value: 1e 02 00 00
key: 98 02 00 00  value: 04 02 00 00
key: 32 04 00 00  value: fd 01 00 00
key: ad 06 00 00  value: 6f 02 00 00
Found 4 elements
