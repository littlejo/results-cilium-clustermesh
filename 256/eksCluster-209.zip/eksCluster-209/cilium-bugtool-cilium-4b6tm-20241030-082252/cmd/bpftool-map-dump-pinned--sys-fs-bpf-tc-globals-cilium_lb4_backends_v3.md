key: 06 00 00 00  value: 0a d1 00 50 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: 0a d1 00 50 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a d1 00 25 09 4b 00 00  00 00 00 00
key: 03 00 00 00  value: ac 1f e6 da 10 94 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f e4 07 01 bb 00 00  00 00 00 00
key: 04 00 00 00  value: 0a d1 00 5e 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: 0a d1 00 5e 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 97 42 01 bb 00 00  00 00 00 00
Found 8 elements
