KEY             VALUE
AgentLiveness   1833570208607
UTimeOffset     3379442914062500
