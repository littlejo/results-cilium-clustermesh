Endpoint ID: 473
Path: /sys/fs/bpf/tc/globals/cilium_policy_00473

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1643858   20720     0        
Allow    Ingress     1          ANY          NONE         disabled    18566     219       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 664
Path: /sys/fs/bpf/tc/globals/cilium_policy_00664

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113446   1297      0        
Allow    Egress      0          ANY          NONE         disabled    16420    176       0        


Endpoint ID: 918
Path: /sys/fs/bpf/tc/globals/cilium_policy_00918

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1074
Path: /sys/fs/bpf/tc/globals/cilium_policy_01074

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    115426   1327      0        
Allow    Egress      0          ANY          NONE         disabled    17590    190       0        


Endpoint ID: 1709
Path: /sys/fs/bpf/tc/globals/cilium_policy_01709

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11597236   115394    0        
Allow    Ingress     1          ANY          NONE         disabled    9798604    102953    0        
Allow    Egress      0          ANY          NONE         disabled    12601140   124331    0        


