IP ADDRESS         LOCAL ENDPOINT INFO
10.209.0.80:0      id=664   sec_id=6891850 flags=0x0000 ifindex=12  mac=BA:9F:7C:B4:51:F6 nodemac=5E:32:4E:F8:B0:A5   
10.209.0.226:0     (localhost)                                                                                        
172.31.230.218:0   (localhost)                                                                                        
10.209.0.136:0     id=473   sec_id=4     flags=0x0000 ifindex=10  mac=6E:15:FF:E8:8A:28 nodemac=DA:2D:03:F6:FF:DD     
10.209.0.37:0      id=1709  sec_id=6898023 flags=0x0000 ifindex=18  mac=06:1D:FC:21:6B:ED nodemac=9E:B6:95:A4:5E:7E   
10.209.0.94:0      id=1074  sec_id=6891850 flags=0x0000 ifindex=14  mac=42:70:11:3F:1C:B6 nodemac=EE:E9:FB:F2:BD:7D   
172.31.193.30:0    (localhost)                                                                                        
