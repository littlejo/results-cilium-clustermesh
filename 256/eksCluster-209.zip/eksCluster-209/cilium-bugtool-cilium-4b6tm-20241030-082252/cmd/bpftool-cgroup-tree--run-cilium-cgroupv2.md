CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04227a49_8b96_4370_a1bf_b70e9be325e7.slice/cri-containerd-9fc3abe1230087ce6c8eaa7c89df5e1cf06bd350feda1e3874e49c68618e97d9.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04227a49_8b96_4370_a1bf_b70e9be325e7.slice/cri-containerd-5b71aa7eba19754bd7112274e62c545261bca27a0fad816755a303de49f94d3c.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode8dcca8a_caac_40eb_9bc9_6ae33f26645d.slice/cri-containerd-ad3025ce50b499e547691f79875070cf62be1c12bd6d49a02818447a563ddfef.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode8dcca8a_caac_40eb_9bc9_6ae33f26645d.slice/cri-containerd-d7687b421894c739a549a628842ef9db7ece016a937f790fa060ad901a9dc894.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb71d7823_edcf_47b6_9f5f_209cd8330f6c.slice/cri-containerd-5ba00cfe134f540c1e48262646bca1b667cdc286dbeb2f2eb4356bc8e2d7cbc6.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb71d7823_edcf_47b6_9f5f_209cd8330f6c.slice/cri-containerd-33c85b0906b3a6e59697f89dbb09b80c1f5df6164e8f4f9bbaa412b90eed2f7d.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod017c3584_8087_4707_88de_67ec237f87d0.slice/cri-containerd-0370bb767cc7de8bdf20e1cbf66e9ae215e9041c456904c844f12130cd972eb3.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod017c3584_8087_4707_88de_67ec237f87d0.slice/cri-containerd-261afbadae37fa640ece1882395d9ccead5aaa6efcb67c06e1ccab1ec45bacaa.scope
    527      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda02fecfb_61a8_4998_8281_2f4a6bcc5132.slice/cri-containerd-9fda6e619e119d2ffd460bdd4ab3fc61b942f97557baf57c942569b4e625b086.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda02fecfb_61a8_4998_8281_2f4a6bcc5132.slice/cri-containerd-4def94bfa4615969d217299475f2962a287bd3d1f7953d9c48341ff3ee32e824.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda02fecfb_61a8_4998_8281_2f4a6bcc5132.slice/cri-containerd-5ed9f17139f109883f3623736cdb5b17b689636eba08a6567bafcfdcd4301bf5.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda02fecfb_61a8_4998_8281_2f4a6bcc5132.slice/cri-containerd-c582f259d7222cac835ec0da0796bd452b2815d24be29f9c8e209a3207951277.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode308fc8d_836e_4474_9b37_40fc6e9d604b.slice/cri-containerd-423c0482b4ea236f6adb7aa18e6f6449666cf69ed3ea16fd48a20a947c4324bb.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode308fc8d_836e_4474_9b37_40fc6e9d604b.slice/cri-containerd-8e6f468e61dc2f95ceb24d398aa172ef5a7f9d535d75994263f9f156f681815c.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod536e0b2d_1a83_49a8_a208_b42622976302.slice/cri-containerd-344f2e28c1b3bb814d329f3387a28929916309d9c48d3208238e3fbeec6f813f.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod536e0b2d_1a83_49a8_a208_b42622976302.slice/cri-containerd-c21ea3e4e6df80f52989086c9ca3ebd255d1ad3a1f50f55f8f83284d392d0b7d.scope
    99       cgroup_device   multi                                          
