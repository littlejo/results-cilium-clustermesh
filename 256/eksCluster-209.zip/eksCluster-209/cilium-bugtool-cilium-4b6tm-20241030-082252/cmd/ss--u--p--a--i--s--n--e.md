Total: 677
TCP:   1849 (estab 427, closed 1403, orphaned 0, timewait 563)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  446       436       10       
INET	  456       442       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:43493      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=37)) ino:35569 sk:3f2 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.230.218%ens5:68         0.0.0.0:*    uid:192 ino:16567 sk:3f3 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:36460 sk:3f4 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15314 sk:3f5 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:36459 sk:3f6 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15315 sk:3f7 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::842:91ff:fe80:3637]%ens5:546           [::]:*    uid:192 ino:16559 sk:3f8 cgroup:unreachable:c4e v6only:1 <->                   
