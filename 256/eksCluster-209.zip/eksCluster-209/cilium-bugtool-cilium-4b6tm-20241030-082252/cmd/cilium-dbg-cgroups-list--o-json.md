[
  {
    "containers": [
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda02fecfb_61a8_4998_8281_2f4a6bcc5132.slice/cri-containerd-5ed9f17139f109883f3623736cdb5b17b689636eba08a6567bafcfdcd4301bf5.scope"
      },
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda02fecfb_61a8_4998_8281_2f4a6bcc5132.slice/cri-containerd-4def94bfa4615969d217299475f2962a287bd3d1f7953d9c48341ff3ee32e824.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda02fecfb_61a8_4998_8281_2f4a6bcc5132.slice/cri-containerd-9fda6e619e119d2ffd460bdd4ab3fc61b942f97557baf57c942569b4e625b086.scope"
      }
    ],
    "ips": [
      "10.209.0.37"
    ],
    "name": "clustermesh-apiserver-75dbd97789-2xxnv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04227a49_8b96_4370_a1bf_b70e9be325e7.slice/cri-containerd-5b71aa7eba19754bd7112274e62c545261bca27a0fad816755a303de49f94d3c.scope"
      }
    ],
    "ips": [
      "10.209.0.94"
    ],
    "name": "coredns-cc6ccd49c-8f2wn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod017c3584_8087_4707_88de_67ec237f87d0.slice/cri-containerd-0370bb767cc7de8bdf20e1cbf66e9ae215e9041c456904c844f12130cd972eb3.scope"
      }
    ],
    "ips": [
      "10.209.0.80"
    ],
    "name": "coredns-cc6ccd49c-bdrxs",
    "namespace": "kube-system"
  }
]

