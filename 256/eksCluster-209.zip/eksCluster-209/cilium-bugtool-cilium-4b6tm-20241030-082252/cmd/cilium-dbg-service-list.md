ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.151.66:443 (active)     
                                         2 => 172.31.228.7:443 (active)      
2    10.100.229.139:443   ClusterIP      1 => 172.31.230.218:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.209.0.94:53 (active)        
                                         2 => 10.209.0.80:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.209.0.94:9153 (active)      
                                         2 => 10.209.0.80:9153 (active)      
5    10.100.34.198:2379   ClusterIP      1 => 10.209.0.37:2379 (active)      
