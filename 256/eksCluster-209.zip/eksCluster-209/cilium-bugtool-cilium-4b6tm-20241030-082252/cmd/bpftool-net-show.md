xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 567
ens6(5) clsact/ingress cil_from_netdev-ens6 id 576
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 565
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 554
cilium_host(7) clsact/egress cil_from_host-cilium_host id 553
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 479
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 544
lxc99eae1c6e25b(12) clsact/ingress cil_from_container-lxc99eae1c6e25b id 522
lxc98ad2bb19ba4(14) clsact/ingress cil_from_container-lxc98ad2bb19ba4 id 511
lxc7f65f201c280(18) clsact/ingress cil_from_container-lxc7f65f201c280 id 620

flow_dissector:

netfilter:

