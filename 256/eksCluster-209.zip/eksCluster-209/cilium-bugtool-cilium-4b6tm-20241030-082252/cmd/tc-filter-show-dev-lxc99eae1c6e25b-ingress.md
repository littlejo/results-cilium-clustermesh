filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc99eae1c6e25b direct-action not_in_hw id 522 tag c7c119a153789140 jited 
