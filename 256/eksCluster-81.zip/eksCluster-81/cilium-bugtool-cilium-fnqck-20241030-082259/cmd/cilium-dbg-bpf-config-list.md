KEY             VALUE
AgentLiveness   2257623935916
UTimeOffset     3379442095703125
