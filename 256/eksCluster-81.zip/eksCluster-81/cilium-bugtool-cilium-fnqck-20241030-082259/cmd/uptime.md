 08:23:00 up 37 min,  0 users,  load average: 0.38, 0.30, 0.20
