REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37011     2927479     677    bpf_overlay.c
Interface                 INGRESS     654112    134064301   1132   bpf_host.c
Success                   EGRESS      16538     1301443     1694   bpf_host.c
Success                   EGRESS      277359    34497388    1308   bpf_lxc.c
Success                   EGRESS      37188     2941381     53     encap.h
Success                   INGRESS     320567    36139607    86     l3.h
Success                   INGRESS     341691    37809689    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
