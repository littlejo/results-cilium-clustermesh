CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa32bde4_1c2b_4aa4_81d6_05e2b840fc3a.slice/cri-containerd-eb25c3bc6877021ac577117a13b022a48dfbb3abf392b5334526c2b26518d641.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa32bde4_1c2b_4aa4_81d6_05e2b840fc3a.slice/cri-containerd-ca7c1a68701c1c6d333b29f4c063b8819a9a978629df41bf27443c83d5032f62.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4a487ee8_9490_48df_b487_58138d4bca22.slice/cri-containerd-edceb96d2680e4618fb916939f918223d01d5b0705edf5f7fb34ce69d6818927.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4a487ee8_9490_48df_b487_58138d4bca22.slice/cri-containerd-cd5855785a1bbd57d3e83f597de63e4d4ca0cf73415d95f48b285b010aec4cbb.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda312e3fc_5bdb_493d_b18c_a31eb9e8e28f.slice/cri-containerd-07a23fe32fd62726e0c742bfcc458bf65116640fd8618bfca69b3ec513494e4d.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda312e3fc_5bdb_493d_b18c_a31eb9e8e28f.slice/cri-containerd-a915338dc5ca9e1896ba31ec6ba8154c1d99486e3bb377fb80b3738491ceb24c.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod15f4e3cb_b0cc_4c56_853d_3dc909ee4e7f.slice/cri-containerd-0b6b168b290c2663a3f45f62512e55eed4d038b1f96fdb93de1aab1eb36329df.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod15f4e3cb_b0cc_4c56_853d_3dc909ee4e7f.slice/cri-containerd-34d67f4e2301346cbecdff6169a65e4a04764a9acf79cef39dd877ed009d8de5.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod48960f7d_d2b5_46f0_b136_1353c056ae82.slice/cri-containerd-15e05e59eec65d15cd3b9694a282e35f524b7c2cac745e4381d44d0b149147f1.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod48960f7d_d2b5_46f0_b136_1353c056ae82.slice/cri-containerd-5147fbe68eec540f888a8ca87da755730d699d3265f0e6baae44b87455ad3fbf.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod48960f7d_d2b5_46f0_b136_1353c056ae82.slice/cri-containerd-4ee1a8acda5e7191b0f401b7ff352b399edf728ed329c3ffd02a421ee66a14aa.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod48960f7d_d2b5_46f0_b136_1353c056ae82.slice/cri-containerd-0cd5f2f672093250f97d7a76a2031fe14788f620e61fb0cf6575121a2360e321.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod954c57c8_0d15_4cdf_b749_4db76a4b82d6.slice/cri-containerd-788a4f0def3d25240f1f60757e0281543cd5db6a076c6e6b26c3e01419a6fabf.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod954c57c8_0d15_4cdf_b749_4db76a4b82d6.slice/cri-containerd-0fe3a11028c7c3e69b6b96be6a2e628c6a56f03a72207604a24e5b8ab307445e.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6b2db46b_f94d_4f8d_bfbe_f75581170259.slice/cri-containerd-f59c1b2c2e676d0b38ee3428022ba2d9796a58fa933f1c61f5acebc4e7031f1e.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6b2db46b_f94d_4f8d_bfbe_f75581170259.slice/cri-containerd-359725d17d06ef75913c2cb70d570b16dce3639944d34783abb47b35a313dff6.scope
    106      cgroup_device   multi                                          
