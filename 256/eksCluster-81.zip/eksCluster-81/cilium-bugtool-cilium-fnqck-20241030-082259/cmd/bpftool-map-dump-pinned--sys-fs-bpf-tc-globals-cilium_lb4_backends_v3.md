key: 01 00 00 00  value: ac 1f 89 08 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 51 00 7a 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f d9 4c 10 94 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 51 00 ef 09 4b 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f fd c3 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 51 00 62 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 51 00 62 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 51 00 7a 00 35 00 00  00 00 00 00
Found 8 elements
