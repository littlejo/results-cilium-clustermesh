Endpoint ID: 116
Path: /sys/fs/bpf/tc/globals/cilium_policy_00116

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174575   2006      0        
Allow    Egress      0          ANY          NONE         disabled    21396    241       0        


Endpoint ID: 1003
Path: /sys/fs/bpf/tc/globals/cilium_policy_01003

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1671744   21148     0        
Allow    Ingress     1          ANY          NONE         disabled    26632     312       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2188
Path: /sys/fs/bpf/tc/globals/cilium_policy_02188

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11626150   115973    0        
Allow    Ingress     1          ANY          NONE         disabled    10274952   108318    0        
Allow    Egress      0          ANY          NONE         disabled    13276305   130756    0        


Endpoint ID: 2608
Path: /sys/fs/bpf/tc/globals/cilium_policy_02608

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    173820   2000      0        
Allow    Egress      0          ANY          NONE         disabled    20287    228       0        


Endpoint ID: 2897
Path: /sys/fs/bpf/tc/globals/cilium_policy_02897

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


