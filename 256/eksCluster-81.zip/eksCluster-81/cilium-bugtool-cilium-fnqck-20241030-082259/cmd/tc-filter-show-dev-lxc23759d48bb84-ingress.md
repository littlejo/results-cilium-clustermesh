filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc23759d48bb84 direct-action not_in_hw id 622 tag 423e4dfcf7c331f7 jited 
