top - 08:23:00 up 37 min,  0 users,  load average: 0.38, 0.30, 0.20
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s):  9.7 us, 35.5 sy,  0.0 ni, 48.4 id,  0.0 wa,  0.0 hi,  0.0 si,  6.5 st
MiB Mem :   7814.2 total,   4482.6 free,   1185.4 used,   2146.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6443.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    641 root      20   0 1240432  16248  11292 S   6.7   0.2   0:00.04 cilium-+
      1 root      20   0 1606080 378760  78592 S   0.0   4.7   0:59.18 cilium-+
    417 root      20   0 1229744   6968   2864 S   0.0   0.1   0:01.22 cilium-+
    620 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    630 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    640 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    697 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    703 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    714 root      20   0    6576   2408   2084 R   0.0   0.0   0:00.00 top
    735 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    741 root      20   0 1616008   8332   6260 S   0.0   0.1   0:00.00 runc:[2+
