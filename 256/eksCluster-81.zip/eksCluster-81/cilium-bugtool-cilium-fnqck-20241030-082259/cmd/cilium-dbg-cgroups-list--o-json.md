[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda312e3fc_5bdb_493d_b18c_a31eb9e8e28f.slice/cri-containerd-07a23fe32fd62726e0c742bfcc458bf65116640fd8618bfca69b3ec513494e4d.scope"
      }
    ],
    "ips": [
      "10.81.0.98"
    ],
    "name": "coredns-cc6ccd49c-x9frh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod48960f7d_d2b5_46f0_b136_1353c056ae82.slice/cri-containerd-4ee1a8acda5e7191b0f401b7ff352b399edf728ed329c3ffd02a421ee66a14aa.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod48960f7d_d2b5_46f0_b136_1353c056ae82.slice/cri-containerd-0cd5f2f672093250f97d7a76a2031fe14788f620e61fb0cf6575121a2360e321.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod48960f7d_d2b5_46f0_b136_1353c056ae82.slice/cri-containerd-5147fbe68eec540f888a8ca87da755730d699d3265f0e6baae44b87455ad3fbf.scope"
      }
    ],
    "ips": [
      "10.81.0.239"
    ],
    "name": "clustermesh-apiserver-59d75c6bb5-59sjr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4a487ee8_9490_48df_b487_58138d4bca22.slice/cri-containerd-edceb96d2680e4618fb916939f918223d01d5b0705edf5f7fb34ce69d6818927.scope"
      }
    ],
    "ips": [
      "10.81.0.122"
    ],
    "name": "coredns-cc6ccd49c-26mcv",
    "namespace": "kube-system"
  }
]

