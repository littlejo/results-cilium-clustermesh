IP ADDRESS        LOCAL ENDPOINT INFO
172.31.217.76:0   (localhost)                                                                                        
10.81.0.239:0     id=2188  sec_id=2689557 flags=0x0000 ifindex=18  mac=CE:9D:54:15:B3:7B nodemac=52:DA:02:F0:CF:66   
172.31.216.14:0   (localhost)                                                                                        
10.81.0.98:0      id=2608  sec_id=2712718 flags=0x0000 ifindex=12  mac=EE:67:FD:B4:50:EF nodemac=1E:00:71:59:38:87   
10.81.0.66:0      (localhost)                                                                                        
10.81.0.185:0     id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=26:B7:5B:5D:55:01 nodemac=C2:39:72:6B:20:1B     
10.81.0.122:0     id=116   sec_id=2712718 flags=0x0000 ifindex=14  mac=E6:BA:3A:7B:68:4B nodemac=5A:2D:A8:59:42:A5   
