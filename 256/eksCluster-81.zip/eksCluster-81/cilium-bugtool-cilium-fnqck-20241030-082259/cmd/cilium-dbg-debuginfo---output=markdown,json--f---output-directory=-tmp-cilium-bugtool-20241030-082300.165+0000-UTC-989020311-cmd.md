markdown output at /tmp/cilium-bugtool-20241030-082300.165+0000-UTC-989020311/cmd/cilium-debuginfo-20241030-082331.114+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082300.165+0000-UTC-989020311/cmd/cilium-debuginfo-20241030-082331.114+0000-UTC.json
