{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:01.052Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.216.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:01.052Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.217.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:01.052Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:06.140Z",
  "value": "id=2608  sec_id=2712718 flags=0x0000 ifindex=12  mac=EE:67:FD:B4:50:EF nodemac=1E:00:71:59:38:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:06.147Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=26:B7:5B:5D:55:01 nodemac=C2:39:72:6B:20:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:06.204Z",
  "value": "id=116   sec_id=2712718 flags=0x0000 ifindex=14  mac=E6:BA:3A:7B:68:4B nodemac=5A:2D:A8:59:42:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:06.217Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=26:B7:5B:5D:55:01 nodemac=C2:39:72:6B:20:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:23.374Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=26:B7:5B:5D:55:01 nodemac=C2:39:72:6B:20:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:23.375Z",
  "value": "id=116   sec_id=2712718 flags=0x0000 ifindex=14  mac=E6:BA:3A:7B:68:4B nodemac=5A:2D:A8:59:42:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:23.375Z",
  "value": "id=2608  sec_id=2712718 flags=0x0000 ifindex=12  mac=EE:67:FD:B4:50:EF nodemac=1E:00:71:59:38:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:23.407Z",
  "value": "id=2605  sec_id=2689557 flags=0x0000 ifindex=16  mac=8E:F5:F0:EF:7F:9C nodemac=D6:53:50:E5:75:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:24.374Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=26:B7:5B:5D:55:01 nodemac=C2:39:72:6B:20:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:24.374Z",
  "value": "id=2605  sec_id=2689557 flags=0x0000 ifindex=16  mac=8E:F5:F0:EF:7F:9C nodemac=D6:53:50:E5:75:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:24.374Z",
  "value": "id=116   sec_id=2712718 flags=0x0000 ifindex=14  mac=E6:BA:3A:7B:68:4B nodemac=5A:2D:A8:59:42:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:24.374Z",
  "value": "id=2608  sec_id=2712718 flags=0x0000 ifindex=12  mac=EE:67:FD:B4:50:EF nodemac=1E:00:71:59:38:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.375Z",
  "value": "id=2188  sec_id=2689557 flags=0x0000 ifindex=18  mac=CE:9D:54:15:B3:7B nodemac=52:DA:02:F0:CF:66"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.81.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.721Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.571Z",
  "value": "id=2188  sec_id=2689557 flags=0x0000 ifindex=18  mac=CE:9D:54:15:B3:7B nodemac=52:DA:02:F0:CF:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.573Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=26:B7:5B:5D:55:01 nodemac=C2:39:72:6B:20:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.574Z",
  "value": "id=2608  sec_id=2712718 flags=0x0000 ifindex=12  mac=EE:67:FD:B4:50:EF nodemac=1E:00:71:59:38:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.574Z",
  "value": "id=116   sec_id=2712718 flags=0x0000 ifindex=14  mac=E6:BA:3A:7B:68:4B nodemac=5A:2D:A8:59:42:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.551Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=26:B7:5B:5D:55:01 nodemac=C2:39:72:6B:20:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.552Z",
  "value": "id=2188  sec_id=2689557 flags=0x0000 ifindex=18  mac=CE:9D:54:15:B3:7B nodemac=52:DA:02:F0:CF:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.553Z",
  "value": "id=116   sec_id=2712718 flags=0x0000 ifindex=14  mac=E6:BA:3A:7B:68:4B nodemac=5A:2D:A8:59:42:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.553Z",
  "value": "id=2608  sec_id=2712718 flags=0x0000 ifindex=12  mac=EE:67:FD:B4:50:EF nodemac=1E:00:71:59:38:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.552Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=26:B7:5B:5D:55:01 nodemac=C2:39:72:6B:20:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.553Z",
  "value": "id=2608  sec_id=2712718 flags=0x0000 ifindex=12  mac=EE:67:FD:B4:50:EF nodemac=1E:00:71:59:38:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.553Z",
  "value": "id=2188  sec_id=2689557 flags=0x0000 ifindex=18  mac=CE:9D:54:15:B3:7B nodemac=52:DA:02:F0:CF:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.81.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.553Z",
  "value": "id=116   sec_id=2712718 flags=0x0000 ifindex=14  mac=E6:BA:3A:7B:68:4B nodemac=5A:2D:A8:59:42:A5"
}

