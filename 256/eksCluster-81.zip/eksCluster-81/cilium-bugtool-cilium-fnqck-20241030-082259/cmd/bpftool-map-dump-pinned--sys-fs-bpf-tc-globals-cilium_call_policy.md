key: 74 00 00 00  value: 22 02 00 00
key: eb 03 00 00  value: 1e 02 00 00
key: 8c 08 00 00  value: 6d 02 00 00
key: 30 0a 00 00  value: 0b 02 00 00
Found 4 elements
