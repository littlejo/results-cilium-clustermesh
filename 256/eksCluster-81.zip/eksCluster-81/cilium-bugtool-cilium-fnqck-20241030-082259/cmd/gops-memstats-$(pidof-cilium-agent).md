alloc: 149.31MB (156562720 bytes)
total-alloc: 2.33GB (2501029032 bytes)
sys: 332.77MB (348934500 bytes)
lookups: 0
mallocs: 64611848
frees: 63357396
heap-alloc: 149.31MB (156562720 bytes)
heap-sys: 255.52MB (267927552 bytes)
heap-idle: 69.23MB (72589312 bytes)
heap-in-use: 186.29MB (195338240 bytes)
heap-released: 2.84MB (2981888 bytes)
heap-objects: 1254452
stack-in-use: 64.44MB (67567616 bytes)
stack-sys: 64.44MB (67567616 bytes)
stack-mspan-inuse: 2.86MB (2996000 bytes)
stack-mspan-sys: 3.78MB (3965760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.03MB (1078313 bytes)
gc-sys: 6.02MB (6315496 bytes)
next-gc: when heap-alloc >= 213.45MB (223814920 bytes)
last-gc: 2024-10-30 08:23:09.04768988 +0000 UTC
gc-pause-total: 34.412131ms
gc-pause: 160612
gc-pause-end: 1730276589047689880
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.0003841877231909235
enable-gc: true
debug-gc: false
