xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 500
ens6(5) clsact/ingress cil_from_netdev-ens6 id 509
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 496
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 487
cilium_host(7) clsact/egress cil_from_host-cilium_host id 486
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 554
lxc4908abf6867d(12) clsact/ingress cil_from_container-lxc4908abf6867d id 515
lxc5346731f968d(14) clsact/ingress cil_from_container-lxc5346731f968d id 548
lxc23759d48bb84(18) clsact/ingress cil_from_container-lxc23759d48bb84 id 622

flow_dissector:

netfilter:

