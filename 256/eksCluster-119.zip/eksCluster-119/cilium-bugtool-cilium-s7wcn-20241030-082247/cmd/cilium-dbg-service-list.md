ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.161.39:443 (active)     
                                        2 => 172.31.233.206:443 (active)    
2    10.100.78.158:443   ClusterIP      1 => 172.31.192.187:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.119.0.176:53 (active)       
                                        2 => 10.119.0.198:53 (active)       
4    10.100.0.10:9153    ClusterIP      1 => 10.119.0.176:9153 (active)     
                                        2 => 10.119.0.198:9153 (active)     
5    10.100.71.92:2379   ClusterIP      1 => 10.119.0.61:2379 (active)      
