Endpoint ID: 185
Path: /sys/fs/bpf/tc/globals/cilium_policy_00185

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1641965   20729     0        
Allow    Ingress     1          ANY          NONE         disabled    22906     267       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 201
Path: /sys/fs/bpf/tc/globals/cilium_policy_00201

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    149221   1699      0        
Allow    Egress      0          ANY          NONE         disabled    19042    211       0        


Endpoint ID: 284
Path: /sys/fs/bpf/tc/globals/cilium_policy_00284

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    150145   1713      0        
Allow    Egress      0          ANY          NONE         disabled    19412    216       0        


Endpoint ID: 694
Path: /sys/fs/bpf/tc/globals/cilium_policy_00694

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2769
Path: /sys/fs/bpf/tc/globals/cilium_policy_02769

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11545064   114804    0        
Allow    Ingress     1          ANY          NONE         disabled    10073783   106028    0        
Allow    Egress      0          ANY          NONE         disabled    12578322   124093    0        


