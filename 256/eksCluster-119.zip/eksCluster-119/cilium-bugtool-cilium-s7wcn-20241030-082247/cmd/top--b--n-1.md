top - 08:22:49 up 34 min,  0 users,  load average: 0.13, 0.17, 0.16
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 70.6 us, 26.5 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  2.9 si,  0.0 st
MiB Mem :   7814.2 total,   4476.8 free,   1190.7 used,   2146.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6438.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606144 383040  78784 S 100.0   4.8   0:49.49 cilium-+
    638 root      20   0 1240432  16748  11548 S   6.2   0.2   0:00.03 cilium-+
    416 root      20   0 1229744   6960   2864 S   0.0   0.1   0:01.13 cilium-+
    707 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    718 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    726 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    749 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
