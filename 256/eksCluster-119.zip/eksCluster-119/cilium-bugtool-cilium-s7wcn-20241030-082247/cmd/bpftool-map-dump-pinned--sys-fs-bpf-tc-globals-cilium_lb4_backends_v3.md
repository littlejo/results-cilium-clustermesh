key: 01 00 00 00  value: ac 1f a1 27 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 77 00 c6 00 35 00 00  00 00 00 00
key: 03 00 00 00  value: ac 1f c0 bb 10 94 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 77 00 3d 09 4b 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f e9 ce 01 bb 00 00  00 00 00 00
key: 04 00 00 00  value: 0a 77 00 b0 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 77 00 c6 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 77 00 b0 23 c1 00 00  00 00 00 00
Found 8 elements
