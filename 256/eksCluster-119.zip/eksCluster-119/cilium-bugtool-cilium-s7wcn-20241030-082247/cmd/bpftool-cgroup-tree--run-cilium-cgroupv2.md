CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc6b982d2_5d90_4367_8a95_acb814b9f40f.slice/cri-containerd-03b0dc765c91628f6bb84405bab7bcce4005a69fb52a3e616d718dd3653cad19.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc6b982d2_5d90_4367_8a95_acb814b9f40f.slice/cri-containerd-b280c7b05395b17264d12b000d2b980b242da46fa4abeb1182a5cb452af2e013.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f0b88fb_e00e_4383_91b9_18097639298b.slice/cri-containerd-00450acd8e5fb0b5d34b566a9626ae7a2eb1b9e594928b01688d0a2a6dd3a3e3.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f0b88fb_e00e_4383_91b9_18097639298b.slice/cri-containerd-4495fc3c02aed3f8114a30adc3fcd73098536f9b86d70c63454c8086a68b0f95.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6552a1c_568c_4a07_9376_d22d39deeef5.slice/cri-containerd-ead4a4066d36710e95bda91df6508b2fb0238ea4a722ffa362ffcf5d4d371615.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6552a1c_568c_4a07_9376_d22d39deeef5.slice/cri-containerd-7090c94076f15ee5ad093dffae82ebaa2b26206c4ff49ea9b7a5ce3fdddfff21.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3e2b62ee_7534_4902_8f27_122e65a5fc26.slice/cri-containerd-3a8f9e87a991fdf282aee09f9822906221a14dd32383e5586539af6faff31c5b.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3e2b62ee_7534_4902_8f27_122e65a5fc26.slice/cri-containerd-8ce6ca3fc903ab1698fe29fced5a5867e4bad1277f360917b90da2647fa06942.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod87bf687a_a792_4e2e_9be6_33334c68d4f8.slice/cri-containerd-4fadd084af96d5d00f7b3e477a6e5e136651f3d4cbcccfed58887caf140dcbc0.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod87bf687a_a792_4e2e_9be6_33334c68d4f8.slice/cri-containerd-35faabe535f2392bf3697766d8925f7d897c960f0e65396f4ae5f5d054eefe96.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod87bf687a_a792_4e2e_9be6_33334c68d4f8.slice/cri-containerd-22ae7954998de785ca3a63a763639a80ca81d638daa5cd2bd072cbbc2e227be6.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod87bf687a_a792_4e2e_9be6_33334c68d4f8.slice/cri-containerd-2e493126bc4021e25f1a0214ad1e28c0eae8cd864597924282ca66e730646c70.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83c5f542_eeaa_4578_a5bc_7825c119e2c0.slice/cri-containerd-545113f5773dfd584edcc17b9c62040a1b12d4e0a2302131a37e3902c1478b43.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83c5f542_eeaa_4578_a5bc_7825c119e2c0.slice/cri-containerd-60b168da270e588391c147aec2dc25352fd44e9c8a697702b622a0b24525c129.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a46b002_3cad_457e_b27b_edf7d32fb61b.slice/cri-containerd-e9430bbb1e8754d197cd4615dcd82af447299d9e73eb44548abb3c098b423188.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a46b002_3cad_457e_b27b_edf7d32fb61b.slice/cri-containerd-a6fb3762e7b3b1be4724135e7894a6ae42fadcd858d341c6ee66377576effc82.scope
    103      cgroup_device   multi                                          
