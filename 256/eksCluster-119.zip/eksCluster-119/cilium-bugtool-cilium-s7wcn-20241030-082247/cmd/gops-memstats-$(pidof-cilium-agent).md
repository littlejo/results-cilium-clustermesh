alloc: 208.54MB (218671256 bytes)
total-alloc: 2.28GB (2448926760 bytes)
sys: 336.90MB (353262964 bytes)
lookups: 0
mallocs: 63864598
frees: 61639573
heap-alloc: 208.54MB (218671256 bytes)
heap-sys: 258.83MB (271400960 bytes)
heap-idle: 29.62MB (31064064 bytes)
heap-in-use: 229.20MB (240336896 bytes)
heap-released: 6.09MB (6389760 bytes)
heap-objects: 2225025
stack-in-use: 65.12MB (68288512 bytes)
stack-sys: 65.12MB (68288512 bytes)
stack-mspan-inuse: 3.61MB (3785440 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 949.72KB (972513 bytes)
gc-sys: 6.19MB (6488808 bytes)
next-gc: when heap-alloc >= 226.89MB (237906776 bytes)
last-gc: 2024-10-30 08:22:49.436185422 +0000 UTC
gc-pause-total: 13.654432ms
gc-pause: 2343504
gc-pause-end: 1730276569436185422
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.00043099647751517205
enable-gc: true
debug-gc: false
