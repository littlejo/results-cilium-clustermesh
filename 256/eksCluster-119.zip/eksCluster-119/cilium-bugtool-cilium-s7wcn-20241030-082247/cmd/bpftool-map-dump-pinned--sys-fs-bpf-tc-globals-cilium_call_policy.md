key: b9 00 00 00  value: 18 02 00 00
key: c9 00 00 00  value: 24 02 00 00
key: 1c 01 00 00  value: 04 02 00 00
key: d1 0a 00 00  value: 68 02 00 00
Found 4 elements
