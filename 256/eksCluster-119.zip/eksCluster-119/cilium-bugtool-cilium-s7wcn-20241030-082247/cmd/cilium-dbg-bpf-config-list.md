KEY             VALUE
AgentLiveness   2094332144288
UTimeOffset     3379442394531250
