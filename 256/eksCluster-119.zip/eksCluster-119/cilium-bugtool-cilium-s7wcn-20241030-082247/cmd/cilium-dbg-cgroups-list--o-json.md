[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc6b982d2_5d90_4367_8a95_acb814b9f40f.slice/cri-containerd-03b0dc765c91628f6bb84405bab7bcce4005a69fb52a3e616d718dd3653cad19.scope"
      }
    ],
    "ips": [
      "10.119.0.176"
    ],
    "name": "coredns-cc6ccd49c-b6phh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod87bf687a_a792_4e2e_9be6_33334c68d4f8.slice/cri-containerd-4fadd084af96d5d00f7b3e477a6e5e136651f3d4cbcccfed58887caf140dcbc0.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod87bf687a_a792_4e2e_9be6_33334c68d4f8.slice/cri-containerd-35faabe535f2392bf3697766d8925f7d897c960f0e65396f4ae5f5d054eefe96.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod87bf687a_a792_4e2e_9be6_33334c68d4f8.slice/cri-containerd-22ae7954998de785ca3a63a763639a80ca81d638daa5cd2bd072cbbc2e227be6.scope"
      }
    ],
    "ips": [
      "10.119.0.61"
    ],
    "name": "clustermesh-apiserver-7fcc75df85-g6p9k",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3e2b62ee_7534_4902_8f27_122e65a5fc26.slice/cri-containerd-8ce6ca3fc903ab1698fe29fced5a5867e4bad1277f360917b90da2647fa06942.scope"
      }
    ],
    "ips": [
      "10.119.0.198"
    ],
    "name": "coredns-cc6ccd49c-xqhhb",
    "namespace": "kube-system"
  }
]

