 08:22:49 up 34 min,  0 users,  load average: 0.13, 0.17, 0.16
