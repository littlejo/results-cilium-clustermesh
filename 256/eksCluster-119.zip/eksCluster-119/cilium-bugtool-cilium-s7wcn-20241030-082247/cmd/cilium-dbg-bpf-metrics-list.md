REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36615     2899280     677    bpf_overlay.c
Interface                 INGRESS     645143    132202297   1132   bpf_host.c
Success                   EGRESS      16560     1303164     1694   bpf_host.c
Success                   EGRESS      270944    33961648    1308   bpf_lxc.c
Success                   EGRESS      36908     2919325     53     encap.h
Success                   INGRESS     314706    35370893    86     l3.h
Success                   INGRESS     335412    37011055    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
