IP ADDRESS         LOCAL ENDPOINT INFO
10.119.0.198:0     id=201   sec_id=3943978 flags=0x0000 ifindex=14  mac=7A:F0:F3:6D:62:46 nodemac=92:C3:50:8B:53:08   
172.31.206.94:0    (localhost)                                                                                        
10.119.0.176:0     id=284   sec_id=3943978 flags=0x0000 ifindex=12  mac=BE:EF:F6:2E:FC:DD nodemac=5E:46:91:5B:F7:A1   
172.31.192.187:0   (localhost)                                                                                        
10.119.0.224:0     id=185   sec_id=4     flags=0x0000 ifindex=10  mac=92:08:EC:C4:B2:A9 nodemac=56:B3:94:2B:0F:25     
10.119.0.185:0     (localhost)                                                                                        
10.119.0.61:0      id=2769  sec_id=3944826 flags=0x0000 ifindex=18  mac=9A:44:B9:13:FA:71 nodemac=42:D7:01:A7:D3:FA   
