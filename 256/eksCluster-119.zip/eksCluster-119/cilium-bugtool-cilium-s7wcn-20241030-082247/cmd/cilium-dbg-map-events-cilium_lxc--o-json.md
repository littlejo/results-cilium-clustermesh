{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:46.770Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.192.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:46.770Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.206.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:46.770Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:51.440Z",
  "value": "id=185   sec_id=4     flags=0x0000 ifindex=10  mac=92:08:EC:C4:B2:A9 nodemac=56:B3:94:2B:0F:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:51.447Z",
  "value": "id=284   sec_id=3943978 flags=0x0000 ifindex=12  mac=BE:EF:F6:2E:FC:DD nodemac=5E:46:91:5B:F7:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:51.485Z",
  "value": "id=201   sec_id=3943978 flags=0x0000 ifindex=14  mac=7A:F0:F3:6D:62:46 nodemac=92:C3:50:8B:53:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:51.491Z",
  "value": "id=284   sec_id=3943978 flags=0x0000 ifindex=12  mac=BE:EF:F6:2E:FC:DD nodemac=5E:46:91:5B:F7:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:51.505Z",
  "value": "id=185   sec_id=4     flags=0x0000 ifindex=10  mac=92:08:EC:C4:B2:A9 nodemac=56:B3:94:2B:0F:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:33.434Z",
  "value": "id=185   sec_id=4     flags=0x0000 ifindex=10  mac=92:08:EC:C4:B2:A9 nodemac=56:B3:94:2B:0F:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:33.435Z",
  "value": "id=284   sec_id=3943978 flags=0x0000 ifindex=12  mac=BE:EF:F6:2E:FC:DD nodemac=5E:46:91:5B:F7:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:33.435Z",
  "value": "id=201   sec_id=3943978 flags=0x0000 ifindex=14  mac=7A:F0:F3:6D:62:46 nodemac=92:C3:50:8B:53:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:33.465Z",
  "value": "id=3511  sec_id=3944826 flags=0x0000 ifindex=16  mac=9E:4E:8D:CE:B4:D3 nodemac=82:86:FA:0B:B9:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:34.435Z",
  "value": "id=185   sec_id=4     flags=0x0000 ifindex=10  mac=92:08:EC:C4:B2:A9 nodemac=56:B3:94:2B:0F:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:34.435Z",
  "value": "id=284   sec_id=3943978 flags=0x0000 ifindex=12  mac=BE:EF:F6:2E:FC:DD nodemac=5E:46:91:5B:F7:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:34.435Z",
  "value": "id=3511  sec_id=3944826 flags=0x0000 ifindex=16  mac=9E:4E:8D:CE:B4:D3 nodemac=82:86:FA:0B:B9:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:34.435Z",
  "value": "id=201   sec_id=3943978 flags=0x0000 ifindex=14  mac=7A:F0:F3:6D:62:46 nodemac=92:C3:50:8B:53:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.329Z",
  "value": "id=2769  sec_id=3944826 flags=0x0000 ifindex=18  mac=9A:44:B9:13:FA:71 nodemac=42:D7:01:A7:D3:FA"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.119.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.760Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.582Z",
  "value": "id=185   sec_id=4     flags=0x0000 ifindex=10  mac=92:08:EC:C4:B2:A9 nodemac=56:B3:94:2B:0F:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.584Z",
  "value": "id=201   sec_id=3943978 flags=0x0000 ifindex=14  mac=7A:F0:F3:6D:62:46 nodemac=92:C3:50:8B:53:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.584Z",
  "value": "id=2769  sec_id=3944826 flags=0x0000 ifindex=18  mac=9A:44:B9:13:FA:71 nodemac=42:D7:01:A7:D3:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.589Z",
  "value": "id=284   sec_id=3943978 flags=0x0000 ifindex=12  mac=BE:EF:F6:2E:FC:DD nodemac=5E:46:91:5B:F7:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.580Z",
  "value": "id=2769  sec_id=3944826 flags=0x0000 ifindex=18  mac=9A:44:B9:13:FA:71 nodemac=42:D7:01:A7:D3:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.580Z",
  "value": "id=185   sec_id=4     flags=0x0000 ifindex=10  mac=92:08:EC:C4:B2:A9 nodemac=56:B3:94:2B:0F:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.581Z",
  "value": "id=284   sec_id=3943978 flags=0x0000 ifindex=12  mac=BE:EF:F6:2E:FC:DD nodemac=5E:46:91:5B:F7:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.581Z",
  "value": "id=201   sec_id=3943978 flags=0x0000 ifindex=14  mac=7A:F0:F3:6D:62:46 nodemac=92:C3:50:8B:53:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.580Z",
  "value": "id=185   sec_id=4     flags=0x0000 ifindex=10  mac=92:08:EC:C4:B2:A9 nodemac=56:B3:94:2B:0F:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.580Z",
  "value": "id=2769  sec_id=3944826 flags=0x0000 ifindex=18  mac=9A:44:B9:13:FA:71 nodemac=42:D7:01:A7:D3:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.580Z",
  "value": "id=284   sec_id=3943978 flags=0x0000 ifindex=12  mac=BE:EF:F6:2E:FC:DD nodemac=5E:46:91:5B:F7:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.581Z",
  "value": "id=201   sec_id=3943978 flags=0x0000 ifindex=14  mac=7A:F0:F3:6D:62:46 nodemac=92:C3:50:8B:53:08"
}

