REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38037     3015599     677    bpf_overlay.c
Interface                 INGRESS     671910    136015794   1132   bpf_host.c
Success                   EGRESS      17644     1394945     1694   bpf_host.c
Success                   EGRESS      283933    35150549    1308   bpf_lxc.c
Success                   EGRESS      38967     3084347     53     encap.h
Success                   INGRESS     327782    36991852    86     l3.h
Success                   INGRESS     348826    38656552    235    trace.h
Unsupported L3 protocol   EGRESS      42        3132        1492   bpf_lxc.c
