{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:01.394Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.161.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:01.394Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.165.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:01.394Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:06.028Z",
  "value": "id=399   sec_id=2150024 flags=0x0000 ifindex=12  mac=4E:0F:14:55:25:BB nodemac=8A:FE:A0:6B:12:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:06.049Z",
  "value": "id=976   sec_id=4     flags=0x0000 ifindex=10  mac=2E:94:1F:23:DF:38 nodemac=CE:51:F7:DD:BB:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:06.053Z",
  "value": "id=399   sec_id=2150024 flags=0x0000 ifindex=12  mac=4E:0F:14:55:25:BB nodemac=8A:FE:A0:6B:12:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:06.107Z",
  "value": "id=1023  sec_id=2150024 flags=0x0000 ifindex=14  mac=7A:55:E5:30:29:04 nodemac=62:10:E4:E2:39:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:06.118Z",
  "value": "id=976   sec_id=4     flags=0x0000 ifindex=10  mac=2E:94:1F:23:DF:38 nodemac=CE:51:F7:DD:BB:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:24.428Z",
  "value": "id=976   sec_id=4     flags=0x0000 ifindex=10  mac=2E:94:1F:23:DF:38 nodemac=CE:51:F7:DD:BB:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:24.428Z",
  "value": "id=1023  sec_id=2150024 flags=0x0000 ifindex=14  mac=7A:55:E5:30:29:04 nodemac=62:10:E4:E2:39:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:24.429Z",
  "value": "id=399   sec_id=2150024 flags=0x0000 ifindex=12  mac=4E:0F:14:55:25:BB nodemac=8A:FE:A0:6B:12:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:24.458Z",
  "value": "id=2301  sec_id=2131144 flags=0x0000 ifindex=16  mac=FA:C1:C8:71:C3:1C nodemac=7E:7D:F7:5F:FB:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:25.429Z",
  "value": "id=976   sec_id=4     flags=0x0000 ifindex=10  mac=2E:94:1F:23:DF:38 nodemac=CE:51:F7:DD:BB:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:25.429Z",
  "value": "id=2301  sec_id=2131144 flags=0x0000 ifindex=16  mac=FA:C1:C8:71:C3:1C nodemac=7E:7D:F7:5F:FB:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:25.429Z",
  "value": "id=399   sec_id=2150024 flags=0x0000 ifindex=12  mac=4E:0F:14:55:25:BB nodemac=8A:FE:A0:6B:12:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:25.429Z",
  "value": "id=1023  sec_id=2150024 flags=0x0000 ifindex=14  mac=7A:55:E5:30:29:04 nodemac=62:10:E4:E2:39:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.028Z",
  "value": "id=1335  sec_id=2131144 flags=0x0000 ifindex=18  mac=7E:2A:FD:6A:73:CB nodemac=5A:B4:24:C1:11:D7"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.64.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.385Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.006Z",
  "value": "id=399   sec_id=2150024 flags=0x0000 ifindex=12  mac=4E:0F:14:55:25:BB nodemac=8A:FE:A0:6B:12:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.006Z",
  "value": "id=1335  sec_id=2131144 flags=0x0000 ifindex=18  mac=7E:2A:FD:6A:73:CB nodemac=5A:B4:24:C1:11:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.007Z",
  "value": "id=976   sec_id=4     flags=0x0000 ifindex=10  mac=2E:94:1F:23:DF:38 nodemac=CE:51:F7:DD:BB:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.008Z",
  "value": "id=1023  sec_id=2150024 flags=0x0000 ifindex=14  mac=7A:55:E5:30:29:04 nodemac=62:10:E4:E2:39:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.011Z",
  "value": "id=399   sec_id=2150024 flags=0x0000 ifindex=12  mac=4E:0F:14:55:25:BB nodemac=8A:FE:A0:6B:12:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.014Z",
  "value": "id=1335  sec_id=2131144 flags=0x0000 ifindex=18  mac=7E:2A:FD:6A:73:CB nodemac=5A:B4:24:C1:11:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.015Z",
  "value": "id=976   sec_id=4     flags=0x0000 ifindex=10  mac=2E:94:1F:23:DF:38 nodemac=CE:51:F7:DD:BB:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.016Z",
  "value": "id=1023  sec_id=2150024 flags=0x0000 ifindex=14  mac=7A:55:E5:30:29:04 nodemac=62:10:E4:E2:39:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.038Z",
  "value": "id=399   sec_id=2150024 flags=0x0000 ifindex=12  mac=4E:0F:14:55:25:BB nodemac=8A:FE:A0:6B:12:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.042Z",
  "value": "id=1335  sec_id=2131144 flags=0x0000 ifindex=18  mac=7E:2A:FD:6A:73:CB nodemac=5A:B4:24:C1:11:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.043Z",
  "value": "id=976   sec_id=4     flags=0x0000 ifindex=10  mac=2E:94:1F:23:DF:38 nodemac=CE:51:F7:DD:BB:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.043Z",
  "value": "id=1023  sec_id=2150024 flags=0x0000 ifindex=14  mac=7A:55:E5:30:29:04 nodemac=62:10:E4:E2:39:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.007Z",
  "value": "id=1335  sec_id=2131144 flags=0x0000 ifindex=18  mac=7E:2A:FD:6A:73:CB nodemac=5A:B4:24:C1:11:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.007Z",
  "value": "id=1023  sec_id=2150024 flags=0x0000 ifindex=14  mac=7A:55:E5:30:29:04 nodemac=62:10:E4:E2:39:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.007Z",
  "value": "id=976   sec_id=4     flags=0x0000 ifindex=10  mac=2E:94:1F:23:DF:38 nodemac=CE:51:F7:DD:BB:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.008Z",
  "value": "id=399   sec_id=2150024 flags=0x0000 ifindex=12  mac=4E:0F:14:55:25:BB nodemac=8A:FE:A0:6B:12:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.007Z",
  "value": "id=399   sec_id=2150024 flags=0x0000 ifindex=12  mac=4E:0F:14:55:25:BB nodemac=8A:FE:A0:6B:12:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.007Z",
  "value": "id=1335  sec_id=2131144 flags=0x0000 ifindex=18  mac=7E:2A:FD:6A:73:CB nodemac=5A:B4:24:C1:11:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.007Z",
  "value": "id=976   sec_id=4     flags=0x0000 ifindex=10  mac=2E:94:1F:23:DF:38 nodemac=CE:51:F7:DD:BB:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.64.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.008Z",
  "value": "id=1023  sec_id=2150024 flags=0x0000 ifindex=14  mac=7A:55:E5:30:29:04 nodemac=62:10:E4:E2:39:9E"
}

