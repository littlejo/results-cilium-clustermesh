ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.229.8:443 (active)     
                                         2 => 172.31.181.112:443 (active)   
2    10.100.97.134:443    ClusterIP      1 => 172.31.165.36:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.64.0.116:9153 (active)     
                                         2 => 10.64.0.126:9153 (active)     
4    10.100.0.10:53       ClusterIP      1 => 10.64.0.116:53 (active)       
                                         2 => 10.64.0.126:53 (active)       
5    10.100.26.137:2379   ClusterIP      1 => 10.64.0.190:2379 (active)     
