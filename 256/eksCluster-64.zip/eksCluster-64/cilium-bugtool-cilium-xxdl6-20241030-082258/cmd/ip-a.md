1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:3b:b9:82:6a:6d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.165.36/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3192sec preferred_lft 3192sec
    inet6 fe80::43b:b9ff:fe82:6a6d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:73:0e:72:6e:89 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.161.159/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::473:eff:fe72:6e89/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:92:9b:b6:e9:49 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5c92:9bff:feb6:e949/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:05:17:87:b0:52 brd ff:ff:ff:ff:ff:ff
    inet 10.64.0.231/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::6005:17ff:fe87:b052/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 96:da:c8:7b:8a:26 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::94da:c8ff:fe7b:8a26/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:51:f7:dd:bb:46 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::cc51:f7ff:fedd:bb46/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcea2992034141@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:fe:a0:6b:12:e4 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::88fe:a0ff:fe6b:12e4/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc0b346cadd6ec@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:10:e4:e2:39:9e brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::6010:e4ff:fee2:399e/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc795071444a25@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:b4:24:c1:11:d7 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::58b4:24ff:fec1:11d7/64 scope link 
       valid_lft forever preferred_lft forever
