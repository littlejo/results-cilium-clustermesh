 08:23:00 up 37 min,  0 users,  load average: 0.86, 0.48, 0.32
