CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7ba4c794_f1c9_437d_bfaa_552f55efdb7f.slice/cri-containerd-59e1d61ee767e36098de0224800b73442d0a0e18bcdd2bc4cf2339a5f715af40.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7ba4c794_f1c9_437d_bfaa_552f55efdb7f.slice/cri-containerd-fcf505df8a085faf95f68c6034483aed6c8b319522b40fb77fc0a82733e4a942.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod29c30008_0345_4566_8338_15623be5679c.slice/cri-containerd-7c5eabe47af048e73c458638e0cff5f3313ef92aa874a240187693e76a31d0f1.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod29c30008_0345_4566_8338_15623be5679c.slice/cri-containerd-fb3083eab8d836306f3411099a02fcdb602db4403defcc221d5db4667ccf14ad.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf03e787b_748e_4c5b_b858_c839240a8678.slice/cri-containerd-f91aea848f826a6bc104f38aac8e9f1962e6ef9fec41d28e1096c887c4187320.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf03e787b_748e_4c5b_b858_c839240a8678.slice/cri-containerd-a81d272f6128d2341322b6e2b552b39b1c0feff053e38bca8a2b0ae155cb415a.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod48b8f825_39f0_485e_abe1_f789cc9c3626.slice/cri-containerd-c0bf02ca20bcfa5684248bac91328b4fbcbf7544597eba64807b797662f3f82e.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod48b8f825_39f0_485e_abe1_f789cc9c3626.slice/cri-containerd-56db9fc709348ebfc3d9196c017681360cdada1b662dba952b7cdb02ee103290.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9eda0a39_d616_4357_9ab7_73e12710ee68.slice/cri-containerd-14bb0e1b78b57510603b59f26b572ba7cb6f0c953c1dbc4ea723db4d3099db20.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9eda0a39_d616_4357_9ab7_73e12710ee68.slice/cri-containerd-e1e59f4ec476f0ca5c377b2bc3bdc3dbbfa9e4cc34b9579177db62d1a6b0c5eb.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod172ab11d_eede_4be7_b03c_81d9e8227b22.slice/cri-containerd-3829349d4bc28ba03727e106633934d3db55909d9ca41103c808f5441050b283.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod172ab11d_eede_4be7_b03c_81d9e8227b22.slice/cri-containerd-3ddda30c716b18f6c02fee710e17631859a2ac1ab437eeea2b0ca7b6c017c4a4.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d216f1a_68ff_4572_84bb_c2be6aa322d5.slice/cri-containerd-b1e43dfa69c6b26767e350b9fc58c5b1ee9b64b09d78ce75bd20f3ca612efb8f.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d216f1a_68ff_4572_84bb_c2be6aa322d5.slice/cri-containerd-241f64fa3840403fd91681ecde794e7847b06a6c911fb441d84028708bc7879b.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d216f1a_68ff_4572_84bb_c2be6aa322d5.slice/cri-containerd-5ba0f38704d1dfbf6bde8df820265e6fdca068e50f8a3bdedd8da2a337c88a18.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d216f1a_68ff_4572_84bb_c2be6aa322d5.slice/cri-containerd-af3d69b5a7332c27a347a5b8fed357b80fab7006d6d1dbdb84425d09dd32e16e.scope
    643      cgroup_device   multi                                          
