KEY             VALUE
AgentLiveness   2251955215986
UTimeOffset     3379442107421875
