key: 8f 01 00 00  value: 0b 02 00 00
key: d0 03 00 00  value: 17 02 00 00
key: ff 03 00 00  value: 18 02 00 00
key: 37 05 00 00  value: 62 02 00 00
Found 4 elements
