Endpoint ID: 298
Path: /sys/fs/bpf/tc/globals/cilium_policy_00298

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 399
Path: /sys/fs/bpf/tc/globals/cilium_policy_00399

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    172727   1978      0        
Allow    Egress      0          ANY          NONE         disabled    22410    253       0        


Endpoint ID: 976
Path: /sys/fs/bpf/tc/globals/cilium_policy_00976

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1667278   21077     0        
Allow    Ingress     1          ANY          NONE         disabled    26294     307       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1023
Path: /sys/fs/bpf/tc/globals/cilium_policy_01023

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    172661   1977      0        
Allow    Egress      0          ANY          NONE         disabled    21287    239       0        


Endpoint ID: 1335
Path: /sys/fs/bpf/tc/globals/cilium_policy_01335

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11682178   117158    0        
Allow    Ingress     1          ANY          NONE         disabled    10720659   113068    0        
Allow    Egress      0          ANY          NONE         disabled    13914806   136534    0        


