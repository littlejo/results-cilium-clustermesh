markdown output at /tmp/cilium-bugtool-20241030-082300.146+0000-UTC-538852652/cmd/cilium-debuginfo-20241030-082331.318+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082300.146+0000-UTC-538852652/cmd/cilium-debuginfo-20241030-082331.318+0000-UTC.json
