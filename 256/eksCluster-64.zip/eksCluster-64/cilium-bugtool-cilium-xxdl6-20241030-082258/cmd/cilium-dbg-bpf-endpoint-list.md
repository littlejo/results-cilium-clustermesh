IP ADDRESS         LOCAL ENDPOINT INFO
10.64.0.116:0      id=399   sec_id=2150024 flags=0x0000 ifindex=12  mac=4E:0F:14:55:25:BB nodemac=8A:FE:A0:6B:12:E4   
10.64.0.231:0      (localhost)                                                                                        
10.64.0.126:0      id=1023  sec_id=2150024 flags=0x0000 ifindex=14  mac=7A:55:E5:30:29:04 nodemac=62:10:E4:E2:39:9E   
10.64.0.117:0      id=976   sec_id=4     flags=0x0000 ifindex=10  mac=2E:94:1F:23:DF:38 nodemac=CE:51:F7:DD:BB:46     
172.31.165.36:0    (localhost)                                                                                        
10.64.0.190:0      id=1335  sec_id=2131144 flags=0x0000 ifindex=18  mac=7E:2A:FD:6A:73:CB nodemac=5A:B4:24:C1:11:D7   
172.31.161.159:0   (localhost)                                                                                        
