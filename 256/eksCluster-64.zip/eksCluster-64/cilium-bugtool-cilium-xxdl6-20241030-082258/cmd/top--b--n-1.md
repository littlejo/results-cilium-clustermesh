top - 08:23:00 up 37 min,  0 users,  load average: 0.86, 0.48, 0.32
Tasks:  12 total,   2 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 53.3 us, 33.3 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi, 13.3 si,  0.0 st
MiB Mem :   7814.2 total,   4460.9 free,   1205.9 used,   2147.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6423.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    684 root      20   0 1244340  22136  14336 S  46.7   0.3   0:00.19 hubble
      1 root      20   0 1606080 388532  78792 S  13.3   4.9   0:57.79 cilium-+
    418 root      20   0 1229744   8232   3836 S   0.0   0.1   0:01.17 cilium-+
    643 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    653 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    663 root      20   0    2208    784    704 S   0.0   0.0   0:00.00 timeout
    664 root      20   0 1240432  15852  11100 S   0.0   0.2   0:00.03 cilium-+
    673 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    683 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    742 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    754 root      20   0 1616264   8852   6344 S   0.0   0.1   0:00.00 runc:[2+
    763 root      20   0    2128    492    420 R   0.0   0.0   0:00.00 ip
