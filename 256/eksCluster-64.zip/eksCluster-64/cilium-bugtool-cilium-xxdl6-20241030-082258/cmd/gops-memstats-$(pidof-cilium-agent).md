alloc: 128.57MB (134816984 bytes)
total-alloc: 2.37GB (2546812728 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 65324741
frees: 64361461
heap-alloc: 128.57MB (134816984 bytes)
heap-sys: 252.10MB (264347648 bytes)
heap-idle: 66.52MB (69746688 bytes)
heap-in-use: 185.59MB (194600960 bytes)
heap-released: 1.01MB (1056768 bytes)
heap-objects: 963280
stack-in-use: 63.88MB (66977792 bytes)
stack-sys: 63.88MB (66977792 bytes)
stack-mspan-inuse: 2.92MB (3066720 bytes)
stack-mspan-sys: 3.91MB (4096320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 921.81KB (943929 bytes)
gc-sys: 6.01MB (6303256 bytes)
next-gc: when heap-alloc >= 212.96MB (223308520 bytes)
last-gc: 2024-10-30 08:23:18.798773753 +0000 UTC
gc-pause-total: 22.893135ms
gc-pause: 100843
gc-pause-end: 1730276598798773753
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.000376688070404565
enable-gc: true
debug-gc: false
