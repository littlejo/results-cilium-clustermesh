xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 501
ens6(5) clsact/ingress cil_from_netdev-ens6 id 504
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 491
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 488
cilium_host(7) clsact/egress cil_from_host-cilium_host id 486
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 478
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 551
lxcea2992034141(12) clsact/ingress cil_from_container-lxcea2992034141 id 511
lxc0b346cadd6ec(14) clsact/ingress cil_from_container-lxc0b346cadd6ec id 538
lxc795071444a25(18) clsact/ingress cil_from_container-lxc795071444a25 id 619

flow_dissector:

netfilter:

