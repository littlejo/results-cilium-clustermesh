[
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d216f1a_68ff_4572_84bb_c2be6aa322d5.slice/cri-containerd-af3d69b5a7332c27a347a5b8fed357b80fab7006d6d1dbdb84425d09dd32e16e.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d216f1a_68ff_4572_84bb_c2be6aa322d5.slice/cri-containerd-241f64fa3840403fd91681ecde794e7847b06a6c911fb441d84028708bc7879b.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d216f1a_68ff_4572_84bb_c2be6aa322d5.slice/cri-containerd-b1e43dfa69c6b26767e350b9fc58c5b1ee9b64b09d78ce75bd20f3ca612efb8f.scope"
      }
    ],
    "ips": [
      "10.64.0.190"
    ],
    "name": "clustermesh-apiserver-d6bdc5666-9vszh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7835,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod48b8f825_39f0_485e_abe1_f789cc9c3626.slice/cri-containerd-c0bf02ca20bcfa5684248bac91328b4fbcbf7544597eba64807b797662f3f82e.scope"
      }
    ],
    "ips": [
      "10.64.0.116"
    ],
    "name": "coredns-cc6ccd49c-csj95",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7751,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod29c30008_0345_4566_8338_15623be5679c.slice/cri-containerd-fb3083eab8d836306f3411099a02fcdb602db4403defcc221d5db4667ccf14ad.scope"
      }
    ],
    "ips": [
      "10.64.0.126"
    ],
    "name": "coredns-cc6ccd49c-vmjmn",
    "namespace": "kube-system"
  }
]

