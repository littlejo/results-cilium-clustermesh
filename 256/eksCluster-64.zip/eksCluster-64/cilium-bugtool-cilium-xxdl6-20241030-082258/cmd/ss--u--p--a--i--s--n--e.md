Total: 672
TCP:   1865 (estab 437, closed 1409, orphaned 0, timewait 570)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  456       443       13       
INET	  466       449       17       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                            127.0.0.1:36081      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:31704 sk:10f5 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.165.36%ens5:68         0.0.0.0:*    uid:192 ino:65436 sk:10f6 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:32625 sk:10f7 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15016 sk:10f8 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:32624 sk:10f9 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15017 sk:10fa cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::43b:b9ff:fe82:6a6d]%ens5:546           [::]:*    uid:192 ino:15947 sk:10fb cgroup:unreachable:c4e v6only:1 <->                   
