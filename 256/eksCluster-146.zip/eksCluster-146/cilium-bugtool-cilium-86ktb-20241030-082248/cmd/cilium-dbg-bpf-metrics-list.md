REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36632     2900490     677    bpf_overlay.c
Interface                 INGRESS     645153    132528876   1132   bpf_host.c
Success                   EGRESS      16638     1308456     1694   bpf_host.c
Success                   EGRESS      272870    34004359    1308   bpf_lxc.c
Success                   EGRESS      36965     2923015     53     encap.h
Success                   INGRESS     314967    35619415    86     l3.h
Success                   INGRESS     335612    37255495    235    trace.h
Unsupported L3 protocol   EGRESS      43        3222        1492   bpf_lxc.c
