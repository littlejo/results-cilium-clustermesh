IP ADDRESS         LOCAL ENDPOINT INFO
10.146.0.99:0      (localhost)                                                                                        
10.146.0.115:0     id=1159  sec_id=4818038 flags=0x0000 ifindex=12  mac=6A:97:74:86:50:F1 nodemac=2E:19:FE:23:F4:9A   
10.146.0.40:0      id=1932  sec_id=4839768 flags=0x0000 ifindex=18  mac=EA:25:68:88:5B:57 nodemac=72:69:C2:85:7B:28   
10.146.0.213:0     id=3667  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C8:A1:76:BC:60 nodemac=02:A2:BC:58:13:FB     
172.31.159.14:0    (localhost)                                                                                        
172.31.145.254:0   (localhost)                                                                                        
10.146.0.223:0     id=2394  sec_id=4818038 flags=0x0000 ifindex=14  mac=B2:FD:3B:68:0A:52 nodemac=26:05:59:71:9F:5B   
