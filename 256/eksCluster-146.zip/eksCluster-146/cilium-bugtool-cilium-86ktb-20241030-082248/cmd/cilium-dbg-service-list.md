ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.174.78:443 (active)    
                                          2 => 172.31.233.45:443 (active)    
2    10.100.10.238:443     ClusterIP      1 => 172.31.159.14:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.146.0.115:9153 (active)    
                                          2 => 10.146.0.223:9153 (active)    
4    10.100.0.10:53        ClusterIP      1 => 10.146.0.115:53 (active)      
                                          2 => 10.146.0.223:53 (active)      
5    10.100.218.212:2379   ClusterIP      1 => 10.146.0.40:2379 (active)     
