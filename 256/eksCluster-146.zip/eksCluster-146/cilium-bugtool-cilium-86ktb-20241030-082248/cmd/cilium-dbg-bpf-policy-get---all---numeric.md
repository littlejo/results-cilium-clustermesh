Endpoint ID: 1159
Path: /sys/fs/bpf/tc/globals/cilium_policy_01159

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    129145   1481      0        
Allow    Egress      0          ANY          NONE         disabled    17196    187       0        


Endpoint ID: 1932
Path: /sys/fs/bpf/tc/globals/cilium_policy_01932

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11498195   115016    0        
Allow    Ingress     1          ANY          NONE         disabled    10135582   106699    0        
Allow    Egress      0          ANY          NONE         disabled    13397171   131537    0        


Endpoint ID: 2394
Path: /sys/fs/bpf/tc/globals/cilium_policy_02394

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    130333   1499      0        
Allow    Egress      0          ANY          NONE         disabled    17562    190       0        


Endpoint ID: 3667
Path: /sys/fs/bpf/tc/globals/cilium_policy_03667

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1640555   20702     0        
Allow    Ingress     1          ANY          NONE         disabled    19392     226       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3806
Path: /sys/fs/bpf/tc/globals/cilium_policy_03806

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


