xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 502
ens6(5) clsact/ingress cil_from_netdev-ens6 id 503
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 494
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 488
cilium_host(7) clsact/egress cil_from_host-cilium_host id 482
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 534
lxc356a86d8a389(12) clsact/ingress cil_from_container-lxc356a86d8a389 id 530
lxce1a548d59345(14) clsact/ingress cil_from_container-lxce1a548d59345 id 540
lxc0e929dfa5466(18) clsact/ingress cil_from_container-lxc0e929dfa5466 id 614

flow_dissector:

netfilter:

