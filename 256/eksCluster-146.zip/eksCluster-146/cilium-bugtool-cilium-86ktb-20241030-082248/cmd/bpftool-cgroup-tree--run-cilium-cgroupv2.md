CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddf9f82ef_5083_461e_99ec_f9434bfc48a5.slice/cri-containerd-3ef1a3a34f75d5e2bdb7617e197c9a7f7b65fec3bcb45ea32fd369246d713aed.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddf9f82ef_5083_461e_99ec_f9434bfc48a5.slice/cri-containerd-8b1894ca25c33c11bbf3898d1f7e5d8612b50a723010c136705b86cba563c783.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5a952105_43e1_493e_8ac6_ff718cc218cd.slice/cri-containerd-2086a4b79e05e6bb4e2c16f57a9f2c2054eb036619571ee0aa439e58dc4fc9d0.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5a952105_43e1_493e_8ac6_ff718cc218cd.slice/cri-containerd-a0d88fa06af07e42b3bd7781e326187dca890b9eeeb47aa828928b639cacfdef.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c7b9b5a_1283_4e9a_9a78_6232c6a89b83.slice/cri-containerd-b7aef341379dce8b5a06a988cf84b969b5fe1371e66a792330920e4511b0da08.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c7b9b5a_1283_4e9a_9a78_6232c6a89b83.slice/cri-containerd-ac45b4376f83485c0490769bb0fb7a1192dcf101891359902462171d467915b9.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a117a52_e98e_4a2b_9902_466f4c536c39.slice/cri-containerd-7b0d0acf11589c87c8e68c4f8a5d50716d5ac5cf183131ff1408910dc1f9f2a7.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a117a52_e98e_4a2b_9902_466f4c536c39.slice/cri-containerd-22d2a6146c22b4eb6a6fea85eb25ac206281fa7f56037d55a7895d832d0300a9.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3851460_5095_4064_87f1_29dce0abf8db.slice/cri-containerd-aa29ca4a088a5113d2243f5839e31308dee0ce9effdc979dea6cd751ae235eb8.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3851460_5095_4064_87f1_29dce0abf8db.slice/cri-containerd-7cea83c463034a71ade8ceebbfb3d0d699f8bb895ee2efc74f23b5ab7e82ae2a.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd2429aa_d420_4491_ae8b_e541a552bc7b.slice/cri-containerd-0072100e102b59e7c6829659a60ba832285292fe27452585936418150746e3e1.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd2429aa_d420_4491_ae8b_e541a552bc7b.slice/cri-containerd-bb33f63f471ddbf0930f31a6698243da6074d003d1e7a9d54457415f45a7afbc.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd2429aa_d420_4491_ae8b_e541a552bc7b.slice/cri-containerd-a7943aab3d38dcc5272be05aa7b5e813d699bb98abaf1c3e7d45c00596b93051.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd2429aa_d420_4491_ae8b_e541a552bc7b.slice/cri-containerd-6c72986a60cba761f9398a99c9995424538767b65fad75ca77a11328f2d68398.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb907cdab_1eb2_4207_8dd3_eea64972c22d.slice/cri-containerd-8e191ec6a6a439137eff9bb780fdb1a1668bd62510e92f49ec9094a8c5846f02.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb907cdab_1eb2_4207_8dd3_eea64972c22d.slice/cri-containerd-87056e0ac31b86a86c64fb5f51bb7d8ab227c6bc2e262f86bac481c19a907782.scope
    91       cgroup_device   multi                                          
