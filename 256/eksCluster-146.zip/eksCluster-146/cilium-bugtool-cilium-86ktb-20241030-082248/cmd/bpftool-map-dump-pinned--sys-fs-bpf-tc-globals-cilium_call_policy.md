key: 87 04 00 00  value: 01 02 00 00
key: 8c 07 00 00  value: 64 02 00 00
key: 5a 09 00 00  value: 1f 02 00 00
key: 53 0e 00 00  value: 1e 02 00 00
Found 4 elements
