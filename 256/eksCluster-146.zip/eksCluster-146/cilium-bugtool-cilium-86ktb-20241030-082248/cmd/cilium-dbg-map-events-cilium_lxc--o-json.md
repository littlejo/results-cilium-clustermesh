{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.333Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.145.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.333Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.159.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.333Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:48.765Z",
  "value": "id=1159  sec_id=4818038 flags=0x0000 ifindex=12  mac=6A:97:74:86:50:F1 nodemac=2E:19:FE:23:F4:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:48.765Z",
  "value": "id=3667  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C8:A1:76:BC:60 nodemac=02:A2:BC:58:13:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:48.766Z",
  "value": "id=1159  sec_id=4818038 flags=0x0000 ifindex=12  mac=6A:97:74:86:50:F1 nodemac=2E:19:FE:23:F4:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:48.820Z",
  "value": "id=2394  sec_id=4818038 flags=0x0000 ifindex=14  mac=B2:FD:3B:68:0A:52 nodemac=26:05:59:71:9F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:48.822Z",
  "value": "id=3667  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C8:A1:76:BC:60 nodemac=02:A2:BC:58:13:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:50.272Z",
  "value": "id=2394  sec_id=4818038 flags=0x0000 ifindex=14  mac=B2:FD:3B:68:0A:52 nodemac=26:05:59:71:9F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:50.273Z",
  "value": "id=3667  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C8:A1:76:BC:60 nodemac=02:A2:BC:58:13:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:50.273Z",
  "value": "id=1159  sec_id=4818038 flags=0x0000 ifindex=12  mac=6A:97:74:86:50:F1 nodemac=2E:19:FE:23:F4:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:50.305Z",
  "value": "id=1938  sec_id=4839768 flags=0x0000 ifindex=16  mac=32:65:4A:E0:C7:AB nodemac=D6:32:42:44:4D:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:50.306Z",
  "value": "id=1938  sec_id=4839768 flags=0x0000 ifindex=16  mac=32:65:4A:E0:C7:AB nodemac=D6:32:42:44:4D:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:51.272Z",
  "value": "id=1938  sec_id=4839768 flags=0x0000 ifindex=16  mac=32:65:4A:E0:C7:AB nodemac=D6:32:42:44:4D:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:51.272Z",
  "value": "id=3667  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C8:A1:76:BC:60 nodemac=02:A2:BC:58:13:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:51.272Z",
  "value": "id=1159  sec_id=4818038 flags=0x0000 ifindex=12  mac=6A:97:74:86:50:F1 nodemac=2E:19:FE:23:F4:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:51.273Z",
  "value": "id=2394  sec_id=4818038 flags=0x0000 ifindex=14  mac=B2:FD:3B:68:0A:52 nodemac=26:05:59:71:9F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.410Z",
  "value": "id=1932  sec_id=4839768 flags=0x0000 ifindex=18  mac=EA:25:68:88:5B:57 nodemac=72:69:C2:85:7B:28"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.146.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.662Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:34.227Z",
  "value": "id=2394  sec_id=4818038 flags=0x0000 ifindex=14  mac=B2:FD:3B:68:0A:52 nodemac=26:05:59:71:9F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:34.227Z",
  "value": "id=1932  sec_id=4839768 flags=0x0000 ifindex=18  mac=EA:25:68:88:5B:57 nodemac=72:69:C2:85:7B:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:34.233Z",
  "value": "id=3667  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C8:A1:76:BC:60 nodemac=02:A2:BC:58:13:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:34.233Z",
  "value": "id=1159  sec_id=4818038 flags=0x0000 ifindex=12  mac=6A:97:74:86:50:F1 nodemac=2E:19:FE:23:F4:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:35.247Z",
  "value": "id=3667  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C8:A1:76:BC:60 nodemac=02:A2:BC:58:13:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:35.247Z",
  "value": "id=1159  sec_id=4818038 flags=0x0000 ifindex=12  mac=6A:97:74:86:50:F1 nodemac=2E:19:FE:23:F4:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:35.248Z",
  "value": "id=2394  sec_id=4818038 flags=0x0000 ifindex=14  mac=B2:FD:3B:68:0A:52 nodemac=26:05:59:71:9F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:35.248Z",
  "value": "id=1932  sec_id=4839768 flags=0x0000 ifindex=18  mac=EA:25:68:88:5B:57 nodemac=72:69:C2:85:7B:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:36.227Z",
  "value": "id=3667  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C8:A1:76:BC:60 nodemac=02:A2:BC:58:13:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:36.227Z",
  "value": "id=1932  sec_id=4839768 flags=0x0000 ifindex=18  mac=EA:25:68:88:5B:57 nodemac=72:69:C2:85:7B:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:36.228Z",
  "value": "id=1159  sec_id=4818038 flags=0x0000 ifindex=12  mac=6A:97:74:86:50:F1 nodemac=2E:19:FE:23:F4:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:36.228Z",
  "value": "id=2394  sec_id=4818038 flags=0x0000 ifindex=14  mac=B2:FD:3B:68:0A:52 nodemac=26:05:59:71:9F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:37.228Z",
  "value": "id=3667  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C8:A1:76:BC:60 nodemac=02:A2:BC:58:13:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:37.228Z",
  "value": "id=1932  sec_id=4839768 flags=0x0000 ifindex=18  mac=EA:25:68:88:5B:57 nodemac=72:69:C2:85:7B:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:37.228Z",
  "value": "id=2394  sec_id=4818038 flags=0x0000 ifindex=14  mac=B2:FD:3B:68:0A:52 nodemac=26:05:59:71:9F:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.146.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:37.228Z",
  "value": "id=1159  sec_id=4818038 flags=0x0000 ifindex=12  mac=6A:97:74:86:50:F1 nodemac=2E:19:FE:23:F4:9A"
}

