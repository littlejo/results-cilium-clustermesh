[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c7b9b5a_1283_4e9a_9a78_6232c6a89b83.slice/cri-containerd-b7aef341379dce8b5a06a988cf84b969b5fe1371e66a792330920e4511b0da08.scope"
      }
    ],
    "ips": [
      "10.146.0.115"
    ],
    "name": "coredns-cc6ccd49c-xpqxj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5a952105_43e1_493e_8ac6_ff718cc218cd.slice/cri-containerd-2086a4b79e05e6bb4e2c16f57a9f2c2054eb036619571ee0aa439e58dc4fc9d0.scope"
      }
    ],
    "ips": [
      "10.146.0.223"
    ],
    "name": "coredns-cc6ccd49c-gv5cm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd2429aa_d420_4491_ae8b_e541a552bc7b.slice/cri-containerd-0072100e102b59e7c6829659a60ba832285292fe27452585936418150746e3e1.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd2429aa_d420_4491_ae8b_e541a552bc7b.slice/cri-containerd-bb33f63f471ddbf0930f31a6698243da6074d003d1e7a9d54457415f45a7afbc.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd2429aa_d420_4491_ae8b_e541a552bc7b.slice/cri-containerd-6c72986a60cba761f9398a99c9995424538767b65fad75ca77a11328f2d68398.scope"
      }
    ],
    "ips": [
      "10.146.0.40"
    ],
    "name": "clustermesh-apiserver-6557d66b78-pkt7k",
    "namespace": "kube-system"
  }
]

