KEY             VALUE
AgentLiveness   1988893050313
UTimeOffset     3379442601562500
