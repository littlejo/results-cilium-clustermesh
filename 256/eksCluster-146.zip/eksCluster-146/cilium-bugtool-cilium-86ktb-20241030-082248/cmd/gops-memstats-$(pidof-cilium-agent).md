alloc: 152.08MB (159470424 bytes)
total-alloc: 2.26GB (2426671256 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 63678468
frees: 62007300
heap-alloc: 152.08MB (159470424 bytes)
heap-sys: 247.16MB (259170304 bytes)
heap-idle: 64.34MB (67461120 bytes)
heap-in-use: 182.83MB (191709184 bytes)
heap-released: 1.00MB (1048576 bytes)
heap-objects: 1671168
stack-in-use: 64.81MB (67960832 bytes)
stack-sys: 64.81MB (67960832 bytes)
stack-mspan-inuse: 3.11MB (3258400 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.22MB (1281057 bytes)
gc-sys: 6.00MB (6294992 bytes)
next-gc: when heap-alloc >= 213.42MB (223782312 bytes)
last-gc: 2024-10-30 08:22:54.174021151 +0000 UTC
gc-pause-total: 8.171279ms
gc-pause: 121553
gc-pause-end: 1730276574174021151
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.00047608345318794987
enable-gc: true
debug-gc: false
