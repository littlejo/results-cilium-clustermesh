REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35483     2802927     677    bpf_overlay.c
Interface                 INGRESS     646061    131907269   1132   bpf_host.c
Success                   EGRESS      15345     1203281     1694   bpf_host.c
Success                   EGRESS      282600    35944498    1308   bpf_lxc.c
Success                   EGRESS      35068     2773104     53     encap.h
Success                   INGRESS     323966    36537029    86     l3.h
Success                   INGRESS     344755    38180721    235    trace.h
Unsupported L3 protocol   EGRESS      38        2792        1492   bpf_lxc.c
