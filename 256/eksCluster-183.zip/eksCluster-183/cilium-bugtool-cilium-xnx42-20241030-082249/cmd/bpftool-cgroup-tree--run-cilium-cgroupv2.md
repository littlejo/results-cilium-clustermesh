CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod203caa12_3b52_436e_988f_044948c9f724.slice/cri-containerd-4ceccd7158f84dba080f5d9a68dcc7e19578847e4460817d1c3cfba2e72bf25b.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod203caa12_3b52_436e_988f_044948c9f724.slice/cri-containerd-e79d0027e092dd93fc3df552cc8ef869d57b535f8e3d0ac66edbda09d96417a5.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc86da669_bf36_4ef4_b88b_2e1772f98edc.slice/cri-containerd-50e46d2fcfb88be0784efff6811c2a27615c121f781904d5fdf7e559f32a7f9e.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc86da669_bf36_4ef4_b88b_2e1772f98edc.slice/cri-containerd-e0f255e645b436fbaf46c9a9e0c7ee3adcd8fcebf144d22ed48a29d6a9d2613b.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56ed6374_d300_4f76_a626_fa9cc98ce195.slice/cri-containerd-82da8f93c2a92e2058eb12de5cc11f1af5e42a4eda60136a3b95229beb37b497.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56ed6374_d300_4f76_a626_fa9cc98ce195.slice/cri-containerd-7f1dca458c3bd599727441bcbc553b5108d95e09c1ff9667dabcbef29d4ce923.scope
    531      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6124c29a_a199_4cd6_a873_1115a641bd21.slice/cri-containerd-120290a243bc807804e0904bffecdc94582b634eb1a7229684e45c41be1e6851.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6124c29a_a199_4cd6_a873_1115a641bd21.slice/cri-containerd-32cd915ccdf91be52186e023e2bc62b7bde13e131e7159d524541284e7440eaf.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a3297e6_e6a8_46c0_b904_7bf0dcc81012.slice/cri-containerd-0c9977c7c289bc3018635bc887cf9ecfb172c6adf4936445c7a157c9b14f14d1.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a3297e6_e6a8_46c0_b904_7bf0dcc81012.slice/cri-containerd-a6f17417a004b2a5397ac13e5b00fe97c8e539c28541bbf0ac14ba077e835ac0.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a3297e6_e6a8_46c0_b904_7bf0dcc81012.slice/cri-containerd-eb892ad157412363b7ac68b3b5aea52ad47ac1447efb2bf0f9e71666807e2ef2.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a3297e6_e6a8_46c0_b904_7bf0dcc81012.slice/cri-containerd-9f89e60b7350f6cc49bdeedb2009678f92cdde28f68016c388aec2ef7c8e2f50.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod573d7cf5_5391_4fb0_9b06_167e6d5a3f1d.slice/cri-containerd-be12364f97dc35a47ed8b2738f8a89bb9d3e3cd82de8ebda03e0b243f9d8afa5.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod573d7cf5_5391_4fb0_9b06_167e6d5a3f1d.slice/cri-containerd-cff8a2dfedbf8ea76f6577dfe224d23dee2b8fea16aaba988f1bbf2f633a369c.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a9bf81a_e8bb_4581_ae05_08d17fd4cd7d.slice/cri-containerd-2248e33ff04fd86697c0e1028a38d5fdca5dcf46faf2dee74d80d1705a322ac0.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a9bf81a_e8bb_4581_ae05_08d17fd4cd7d.slice/cri-containerd-f3cfe0cfa9c15939fdb6bd47e804fa55353c9a9b7e21424f121afb906f72c438.scope
    91       cgroup_device   multi                                          
