ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.228.161:443 (active)   
                                         2 => 172.31.152.140:443 (active)   
2    10.100.162.31:443    ClusterIP      1 => 172.31.233.71:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.183.0.181:53 (active)      
                                         2 => 10.183.0.218:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.183.0.181:9153 (active)    
                                         2 => 10.183.0.218:9153 (active)    
5    10.100.31.111:2379   ClusterIP      1 => 10.183.0.148:2379 (active)    
