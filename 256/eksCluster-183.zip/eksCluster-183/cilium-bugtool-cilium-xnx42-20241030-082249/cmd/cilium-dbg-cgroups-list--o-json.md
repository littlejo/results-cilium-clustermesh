[
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a3297e6_e6a8_46c0_b904_7bf0dcc81012.slice/cri-containerd-9f89e60b7350f6cc49bdeedb2009678f92cdde28f68016c388aec2ef7c8e2f50.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a3297e6_e6a8_46c0_b904_7bf0dcc81012.slice/cri-containerd-0c9977c7c289bc3018635bc887cf9ecfb172c6adf4936445c7a157c9b14f14d1.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a3297e6_e6a8_46c0_b904_7bf0dcc81012.slice/cri-containerd-a6f17417a004b2a5397ac13e5b00fe97c8e539c28541bbf0ac14ba077e835ac0.scope"
      }
    ],
    "ips": [
      "10.183.0.148"
    ],
    "name": "clustermesh-apiserver-7ffb7fbdc7-l6fvm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7746,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc86da669_bf36_4ef4_b88b_2e1772f98edc.slice/cri-containerd-e0f255e645b436fbaf46c9a9e0c7ee3adcd8fcebf144d22ed48a29d6a9d2613b.scope"
      }
    ],
    "ips": [
      "10.183.0.181"
    ],
    "name": "coredns-cc6ccd49c-k9kpj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7830,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56ed6374_d300_4f76_a626_fa9cc98ce195.slice/cri-containerd-82da8f93c2a92e2058eb12de5cc11f1af5e42a4eda60136a3b95229beb37b497.scope"
      }
    ],
    "ips": [
      "10.183.0.218"
    ],
    "name": "coredns-cc6ccd49c-b2nzt",
    "namespace": "kube-system"
  }
]

