filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc6ac4f59bae9b direct-action not_in_hw id 526 tag ca3e9901d1a50faf jited 
