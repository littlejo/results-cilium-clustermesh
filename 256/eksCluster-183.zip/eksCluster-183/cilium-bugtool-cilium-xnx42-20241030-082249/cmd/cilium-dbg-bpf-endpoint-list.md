IP ADDRESS         LOCAL ENDPOINT INFO
10.183.0.107:0     (localhost)                                                                                        
10.183.0.218:0     id=1315  sec_id=6030197 flags=0x0000 ifindex=12  mac=7E:0A:88:50:22:8E nodemac=B6:CE:AD:D6:C3:46   
172.31.233.71:0    (localhost)                                                                                        
10.183.0.16:0      id=1915  sec_id=4     flags=0x0000 ifindex=10  mac=CA:E1:AC:70:99:C6 nodemac=B6:B5:76:87:04:AB     
172.31.215.239:0   (localhost)                                                                                        
10.183.0.181:0     id=1914  sec_id=6030197 flags=0x0000 ifindex=14  mac=8A:B4:F4:FB:BD:C6 nodemac=EE:88:EC:20:02:B8   
10.183.0.148:0     id=2345  sec_id=6038243 flags=0x0000 ifindex=18  mac=C6:9A:FA:B6:03:9B nodemac=3E:8D:3A:FB:CA:B0   
