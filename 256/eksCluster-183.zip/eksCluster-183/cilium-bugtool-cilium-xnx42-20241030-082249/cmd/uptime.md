 08:22:51 up 30 min,  0 users,  load average: 0.13, 0.19, 0.17
