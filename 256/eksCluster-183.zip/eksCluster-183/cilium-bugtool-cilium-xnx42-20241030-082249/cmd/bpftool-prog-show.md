29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:52:13+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:52:13+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:52:13+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:52:13+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:52:18+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:52:30+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:02:26+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 124
479: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:02:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
480: sched_cls  name tail_handle_ipv4  tag a6644f65a35cd001  gpl
	loaded_at 2024-10-30T08:02:26+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
481: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:02:26+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
504: sched_cls  name tail_ipv4_ct_ingress  tag 275461184dbb0b68  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 153
505: sched_cls  name tail_handle_ipv4  tag 57789f7843576cc9  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 154
506: sched_cls  name cil_from_container  tag 7a7bc6db31ed6095  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,76
	btf_id 155
507: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 156
508: sched_cls  name tail_ipv4_to_endpoint  tag 1f73ad8e45957ffc  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,107,41,82,83,80,106,39,108,40,37,38
	btf_id 157
509: sched_cls  name tail_ipv4_ct_egress  tag d507ee46cd1365ce  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 158
511: sched_cls  name tail_handle_ipv4_cont  tag cf1319a36d0c7614  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,107,41,106,82,83,39,76,74,77,108,40,37,38,81
	btf_id 160
512: sched_cls  name __send_drop_notify  tag ec0938bc822e347f  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 161
513: sched_cls  name handle_policy  tag 6cbf9ca5e89657ce  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,108,82,83,107,41,80,106,39,84,75,40,37,38
	btf_id 162
514: sched_cls  name tail_handle_arp  tag e4f535dd99f9a116  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 163
515: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 165
516: sched_cls  name tail_handle_arp  tag f4cd53342118476b  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 166
517: sched_cls  name handle_policy  tag 58dc7df583b35764  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,110,82,83,109,41,80,100,39,84,75,40,37,38
	btf_id 167
518: sched_cls  name tail_handle_ipv4_cont  tag d82972649895dd4f  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,109,41,100,82,83,39,76,74,77,110,40,37,38,81
	btf_id 168
519: sched_cls  name tail_handle_ipv4  tag 921475691372fd78  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 169
520: sched_cls  name cil_from_container  tag 883e65fbce65c277  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 110,76
	btf_id 170
521: sched_cls  name tail_ipv4_to_endpoint  tag 8d7827ba526f2616  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,109,41,82,83,80,100,39,110,40,37,38
	btf_id 171
522: sched_cls  name tail_ipv4_ct_ingress  tag ef3728e7b3eb3afc  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 172
523: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 173
525: sched_cls  name __send_drop_notify  tag d667c95ff6903181  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 175
526: sched_cls  name cil_from_container  tag ca3e9901d1a50faf  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 177
527: sched_cls  name tail_handle_ipv4_cont  tag 114b70c3d63416de  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,112,41,101,82,83,39,76,74,77,111,40,37,38,81
	btf_id 178
528: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
531: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
532: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
535: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
536: sched_cls  name handle_policy  tag 9315b933ddba8eac  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,112,41,80,101,39,84,75,40,37,38
	btf_id 179
537: sched_cls  name tail_ipv4_ct_ingress  tag df1969875d378b3c  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 180
538: sched_cls  name __send_drop_notify  tag af85e08413fa2dd9  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 181
539: sched_cls  name tail_handle_ipv4  tag 7defea58a188a517  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 182
540: sched_cls  name tail_handle_arp  tag ffde1e95f303e6af  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 183
541: sched_cls  name tail_ipv4_ct_egress  tag d507ee46cd1365ce  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 184
543: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 186
544: sched_cls  name tail_ipv4_to_endpoint  tag 855131789f215fc1  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,101,39,111,40,37,38
	btf_id 187
545: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
548: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
549: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
552: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
553: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 189
554: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,117
	btf_id 190
557: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 193
558: sched_cls  name __send_drop_notify  tag 48bd7429d39e3a6b  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 194
559: sched_cls  name tail_handle_ipv4_from_host  tag f56fe8b820e7c427  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 195
560: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 197
564: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 201
565: sched_cls  name __send_drop_notify  tag 48bd7429d39e3a6b  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 202
566: sched_cls  name tail_handle_ipv4_from_host  tag f56fe8b820e7c427  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 203
567: sched_cls  name tail_handle_ipv4_from_host  tag f56fe8b820e7c427  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 205
568: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 206
570: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 208
573: sched_cls  name __send_drop_notify  tag 48bd7429d39e3a6b  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 211
574: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 213
577: sched_cls  name __send_drop_notify  tag 48bd7429d39e3a6b  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 216
578: sched_cls  name tail_handle_ipv4_from_host  tag f56fe8b820e7c427  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 217
579: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 218
620: sched_cls  name tail_ipv4_to_endpoint  tag 72c4b8e7ec2f5b62  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,136,41,82,83,80,135,39,137,40,37,38
	btf_id 233
621: sched_cls  name tail_handle_ipv4_cont  tag f54d55ab2bcfc41c  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,136,41,135,82,83,39,76,74,77,137,40,37,38,81
	btf_id 234
623: sched_cls  name cil_from_container  tag 64572ee688b29f56  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 137,76
	btf_id 236
624: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,137
	btf_id 237
625: sched_cls  name tail_handle_arp  tag 7d1768d13a083cec  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,137
	btf_id 238
626: sched_cls  name handle_policy  tag 5c531f8811d3eb0a  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,137,82,83,136,41,80,135,39,84,75,40,37,38
	btf_id 239
627: sched_cls  name tail_ipv4_ct_egress  tag 639a33aa6be1b95d  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 240
628: sched_cls  name tail_ipv4_ct_ingress  tag 62ea53e31d0c3718  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 241
629: sched_cls  name __send_drop_notify  tag 6eaaaec55a015b6c  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 242
630: sched_cls  name tail_handle_ipv4  tag 6a4a2c37537e8814  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,137
	btf_id 243
631: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
634: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
647: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
650: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
655: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
658: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
