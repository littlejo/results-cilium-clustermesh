alloc: 105.74MB (110877096 bytes)
total-alloc: 2.34GB (2513371376 bytes)
sys: 337.09MB (353459572 bytes)
lookups: 0
mallocs: 64367215
frees: 63540284
heap-alloc: 105.74MB (110877096 bytes)
heap-sys: 255.91MB (268345344 bytes)
heap-idle: 86.32MB (90513408 bytes)
heap-in-use: 169.59MB (177831936 bytes)
heap-released: 2.37MB (2482176 bytes)
heap-objects: 826931
stack-in-use: 68.06MB (71368704 bytes)
stack-sys: 68.06MB (71368704 bytes)
stack-mspan-inuse: 2.96MB (3105280 bytes)
stack-mspan-sys: 4.00MB (4194240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.02MB (1066441 bytes)
gc-sys: 6.09MB (6386360 bytes)
next-gc: when heap-alloc >= 215.13MB (225578248 bytes)
last-gc: 2024-10-30 08:23:15.360560238 +0000 UTC
gc-pause-total: 16.795031ms
gc-pause: 257695
gc-pause-end: 1730276595360560238
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0005870609988188629
enable-gc: true
debug-gc: false
