1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:61:39:23:80:71 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.233.71/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3569sec preferred_lft 3569sec
    inet6 fe80::861:39ff:fe23:8071/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:e4:3e:2e:15:4b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.215.239/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8e4:3eff:fe2e:154b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:1d:fa:61:24:de brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2c1d:faff:fe61:24de/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:2d:09:8a:94:4c brd ff:ff:ff:ff:ff:ff
    inet 10.183.0.107/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::542d:9ff:fe8a:944c/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 8e:25:8a:cd:91:9a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8c25:8aff:fecd:919a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:b5:76:87:04:ab brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b4b5:76ff:fe87:4ab/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc6ac4f59bae9b@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:ce:ad:d6:c3:46 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b4ce:adff:fed6:c346/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcf79b7c3d59ff@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:88:ec:20:02:b8 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ec88:ecff:fe20:2b8/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc8eff76865965@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:8d:3a:fb:ca:b0 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::3c8d:3aff:fefb:cab0/64 scope link 
       valid_lft forever preferred_lft forever
