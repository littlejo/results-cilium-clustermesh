{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:23.924Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.215.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:23.924Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.233.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:23.924Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:28.427Z",
  "value": "id=1915  sec_id=4     flags=0x0000 ifindex=10  mac=CA:E1:AC:70:99:C6 nodemac=B6:B5:76:87:04:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:28.431Z",
  "value": "id=1315  sec_id=6030197 flags=0x0000 ifindex=12  mac=7E:0A:88:50:22:8E nodemac=B6:CE:AD:D6:C3:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:28.493Z",
  "value": "id=1914  sec_id=6030197 flags=0x0000 ifindex=14  mac=8A:B4:F4:FB:BD:C6 nodemac=EE:88:EC:20:02:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:28.533Z",
  "value": "id=1915  sec_id=4     flags=0x0000 ifindex=10  mac=CA:E1:AC:70:99:C6 nodemac=B6:B5:76:87:04:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:28.644Z",
  "value": "id=1315  sec_id=6030197 flags=0x0000 ifindex=12  mac=7E:0A:88:50:22:8E nodemac=B6:CE:AD:D6:C3:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:15.026Z",
  "value": "id=1915  sec_id=4     flags=0x0000 ifindex=10  mac=CA:E1:AC:70:99:C6 nodemac=B6:B5:76:87:04:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:15.026Z",
  "value": "id=1315  sec_id=6030197 flags=0x0000 ifindex=12  mac=7E:0A:88:50:22:8E nodemac=B6:CE:AD:D6:C3:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:15.027Z",
  "value": "id=1914  sec_id=6030197 flags=0x0000 ifindex=14  mac=8A:B4:F4:FB:BD:C6 nodemac=EE:88:EC:20:02:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:15.057Z",
  "value": "id=885   sec_id=6038243 flags=0x0000 ifindex=16  mac=D2:7F:4A:40:23:5C nodemac=92:4F:75:D5:6C:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:16.026Z",
  "value": "id=1914  sec_id=6030197 flags=0x0000 ifindex=14  mac=8A:B4:F4:FB:BD:C6 nodemac=EE:88:EC:20:02:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:16.027Z",
  "value": "id=1315  sec_id=6030197 flags=0x0000 ifindex=12  mac=7E:0A:88:50:22:8E nodemac=B6:CE:AD:D6:C3:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:16.027Z",
  "value": "id=1915  sec_id=4     flags=0x0000 ifindex=10  mac=CA:E1:AC:70:99:C6 nodemac=B6:B5:76:87:04:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:16.027Z",
  "value": "id=885   sec_id=6038243 flags=0x0000 ifindex=16  mac=D2:7F:4A:40:23:5C nodemac=92:4F:75:D5:6C:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.696Z",
  "value": "id=2345  sec_id=6038243 flags=0x0000 ifindex=18  mac=C6:9A:FA:B6:03:9B nodemac=3E:8D:3A:FB:CA:B0"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.183.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.933Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.407Z",
  "value": "id=1915  sec_id=4     flags=0x0000 ifindex=10  mac=CA:E1:AC:70:99:C6 nodemac=B6:B5:76:87:04:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.407Z",
  "value": "id=1315  sec_id=6030197 flags=0x0000 ifindex=12  mac=7E:0A:88:50:22:8E nodemac=B6:CE:AD:D6:C3:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.407Z",
  "value": "id=1914  sec_id=6030197 flags=0x0000 ifindex=14  mac=8A:B4:F4:FB:BD:C6 nodemac=EE:88:EC:20:02:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.408Z",
  "value": "id=2345  sec_id=6038243 flags=0x0000 ifindex=18  mac=C6:9A:FA:B6:03:9B nodemac=3E:8D:3A:FB:CA:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.406Z",
  "value": "id=1914  sec_id=6030197 flags=0x0000 ifindex=14  mac=8A:B4:F4:FB:BD:C6 nodemac=EE:88:EC:20:02:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.407Z",
  "value": "id=2345  sec_id=6038243 flags=0x0000 ifindex=18  mac=C6:9A:FA:B6:03:9B nodemac=3E:8D:3A:FB:CA:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.408Z",
  "value": "id=1915  sec_id=4     flags=0x0000 ifindex=10  mac=CA:E1:AC:70:99:C6 nodemac=B6:B5:76:87:04:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.409Z",
  "value": "id=1315  sec_id=6030197 flags=0x0000 ifindex=12  mac=7E:0A:88:50:22:8E nodemac=B6:CE:AD:D6:C3:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:21.407Z",
  "value": "id=1914  sec_id=6030197 flags=0x0000 ifindex=14  mac=8A:B4:F4:FB:BD:C6 nodemac=EE:88:EC:20:02:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:21.407Z",
  "value": "id=2345  sec_id=6038243 flags=0x0000 ifindex=18  mac=C6:9A:FA:B6:03:9B nodemac=3E:8D:3A:FB:CA:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:21.411Z",
  "value": "id=1915  sec_id=4     flags=0x0000 ifindex=10  mac=CA:E1:AC:70:99:C6 nodemac=B6:B5:76:87:04:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:21.411Z",
  "value": "id=1315  sec_id=6030197 flags=0x0000 ifindex=12  mac=7E:0A:88:50:22:8E nodemac=B6:CE:AD:D6:C3:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:22.407Z",
  "value": "id=1315  sec_id=6030197 flags=0x0000 ifindex=12  mac=7E:0A:88:50:22:8E nodemac=B6:CE:AD:D6:C3:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:22.407Z",
  "value": "id=1914  sec_id=6030197 flags=0x0000 ifindex=14  mac=8A:B4:F4:FB:BD:C6 nodemac=EE:88:EC:20:02:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:22.407Z",
  "value": "id=2345  sec_id=6038243 flags=0x0000 ifindex=18  mac=C6:9A:FA:B6:03:9B nodemac=3E:8D:3A:FB:CA:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:22.408Z",
  "value": "id=1915  sec_id=4     flags=0x0000 ifindex=10  mac=CA:E1:AC:70:99:C6 nodemac=B6:B5:76:87:04:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:23.407Z",
  "value": "id=2345  sec_id=6038243 flags=0x0000 ifindex=18  mac=C6:9A:FA:B6:03:9B nodemac=3E:8D:3A:FB:CA:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:23.407Z",
  "value": "id=1915  sec_id=4     flags=0x0000 ifindex=10  mac=CA:E1:AC:70:99:C6 nodemac=B6:B5:76:87:04:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:23.407Z",
  "value": "id=1315  sec_id=6030197 flags=0x0000 ifindex=12  mac=7E:0A:88:50:22:8E nodemac=B6:CE:AD:D6:C3:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.183.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:23.408Z",
  "value": "id=1914  sec_id=6030197 flags=0x0000 ifindex=14  mac=8A:B4:F4:FB:BD:C6 nodemac=EE:88:EC:20:02:B8"
}

