Endpoint ID: 343
Path: /sys/fs/bpf/tc/globals/cilium_policy_00343

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1315
Path: /sys/fs/bpf/tc/globals/cilium_policy_01315

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    118657   1358      0        
Allow    Egress      0          ANY          NONE         disabled    16145    175       0        


Endpoint ID: 1914
Path: /sys/fs/bpf/tc/globals/cilium_policy_01914

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    118789   1360      0        
Allow    Egress      0          ANY          NONE         disabled    16239    174       0        


Endpoint ID: 1915
Path: /sys/fs/bpf/tc/globals/cilium_policy_01915

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1648072   20843     0        
Allow    Ingress     1          ANY          NONE         disabled    17686     207       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2345
Path: /sys/fs/bpf/tc/globals/cilium_policy_02345

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11541563   113610    0        
Allow    Ingress     1          ANY          NONE         disabled    10436568   106198    0        
Allow    Egress      0          ANY          NONE         disabled    11197255   111170    0        


