xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 570
ens6(5) clsact/ingress cil_from_netdev-ens6 id 574
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 564
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 557
cilium_host(7) clsact/egress cil_from_host-cilium_host id 554
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 478
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 520
lxc6ac4f59bae9b(12) clsact/ingress cil_from_container-lxc6ac4f59bae9b id 526
lxcf79b7c3d59ff(14) clsact/ingress cil_from_container-lxcf79b7c3d59ff id 506
lxc8eff76865965(18) clsact/ingress cil_from_container-lxc8eff76865965 id 623

flow_dissector:

netfilter:

