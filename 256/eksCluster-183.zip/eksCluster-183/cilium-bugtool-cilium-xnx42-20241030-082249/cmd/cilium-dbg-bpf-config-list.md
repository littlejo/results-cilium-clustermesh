KEY             VALUE
AgentLiveness   1873488655659
UTimeOffset     3379442830078125
