key: 23 05 00 00  value: 18 02 00 00
key: 7a 07 00 00  value: 01 02 00 00
key: 7b 07 00 00  value: 05 02 00 00
key: 29 09 00 00  value: 72 02 00 00
Found 4 elements
