 08:22:57 up 38 min,  0 users,  load average: 0.25, 0.27, 0.20
