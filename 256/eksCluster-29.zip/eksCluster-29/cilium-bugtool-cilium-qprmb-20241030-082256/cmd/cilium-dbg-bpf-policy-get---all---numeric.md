Endpoint ID: 346
Path: /sys/fs/bpf/tc/globals/cilium_policy_00346

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1658772   20958     0        
Allow    Ingress     1          ANY          NONE         disabled    26614     309       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 918
Path: /sys/fs/bpf/tc/globals/cilium_policy_00918

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1109
Path: /sys/fs/bpf/tc/globals/cilium_policy_01109

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11601219   115661    0        
Allow    Ingress     1          ANY          NONE         disabled    9851603    103512    0        
Allow    Egress      0          ANY          NONE         disabled    12763435   125803    0        


Endpoint ID: 1168
Path: /sys/fs/bpf/tc/globals/cilium_policy_01168

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    178844   2060      0        
Allow    Egress      0          ANY          NONE         disabled    19569    220       0        


Endpoint ID: 1221
Path: /sys/fs/bpf/tc/globals/cilium_policy_01221

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    177260   2038      0        
Allow    Egress      0          ANY          NONE         disabled    21936    246       0        


