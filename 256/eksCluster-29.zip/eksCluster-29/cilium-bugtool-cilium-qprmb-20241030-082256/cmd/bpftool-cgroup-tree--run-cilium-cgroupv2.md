CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podece740fc_5bd2_4941_843e_9b5386f736b6.slice/cri-containerd-9b47d566d5c2cd08d2b525e30759f0177937fdf2a8c171245cdaafb35f66f34d.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podece740fc_5bd2_4941_843e_9b5386f736b6.slice/cri-containerd-3a4b52bad9f77502f17de0defbec8587c6c133f613cf34d3075187ab04f15df4.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5e978d06_a89e_44cb_b97d_47bfaafc8998.slice/cri-containerd-0e540ced328a591af7db34e90431bc1e4f7784e2552d2ec0dbd6dd64b72423d8.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5e978d06_a89e_44cb_b97d_47bfaafc8998.slice/cri-containerd-e4bd1a5437de4676af169711cca634c27c7215938106dc4a2d5e141b43a5bb2d.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1b8722c2_2984_4d09_b0fb_082cd58d81e6.slice/cri-containerd-67ad19f89764921aa64ff813d39b6e2a652a43def632cdaaebfa71ec53482a0c.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1b8722c2_2984_4d09_b0fb_082cd58d81e6.slice/cri-containerd-6be705421746f40470cd12946f22c7e62f67e43ce5d95c4f86908a564cd9d3f8.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod74fda470_4d80_4464_81d1_3f885f8a3264.slice/cri-containerd-2fbb2c060c91266692919ca5cb13904cdda73340b9a1e5479628f2b5bb158f7b.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod74fda470_4d80_4464_81d1_3f885f8a3264.slice/cri-containerd-3a5afcdabbfd579fd4a72d8210724fd606038a877c60fc6a0a28af46d29ff677.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod415e1cc7_264e_4086_92f5_28f5b79fdc11.slice/cri-containerd-ebe37c608682f88dfcd3be4e843736b28de57750a8390d120419c8b292e32ea0.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod415e1cc7_264e_4086_92f5_28f5b79fdc11.slice/cri-containerd-3892c89ee8741797e69b2ff9ef2cffbb31bd65e921e1a46acbf653dffd3626f5.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod22625d24_c16e_4c5b_be9c_4affe9a483a3.slice/cri-containerd-f25390de625b954666bf4175e04720233005aa659138837535af0d4bf8fd52f5.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod22625d24_c16e_4c5b_be9c_4affe9a483a3.slice/cri-containerd-62af3dda0aa748ea3ff3fa9abcc600b2d6883ace4442485a48735bb5c7d12fb4.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ffd5d5b_1fb7_4bdc_baa0_82747df83572.slice/cri-containerd-6b5d3acbaf952e9b37e47a90304c01c8adfa616a8d755e8fe9c6e9af1c41c2fb.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ffd5d5b_1fb7_4bdc_baa0_82747df83572.slice/cri-containerd-3bcc5a73b6b438329cd85b873b749c325e74f7f1e6c379830d412e1d1a6262bd.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ffd5d5b_1fb7_4bdc_baa0_82747df83572.slice/cri-containerd-499c2e3976e8ec3a6fa1a2a87d596a196b14a5c483e1d7e1b2d8ab828f9a1102.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ffd5d5b_1fb7_4bdc_baa0_82747df83572.slice/cri-containerd-9af77955baebfb8a3f61272b68dac0b1fb9c438c3ecfe86a4b7e04826bd8d40f.scope
    623      cgroup_device   multi                                          
