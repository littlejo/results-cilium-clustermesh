1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:30:da:4f:13:6f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.231.174/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3130sec preferred_lft 3130sec
    inet6 fe80::830:daff:fe4f:136f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:b3:eb:15:9e:d7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.230.95/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8b3:ebff:fe15:9ed7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:dd:ea:dc:11:9f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::38dd:eaff:fedc:119f/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:92:29:42:99:59 brd ff:ff:ff:ff:ff:ff
    inet 10.29.0.229/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::8492:29ff:fe42:9959/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 42:b6:ae:b6:33:34 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::40b6:aeff:feb6:3334/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:c5:1a:3b:bb:02 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d8c5:1aff:fe3b:bb02/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcd44ff3a4bbad@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:d8:45:03:fa:a7 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::24d8:45ff:fe03:faa7/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc5021ed9c3d72@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:a6:b7:1a:56:ea brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ca6:b7ff:fe1a:56ea/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc33098500f206@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:cb:92:de:7b:da brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::64cb:92ff:fede:7bda/64 scope link 
       valid_lft forever preferred_lft forever
