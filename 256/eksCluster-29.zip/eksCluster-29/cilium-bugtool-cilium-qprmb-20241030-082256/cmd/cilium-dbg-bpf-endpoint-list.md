IP ADDRESS         LOCAL ENDPOINT INFO
10.29.0.37:0       id=1109  sec_id=1008833 flags=0x0000 ifindex=18  mac=72:6A:4D:D1:96:DB nodemac=66:CB:92:DE:7B:DA   
172.31.231.174:0   (localhost)                                                                                        
172.31.230.95:0    (localhost)                                                                                        
10.29.0.229:0      (localhost)                                                                                        
10.29.0.183:0      id=346   sec_id=4     flags=0x0000 ifindex=10  mac=D2:67:7A:F5:3A:6D nodemac=DA:C5:1A:3B:BB:02     
10.29.0.228:0      id=1168  sec_id=983237 flags=0x0000 ifindex=12  mac=F6:8F:B5:04:82:4D nodemac=26:D8:45:03:FA:A7    
10.29.0.70:0       id=1221  sec_id=983237 flags=0x0000 ifindex=14  mac=3E:D8:CD:CF:88:A2 nodemac=0E:A6:B7:1A:56:EA    
