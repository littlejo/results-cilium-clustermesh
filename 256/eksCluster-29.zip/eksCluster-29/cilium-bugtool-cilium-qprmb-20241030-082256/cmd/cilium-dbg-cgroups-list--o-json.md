[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podece740fc_5bd2_4941_843e_9b5386f736b6.slice/cri-containerd-9b47d566d5c2cd08d2b525e30759f0177937fdf2a8c171245cdaafb35f66f34d.scope"
      }
    ],
    "ips": [
      "10.29.0.70"
    ],
    "name": "coredns-cc6ccd49c-qhv68",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ffd5d5b_1fb7_4bdc_baa0_82747df83572.slice/cri-containerd-6b5d3acbaf952e9b37e47a90304c01c8adfa616a8d755e8fe9c6e9af1c41c2fb.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ffd5d5b_1fb7_4bdc_baa0_82747df83572.slice/cri-containerd-499c2e3976e8ec3a6fa1a2a87d596a196b14a5c483e1d7e1b2d8ab828f9a1102.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ffd5d5b_1fb7_4bdc_baa0_82747df83572.slice/cri-containerd-3bcc5a73b6b438329cd85b873b749c325e74f7f1e6c379830d412e1d1a6262bd.scope"
      }
    ],
    "ips": [
      "10.29.0.37"
    ],
    "name": "clustermesh-apiserver-68695cfc57-6482h",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7614,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5e978d06_a89e_44cb_b97d_47bfaafc8998.slice/cri-containerd-e4bd1a5437de4676af169711cca634c27c7215938106dc4a2d5e141b43a5bb2d.scope"
      }
    ],
    "ips": [
      "10.29.0.228"
    ],
    "name": "coredns-cc6ccd49c-t4hs9",
    "namespace": "kube-system"
  }
]

