# Cilium debug information

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 39890698                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 39890698                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 39890698                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-4013800000 rw-p 00000000 00:00 0 
4013800000-4014000000 ---p 00000000 00:00 0 
ffff49911000-ffff49c59000 rw-p 00000000 00:00 0 
ffff49c5d000-ffff49d8e000 rw-p 00000000 00:00 0 
ffff49d96000-ffff49ec7000 rw-p 00000000 00:00 0 
ffff49ec7000-ffff49f08000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff49f08000-ffff49f49000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff49f49000-ffff49f4b000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff49f4b000-ffff49f4d000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff49f4d000-ffff4a4f4000 rw-p 00000000 00:00 0 
ffff4a4f4000-ffff4a5f4000 rw-p 00000000 00:00 0 
ffff4a5f4000-ffff4a605000 rw-p 00000000 00:00 0 
ffff4a605000-ffff4c605000 rw-p 00000000 00:00 0 
ffff4c605000-ffff4c685000 ---p 00000000 00:00 0 
ffff4c685000-ffff4c686000 rw-p 00000000 00:00 0 
ffff4c686000-ffff6c685000 ---p 00000000 00:00 0 
ffff6c685000-ffff6c686000 rw-p 00000000 00:00 0 
ffff6c686000-ffff8c615000 ---p 00000000 00:00 0 
ffff8c615000-ffff8c616000 rw-p 00000000 00:00 0 
ffff8c616000-ffff90607000 ---p 00000000 00:00 0 
ffff90607000-ffff90608000 rw-p 00000000 00:00 0 
ffff90608000-ffff90e05000 ---p 00000000 00:00 0 
ffff90e05000-ffff90e06000 rw-p 00000000 00:00 0 
ffff90e06000-ffff90f05000 ---p 00000000 00:00 0 
ffff90f05000-ffff90f65000 rw-p 00000000 00:00 0 
ffff90f65000-ffff90f67000 r--p 00000000 00:00 0                          [vvar]
ffff90f67000-ffff90f68000 r-xp 00000000 00:00 0                          [vdso]
ffffe582c000-ffffe584d000 rw-p 00000000 00:00 0                          [stack]

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.29.0.183": (string) (len=6) "health",
  (string) (len=11) "10.29.0.228": (string) (len=35) "kube-system/coredns-cc6ccd49c-t4hs9",
  (string) (len=10) "10.29.0.70": (string) (len=35) "kube-system/coredns-cc6ccd49c-qhv68",
  (string) (len=10) "10.29.0.37": (string) (len=50) "kube-system/clustermesh-apiserver-68695cfc57-6482h",
  (string) (len=11) "10.29.0.229": (string) (len=6) "router"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.231.174": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40013f13f0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001bf3ce0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001bf3ce0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40025c1c30)(frontends:[]/ports=[etcd-metrics apiserv-metrics kvmesh-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40025c1d90)(frontends:[10.100.252.125]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4000c4b8c0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4000c4b970)(frontends:[10.100.88.194]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4000c4ba20)(frontends:[10.100.0.10]/ports=[dns-tcp metrics dns]/selector=map[k8s-app:kube-dns])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40004f3440)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002affc70)(172.31.159.121:443/TCP,172.31.210.169:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40004f3448)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-gsc4n": (*k8s.Endpoints)(0x4003077380)(172.31.231.174:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40004f3450)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-8g42h": (*k8s.Endpoints)(0x4002afe750)(10.29.0.228:53/TCP[eu-west-3b],10.29.0.228:53/UDP[eu-west-3b],10.29.0.228:9153/TCP[eu-west-3b],10.29.0.70:53/TCP[eu-west-3b],10.29.0.70:53/UDP[eu-west-3b],10.29.0.70:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4000ab2020)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-txgdv": (*k8s.Endpoints)(0x40033189c0)(10.29.0.37:2379/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001836690)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4000447310)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400f2d7e18
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001ad32c0,
  gcExited: (chan struct {}) 0x4001ad3320,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001b38380)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000b2f888)({
      MetricVec: (*prometheus.MetricVec)(0x4001b63c50)({
       metricMap: (*prometheus.metricMap)(0x4001b63c80)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017a5560)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001b38400)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000b2f890)({
      MetricVec: (*prometheus.MetricVec)(0x4001b63ce0)({
       metricMap: (*prometheus.metricMap)(0x4001b63d10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017a55c0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001b38480)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000b2f898)({
      MetricVec: (*prometheus.MetricVec)(0x4001b63d70)({
       metricMap: (*prometheus.metricMap)(0x4001b63da0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017a5620)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001b38500)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000b2f8a0)({
      MetricVec: (*prometheus.MetricVec)(0x4001b63e00)({
       metricMap: (*prometheus.metricMap)(0x4001b63e30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017a5680)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001b38580)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000b2f8a8)({
      MetricVec: (*prometheus.MetricVec)(0x4001b63e90)({
       metricMap: (*prometheus.metricMap)(0x4001b63ec0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017a56e0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001b38600)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000b2f8b0)({
      MetricVec: (*prometheus.MetricVec)(0x4001b63f20)({
       metricMap: (*prometheus.metricMap)(0x4001b63f50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017a5740)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001b38680)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000b2f8b8)({
      MetricVec: (*prometheus.MetricVec)(0x4001bb8030)({
       metricMap: (*prometheus.metricMap)(0x4001bb8060)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017a57a0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001b38700)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000b2f8c0)({
      MetricVec: (*prometheus.MetricVec)(0x4001bb80c0)({
       metricMap: (*prometheus.metricMap)(0x4001bb80f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017a5800)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001b38780)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000b2f8c8)({
      MetricVec: (*prometheus.MetricVec)(0x4001bb8150)({
       metricMap: (*prometheus.metricMap)(0x4001bb8180)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017a5860)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001836690)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001837810)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001d06750)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 279ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### Cilium environment keys

```
set-cilium-node-taints:true
node-port-bind-protection:true
bpf-policy-map-max:16384
procfs:/host/proc
mesh-auth-mutual-listener-port:0
max-connected-clusters:511
tofqdns-proxy-port:0
ipv4-range:auto
http-max-grpc-timeout:0
proxy-connect-timeout:2
cluster-name:cmesh30
hubble-export-file-max-backups:5
debug:false
identity-gc-interval:15m0s
hubble-drop-events-interval:2m0s
mesh-auth-enabled:true
crd-wait-timeout:5m0s
dnsproxy-concurrency-limit:0
enable-policy:default
ipv6-range:auto
ipv6-service-range:auto
tunnel-protocol:vxlan
http-retry-count:3
hubble-export-allowlist:
bpf-fragments-map-max:8192
set-cilium-is-up-condition:true
enable-l7-proxy:true
enable-auto-protect-node-port-range:true
enable-stale-cilium-endpoint-cleanup:true
hubble-export-file-max-size-mb:10
enable-node-port:false
cgroup-root:/run/cilium/cgroupv2
route-metric:0
bpf-ct-timeout-regular-tcp-syn:1m0s
enable-ipv4-masquerade:true
enable-tcx:true
enable-vtep:false
synchronize-k8s-nodes:true
install-no-conntrack-iptables-rules:false
hubble-event-queue-size:0
tunnel-port:0
l2-announcements-retry-period:2s
enable-ipv4:true
envoy-config-timeout:2m0s
fqdn-regex-compile-lru-size:1024
force-device-detection:false
tofqdns-pre-cache:
enable-xt-socket-fallback:true
bpf-lb-dsr-dispatch:opt
envoy-keep-cap-netbindservice:false
enable-node-selector-labels:false
cluster-health-port:4240
cluster-id:30
local-router-ipv4:
restore:true
ipv6-cluster-alloc-cidr:f00d::/64
l2-announcements-lease-duration:15s
enable-host-legacy-routing:false
cni-chaining-mode:none
k8s-namespace:kube-system
keep-config:false
enable-host-firewall:false
envoy-base-id:0
bpf-ct-timeout-regular-any:1m0s
remove-cilium-node-taints:true
proxy-gid:1337
config-dir:/tmp/cilium/config-map
max-controller-interval:0
cflags:
envoy-secrets-namespace:
enable-health-checking:true
hubble-metrics:
hubble-export-fieldmask:
operator-prometheus-serve-addr::9963
kube-proxy-replacement:false
config:
ipsec-key-file:
enable-runtime-device-detection:true
bpf-map-event-buffers:
enable-sctp:false
nat-map-stats-interval:30s
mesh-auth-spire-admin-socket:
bpf-ct-timeout-regular-tcp:2h13m20s
enable-xdp-prefilter:false
hubble-export-file-path:
cluster-pool-ipv4-cidr:10.29.0.0/16
enable-bgp-control-plane:false
disable-iptables-feeder-rules:
cni-log-file:/var/run/cilium/cilium-cni.log
vlan-bpf-bypass:
ipsec-key-rotation-duration:5m0s
enable-route-mtu-for-cni-chaining:false
vtep-mac:
k8s-service-proxy-name:
bpf-root:/sys/fs/bpf
enable-ipv4-egress-gateway:false
bpf-policy-map-full-reconciliation-interval:15m0s
ipv6-mcast-device:
enable-mke:false
enable-hubble:true
kvstore:
bpf-lb-service-map-max:0
kvstore-opt:
proxy-prometheus-port:0
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-k8s-api-discovery:false
join-cluster:false
bpf-lb-map-max:65536
clustermesh-enable-mcs-api:false
enable-bpf-masquerade:false
enable-ip-masq-agent:false
ip-masq-agent-config-path:/etc/config/ip-masq-agent
datapath-mode:veth
enable-health-check-nodeport:true
dnsproxy-lock-count:131
hubble-redact-enabled:false
enable-ipv6:false
log-opt:
enable-wireguard:false
proxy-portrange-min:10000
bpf-lb-external-clusterip:false
prometheus-serve-addr:
monitor-aggregation-interval:5s
lib-dir:/var/lib/cilium
dnsproxy-insecure-skip-transparent-mode-check:false
mesh-auth-gc-interval:5m0s
vtep-mask:
log-system-load:false
static-cnp-path:
dnsproxy-lock-timeout:500ms
hubble-export-denylist:
bpf-lb-algorithm:random
dns-policy-unload-on-shutdown:false
agent-health-port:9879
agent-labels:
clustermesh-enable-endpoint-sync:false
disable-external-ip-mitigation:false
enable-endpoint-health-checking:true
bpf-lb-rss-ipv4-src-cidr:
annotate-k8s-node:false
hubble-metrics-server:
hubble-disable-tls:false
cmdref:
mesh-auth-queue-size:1024
identity-allocation-mode:crd
hubble-drop-events-reasons:auth_required,policy_denied
bgp-announce-lb-ip:false
kvstore-connectivity-timeout:2m0s
hubble-recorder-storage-path:/var/run/cilium/pcaps
gops-port:9890
enable-l2-neigh-discovery:true
bpf-events-policy-verdict-enabled:true
cni-chaining-target:
version:false
enable-k8s-networkpolicy:true
bpf-sock-rev-map-max:262144
ipv6-node:auto
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-external-ips:false
multicast-enabled:false
k8s-require-ipv6-pod-cidr:false
hubble-recorder-sink-queue-size:1024
kvstore-lease-ttl:15m0s
label-prefix-file:
enable-gateway-api:false
ipam-multi-pool-pre-allocation:
trace-sock:true
iptables-lock-timeout:5s
tofqdns-dns-reject-response-code:refused
bpf-ct-timeout-service-any:1m0s
socket-path:/var/run/cilium/cilium.sock
enable-well-known-identities:false
bpf-lb-sock-hostns-only:false
tofqdns-endpoint-max-ip-per-hostname:50
clustermesh-ip-identities-sync-timeout:1m0s
bpf-map-dynamic-size-ratio:0.0025
enable-masquerade-to-route-source:false
enable-ipv4-fragment-tracking:true
proxy-xff-num-trusted-hops-ingress:0
k8s-kubeconfig-path:
enable-ipv4-big-tcp:false
max-internal-timer-delay:0s
bpf-neigh-global-max:524288
hubble-export-file-compress:false
enable-bbr:false
trace-payloadlen:128
enable-srv6:false
config-sources:config-map:kube-system/cilium-config
enable-k8s-endpoint-slice:true
agent-liveness-update-interval:1s
read-cni-conf:
preallocate-bpf-maps:false
monitor-queue-size:0
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
egress-masquerade-interfaces:ens+
enable-bpf-tproxy:false
enable-cilium-api-server-access:
nat-map-stats-entries:32
ipv4-native-routing-cidr:
service-no-backend-response:reject
endpoint-queue-size:25
enable-ipv6-masquerade:true
allow-icmp-frag-needed:true
bpf-ct-timeout-service-tcp:2h13m20s
proxy-admin-port:0
enable-host-port:false
ipv6-native-routing-cidr:
enable-active-connection-tracking:false
dnsproxy-enable-transparent-mode:true
metrics:
clustermesh-config:/var/lib/cilium/clustermesh/
enable-hubble-recorder-api:true
ipv4-pod-subnets:
cni-external-routing:false
enable-ipsec:false
pprof-port:6060
arping-refresh-period:30s
pprof:false
policy-queue-size:100
proxy-portrange-max:20000
envoy-config-retry-interval:15s
bpf-lb-source-range-map-max:0
enable-local-redirect-policy:false
enable-recorder:false
auto-create-cilium-node-resource:true
bpf-ct-global-any-max:262144
operator-api-serve-addr:127.0.0.1:9234
enable-encryption-strict-mode:false
certificates-directory:/var/run/cilium/certs
enable-l2-pod-announcements:false
bpf-node-map-max:16384
enable-monitor:true
conntrack-gc-max-interval:0s
auto-direct-node-routes:false
ipam-cilium-node-update-rate:15s
enable-metrics:true
k8s-client-connection-timeout:30s
node-labels:
enable-service-topology:false
encrypt-node:false
mesh-auth-signal-backoff-duration:1s
pprof-address:localhost
container-ip-local-reserved-ports:auto
use-cilium-internal-ip-for-ipsec:false
k8s-service-cache-size:128
enable-bpf-clock-probe:false
ipv4-service-loopback-address:169.254.42.1
hubble-redact-http-userinfo:true
direct-routing-skip-unreachable:false
srv6-encap-mode:reduced
k8s-client-connection-keep-alive:30s
endpoint-gc-interval:5m0s
state-dir:/var/run/cilium
bpf-lb-dsr-l4-xlate:frontend
enable-bandwidth-manager:false
k8s-sync-timeout:3m0s
bpf-events-trace-enabled:true
enable-health-check-loadbalancer-ip:false
hubble-drop-events:false
tofqdns-min-ttl:0
hubble-redact-http-headers-allow:
log-driver:
disable-envoy-version-check:false
l2-pod-announcements-interface:
tofqdns-enable-dns-compression:true
policy-accounting:true
node-port-acceleration:disabled
enable-tracing:false
disable-endpoint-crd:false
proxy-max-connection-duration-seconds:0
identity-heartbeat-timeout:30m0s
enable-session-affinity:false
gateway-api-secrets-namespace:
nodeport-addresses:
nodes-gc-interval:5m0s
enable-ipip-termination:false
enable-icmp-rules:true
bpf-events-drop-enabled:true
enable-high-scale-ipcache:false
node-port-range:
iptables-random-fully:false
bgp-announce-pod-cidr:false
enable-k8s:true
node-port-algorithm:random
encryption-strict-mode-cidr:
enable-l2-announcements:false
monitor-aggregation:medium
allocator-list-timeout:3m0s
enable-ipsec-encrypted-overlay:false
unmanaged-pod-watcher-interval:15
api-rate-limit:
bpf-lb-rev-nat-map-max:0
http-normalize-path:true
mesh-auth-rotated-identities-queue-size:1024
hubble-event-buffer-capacity:4095
debug-verbose:
bpf-nat-global-max:524288
vtep-endpoint:
local-router-ipv6:
bpf-lb-affinity-map-max:0
k8s-api-server:
custom-cni-conf:false
dnsproxy-socket-linger-timeout:10
enable-unreachable-routes:false
policy-audit-mode:false
external-envoy-proxy:true
enable-ipv6-ndp:false
fixed-identity-mapping:
bpf-auth-map-max:524288
k8s-require-ipv4-pod-cidr:false
hubble-flowlogs-config-path:
ipv4-node:auto
enable-ipsec-key-watcher:true
bpf-lb-sock-terminate-pod-connections:false
bpf-lb-maglev-table-size:16381
bpf-lb-rss-ipv6-src-cidr:
mesh-auth-spiffe-trust-domain:spiffe.cilium
policy-trigger-interval:1s
bpf-lb-acceleration:disabled
enable-identity-mark:true
kvstore-periodic-sync:5m0s
bpf-ct-timeout-service-tcp-grace:1m0s
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
hubble-redact-kafka-apikey:false
dns-max-ips-per-restored-rule:1000
labels:
hubble-redact-http-urlquery:false
l2-announcements-renew-deadline:5s
dnsproxy-concurrency-processing-grace-period:0s
enable-wireguard-userspace-fallback:false
enable-nat46x64-gateway:false
identity-change-grace-period:5s
ipv6-pod-subnets:
derive-masq-ip-addr-from-device:
install-iptables-rules:true
bpf-lb-maglev-map-max:0
devices:
enable-svc-source-range-check:true
kube-proxy-replacement-healthz-bind-address:
hubble-skip-unknown-cgroup-ids:true
exclude-node-label-patterns:
proxy-max-requests-per-connection:0
enable-envoy-config:false
bpf-ct-timeout-regular-tcp-fin:10s
enable-local-node-route:true
routing-mode:tunnel
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
hubble-socket-path:/var/run/cilium/hubble.sock
enable-pmtu-discovery:false
enable-cilium-health-api-server-access:
clustermesh-sync-timeout:1m0s
encrypt-interface:
monitor-aggregation-flags:all
http-request-timeout:3600
controller-group-metrics:
egress-gateway-policy-map-max:16384
conntrack-gc-interval:0s
enable-ipv6-big-tcp:false
enable-custom-calls:false
bpf-lb-service-backend-map-max:0
cluster-pool-ipv4-mask-size:24
kvstore-max-consecutive-quorum-errors:2
wireguard-persistent-keepalive:0s
mke-cgroup-mount:
ipam:cluster-pool
egress-gateway-reconciliation-trigger-interval:1s
enable-cilium-endpoint-slice:false
tofqdns-max-deferred-connection-deletes:10000
tofqdns-proxy-response-max-delay:100ms
egress-multi-home-ip-rule-compat:false
bypass-ip-availability-upon-restore:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
hubble-listen-address::4244
endpoint-bpf-prog-watchdog-interval:30s
hubble-monitor-events:
local-max-addr-scope:252
bpf-lb-sock:false
prepend-iptables-chains:true
bpf-ct-global-tcp-max:524288
cilium-endpoint-gc-interval:5m0s
tofqdns-idle-connection-grace-period:0s
policy-cidr-match-mode:
cni-exclusive:true
identity-restore-grace-period:30s
allow-localhost:auto
exclude-local-address:
ipv4-service-range:auto
http-retry-timeout:0
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bgp-config-path:/var/lib/cilium/bgp/config.yaml
vtep-cidr:
k8s-client-qps:10
enable-ipsec-xfrm-state-caching:true
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
envoy-log:
encryption-strict-mode-allow-remote-node-identities:false
http-idle-timeout:0
hubble-prefer-ipv6:false
bpf-filter-priority:1
k8s-client-burst:20
proxy-idle-timeout-seconds:60
direct-routing-device:
mtu:0
proxy-xff-num-trusted-hops-egress:0
enable-endpoint-routes:false
use-full-tls-context:false
ipam-default-ip-pool:default
enable-k8s-terminating-endpoint:true
k8s-heartbeat-timeout:30s
bpf-lb-mode:snat
ingress-secrets-namespace:
node-port-mode:snat
enable-ingress-controller:false
hubble-redact-http-headers-deny:
mesh-auth-mutual-connect-timeout:5s
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
346        Disabled           Disabled          4          reserved:health                                                                     10.29.0.183   ready   
918        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.large                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
1109       Disabled           Disabled          1008833    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.29.0.37    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh30                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
1168       Disabled           Disabled          983237     k8s:eks.amazonaws.com/component=coredns                                             10.29.0.228   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh30                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
1221       Disabled           Disabled          983237     k8s:eks.amazonaws.com/component=coredns                                             10.29.0.70    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh30                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
```

#### BPF Policy Get 346

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1652866   20886     0        
Allow    Ingress     1          ANY          NONE         disabled    25948     302       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        

```


#### BPF CT List 346

```
Invalid argument: unknown type 346
```


#### Endpoint Get 346

```
[
  {
    "id": 346,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-346-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f61132eb-7efd-4d5f-8b88-d5d121190921"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-346",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:28.819Z",
            "success-count": 7
          },
          "uuid": "db5e2b54-5a82-49db-91be-2d9e17572780"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-346",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:32.023Z",
            "success-count": 3
          },
          "uuid": "49d41938-fb19-4baa-945f-ec7ad137a47b"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:12:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.29.0.183",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "da:c5:1a:3b:bb:02",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "d2:67:7a:f5:3a:6d"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 346

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 346

```
Timestamp              Status   State                   Message
2024-10-30T08:12:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:12:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:09Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:12:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:12:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-30T07:52:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:52:32Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-30T07:52:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:52:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-30T07:52:30Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T07:52:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-30T07:52:28Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:52:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:52:28Z   OK       ready                   Set identity for this endpoint
2024-10-30T07:52:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 918

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 918

```
Invalid argument: unknown type 918
```


#### Endpoint Get 918

```
[
  {
    "id": 918,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-918-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "bf12c549-34e0-4dd4-a464-f6306867e3a4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-918",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:27.752Z",
            "success-count": 7
          },
          "uuid": "e0b6c58b-befa-42f3-b550-e24fe3f52de9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-918",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:28.820Z",
            "success-count": 3
          },
          "uuid": "894e5ecf-8773-477d-88d3-f75022bc8ff0"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:12:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "86:92:29:42:99:59",
        "interface-name": "cilium_host",
        "mac": "86:92:29:42:99:59"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 918

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 918

```
Timestamp              Status   State                   Message
2024-10-30T08:12:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:12:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:09Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:12:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:12:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:52:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:52:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:52:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T07:52:30Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-30T07:52:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:29Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-30T07:52:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-30T07:52:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:52:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:52:27Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:52:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:52:27Z   OK       ready                   Set identity for this endpoint
2024-10-30T07:52:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 1109

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11595611   115599    0        
Allow    Ingress     1          ANY          NONE         disabled    9851603    103512    0        
Allow    Egress      0          ANY          NONE         disabled    12754227   125700    0        

```


#### BPF CT List 1109

```
Invalid argument: unknown type 1109
```


#### Endpoint Get 1109

```
[
  {
    "id": 1109,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1109-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b80703e4-aa8d-4ec8-864b-02b025d3f95d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1109",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:21:08.264Z",
            "success-count": 3
          },
          "uuid": "994630e5-0264-4ce9-8d46-01bb6bffd351"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-68695cfc57-6482h",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:11:08.263Z",
            "success-count": 1
          },
          "uuid": "7fa30ce0-9005-43a4-9f16-111095b05e5f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1109",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:11:08.300Z",
            "success-count": 1
          },
          "uuid": "4d4d06c1-2a1e-4129-ac45-e1da0b787f10"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1109)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:28.345Z",
            "success-count": 76
          },
          "uuid": "75ef0d99-f893-41d6-b7ca-1e43e7c6ce9e"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "9af77955baebfb8a3f61272b68dac0b1fb9c438c3ecfe86a4b7e04826bd8d40f:eth0",
        "container-id": "9af77955baebfb8a3f61272b68dac0b1fb9c438c3ecfe86a4b7e04826bd8d40f",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-68695cfc57-6482h",
        "pod-name": "kube-system/clustermesh-apiserver-68695cfc57-6482h"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1008833,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh30",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=68695cfc57"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh30",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:12:09Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.29.0.37",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "66:cb:92:de:7b:da",
        "interface-index": 18,
        "interface-name": "lxc33098500f206",
        "mac": "72:6a:4d:d1:96:db"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1008833,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1008833,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1109

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1109

```
Timestamp              Status   State                   Message
2024-10-30T08:12:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:12:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:09Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:12:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:12:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T08:11:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:08Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T08:11:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T08:11:08Z   OK       ready                   Set identity for this endpoint
2024-10-30T08:11:08Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1008833

```
ID        LABELS
1008833   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh30
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1168

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    178844   2060      0        
Allow    Egress      0          ANY          NONE         disabled    19569    220       0        

```


#### BPF CT List 1168

```
Invalid argument: unknown type 1168
```


#### Endpoint Get 1168

```
[
  {
    "id": 1168,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1168-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "6159c16e-027b-4a14-a80c-b45dd234f310"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1168",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:30.778Z",
            "success-count": 7
          },
          "uuid": "4088d444-3636-4ffa-85be-98cb5b0b4d1c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-t4hs9",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T07:52:30.775Z",
            "success-count": 1
          },
          "uuid": "a59a676b-a985-4e61-9776-c385bbfd2022"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1168",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:32.034Z",
            "success-count": 3
          },
          "uuid": "48bde7ab-afcc-44f2-95a7-b33fe8259b35"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1168)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:20.919Z",
            "success-count": 187
          },
          "uuid": "03b1eff7-e633-4329-aba6-662f95c1479f"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "0e540ced328a591af7db34e90431bc1e4f7784e2552d2ec0dbd6dd64b72423d8:eth0",
        "container-id": "0e540ced328a591af7db34e90431bc1e4f7784e2552d2ec0dbd6dd64b72423d8",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-t4hs9",
        "pod-name": "kube-system/coredns-cc6ccd49c-t4hs9"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 983237,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh30",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh30",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:12:09Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.29.0.228",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "26:d8:45:03:fa:a7",
        "interface-index": 12,
        "interface-name": "lxcd44ff3a4bbad",
        "mac": "f6:8f:b5:04:82:4d"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 983237,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 983237,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1168

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1168

```
Timestamp              Status    State                   Message
2024-10-30T08:12:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:12:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:09Z   OK        regenerating            Regenerating endpoint: 
2024-10-30T08:12:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:12:08Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:08Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:08Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:08Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:07Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:07Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:07Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:07Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:06Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:06Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:06Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:06Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:43Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:42Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:42Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:42Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:32Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:52:32Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:52:32Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:52:32Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:52:31Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:30Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:52:30Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:52:30Z   OK        ready                   Set identity for this endpoint
2024-10-30T07:52:30Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:30Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 983237

```
ID       LABELS
983237   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh30
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1221

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176301   2027      0        
Allow    Egress      0          ANY          NONE         disabled    21936    246       0        

```


#### BPF CT List 1221

```
Invalid argument: unknown type 1221
```


#### Endpoint Get 1221

```
[
  {
    "id": 1221,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1221-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f101ef5f-fa02-49e0-bbcb-fd31c1e8f5f9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1221",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:35.507Z",
            "success-count": 7
          },
          "uuid": "75ec6e39-bee1-4c5a-818a-30d9f3ef73f6"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-qhv68",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T07:52:35.504Z",
            "success-count": 1
          },
          "uuid": "199dc7d7-9130-4d7f-b432-e75c20d2bf0f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1221",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:35.534Z",
            "success-count": 3
          },
          "uuid": "c6609bb6-8173-46e0-8f38-10014719f8ea"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1221)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:25.646Z",
            "success-count": 187
          },
          "uuid": "ba1d6eab-0017-4aaf-ab37-2d99f88869a4"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "3a4b52bad9f77502f17de0defbec8587c6c133f613cf34d3075187ab04f15df4:eth0",
        "container-id": "3a4b52bad9f77502f17de0defbec8587c6c133f613cf34d3075187ab04f15df4",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-qhv68",
        "pod-name": "kube-system/coredns-cc6ccd49c-qhv68"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 983237,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh30",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh30",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:12:09Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.29.0.70",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "0e:a6:b7:1a:56:ea",
        "interface-index": 14,
        "interface-name": "lxc5021ed9c3d72",
        "mac": "3e:d8:cd:cf:88:a2"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 983237,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 983237,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1221

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1221

```
Timestamp              Status   State                   Message
2024-10-30T08:12:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:12:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:09Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:12:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:12:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:52:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:52:35Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:52:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:52:35Z   OK       ready                   Set identity for this endpoint
2024-10-30T07:52:35Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 983237

```
ID       LABELS
983237   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh30
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.159.121:443 (active)    
                                          2 => 172.31.210.169:443 (active)    
2    10.100.88.194:443     ClusterIP      1 => 172.31.231.174:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.29.0.228:53 (active)        
                                          2 => 10.29.0.70:53 (active)         
4    10.100.0.10:9153      ClusterIP      1 => 10.29.0.228:9153 (active)      
                                          2 => 10.29.0.70:9153 (active)       
5    10.100.252.125:2379   ClusterIP      1 => 10.29.0.37:2379 (active)       
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.29.0.0/24, 
Allocated addresses:
  10.29.0.183 (health)
  10.29.0.228 (kube-system/coredns-cc6ccd49c-t4hs9)
  10.29.0.229 (router)
  10.29.0.37 (kube-system/clustermesh-apiserver-68695cfc57-6482h)
  10.29.0.70 (kube-system/coredns-cc6ccd49c-qhv68)
ClusterMesh:   255/255 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh129: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=129, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh130: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=130, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh131: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=131, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh132: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=132, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh133: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=133, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh134: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=134, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh135: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=135, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh136: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=136, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh137: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=137, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh138: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=138, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh139: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=139, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh140: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=140, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh141: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=141, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh142: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=142, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh143: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=143, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh144: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=144, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh145: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=145, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh146: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=146, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh147: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=147, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh148: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=148, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh149: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=149, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh150: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=150, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh151: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=151, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh152: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=152, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh153: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=153, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh154: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=154, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh155: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=155, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh156: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=156, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh157: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=157, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh158: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=158, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh159: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=159, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh160: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=160, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh161: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=161, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh162: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=162, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh163: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=163, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh164: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=164, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh165: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=165, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh166: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=166, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh167: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=167, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh168: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=168, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh169: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=169, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh170: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=170, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh171: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=171, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh172: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=172, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh173: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=173, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh174: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=174, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh175: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=175, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh176: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=176, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh177: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=177, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh178: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=178, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh179: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=179, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh180: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=180, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh181: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=181, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh182: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=182, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh183: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=183, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh184: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=184, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh185: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=185, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh186: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=186, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh187: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=187, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh188: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=188, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh189: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=189, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh190: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=190, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh191: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=191, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh192: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=192, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh193: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=193, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh194: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=194, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh195: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=195, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh196: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=196, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh197: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=197, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh198: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=198, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh199: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=199, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh200: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=200, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh201: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=201, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh202: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=202, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh203: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=203, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh204: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=204, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh205: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=205, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh206: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=206, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh207: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=207, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh208: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=208, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh209: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=209, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh210: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=210, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh211: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=211, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh212: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=212, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh213: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=213, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh214: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=214, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh215: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=215, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh216: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=216, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh217: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=217, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh218: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=218, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh219: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=219, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh220: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=220, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh221: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=221, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh222: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=222, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh223: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=223, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh224: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=224, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh225: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=225, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh226: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=226, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh227: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=227, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh228: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=228, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh229: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=229, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh230: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=230, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh231: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=231, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh232: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=232, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh233: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=233, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh234: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=234, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh235: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=235, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh236: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=236, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh237: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=237, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh238: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=238, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh239: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=239, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh240: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=240, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh241: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=241, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh242: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=242, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh243: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=243, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh244: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=244, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh245: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=245, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh246: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=246, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh247: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=247, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh248: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=248, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh249: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=249, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh250: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=250, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh251: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=251, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh252: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=252, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh253: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=253, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh254: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=254, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh255: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=255, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh256: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=256, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b33bbc17ef237aa0
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      290/290 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    1m1s ago       never        0       no error   
  ct-map-pressure                                                     2s ago         never        0       no error   
  daemon-validate-config                                              32s ago        never        0       no error   
  dns-garbage-collector-job                                           4s ago         never        0       no error   
  endpoint-1109-regeneration-recovery                                 never          never        0       no error   
  endpoint-1168-regeneration-recovery                                 never          never        0       no error   
  endpoint-1221-regeneration-recovery                                 never          never        0       no error   
  endpoint-346-regeneration-recovery                                  never          never        0       no error   
  endpoint-918-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         1m4s ago       never        0       no error   
  ep-bpf-prog-watchdog                                                2s ago         never        0       no error   
  ipcache-inject-labels                                               2s ago         never        0       no error   
  k8s-heartbeat                                                       4s ago         never        0       no error   
  link-cache                                                          2s ago         never        0       no error   
  local-identity-checkpoint                                           31m2s ago      never        0       no error   
  node-neighbor-link-updater                                          2s ago         never        0       no error   
  remote-etcd-cmesh1                                                  11m22s ago     never        0       no error   
  remote-etcd-cmesh10                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh100                                                11m23s ago     never        0       no error   
  remote-etcd-cmesh101                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh102                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh103                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh104                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh105                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh106                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh107                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh108                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh109                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh11                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh110                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh111                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh112                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh113                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh114                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh115                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh116                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh117                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh118                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh119                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh12                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh120                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh121                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh122                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh123                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh124                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh125                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh126                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh127                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh128                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh129                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh13                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh130                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh131                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh132                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh133                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh134                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh135                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh136                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh137                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh138                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh139                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh14                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh140                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh141                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh142                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh143                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh144                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh145                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh146                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh147                                                11m23s ago     never        0       no error   
  remote-etcd-cmesh148                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh149                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh15                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh150                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh151                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh152                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh153                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh154                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh155                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh156                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh157                                                11m23s ago     never        0       no error   
  remote-etcd-cmesh158                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh159                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh16                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh160                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh161                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh162                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh163                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh164                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh165                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh166                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh167                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh168                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh169                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh17                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh170                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh171                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh172                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh173                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh174                                                11m23s ago     never        0       no error   
  remote-etcd-cmesh175                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh176                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh177                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh178                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh179                                                11m23s ago     never        0       no error   
  remote-etcd-cmesh18                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh180                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh181                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh182                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh183                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh184                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh185                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh186                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh187                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh188                                                11m23s ago     never        0       no error   
  remote-etcd-cmesh189                                                11m23s ago     never        0       no error   
  remote-etcd-cmesh19                                                 11m23s ago     never        0       no error   
  remote-etcd-cmesh190                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh191                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh192                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh193                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh194                                                11m23s ago     never        0       no error   
  remote-etcd-cmesh195                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh196                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh197                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh198                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh199                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh2                                                  11m22s ago     never        0       no error   
  remote-etcd-cmesh20                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh200                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh201                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh202                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh203                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh204                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh205                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh206                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh207                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh208                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh209                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh21                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh210                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh211                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh212                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh213                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh214                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh215                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh216                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh217                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh218                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh219                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh22                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh220                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh221                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh222                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh223                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh224                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh225                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh226                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh227                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh228                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh229                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh23                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh230                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh231                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh232                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh233                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh234                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh235                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh236                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh237                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh238                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh239                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh24                                                 11m23s ago     never        0       no error   
  remote-etcd-cmesh240                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh241                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh242                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh243                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh244                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh245                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh246                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh247                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh248                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh249                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh25                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh250                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh251                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh252                                                11m23s ago     never        0       no error   
  remote-etcd-cmesh253                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh254                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh255                                                11m23s ago     never        0       no error   
  remote-etcd-cmesh256                                                11m22s ago     never        0       no error   
  remote-etcd-cmesh26                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh27                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh28                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh29                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh3                                                  11m22s ago     never        0       no error   
  remote-etcd-cmesh31                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh32                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh33                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh34                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh35                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh36                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh37                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh38                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh39                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh4                                                  11m22s ago     never        0       no error   
  remote-etcd-cmesh40                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh41                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh42                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh43                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh44                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh45                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh46                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh47                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh48                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh49                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh5                                                  11m22s ago     never        0       no error   
  remote-etcd-cmesh50                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh51                                                 11m23s ago     never        0       no error   
  remote-etcd-cmesh52                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh53                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh54                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh55                                                 11m23s ago     never        0       no error   
  remote-etcd-cmesh56                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh57                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh58                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh59                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh6                                                  11m22s ago     never        0       no error   
  remote-etcd-cmesh60                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh61                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh62                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh63                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh64                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh65                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh66                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh67                                                 11m23s ago     never        0       no error   
  remote-etcd-cmesh68                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh69                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh7                                                  11m22s ago     never        0       no error   
  remote-etcd-cmesh70                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh71                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh72                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh73                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh74                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh75                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh76                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh77                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh78                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh79                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh8                                                  11m22s ago     never        0       no error   
  remote-etcd-cmesh80                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh81                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh82                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh83                                                 11m23s ago     never        0       no error   
  remote-etcd-cmesh84                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh85                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh86                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh87                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh88                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh89                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh9                                                  11m22s ago     never        0       no error   
  remote-etcd-cmesh90                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh91                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh92                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh93                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh94                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh95                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh96                                                 11m23s ago     never        0       no error   
  remote-etcd-cmesh97                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh98                                                 11m22s ago     never        0       no error   
  remote-etcd-cmesh99                                                 11m22s ago     never        0       no error   
  resolve-identity-1109                                               2m21s ago      never        0       no error   
  resolve-identity-1168                                               59s ago        never        0       no error   
  resolve-identity-1221                                               54s ago        never        0       no error   
  resolve-identity-346                                                1m1s ago       never        0       no error   
  resolve-identity-918                                                1m2s ago       never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-68695cfc57-6482h   12m21s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-qhv68                  30m54s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-t4hs9                  30m59s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      31m2s ago      never        0       no error   
  sync-policymap-1109                                                 12m21s ago     never        0       no error   
  sync-policymap-1168                                                 58s ago        never        0       no error   
  sync-policymap-1221                                                 54s ago        never        0       no error   
  sync-policymap-346                                                  58s ago        never        0       no error   
  sync-policymap-918                                                  1m1s ago       never        0       no error   
  sync-to-k8s-ciliumendpoint (1109)                                   11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1168)                                   9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1221)                                   4s ago         never        0       no error   
  sync-utime                                                          2s ago         never        0       no error   
  write-cni-file                                                      31m4s ago      never        0       no error   
Proxy Status:            OK, ip 10.29.0.229, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 983040, max 1015807
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 110.66   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium encryption


