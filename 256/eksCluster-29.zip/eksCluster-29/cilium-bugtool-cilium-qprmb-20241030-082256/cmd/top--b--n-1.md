top - 08:22:57 up 38 min,  0 users,  load average: 0.25, 0.27, 0.20
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 70.0 us, 10.0 sy,  0.0 ni, 20.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4483.7 free,   1183.6 used,   2146.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6445.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 380772  79812 S 100.0   4.8   0:45.30 cilium-+
    643 root      20   0 1240432  16460  11292 S   6.7   0.2   0:00.02 cilium-+
    392 root      20   0 1229744   6924   2924 S   0.0   0.1   0:01.10 cilium-+
    663 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    677 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    682 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    689 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    716 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
