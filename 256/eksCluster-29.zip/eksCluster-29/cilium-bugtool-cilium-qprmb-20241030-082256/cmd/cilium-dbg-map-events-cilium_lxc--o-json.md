{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:27.622Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.230.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:27.622Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.231.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:27.622Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:32.020Z",
  "value": "id=346   sec_id=4     flags=0x0000 ifindex=10  mac=D2:67:7A:F5:3A:6D nodemac=DA:C5:1A:3B:BB:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:32.032Z",
  "value": "id=1168  sec_id=983237 flags=0x0000 ifindex=12  mac=F6:8F:B5:04:82:4D nodemac=26:D8:45:03:FA:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:32.033Z",
  "value": "id=1168  sec_id=983237 flags=0x0000 ifindex=12  mac=F6:8F:B5:04:82:4D nodemac=26:D8:45:03:FA:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:32.052Z",
  "value": "id=346   sec_id=4     flags=0x0000 ifindex=10  mac=D2:67:7A:F5:3A:6D nodemac=DA:C5:1A:3B:BB:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:35.533Z",
  "value": "id=1221  sec_id=983237 flags=0x0000 ifindex=14  mac=3E:D8:CD:CF:88:A2 nodemac=0E:A6:B7:1A:56:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:42.835Z",
  "value": "id=346   sec_id=4     flags=0x0000 ifindex=10  mac=D2:67:7A:F5:3A:6D nodemac=DA:C5:1A:3B:BB:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:42.835Z",
  "value": "id=1168  sec_id=983237 flags=0x0000 ifindex=12  mac=F6:8F:B5:04:82:4D nodemac=26:D8:45:03:FA:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:42.835Z",
  "value": "id=1221  sec_id=983237 flags=0x0000 ifindex=14  mac=3E:D8:CD:CF:88:A2 nodemac=0E:A6:B7:1A:56:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:42.867Z",
  "value": "id=3347  sec_id=1008833 flags=0x0000 ifindex=16  mac=1A:39:A2:09:66:F8 nodemac=16:FE:4D:09:03:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:43.836Z",
  "value": "id=346   sec_id=4     flags=0x0000 ifindex=10  mac=D2:67:7A:F5:3A:6D nodemac=DA:C5:1A:3B:BB:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:43.836Z",
  "value": "id=1168  sec_id=983237 flags=0x0000 ifindex=12  mac=F6:8F:B5:04:82:4D nodemac=26:D8:45:03:FA:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:43.836Z",
  "value": "id=3347  sec_id=1008833 flags=0x0000 ifindex=16  mac=1A:39:A2:09:66:F8 nodemac=16:FE:4D:09:03:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:43.836Z",
  "value": "id=1221  sec_id=983237 flags=0x0000 ifindex=14  mac=3E:D8:CD:CF:88:A2 nodemac=0E:A6:B7:1A:56:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:08.300Z",
  "value": "id=1109  sec_id=1008833 flags=0x0000 ifindex=18  mac=72:6A:4D:D1:96:DB nodemac=66:CB:92:DE:7B:DA"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.29.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.704Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.764Z",
  "value": "id=1221  sec_id=983237 flags=0x0000 ifindex=14  mac=3E:D8:CD:CF:88:A2 nodemac=0E:A6:B7:1A:56:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.764Z",
  "value": "id=1109  sec_id=1008833 flags=0x0000 ifindex=18  mac=72:6A:4D:D1:96:DB nodemac=66:CB:92:DE:7B:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.765Z",
  "value": "id=346   sec_id=4     flags=0x0000 ifindex=10  mac=D2:67:7A:F5:3A:6D nodemac=DA:C5:1A:3B:BB:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.765Z",
  "value": "id=1168  sec_id=983237 flags=0x0000 ifindex=12  mac=F6:8F:B5:04:82:4D nodemac=26:D8:45:03:FA:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:07.790Z",
  "value": "id=1221  sec_id=983237 flags=0x0000 ifindex=14  mac=3E:D8:CD:CF:88:A2 nodemac=0E:A6:B7:1A:56:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:07.906Z",
  "value": "id=1109  sec_id=1008833 flags=0x0000 ifindex=18  mac=72:6A:4D:D1:96:DB nodemac=66:CB:92:DE:7B:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:07.907Z",
  "value": "id=346   sec_id=4     flags=0x0000 ifindex=10  mac=D2:67:7A:F5:3A:6D nodemac=DA:C5:1A:3B:BB:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:07.907Z",
  "value": "id=1168  sec_id=983237 flags=0x0000 ifindex=12  mac=F6:8F:B5:04:82:4D nodemac=26:D8:45:03:FA:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:08.767Z",
  "value": "id=1109  sec_id=1008833 flags=0x0000 ifindex=18  mac=72:6A:4D:D1:96:DB nodemac=66:CB:92:DE:7B:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:08.768Z",
  "value": "id=1221  sec_id=983237 flags=0x0000 ifindex=14  mac=3E:D8:CD:CF:88:A2 nodemac=0E:A6:B7:1A:56:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:08.768Z",
  "value": "id=346   sec_id=4     flags=0x0000 ifindex=10  mac=D2:67:7A:F5:3A:6D nodemac=DA:C5:1A:3B:BB:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:08.768Z",
  "value": "id=1168  sec_id=983237 flags=0x0000 ifindex=12  mac=F6:8F:B5:04:82:4D nodemac=26:D8:45:03:FA:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.767Z",
  "value": "id=346   sec_id=4     flags=0x0000 ifindex=10  mac=D2:67:7A:F5:3A:6D nodemac=DA:C5:1A:3B:BB:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.767Z",
  "value": "id=1109  sec_id=1008833 flags=0x0000 ifindex=18  mac=72:6A:4D:D1:96:DB nodemac=66:CB:92:DE:7B:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.768Z",
  "value": "id=1168  sec_id=983237 flags=0x0000 ifindex=12  mac=F6:8F:B5:04:82:4D nodemac=26:D8:45:03:FA:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.768Z",
  "value": "id=1221  sec_id=983237 flags=0x0000 ifindex=14  mac=3E:D8:CD:CF:88:A2 nodemac=0E:A6:B7:1A:56:EA"
}

