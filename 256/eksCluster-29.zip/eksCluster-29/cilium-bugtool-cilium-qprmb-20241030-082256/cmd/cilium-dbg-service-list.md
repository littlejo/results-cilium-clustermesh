ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.159.121:443 (active)    
                                          2 => 172.31.210.169:443 (active)    
2    10.100.88.194:443     ClusterIP      1 => 172.31.231.174:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.29.0.228:53 (active)        
                                          2 => 10.29.0.70:53 (active)         
4    10.100.0.10:9153      ClusterIP      1 => 10.29.0.228:9153 (active)      
                                          2 => 10.29.0.70:9153 (active)       
5    10.100.252.125:2379   ClusterIP      1 => 10.29.0.37:2379 (active)       
