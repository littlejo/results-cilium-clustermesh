ip-172-31-231-174.eu-west-3.compute.internal
