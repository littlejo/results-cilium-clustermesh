KEY             VALUE
AgentLiveness   2312184386895
UTimeOffset     3379441984375000
