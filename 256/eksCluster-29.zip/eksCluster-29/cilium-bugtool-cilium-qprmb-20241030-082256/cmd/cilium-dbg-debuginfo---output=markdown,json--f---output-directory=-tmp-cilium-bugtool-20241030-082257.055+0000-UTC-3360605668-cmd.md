markdown output at /tmp/cilium-bugtool-20241030-082257.055+0000-UTC-3360605668/cmd/cilium-debuginfo-20241030-082328.297+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082257.055+0000-UTC-3360605668/cmd/cilium-debuginfo-20241030-082328.297+0000-UTC.json
