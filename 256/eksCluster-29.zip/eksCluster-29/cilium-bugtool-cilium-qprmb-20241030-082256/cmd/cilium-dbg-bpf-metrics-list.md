REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35606     2814284     677    bpf_overlay.c
Interface                 INGRESS     642019    132653733   1132   bpf_host.c
Success                   EGRESS      15347     1203468     1694   bpf_host.c
Success                   EGRESS      271787    34039506    1308   bpf_lxc.c
Success                   EGRESS      35172     2782227     53     encap.h
Success                   INGRESS     314043    35354435    86     l3.h
Success                   INGRESS     334954    37009367    235    trace.h
Unsupported L3 protocol   EGRESS      48        3628        1492   bpf_lxc.c
