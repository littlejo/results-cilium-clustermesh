alloc: 144.11MB (151109256 bytes)
total-alloc: 2.28GB (2452842768 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63842333
frees: 62317108
heap-alloc: 144.11MB (151109256 bytes)
heap-sys: 247.48MB (259497984 bytes)
heap-idle: 77.59MB (81362944 bytes)
heap-in-use: 169.88MB (178135040 bytes)
heap-released: 6.26MB (6561792 bytes)
heap-objects: 1525225
stack-in-use: 64.50MB (67633152 bytes)
stack-sys: 64.50MB (67633152 bytes)
stack-mspan-inuse: 2.86MB (3003680 bytes)
stack-mspan-sys: 3.77MB (3949440 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.05MB (1096953 bytes)
gc-sys: 6.01MB (6299136 bytes)
next-gc: when heap-alloc >= 213.39MB (223753688 bytes)
last-gc: 2024-10-30 08:23:02.866799751 +0000 UTC
gc-pause-total: 8.684636ms
gc-pause: 67774
gc-pause-end: 1730276582866799751
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.0003459077184434159
enable-gc: true
debug-gc: false
