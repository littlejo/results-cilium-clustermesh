key: 5a 01 00 00  value: 19 02 00 00
key: 55 04 00 00  value: 62 02 00 00
key: 90 04 00 00  value: 0f 02 00 00
key: c5 04 00 00  value: 29 02 00 00
Found 4 elements
