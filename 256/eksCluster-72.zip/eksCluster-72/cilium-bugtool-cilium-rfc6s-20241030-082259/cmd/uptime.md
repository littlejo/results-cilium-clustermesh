 08:23:00 up 35 min,  0 users,  load average: 0.69, 0.41, 0.24
