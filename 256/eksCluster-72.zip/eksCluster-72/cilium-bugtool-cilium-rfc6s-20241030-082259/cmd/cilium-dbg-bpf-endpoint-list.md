IP ADDRESS         LOCAL ENDPOINT INFO
10.72.0.7:0        id=658   sec_id=4     flags=0x0000 ifindex=10  mac=BA:AC:73:F2:6F:A7 nodemac=92:E5:55:54:D4:CA     
10.72.0.117:0      id=293   sec_id=2406176 flags=0x0000 ifindex=14  mac=AA:12:BD:7E:D3:F5 nodemac=9E:B1:87:13:73:1F   
172.31.165.142:0   (localhost)                                                                                        
10.72.0.172:0      (localhost)                                                                                        
10.72.0.84:0       id=2160  sec_id=2392286 flags=0x0000 ifindex=18  mac=7E:7C:CE:BA:5E:42 nodemac=26:14:20:14:50:65   
10.72.0.66:0       id=223   sec_id=2406176 flags=0x0000 ifindex=12  mac=5A:4A:01:F7:06:6F nodemac=06:C5:B6:CA:56:7E   
172.31.154.219:0   (localhost)                                                                                        
