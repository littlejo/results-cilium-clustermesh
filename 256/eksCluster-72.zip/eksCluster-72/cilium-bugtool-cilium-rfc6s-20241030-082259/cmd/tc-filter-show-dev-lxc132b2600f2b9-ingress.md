filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc132b2600f2b9 direct-action not_in_hw id 551 tag 16b07877631b87b7 jited 
