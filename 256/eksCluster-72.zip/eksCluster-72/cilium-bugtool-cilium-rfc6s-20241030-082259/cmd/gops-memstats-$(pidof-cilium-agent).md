alloc: 163.09MB (171014464 bytes)
total-alloc: 2.30GB (2464769984 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 64096837
frees: 62179566
heap-alloc: 163.09MB (171014464 bytes)
heap-sys: 247.79MB (259825664 bytes)
heap-idle: 56.88MB (59637760 bytes)
heap-in-use: 190.91MB (200187904 bytes)
heap-released: 3.84MB (4022272 bytes)
heap-objects: 1917271
stack-in-use: 64.19MB (67305472 bytes)
stack-sys: 64.19MB (67305472 bytes)
stack-mspan-inuse: 3.28MB (3436160 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.22MB (1276281 bytes)
gc-sys: 6.00MB (6288872 bytes)
next-gc: when heap-alloc >= 212.63MB (222961448 bytes)
last-gc: 2024-10-30 08:23:02.740668847 +0000 UTC
gc-pause-total: 8.991435ms
gc-pause: 106645
gc-pause-end: 1730276582740668847
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.00037752555005879005
enable-gc: true
debug-gc: false
