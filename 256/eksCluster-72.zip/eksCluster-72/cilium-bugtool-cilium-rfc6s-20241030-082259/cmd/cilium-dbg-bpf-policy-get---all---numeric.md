Endpoint ID: 223
Path: /sys/fs/bpf/tc/globals/cilium_policy_00223

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    166676   1920      0        
Allow    Egress      0          ANY          NONE         disabled    21611    243       0        


Endpoint ID: 293
Path: /sys/fs/bpf/tc/globals/cilium_policy_00293

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    166359   1910      0        
Allow    Egress      0          ANY          NONE         disabled    21194    238       0        


Endpoint ID: 658
Path: /sys/fs/bpf/tc/globals/cilium_policy_00658

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1667490   21157     0        
Allow    Ingress     1          ANY          NONE         disabled    24248     284       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2160
Path: /sys/fs/bpf/tc/globals/cilium_policy_02160

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11600610   115230    0        
Allow    Ingress     1          ANY          NONE         disabled    10143901   106714    0        
Allow    Egress      0          ANY          NONE         disabled    12669253   125105    0        


Endpoint ID: 3032
Path: /sys/fs/bpf/tc/globals/cilium_policy_03032

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


