CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda989f5d_8f20_4bcc_a0d7_6d9e30ab2fb9.slice/cri-containerd-c15e61aaee8338ad37f3d142db98ba569a08da031edadd0cc3686475f1c4c79b.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda989f5d_8f20_4bcc_a0d7_6d9e30ab2fb9.slice/cri-containerd-5f808d2c9b01685ef9ad443bd7bdbb94d7baaf16178917b2246de0b37390daa6.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod124cd36f_576b_40bd_9bc8_1824d239242b.slice/cri-containerd-68a35ae67333c26e5a7b3b740043231df454a2be228b58692d5098d0abaa88f3.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod124cd36f_576b_40bd_9bc8_1824d239242b.slice/cri-containerd-db99ed201bc9604d2102b4d8a8f09477619e7a4eb8d67b7f2abc9d580901f770.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9757353_b49f_4bd9_b304_287768755aa3.slice/cri-containerd-0698bb8ab3fb4b84af47f3ceb465c422ca129c2d669f0d9cb7ee302647a675af.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9757353_b49f_4bd9_b304_287768755aa3.slice/cri-containerd-7d2c97cdcc7b86ccafcf7525d312aa4c7502363232427fbfc395859e74efd5b4.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf94d8bb7_f5b3_477f_a8e3_9e761b402b5e.slice/cri-containerd-17bb114114c1501baccb623d311c78ffbf843d9eb2221c99000f75f779967284.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf94d8bb7_f5b3_477f_a8e3_9e761b402b5e.slice/cri-containerd-645f22a5540410d331f28eb2274814d735eaaeff04a5c456cc258a176c828a4b.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c586807_c27a_4229_82b0_97eb8af589af.slice/cri-containerd-8ce1a001f7506363bb98b155e2cfdcf56ed1c8f0c9d12a67fd02e4c0258be8b1.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c586807_c27a_4229_82b0_97eb8af589af.slice/cri-containerd-5037e3e0f0e2d8aa02fc6e4d5d11ade86505c42aa93f4db10ee4974415a795f5.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c586807_c27a_4229_82b0_97eb8af589af.slice/cri-containerd-5b6073aa7882ea374a89ef15211cf213fa18b6a85a984631e36c788a6d5f2bef.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c586807_c27a_4229_82b0_97eb8af589af.slice/cri-containerd-48b1be17ab2b3cdddb21777eee6c57f8c30b567735a193bb990ef644a8168e90.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podac4c91b9_9815_40af_8dec_3314ba1c8dc2.slice/cri-containerd-b15d69899bf2f8a9ea55442de5ec6801e49a2468cb0a1cb045281410a623a7ad.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podac4c91b9_9815_40af_8dec_3314ba1c8dc2.slice/cri-containerd-ad898ad9c5086b15c84fecfd05323606fdfe4a754ce7697e22b2c55b5b8c3f6f.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda415284d_d1a4_4ca5_a129_11e39e694693.slice/cri-containerd-1a5d9d0b7d94f6b2835f39142f63b7833eb84f3474f32c5141bb48552096b5ef.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda415284d_d1a4_4ca5_a129_11e39e694693.slice/cri-containerd-2ba40adc0bfcfcb0b0e7e27166a4af682157b5e66dd68e04fa283130565ab947.scope
    98       cgroup_device   multi                                          
