REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35849     2826152     677    bpf_overlay.c
Interface                 INGRESS     645721    132824379   1132   bpf_host.c
Success                   EGRESS      15395     1206608     1694   bpf_host.c
Success                   EGRESS      273704    34372017    1308   bpf_lxc.c
Success                   EGRESS      35440     2800435     53     encap.h
Success                   INGRESS     316890    35630341    86     l3.h
Success                   INGRESS     337995    37293931    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
