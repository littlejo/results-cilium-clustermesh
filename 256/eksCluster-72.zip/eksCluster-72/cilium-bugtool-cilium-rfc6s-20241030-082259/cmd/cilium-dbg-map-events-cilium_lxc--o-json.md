{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:31.091Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.154.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:31.091Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.165.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:31.091Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:35.937Z",
  "value": "id=658   sec_id=4     flags=0x0000 ifindex=10  mac=BA:AC:73:F2:6F:A7 nodemac=92:E5:55:54:D4:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:35.950Z",
  "value": "id=223   sec_id=2406176 flags=0x0000 ifindex=12  mac=5A:4A:01:F7:06:6F nodemac=06:C5:B6:CA:56:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:36.011Z",
  "value": "id=293   sec_id=2406176 flags=0x0000 ifindex=14  mac=AA:12:BD:7E:D3:F5 nodemac=9E:B1:87:13:73:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:36.032Z",
  "value": "id=658   sec_id=4     flags=0x0000 ifindex=10  mac=BA:AC:73:F2:6F:A7 nodemac=92:E5:55:54:D4:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:42.663Z",
  "value": "id=293   sec_id=2406176 flags=0x0000 ifindex=14  mac=AA:12:BD:7E:D3:F5 nodemac=9E:B1:87:13:73:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:42.663Z",
  "value": "id=658   sec_id=4     flags=0x0000 ifindex=10  mac=BA:AC:73:F2:6F:A7 nodemac=92:E5:55:54:D4:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:42.664Z",
  "value": "id=223   sec_id=2406176 flags=0x0000 ifindex=12  mac=5A:4A:01:F7:06:6F nodemac=06:C5:B6:CA:56:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:42.694Z",
  "value": "id=605   sec_id=2392286 flags=0x0000 ifindex=16  mac=9E:47:35:30:0D:90 nodemac=56:97:B8:BA:F7:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:43.664Z",
  "value": "id=605   sec_id=2392286 flags=0x0000 ifindex=16  mac=9E:47:35:30:0D:90 nodemac=56:97:B8:BA:F7:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:43.664Z",
  "value": "id=223   sec_id=2406176 flags=0x0000 ifindex=12  mac=5A:4A:01:F7:06:6F nodemac=06:C5:B6:CA:56:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:43.664Z",
  "value": "id=293   sec_id=2406176 flags=0x0000 ifindex=14  mac=AA:12:BD:7E:D3:F5 nodemac=9E:B1:87:13:73:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:43.664Z",
  "value": "id=658   sec_id=4     flags=0x0000 ifindex=10  mac=BA:AC:73:F2:6F:A7 nodemac=92:E5:55:54:D4:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.010Z",
  "value": "id=2160  sec_id=2392286 flags=0x0000 ifindex=18  mac=7E:7C:CE:BA:5E:42 nodemac=26:14:20:14:50:65"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.72.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.333Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.701Z",
  "value": "id=658   sec_id=4     flags=0x0000 ifindex=10  mac=BA:AC:73:F2:6F:A7 nodemac=92:E5:55:54:D4:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.702Z",
  "value": "id=223   sec_id=2406176 flags=0x0000 ifindex=12  mac=5A:4A:01:F7:06:6F nodemac=06:C5:B6:CA:56:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.702Z",
  "value": "id=293   sec_id=2406176 flags=0x0000 ifindex=14  mac=AA:12:BD:7E:D3:F5 nodemac=9E:B1:87:13:73:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.702Z",
  "value": "id=2160  sec_id=2392286 flags=0x0000 ifindex=18  mac=7E:7C:CE:BA:5E:42 nodemac=26:14:20:14:50:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.719Z",
  "value": "id=2160  sec_id=2392286 flags=0x0000 ifindex=18  mac=7E:7C:CE:BA:5E:42 nodemac=26:14:20:14:50:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.720Z",
  "value": "id=658   sec_id=4     flags=0x0000 ifindex=10  mac=BA:AC:73:F2:6F:A7 nodemac=92:E5:55:54:D4:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.720Z",
  "value": "id=223   sec_id=2406176 flags=0x0000 ifindex=12  mac=5A:4A:01:F7:06:6F nodemac=06:C5:B6:CA:56:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.720Z",
  "value": "id=293   sec_id=2406176 flags=0x0000 ifindex=14  mac=AA:12:BD:7E:D3:F5 nodemac=9E:B1:87:13:73:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.700Z",
  "value": "id=2160  sec_id=2392286 flags=0x0000 ifindex=18  mac=7E:7C:CE:BA:5E:42 nodemac=26:14:20:14:50:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.700Z",
  "value": "id=658   sec_id=4     flags=0x0000 ifindex=10  mac=BA:AC:73:F2:6F:A7 nodemac=92:E5:55:54:D4:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.700Z",
  "value": "id=223   sec_id=2406176 flags=0x0000 ifindex=12  mac=5A:4A:01:F7:06:6F nodemac=06:C5:B6:CA:56:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.701Z",
  "value": "id=293   sec_id=2406176 flags=0x0000 ifindex=14  mac=AA:12:BD:7E:D3:F5 nodemac=9E:B1:87:13:73:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.700Z",
  "value": "id=2160  sec_id=2392286 flags=0x0000 ifindex=18  mac=7E:7C:CE:BA:5E:42 nodemac=26:14:20:14:50:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.701Z",
  "value": "id=658   sec_id=4     flags=0x0000 ifindex=10  mac=BA:AC:73:F2:6F:A7 nodemac=92:E5:55:54:D4:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.701Z",
  "value": "id=223   sec_id=2406176 flags=0x0000 ifindex=12  mac=5A:4A:01:F7:06:6F nodemac=06:C5:B6:CA:56:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.702Z",
  "value": "id=293   sec_id=2406176 flags=0x0000 ifindex=14  mac=AA:12:BD:7E:D3:F5 nodemac=9E:B1:87:13:73:1F"
}

