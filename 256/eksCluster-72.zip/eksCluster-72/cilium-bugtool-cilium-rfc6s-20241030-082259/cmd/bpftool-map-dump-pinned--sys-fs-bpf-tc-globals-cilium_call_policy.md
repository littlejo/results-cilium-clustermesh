key: df 00 00 00  value: 1b 02 00 00
key: 25 01 00 00  value: 1e 02 00 00
key: 92 02 00 00  value: 2c 02 00 00
key: 70 08 00 00  value: 68 02 00 00
Found 4 elements
