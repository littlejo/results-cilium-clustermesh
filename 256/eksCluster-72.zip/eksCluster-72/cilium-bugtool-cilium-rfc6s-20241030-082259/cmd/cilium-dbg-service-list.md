ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.190.20:443 (active)     
                                        2 => 172.31.242.155:443 (active)    
2    10.100.108.18:443   ClusterIP      1 => 172.31.154.219:4244 (active)   
3    10.100.0.10:9153    ClusterIP      1 => 10.72.0.66:9153 (active)       
                                        2 => 10.72.0.117:9153 (active)      
4    10.100.0.10:53      ClusterIP      1 => 10.72.0.66:53 (active)         
                                        2 => 10.72.0.117:53 (active)        
5    10.100.36.49:2379   ClusterIP      1 => 10.72.0.84:2379 (active)       
