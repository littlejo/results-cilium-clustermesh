top - 08:23:01 up 35 min,  0 users,  load average: 0.69, 0.41, 0.24
Tasks:   8 total,   2 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 43.3 us, 50.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   7814.2 total,   4459.1 free,   1209.1 used,   2146.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6420.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    673 root      20   0 1244340  22420  14528 S  46.7   0.3   0:00.19 hubble
      1 root      20   0 1606336 393608  78012 S  13.3   4.9   0:55.71 cilium-+
    681 root      20   0 1240432  16248  11024 S   6.7   0.2   0:00.03 cilium-+
    394 root      20   0 1229744   7092   2924 S   0.0   0.1   0:01.18 cilium-+
    656 root      20   0 1228744   3944   3228 S   0.0   0.0   0:00.00 gops
    666 root      20   0    2208    784    704 S   0.0   0.0   0:00.00 timeout
    725 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    739 root      20   0    3008    968    856 R   0.0   0.0   0:00.00 ip6tabl+
