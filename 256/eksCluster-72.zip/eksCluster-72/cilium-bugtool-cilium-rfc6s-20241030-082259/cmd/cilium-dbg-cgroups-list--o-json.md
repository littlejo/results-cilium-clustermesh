[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda989f5d_8f20_4bcc_a0d7_6d9e30ab2fb9.slice/cri-containerd-5f808d2c9b01685ef9ad443bd7bdbb94d7baaf16178917b2246de0b37390daa6.scope"
      }
    ],
    "ips": [
      "10.72.0.117"
    ],
    "name": "coredns-cc6ccd49c-7tclq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf94d8bb7_f5b3_477f_a8e3_9e761b402b5e.slice/cri-containerd-17bb114114c1501baccb623d311c78ffbf843d9eb2221c99000f75f779967284.scope"
      }
    ],
    "ips": [
      "10.72.0.66"
    ],
    "name": "coredns-cc6ccd49c-h5nwz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c586807_c27a_4229_82b0_97eb8af589af.slice/cri-containerd-8ce1a001f7506363bb98b155e2cfdcf56ed1c8f0c9d12a67fd02e4c0258be8b1.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c586807_c27a_4229_82b0_97eb8af589af.slice/cri-containerd-5b6073aa7882ea374a89ef15211cf213fa18b6a85a984631e36c788a6d5f2bef.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c586807_c27a_4229_82b0_97eb8af589af.slice/cri-containerd-5037e3e0f0e2d8aa02fc6e4d5d11ade86505c42aa93f4db10ee4974415a795f5.scope"
      }
    ],
    "ips": [
      "10.72.0.84"
    ],
    "name": "clustermesh-apiserver-5bf5f9689d-gj5tb",
    "namespace": "kube-system"
  }
]

