1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:bc:34:38:e4:67 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.154.219/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3279sec preferred_lft 3279sec
    inet6 fe80::4bc:34ff:fe38:e467/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:90:62:8b:8b:7b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.165.142/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::490:62ff:fe8b:8b7b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:57:ea:cb:1e:02 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::857:eaff:fecb:1e02/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:f2:73:d6:be:cb brd ff:ff:ff:ff:ff:ff
    inet 10.72.0.172/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::9cf2:73ff:fed6:becb/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6e:1c:fb:0d:59:51 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6c1c:fbff:fe0d:5951/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:e5:55:54:d4:ca brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::90e5:55ff:fe54:d4ca/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca560a318995c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:c5:b6:ca:56:7e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4c5:b6ff:feca:567e/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc132b2600f2b9@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:b1:87:13:73:1f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::9cb1:87ff:fe13:731f/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc1159e334f228@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:14:20:14:50:65 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2414:20ff:fe14:5065/64 scope link 
       valid_lft forever preferred_lft forever
