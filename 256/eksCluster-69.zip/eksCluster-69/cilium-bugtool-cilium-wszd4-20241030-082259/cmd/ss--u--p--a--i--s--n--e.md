Total: 683
TCP:   1857 (estab 432, closed 1406, orphaned 0, timewait 561)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  451       441       10       
INET	  461       447       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.210.245%ens5:68         0.0.0.0:*    uid:192 ino:70638 sk:312 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:34255 sk:313 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15899 sk:314 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:37717      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:33608 sk:315 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:34254 sk:316 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15900 sk:317 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::806:a6ff:fe4f:2b31]%ens5:546           [::]:*    uid:192 ino:16132 sk:318 cgroup:unreachable:c4e v6only:1 <->                   
