USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         689  0.0  0.2 1240432 16564 ?       Ssl  08:23   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         719  0.0  0.0   6408  1640 ?        R    08:23   0:00  \_ ps auxfw
root         721  0.0  0.0   3852  1272 ?        R    08:23   0:00  \_ bash -c hostname
root         684  0.0  0.0 1228744 4040 ?        Ssl  08:23   0:00 /bin/gops stack 1
root         657  0.0  0.0 1228744 3660 ?        Ssl  08:23   0:00 /bin/gops pprof-cpu 1
root         656  0.0  0.0 1228744 4040 ?        Ssl  08:23   0:00 /bin/gops stats 1
root           1  3.7  4.7 1606080 383220 ?      Ssl  07:57   0:57 cilium-agent --config-dir=/tmp/cilium/config-map
root         419  0.0  0.1 1229744 8252 ?        Sl   07:57   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
