key: c2 04 00 00  value: 7a 02 00 00
key: 77 06 00 00  value: 26 02 00 00
key: 5e 07 00 00  value: 0c 02 00 00
key: fd 0c 00 00  value: 20 02 00 00
Found 4 elements
