CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod51e4fcf5_4886_43d8_94d5_8eff0c7800f8.slice/cri-containerd-924f51380639b2ad5dff56e8ebd5c0c22d8b472e323d6928f0c1e938bb7f2d8a.scope
    492      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod51e4fcf5_4886_43d8_94d5_8eff0c7800f8.slice/cri-containerd-62be9921e14251d590bc800b1dc559e35d5606407567c5c518d6cf14d61ba9e3.scope
    496      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod035eb38b_9b14_4f59_a8ab_b79184cf4d4f.slice/cri-containerd-9baaf8bda51a6a172c8a505bf10977ecdd850e293f3f66af253933c65febded1.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod035eb38b_9b14_4f59_a8ab_b79184cf4d4f.slice/cri-containerd-4aea4c9b4a3410202a9299d3076f777d838478587b11a31f9fcd77ab1fa80c50.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5d76e88d_fcb9_4b19_962d_db805952ddcb.slice/cri-containerd-1e0d5072c39211e2db8ec6259d77bfae3111ed6425b47dfe41dc47feb732f7c8.scope
    543      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5d76e88d_fcb9_4b19_962d_db805952ddcb.slice/cri-containerd-02c15a32a3c55bcf16cc9e7c2e53946cc047ce26f552cd719c88f7760a8ad219.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0e782b3_53f8_4226_863a_92942e670c6c.slice/cri-containerd-4b3551711d8f2b5c12e77a5c2b9cf5f56feefa87bf6b8c4a7b88fd7c055bd779.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0e782b3_53f8_4226_863a_92942e670c6c.slice/cri-containerd-3cd44fbd04821d19ca18000c136da92cbd9c5eeccc2c339d4e36596d6877b75b.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod93f98beb_9733_464c_9320_75773dd4a8eb.slice/cri-containerd-aeaae7eb9df460912220da43ce513d25847ecd64bd95b76a1c663835f0561561.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod93f98beb_9733_464c_9320_75773dd4a8eb.slice/cri-containerd-6715a84bd4a1708407a78811ac5c58cb278690425d3088aedec73e77899aaa07.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff04dfdd_c241_44a9_8e96_58b5d5267403.slice/cri-containerd-77f5e936d71b01d3b29efe168833f2967847a5d9183c04af072f86e96418af84.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff04dfdd_c241_44a9_8e96_58b5d5267403.slice/cri-containerd-5356e4ebe8f6bd05684861c12752390023a4d7956c849a428063981417240b12.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5aa5fde1_bb6e_48bb_b5d0_b96a4cf6ed10.slice/cri-containerd-81b0f1cffb7383eb729774c0eb2e02ee8db0a87c7b121bef2050d3f8deed2b78.scope
    669      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5aa5fde1_bb6e_48bb_b5d0_b96a4cf6ed10.slice/cri-containerd-7c73539d8505701cf44048c23a90b4f278f700ba21e273c6657180b6da00a23f.scope
    665      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5aa5fde1_bb6e_48bb_b5d0_b96a4cf6ed10.slice/cri-containerd-90a2085c689c282a37aab121f31cd3dc67798c0f38d32dad6f416fbc85bd3e34.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5aa5fde1_bb6e_48bb_b5d0_b96a4cf6ed10.slice/cri-containerd-0745acf34ad9aa8e0366021d9bb8413457632929915ad4cb1114a804d53a376a.scope
    645      cgroup_device   multi                                          
