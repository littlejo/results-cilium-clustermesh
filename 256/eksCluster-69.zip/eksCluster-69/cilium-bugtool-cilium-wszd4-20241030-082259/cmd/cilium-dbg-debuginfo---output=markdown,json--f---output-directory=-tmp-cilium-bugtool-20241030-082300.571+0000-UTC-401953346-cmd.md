markdown output at /tmp/cilium-bugtool-20241030-082300.571+0000-UTC-401953346/cmd/cilium-debuginfo-20241030-082331.801+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082300.571+0000-UTC-401953346/cmd/cilium-debuginfo-20241030-082331.801+0000-UTC.json
