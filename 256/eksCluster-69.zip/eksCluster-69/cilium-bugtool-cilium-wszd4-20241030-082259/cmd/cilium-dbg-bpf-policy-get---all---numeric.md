Endpoint ID: 721
Path: /sys/fs/bpf/tc/globals/cilium_policy_00721

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1218
Path: /sys/fs/bpf/tc/globals/cilium_policy_01218

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11646295   115330    0        
Allow    Ingress     1          ANY          NONE         disabled    9912451    104298    0        
Allow    Egress      0          ANY          NONE         disabled    12385711   122608    0        


Endpoint ID: 1655
Path: /sys/fs/bpf/tc/globals/cilium_policy_01655

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    150078   1725      0        
Allow    Egress      0          ANY          NONE         disabled    18477    203       0        


Endpoint ID: 1886
Path: /sys/fs/bpf/tc/globals/cilium_policy_01886

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    151247   1738      0        
Allow    Egress      0          ANY          NONE         disabled    18993    210       0        


Endpoint ID: 3325
Path: /sys/fs/bpf/tc/globals/cilium_policy_03325

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1669469   21142     0        
Allow    Ingress     1          ANY          NONE         disabled    22934     269       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


