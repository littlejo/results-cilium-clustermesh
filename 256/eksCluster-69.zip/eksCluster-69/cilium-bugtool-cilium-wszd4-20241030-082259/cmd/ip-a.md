1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:06:a6:4f:2b:31 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.210.245/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3355sec preferred_lft 3355sec
    inet6 fe80::806:a6ff:fe4f:2b31/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:bf:68:b9:cf:7f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.226.126/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8bf:68ff:feb9:cf7f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:b8:b9:9e:a0:3d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f8b8:b9ff:fe9e:a03d/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:38:e1:bc:bf:06 brd ff:ff:ff:ff:ff:ff
    inet 10.69.0.34/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d438:e1ff:febc:bf06/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 62:ed:6d:4a:2a:2d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::60ed:6dff:fe4a:2a2d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:c1:11:7f:a5:95 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::20c1:11ff:fe7f:a595/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc41d16b70cc5d@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:8a:ff:39:e7:cc brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::ec8a:ffff:fe39:e7cc/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc13c83c843977@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:c2:65:14:c0:d3 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ccc2:65ff:fe14:c0d3/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc2f9cdb56ad8f@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:31:d8:4b:df:c6 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7c31:d8ff:fe4b:dfc6/64 scope link 
       valid_lft forever preferred_lft forever
