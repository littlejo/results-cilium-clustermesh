REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36954     2920690     677    bpf_overlay.c
Interface                 INGRESS     644340    132109779   1132   bpf_host.c
Success                   EGRESS      16539     1301301     1694   bpf_host.c
Success                   EGRESS      270952    34269053    1308   bpf_lxc.c
Success                   EGRESS      37023     2931134     53     encap.h
Success                   INGRESS     313554    35259988    86     l3.h
Success                   INGRESS     334620    36923423    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
