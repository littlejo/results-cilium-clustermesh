{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:12.292Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.210.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:12.293Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.226.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:12.293Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:15.679Z",
  "value": "id=1886  sec_id=2295539 flags=0x0000 ifindex=12  mac=9A:97:BB:8C:55:64 nodemac=EE:8A:FF:39:E7:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:18.918Z",
  "value": "id=3325  sec_id=4     flags=0x0000 ifindex=10  mac=A6:1A:73:0E:9E:34 nodemac=22:C1:11:7F:A5:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:18.943Z",
  "value": "id=1655  sec_id=2295539 flags=0x0000 ifindex=14  mac=52:EA:9F:33:EE:18 nodemac=CE:C2:65:14:C0:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:19.018Z",
  "value": "id=1886  sec_id=2295539 flags=0x0000 ifindex=12  mac=9A:97:BB:8C:55:64 nodemac=EE:8A:FF:39:E7:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:19.112Z",
  "value": "id=3325  sec_id=4     flags=0x0000 ifindex=10  mac=A6:1A:73:0E:9E:34 nodemac=22:C1:11:7F:A5:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:19.186Z",
  "value": "id=1655  sec_id=2295539 flags=0x0000 ifindex=14  mac=52:EA:9F:33:EE:18 nodemac=CE:C2:65:14:C0:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:09.663Z",
  "value": "id=1886  sec_id=2295539 flags=0x0000 ifindex=12  mac=9A:97:BB:8C:55:64 nodemac=EE:8A:FF:39:E7:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:09.664Z",
  "value": "id=1655  sec_id=2295539 flags=0x0000 ifindex=14  mac=52:EA:9F:33:EE:18 nodemac=CE:C2:65:14:C0:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:09.664Z",
  "value": "id=3325  sec_id=4     flags=0x0000 ifindex=10  mac=A6:1A:73:0E:9E:34 nodemac=22:C1:11:7F:A5:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:09.698Z",
  "value": "id=1293  sec_id=2297523 flags=0x0000 ifindex=16  mac=42:E2:70:DF:07:F5 nodemac=22:89:C7:28:36:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:10.663Z",
  "value": "id=3325  sec_id=4     flags=0x0000 ifindex=10  mac=A6:1A:73:0E:9E:34 nodemac=22:C1:11:7F:A5:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:10.663Z",
  "value": "id=1886  sec_id=2295539 flags=0x0000 ifindex=12  mac=9A:97:BB:8C:55:64 nodemac=EE:8A:FF:39:E7:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:10.663Z",
  "value": "id=1293  sec_id=2297523 flags=0x0000 ifindex=16  mac=42:E2:70:DF:07:F5 nodemac=22:89:C7:28:36:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:10.663Z",
  "value": "id=1655  sec_id=2295539 flags=0x0000 ifindex=14  mac=52:EA:9F:33:EE:18 nodemac=CE:C2:65:14:C0:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.237Z",
  "value": "id=1218  sec_id=2297523 flags=0x0000 ifindex=18  mac=66:D1:1C:A6:2E:1F nodemac=7E:31:D8:4B:DF:C6"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.69.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.682Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.803Z",
  "value": "id=1218  sec_id=2297523 flags=0x0000 ifindex=18  mac=66:D1:1C:A6:2E:1F nodemac=7E:31:D8:4B:DF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.805Z",
  "value": "id=1886  sec_id=2295539 flags=0x0000 ifindex=12  mac=9A:97:BB:8C:55:64 nodemac=EE:8A:FF:39:E7:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.806Z",
  "value": "id=1655  sec_id=2295539 flags=0x0000 ifindex=14  mac=52:EA:9F:33:EE:18 nodemac=CE:C2:65:14:C0:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.807Z",
  "value": "id=3325  sec_id=4     flags=0x0000 ifindex=10  mac=A6:1A:73:0E:9E:34 nodemac=22:C1:11:7F:A5:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.801Z",
  "value": "id=1886  sec_id=2295539 flags=0x0000 ifindex=12  mac=9A:97:BB:8C:55:64 nodemac=EE:8A:FF:39:E7:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.802Z",
  "value": "id=1655  sec_id=2295539 flags=0x0000 ifindex=14  mac=52:EA:9F:33:EE:18 nodemac=CE:C2:65:14:C0:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.811Z",
  "value": "id=1218  sec_id=2297523 flags=0x0000 ifindex=18  mac=66:D1:1C:A6:2E:1F nodemac=7E:31:D8:4B:DF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.812Z",
  "value": "id=3325  sec_id=4     flags=0x0000 ifindex=10  mac=A6:1A:73:0E:9E:34 nodemac=22:C1:11:7F:A5:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.801Z",
  "value": "id=3325  sec_id=4     flags=0x0000 ifindex=10  mac=A6:1A:73:0E:9E:34 nodemac=22:C1:11:7F:A5:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.801Z",
  "value": "id=1886  sec_id=2295539 flags=0x0000 ifindex=12  mac=9A:97:BB:8C:55:64 nodemac=EE:8A:FF:39:E7:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.801Z",
  "value": "id=1655  sec_id=2295539 flags=0x0000 ifindex=14  mac=52:EA:9F:33:EE:18 nodemac=CE:C2:65:14:C0:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.801Z",
  "value": "id=1218  sec_id=2297523 flags=0x0000 ifindex=18  mac=66:D1:1C:A6:2E:1F nodemac=7E:31:D8:4B:DF:C6"
}

