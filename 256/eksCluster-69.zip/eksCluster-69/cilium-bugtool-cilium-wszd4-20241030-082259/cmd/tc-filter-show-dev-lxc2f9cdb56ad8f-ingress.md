filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc2f9cdb56ad8f direct-action not_in_hw id 635 tag 79f1d10bce01103a jited 
