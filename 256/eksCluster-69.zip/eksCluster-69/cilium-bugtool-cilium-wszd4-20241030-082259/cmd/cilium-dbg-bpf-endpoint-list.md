IP ADDRESS         LOCAL ENDPOINT INFO
10.69.0.34:0       (localhost)                                                                                        
10.69.0.100:0      id=1886  sec_id=2295539 flags=0x0000 ifindex=12  mac=9A:97:BB:8C:55:64 nodemac=EE:8A:FF:39:E7:CC   
10.69.0.74:0       id=3325  sec_id=4     flags=0x0000 ifindex=10  mac=A6:1A:73:0E:9E:34 nodemac=22:C1:11:7F:A5:95     
172.31.210.245:0   (localhost)                                                                                        
10.69.0.62:0       id=1655  sec_id=2295539 flags=0x0000 ifindex=14  mac=52:EA:9F:33:EE:18 nodemac=CE:C2:65:14:C0:D3   
10.69.0.65:0       id=1218  sec_id=2297523 flags=0x0000 ifindex=18  mac=66:D1:1C:A6:2E:1F nodemac=7E:31:D8:4B:DF:C6   
172.31.226.126:0   (localhost)                                                                                        
