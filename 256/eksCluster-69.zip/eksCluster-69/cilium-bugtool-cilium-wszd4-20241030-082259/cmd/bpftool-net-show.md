xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 582
ens6(5) clsact/ingress cil_from_netdev-ens6 id 590
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 571
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 567
cilium_host(7) clsact/egress cil_from_host-cilium_host id 570
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 497
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 498
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 536
lxc41d16b70cc5d(12) clsact/ingress cil_from_container-lxc41d16b70cc5d id 530
lxc13c83c843977(14) clsact/ingress cil_from_container-lxc13c83c843977 id 556
lxc2f9cdb56ad8f(18) clsact/ingress cil_from_container-lxc2f9cdb56ad8f id 635

flow_dissector:

netfilter:

