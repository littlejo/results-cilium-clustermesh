top - 08:23:00 up 34 min,  0 users,  load average: 1.09, 0.56, 0.32
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 17.2 us, 31.0 sy,  0.0 ni, 51.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4469.7 free,   1199.3 used,   2145.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6429.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 383220  78648 S  13.3   4.8   0:57.78 cilium-+
    689 root      20   0 1240432  16564  11356 S   6.7   0.2   0:00.03 cilium-+
    419 root      20   0 1229744   8252   3836 S   0.0   0.1   0:01.20 cilium-+
    656 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    657 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    684 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    731 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    749 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
    754 root      20   0 1539912   8420   6344 S   0.0   0.1   0:00.00 runc:[2+
    759 root      20   0 1616264   8776   6268 S   0.0   0.1   0:00.00 runc:[2+
