alloc: 123.89MB (129905648 bytes)
total-alloc: 2.27GB (2438765720 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63700220
frees: 62827928
heap-alloc: 123.89MB (129905648 bytes)
heap-sys: 247.57MB (259596288 bytes)
heap-idle: 67.71MB (71000064 bytes)
heap-in-use: 179.86MB (188596224 bytes)
heap-released: 3.09MB (3244032 bytes)
heap-objects: 872292
stack-in-use: 64.41MB (67534848 bytes)
stack-sys: 64.41MB (67534848 bytes)
stack-mspan-inuse: 2.82MB (2954400 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 967.57KB (990793 bytes)
gc-sys: 5.99MB (6280608 bytes)
next-gc: when heap-alloc >= 210.87MB (221113592 bytes)
last-gc: 2024-10-30 08:23:22.493380935 +0000 UTC
gc-pause-total: 10.012722ms
gc-pause: 100740
gc-pause-end: 1730276602493380935
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.00038718441959447505
enable-gc: true
debug-gc: false
