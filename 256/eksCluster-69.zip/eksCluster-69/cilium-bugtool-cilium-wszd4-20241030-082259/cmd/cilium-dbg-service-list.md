ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.185.0:443 (active)      
                                          2 => 172.31.217.38:443 (active)     
2    10.100.117.140:443    ClusterIP      1 => 172.31.210.245:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.69.0.100:53 (active)        
                                          2 => 10.69.0.62:53 (active)         
4    10.100.0.10:9153      ClusterIP      1 => 10.69.0.100:9153 (active)      
                                          2 => 10.69.0.62:9153 (active)       
5    10.100.245.102:2379   ClusterIP      1 => 10.69.0.65:2379 (active)       
