[
  {
    "containers": [
      {
        "cgroup-id": 9184,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5aa5fde1_bb6e_48bb_b5d0_b96a4cf6ed10.slice/cri-containerd-90a2085c689c282a37aab121f31cd3dc67798c0f38d32dad6f416fbc85bd3e34.scope"
      },
      {
        "cgroup-id": 9352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5aa5fde1_bb6e_48bb_b5d0_b96a4cf6ed10.slice/cri-containerd-81b0f1cffb7383eb729774c0eb2e02ee8db0a87c7b121bef2050d3f8deed2b78.scope"
      },
      {
        "cgroup-id": 9268,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5aa5fde1_bb6e_48bb_b5d0_b96a4cf6ed10.slice/cri-containerd-7c73539d8505701cf44048c23a90b4f278f700ba21e273c6657180b6da00a23f.scope"
      }
    ],
    "ips": [
      "10.69.0.65"
    ],
    "name": "clustermesh-apiserver-5b9987d7c9-hw6sb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7624,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod51e4fcf5_4886_43d8_94d5_8eff0c7800f8.slice/cri-containerd-62be9921e14251d590bc800b1dc559e35d5606407567c5c518d6cf14d61ba9e3.scope"
      }
    ],
    "ips": [
      "10.69.0.100"
    ],
    "name": "coredns-cc6ccd49c-qj7zs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5d76e88d_fcb9_4b19_962d_db805952ddcb.slice/cri-containerd-02c15a32a3c55bcf16cc9e7c2e53946cc047ce26f552cd719c88f7760a8ad219.scope"
      }
    ],
    "ips": [
      "10.69.0.62"
    ],
    "name": "coredns-cc6ccd49c-mwt9r",
    "namespace": "kube-system"
  }
]

