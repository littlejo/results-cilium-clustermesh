KEY             VALUE
AgentLiveness   2085855237654
UTimeOffset     3379442433593750
