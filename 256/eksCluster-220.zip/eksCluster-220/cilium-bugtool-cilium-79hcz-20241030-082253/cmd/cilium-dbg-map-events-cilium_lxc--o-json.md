{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:21.050Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.142.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:21.050Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.178.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:21.050Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:25.607Z",
  "value": "id=147   sec_id=4     flags=0x0000 ifindex=10  mac=56:07:1E:8F:C2:FE nodemac=EE:B3:F5:0E:70:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:25.612Z",
  "value": "id=230   sec_id=7245078 flags=0x0000 ifindex=12  mac=92:9B:54:34:4F:77 nodemac=56:7D:68:05:37:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:25.651Z",
  "value": "id=3315  sec_id=7245078 flags=0x0000 ifindex=14  mac=92:EF:D8:6B:D0:F4 nodemac=46:12:D6:E9:5F:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:25.685Z",
  "value": "id=147   sec_id=4     flags=0x0000 ifindex=10  mac=56:07:1E:8F:C2:FE nodemac=EE:B3:F5:0E:70:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:08.672Z",
  "value": "id=147   sec_id=4     flags=0x0000 ifindex=10  mac=56:07:1E:8F:C2:FE nodemac=EE:B3:F5:0E:70:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:08.673Z",
  "value": "id=230   sec_id=7245078 flags=0x0000 ifindex=12  mac=92:9B:54:34:4F:77 nodemac=56:7D:68:05:37:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:08.673Z",
  "value": "id=3315  sec_id=7245078 flags=0x0000 ifindex=14  mac=92:EF:D8:6B:D0:F4 nodemac=46:12:D6:E9:5F:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:08.706Z",
  "value": "id=1149  sec_id=7249404 flags=0x0000 ifindex=16  mac=DA:8C:2E:44:D9:51 nodemac=26:21:D4:A4:CB:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:09.672Z",
  "value": "id=1149  sec_id=7249404 flags=0x0000 ifindex=16  mac=DA:8C:2E:44:D9:51 nodemac=26:21:D4:A4:CB:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:09.672Z",
  "value": "id=147   sec_id=4     flags=0x0000 ifindex=10  mac=56:07:1E:8F:C2:FE nodemac=EE:B3:F5:0E:70:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:09.672Z",
  "value": "id=230   sec_id=7245078 flags=0x0000 ifindex=12  mac=92:9B:54:34:4F:77 nodemac=56:7D:68:05:37:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:09.673Z",
  "value": "id=3315  sec_id=7245078 flags=0x0000 ifindex=14  mac=92:EF:D8:6B:D0:F4 nodemac=46:12:D6:E9:5F:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:36.227Z",
  "value": "id=713   sec_id=7249404 flags=0x0000 ifindex=18  mac=FA:C8:BF:46:60:D6 nodemac=72:FA:16:41:40:69"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.220.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.875Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.844Z",
  "value": "id=230   sec_id=7245078 flags=0x0000 ifindex=12  mac=92:9B:54:34:4F:77 nodemac=56:7D:68:05:37:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.845Z",
  "value": "id=3315  sec_id=7245078 flags=0x0000 ifindex=14  mac=92:EF:D8:6B:D0:F4 nodemac=46:12:D6:E9:5F:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.845Z",
  "value": "id=713   sec_id=7249404 flags=0x0000 ifindex=18  mac=FA:C8:BF:46:60:D6 nodemac=72:FA:16:41:40:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.846Z",
  "value": "id=147   sec_id=4     flags=0x0000 ifindex=10  mac=56:07:1E:8F:C2:FE nodemac=EE:B3:F5:0E:70:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:49.845Z",
  "value": "id=230   sec_id=7245078 flags=0x0000 ifindex=12  mac=92:9B:54:34:4F:77 nodemac=56:7D:68:05:37:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:49.845Z",
  "value": "id=147   sec_id=4     flags=0x0000 ifindex=10  mac=56:07:1E:8F:C2:FE nodemac=EE:B3:F5:0E:70:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:49.846Z",
  "value": "id=3315  sec_id=7245078 flags=0x0000 ifindex=14  mac=92:EF:D8:6B:D0:F4 nodemac=46:12:D6:E9:5F:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:49.846Z",
  "value": "id=713   sec_id=7249404 flags=0x0000 ifindex=18  mac=FA:C8:BF:46:60:D6 nodemac=72:FA:16:41:40:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.854Z",
  "value": "id=713   sec_id=7249404 flags=0x0000 ifindex=18  mac=FA:C8:BF:46:60:D6 nodemac=72:FA:16:41:40:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.856Z",
  "value": "id=147   sec_id=4     flags=0x0000 ifindex=10  mac=56:07:1E:8F:C2:FE nodemac=EE:B3:F5:0E:70:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.857Z",
  "value": "id=230   sec_id=7245078 flags=0x0000 ifindex=12  mac=92:9B:54:34:4F:77 nodemac=56:7D:68:05:37:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.857Z",
  "value": "id=3315  sec_id=7245078 flags=0x0000 ifindex=14  mac=92:EF:D8:6B:D0:F4 nodemac=46:12:D6:E9:5F:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.845Z",
  "value": "id=3315  sec_id=7245078 flags=0x0000 ifindex=14  mac=92:EF:D8:6B:D0:F4 nodemac=46:12:D6:E9:5F:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.846Z",
  "value": "id=713   sec_id=7249404 flags=0x0000 ifindex=18  mac=FA:C8:BF:46:60:D6 nodemac=72:FA:16:41:40:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.846Z",
  "value": "id=147   sec_id=4     flags=0x0000 ifindex=10  mac=56:07:1E:8F:C2:FE nodemac=EE:B3:F5:0E:70:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.846Z",
  "value": "id=230   sec_id=7245078 flags=0x0000 ifindex=12  mac=92:9B:54:34:4F:77 nodemac=56:7D:68:05:37:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.846Z",
  "value": "id=3315  sec_id=7245078 flags=0x0000 ifindex=14  mac=92:EF:D8:6B:D0:F4 nodemac=46:12:D6:E9:5F:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.847Z",
  "value": "id=713   sec_id=7249404 flags=0x0000 ifindex=18  mac=FA:C8:BF:46:60:D6 nodemac=72:FA:16:41:40:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.847Z",
  "value": "id=230   sec_id=7245078 flags=0x0000 ifindex=12  mac=92:9B:54:34:4F:77 nodemac=56:7D:68:05:37:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.220.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.847Z",
  "value": "id=147   sec_id=4     flags=0x0000 ifindex=10  mac=56:07:1E:8F:C2:FE nodemac=EE:B3:F5:0E:70:C0"
}

