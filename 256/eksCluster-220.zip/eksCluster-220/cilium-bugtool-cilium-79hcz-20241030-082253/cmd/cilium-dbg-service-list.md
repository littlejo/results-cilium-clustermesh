ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.169.118:443 (active)    
                                          2 => 172.31.229.221:443 (active)    
2    10.100.71.240:443     ClusterIP      1 => 172.31.178.150:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.220.0.209:53 (active)       
                                          2 => 10.220.0.173:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.220.0.209:9153 (active)     
                                          2 => 10.220.0.173:9153 (active)     
5    10.100.235.229:2379   ClusterIP      1 => 10.220.0.205:2379 (active)     
