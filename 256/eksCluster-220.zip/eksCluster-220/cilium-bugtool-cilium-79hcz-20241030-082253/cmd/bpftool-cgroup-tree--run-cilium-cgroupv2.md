CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod692851b1_bf0a_407d_a2fe_74d1c90a4530.slice/cri-containerd-9a7e5a2a1fd0eaf4d4160d31c16cd127bf68088670f00831d9bd6f701929b594.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod692851b1_bf0a_407d_a2fe_74d1c90a4530.slice/cri-containerd-22f9d28bb014284a9785e77a73298cfea004cd9c87b0c045f0d664a9c05b194f.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod524ec4ef_66bb_46eb_a1ee_2a7a17d733bf.slice/cri-containerd-9d7d6793ca5bc195713e79d0cca8d096a2d06ddada20646a2d6f5f8abe428c82.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod524ec4ef_66bb_46eb_a1ee_2a7a17d733bf.slice/cri-containerd-fb218f4844b323d50f7cf76fd5018ee6f7744d25d57f5c79fcc7829ed5994fd6.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2b191709_df96_44b5_b67f_1897d873cd14.slice/cri-containerd-9c0326380a8b0ea0fed5eb66386970b850c59e31a6e6febd03f2728ecd710497.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2b191709_df96_44b5_b67f_1897d873cd14.slice/cri-containerd-c2250e227ecf49ce9d52dca050fdde1e5b35dce8eb142b7769ff2b9706dd4bff.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd0883f17_a197_4c15_b7ef_b4fb79a5d0eb.slice/cri-containerd-095f0fe9016b9b14b62d183b8cc4bbe640d8142961cfe76ffedae57f2f10dce4.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd0883f17_a197_4c15_b7ef_b4fb79a5d0eb.slice/cri-containerd-40c1acb9bc48c99fca10696a625ba30317035c77f43987b7790c5c7a6d806ba7.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b6bf51e_1f10_4c34_8c76_05c7c889a84d.slice/cri-containerd-b7c72e59327b28f8f22cf8343d65e7932c8b21159bd71f46e75bff6e8acdf687.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b6bf51e_1f10_4c34_8c76_05c7c889a84d.slice/cri-containerd-fdc3b256312bf6217eff8a503727ef909642f983e7e619410a2cb9dc18160c2e.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41263a2a_07d6_45f2_a8f2_70e0777e1e5a.slice/cri-containerd-ba74b2afa97385dba77e165bfbca4ec304e9a41ad3c1a5bb9160dc1a0ed1343b.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41263a2a_07d6_45f2_a8f2_70e0777e1e5a.slice/cri-containerd-a36a3c5dba4bc93defc1f2118c1792956515c90d8107e6c18ba57e41c92b370c.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41263a2a_07d6_45f2_a8f2_70e0777e1e5a.slice/cri-containerd-4a9a6cec2da87023fc8352667f04ac06b2f1f03c099e875bbd79da5ace125ab4.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41263a2a_07d6_45f2_a8f2_70e0777e1e5a.slice/cri-containerd-045a345c7bb173db886a839d98cedf16e8968c7b0572e4652980c1f7c8d1c960.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod523582b4_daeb_4593_8209_3f738d2c7c77.slice/cri-containerd-53f85dd622aa796da4b4773b290e83d81c9acb3c50a180ee1ae23e4aa8582a03.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod523582b4_daeb_4593_8209_3f738d2c7c77.slice/cri-containerd-58931c36659a3e14338f01ba193753dc67c6b67a5d8df1b5902f2824aa7695d5.scope
    95       cgroup_device   multi                                          
