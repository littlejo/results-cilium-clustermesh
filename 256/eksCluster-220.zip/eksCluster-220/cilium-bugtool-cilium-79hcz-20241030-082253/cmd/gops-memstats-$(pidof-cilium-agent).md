alloc: 170.17MB (178433000 bytes)
total-alloc: 2.38GB (2552054792 bytes)
sys: 332.96MB (349131108 bytes)
lookups: 0
mallocs: 65016983
frees: 63034345
heap-alloc: 170.17MB (178433000 bytes)
heap-sys: 252.07MB (264314880 bytes)
heap-idle: 55.43MB (58122240 bytes)
heap-in-use: 196.64MB (206192640 bytes)
heap-released: 1.62MB (1695744 bytes)
heap-objects: 1982638
stack-in-use: 67.50MB (70778880 bytes)
stack-sys: 67.50MB (70778880 bytes)
stack-mspan-inuse: 3.37MB (3536480 bytes)
stack-mspan-sys: 3.91MB (4096320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.06MB (1114929 bytes)
gc-sys: 6.39MB (6702760 bytes)
next-gc: when heap-alloc >= 213.39MB (223756248 bytes)
last-gc: 2024-10-30 08:22:55.92099545 +0000 UTC
gc-pause-total: 8.486339ms
gc-pause: 84407
gc-pause-end: 1730276575920995450
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005935964533984541
enable-gc: true
debug-gc: false
