IP ADDRESS         LOCAL ENDPOINT INFO
10.220.0.173:0     id=3315  sec_id=7245078 flags=0x0000 ifindex=14  mac=92:EF:D8:6B:D0:F4 nodemac=46:12:D6:E9:5F:7F   
172.31.178.150:0   (localhost)                                                                                        
10.220.0.205:0     id=713   sec_id=7249404 flags=0x0000 ifindex=18  mac=FA:C8:BF:46:60:D6 nodemac=72:FA:16:41:40:69   
172.31.142.77:0    (localhost)                                                                                        
10.220.0.209:0     id=230   sec_id=7245078 flags=0x0000 ifindex=12  mac=92:9B:54:34:4F:77 nodemac=56:7D:68:05:37:F2   
10.220.0.35:0      id=147   sec_id=4     flags=0x0000 ifindex=10  mac=56:07:1E:8F:C2:FE nodemac=EE:B3:F5:0E:70:C0     
10.220.0.60:0      (localhost)                                                                                        
