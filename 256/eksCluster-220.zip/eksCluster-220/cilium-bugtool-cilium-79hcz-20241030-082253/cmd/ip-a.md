1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:4a:22:b6:e4:bd brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.178.150/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1870sec preferred_lft 1870sec
    inet6 fe80::44a:22ff:feb6:e4bd/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:cd:e0:af:5e:27 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.142.77/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4cd:e0ff:feaf:5e27/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:3a:c4:f1:a2:8e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::803a:c4ff:fef1:a28e/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:26:fe:39:cd:65 brd ff:ff:ff:ff:ff:ff
    inet 10.220.0.60/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::ac26:feff:fe39:cd65/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ba:4a:36:76:c6:0d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b84a:36ff:fe76:c60d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:b3:f5:0e:70:c0 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::ecb3:f5ff:fe0e:70c0/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc8c184e86334a@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:7d:68:05:37:f2 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::547d:68ff:fe05:37f2/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcf5969caa50a5@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:12:d6:e9:5f:7f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::4412:d6ff:fee9:5f7f/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb86399b652d4@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:fa:16:41:40:69 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::70fa:16ff:fe41:4069/64 scope link 
       valid_lft forever preferred_lft forever
