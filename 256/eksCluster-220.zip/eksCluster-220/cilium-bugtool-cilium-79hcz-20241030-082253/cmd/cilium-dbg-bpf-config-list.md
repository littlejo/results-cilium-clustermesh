KEY             VALUE
AgentLiveness   1770612790544
UTimeOffset     3379443037109375
