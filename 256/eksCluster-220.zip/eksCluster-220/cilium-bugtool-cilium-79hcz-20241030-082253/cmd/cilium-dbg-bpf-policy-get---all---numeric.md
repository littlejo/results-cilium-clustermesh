Endpoint ID: 147
Path: /sys/fs/bpf/tc/globals/cilium_policy_00147

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1649360   20840     0        
Allow    Ingress     1          ANY          NONE         disabled    18674     221       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 230
Path: /sys/fs/bpf/tc/globals/cilium_policy_00230

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    114568   1314      0        
Allow    Egress      0          ANY          NONE         disabled    15682    168       0        


Endpoint ID: 713
Path: /sys/fs/bpf/tc/globals/cilium_policy_00713

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11618122   115109    0        
Allow    Ingress     1          ANY          NONE         disabled    10779823   109936    0        
Allow    Egress      0          ANY          NONE         disabled    11965947   118404    0        


Endpoint ID: 1797
Path: /sys/fs/bpf/tc/globals/cilium_policy_01797

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3315
Path: /sys/fs/bpf/tc/globals/cilium_policy_03315

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113974   1305      0        
Allow    Egress      0          ANY          NONE         disabled    17147    187       0        


