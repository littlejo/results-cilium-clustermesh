 08:22:54 up 28 min,  0 users,  load average: 0.70, 0.33, 0.22
