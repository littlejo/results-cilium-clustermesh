filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf5969caa50a5 direct-action not_in_hw id 549 tag af64e1b1f32c133a jited 
