xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 555
ens6(5) clsact/ingress cil_from_netdev-ens6 id 559
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 546
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 536
cilium_host(7) clsact/egress cil_from_host-cilium_host id 534
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 572
lxc8c184e86334a(12) clsact/ingress cil_from_container-lxc8c184e86334a id 510
lxcf5969caa50a5(14) clsact/ingress cil_from_container-lxcf5969caa50a5 id 549
lxcb86399b652d4(18) clsact/ingress cil_from_container-lxcb86399b652d4 id 645

flow_dissector:

netfilter:

