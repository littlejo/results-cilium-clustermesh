[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod692851b1_bf0a_407d_a2fe_74d1c90a4530.slice/cri-containerd-9a7e5a2a1fd0eaf4d4160d31c16cd127bf68088670f00831d9bd6f701929b594.scope"
      }
    ],
    "ips": [
      "10.220.0.209"
    ],
    "name": "coredns-cc6ccd49c-pfsdq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2b191709_df96_44b5_b67f_1897d873cd14.slice/cri-containerd-9c0326380a8b0ea0fed5eb66386970b850c59e31a6e6febd03f2728ecd710497.scope"
      }
    ],
    "ips": [
      "10.220.0.173"
    ],
    "name": "coredns-cc6ccd49c-4zhd4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41263a2a_07d6_45f2_a8f2_70e0777e1e5a.slice/cri-containerd-a36a3c5dba4bc93defc1f2118c1792956515c90d8107e6c18ba57e41c92b370c.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41263a2a_07d6_45f2_a8f2_70e0777e1e5a.slice/cri-containerd-045a345c7bb173db886a839d98cedf16e8968c7b0572e4652980c1f7c8d1c960.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41263a2a_07d6_45f2_a8f2_70e0777e1e5a.slice/cri-containerd-ba74b2afa97385dba77e165bfbca4ec304e9a41ad3c1a5bb9160dc1a0ed1343b.scope"
      }
    ],
    "ips": [
      "10.220.0.205"
    ],
    "name": "clustermesh-apiserver-55bcc4cb75-xsh46",
    "namespace": "kube-system"
  }
]

