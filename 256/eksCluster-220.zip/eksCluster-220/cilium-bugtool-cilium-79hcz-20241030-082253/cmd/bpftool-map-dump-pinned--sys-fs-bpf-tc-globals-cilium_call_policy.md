key: 93 00 00 00  value: 42 02 00 00
key: e6 00 00 00  value: 12 02 00 00
key: c9 02 00 00  value: 83 02 00 00
key: f3 0c 00 00  value: 21 02 00 00
Found 4 elements
