Endpoint ID: 109
Path: /sys/fs/bpf/tc/globals/cilium_policy_00109

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1659066   20969     0        
Allow    Ingress     1          ANY          NONE         disabled    17530     207       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 649
Path: /sys/fs/bpf/tc/globals/cilium_policy_00649

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    111508   1282      0        
Allow    Egress      0          ANY          NONE         disabled    15633    166       0        


Endpoint ID: 3201
Path: /sys/fs/bpf/tc/globals/cilium_policy_03201

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    110782   1271      0        
Allow    Egress      0          ANY          NONE         disabled    17211    187       0        


Endpoint ID: 3747
Path: /sys/fs/bpf/tc/globals/cilium_policy_03747

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 4075
Path: /sys/fs/bpf/tc/globals/cilium_policy_04075

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11328169   110377    0        
Allow    Ingress     1          ANY          NONE         disabled    9403068    97685     0        
Allow    Egress      0          ANY          NONE         disabled    10629187   106099    0        


