ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.140.185:443 (active)   
                                          2 => 172.31.244.198:443 (active)   
2    10.100.36.219:443     ClusterIP      1 => 172.31.249.38:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.255.0.130:53 (active)      
                                          2 => 10.255.0.110:53 (active)      
4    10.100.0.10:9153      ClusterIP      1 => 10.255.0.130:9153 (active)    
                                          2 => 10.255.0.110:9153 (active)    
5    10.100.222.115:2379   ClusterIP      1 => 10.255.0.229:2379 (active)    
