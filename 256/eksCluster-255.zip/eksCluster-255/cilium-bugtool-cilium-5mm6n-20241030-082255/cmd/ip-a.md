1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:f1:67:76:e7:15 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.249.38/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1982sec preferred_lft 1982sec
    inet6 fe80::8f1:67ff:fe76:e715/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:af:15:7a:31:e7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.240.189/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8af:15ff:fe7a:31e7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:ed:61:2e:b2:fc brd ff:ff:ff:ff:ff:ff
    inet6 fe80::64ed:61ff:fe2e:b2fc/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:35:60:85:dc:7b brd ff:ff:ff:ff:ff:ff
    inet 10.255.0.241/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::bc35:60ff:fe85:dc7b/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 02:71:45:74:8a:9d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::71:45ff:fe74:8a9d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:c8:01:2c:75:46 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::cc8:1ff:fe2c:7546/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc8449a182c476@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:a3:c1:dc:56:85 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::d0a3:c1ff:fedc:5685/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc370c03782111@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:1d:f6:d0:04:d6 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d81d:f6ff:fed0:4d6/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc3c5c1ae97750@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:da:12:51:a2:b9 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::acda:12ff:fe51:a2b9/64 scope link 
       valid_lft forever preferred_lft forever
