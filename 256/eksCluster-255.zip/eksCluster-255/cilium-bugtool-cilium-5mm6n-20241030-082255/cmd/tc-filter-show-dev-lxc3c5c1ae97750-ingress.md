filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc3c5c1ae97750 direct-action not_in_hw id 641 tag 70a73979493d4263 jited 
