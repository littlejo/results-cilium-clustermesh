[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56bd55b3_22e6_4587_ac86_c2f10822def3.slice/cri-containerd-942dc6212f56bc1a6933851f371e0b414bf477547b01d93962965e0fa5b95d8c.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56bd55b3_22e6_4587_ac86_c2f10822def3.slice/cri-containerd-db86e844a599e54949af53bf251a891348393ce783c4a36942e2b0c51eab10fa.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56bd55b3_22e6_4587_ac86_c2f10822def3.slice/cri-containerd-623a583385a19c75dfbd178b0b433640d1a481dd2071ce16a54f634dc8fd35d4.scope"
      }
    ],
    "ips": [
      "10.255.0.229"
    ],
    "name": "clustermesh-apiserver-5d85478dc5-f8rzs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7614,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod266fb9d0_4433_446c_a384_754db68c2043.slice/cri-containerd-ec9a8bd7ebc6ae56da082de6aef899ff9517006af9e0054d73f07a75583f1261.scope"
      }
    ],
    "ips": [
      "10.255.0.130"
    ],
    "name": "coredns-cc6ccd49c-k5zzk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podede0bfe3_06d4_4730_8139_940c5f8395f7.slice/cri-containerd-852177a7e22cca2a9c14cb3f7f24496bcfc3cc75b7455ca14a585a0e3231aa30.scope"
      }
    ],
    "ips": [
      "10.255.0.110"
    ],
    "name": "coredns-cc6ccd49c-tkqg8",
    "namespace": "kube-system"
  }
]

