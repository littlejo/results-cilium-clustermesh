{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:07.289Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.240.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:07.289Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.249.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:07.289Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.331Z",
  "value": "id=3201  sec_id=8402338 flags=0x0000 ifindex=12  mac=BA:28:73:BB:23:E4 nodemac=D2:A3:C1:DC:56:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:13.271Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=B6:F2:E7:E1:8B:25 nodemac=0E:C8:01:2C:75:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:13.278Z",
  "value": "id=649   sec_id=8402338 flags=0x0000 ifindex=14  mac=76:67:50:0F:CC:8D nodemac=DA:1D:F6:D0:04:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:13.317Z",
  "value": "id=3201  sec_id=8402338 flags=0x0000 ifindex=12  mac=BA:28:73:BB:23:E4 nodemac=D2:A3:C1:DC:56:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:13.360Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=B6:F2:E7:E1:8B:25 nodemac=0E:C8:01:2C:75:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:13.393Z",
  "value": "id=649   sec_id=8402338 flags=0x0000 ifindex=14  mac=76:67:50:0F:CC:8D nodemac=DA:1D:F6:D0:04:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:13.476Z",
  "value": "id=3201  sec_id=8402338 flags=0x0000 ifindex=12  mac=BA:28:73:BB:23:E4 nodemac=D2:A3:C1:DC:56:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:13.476Z",
  "value": "id=649   sec_id=8402338 flags=0x0000 ifindex=14  mac=76:67:50:0F:CC:8D nodemac=DA:1D:F6:D0:04:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:13.476Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=B6:F2:E7:E1:8B:25 nodemac=0E:C8:01:2C:75:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:13.504Z",
  "value": "id=843   sec_id=8398258 flags=0x0000 ifindex=16  mac=92:B6:00:F9:5A:A5 nodemac=2E:E5:5B:11:DE:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:14.476Z",
  "value": "id=843   sec_id=8398258 flags=0x0000 ifindex=16  mac=92:B6:00:F9:5A:A5 nodemac=2E:E5:5B:11:DE:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:14.476Z",
  "value": "id=3201  sec_id=8402338 flags=0x0000 ifindex=12  mac=BA:28:73:BB:23:E4 nodemac=D2:A3:C1:DC:56:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:14.476Z",
  "value": "id=649   sec_id=8402338 flags=0x0000 ifindex=14  mac=76:67:50:0F:CC:8D nodemac=DA:1D:F6:D0:04:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:14.476Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=B6:F2:E7:E1:8B:25 nodemac=0E:C8:01:2C:75:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:33.540Z",
  "value": "id=4075  sec_id=8398258 flags=0x0000 ifindex=18  mac=5E:C3:AA:76:A1:33 nodemac=AE:DA:12:51:A2:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.795Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=B6:F2:E7:E1:8B:25 nodemac=0E:C8:01:2C:75:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.796Z",
  "value": "id=843   sec_id=8398258 flags=0x0000 ifindex=16  mac=92:B6:00:F9:5A:A5 nodemac=2E:E5:5B:11:DE:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.797Z",
  "value": "id=4075  sec_id=8398258 flags=0x0000 ifindex=18  mac=5E:C3:AA:76:A1:33 nodemac=AE:DA:12:51:A2:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.798Z",
  "value": "id=3201  sec_id=8402338 flags=0x0000 ifindex=12  mac=BA:28:73:BB:23:E4 nodemac=D2:A3:C1:DC:56:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.798Z",
  "value": "id=649   sec_id=8402338 flags=0x0000 ifindex=14  mac=76:67:50:0F:CC:8D nodemac=DA:1D:F6:D0:04:D6"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.255.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.466Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.795Z",
  "value": "id=649   sec_id=8402338 flags=0x0000 ifindex=14  mac=76:67:50:0F:CC:8D nodemac=DA:1D:F6:D0:04:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.796Z",
  "value": "id=3201  sec_id=8402338 flags=0x0000 ifindex=12  mac=BA:28:73:BB:23:E4 nodemac=D2:A3:C1:DC:56:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.796Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=B6:F2:E7:E1:8B:25 nodemac=0E:C8:01:2C:75:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.797Z",
  "value": "id=4075  sec_id=8398258 flags=0x0000 ifindex=18  mac=5E:C3:AA:76:A1:33 nodemac=AE:DA:12:51:A2:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.795Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=B6:F2:E7:E1:8B:25 nodemac=0E:C8:01:2C:75:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.796Z",
  "value": "id=4075  sec_id=8398258 flags=0x0000 ifindex=18  mac=5E:C3:AA:76:A1:33 nodemac=AE:DA:12:51:A2:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.797Z",
  "value": "id=3201  sec_id=8402338 flags=0x0000 ifindex=12  mac=BA:28:73:BB:23:E4 nodemac=D2:A3:C1:DC:56:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.797Z",
  "value": "id=649   sec_id=8402338 flags=0x0000 ifindex=14  mac=76:67:50:0F:CC:8D nodemac=DA:1D:F6:D0:04:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.795Z",
  "value": "id=4075  sec_id=8398258 flags=0x0000 ifindex=18  mac=5E:C3:AA:76:A1:33 nodemac=AE:DA:12:51:A2:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.796Z",
  "value": "id=3201  sec_id=8402338 flags=0x0000 ifindex=12  mac=BA:28:73:BB:23:E4 nodemac=D2:A3:C1:DC:56:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.797Z",
  "value": "id=649   sec_id=8402338 flags=0x0000 ifindex=14  mac=76:67:50:0F:CC:8D nodemac=DA:1D:F6:D0:04:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.797Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=B6:F2:E7:E1:8B:25 nodemac=0E:C8:01:2C:75:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.796Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=B6:F2:E7:E1:8B:25 nodemac=0E:C8:01:2C:75:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.797Z",
  "value": "id=4075  sec_id=8398258 flags=0x0000 ifindex=18  mac=5E:C3:AA:76:A1:33 nodemac=AE:DA:12:51:A2:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.798Z",
  "value": "id=3201  sec_id=8402338 flags=0x0000 ifindex=12  mac=BA:28:73:BB:23:E4 nodemac=D2:A3:C1:DC:56:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.798Z",
  "value": "id=649   sec_id=8402338 flags=0x0000 ifindex=14  mac=76:67:50:0F:CC:8D nodemac=DA:1D:F6:D0:04:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.796Z",
  "value": "id=3201  sec_id=8402338 flags=0x0000 ifindex=12  mac=BA:28:73:BB:23:E4 nodemac=D2:A3:C1:DC:56:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.797Z",
  "value": "id=4075  sec_id=8398258 flags=0x0000 ifindex=18  mac=5E:C3:AA:76:A1:33 nodemac=AE:DA:12:51:A2:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.797Z",
  "value": "id=649   sec_id=8402338 flags=0x0000 ifindex=14  mac=76:67:50:0F:CC:8D nodemac=DA:1D:F6:D0:04:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.797Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=B6:F2:E7:E1:8B:25 nodemac=0E:C8:01:2C:75:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.798Z",
  "value": "id=3201  sec_id=8402338 flags=0x0000 ifindex=12  mac=BA:28:73:BB:23:E4 nodemac=D2:A3:C1:DC:56:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.798Z",
  "value": "id=4075  sec_id=8398258 flags=0x0000 ifindex=18  mac=5E:C3:AA:76:A1:33 nodemac=AE:DA:12:51:A2:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.798Z",
  "value": "id=649   sec_id=8402338 flags=0x0000 ifindex=14  mac=76:67:50:0F:CC:8D nodemac=DA:1D:F6:D0:04:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.255.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.798Z",
  "value": "id=109   sec_id=4     flags=0x0000 ifindex=10  mac=B6:F2:E7:E1:8B:25 nodemac=0E:C8:01:2C:75:46"
}

