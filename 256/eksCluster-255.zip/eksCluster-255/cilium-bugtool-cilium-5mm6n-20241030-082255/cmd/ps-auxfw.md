USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         678  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         672  0.0  0.1 1240432 15508 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         696  0.0  0.0   3852  1272 ?        R    08:22   0:00  \_ bash -c cat /proc/net/xfrm_stat
root         697  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         662  0.0  0.0 1228744 4044 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         650  0.0  0.0 1228744 3776 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         644  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops stats 1
root           1  3.6  4.8 1606080 387352 ?      Ssl  08:03   0:41 cilium-agent --config-dir=/tmp/cilium/config-map
root         417  0.0  0.0 1229488 7932 ?        Sl   08:04   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
