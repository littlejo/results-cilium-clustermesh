CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podede0bfe3_06d4_4730_8139_940c5f8395f7.slice/cri-containerd-054fb9c8b8de9cd55825d8c609a7630e0075c895f05d8f8d67865475fae8d8e6.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podede0bfe3_06d4_4730_8139_940c5f8395f7.slice/cri-containerd-852177a7e22cca2a9c14cb3f7f24496bcfc3cc75b7455ca14a585a0e3231aa30.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod09a533e2_cd9c_451c_89f9_3f0bc04e0aef.slice/cri-containerd-8839fcddf535c682f17015e8df420cba2e704254463db55b0b5ad4d5172cae5b.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod09a533e2_cd9c_451c_89f9_3f0bc04e0aef.slice/cri-containerd-66af05c3c503a7111341e2226f8d04eb93182b221e0bc6c96cf88a8eac186f08.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9c0cabb0_e25b_4452_9364_b3f0bb4256c8.slice/cri-containerd-d69e04f395d2376ca5510e755740c5d80d671affc9394e3bbdafc5c05c53f998.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9c0cabb0_e25b_4452_9364_b3f0bb4256c8.slice/cri-containerd-d6d7fe6cb37f1717dea63c705201514c03be9279002aaab91503451bc617f330.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod266fb9d0_4433_446c_a384_754db68c2043.slice/cri-containerd-ec9a8bd7ebc6ae56da082de6aef899ff9517006af9e0054d73f07a75583f1261.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod266fb9d0_4433_446c_a384_754db68c2043.slice/cri-containerd-b10ea02c354831289fb8a61f7ec8daf5493282dc90c91174c105edb1e2ace19f.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e691a24_fc75_4e7d_b44f_6c611e9440ad.slice/cri-containerd-be51bb706af7e6c355e465c3067f596d91227ac73aadcdbfbd1a58d6989ba80e.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e691a24_fc75_4e7d_b44f_6c611e9440ad.slice/cri-containerd-f52d52efd23094fe66109b7ce7db0a6f526ec15715cb5b9384900c2249083db6.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56bd55b3_22e6_4587_ac86_c2f10822def3.slice/cri-containerd-db86e844a599e54949af53bf251a891348393ce783c4a36942e2b0c51eab10fa.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56bd55b3_22e6_4587_ac86_c2f10822def3.slice/cri-containerd-942dc6212f56bc1a6933851f371e0b414bf477547b01d93962965e0fa5b95d8c.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56bd55b3_22e6_4587_ac86_c2f10822def3.slice/cri-containerd-623a583385a19c75dfbd178b0b433640d1a481dd2071ce16a54f634dc8fd35d4.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56bd55b3_22e6_4587_ac86_c2f10822def3.slice/cri-containerd-65347ed695e08bd1e025beb6afe0bccb92f5afcc659f882278c85a012e56cf76.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod094a96bb_84c4_495d_9358_0a09f8d7c430.slice/cri-containerd-4437617a739f5c65e016280b0e5c1811228db25421ca526fc54c447c7b7a9dfe.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod094a96bb_84c4_495d_9358_0a09f8d7c430.slice/cri-containerd-b076a24c277e3834c3b46fd51ea603b520f42351201b1dc7debfa048b9653413.scope
    97       cgroup_device   multi                                          
