top - 08:22:56 up 27 min,  0 users,  load average: 0.52, 0.19, 0.13
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 53.6 us, 35.7 sy,  0.0 ni, 10.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4479.2 free,   1189.2 used,   2145.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6440.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 397120  78656 S 100.0   5.0   0:41.36 cilium-+
    672 root      20   0 1240432  15508  10704 S   6.7   0.2   0:00.03 cilium-+
    417 root      20   0 1229488   7932   3836 S   0.0   0.1   0:01.11 cilium-+
    644 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    650 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
    662 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    678 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    708 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    726 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    732 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
