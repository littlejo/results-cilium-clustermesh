alloc: 139.28MB (146049136 bytes)
total-alloc: 2.22GB (2384871376 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 62749906
frees: 61456881
heap-alloc: 139.28MB (146049136 bytes)
heap-sys: 242.33MB (254099456 bytes)
heap-idle: 68.80MB (72138752 bytes)
heap-in-use: 173.53MB (181960704 bytes)
heap-released: 3.85MB (4038656 bytes)
heap-objects: 1293025
stack-in-use: 65.62MB (68812800 bytes)
stack-sys: 65.62MB (68812800 bytes)
stack-mspan-inuse: 2.92MB (3063840 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1016.02KB (1040409 bytes)
gc-sys: 6.05MB (6340192 bytes)
next-gc: when heap-alloc >= 213.29MB (223651368 bytes)
last-gc: 2024-10-30 08:23:09.131762539 +0000 UTC
gc-pause-total: 9.247506ms
gc-pause: 87770
gc-pause-end: 1730276589131762539
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0005345230025815969
enable-gc: true
debug-gc: false
