REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35595     2812702     677    bpf_overlay.c
Interface                 INGRESS     621116    128792323   1132   bpf_host.c
Success                   EGRESS      15195     1191968     1694   bpf_host.c
Success                   EGRESS      263560    33863291    1308   bpf_lxc.c
Success                   EGRESS      34954     2768501     53     encap.h
Success                   INGRESS     305081    34396406    86     l3.h
Success                   INGRESS     326005    36051788    235    trace.h
Unsupported L3 protocol   EGRESS      40        2972        1492   bpf_lxc.c
