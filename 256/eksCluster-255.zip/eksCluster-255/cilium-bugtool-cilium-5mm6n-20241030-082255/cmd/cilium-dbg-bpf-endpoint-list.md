IP ADDRESS         LOCAL ENDPOINT INFO
10.255.0.20:0      id=109   sec_id=4     flags=0x0000 ifindex=10  mac=B6:F2:E7:E1:8B:25 nodemac=0E:C8:01:2C:75:46     
10.255.0.241:0     (localhost)                                                                                        
10.255.0.229:0     id=4075  sec_id=8398258 flags=0x0000 ifindex=18  mac=5E:C3:AA:76:A1:33 nodemac=AE:DA:12:51:A2:B9   
172.31.240.189:0   (localhost)                                                                                        
10.255.0.110:0     id=649   sec_id=8402338 flags=0x0000 ifindex=14  mac=76:67:50:0F:CC:8D nodemac=DA:1D:F6:D0:04:D6   
172.31.249.38:0    (localhost)                                                                                        
10.255.0.130:0     id=3201  sec_id=8402338 flags=0x0000 ifindex=12  mac=BA:28:73:BB:23:E4 nodemac=D2:A3:C1:DC:56:85   
