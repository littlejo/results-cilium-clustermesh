1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:0a:34:e4:2e:55 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.227.236/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3333sec preferred_lft 3333sec
    inet6 fe80::80a:34ff:fee4:2e55/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:21:1d:e1:1d:47 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.213.237/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::821:1dff:fee1:1d47/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:3a:96:05:05:f1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::483a:96ff:fe05:5f1/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:40:69:13:55:23 brd ff:ff:ff:ff:ff:ff
    inet 10.55.0.233/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::6440:69ff:fe13:5523/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether fa:32:0a:3c:fa:df brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f832:aff:fe3c:fadf/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:5b:fe:f1:f3:23 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::405b:feff:fef1:f323/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf8f3d52fd0a5@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:37:0c:b0:80:09 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8037:cff:feb0:8009/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc238f71f9e04f@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:29:fc:c5:05:b6 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::cc29:fcff:fec5:5b6/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc7df5baefcae8@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:46:8c:59:99:81 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a846:8cff:fe59:9981/64 scope link 
       valid_lft forever preferred_lft forever
