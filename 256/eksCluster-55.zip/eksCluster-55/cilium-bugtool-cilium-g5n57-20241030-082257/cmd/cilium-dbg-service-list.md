ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.160.72:443 (active)     
                                          2 => 172.31.248.86:443 (active)     
2    10.100.157.94:443     ClusterIP      1 => 172.31.227.236:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.55.0.145:9153 (active)      
                                          2 => 10.55.0.124:9153 (active)      
4    10.100.0.10:53        ClusterIP      1 => 10.55.0.145:53 (active)        
                                          2 => 10.55.0.124:53 (active)        
5    10.100.255.201:2379   ClusterIP      1 => 10.55.0.46:2379 (active)       
