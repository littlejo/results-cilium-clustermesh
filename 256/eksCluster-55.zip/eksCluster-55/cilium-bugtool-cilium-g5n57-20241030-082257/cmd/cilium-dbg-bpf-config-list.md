KEY             VALUE
AgentLiveness   2109005433597
UTimeOffset     3379442382812500
