USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         627  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         609  0.0  0.1 1240432 15948 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         648  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         651  0.0  0.0   3728   488 ?        R    08:22   0:00  \_ bash -c ip a
root         599  0.0  0.0 1228744 3660 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.2  4.7 1606208 379720 ?      Ssl  07:56   0:52 cilium-agent --config-dir=/tmp/cilium/config-map
root         400  0.0  0.1 1229744 8016 ?        Sl   07:56   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
