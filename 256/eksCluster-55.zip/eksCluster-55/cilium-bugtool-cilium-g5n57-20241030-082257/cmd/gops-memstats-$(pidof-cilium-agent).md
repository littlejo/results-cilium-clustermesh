alloc: 196.98MB (206553536 bytes)
total-alloc: 2.18GB (2337275824 bytes)
sys: 316.89MB (332288356 bytes)
lookups: 0
mallocs: 62370943
frees: 60054368
heap-alloc: 196.98MB (206553536 bytes)
heap-sys: 236.95MB (248463360 bytes)
heap-idle: 18.91MB (19832832 bytes)
heap-in-use: 218.04MB (228630528 bytes)
heap-released: 11.47MB (12025856 bytes)
heap-objects: 2316575
stack-in-use: 66.78MB (70025216 bytes)
stack-sys: 66.78MB (70025216 bytes)
stack-mspan-inuse: 3.64MB (3812800 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1061873 bytes)
gc-sys: 6.37MB (6676040 bytes)
next-gc: when heap-alloc >= 207.95MB (218055480 bytes)
last-gc: 2024-10-30 08:22:44.678390654 +0000 UTC
gc-pause-total: 15.152331ms
gc-pause: 151117
gc-pause-end: 1730276564678390654
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.0003881977003527043
enable-gc: true
debug-gc: false
