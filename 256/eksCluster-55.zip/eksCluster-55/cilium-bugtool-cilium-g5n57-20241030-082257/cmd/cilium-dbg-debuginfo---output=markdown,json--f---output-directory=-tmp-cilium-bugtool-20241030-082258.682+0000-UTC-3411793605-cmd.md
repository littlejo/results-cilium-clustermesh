markdown output at /tmp/cilium-bugtool-20241030-082258.682+0000-UTC-3411793605/cmd/cilium-debuginfo-20241030-082329.53+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082258.682+0000-UTC-3411793605/cmd/cilium-debuginfo-20241030-082329.53+0000-UTC.json
