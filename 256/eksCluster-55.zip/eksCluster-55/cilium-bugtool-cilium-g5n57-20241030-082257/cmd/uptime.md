 08:22:58 up 34 min,  0 users,  load average: 0.37, 0.21, 0.14
