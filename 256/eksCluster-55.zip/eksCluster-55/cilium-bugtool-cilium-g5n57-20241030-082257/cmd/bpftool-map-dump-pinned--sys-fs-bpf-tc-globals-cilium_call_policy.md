key: 1f 01 00 00  value: 1c 02 00 00
key: a3 01 00 00  value: 0e 02 00 00
key: d7 07 00 00  value: 76 02 00 00
key: 5e 09 00 00  value: ff 01 00 00
Found 4 elements
