REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34201     2702511     677    bpf_overlay.c
Interface                 INGRESS     611968    128150428   1132   bpf_host.c
Success                   EGRESS      13929     1090063     1694   bpf_host.c
Success                   EGRESS      257720    32912457    1308   bpf_lxc.c
Success                   EGRESS      32998     2614280     53     encap.h
Success                   INGRESS     299142    33504755    86     l3.h
Success                   INGRESS     320065    35161249    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
