Endpoint ID: 287
Path: /sys/fs/bpf/tc/globals/cilium_policy_00287

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    152971   1757      0        
Allow    Egress      0          ANY          NONE         disabled    19861    219       0        


Endpoint ID: 419
Path: /sys/fs/bpf/tc/globals/cilium_policy_00419

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1659544   20961     0        
Allow    Ingress     1          ANY          NONE         disabled    22220     258       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 487
Path: /sys/fs/bpf/tc/globals/cilium_policy_00487

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2007
Path: /sys/fs/bpf/tc/globals/cilium_policy_02007

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11278927   109995    0        
Allow    Ingress     1          ANY          NONE         disabled    9136813    95424     0        
Allow    Egress      0          ANY          NONE         disabled    10639985   106244    0        


Endpoint ID: 2398
Path: /sys/fs/bpf/tc/globals/cilium_policy_02398

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    153961   1772      0        
Allow    Egress      0          ANY          NONE         disabled    19333    214       0        


