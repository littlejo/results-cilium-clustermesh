top - 08:22:58 up 34 min,  0 users,  load average: 0.37, 0.21, 0.14
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 23.3 us, 20.0 sy,  0.0 ni, 56.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4498.0 free,   1170.4 used,   2145.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6458.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606208 379720  78332 S   6.7   4.7   0:52.03 cilium-+
    609 root      20   0 1240432  16236  11228 S   6.7   0.2   0:00.03 cilium-+
    400 root      20   0 1229744   8016   3900 S   0.0   0.1   0:01.20 cilium-+
    599 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    627 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    660 root      20   0    6576   2420   2096 R   0.0   0.0   0:00.00 top
    678 root      20   0 1229000   4024   3356 S   0.0   0.1   0:00.00 gops
    684 root      20   0 1615752   8288   6220 S   0.0   0.1   0:00.00 runc:[2+
    685 root      20   0 1616264   8804   6308 S   0.0   0.1   0:00.00 runc:[2+
