29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:23+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:23+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:23+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:23+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:23+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:48:24+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:48:24+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:48:24+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:48:24+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:24+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:48:29+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:48:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:48:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:48:40+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name tail_handle_ipv4  tag 463a6703d2a7568b  gpl
	loaded_at 2024-10-30T07:56:42+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
479: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:56:42+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
480: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:56:42+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 126
481: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:56:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
504: sched_cls  name tail_ipv4_ct_egress  tag 4de25f24ec5b9d0b  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 153
505: sched_cls  name cil_from_container  tag dc5d5ccf37327df4  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,76
	btf_id 154
506: sched_cls  name tail_handle_ipv4_cont  tag 1af6a36db0c8a854  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,107,41,106,82,83,39,76,74,77,108,40,37,38,81
	btf_id 155
507: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 156
508: sched_cls  name tail_handle_ipv4  tag 7dd099cb90f79321  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 157
510: sched_cls  name tail_handle_arp  tag e1b9f8b0e829bc3d  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 159
511: sched_cls  name handle_policy  tag 47f5ffa76682ae32  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,108,82,83,107,41,80,106,39,84,75,40,37,38
	btf_id 160
512: sched_cls  name __send_drop_notify  tag 7dd646cbda5f30dc  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 161
513: sched_cls  name tail_ipv4_to_endpoint  tag 54223f30abecabc0  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,107,41,82,83,80,106,39,108,40,37,38
	btf_id 162
514: sched_cls  name tail_ipv4_ct_ingress  tag 963a71f4a106b931  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 163
515: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 165
516: sched_cls  name tail_handle_ipv4  tag 690d8cc6ff4c7c3e  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 166
517: sched_cls  name tail_ipv4_ct_ingress  tag 235f7bc207808320  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 167
518: sched_cls  name cil_from_container  tag ad5f15ef54129d62  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 110,76
	btf_id 168
519: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
522: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
523: sched_cls  name tail_handle_ipv4_cont  tag d5da23dd3434de78  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,109,41,101,82,83,39,76,74,77,110,40,37,38,81
	btf_id 169
524: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 170
525: sched_cls  name __send_drop_notify  tag 3312c88dd1b39375  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 171
526: sched_cls  name handle_policy  tag a4ce977957a09edb  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,110,82,83,109,41,80,101,39,84,75,40,37,38
	btf_id 172
527: sched_cls  name tail_handle_arp  tag be59c40dafb56b9e  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 173
529: sched_cls  name tail_ipv4_to_endpoint  tag e79b8764352a7890  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,109,41,82,83,80,101,39,110,40,37,38
	btf_id 175
530: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 177
531: sched_cls  name tail_handle_ipv4  tag e3edb52704885f5d  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 178
532: sched_cls  name __send_drop_notify  tag 89bb6083873cbdce  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 179
533: sched_cls  name tail_ipv4_ct_ingress  tag 05dc31f4b5246679  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 180
534: sched_cls  name tail_ipv4_ct_egress  tag 4de25f24ec5b9d0b  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 181
535: sched_cls  name tail_handle_arp  tag 90e456ea43fe4f83  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 182
536: sched_cls  name cil_from_container  tag 284d0a045e7b9fbc  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 183
538: sched_cls  name tail_ipv4_to_endpoint  tag 8ba7a63183f485f3  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,100,39,113,40,37,38
	btf_id 185
539: sched_cls  name tail_handle_ipv4_cont  tag a9fc625592a2afe2  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,112,41,100,82,83,39,76,74,77,113,40,37,38,81
	btf_id 186
540: sched_cls  name handle_policy  tag 5e91d8ca9e081ab8  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,100,39,84,75,40,37,38
	btf_id 187
541: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
544: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
545: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
548: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
549: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
552: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
553: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 189
554: sched_cls  name tail_handle_ipv4_from_host  tag 67bef5407d971846  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 190
555: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 191
557: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,117
	btf_id 193
558: sched_cls  name __send_drop_notify  tag 311fd4bcbfcdc7c4  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 194
561: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 198
562: sched_cls  name tail_handle_ipv4_from_host  tag 67bef5407d971846  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 199
563: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 200
566: sched_cls  name __send_drop_notify  tag 311fd4bcbfcdc7c4  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
569: sched_cls  name tail_handle_ipv4_from_host  tag 67bef5407d971846  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 207
570: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 208
571: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 209
573: sched_cls  name __send_drop_notify  tag 311fd4bcbfcdc7c4  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 211
574: sched_cls  name __send_drop_notify  tag 311fd4bcbfcdc7c4  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 213
577: sched_cls  name tail_handle_ipv4_from_host  tag 67bef5407d971846  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 216
578: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 217
579: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 218
620: sched_cls  name cil_from_container  tag 19c4a0bd0d803e09  gpl
	loaded_at 2024-10-30T08:12:32+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 137,76
	btf_id 233
621: sched_cls  name tail_ipv4_ct_ingress  tag ff4ebf145722e3e9  gpl
	loaded_at 2024-10-30T08:12:32+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 234
622: sched_cls  name tail_ipv4_ct_egress  tag 8df547205c72ff99  gpl
	loaded_at 2024-10-30T08:12:32+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 235
623: sched_cls  name tail_handle_ipv4  tag d602e1e03ef74b05  gpl
	loaded_at 2024-10-30T08:12:32+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,137
	btf_id 236
625: sched_cls  name __send_drop_notify  tag e974efe6eac20df4  gpl
	loaded_at 2024-10-30T08:12:32+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 238
626: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:12:32+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,137
	btf_id 239
627: sched_cls  name tail_handle_arp  tag 47fe02c3d151aabe  gpl
	loaded_at 2024-10-30T08:12:32+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,137
	btf_id 240
628: sched_cls  name tail_handle_ipv4_cont  tag 40304db4de301694  gpl
	loaded_at 2024-10-30T08:12:32+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,136,41,135,82,83,39,76,74,77,137,40,37,38,81
	btf_id 241
629: sched_cls  name tail_ipv4_to_endpoint  tag d3421da56975881b  gpl
	loaded_at 2024-10-30T08:12:32+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,136,41,82,83,80,135,39,137,40,37,38
	btf_id 242
630: sched_cls  name handle_policy  tag 307bc626bc8a1216  gpl
	loaded_at 2024-10-30T08:12:32+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,137,82,83,136,41,80,135,39,84,75,40,37,38
	btf_id 243
631: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
634: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
647: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
650: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
655: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
658: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
