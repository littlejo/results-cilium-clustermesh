key: 08 00 00 00  value: 0a 37 00 7c 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f e3 ec 10 94 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f f8 56 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 37 00 2e 09 4b 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 37 00 7c 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 37 00 91 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 37 00 91 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f a0 48 01 bb 00 00  00 00 00 00
Found 8 elements
