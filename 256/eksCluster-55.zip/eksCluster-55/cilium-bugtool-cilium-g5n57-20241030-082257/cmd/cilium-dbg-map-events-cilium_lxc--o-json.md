{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:40.436Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.213.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:40.436Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.227.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:40.436Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:45.139Z",
  "value": "id=419   sec_id=4     flags=0x0000 ifindex=10  mac=1E:DB:2A:90:2C:6C nodemac=42:5B:FE:F1:F3:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:45.140Z",
  "value": "id=287   sec_id=1837813 flags=0x0000 ifindex=12  mac=E6:6E:75:6C:B9:9A nodemac=82:37:0C:B0:80:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:45.215Z",
  "value": "id=2398  sec_id=1837813 flags=0x0000 ifindex=14  mac=B6:EC:FA:9F:63:2D nodemac=CE:29:FC:C5:05:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:45.297Z",
  "value": "id=419   sec_id=4     flags=0x0000 ifindex=10  mac=1E:DB:2A:90:2C:6C nodemac=42:5B:FE:F1:F3:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:45.338Z",
  "value": "id=287   sec_id=1837813 flags=0x0000 ifindex=12  mac=E6:6E:75:6C:B9:9A nodemac=82:37:0C:B0:80:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:27.027Z",
  "value": "id=2398  sec_id=1837813 flags=0x0000 ifindex=14  mac=B6:EC:FA:9F:63:2D nodemac=CE:29:FC:C5:05:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:27.028Z",
  "value": "id=419   sec_id=4     flags=0x0000 ifindex=10  mac=1E:DB:2A:90:2C:6C nodemac=42:5B:FE:F1:F3:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:27.029Z",
  "value": "id=287   sec_id=1837813 flags=0x0000 ifindex=12  mac=E6:6E:75:6C:B9:9A nodemac=82:37:0C:B0:80:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:27.058Z",
  "value": "id=687   sec_id=1850633 flags=0x0000 ifindex=16  mac=B6:7F:51:19:7E:FC nodemac=D2:0E:F3:AA:0A:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:27.059Z",
  "value": "id=687   sec_id=1850633 flags=0x0000 ifindex=16  mac=B6:7F:51:19:7E:FC nodemac=D2:0E:F3:AA:0A:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:28.029Z",
  "value": "id=419   sec_id=4     flags=0x0000 ifindex=10  mac=1E:DB:2A:90:2C:6C nodemac=42:5B:FE:F1:F3:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:28.029Z",
  "value": "id=2398  sec_id=1837813 flags=0x0000 ifindex=14  mac=B6:EC:FA:9F:63:2D nodemac=CE:29:FC:C5:05:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:28.029Z",
  "value": "id=287   sec_id=1837813 flags=0x0000 ifindex=12  mac=E6:6E:75:6C:B9:9A nodemac=82:37:0C:B0:80:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:28.029Z",
  "value": "id=687   sec_id=1850633 flags=0x0000 ifindex=16  mac=B6:7F:51:19:7E:FC nodemac=D2:0E:F3:AA:0A:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.344Z",
  "value": "id=2007  sec_id=1850633 flags=0x0000 ifindex=18  mac=26:16:5F:2D:8D:33 nodemac=AA:46:8C:59:99:81"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.55.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.860Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.254Z",
  "value": "id=2007  sec_id=1850633 flags=0x0000 ifindex=18  mac=26:16:5F:2D:8D:33 nodemac=AA:46:8C:59:99:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.260Z",
  "value": "id=419   sec_id=4     flags=0x0000 ifindex=10  mac=1E:DB:2A:90:2C:6C nodemac=42:5B:FE:F1:F3:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.260Z",
  "value": "id=287   sec_id=1837813 flags=0x0000 ifindex=12  mac=E6:6E:75:6C:B9:9A nodemac=82:37:0C:B0:80:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.261Z",
  "value": "id=2398  sec_id=1837813 flags=0x0000 ifindex=14  mac=B6:EC:FA:9F:63:2D nodemac=CE:29:FC:C5:05:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.260Z",
  "value": "id=419   sec_id=4     flags=0x0000 ifindex=10  mac=1E:DB:2A:90:2C:6C nodemac=42:5B:FE:F1:F3:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.261Z",
  "value": "id=287   sec_id=1837813 flags=0x0000 ifindex=12  mac=E6:6E:75:6C:B9:9A nodemac=82:37:0C:B0:80:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.262Z",
  "value": "id=2398  sec_id=1837813 flags=0x0000 ifindex=14  mac=B6:EC:FA:9F:63:2D nodemac=CE:29:FC:C5:05:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.263Z",
  "value": "id=2007  sec_id=1850633 flags=0x0000 ifindex=18  mac=26:16:5F:2D:8D:33 nodemac=AA:46:8C:59:99:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.255Z",
  "value": "id=2398  sec_id=1837813 flags=0x0000 ifindex=14  mac=B6:EC:FA:9F:63:2D nodemac=CE:29:FC:C5:05:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.255Z",
  "value": "id=287   sec_id=1837813 flags=0x0000 ifindex=12  mac=E6:6E:75:6C:B9:9A nodemac=82:37:0C:B0:80:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.256Z",
  "value": "id=2007  sec_id=1850633 flags=0x0000 ifindex=18  mac=26:16:5F:2D:8D:33 nodemac=AA:46:8C:59:99:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.256Z",
  "value": "id=419   sec_id=4     flags=0x0000 ifindex=10  mac=1E:DB:2A:90:2C:6C nodemac=42:5B:FE:F1:F3:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.256Z",
  "value": "id=419   sec_id=4     flags=0x0000 ifindex=10  mac=1E:DB:2A:90:2C:6C nodemac=42:5B:FE:F1:F3:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.256Z",
  "value": "id=2007  sec_id=1850633 flags=0x0000 ifindex=18  mac=26:16:5F:2D:8D:33 nodemac=AA:46:8C:59:99:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.256Z",
  "value": "id=2398  sec_id=1837813 flags=0x0000 ifindex=14  mac=B6:EC:FA:9F:63:2D nodemac=CE:29:FC:C5:05:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.256Z",
  "value": "id=287   sec_id=1837813 flags=0x0000 ifindex=12  mac=E6:6E:75:6C:B9:9A nodemac=82:37:0C:B0:80:09"
}

