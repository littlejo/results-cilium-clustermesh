CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbbdf96ab_e387_4ab5_b59f_11119c1f5694.slice/cri-containerd-57fb32d74857f45dabebd48cadfc44c4ab6ab25ee8c6a7f30204ec7304640ddb.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbbdf96ab_e387_4ab5_b59f_11119c1f5694.slice/cri-containerd-488202d733bbcde2b8786f586e87ab6a0f498d3b750e177f205615e9aebc7a3e.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod107dd8af_ccc1_4a53_abb0_baefb8af5aee.slice/cri-containerd-3d9ff63c6f1bd612ee65569463971a68a511b0b209a043267f9537555b527495.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod107dd8af_ccc1_4a53_abb0_baefb8af5aee.slice/cri-containerd-8a23bac7a7e38361be135ee40c9a552d87a39be9c503d2dc6eeba2b57afa6820.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podadfe443c_b341_469e_aec8_57b22e9a5bfd.slice/cri-containerd-7484556ef8a919d8abb5bcae62582e007c072c87bd246015106d334ebedd88de.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podadfe443c_b341_469e_aec8_57b22e9a5bfd.slice/cri-containerd-82c3a9c3d4898c04f9f956b013e8f9651bcea979cfba1f0d845f3f79a41818c0.scope
    522      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcacb605f_6ce1_4526_a912_96c067b0690c.slice/cri-containerd-7262154e29d9da80436e21de28320b02d45eb6856f8a0b66e632252ac994275b.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcacb605f_6ce1_4526_a912_96c067b0690c.slice/cri-containerd-5acc8501ea6012b59dfb7acc4fd42c3afcf4764d3d88f8b1a77f96abad61c76e.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda70ced82_e9e3_4f69_bed7_64922123cc6e.slice/cri-containerd-77573a5c21b6ef638323410b425ad31f74caff197cb04850eb9bb63f388d797f.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda70ced82_e9e3_4f69_bed7_64922123cc6e.slice/cri-containerd-2d3435d87df2fb94ed91c817e212de17978836af96c8f94d2ac96e3540b379cb.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda70ced82_e9e3_4f69_bed7_64922123cc6e.slice/cri-containerd-fbcb7d18314da0d5dd4bb2c76beeed64c09e1575e75ee1620651eaeee7474bca.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda70ced82_e9e3_4f69_bed7_64922123cc6e.slice/cri-containerd-f5bdf32faf4ba5f1d84da28029782d867f08bced213e455b3342030cda465a28.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod039e37b0_eea6_4caf_b795_c538f3c44d89.slice/cri-containerd-bde9713b56c7f8ebb6d03b10c377a8664f221e90d61ac3e33bc629d7ffd86544.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod039e37b0_eea6_4caf_b795_c538f3c44d89.slice/cri-containerd-ff7fe661796f02ba20b2fb12ce96c70ba779cc24f2787b77f24fa1619d34dd00.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod383801d5_b3fb_4b82_9d8f_7fa018ed9741.slice/cri-containerd-40c03e2e558c074afd490b39ed483880e8b7317b02023fbd5b5980943dd8b827.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod383801d5_b3fb_4b82_9d8f_7fa018ed9741.slice/cri-containerd-9184db611928eb94e698511ee2a8b08f25d9aaf501e975b203ab8b5a3c8442bb.scope
    103      cgroup_device   multi                                          
