[
  {
    "containers": [
      {
        "cgroup-id": 7835,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcacb605f_6ce1_4526_a912_96c067b0690c.slice/cri-containerd-7262154e29d9da80436e21de28320b02d45eb6856f8a0b66e632252ac994275b.scope"
      }
    ],
    "ips": [
      "10.55.0.145"
    ],
    "name": "coredns-cc6ccd49c-wmj7k",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7751,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podadfe443c_b341_469e_aec8_57b22e9a5bfd.slice/cri-containerd-7484556ef8a919d8abb5bcae62582e007c072c87bd246015106d334ebedd88de.scope"
      }
    ],
    "ips": [
      "10.55.0.124"
    ],
    "name": "coredns-cc6ccd49c-vns7v",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda70ced82_e9e3_4f69_bed7_64922123cc6e.slice/cri-containerd-2d3435d87df2fb94ed91c817e212de17978836af96c8f94d2ac96e3540b379cb.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda70ced82_e9e3_4f69_bed7_64922123cc6e.slice/cri-containerd-fbcb7d18314da0d5dd4bb2c76beeed64c09e1575e75ee1620651eaeee7474bca.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda70ced82_e9e3_4f69_bed7_64922123cc6e.slice/cri-containerd-77573a5c21b6ef638323410b425ad31f74caff197cb04850eb9bb63f388d797f.scope"
      }
    ],
    "ips": [
      "10.55.0.46"
    ],
    "name": "clustermesh-apiserver-8ddb469ff-s5pwq",
    "namespace": "kube-system"
  }
]

