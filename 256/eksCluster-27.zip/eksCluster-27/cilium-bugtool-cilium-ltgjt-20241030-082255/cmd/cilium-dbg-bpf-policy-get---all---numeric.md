Endpoint ID: 87
Path: /sys/fs/bpf/tc/globals/cilium_policy_00087

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    178052   2050      0        
Allow    Egress      0          ANY          NONE         disabled    21495    243       0        


Endpoint ID: 165
Path: /sys/fs/bpf/tc/globals/cilium_policy_00165

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1664520   21054     0        
Allow    Ingress     1          ANY          NONE         disabled    26680     310       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 595
Path: /sys/fs/bpf/tc/globals/cilium_policy_00595

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2901
Path: /sys/fs/bpf/tc/globals/cilium_policy_02901

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11714255   117097    0        
Allow    Ingress     1          ANY          NONE         disabled    11475517   117843    0        
Allow    Egress      0          ANY          NONE         disabled    13292353   130760    0        


Endpoint ID: 3445
Path: /sys/fs/bpf/tc/globals/cilium_policy_03445

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    178023   2044      0        
Allow    Egress      0          ANY          NONE         disabled    21004    236       0        


