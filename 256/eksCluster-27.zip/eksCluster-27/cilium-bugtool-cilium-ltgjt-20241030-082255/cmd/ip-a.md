1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:21:ff:09:26:0d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.193.237/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3105sec preferred_lft 3105sec
    inet6 fe80::821:ffff:fe09:260d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:83:06:72:75:c9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.252.239/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::883:6ff:fe72:75c9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:55:e0:9b:0a:6f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6855:e0ff:fe9b:a6f/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:54:b5:52:b9:09 brd ff:ff:ff:ff:ff:ff
    inet 10.27.0.232/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::6454:b5ff:fe52:b909/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3e:8e:e3:3b:83:8a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3c8e:e3ff:fe3b:838a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:5a:c7:3a:36:e3 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::985a:c7ff:fe3a:36e3/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc0195db0647a2@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:62:d6:98:5b:c9 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f462:d6ff:fe98:5bc9/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc4d54cbd1dd5f@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:02:b7:54:4e:42 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c402:b7ff:fe54:4e42/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcd84486c64cda@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:38:92:36:7c:3a brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::1438:92ff:fe36:7c3a/64 scope link 
       valid_lft forever preferred_lft forever
