alloc: 161.54MB (169387848 bytes)
total-alloc: 2.50GB (2682980552 bytes)
sys: 333.02MB (349196644 bytes)
lookups: 0
mallocs: 66818166
frees: 65133206
heap-alloc: 161.54MB (169387848 bytes)
heap-sys: 252.67MB (264945664 bytes)
heap-idle: 56.80MB (59555840 bytes)
heap-in-use: 195.88MB (205389824 bytes)
heap-released: 1.52MB (1589248 bytes)
heap-objects: 1684960
stack-in-use: 67.28MB (70549504 bytes)
stack-sys: 67.28MB (70549504 bytes)
stack-mspan-inuse: 3.30MB (3464960 bytes)
stack-mspan-sys: 4.00MB (4194240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.03MB (1078081 bytes)
gc-sys: 6.02MB (6315472 bytes)
next-gc: when heap-alloc >= 213.56MB (223931704 bytes)
last-gc: 2024-10-30 08:23:02.844924959 +0000 UTC
gc-pause-total: 16.721571ms
gc-pause: 78795
gc-pause-end: 1730276582844924959
num-gc: 87
num-forced-gc: 0
gc-cpu-fraction: 0.0005074615048223611
enable-gc: true
debug-gc: false
