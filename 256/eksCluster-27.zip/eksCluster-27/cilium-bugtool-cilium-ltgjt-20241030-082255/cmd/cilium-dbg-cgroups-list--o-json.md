[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f25db03_7d49_42d5_92d1_4d1eef439f0c.slice/cri-containerd-15e3cef3a16483a4a41284bbd1b45c5e64ff3ca55a612dbe3d724722ce00338a.scope"
      }
    ],
    "ips": [
      "10.27.0.15"
    ],
    "name": "coredns-cc6ccd49c-6x42v",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55d95ff0_4e82_4f90_bcc7_9dc80c97e579.slice/cri-containerd-b013f948bb56b1e8385013e1ac8eaecd23f7a441e6e87399b3aad141d2259341.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55d95ff0_4e82_4f90_bcc7_9dc80c97e579.slice/cri-containerd-8eef997369bd45b6a8fa1cd845447e41d562cd6abba9deb67a5ac0d510ed38a6.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55d95ff0_4e82_4f90_bcc7_9dc80c97e579.slice/cri-containerd-3923a7cf8e95e6f17d9f0e3522488d14869306cdef1e8e87201a74f21c7f9eb0.scope"
      }
    ],
    "ips": [
      "10.27.0.40"
    ],
    "name": "clustermesh-apiserver-7986c578cc-w85dn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddab0d779_af0b_42dd_bed2_b76ef0b26972.slice/cri-containerd-be2a79af0e8946932be53b0c70998412e8f4e85570ca2d80ed8eb9635f908df6.scope"
      }
    ],
    "ips": [
      "10.27.0.137"
    ],
    "name": "coredns-cc6ccd49c-qzlhb",
    "namespace": "kube-system"
  }
]

