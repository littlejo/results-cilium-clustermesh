key: 07 00 00 00  value: 0a 1b 00 89 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 1b 00 28 09 4b 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 1b 00 0f 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 1b 00 0f 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f fd e6 01 bb 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f ae c1 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 1b 00 89 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f c1 ed 10 94 00 00  00 00 00 00
Found 8 elements
