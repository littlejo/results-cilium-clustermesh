key: 57 00 00 00  value: 20 02 00 00
key: a5 00 00 00  value: 04 02 00 00
key: 55 0b 00 00  value: 75 02 00 00
key: 75 0d 00 00  value: f9 01 00 00
Found 4 elements
