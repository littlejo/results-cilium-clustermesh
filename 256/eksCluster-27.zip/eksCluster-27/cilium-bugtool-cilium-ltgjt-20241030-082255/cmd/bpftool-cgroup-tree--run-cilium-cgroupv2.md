CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36d79b9e_d9bc_4eae_af5a_a495871fc1ab.slice/cri-containerd-8e424db0f3e7e021f5f1cd15f714e5c39f81e9cb332abfefbc280e1bf7895fe5.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36d79b9e_d9bc_4eae_af5a_a495871fc1ab.slice/cri-containerd-94be87c68197c5f672fc26ebd4bd527559602dcca8b4f6c416c6e07ec050d91e.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f25db03_7d49_42d5_92d1_4d1eef439f0c.slice/cri-containerd-15e3cef3a16483a4a41284bbd1b45c5e64ff3ca55a612dbe3d724722ce00338a.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f25db03_7d49_42d5_92d1_4d1eef439f0c.slice/cri-containerd-1f9f23076ed2adef476d95cea5f6c035fe1208eba3ab3b9e098e86a5a46f186e.scope
    530      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddab0d779_af0b_42dd_bed2_b76ef0b26972.slice/cri-containerd-be2a79af0e8946932be53b0c70998412e8f4e85570ca2d80ed8eb9635f908df6.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddab0d779_af0b_42dd_bed2_b76ef0b26972.slice/cri-containerd-8ba3553eb6392b7e8e23b42cb40f934b94eb160bfd6671bdaa63ea8432586190.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd8f3ae9_7ef9_4073_ac9f_74b5207364c0.slice/cri-containerd-59dbbcc5046bc921553d4a7347c9daddc54457741140edc6ed10992f930637ab.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd8f3ae9_7ef9_4073_ac9f_74b5207364c0.slice/cri-containerd-72355cd2992193ebc3e47d7d82cc1ec2e2839dd0d977b8fcccd9a70c6a07095e.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55d95ff0_4e82_4f90_bcc7_9dc80c97e579.slice/cri-containerd-b013f948bb56b1e8385013e1ac8eaecd23f7a441e6e87399b3aad141d2259341.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55d95ff0_4e82_4f90_bcc7_9dc80c97e579.slice/cri-containerd-80a4a80dad73da8dcca9130a4e4794300c6e591d8ca1a2293b3c407a6e3f9f9d.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55d95ff0_4e82_4f90_bcc7_9dc80c97e579.slice/cri-containerd-8eef997369bd45b6a8fa1cd845447e41d562cd6abba9deb67a5ac0d510ed38a6.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55d95ff0_4e82_4f90_bcc7_9dc80c97e579.slice/cri-containerd-3923a7cf8e95e6f17d9f0e3522488d14869306cdef1e8e87201a74f21c7f9eb0.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbe37451b_53a6_4632_a6ea_761e61774561.slice/cri-containerd-d3350921bd17d9447d7540da4a4423f8e3fdea46da2b04888254a5394a4f79f8.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbe37451b_53a6_4632_a6ea_761e61774561.slice/cri-containerd-5b42421294a0e39aad4513360095eb3ce0c549825a79fd9f153311e81c1afc09.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab91011d_5957_495d_be90_fc1a6cab6bbb.slice/cri-containerd-a63383e1cc64807248db888c8edd1b9b71590e65263cad158b91aff5e2a63e4d.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab91011d_5957_495d_be90_fc1a6cab6bbb.slice/cri-containerd-b757284274ad2f13d80093a17d2ac34df69f74e8e2406bc8ea7fcad138742b6e.scope
    95       cgroup_device   multi                                          
