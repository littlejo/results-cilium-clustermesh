ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.174.193:443 (active)    
                                          2 => 172.31.253.230:443 (active)    
2    10.100.92.161:443     ClusterIP      1 => 172.31.193.237:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.27.0.137:9153 (active)      
                                          2 => 10.27.0.15:9153 (active)       
4    10.100.0.10:53        ClusterIP      1 => 10.27.0.137:53 (active)        
                                          2 => 10.27.0.15:53 (active)         
5    10.100.239.139:2379   ClusterIP      1 => 10.27.0.40:2379 (active)       
