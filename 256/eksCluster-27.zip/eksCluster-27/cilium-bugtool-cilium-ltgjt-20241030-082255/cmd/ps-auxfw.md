USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         677  0.0  0.0 1228744 3776 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         669  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         668  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         649  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         642  0.0  0.2 1240176 16300 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         704  0.0  0.0   6408  1632 ?        R    08:22   0:00  \_ ps auxfw
root         705  0.0  0.2 1240176 16300 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  3.1  4.9 1606336 397932 ?      Ssl  07:52   0:58 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.1 1229488 8132 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
