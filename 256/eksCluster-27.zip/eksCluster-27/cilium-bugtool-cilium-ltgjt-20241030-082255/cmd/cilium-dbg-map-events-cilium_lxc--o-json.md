{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:19.935Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.193.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:19.935Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.252.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:19.935Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:24.793Z",
  "value": "id=165   sec_id=4     flags=0x0000 ifindex=10  mac=BA:A6:23:2C:9D:50 nodemac=9A:5A:C7:3A:36:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:24.794Z",
  "value": "id=87    sec_id=931810 flags=0x0000 ifindex=12  mac=E2:CA:7A:F9:F5:52 nodemac=F6:62:D6:98:5B:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:24.837Z",
  "value": "id=3445  sec_id=931810 flags=0x0000 ifindex=14  mac=82:CF:51:23:2C:B3 nodemac=C6:02:B7:54:4E:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:24.961Z",
  "value": "id=165   sec_id=4     flags=0x0000 ifindex=10  mac=BA:A6:23:2C:9D:50 nodemac=9A:5A:C7:3A:36:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.057Z",
  "value": "id=87    sec_id=931810 flags=0x0000 ifindex=12  mac=E2:CA:7A:F9:F5:52 nodemac=F6:62:D6:98:5B:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:31.985Z",
  "value": "id=87    sec_id=931810 flags=0x0000 ifindex=12  mac=E2:CA:7A:F9:F5:52 nodemac=F6:62:D6:98:5B:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:31.986Z",
  "value": "id=3445  sec_id=931810 flags=0x0000 ifindex=14  mac=82:CF:51:23:2C:B3 nodemac=C6:02:B7:54:4E:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:31.986Z",
  "value": "id=165   sec_id=4     flags=0x0000 ifindex=10  mac=BA:A6:23:2C:9D:50 nodemac=9A:5A:C7:3A:36:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:32.017Z",
  "value": "id=1540  sec_id=919666 flags=0x0000 ifindex=16  mac=0A:3E:2E:A1:DC:4B nodemac=4A:F2:BB:DB:A6:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:32.986Z",
  "value": "id=3445  sec_id=931810 flags=0x0000 ifindex=14  mac=82:CF:51:23:2C:B3 nodemac=C6:02:B7:54:4E:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:32.986Z",
  "value": "id=165   sec_id=4     flags=0x0000 ifindex=10  mac=BA:A6:23:2C:9D:50 nodemac=9A:5A:C7:3A:36:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:32.987Z",
  "value": "id=87    sec_id=931810 flags=0x0000 ifindex=12  mac=E2:CA:7A:F9:F5:52 nodemac=F6:62:D6:98:5B:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:32.987Z",
  "value": "id=1540  sec_id=919666 flags=0x0000 ifindex=16  mac=0A:3E:2E:A1:DC:4B nodemac=4A:F2:BB:DB:A6:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.663Z",
  "value": "id=2901  sec_id=919666 flags=0x0000 ifindex=18  mac=66:0A:28:A7:96:D2 nodemac=16:38:92:36:7C:3A"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.27.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.236Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.608Z",
  "value": "id=165   sec_id=4     flags=0x0000 ifindex=10  mac=BA:A6:23:2C:9D:50 nodemac=9A:5A:C7:3A:36:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.609Z",
  "value": "id=87    sec_id=931810 flags=0x0000 ifindex=12  mac=E2:CA:7A:F9:F5:52 nodemac=F6:62:D6:98:5B:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.609Z",
  "value": "id=3445  sec_id=931810 flags=0x0000 ifindex=14  mac=82:CF:51:23:2C:B3 nodemac=C6:02:B7:54:4E:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.609Z",
  "value": "id=2901  sec_id=919666 flags=0x0000 ifindex=18  mac=66:0A:28:A7:96:D2 nodemac=16:38:92:36:7C:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.608Z",
  "value": "id=87    sec_id=931810 flags=0x0000 ifindex=12  mac=E2:CA:7A:F9:F5:52 nodemac=F6:62:D6:98:5B:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.609Z",
  "value": "id=3445  sec_id=931810 flags=0x0000 ifindex=14  mac=82:CF:51:23:2C:B3 nodemac=C6:02:B7:54:4E:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.609Z",
  "value": "id=2901  sec_id=919666 flags=0x0000 ifindex=18  mac=66:0A:28:A7:96:D2 nodemac=16:38:92:36:7C:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.610Z",
  "value": "id=165   sec_id=4     flags=0x0000 ifindex=10  mac=BA:A6:23:2C:9D:50 nodemac=9A:5A:C7:3A:36:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.608Z",
  "value": "id=3445  sec_id=931810 flags=0x0000 ifindex=14  mac=82:CF:51:23:2C:B3 nodemac=C6:02:B7:54:4E:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.608Z",
  "value": "id=165   sec_id=4     flags=0x0000 ifindex=10  mac=BA:A6:23:2C:9D:50 nodemac=9A:5A:C7:3A:36:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.608Z",
  "value": "id=2901  sec_id=919666 flags=0x0000 ifindex=18  mac=66:0A:28:A7:96:D2 nodemac=16:38:92:36:7C:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.608Z",
  "value": "id=87    sec_id=931810 flags=0x0000 ifindex=12  mac=E2:CA:7A:F9:F5:52 nodemac=F6:62:D6:98:5B:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.608Z",
  "value": "id=87    sec_id=931810 flags=0x0000 ifindex=12  mac=E2:CA:7A:F9:F5:52 nodemac=F6:62:D6:98:5B:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.609Z",
  "value": "id=165   sec_id=4     flags=0x0000 ifindex=10  mac=BA:A6:23:2C:9D:50 nodemac=9A:5A:C7:3A:36:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.609Z",
  "value": "id=3445  sec_id=931810 flags=0x0000 ifindex=14  mac=82:CF:51:23:2C:B3 nodemac=C6:02:B7:54:4E:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.609Z",
  "value": "id=2901  sec_id=919666 flags=0x0000 ifindex=18  mac=66:0A:28:A7:96:D2 nodemac=16:38:92:36:7C:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.609Z",
  "value": "id=165   sec_id=4     flags=0x0000 ifindex=10  mac=BA:A6:23:2C:9D:50 nodemac=9A:5A:C7:3A:36:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.610Z",
  "value": "id=87    sec_id=931810 flags=0x0000 ifindex=12  mac=E2:CA:7A:F9:F5:52 nodemac=F6:62:D6:98:5B:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.610Z",
  "value": "id=3445  sec_id=931810 flags=0x0000 ifindex=14  mac=82:CF:51:23:2C:B3 nodemac=C6:02:B7:54:4E:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.27.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.610Z",
  "value": "id=2901  sec_id=919666 flags=0x0000 ifindex=18  mac=66:0A:28:A7:96:D2 nodemac=16:38:92:36:7C:3A"
}

