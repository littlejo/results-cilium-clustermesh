IP ADDRESS         LOCAL ENDPOINT INFO
10.27.0.40:0       id=2901  sec_id=919666 flags=0x0000 ifindex=18  mac=66:0A:28:A7:96:D2 nodemac=16:38:92:36:7C:3A   
172.31.193.237:0   (localhost)                                                                                       
10.27.0.232:0      (localhost)                                                                                       
10.27.0.15:0       id=87    sec_id=931810 flags=0x0000 ifindex=12  mac=E2:CA:7A:F9:F5:52 nodemac=F6:62:D6:98:5B:C9   
172.31.252.239:0   (localhost)                                                                                       
10.27.0.105:0      id=165   sec_id=4     flags=0x0000 ifindex=10  mac=BA:A6:23:2C:9D:50 nodemac=9A:5A:C7:3A:36:E3    
10.27.0.137:0      id=3445  sec_id=931810 flags=0x0000 ifindex=14  mac=82:CF:51:23:2C:B3 nodemac=C6:02:B7:54:4E:42   
