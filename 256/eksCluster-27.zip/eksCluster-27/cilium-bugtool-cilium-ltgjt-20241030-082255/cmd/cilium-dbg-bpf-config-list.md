KEY             VALUE
AgentLiveness   2337494954555
UTimeOffset     3379441933593750
