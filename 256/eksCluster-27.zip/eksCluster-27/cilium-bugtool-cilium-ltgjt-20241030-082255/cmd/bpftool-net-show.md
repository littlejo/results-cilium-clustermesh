xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 570
ens6(5) clsact/ingress cil_from_netdev-ens6 id 574
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 560
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 553
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 519
lxc0195db0647a2(12) clsact/ingress cil_from_container-lxc0195db0647a2 id 538
lxc4d54cbd1dd5f(14) clsact/ingress cil_from_container-lxc4d54cbd1dd5f id 511
lxcd84486c64cda(18) clsact/ingress cil_from_container-lxcd84486c64cda id 630

flow_dissector:

netfilter:

