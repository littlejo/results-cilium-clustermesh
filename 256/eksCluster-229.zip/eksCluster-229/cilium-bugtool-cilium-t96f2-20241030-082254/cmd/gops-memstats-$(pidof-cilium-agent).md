alloc: 157.01MB (164635376 bytes)
total-alloc: 2.23GB (2393864448 bytes)
sys: 333.02MB (349196644 bytes)
lookups: 0
mallocs: 63177364
frees: 61841019
heap-alloc: 157.01MB (164635376 bytes)
heap-sys: 255.27MB (267665408 bytes)
heap-idle: 58.35MB (61186048 bytes)
heap-in-use: 196.91MB (206479360 bytes)
heap-released: 8.33MB (8732672 bytes)
heap-objects: 1336345
stack-in-use: 64.69MB (67829760 bytes)
stack-sys: 64.69MB (67829760 bytes)
stack-mspan-inuse: 3.08MB (3231840 bytes)
stack-mspan-sys: 3.89MB (4080000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.17MB (1223241 bytes)
gc-sys: 6.03MB (6321664 bytes)
next-gc: when heap-alloc >= 215.43MB (225899768 bytes)
last-gc: 2024-10-30 08:23:07.138644336 +0000 UTC
gc-pause-total: 17.281496ms
gc-pause: 125179
gc-pause-end: 1730276587138644336
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005440618665839231
enable-gc: true
debug-gc: false
