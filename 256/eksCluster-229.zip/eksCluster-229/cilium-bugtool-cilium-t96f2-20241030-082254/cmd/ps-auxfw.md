USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         671  0.0  0.2 1240432 16576 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         686  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         687  0.0  0.0   3852  1296 ?        R    08:22   0:00  \_ bash -c hostname
root         650  0.0  0.0 1228744 3780 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         638  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         637  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         632  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  4.1  4.7 1606336 382840 ?      Ssl  08:03   0:47 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.1  0.0 1229488 6872 ?        Sl   08:04   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
