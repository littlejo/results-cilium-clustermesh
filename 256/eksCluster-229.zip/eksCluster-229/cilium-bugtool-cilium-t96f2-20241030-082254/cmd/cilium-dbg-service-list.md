ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.162.152:443 (active)    
                                         2 => 172.31.213.189:443 (active)    
2    10.100.48.228:443    ClusterIP      1 => 172.31.218.213:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.229.0.147:9153 (active)     
                                         2 => 10.229.0.187:9153 (active)     
4    10.100.0.10:53       ClusterIP      1 => 10.229.0.147:53 (active)       
                                         2 => 10.229.0.187:53 (active)       
5    10.100.72.255:2379   ClusterIP      1 => 10.229.0.47:2379 (active)      
