markdown output at /tmp/cilium-bugtool-20241030-082254.864+0000-UTC-2053582476/cmd/cilium-debuginfo-20241030-082325.925+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082254.864+0000-UTC-2053582476/cmd/cilium-debuginfo-20241030-082325.925+0000-UTC.json
