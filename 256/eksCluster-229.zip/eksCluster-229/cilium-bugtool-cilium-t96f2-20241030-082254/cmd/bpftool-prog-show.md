35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:55:55+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:55:56+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:55:57+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:55:57+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:55:57+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:55:57+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:56:01+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:56:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:04:08+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 124
485: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:04:08+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
486: sched_cls  name tail_handle_ipv4  tag 0ff01db3c8ecf9b2  gpl
	loaded_at 2024-10-30T08:04:08+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
487: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:04:08+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
520: sched_cls  name tail_ipv4_to_endpoint  tag 178a13f547197a3c  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,111,40,37,38
	btf_id 163
521: sched_cls  name __send_drop_notify  tag ad7a5187aaa96583  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 168
523: sched_cls  name tail_handle_arp  tag d2fca4448a500160  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 170
525: sched_cls  name tail_handle_ipv4  tag 5d3b8607d9a0cae0  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 171
529: sched_cls  name handle_policy  tag 70403b608ff90d1f  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 173
530: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 177
533: sched_cls  name tail_ipv4_ct_egress  tag 687d578c5aaacf2d  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 178
534: sched_cls  name cil_from_container  tag 7fd06b8dc3b2ed9e  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 180
535: sched_cls  name tail_handle_ipv4_cont  tag 53b085a040884ed6  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,111,40,37,38,81
	btf_id 182
537: sched_cls  name tail_ipv4_ct_ingress  tag 891ce784a9810862  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 183
538: sched_cls  name tail_handle_arp  tag 9fe43117960efbbf  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 185
539: sched_cls  name cil_from_container  tag 76aa90d770eed413  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 186
540: sched_cls  name tail_handle_ipv4_cont  tag e80b01a4c41d8ee1  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 187
541: sched_cls  name tail_handle_ipv4_from_host  tag 74241f9744d365f2  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 189
542: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 191
544: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 193
545: sched_cls  name __send_drop_notify  tag 10623b7a686f154a  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 194
546: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,118
	btf_id 195
547: sched_cls  name tail_ipv4_ct_egress  tag 687d578c5aaacf2d  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 190
550: sched_cls  name __send_drop_notify  tag 5f3a190495ab3fc7  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 198
551: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 201
552: sched_cls  name __send_drop_notify  tag 10623b7a686f154a  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 202
555: sched_cls  name tail_ipv4_ct_ingress  tag de47698cb2dcea16  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 199
556: sched_cls  name tail_handle_ipv4_from_host  tag 74241f9744d365f2  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 205
557: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 206
559: sched_cls  name tail_handle_ipv4  tag a5411e8cb1083ef3  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 207
560: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 210
561: sched_cls  name __send_drop_notify  tag 10623b7a686f154a  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 211
564: sched_cls  name tail_handle_ipv4_from_host  tag 74241f9744d365f2  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 214
566: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 216
567: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 218
568: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 219
569: sched_cls  name __send_drop_notify  tag 10623b7a686f154a  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 220
572: sched_cls  name tail_handle_ipv4_from_host  tag 74241f9744d365f2  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 223
574: sched_cls  name tail_ipv4_to_endpoint  tag 1f13285ccd1704a0  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,126,41,82,83,80,100,39,125,40,37,38
	btf_id 226
575: sched_cls  name tail_handle_arp  tag 54c4c595136efc0d  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 228
576: sched_cls  name tail_ipv4_to_endpoint  tag 36a0595dfb2da1f3  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 227
577: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 229
578: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 230
579: sched_cls  name tail_handle_ipv4_cont  tag 96d7e13151e6eaac  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,126,41,100,82,83,39,76,74,77,125,40,37,38,81
	btf_id 231
580: sched_cls  name tail_handle_ipv4  tag 6238b276c26ea141  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 233
582: sched_cls  name handle_policy  tag b2211704e518a1e2  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 232
583: sched_cls  name handle_policy  tag d663f405c4ae11d9  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,125,82,83,126,41,80,100,39,84,75,40,37,38
	btf_id 235
584: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 236
585: sched_cls  name tail_ipv4_ct_ingress  tag 603663ede0e0ac6d  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 237
586: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
589: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
590: sched_cls  name __send_drop_notify  tag b433561100f6ebc1  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 238
591: sched_cls  name cil_from_container  tag cfd139146b55c940  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 125,76
	btf_id 239
592: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
595: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
596: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
599: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:04:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
643: sched_cls  name tail_ipv4_ct_egress  tag edb3945d1aad1c2e  gpl
	loaded_at 2024-10-30T08:11:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 253
644: sched_cls  name handle_policy  tag 164fca9280d04dce  gpl
	loaded_at 2024-10-30T08:11:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 254
645: sched_cls  name __send_drop_notify  tag 0b55fad0573d472f  gpl
	loaded_at 2024-10-30T08:11:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 255
646: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:11:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 256
647: sched_cls  name tail_ipv4_ct_ingress  tag d983226b8e9bc36a  gpl
	loaded_at 2024-10-30T08:11:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 257
648: sched_cls  name tail_handle_ipv4_cont  tag 060c47da05280d7f  gpl
	loaded_at 2024-10-30T08:11:28+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 258
649: sched_cls  name tail_ipv4_to_endpoint  tag 203b4c17919f1609  gpl
	loaded_at 2024-10-30T08:11:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 259
650: sched_cls  name cil_from_container  tag b7065533a8b6178b  gpl
	loaded_at 2024-10-30T08:11:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 260
651: sched_cls  name tail_handle_ipv4  tag 35a37f337c97ad44  gpl
	loaded_at 2024-10-30T08:11:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 261
652: sched_cls  name tail_handle_arp  tag 8317c3f1e928c6ca  gpl
	loaded_at 2024-10-30T08:11:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 262
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
670: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
673: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
674: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
677: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
678: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
681: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
