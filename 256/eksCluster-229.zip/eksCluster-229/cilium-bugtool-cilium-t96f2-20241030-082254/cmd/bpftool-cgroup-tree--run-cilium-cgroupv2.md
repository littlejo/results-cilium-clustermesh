CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod94ec06d6_38ea_424e_ba61_ac3dfa97c272.slice/cri-containerd-a795042e82681e7d35ab13d211414311e678631d956b1d50dcea44bad1e53ff0.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod94ec06d6_38ea_424e_ba61_ac3dfa97c272.slice/cri-containerd-59d534b6fe7e7527b45b3217ad42a63144c8bd59b127dfe828c320834f1d3b20.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1433c19e_b1e5_42ba_99c5_8e437201bb48.slice/cri-containerd-7e25d4ad58398e14f1cc50dd1f46c7ec579486e3c199734c0885d3b21e65dfe9.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1433c19e_b1e5_42ba_99c5_8e437201bb48.slice/cri-containerd-6d610cca5b70bc266b898cd2d96ea04ca1495dfdfa7a29133c5938ff46bbcb93.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04a31cc7_6d81_47f1_a85f_bb5ed970f818.slice/cri-containerd-5dbb5abae3d5e4970a58d868a1099e74ef33ca7545d86bea20e34943a667780a.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04a31cc7_6d81_47f1_a85f_bb5ed970f818.slice/cri-containerd-b1962eeefed256425b39f23c981a67c28e2d813648da2d59f0bd7f96594b52d8.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod097ec6e3_74bc_476a_a431_8d08f5d8b1dd.slice/cri-containerd-df0186622b77dc123c6a03b0f6ada7dc9debae9c3578e5fcfd9d6be5341f34e8.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod097ec6e3_74bc_476a_a431_8d08f5d8b1dd.slice/cri-containerd-2f80eeba92f9e799b3251cea2dc405394a9bd608d80064c46e9dd0cb4f4374b7.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod07f9e828_3665_4d37_9fb8_2e9400869f43.slice/cri-containerd-efe61638eada514fdcfa07231d241a48ab35fc904a9fa77d69d0c423c54da29d.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod07f9e828_3665_4d37_9fb8_2e9400869f43.slice/cri-containerd-7df589725ed1d3675515ae720524c0fa87da8f546c2b6b17071bd9e19514dfac.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod07f9e828_3665_4d37_9fb8_2e9400869f43.slice/cri-containerd-9d507eda486b0768cf242ff37dc187d83e1888feaf97cce6560cf3e9b6159f62.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod07f9e828_3665_4d37_9fb8_2e9400869f43.slice/cri-containerd-eba0529092e6678b6e42b52b3580b12745f41c9483bb10d6234dfc31fda31259.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf06c29df_da3d_4f08_a0df_cce2af47eade.slice/cri-containerd-056e8c2297d6b46d2d0041f369deb3ddd2c2ce00f04b9f8beef13938bac037e5.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf06c29df_da3d_4f08_a0df_cce2af47eade.slice/cri-containerd-a03db4e8b7312cf9664a5ee3de5b27146a842d065ace08d021c836f9274cfec6.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod28d220b2_f13d_4c13_a1e9_34fff313d966.slice/cri-containerd-678511d1c5b58d8af4b148fdbd7a1bac511f15289178a1f0c89bc3f7754b8967.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod28d220b2_f13d_4c13_a1e9_34fff313d966.slice/cri-containerd-12199c386d5dec4109be93301e8a63b046bdd07f45b12cebce6a2f489c7b7808.scope
    93       cgroup_device   multi                                          
