xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 566
ens6(5) clsact/ingress cil_from_netdev-ens6 id 567
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 557
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 542
cilium_host(7) clsact/egress cil_from_host-cilium_host id 546
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 591
lxce0fca58b9e37(12) clsact/ingress cil_from_container-lxce0fca58b9e37 id 534
lxc6f84e601ee24(14) clsact/ingress cil_from_container-lxc6f84e601ee24 id 539
lxcda74bff1c1cf(18) clsact/ingress cil_from_container-lxcda74bff1c1cf id 650

flow_dissector:

netfilter:

