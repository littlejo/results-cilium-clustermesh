IP ADDRESS         LOCAL ENDPOINT INFO
172.31.206.125:0   (localhost)                                                                                        
172.31.218.213:0   (localhost)                                                                                        
10.229.0.147:0     id=3339  sec_id=7538575 flags=0x0000 ifindex=12  mac=3E:F2:F5:C0:BF:83 nodemac=36:9E:C2:C5:37:1C   
10.229.0.125:0     id=2241  sec_id=4     flags=0x0000 ifindex=10  mac=B2:44:49:F4:D9:7F nodemac=46:E3:70:12:F9:BE     
10.229.0.187:0     id=1738  sec_id=7538575 flags=0x0000 ifindex=14  mac=1E:C3:C6:BC:F3:5A nodemac=D2:B2:42:F8:91:B6   
10.229.0.174:0     (localhost)                                                                                        
10.229.0.47:0      id=1629  sec_id=7541860 flags=0x0000 ifindex=18  mac=D6:51:48:D0:E8:9D nodemac=DA:3C:B5:04:D6:25   
