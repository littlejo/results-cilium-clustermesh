1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:a7:24:87:d9:77 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.218.213/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1989sec preferred_lft 1989sec
    inet6 fe80::8a7:24ff:fe87:d977/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:9b:35:a7:36:cb brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.206.125/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::89b:35ff:fea7:36cb/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:c1:16:21:1a:38 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::58c1:16ff:fe21:1a38/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:e7:4c:8f:fe:4a brd ff:ff:ff:ff:ff:ff
    inet 10.229.0.174/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b0e7:4cff:fe8f:fe4a/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 36:e5:4e:f1:ca:61 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::34e5:4eff:fef1:ca61/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:e3:70:12:f9:be brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::44e3:70ff:fe12:f9be/64 scope link 
       valid_lft forever preferred_lft forever
12: lxce0fca58b9e37@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:9e:c2:c5:37:1c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::349e:c2ff:fec5:371c/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc6f84e601ee24@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:b2:42:f8:91:b6 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d0b2:42ff:fef8:91b6/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcda74bff1c1cf@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:3c:b5:04:d6:25 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d83c:b5ff:fe04:d625/64 scope link 
       valid_lft forever preferred_lft forever
