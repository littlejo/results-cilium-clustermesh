Endpoint ID: 78
Path: /sys/fs/bpf/tc/globals/cilium_policy_00078

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1629
Path: /sys/fs/bpf/tc/globals/cilium_policy_01629

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11463510   113607    0        
Allow    Ingress     1          ANY          NONE         disabled    9933123    104406    0        
Allow    Egress      0          ANY          NONE         disabled    12208326   120804    0        


Endpoint ID: 1738
Path: /sys/fs/bpf/tc/globals/cilium_policy_01738

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    109159   1250      0        
Allow    Egress      0          ANY          NONE         disabled    16859    181       0        


Endpoint ID: 2241
Path: /sys/fs/bpf/tc/globals/cilium_policy_02241

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1656901   20917     0        
Allow    Ingress     1          ANY          NONE         disabled    17708     209       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3339
Path: /sys/fs/bpf/tc/globals/cilium_policy_03339

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    109225   1251      0        
Allow    Egress      0          ANY          NONE         disabled    16326    176       0        


