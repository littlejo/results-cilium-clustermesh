REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36782     2912585     677    bpf_overlay.c
Interface                 INGRESS     633929    130493023   1132   bpf_host.c
Success                   EGRESS      16548     1302111     1694   bpf_host.c
Success                   EGRESS      265619    33481466    1308   bpf_lxc.c
Success                   EGRESS      36955     2924613     53     encap.h
Success                   INGRESS     309743    34799718    86     l3.h
Success                   INGRESS     330628    36454238    235    trace.h
Unsupported L3 protocol   EGRESS      39        2902        1492   bpf_lxc.c
