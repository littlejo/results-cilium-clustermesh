{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:06.006Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.206.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:06.006Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.218.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:06.006Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.527Z",
  "value": "id=2241  sec_id=4     flags=0x0000 ifindex=10  mac=B2:44:49:F4:D9:7F nodemac=46:E3:70:12:F9:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.528Z",
  "value": "id=3339  sec_id=7538575 flags=0x0000 ifindex=12  mac=3E:F2:F5:C0:BF:83 nodemac=36:9E:C2:C5:37:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.592Z",
  "value": "id=1738  sec_id=7538575 flags=0x0000 ifindex=14  mac=1E:C3:C6:BC:F3:5A nodemac=D2:B2:42:F8:91:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.616Z",
  "value": "id=2241  sec_id=4     flags=0x0000 ifindex=10  mac=B2:44:49:F4:D9:7F nodemac=46:E3:70:12:F9:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:14.083Z",
  "value": "id=3339  sec_id=7538575 flags=0x0000 ifindex=12  mac=3E:F2:F5:C0:BF:83 nodemac=36:9E:C2:C5:37:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:14.084Z",
  "value": "id=1738  sec_id=7538575 flags=0x0000 ifindex=14  mac=1E:C3:C6:BC:F3:5A nodemac=D2:B2:42:F8:91:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:14.084Z",
  "value": "id=2241  sec_id=4     flags=0x0000 ifindex=10  mac=B2:44:49:F4:D9:7F nodemac=46:E3:70:12:F9:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:14.116Z",
  "value": "id=731   sec_id=7541860 flags=0x0000 ifindex=16  mac=76:32:A0:E0:D2:7A nodemac=C6:59:C4:51:C8:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:15.083Z",
  "value": "id=2241  sec_id=4     flags=0x0000 ifindex=10  mac=B2:44:49:F4:D9:7F nodemac=46:E3:70:12:F9:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:15.083Z",
  "value": "id=1738  sec_id=7538575 flags=0x0000 ifindex=14  mac=1E:C3:C6:BC:F3:5A nodemac=D2:B2:42:F8:91:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:15.083Z",
  "value": "id=3339  sec_id=7538575 flags=0x0000 ifindex=12  mac=3E:F2:F5:C0:BF:83 nodemac=36:9E:C2:C5:37:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:15.083Z",
  "value": "id=731   sec_id=7541860 flags=0x0000 ifindex=16  mac=76:32:A0:E0:D2:7A nodemac=C6:59:C4:51:C8:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.314Z",
  "value": "id=1629  sec_id=7541860 flags=0x0000 ifindex=18  mac=D6:51:48:D0:E8:9D nodemac=DA:3C:B5:04:D6:25"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.229.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:34.786Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.310Z",
  "value": "id=1629  sec_id=7541860 flags=0x0000 ifindex=18  mac=D6:51:48:D0:E8:9D nodemac=DA:3C:B5:04:D6:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.311Z",
  "value": "id=2241  sec_id=4     flags=0x0000 ifindex=10  mac=B2:44:49:F4:D9:7F nodemac=46:E3:70:12:F9:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.311Z",
  "value": "id=3339  sec_id=7538575 flags=0x0000 ifindex=12  mac=3E:F2:F5:C0:BF:83 nodemac=36:9E:C2:C5:37:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.311Z",
  "value": "id=1738  sec_id=7538575 flags=0x0000 ifindex=14  mac=1E:C3:C6:BC:F3:5A nodemac=D2:B2:42:F8:91:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.316Z",
  "value": "id=1629  sec_id=7541860 flags=0x0000 ifindex=18  mac=D6:51:48:D0:E8:9D nodemac=DA:3C:B5:04:D6:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.319Z",
  "value": "id=2241  sec_id=4     flags=0x0000 ifindex=10  mac=B2:44:49:F4:D9:7F nodemac=46:E3:70:12:F9:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.319Z",
  "value": "id=3339  sec_id=7538575 flags=0x0000 ifindex=12  mac=3E:F2:F5:C0:BF:83 nodemac=36:9E:C2:C5:37:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.320Z",
  "value": "id=1738  sec_id=7538575 flags=0x0000 ifindex=14  mac=1E:C3:C6:BC:F3:5A nodemac=D2:B2:42:F8:91:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.311Z",
  "value": "id=1738  sec_id=7538575 flags=0x0000 ifindex=14  mac=1E:C3:C6:BC:F3:5A nodemac=D2:B2:42:F8:91:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.311Z",
  "value": "id=1629  sec_id=7541860 flags=0x0000 ifindex=18  mac=D6:51:48:D0:E8:9D nodemac=DA:3C:B5:04:D6:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.312Z",
  "value": "id=2241  sec_id=4     flags=0x0000 ifindex=10  mac=B2:44:49:F4:D9:7F nodemac=46:E3:70:12:F9:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.312Z",
  "value": "id=3339  sec_id=7538575 flags=0x0000 ifindex=12  mac=3E:F2:F5:C0:BF:83 nodemac=36:9E:C2:C5:37:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.311Z",
  "value": "id=1629  sec_id=7541860 flags=0x0000 ifindex=18  mac=D6:51:48:D0:E8:9D nodemac=DA:3C:B5:04:D6:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.311Z",
  "value": "id=2241  sec_id=4     flags=0x0000 ifindex=10  mac=B2:44:49:F4:D9:7F nodemac=46:E3:70:12:F9:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.312Z",
  "value": "id=3339  sec_id=7538575 flags=0x0000 ifindex=12  mac=3E:F2:F5:C0:BF:83 nodemac=36:9E:C2:C5:37:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.229.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.312Z",
  "value": "id=1738  sec_id=7538575 flags=0x0000 ifindex=14  mac=1E:C3:C6:BC:F3:5A nodemac=D2:B2:42:F8:91:B6"
}

