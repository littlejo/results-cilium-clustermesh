 08:22:54 up 27 min,  0 users,  load average: 0.15, 0.21, 0.19
