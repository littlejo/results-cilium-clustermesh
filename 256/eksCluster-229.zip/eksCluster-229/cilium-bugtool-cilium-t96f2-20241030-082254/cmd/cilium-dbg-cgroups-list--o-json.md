[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod07f9e828_3665_4d37_9fb8_2e9400869f43.slice/cri-containerd-7df589725ed1d3675515ae720524c0fa87da8f546c2b6b17071bd9e19514dfac.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod07f9e828_3665_4d37_9fb8_2e9400869f43.slice/cri-containerd-9d507eda486b0768cf242ff37dc187d83e1888feaf97cce6560cf3e9b6159f62.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod07f9e828_3665_4d37_9fb8_2e9400869f43.slice/cri-containerd-eba0529092e6678b6e42b52b3580b12745f41c9483bb10d6234dfc31fda31259.scope"
      }
    ],
    "ips": [
      "10.229.0.47"
    ],
    "name": "clustermesh-apiserver-7cc74f7d84-rb9xz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1433c19e_b1e5_42ba_99c5_8e437201bb48.slice/cri-containerd-6d610cca5b70bc266b898cd2d96ea04ca1495dfdfa7a29133c5938ff46bbcb93.scope"
      }
    ],
    "ips": [
      "10.229.0.187"
    ],
    "name": "coredns-cc6ccd49c-x85zm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04a31cc7_6d81_47f1_a85f_bb5ed970f818.slice/cri-containerd-5dbb5abae3d5e4970a58d868a1099e74ef33ca7545d86bea20e34943a667780a.scope"
      }
    ],
    "ips": [
      "10.229.0.147"
    ],
    "name": "coredns-cc6ccd49c-pg776",
    "namespace": "kube-system"
  }
]

