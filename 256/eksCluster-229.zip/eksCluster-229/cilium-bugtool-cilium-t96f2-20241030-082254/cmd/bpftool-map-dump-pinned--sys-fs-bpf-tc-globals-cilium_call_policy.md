key: 5d 06 00 00  value: 84 02 00 00
key: ca 06 00 00  value: 46 02 00 00
key: c1 08 00 00  value: 47 02 00 00
key: 0b 0d 00 00  value: 11 02 00 00
Found 4 elements
