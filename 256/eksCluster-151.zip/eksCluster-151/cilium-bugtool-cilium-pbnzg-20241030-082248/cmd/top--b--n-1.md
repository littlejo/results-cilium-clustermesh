top - 08:22:49 up 32 min,  0 users,  load average: 0.10, 0.27, 0.22
Tasks:  11 total,   2 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 62.1 us, 24.1 sy,  0.0 ni, 13.8 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4475.0 free,   1192.7 used,   2146.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6436.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 390040  78268 S 100.0   4.9   0:57.06 cilium-+
    414 root      20   0 1229488   7936   3836 S   0.0   0.1   0:01.18 cilium-+
    637 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    638 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    645 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    657 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    663 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    690 root      20   0 1240432  16628  11420 S   0.0   0.2   0:00.02 cilium-+
    722 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    740 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    746 root      20   0 1484936   8040   5928 R   0.0   0.1   0:00.00 runc:[2+
