filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc77a5f64ad634 direct-action not_in_hw id 514 tag ebbf0c41f7025f01 jited 
