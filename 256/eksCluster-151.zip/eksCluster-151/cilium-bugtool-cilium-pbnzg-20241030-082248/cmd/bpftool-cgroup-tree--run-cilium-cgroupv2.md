CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda5a03097_598b_4179_8e59_1fb72ff17176.slice/cri-containerd-88ed3f16915c6bc2682ba95d659efb4e1277a21ea8bb469c95ddd72357edbb10.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda5a03097_598b_4179_8e59_1fb72ff17176.slice/cri-containerd-6df042a037c925d7791130831551f089eb65406283558b9ef2a60adb3a90bfed.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9635aba5_4a0f_44e0_9e4e_b956f655e3b7.slice/cri-containerd-0da41d8da734a86614b98262f8589dd401f9b9593e40d5fe25d5bf9ff6cad3a2.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9635aba5_4a0f_44e0_9e4e_b956f655e3b7.slice/cri-containerd-3d0414517090d6646815a0f7507cfe93146a34e783646347beb01e5ba29e8167.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda2f0c7c0_bb57_4290_ab26_70d4eefc3bfb.slice/cri-containerd-40da421ff64ec42952c97af2eae9ed92f1a38bd639e4d739b5511a36b004bc05.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda2f0c7c0_bb57_4290_ab26_70d4eefc3bfb.slice/cri-containerd-4aeec74fd09cd4e698b57c751dcebea3105457fc311e4f6930fc5ec58c8683ce.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb8d044a1_f4eb_4428_980e_432a5a996382.slice/cri-containerd-f92d04ed0171bbf838f6893ce185827128186152b4a55501d49359091cb698f9.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb8d044a1_f4eb_4428_980e_432a5a996382.slice/cri-containerd-bda24c86fea1350d7dc08f62379da4b2241c599f83f7bddac7ce47635c89c3d8.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57269694_40c3_4a5d_a654_ad5b8fff558c.slice/cri-containerd-4787b1d7d14fc2614f6ef0da867be09f8d5d8248abac923087f945fe87db465f.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57269694_40c3_4a5d_a654_ad5b8fff558c.slice/cri-containerd-a7a817315944b579ffee505f54451d7393869a70b1c0ea8a0a2438c8a0a7c5f6.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod726be3a3_a88f_41c4_8225_8cbf9b7eeb2f.slice/cri-containerd-ccaa9e130c9fa71464009f5a674fd459e1cefaa853c0ea1c3f3ab97c42b41bbc.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod726be3a3_a88f_41c4_8225_8cbf9b7eeb2f.slice/cri-containerd-09653586e299a223ff4636e68ac12390a64e2ec32af92ba2fc4af8d9281d655e.scope
    110      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6af551af_64ec_41d8_b6f6_8a3a45eb0e20.slice/cri-containerd-bdd6e27162f7bce3bf41c21d444d9d784860eb330d844872ed0c6c399574615f.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6af551af_64ec_41d8_b6f6_8a3a45eb0e20.slice/cri-containerd-49b8dccabb1bbfdffec0394d403333f9d8c4773c3de489107665bdfe2fc5fcaa.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6af551af_64ec_41d8_b6f6_8a3a45eb0e20.slice/cri-containerd-5447c1965d50e30fd9fa13f37921d14f8cc55cdc77b143b7874b9a5cd4ee7148.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6af551af_64ec_41d8_b6f6_8a3a45eb0e20.slice/cri-containerd-a16a874bd64661460996c3c6f3ba7c38f9e7b1df86c24192795e9ea0327eb57d.scope
    661      cgroup_device   multi                                          
