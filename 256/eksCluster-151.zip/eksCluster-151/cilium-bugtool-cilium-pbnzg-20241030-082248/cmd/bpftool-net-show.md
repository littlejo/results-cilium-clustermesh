xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 574
ens6(5) clsact/ingress cil_from_netdev-ens6 id 579
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 565
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 561
cilium_host(7) clsact/egress cil_from_host-cilium_host id 558
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 482
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 520
lxc02d51d965b6b(12) clsact/ingress cil_from_container-lxc02d51d965b6b id 545
lxc77a5f64ad634(14) clsact/ingress cil_from_container-lxc77a5f64ad634 id 514
lxc2159bde43874(18) clsact/ingress cil_from_container-lxc2159bde43874 id 623

flow_dissector:

netfilter:

