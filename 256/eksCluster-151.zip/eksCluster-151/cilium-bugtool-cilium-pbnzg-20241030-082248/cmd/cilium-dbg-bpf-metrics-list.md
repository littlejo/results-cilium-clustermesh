REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36536     2890869     677    bpf_overlay.c
Interface                 INGRESS     631997    130516531   1132   bpf_host.c
Success                   EGRESS      16583     1304269     1694   bpf_host.c
Success                   EGRESS      265648    33540026    1308   bpf_lxc.c
Success                   EGRESS      36754     2909291     53     encap.h
Success                   INGRESS     308874    34686405    86     l3.h
Success                   INGRESS     329478    36317051    235    trace.h
Unsupported L3 protocol   EGRESS      40        2972        1492   bpf_lxc.c
