{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:13.018Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.210.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:13.018Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.235.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:13.018Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:17.499Z",
  "value": "id=3137  sec_id=4     flags=0x0000 ifindex=10  mac=62:57:EE:EF:EB:DC nodemac=16:5B:DD:6C:2A:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:17.505Z",
  "value": "id=2128  sec_id=4995030 flags=0x0000 ifindex=12  mac=BE:38:17:93:D7:5B nodemac=76:EA:C4:74:AD:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:17.584Z",
  "value": "id=2340  sec_id=4995030 flags=0x0000 ifindex=14  mac=B2:F2:B9:64:42:D4 nodemac=86:BD:27:FE:64:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:17.676Z",
  "value": "id=3137  sec_id=4     flags=0x0000 ifindex=10  mac=62:57:EE:EF:EB:DC nodemac=16:5B:DD:6C:2A:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:17.762Z",
  "value": "id=2128  sec_id=4995030 flags=0x0000 ifindex=12  mac=BE:38:17:93:D7:5B nodemac=76:EA:C4:74:AD:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:03.123Z",
  "value": "id=3137  sec_id=4     flags=0x0000 ifindex=10  mac=62:57:EE:EF:EB:DC nodemac=16:5B:DD:6C:2A:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:03.123Z",
  "value": "id=2128  sec_id=4995030 flags=0x0000 ifindex=12  mac=BE:38:17:93:D7:5B nodemac=76:EA:C4:74:AD:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:03.124Z",
  "value": "id=2340  sec_id=4995030 flags=0x0000 ifindex=14  mac=B2:F2:B9:64:42:D4 nodemac=86:BD:27:FE:64:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:03.154Z",
  "value": "id=1586  sec_id=5010627 flags=0x0000 ifindex=16  mac=FA:44:14:F0:AC:FC nodemac=56:7C:92:93:3B:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:04.123Z",
  "value": "id=3137  sec_id=4     flags=0x0000 ifindex=10  mac=62:57:EE:EF:EB:DC nodemac=16:5B:DD:6C:2A:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:04.123Z",
  "value": "id=1586  sec_id=5010627 flags=0x0000 ifindex=16  mac=FA:44:14:F0:AC:FC nodemac=56:7C:92:93:3B:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:04.123Z",
  "value": "id=2128  sec_id=4995030 flags=0x0000 ifindex=12  mac=BE:38:17:93:D7:5B nodemac=76:EA:C4:74:AD:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:04.124Z",
  "value": "id=2340  sec_id=4995030 flags=0x0000 ifindex=14  mac=B2:F2:B9:64:42:D4 nodemac=86:BD:27:FE:64:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.532Z",
  "value": "id=2048  sec_id=5010627 flags=0x0000 ifindex=18  mac=72:6F:BF:C4:44:95 nodemac=FE:52:09:07:06:CD"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.151.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.968Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.274Z",
  "value": "id=2048  sec_id=5010627 flags=0x0000 ifindex=18  mac=72:6F:BF:C4:44:95 nodemac=FE:52:09:07:06:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.275Z",
  "value": "id=3137  sec_id=4     flags=0x0000 ifindex=10  mac=62:57:EE:EF:EB:DC nodemac=16:5B:DD:6C:2A:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.276Z",
  "value": "id=2128  sec_id=4995030 flags=0x0000 ifindex=12  mac=BE:38:17:93:D7:5B nodemac=76:EA:C4:74:AD:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.277Z",
  "value": "id=2340  sec_id=4995030 flags=0x0000 ifindex=14  mac=B2:F2:B9:64:42:D4 nodemac=86:BD:27:FE:64:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.275Z",
  "value": "id=2340  sec_id=4995030 flags=0x0000 ifindex=14  mac=B2:F2:B9:64:42:D4 nodemac=86:BD:27:FE:64:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.276Z",
  "value": "id=2048  sec_id=5010627 flags=0x0000 ifindex=18  mac=72:6F:BF:C4:44:95 nodemac=FE:52:09:07:06:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.276Z",
  "value": "id=3137  sec_id=4     flags=0x0000 ifindex=10  mac=62:57:EE:EF:EB:DC nodemac=16:5B:DD:6C:2A:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.276Z",
  "value": "id=2128  sec_id=4995030 flags=0x0000 ifindex=12  mac=BE:38:17:93:D7:5B nodemac=76:EA:C4:74:AD:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.274Z",
  "value": "id=2048  sec_id=5010627 flags=0x0000 ifindex=18  mac=72:6F:BF:C4:44:95 nodemac=FE:52:09:07:06:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.277Z",
  "value": "id=3137  sec_id=4     flags=0x0000 ifindex=10  mac=62:57:EE:EF:EB:DC nodemac=16:5B:DD:6C:2A:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.277Z",
  "value": "id=2128  sec_id=4995030 flags=0x0000 ifindex=12  mac=BE:38:17:93:D7:5B nodemac=76:EA:C4:74:AD:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.278Z",
  "value": "id=2340  sec_id=4995030 flags=0x0000 ifindex=14  mac=B2:F2:B9:64:42:D4 nodemac=86:BD:27:FE:64:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.275Z",
  "value": "id=2340  sec_id=4995030 flags=0x0000 ifindex=14  mac=B2:F2:B9:64:42:D4 nodemac=86:BD:27:FE:64:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.275Z",
  "value": "id=3137  sec_id=4     flags=0x0000 ifindex=10  mac=62:57:EE:EF:EB:DC nodemac=16:5B:DD:6C:2A:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.275Z",
  "value": "id=2048  sec_id=5010627 flags=0x0000 ifindex=18  mac=72:6F:BF:C4:44:95 nodemac=FE:52:09:07:06:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.276Z",
  "value": "id=2128  sec_id=4995030 flags=0x0000 ifindex=12  mac=BE:38:17:93:D7:5B nodemac=76:EA:C4:74:AD:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.276Z",
  "value": "id=2048  sec_id=5010627 flags=0x0000 ifindex=18  mac=72:6F:BF:C4:44:95 nodemac=FE:52:09:07:06:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.277Z",
  "value": "id=3137  sec_id=4     flags=0x0000 ifindex=10  mac=62:57:EE:EF:EB:DC nodemac=16:5B:DD:6C:2A:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.277Z",
  "value": "id=2128  sec_id=4995030 flags=0x0000 ifindex=12  mac=BE:38:17:93:D7:5B nodemac=76:EA:C4:74:AD:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.151.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.277Z",
  "value": "id=2340  sec_id=4995030 flags=0x0000 ifindex=14  mac=B2:F2:B9:64:42:D4 nodemac=86:BD:27:FE:64:0C"
}

