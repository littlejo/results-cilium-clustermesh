IP ADDRESS         LOCAL ENDPOINT INFO
10.151.0.100:0     id=2048  sec_id=5010627 flags=0x0000 ifindex=18  mac=72:6F:BF:C4:44:95 nodemac=FE:52:09:07:06:CD   
172.31.210.247:0   (localhost)                                                                                        
10.151.0.202:0     (localhost)                                                                                        
10.151.0.37:0      id=2128  sec_id=4995030 flags=0x0000 ifindex=12  mac=BE:38:17:93:D7:5B nodemac=76:EA:C4:74:AD:FA   
10.151.0.71:0      id=2340  sec_id=4995030 flags=0x0000 ifindex=14  mac=B2:F2:B9:64:42:D4 nodemac=86:BD:27:FE:64:0C   
10.151.0.73:0      id=3137  sec_id=4     flags=0x0000 ifindex=10  mac=62:57:EE:EF:EB:DC nodemac=16:5B:DD:6C:2A:B7     
172.31.235.78:0    (localhost)                                                                                        
