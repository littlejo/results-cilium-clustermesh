KEY             VALUE
AgentLiveness   1966576053852
UTimeOffset     3379442644531250
