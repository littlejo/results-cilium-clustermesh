1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:fc:29:cf:27:5f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.210.247/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3475sec preferred_lft 3475sec
    inet6 fe80::8fc:29ff:fecf:275f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:e1:96:51:20:67 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.235.78/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8e1:96ff:fe51:2067/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:2c:cb:12:b4:90 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::982c:cbff:fe12:b490/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:c4:76:69:2b:34 brd ff:ff:ff:ff:ff:ff
    inet 10.151.0.202/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::20c4:76ff:fe69:2b34/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 9e:d7:77:ed:c1:f7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9cd7:77ff:feed:c1f7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:5b:dd:6c:2a:b7 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::145b:ddff:fe6c:2ab7/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc02d51d965b6b@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:ea:c4:74:ad:fa brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::74ea:c4ff:fe74:adfa/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc77a5f64ad634@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:bd:27:fe:64:0c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::84bd:27ff:fefe:640c/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc2159bde43874@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:52:09:07:06:cd brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::fc52:9ff:fe07:6cd/64 scope link 
       valid_lft forever preferred_lft forever
