 08:22:49 up 32 min,  0 users,  load average: 0.10, 0.27, 0.22
