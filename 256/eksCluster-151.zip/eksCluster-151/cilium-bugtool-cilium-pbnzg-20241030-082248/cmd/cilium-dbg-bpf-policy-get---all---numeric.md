Endpoint ID: 2048
Path: /sys/fs/bpf/tc/globals/cilium_policy_02048

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11424774   113124    0        
Allow    Ingress     1          ANY          NONE         disabled    9922011    104233    0        
Allow    Egress      0          ANY          NONE         disabled    11994781   118578    0        


Endpoint ID: 2128
Path: /sys/fs/bpf/tc/globals/cilium_policy_02128

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    126723   1459      0        
Allow    Egress      0          ANY          NONE         disabled    17690    192       0        


Endpoint ID: 2340
Path: /sys/fs/bpf/tc/globals/cilium_policy_02340

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    126129   1450      0        
Allow    Egress      0          ANY          NONE         disabled    17444    189       0        


Endpoint ID: 3071
Path: /sys/fs/bpf/tc/globals/cilium_policy_03071

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3137
Path: /sys/fs/bpf/tc/globals/cilium_policy_03137

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1633722   20643     0        
Allow    Ingress     1          ANY          NONE         disabled    20098     237       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


