alloc: 178.96MB (187648944 bytes)
total-alloc: 2.24GB (2405607592 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 63259076
frees: 61181909
heap-alloc: 178.96MB (187648944 bytes)
heap-sys: 243.35MB (255172608 bytes)
heap-idle: 44.78MB (46956544 bytes)
heap-in-use: 198.57MB (208216064 bytes)
heap-released: 192.00KB (196608 bytes)
heap-objects: 2077167
stack-in-use: 64.62MB (67764224 bytes)
stack-sys: 64.62MB (67764224 bytes)
stack-mspan-inuse: 3.40MB (3563040 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1062761 bytes)
gc-sys: 5.99MB (6282728 bytes)
next-gc: when heap-alloc >= 215.04MB (225487608 bytes)
last-gc: 2024-10-30 08:22:50.430710439 +0000 UTC
gc-pause-total: 11.373151ms
gc-pause: 132707
gc-pause-end: 1730276570430710439
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0004903135095423816
enable-gc: true
debug-gc: false
