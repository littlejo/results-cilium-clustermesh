ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.220.1:443 (active)      
                                         2 => 172.31.160.161:443 (active)    
2    10.100.199.205:443   ClusterIP      1 => 172.31.210.247:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.151.0.71:53 (active)        
                                         2 => 10.151.0.37:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.151.0.71:9153 (active)      
                                         2 => 10.151.0.37:9153 (active)      
5    10.100.240.82:2379   ClusterIP      1 => 10.151.0.100:2379 (active)     
