key: 00 08 00 00  value: 70 02 00 00
key: 50 08 00 00  value: 19 02 00 00
key: 24 09 00 00  value: fe 01 00 00
key: 41 0c 00 00  value: 07 02 00 00
Found 4 elements
