[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda2f0c7c0_bb57_4290_ab26_70d4eefc3bfb.slice/cri-containerd-4aeec74fd09cd4e698b57c751dcebea3105457fc311e4f6930fc5ec58c8683ce.scope"
      }
    ],
    "ips": [
      "10.151.0.71"
    ],
    "name": "coredns-cc6ccd49c-lnzvf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6af551af_64ec_41d8_b6f6_8a3a45eb0e20.slice/cri-containerd-a16a874bd64661460996c3c6f3ba7c38f9e7b1df86c24192795e9ea0327eb57d.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6af551af_64ec_41d8_b6f6_8a3a45eb0e20.slice/cri-containerd-5447c1965d50e30fd9fa13f37921d14f8cc55cdc77b143b7874b9a5cd4ee7148.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6af551af_64ec_41d8_b6f6_8a3a45eb0e20.slice/cri-containerd-bdd6e27162f7bce3bf41c21d444d9d784860eb330d844872ed0c6c399574615f.scope"
      }
    ],
    "ips": [
      "10.151.0.100"
    ],
    "name": "clustermesh-apiserver-947dd77bb-xcpkg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9635aba5_4a0f_44e0_9e4e_b956f655e3b7.slice/cri-containerd-0da41d8da734a86614b98262f8589dd401f9b9593e40d5fe25d5bf9ff6cad3a2.scope"
      }
    ],
    "ips": [
      "10.151.0.37"
    ],
    "name": "coredns-cc6ccd49c-lw4td",
    "namespace": "kube-system"
  }
]

