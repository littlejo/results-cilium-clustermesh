USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         690  0.0  0.2 1240176 16628 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         710  0.0  0.0   6408  1640 ?        R    08:22   0:00  \_ ps auxfw
root         712  0.0  0.2 1240176 16628 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         663  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         657  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         645  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         638  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         637  0.0  0.0 1228744 4044 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root           1  4.3  4.7 1606080 381328 ?      Ssl  08:01   0:56 cilium-agent --config-dir=/tmp/cilium/config-map
root         414  0.0  0.0 1229488 7936 ?        Sl   08:01   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
