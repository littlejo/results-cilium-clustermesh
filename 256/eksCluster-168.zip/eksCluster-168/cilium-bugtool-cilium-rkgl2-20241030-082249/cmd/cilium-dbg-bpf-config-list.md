KEY             VALUE
AgentLiveness   1927833580291
UTimeOffset     3379442722656250
