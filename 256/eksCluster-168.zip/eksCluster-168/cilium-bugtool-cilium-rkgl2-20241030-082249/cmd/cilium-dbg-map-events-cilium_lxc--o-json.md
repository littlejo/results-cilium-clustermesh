{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:36.275Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.130.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:36.275Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.152.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:36.275Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.764Z",
  "value": "id=1082  sec_id=4     flags=0x0000 ifindex=10  mac=06:FC:BA:7D:D2:4B nodemac=0A:8E:67:A5:87:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.969Z",
  "value": "id=558   sec_id=5560677 flags=0x0000 ifindex=12  mac=A6:A4:5D:2A:B9:9A nodemac=D6:70:18:2A:9E:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.984Z",
  "value": "id=1082  sec_id=4     flags=0x0000 ifindex=10  mac=06:FC:BA:7D:D2:4B nodemac=0A:8E:67:A5:87:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.034Z",
  "value": "id=1705  sec_id=5560677 flags=0x0000 ifindex=14  mac=E6:D1:E3:35:07:FD nodemac=DA:66:68:7D:22:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.112Z",
  "value": "id=558   sec_id=5560677 flags=0x0000 ifindex=12  mac=A6:A4:5D:2A:B9:9A nodemac=D6:70:18:2A:9E:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:41.187Z",
  "value": "id=1082  sec_id=4     flags=0x0000 ifindex=10  mac=06:FC:BA:7D:D2:4B nodemac=0A:8E:67:A5:87:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:41.187Z",
  "value": "id=558   sec_id=5560677 flags=0x0000 ifindex=12  mac=A6:A4:5D:2A:B9:9A nodemac=D6:70:18:2A:9E:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:41.188Z",
  "value": "id=1705  sec_id=5560677 flags=0x0000 ifindex=14  mac=E6:D1:E3:35:07:FD nodemac=DA:66:68:7D:22:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:41.217Z",
  "value": "id=1379  sec_id=5539374 flags=0x0000 ifindex=16  mac=82:7F:38:B9:29:9B nodemac=46:61:2F:D8:E6:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:42.187Z",
  "value": "id=1705  sec_id=5560677 flags=0x0000 ifindex=14  mac=E6:D1:E3:35:07:FD nodemac=DA:66:68:7D:22:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:42.188Z",
  "value": "id=1082  sec_id=4     flags=0x0000 ifindex=10  mac=06:FC:BA:7D:D2:4B nodemac=0A:8E:67:A5:87:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:42.188Z",
  "value": "id=558   sec_id=5560677 flags=0x0000 ifindex=12  mac=A6:A4:5D:2A:B9:9A nodemac=D6:70:18:2A:9E:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:42.188Z",
  "value": "id=1379  sec_id=5539374 flags=0x0000 ifindex=16  mac=82:7F:38:B9:29:9B nodemac=46:61:2F:D8:E6:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.115Z",
  "value": "id=975   sec_id=5539374 flags=0x0000 ifindex=18  mac=D2:94:ED:89:32:78 nodemac=BA:0C:0C:E4:39:D2"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.168.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.644Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.040Z",
  "value": "id=558   sec_id=5560677 flags=0x0000 ifindex=12  mac=A6:A4:5D:2A:B9:9A nodemac=D6:70:18:2A:9E:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.040Z",
  "value": "id=1705  sec_id=5560677 flags=0x0000 ifindex=14  mac=E6:D1:E3:35:07:FD nodemac=DA:66:68:7D:22:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.041Z",
  "value": "id=975   sec_id=5539374 flags=0x0000 ifindex=18  mac=D2:94:ED:89:32:78 nodemac=BA:0C:0C:E4:39:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.042Z",
  "value": "id=1082  sec_id=4     flags=0x0000 ifindex=10  mac=06:FC:BA:7D:D2:4B nodemac=0A:8E:67:A5:87:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.062Z",
  "value": "id=558   sec_id=5560677 flags=0x0000 ifindex=12  mac=A6:A4:5D:2A:B9:9A nodemac=D6:70:18:2A:9E:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.064Z",
  "value": "id=1705  sec_id=5560677 flags=0x0000 ifindex=14  mac=E6:D1:E3:35:07:FD nodemac=DA:66:68:7D:22:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.066Z",
  "value": "id=975   sec_id=5539374 flags=0x0000 ifindex=18  mac=D2:94:ED:89:32:78 nodemac=BA:0C:0C:E4:39:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.068Z",
  "value": "id=1082  sec_id=4     flags=0x0000 ifindex=10  mac=06:FC:BA:7D:D2:4B nodemac=0A:8E:67:A5:87:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.062Z",
  "value": "id=975   sec_id=5539374 flags=0x0000 ifindex=18  mac=D2:94:ED:89:32:78 nodemac=BA:0C:0C:E4:39:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.062Z",
  "value": "id=1082  sec_id=4     flags=0x0000 ifindex=10  mac=06:FC:BA:7D:D2:4B nodemac=0A:8E:67:A5:87:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.062Z",
  "value": "id=558   sec_id=5560677 flags=0x0000 ifindex=12  mac=A6:A4:5D:2A:B9:9A nodemac=D6:70:18:2A:9E:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.062Z",
  "value": "id=1705  sec_id=5560677 flags=0x0000 ifindex=14  mac=E6:D1:E3:35:07:FD nodemac=DA:66:68:7D:22:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.062Z",
  "value": "id=975   sec_id=5539374 flags=0x0000 ifindex=18  mac=D2:94:ED:89:32:78 nodemac=BA:0C:0C:E4:39:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.063Z",
  "value": "id=1082  sec_id=4     flags=0x0000 ifindex=10  mac=06:FC:BA:7D:D2:4B nodemac=0A:8E:67:A5:87:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.063Z",
  "value": "id=558   sec_id=5560677 flags=0x0000 ifindex=12  mac=A6:A4:5D:2A:B9:9A nodemac=D6:70:18:2A:9E:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.168.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.064Z",
  "value": "id=1705  sec_id=5560677 flags=0x0000 ifindex=14  mac=E6:D1:E3:35:07:FD nodemac=DA:66:68:7D:22:3F"
}

