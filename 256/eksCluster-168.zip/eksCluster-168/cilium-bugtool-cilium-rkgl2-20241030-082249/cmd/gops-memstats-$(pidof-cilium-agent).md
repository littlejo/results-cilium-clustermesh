alloc: 129.33MB (135614512 bytes)
total-alloc: 2.16GB (2319481288 bytes)
sys: 336.84MB (353197428 bytes)
lookups: 0
mallocs: 61933366
frees: 61031070
heap-alloc: 129.33MB (135614512 bytes)
heap-sys: 259.92MB (272547840 bytes)
heap-idle: 78.84MB (82665472 bytes)
heap-in-use: 181.09MB (189882368 bytes)
heap-released: 12.22MB (12812288 bytes)
heap-objects: 902296
stack-in-use: 64.03MB (67141632 bytes)
stack-sys: 64.03MB (67141632 bytes)
stack-mspan-inuse: 2.79MB (2925280 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1010.77KB (1035025 bytes)
gc-sys: 6.10MB (6392408 bytes)
next-gc: when heap-alloc >= 212.00MB (222302360 bytes)
last-gc: 2024-10-30 08:23:11.097283177 +0000 UTC
gc-pause-total: 18.820862ms
gc-pause: 81560
gc-pause-end: 1730276591097283177
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.00044343577292109334
enable-gc: true
debug-gc: false
