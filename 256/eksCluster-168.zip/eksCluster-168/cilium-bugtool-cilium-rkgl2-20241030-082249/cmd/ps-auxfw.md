USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         670  0.0  0.0 1228744 3600 ?        Rsl  08:22   0:00 /bin/gops memstats 1
root         664  0.0  0.0 1228744 3660 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         647  0.0  0.2 1240432 16840 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         677  0.0  0.0   6408  1648 ?        R    08:22   0:00  \_ ps auxfw
root         681  0.0  0.0   3784   400 ?        R    08:22   0:00  \_ bash -c hostname
root         641  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         631  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.3  4.7 1606080 382484 ?      Ssl  08:01   0:43 cilium-agent --config-dir=/tmp/cilium/config-map
root         400  0.0  0.1 1229744 8208 ?        Sl   08:01   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
