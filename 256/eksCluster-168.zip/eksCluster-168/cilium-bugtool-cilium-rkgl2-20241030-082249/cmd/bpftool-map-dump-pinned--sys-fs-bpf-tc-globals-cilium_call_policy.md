key: 2e 02 00 00  value: 51 02 00 00
key: cf 03 00 00  value: 92 02 00 00
key: 3a 04 00 00  value: 23 02 00 00
key: a9 06 00 00  value: 28 02 00 00
Found 4 elements
