[
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e29d172_5c35_424b_bb06_13785e65859b.slice/cri-containerd-01d7f3e4a17024969ddd1477caa2d43a7f150f45d60d444dcee15138e2a245dd.scope"
      }
    ],
    "ips": [
      "10.168.0.122"
    ],
    "name": "coredns-cc6ccd49c-s2hlm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9268,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74cc371e_53f7_4d4e_bd94_92a1802b876b.slice/cri-containerd-3582bf2ef8a940c858ec10d9822976451efb4013f9b9ed72b0c8d10be82fb9a8.scope"
      },
      {
        "cgroup-id": 9184,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74cc371e_53f7_4d4e_bd94_92a1802b876b.slice/cri-containerd-b19c0dd2d9979aff763be3b89fd43bc79abfbad843d7c9df927940f254a9c198.scope"
      },
      {
        "cgroup-id": 9352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74cc371e_53f7_4d4e_bd94_92a1802b876b.slice/cri-containerd-926e87d180116ee3650cd71124cf4f75ef4c722330e381a9d5758a9390f642cb.scope"
      }
    ],
    "ips": [
      "10.168.0.217"
    ],
    "name": "clustermesh-apiserver-6fbf7b55c-64l9p",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc621bd2b_1dd3_4445_9370_39c0e3a742d1.slice/cri-containerd-b4002f671f5e53ea4208da46c2357f7d599908e787261740066816bb13dc00d4.scope"
      }
    ],
    "ips": [
      "10.168.0.199"
    ],
    "name": "coredns-cc6ccd49c-h2pll",
    "namespace": "kube-system"
  }
]

