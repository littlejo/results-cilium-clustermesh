REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34030     2687153     677    bpf_overlay.c
Interface                 INGRESS     613755    128108995   1132   bpf_host.c
Success                   EGRESS      13828     1082525     1694   bpf_host.c
Success                   EGRESS      260308    33082446    1308   bpf_lxc.c
Success                   EGRESS      32955     2608260     53     encap.h
Success                   INGRESS     301776    33689720    86     l3.h
Success                   INGRESS     322502    35328996    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
