IP ADDRESS         LOCAL ENDPOINT INFO
172.31.152.47:0    (localhost)                                                                                        
10.168.0.217:0     id=975   sec_id=5539374 flags=0x0000 ifindex=18  mac=D2:94:ED:89:32:78 nodemac=BA:0C:0C:E4:39:D2   
10.168.0.192:0     (localhost)                                                                                        
10.168.0.52:0      id=1082  sec_id=4     flags=0x0000 ifindex=10  mac=06:FC:BA:7D:D2:4B nodemac=0A:8E:67:A5:87:A9     
10.168.0.122:0     id=1705  sec_id=5560677 flags=0x0000 ifindex=14  mac=E6:D1:E3:35:07:FD nodemac=DA:66:68:7D:22:3F   
172.31.130.205:0   (localhost)                                                                                        
10.168.0.199:0     id=558   sec_id=5560677 flags=0x0000 ifindex=12  mac=A6:A4:5D:2A:B9:9A nodemac=D6:70:18:2A:9E:0A   
