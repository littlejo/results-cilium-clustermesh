xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 579
ens6(5) clsact/ingress cil_from_netdev-ens6 id 585
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 562
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 556
cilium_host(7) clsact/egress cil_from_host-cilium_host id 553
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 498
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 497
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 542
lxcec4b65aa016a(12) clsact/ingress cil_from_container-lxcec4b65aa016a id 598
lxc3f6486b9b997(14) clsact/ingress cil_from_container-lxc3f6486b9b997 id 570
lxc84c6a842e138(18) clsact/ingress cil_from_container-lxc84c6a842e138 id 655

flow_dissector:

netfilter:

