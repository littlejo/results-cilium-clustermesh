35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:51:17+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:51:17+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:51:18+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:51:18+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:51:18+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:51:18+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:51:22+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:51:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
495: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:01:39+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 136
496: sched_cls  name tail_handle_ipv4  tag 5359f67b7436404e  gpl
	loaded_at 2024-10-30T08:01:39+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,102
	btf_id 137
497: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:01:39+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 138
498: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:01:39+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,102
	btf_id 139
530: sched_cls  name tail_ipv4_to_endpoint  tag 62acc657dbc182a5  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,115,41,82,83,80,91,39,112,40,37,38
	btf_id 176
531: sched_cls  name __send_drop_notify  tag a73323c3b308be10  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 179
536: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,112,82,83,115,84
	btf_id 181
537: sched_cls  name tail_handle_ipv4  tag 4b1c09090a4b2080  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 185
538: sched_cls  name tail_handle_ipv4_cont  tag 945ad5c64b76cb03  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,115,41,91,82,83,39,76,74,77,112,40,37,38,81
	btf_id 186
540: sched_cls  name tail_ipv4_ct_ingress  tag faf024026d20e420  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,112,82,83,115,84
	btf_id 187
541: sched_cls  name tail_handle_arp  tag 798dea3c20ad439f  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 189
542: sched_cls  name cil_from_container  tag 1bb1a37a01c281b6  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 112,76
	btf_id 190
547: sched_cls  name handle_policy  tag 3a4b1bf8a6b0a39e  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,112,82,83,115,41,80,91,39,84,75,40,37,38
	btf_id 192
548: sched_cls  name tail_handle_ipv4_cont  tag 4089da1a6a0ec38b  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,117,41,116,82,83,39,76,74,77,118,40,37,38,81
	btf_id 196
550: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 197
552: sched_cls  name handle_policy  tag 1bd08ce55baaa05c  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,118,82,83,117,41,80,116,39,84,75,40,37,38
	btf_id 199
553: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,120
	btf_id 203
554: sched_cls  name tail_ipv4_ct_egress  tag 8451283cb786a656  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 202
556: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 205
557: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 207
558: sched_cls  name __send_drop_notify  tag ed4beb1323de3887  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 208
559: sched_cls  name tail_handle_ipv4  tag f88a1c16140b6225  gpl
	loaded_at 2024-10-30T08:01:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,118
	btf_id 206
560: sched_cls  name tail_handle_ipv4_from_host  tag 754677193ba482b1  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 209
561: sched_cls  name tail_ipv4_ct_ingress  tag fe6ab60ed29c4f98  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 210
562: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 212
563: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 213
564: sched_cls  name __send_drop_notify  tag ed4beb1323de3887  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 214
565: sched_cls  name tail_handle_ipv4_from_host  tag 754677193ba482b1  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 215
569: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,118
	btf_id 219
570: sched_cls  name cil_from_container  tag f953bd60413b4c78  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 118,76
	btf_id 221
571: sched_cls  name __send_drop_notify  tag 1dc2a43548c79dd4  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 222
573: sched_cls  name tail_handle_arp  tag 1fbc85e472ef43d1  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,118
	btf_id 224
575: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 227
576: sched_cls  name __send_drop_notify  tag ed4beb1323de3887  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 228
577: sched_cls  name tail_ipv4_to_endpoint  tag 931c0efd2078821f  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,117,41,82,83,80,116,39,118,40,37,38
	btf_id 226
578: sched_cls  name tail_handle_ipv4_from_host  tag 754677193ba482b1  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 229
579: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 232
581: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,128
	btf_id 235
582: sched_cls  name __send_drop_notify  tag ed4beb1323de3887  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 236
583: sched_cls  name tail_handle_ipv4_from_host  tag 754677193ba482b1  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,128
	btf_id 237
584: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
585: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,128,75
	btf_id 238
587: sched_cls  name tail_ipv4_to_endpoint  tag f45a02392be3bf37  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,126,41,82,83,80,103,39,125,40,37,38
	btf_id 231
590: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: sched_cls  name handle_policy  tag c07680f5b359c96e  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,125,82,83,126,41,80,103,39,84,75,40,37,38
	btf_id 242
594: sched_cls  name tail_handle_ipv4  tag 9410a92691ef4593  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 243
595: sched_cls  name tail_handle_ipv4_cont  tag 2bb4367acda35f2c  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,126,41,103,82,83,39,76,74,77,125,40,37,38,81
	btf_id 244
596: sched_cls  name __send_drop_notify  tag 0c916b9e64c7cb2a  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 245
597: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 246
598: sched_cls  name cil_from_container  tag 4cb6d0f156cd20ec  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 125,76
	btf_id 247
600: sched_cls  name tail_handle_arp  tag 6f3a2ca1f232528a  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 249
601: sched_cls  name tail_ipv4_ct_ingress  tag 0facee66d7501fed  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 250
602: sched_cls  name tail_ipv4_ct_egress  tag 8451283cb786a656  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 251
603: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
606: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
607: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
610: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
611: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
614: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
654: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:12:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,144
	btf_id 265
655: sched_cls  name cil_from_container  tag 05bbcff225e225db  gpl
	loaded_at 2024-10-30T08:12:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 144,76
	btf_id 266
656: sched_cls  name tail_ipv4_to_endpoint  tag 754513a7a611fa8f  gpl
	loaded_at 2024-10-30T08:12:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,145,41,82,83,80,143,39,144,40,37,38
	btf_id 267
657: sched_cls  name tail_ipv4_ct_ingress  tag 7ceb1a07c63dff9f  gpl
	loaded_at 2024-10-30T08:12:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,144,82,83,145,84
	btf_id 268
658: sched_cls  name handle_policy  tag e8f0f9e3452be79f  gpl
	loaded_at 2024-10-30T08:12:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,144,82,83,145,41,80,143,39,84,75,40,37,38
	btf_id 269
659: sched_cls  name tail_handle_arp  tag fa6d94f6999fd5d3  gpl
	loaded_at 2024-10-30T08:12:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,144
	btf_id 270
660: sched_cls  name tail_handle_ipv4  tag 76aa0f720b2f6c2d  gpl
	loaded_at 2024-10-30T08:12:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,144
	btf_id 271
661: sched_cls  name tail_ipv4_ct_egress  tag ec33db6c682e8847  gpl
	loaded_at 2024-10-30T08:12:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,144,82,83,145,84
	btf_id 272
662: sched_cls  name tail_handle_ipv4_cont  tag e4904f9e668bac8c  gpl
	loaded_at 2024-10-30T08:12:31+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,145,41,143,82,83,39,76,74,77,144,40,37,38,81
	btf_id 273
664: sched_cls  name __send_drop_notify  tag 6ecae6dacb538342  gpl
	loaded_at 2024-10-30T08:12:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 275
665: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
668: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
681: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
684: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
685: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
688: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
689: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
692: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
