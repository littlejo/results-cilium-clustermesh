Endpoint ID: 558
Path: /sys/fs/bpf/tc/globals/cilium_policy_00558

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    124132   1423      0        
Allow    Egress      0          ANY          NONE         disabled    17540    192       0        


Endpoint ID: 975
Path: /sys/fs/bpf/tc/globals/cilium_policy_00975

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11390890   111499    0        
Allow    Ingress     1          ANY          NONE         disabled    9445395    98895     0        
Allow    Egress      0          ANY          NONE         disabled    10616881   105830    0        


Endpoint ID: 1082
Path: /sys/fs/bpf/tc/globals/cilium_policy_01082

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1645710   20806     0        
Allow    Ingress     1          ANY          NONE         disabled    21242     256       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1705
Path: /sys/fs/bpf/tc/globals/cilium_policy_01705

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    124528   1429      0        
Allow    Egress      0          ANY          NONE         disabled    17233    187       0        


Endpoint ID: 3268
Path: /sys/fs/bpf/tc/globals/cilium_policy_03268

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


