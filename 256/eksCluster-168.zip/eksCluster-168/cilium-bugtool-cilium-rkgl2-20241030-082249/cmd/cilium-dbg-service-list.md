ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.158.234:443 (active)   
                                         2 => 172.31.252.159:443 (active)   
2    10.100.151.147:443   ClusterIP      1 => 172.31.152.47:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.168.0.122:53 (active)      
                                         2 => 10.168.0.199:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.168.0.122:9153 (active)    
                                         2 => 10.168.0.199:9153 (active)    
5    10.100.164.2:2379    ClusterIP      1 => 10.168.0.217:2379 (active)    
