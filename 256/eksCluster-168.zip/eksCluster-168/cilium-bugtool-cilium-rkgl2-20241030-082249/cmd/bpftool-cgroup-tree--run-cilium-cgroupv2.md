CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc621bd2b_1dd3_4445_9370_39c0e3a742d1.slice/cri-containerd-a3fed22f11a19aec7ef86ab7a037379be9dd27c67084d7377c2ae8e891915e31.scope
    590      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc621bd2b_1dd3_4445_9370_39c0e3a742d1.slice/cri-containerd-b4002f671f5e53ea4208da46c2357f7d599908e787261740066816bb13dc00d4.scope
    610      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcf761342_a119_409c_a48d_62444730da50.slice/cri-containerd-d39c9c6ae3e18e2a78eb6fd726af243e5feac50fddcc49b14b96b24255bebd29.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcf761342_a119_409c_a48d_62444730da50.slice/cri-containerd-57e155495c333072e70e85cddfdd42f51227cdfed39189ff1b5729762a9a8840.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e29d172_5c35_424b_bb06_13785e65859b.slice/cri-containerd-01d7f3e4a17024969ddd1477caa2d43a7f150f45d60d444dcee15138e2a245dd.scope
    614      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e29d172_5c35_424b_bb06_13785e65859b.slice/cri-containerd-bdcfa21ca3dd28346562c3e55c6cbd8082cfd9f4a5ac29575fbb010fc54aa560.scope
    606      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd254fd43_f747_47ea_8489_93f686d8b21e.slice/cri-containerd-86c5bf313884434b1dbb3b1a691a21d60a63f8810a8385c5cc2d375f3dbf857d.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd254fd43_f747_47ea_8489_93f686d8b21e.slice/cri-containerd-7233d457cc91c198f0697cdaa4c54639cb4210184b27ceeaec902154818d5a3f.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod46d0e175_e994_45a5_9220_e4b2af15771d.slice/cri-containerd-559add32b940ca4f7680c900cb9b5b29da1b71f2f517e44716ee641250cd9ff8.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod46d0e175_e994_45a5_9220_e4b2af15771d.slice/cri-containerd-2d1c4900b59bbae2b6c88632d607fcd0bc491b6ad4bdc9f71b3bf09752344c7a.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74cc371e_53f7_4d4e_bd94_92a1802b876b.slice/cri-containerd-926e87d180116ee3650cd71124cf4f75ef4c722330e381a9d5758a9390f642cb.scope
    692      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74cc371e_53f7_4d4e_bd94_92a1802b876b.slice/cri-containerd-6ff30f2759d10a343460a832083290b033a50d9ae1093ad1f0be97087da67de1.scope
    668      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74cc371e_53f7_4d4e_bd94_92a1802b876b.slice/cri-containerd-3582bf2ef8a940c858ec10d9822976451efb4013f9b9ed72b0c8d10be82fb9a8.scope
    688      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74cc371e_53f7_4d4e_bd94_92a1802b876b.slice/cri-containerd-b19c0dd2d9979aff763be3b89fd43bc79abfbad843d7c9df927940f254a9c198.scope
    684      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode65e8e66_a52a_4fbe_bd22_c11b85880ce4.slice/cri-containerd-2981aec89943657b59ac88f500f6b68de9697a9a4b937344714bdac345741a7a.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode65e8e66_a52a_4fbe_bd22_c11b85880ce4.slice/cri-containerd-f6592f9243190362fcb7dd9d6083a9f790529eddbd565225aa8f18f8452b5c89.scope
    105      cgroup_device   multi                                          
