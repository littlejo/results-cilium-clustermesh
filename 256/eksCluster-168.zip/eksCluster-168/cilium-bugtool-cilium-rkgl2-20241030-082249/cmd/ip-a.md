1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:3c:a4:63:4a:5d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.152.47/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3513sec preferred_lft 3513sec
    inet6 fe80::43c:a4ff:fe63:4a5d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:f6:2d:c6:98:19 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.130.205/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4f6:2dff:fec6:9819/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:a5:6c:e7:de:86 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6ca5:6cff:fee7:de86/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:25:55:2f:69:24 brd ff:ff:ff:ff:ff:ff
    inet 10.168.0.192/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::7825:55ff:fe2f:6924/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 2e:25:4c:94:96:3f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2c25:4cff:fe94:963f/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:8e:67:a5:87:a9 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::88e:67ff:fea5:87a9/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcec4b65aa016a@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:70:18:2a:9e:0a brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d470:18ff:fe2a:9e0a/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc3f6486b9b997@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:66:68:7d:22:3f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d866:68ff:fe7d:223f/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc84c6a842e138@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:0c:0c:e4:39:d2 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::b80c:cff:fee4:39d2/64 scope link 
       valid_lft forever preferred_lft forever
