key: 01 00 00 00  value: ef 01 00 00
key: 07 00 00 00  value: f0 01 00 00
Found 2 elements
