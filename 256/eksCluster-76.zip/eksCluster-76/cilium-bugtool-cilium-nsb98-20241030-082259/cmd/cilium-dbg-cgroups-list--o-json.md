[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod24c1bb1b_39e7_4e77_9f83_54cb78f2a375.slice/cri-containerd-b1cb675f929ccba39a11a1483e1eec9a21bf21ab65d83cb73a0f88728f40924b.scope"
      }
    ],
    "ips": [
      "10.76.0.140"
    ],
    "name": "coredns-cc6ccd49c-l25tr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf5a2853_55e8_4fca_8594_f11a9e2333eb.slice/cri-containerd-4e3a4faca7063184bb66b48ac99c16523d802adf755eb39a8cb836e95b010769.scope"
      }
    ],
    "ips": [
      "10.76.0.109"
    ],
    "name": "coredns-cc6ccd49c-94twm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod243e3a43_9b80_470e_8b17_d72bbacd9afc.slice/cri-containerd-411ddbcc0cf0a41185486a255ef2d552a70c83c3b217b4cd4187e668ed96f504.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod243e3a43_9b80_470e_8b17_d72bbacd9afc.slice/cri-containerd-2438a66761f40bbad08f4a9a426a3f771c25ca3847d7315db1432c077138556d.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod243e3a43_9b80_470e_8b17_d72bbacd9afc.slice/cri-containerd-2e2a0a226f504f2c5189531cae63e83c7f112ea1c860da4a26d9be4aae6c4a62.scope"
      }
    ],
    "ips": [
      "10.76.0.137"
    ],
    "name": "clustermesh-apiserver-7cc5f9b94b-6xchs",
    "namespace": "kube-system"
  }
]

