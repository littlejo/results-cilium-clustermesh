KEY             VALUE
AgentLiveness   2094563630849
UTimeOffset     3379442416015625
