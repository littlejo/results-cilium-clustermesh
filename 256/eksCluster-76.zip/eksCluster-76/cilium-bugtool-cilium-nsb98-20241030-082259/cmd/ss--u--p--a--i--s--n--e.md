Total: 696
TCP:   2102 (estab 437, closed 1644, orphaned 1, timewait 793)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  458       447       11       
INET	  468       453       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:34401      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:32677 sk:4ad fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.185.59%ens5:68         0.0.0.0:*    uid:192 ino:71775 sk:4ae cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:34852 sk:4af cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15160 sk:4b0 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:34851 sk:4b1 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15161 sk:4b2 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::477:2eff:fe07:d275]%ens5:546           [::]:*    uid:192 ino:15329 sk:4b3 cgroup:unreachable:c4e v6only:1 <->                   
