Endpoint ID: 356
Path: /sys/fs/bpf/tc/globals/cilium_policy_00356

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1674352   21176     0        
Allow    Ingress     1          ANY          NONE         disabled    23530     277       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 569
Path: /sys/fs/bpf/tc/globals/cilium_policy_00569

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11598777   117058    0        
Allow    Ingress     1          ANY          NONE         disabled    10896822   114941    0        
Allow    Egress      0          ANY          NONE         disabled    15279687   148983    0        


Endpoint ID: 726
Path: /sys/fs/bpf/tc/globals/cilium_policy_00726

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    151746   1742      0        
Allow    Egress      0          ANY          NONE         disabled    18229    203       0        


Endpoint ID: 2629
Path: /sys/fs/bpf/tc/globals/cilium_policy_02629

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3248
Path: /sys/fs/bpf/tc/globals/cilium_policy_03248

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    151944   1745      0        
Allow    Egress      0          ANY          NONE         disabled    20539    229       0        


