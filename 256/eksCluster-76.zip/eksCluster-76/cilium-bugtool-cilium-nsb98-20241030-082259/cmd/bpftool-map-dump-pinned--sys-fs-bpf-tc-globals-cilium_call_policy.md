key: 64 01 00 00  value: 38 02 00 00
key: 39 02 00 00  value: 81 02 00 00
key: d6 02 00 00  value: 0c 02 00 00
key: b0 0c 00 00  value: 37 02 00 00
Found 4 elements
