{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:58.004Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.180.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:58.004Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.185.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:58.004Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:02.438Z",
  "value": "id=356   sec_id=4     flags=0x0000 ifindex=10  mac=2E:40:0A:2E:AF:C7 nodemac=26:5E:21:64:09:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:02.443Z",
  "value": "id=726   sec_id=2540209 flags=0x0000 ifindex=14  mac=7E:06:F5:68:2D:1C nodemac=7A:5A:03:FF:AC:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:02.492Z",
  "value": "id=3248  sec_id=2540209 flags=0x0000 ifindex=12  mac=7E:BF:5E:2C:EC:0D nodemac=BE:BC:06:E7:83:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:02.533Z",
  "value": "id=356   sec_id=4     flags=0x0000 ifindex=10  mac=2E:40:0A:2E:AF:C7 nodemac=26:5E:21:64:09:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:01.858Z",
  "value": "id=356   sec_id=4     flags=0x0000 ifindex=10  mac=2E:40:0A:2E:AF:C7 nodemac=26:5E:21:64:09:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:01.859Z",
  "value": "id=3248  sec_id=2540209 flags=0x0000 ifindex=12  mac=7E:BF:5E:2C:EC:0D nodemac=BE:BC:06:E7:83:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:01.860Z",
  "value": "id=726   sec_id=2540209 flags=0x0000 ifindex=14  mac=7E:06:F5:68:2D:1C nodemac=7A:5A:03:FF:AC:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:01.891Z",
  "value": "id=3034  sec_id=2534646 flags=0x0000 ifindex=16  mac=02:E0:94:E9:A9:12 nodemac=7A:CC:5C:72:7C:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:02.858Z",
  "value": "id=3248  sec_id=2540209 flags=0x0000 ifindex=12  mac=7E:BF:5E:2C:EC:0D nodemac=BE:BC:06:E7:83:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:02.858Z",
  "value": "id=3034  sec_id=2534646 flags=0x0000 ifindex=16  mac=02:E0:94:E9:A9:12 nodemac=7A:CC:5C:72:7C:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:02.859Z",
  "value": "id=726   sec_id=2540209 flags=0x0000 ifindex=14  mac=7E:06:F5:68:2D:1C nodemac=7A:5A:03:FF:AC:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:02.859Z",
  "value": "id=356   sec_id=4     flags=0x0000 ifindex=10  mac=2E:40:0A:2E:AF:C7 nodemac=26:5E:21:64:09:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:28.830Z",
  "value": "id=569   sec_id=2534646 flags=0x0000 ifindex=18  mac=06:CE:29:AD:F7:D5 nodemac=B6:D6:CE:62:5B:2F"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.76.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:39.093Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.482Z",
  "value": "id=356   sec_id=4     flags=0x0000 ifindex=10  mac=2E:40:0A:2E:AF:C7 nodemac=26:5E:21:64:09:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.482Z",
  "value": "id=3248  sec_id=2540209 flags=0x0000 ifindex=12  mac=7E:BF:5E:2C:EC:0D nodemac=BE:BC:06:E7:83:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.483Z",
  "value": "id=726   sec_id=2540209 flags=0x0000 ifindex=14  mac=7E:06:F5:68:2D:1C nodemac=7A:5A:03:FF:AC:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.488Z",
  "value": "id=569   sec_id=2534646 flags=0x0000 ifindex=18  mac=06:CE:29:AD:F7:D5 nodemac=B6:D6:CE:62:5B:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.600Z",
  "value": "id=726   sec_id=2540209 flags=0x0000 ifindex=14  mac=7E:06:F5:68:2D:1C nodemac=7A:5A:03:FF:AC:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.600Z",
  "value": "id=569   sec_id=2534646 flags=0x0000 ifindex=18  mac=06:CE:29:AD:F7:D5 nodemac=B6:D6:CE:62:5B:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.601Z",
  "value": "id=356   sec_id=4     flags=0x0000 ifindex=10  mac=2E:40:0A:2E:AF:C7 nodemac=26:5E:21:64:09:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.602Z",
  "value": "id=3248  sec_id=2540209 flags=0x0000 ifindex=12  mac=7E:BF:5E:2C:EC:0D nodemac=BE:BC:06:E7:83:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.506Z",
  "value": "id=356   sec_id=4     flags=0x0000 ifindex=10  mac=2E:40:0A:2E:AF:C7 nodemac=26:5E:21:64:09:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.507Z",
  "value": "id=726   sec_id=2540209 flags=0x0000 ifindex=14  mac=7E:06:F5:68:2D:1C nodemac=7A:5A:03:FF:AC:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.507Z",
  "value": "id=569   sec_id=2534646 flags=0x0000 ifindex=18  mac=06:CE:29:AD:F7:D5 nodemac=B6:D6:CE:62:5B:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.508Z",
  "value": "id=3248  sec_id=2540209 flags=0x0000 ifindex=12  mac=7E:BF:5E:2C:EC:0D nodemac=BE:BC:06:E7:83:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.508Z",
  "value": "id=356   sec_id=4     flags=0x0000 ifindex=10  mac=2E:40:0A:2E:AF:C7 nodemac=26:5E:21:64:09:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.508Z",
  "value": "id=3248  sec_id=2540209 flags=0x0000 ifindex=12  mac=7E:BF:5E:2C:EC:0D nodemac=BE:BC:06:E7:83:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.508Z",
  "value": "id=726   sec_id=2540209 flags=0x0000 ifindex=14  mac=7E:06:F5:68:2D:1C nodemac=7A:5A:03:FF:AC:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.509Z",
  "value": "id=569   sec_id=2534646 flags=0x0000 ifindex=18  mac=06:CE:29:AD:F7:D5 nodemac=B6:D6:CE:62:5B:2F"
}

