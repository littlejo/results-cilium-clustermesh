key: 07 00 00 00  value: 0a 4c 00 6d 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f b9 3b 10 94 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f d8 d8 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 4c 00 8c 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f b9 6a 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 4c 00 6d 00 35 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 4c 00 89 09 4b 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 4c 00 8c 23 c1 00 00  00 00 00 00
Found 8 elements
