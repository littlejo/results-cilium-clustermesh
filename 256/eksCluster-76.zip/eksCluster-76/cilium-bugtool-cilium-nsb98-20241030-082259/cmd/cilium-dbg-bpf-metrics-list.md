REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38054     3016778     677    bpf_overlay.c
Interface                 INGRESS     671824    136455212   1132   bpf_host.c
Success                   EGRESS      17595     1391636     1694   bpf_host.c
Success                   EGRESS      291265    35738522    1308   bpf_lxc.c
Success                   EGRESS      38998     3086158     53     encap.h
Success                   INGRESS     331549    37852766    86     l3.h
Success                   INGRESS     352659    39521954    235    trace.h
Unsupported L3 protocol   EGRESS      40        2972        1492   bpf_lxc.c
