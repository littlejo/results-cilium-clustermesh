top - 08:23:01 up 34 min,  0 users,  load average: 0.33, 0.27, 0.17
Tasks:   7 total,   2 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 38.2 us, 38.2 sy,  0.0 ni,  8.8 id,  0.0 wa,  0.0 hi, 11.8 si,  2.9 st
MiB Mem :   7814.2 total,   4489.6 free,   1177.8 used,   2146.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6451.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 382756  77796 S  18.8   4.8   0:55.63 cilium-+
    620 root      20   0 1240432  16284  11292 S   6.2   0.2   0:00.03 cilium-+
    393 root      20   0 1229744   6936   2924 S   0.0   0.1   0:01.17 cilium-+
    621 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    678 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    713 root      20   0    3852   1276   1124 S   0.0   0.0   0:00.00 bash
    714 root      20   0    2196    776    700 R   0.0   0.0   0:00.00 pidof
