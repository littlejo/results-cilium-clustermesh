ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.185.106:443 (active)   
                                          2 => 172.31.216.216:443 (active)   
2    10.100.32.133:443     ClusterIP      1 => 172.31.185.59:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.76.0.109:53 (active)       
                                          2 => 10.76.0.140:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.76.0.109:9153 (active)     
                                          2 => 10.76.0.140:9153 (active)     
5    10.100.199.223:2379   ClusterIP      1 => 10.76.0.137:2379 (active)     
