filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc45c4a1756ed direct-action not_in_hw id 530 tag a33aa9bb0aa59e25 jited 
