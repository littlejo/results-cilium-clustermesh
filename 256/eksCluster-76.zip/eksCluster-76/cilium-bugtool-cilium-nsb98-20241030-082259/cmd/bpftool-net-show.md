xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 549
ens6(5) clsact/ingress cil_from_netdev-ens6 id 559
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 546
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 535
cilium_host(7) clsact/egress cil_from_host-cilium_host id 534
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 581
lxcc45c4a1756ed(12) clsact/ingress cil_from_container-lxcc45c4a1756ed id 530
lxcf19e489593b6(14) clsact/ingress cil_from_container-lxcf19e489593b6 id 532
lxc85a7e4a7e41b(18) clsact/ingress cil_from_container-lxc85a7e4a7e41b id 637

flow_dissector:

netfilter:

