USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         621  0.0  0.0 1228744 3600 ?        Ssl  08:23   0:00 /bin/gops pprof-cpu 1
root         620  0.0  0.2 1240432 16024 ?       Ssl  08:23   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         654  0.0  0.0   6408  1640 ?        R    08:23   0:00  \_ ps auxfw
root         655  0.0  0.0      0     0 ?        Z    08:23   0:00  \_ [hostname] <defunct>
root           1  3.5  4.7 1606080 382756 ?      Ssl  07:56   0:55 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.0 1229744 6936 ?        Sl   07:56   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
