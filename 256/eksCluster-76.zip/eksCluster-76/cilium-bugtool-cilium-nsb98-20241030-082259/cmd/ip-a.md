1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:77:2e:07:d2:75 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.185.59/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3345sec preferred_lft 3345sec
    inet6 fe80::477:2eff:fe07:d275/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:3f:ed:1e:44:a3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.180.155/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::43f:edff:fe1e:44a3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:6e:a5:96:1b:7c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9c6e:a5ff:fe96:1b7c/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:aa:1a:80:db:68 brd ff:ff:ff:ff:ff:ff
    inet 10.76.0.172/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a4aa:1aff:fe80:db68/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 36:df:a7:55:e5:5f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::34df:a7ff:fe55:e55f/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:5e:21:64:09:47 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::245e:21ff:fe64:947/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcc45c4a1756ed@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:bc:06:e7:83:66 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::bcbc:6ff:fee7:8366/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcf19e489593b6@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:5a:03:ff:ac:b7 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::785a:3ff:feff:acb7/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc85a7e4a7e41b@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:d6:ce:62:5b:2f brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::b4d6:ceff:fe62:5b2f/64 scope link 
       valid_lft forever preferred_lft forever
