CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc053c1ee_37b7_4453_8d3b_f6fc091b8c55.slice/cri-containerd-a37972c7abd21f51a8c19146f89116ec2285cefc087bfc819599479a38872757.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc053c1ee_37b7_4453_8d3b_f6fc091b8c55.slice/cri-containerd-4f966ec6758d818d1eabcac55ca4c3fe798ad7aa26e51af4976d22f9699b9302.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod583a08c8_45ff_4498_b975_9ef1166ab119.slice/cri-containerd-d79642a90c1752679305e9b6b55c13772762435116686174e9789e715b737bcb.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod583a08c8_45ff_4498_b975_9ef1166ab119.slice/cri-containerd-cbba2655f23e54425675056b7f009ae0de36813de2b2c3e390b7156d258e16c8.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf5a2853_55e8_4fca_8594_f11a9e2333eb.slice/cri-containerd-ad33dbed02a06f9cef39f45d684bb0c03c4a8cc7f78f2de16aff45d5464672fc.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf5a2853_55e8_4fca_8594_f11a9e2333eb.slice/cri-containerd-4e3a4faca7063184bb66b48ac99c16523d802adf755eb39a8cb836e95b010769.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod24c1bb1b_39e7_4e77_9f83_54cb78f2a375.slice/cri-containerd-b1cb675f929ccba39a11a1483e1eec9a21bf21ab65d83cb73a0f88728f40924b.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod24c1bb1b_39e7_4e77_9f83_54cb78f2a375.slice/cri-containerd-ab007d8aa0d2df70ba60183a240f2b8acd016fb1160b3940e29ea60706ce9807.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb0155fb9_ef8d_4a9b_93b8_eae5cd16ae2d.slice/cri-containerd-f5b35e5db88ffd7c30b0a2060ae0e24c7562bb19846fec714262afb2abccc556.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb0155fb9_ef8d_4a9b_93b8_eae5cd16ae2d.slice/cri-containerd-9118556f8d5a4b544f92e2deefa89175af8a1d5735b4f9ad265653cb09597e8f.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode34fa80c_9ad6_40d4_a4d9_ff51270524c2.slice/cri-containerd-be154ff61ce21e7c9e59d11edb0840db125d6d5d2e090122b0b8e4be07bc5bcb.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode34fa80c_9ad6_40d4_a4d9_ff51270524c2.slice/cri-containerd-92759bee462e91bd153ca64ae092f93f30669e4da4a514186468038cc6a0a65c.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod243e3a43_9b80_470e_8b17_d72bbacd9afc.slice/cri-containerd-67df3463d876e2ca11134e1d6883828711620910ebe093f8715653df1ae6e344.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod243e3a43_9b80_470e_8b17_d72bbacd9afc.slice/cri-containerd-2438a66761f40bbad08f4a9a426a3f771c25ca3847d7315db1432c077138556d.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod243e3a43_9b80_470e_8b17_d72bbacd9afc.slice/cri-containerd-411ddbcc0cf0a41185486a255ef2d552a70c83c3b217b4cd4187e668ed96f504.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod243e3a43_9b80_470e_8b17_d72bbacd9afc.slice/cri-containerd-2e2a0a226f504f2c5189531cae63e83c7f112ea1c860da4a26d9be4aae6c4a62.scope
    675      cgroup_device   multi                                          
