alloc: 142.14MB (149043560 bytes)
total-alloc: 2.36GB (2530428280 bytes)
sys: 316.77MB (332157284 bytes)
lookups: 0
mallocs: 65475017
frees: 64017406
heap-alloc: 142.14MB (149043560 bytes)
heap-sys: 239.04MB (250650624 bytes)
heap-idle: 59.77MB (62676992 bytes)
heap-in-use: 179.27MB (187973632 bytes)
heap-released: 7.01MB (7348224 bytes)
heap-objects: 1457611
stack-in-use: 64.94MB (68091904 bytes)
stack-sys: 64.94MB (68091904 bytes)
stack-mspan-inuse: 3.04MB (3186400 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1007.09KB (1031265 bytes)
gc-sys: 5.98MB (6272416 bytes)
next-gc: when heap-alloc >= 214.67MB (225100584 bytes)
last-gc: 2024-10-30 08:23:07.702408756 +0000 UTC
gc-pause-total: 8.002635ms
gc-pause: 91217
gc-pause-end: 1730276587702408756
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.0004123958632256124
enable-gc: true
debug-gc: false
