IP ADDRESS         LOCAL ENDPOINT INFO
10.76.0.137:0      id=569   sec_id=2534646 flags=0x0000 ifindex=18  mac=06:CE:29:AD:F7:D5 nodemac=B6:D6:CE:62:5B:2F   
172.31.185.59:0    (localhost)                                                                                        
10.76.0.172:0      (localhost)                                                                                        
10.76.0.140:0      id=726   sec_id=2540209 flags=0x0000 ifindex=14  mac=7E:06:F5:68:2D:1C nodemac=7A:5A:03:FF:AC:B7   
10.76.0.109:0      id=3248  sec_id=2540209 flags=0x0000 ifindex=12  mac=7E:BF:5E:2C:EC:0D nodemac=BE:BC:06:E7:83:66   
10.76.0.231:0      id=356   sec_id=4     flags=0x0000 ifindex=10  mac=2E:40:0A:2E:AF:C7 nodemac=26:5E:21:64:09:47     
172.31.180.155:0   (localhost)                                                                                        
