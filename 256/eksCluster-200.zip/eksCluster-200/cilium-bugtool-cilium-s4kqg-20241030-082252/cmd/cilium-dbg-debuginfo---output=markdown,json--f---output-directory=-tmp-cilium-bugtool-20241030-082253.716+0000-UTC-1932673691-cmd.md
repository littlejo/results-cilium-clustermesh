markdown output at /tmp/cilium-bugtool-20241030-082253.716+0000-UTC-1932673691/cmd/cilium-debuginfo-20241030-082324.731+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082253.716+0000-UTC-1932673691/cmd/cilium-debuginfo-20241030-082324.731+0000-UTC.json
