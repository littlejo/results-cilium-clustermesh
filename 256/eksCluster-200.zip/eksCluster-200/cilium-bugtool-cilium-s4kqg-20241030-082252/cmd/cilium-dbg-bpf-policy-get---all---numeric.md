Endpoint ID: 288
Path: /sys/fs/bpf/tc/globals/cilium_policy_00288

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    119752   1371      0        
Allow    Egress      0          ANY          NONE         disabled    16882    183       0        


Endpoint ID: 367
Path: /sys/fs/bpf/tc/globals/cilium_policy_00367

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    119752   1371      0        
Allow    Egress      0          ANY          NONE         disabled    17512    190       0        


Endpoint ID: 1419
Path: /sys/fs/bpf/tc/globals/cilium_policy_01419

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11569029   115964    0        
Allow    Ingress     1          ANY          NONE         disabled    10525035   111274    0        
Allow    Egress      0          ANY          NONE         disabled    13821546   135429    0        


Endpoint ID: 2511
Path: /sys/fs/bpf/tc/globals/cilium_policy_02511

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3119
Path: /sys/fs/bpf/tc/globals/cilium_policy_03119

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1660296   20970     0        
Allow    Ingress     1          ANY          NONE         disabled    20042     238       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


