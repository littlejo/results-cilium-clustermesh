IP ADDRESS         LOCAL ENDPOINT INFO
172.31.174.157:0   (localhost)                                                                                        
172.31.187.255:0   (localhost)                                                                                        
10.200.0.240:0     id=3119  sec_id=4     flags=0x0000 ifindex=10  mac=FE:97:C1:B7:AE:86 nodemac=62:0F:C0:62:C7:F9     
10.200.0.214:0     id=1419  sec_id=6606335 flags=0x0000 ifindex=18  mac=B2:75:71:5B:8B:2B nodemac=56:7B:F9:67:3C:5A   
10.200.0.156:0     id=367   sec_id=6611910 flags=0x0000 ifindex=12  mac=7E:12:4C:B6:B6:7C nodemac=32:60:B3:63:B2:AD   
10.200.0.192:0     (localhost)                                                                                        
10.200.0.125:0     id=288   sec_id=6611910 flags=0x0000 ifindex=14  mac=42:02:2E:EF:94:3E nodemac=A6:10:8E:C2:1B:A6   
