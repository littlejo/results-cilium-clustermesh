[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c6d0a1a_af39_4ace_8f98_ded2400ffb4d.slice/cri-containerd-3eecf53ecc1c160678bafb4d72b417d37dd7356fd9d8404bef4229b6c5157105.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c6d0a1a_af39_4ace_8f98_ded2400ffb4d.slice/cri-containerd-a4ceca0b4d3a548eb8150507fe3528e37c5e5dfb81db02cf2cf8a4fc88348852.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c6d0a1a_af39_4ace_8f98_ded2400ffb4d.slice/cri-containerd-69bbab5afbe8794e025b7ce878e77a0488dd479791cc5b013fb6e0c1da368ee7.scope"
      }
    ],
    "ips": [
      "10.200.0.214"
    ],
    "name": "clustermesh-apiserver-7b978c9644-j65h2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod78728365_fe15_457a_af1f_55111661aa9d.slice/cri-containerd-6e87381ae097b7574f2d973a4eb8e24adbc7b1382108d05f8ce5cb83f1c33d3f.scope"
      }
    ],
    "ips": [
      "10.200.0.125"
    ],
    "name": "coredns-cc6ccd49c-hrt7r",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod63fb0342_9f11_44fc_8b03_c08b839cf172.slice/cri-containerd-6b33c80cac8fd8404b6d8dafb6430ff7aab5924ea93049dcf6bdc6260f50261b.scope"
      }
    ],
    "ips": [
      "10.200.0.156"
    ],
    "name": "coredns-cc6ccd49c-7g76x",
    "namespace": "kube-system"
  }
]

