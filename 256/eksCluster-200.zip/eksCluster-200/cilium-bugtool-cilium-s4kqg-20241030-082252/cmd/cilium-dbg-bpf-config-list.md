KEY             VALUE
AgentLiveness   1883704811959
UTimeOffset     3379442814453125
