alloc: 198.95MB (208612152 bytes)
total-alloc: 2.30GB (2466984704 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 64296255
frees: 62173036
heap-alloc: 198.95MB (208612152 bytes)
heap-sys: 251.64MB (263864320 bytes)
heap-idle: 29.81MB (31260672 bytes)
heap-in-use: 221.83MB (232603648 bytes)
heap-released: 3.00MB (3145728 bytes)
heap-objects: 2123219
stack-in-use: 64.31MB (67436544 bytes)
stack-sys: 64.31MB (67436544 bytes)
stack-mspan-inuse: 3.50MB (3666240 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.23MB (1286937 bytes)
gc-sys: 6.02MB (6307280 bytes)
next-gc: when heap-alloc >= 215.50MB (225968408 bytes)
last-gc: 2024-10-30 08:22:55.271089441 +0000 UTC
gc-pause-total: 13.309796ms
gc-pause: 238657
gc-pause-end: 1730276575271089441
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0006495991339281865
enable-gc: true
debug-gc: false
