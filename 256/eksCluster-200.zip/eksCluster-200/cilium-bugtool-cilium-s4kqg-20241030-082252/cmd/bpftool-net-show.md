xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 497
ens6(5) clsact/ingress cil_from_netdev-ens6 id 509
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 490
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 482
cilium_host(7) clsact/egress cil_from_host-cilium_host id 487
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 478
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 539
lxcb638d05d50bc(12) clsact/ingress cil_from_container-lxcb638d05d50bc id 526
lxc15edafd6ecf8(14) clsact/ingress cil_from_container-lxc15edafd6ecf8 id 547
lxc0a15c445337e(18) clsact/ingress cil_from_container-lxc0a15c445337e id 616

flow_dissector:

netfilter:

