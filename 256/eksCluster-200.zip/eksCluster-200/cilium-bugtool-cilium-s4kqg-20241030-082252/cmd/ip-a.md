1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:cf:93:aa:57:19 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.174.157/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3558sec preferred_lft 3558sec
    inet6 fe80::4cf:93ff:feaa:5719/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ff:a7:92:45:1f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.187.255/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4ff:a7ff:fe92:451f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:75:ad:94:f0:cd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8475:adff:fe94:f0cd/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:88:65:47:55:ad brd ff:ff:ff:ff:ff:ff
    inet 10.200.0.192/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::bc88:65ff:fe47:55ad/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 36:29:2c:ac:65:f4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3429:2cff:feac:65f4/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:0f:c0:62:c7:f9 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::600f:c0ff:fe62:c7f9/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb638d05d50bc@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:60:b3:63:b2:ad brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::3060:b3ff:fe63:b2ad/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc15edafd6ecf8@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:10:8e:c2:1b:a6 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::a410:8eff:fec2:1ba6/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc0a15c445337e@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:7b:f9:67:3c:5a brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::547b:f9ff:fe67:3c5a/64 scope link 
       valid_lft forever preferred_lft forever
