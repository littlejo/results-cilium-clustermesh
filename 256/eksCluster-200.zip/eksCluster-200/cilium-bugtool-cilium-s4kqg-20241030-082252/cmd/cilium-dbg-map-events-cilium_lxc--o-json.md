{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:15.145Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.174.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:15.145Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.187.255:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:15.145Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:19.753Z",
  "value": "id=367   sec_id=6611910 flags=0x0000 ifindex=12  mac=7E:12:4C:B6:B6:7C nodemac=32:60:B3:63:B2:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:19.774Z",
  "value": "id=3119  sec_id=4     flags=0x0000 ifindex=10  mac=FE:97:C1:B7:AE:86 nodemac=62:0F:C0:62:C7:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:19.776Z",
  "value": "id=367   sec_id=6611910 flags=0x0000 ifindex=12  mac=7E:12:4C:B6:B6:7C nodemac=32:60:B3:63:B2:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:19.824Z",
  "value": "id=288   sec_id=6611910 flags=0x0000 ifindex=14  mac=42:02:2E:EF:94:3E nodemac=A6:10:8E:C2:1B:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:19.826Z",
  "value": "id=3119  sec_id=4     flags=0x0000 ifindex=10  mac=FE:97:C1:B7:AE:86 nodemac=62:0F:C0:62:C7:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:08.698Z",
  "value": "id=3119  sec_id=4     flags=0x0000 ifindex=10  mac=FE:97:C1:B7:AE:86 nodemac=62:0F:C0:62:C7:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:08.699Z",
  "value": "id=367   sec_id=6611910 flags=0x0000 ifindex=12  mac=7E:12:4C:B6:B6:7C nodemac=32:60:B3:63:B2:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:08.699Z",
  "value": "id=288   sec_id=6611910 flags=0x0000 ifindex=14  mac=42:02:2E:EF:94:3E nodemac=A6:10:8E:C2:1B:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:08.728Z",
  "value": "id=1298  sec_id=6606335 flags=0x0000 ifindex=16  mac=0E:58:44:2A:54:D9 nodemac=AE:D6:12:E0:47:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.306Z",
  "value": "id=1419  sec_id=6606335 flags=0x0000 ifindex=18  mac=B2:75:71:5B:8B:2B nodemac=56:7B:F9:67:3C:5A"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.200.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.670Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:08.092Z",
  "value": "id=288   sec_id=6611910 flags=0x0000 ifindex=14  mac=42:02:2E:EF:94:3E nodemac=A6:10:8E:C2:1B:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:08.094Z",
  "value": "id=1419  sec_id=6606335 flags=0x0000 ifindex=18  mac=B2:75:71:5B:8B:2B nodemac=56:7B:F9:67:3C:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:08.096Z",
  "value": "id=3119  sec_id=4     flags=0x0000 ifindex=10  mac=FE:97:C1:B7:AE:86 nodemac=62:0F:C0:62:C7:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:08.096Z",
  "value": "id=367   sec_id=6611910 flags=0x0000 ifindex=12  mac=7E:12:4C:B6:B6:7C nodemac=32:60:B3:63:B2:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.075Z",
  "value": "id=288   sec_id=6611910 flags=0x0000 ifindex=14  mac=42:02:2E:EF:94:3E nodemac=A6:10:8E:C2:1B:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.076Z",
  "value": "id=1419  sec_id=6606335 flags=0x0000 ifindex=18  mac=B2:75:71:5B:8B:2B nodemac=56:7B:F9:67:3C:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.077Z",
  "value": "id=3119  sec_id=4     flags=0x0000 ifindex=10  mac=FE:97:C1:B7:AE:86 nodemac=62:0F:C0:62:C7:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.077Z",
  "value": "id=367   sec_id=6611910 flags=0x0000 ifindex=12  mac=7E:12:4C:B6:B6:7C nodemac=32:60:B3:63:B2:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.075Z",
  "value": "id=288   sec_id=6611910 flags=0x0000 ifindex=14  mac=42:02:2E:EF:94:3E nodemac=A6:10:8E:C2:1B:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.075Z",
  "value": "id=1419  sec_id=6606335 flags=0x0000 ifindex=18  mac=B2:75:71:5B:8B:2B nodemac=56:7B:F9:67:3C:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.075Z",
  "value": "id=3119  sec_id=4     flags=0x0000 ifindex=10  mac=FE:97:C1:B7:AE:86 nodemac=62:0F:C0:62:C7:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.076Z",
  "value": "id=367   sec_id=6611910 flags=0x0000 ifindex=12  mac=7E:12:4C:B6:B6:7C nodemac=32:60:B3:63:B2:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.076Z",
  "value": "id=3119  sec_id=4     flags=0x0000 ifindex=10  mac=FE:97:C1:B7:AE:86 nodemac=62:0F:C0:62:C7:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.076Z",
  "value": "id=288   sec_id=6611910 flags=0x0000 ifindex=14  mac=42:02:2E:EF:94:3E nodemac=A6:10:8E:C2:1B:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.076Z",
  "value": "id=1419  sec_id=6606335 flags=0x0000 ifindex=18  mac=B2:75:71:5B:8B:2B nodemac=56:7B:F9:67:3C:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.200.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.076Z",
  "value": "id=367   sec_id=6611910 flags=0x0000 ifindex=12  mac=7E:12:4C:B6:B6:7C nodemac=32:60:B3:63:B2:AD"
}

