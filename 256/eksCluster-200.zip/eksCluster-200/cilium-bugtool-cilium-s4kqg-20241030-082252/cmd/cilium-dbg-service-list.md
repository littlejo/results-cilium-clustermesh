ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.162.32:443 (active)     
                                          2 => 172.31.239.48:443 (active)     
2    10.100.74.213:443     ClusterIP      1 => 172.31.174.157:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.200.0.156:9153 (active)     
                                          2 => 10.200.0.125:9153 (active)     
4    10.100.0.10:53        ClusterIP      1 => 10.200.0.156:53 (active)       
                                          2 => 10.200.0.125:53 (active)       
5    10.100.153.177:2379   ClusterIP      1 => 10.200.0.214:2379 (active)     
