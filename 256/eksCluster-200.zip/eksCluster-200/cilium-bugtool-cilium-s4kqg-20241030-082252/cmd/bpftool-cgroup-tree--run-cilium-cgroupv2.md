CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod27a9b227_879b_4d31_8c85_39cae53654ea.slice/cri-containerd-463980bb1627ca0f1595c335a336be4154694f6598d7ce5d9480f33db8ff418a.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod27a9b227_879b_4d31_8c85_39cae53654ea.slice/cri-containerd-fb89c8e3f42e1ebbd28d206d99977df2c35ad3860308239af7c018d473f5ffa3.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab523a4b_848a_40e0_80c3_12e9a7ad9a7d.slice/cri-containerd-7631f23c65a45512fb85a51a0f98d227bd5caf24031f35c200c196b649986550.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab523a4b_848a_40e0_80c3_12e9a7ad9a7d.slice/cri-containerd-c6544515ef99878d9382f262fbe150b0fcf39f3c7f023dc5bcd671b78f579e4c.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod63fb0342_9f11_44fc_8b03_c08b839cf172.slice/cri-containerd-6b33c80cac8fd8404b6d8dafb6430ff7aab5924ea93049dcf6bdc6260f50261b.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod63fb0342_9f11_44fc_8b03_c08b839cf172.slice/cri-containerd-0e74ecb44849e7a560581a7f950741278e1ebe23ee44f100929ddf96a9730995.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod78728365_fe15_457a_af1f_55111661aa9d.slice/cri-containerd-a266e293ca2c743161008ad641a1ebdad9555751998619bbd267e321aebf5c52.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod78728365_fe15_457a_af1f_55111661aa9d.slice/cri-containerd-6e87381ae097b7574f2d973a4eb8e24adbc7b1382108d05f8ce5cb83f1c33d3f.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poded903af6_e47d_4a5e_b20d_0275d3caad24.slice/cri-containerd-c6ad298cecb4b75e88564f1a2ea7f7065297fba0cacc1c15197369d40a9a91bb.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poded903af6_e47d_4a5e_b20d_0275d3caad24.slice/cri-containerd-2609b26ed17edd14acbb3a0890df9aefbee763fce88b672124f0e55e83c56339.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcefde959_4e4e_4aea_a72b_4d66b316e6c2.slice/cri-containerd-7c23b7eb1f959ab0afccfd157ff6ada47fd60afce5b7fa00f5e020e0dabc7d8d.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcefde959_4e4e_4aea_a72b_4d66b316e6c2.slice/cri-containerd-0c2bfe81c865150bf687e13b04af0073e4c14a12620f07568e0f62de01e7ba30.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c6d0a1a_af39_4ace_8f98_ded2400ffb4d.slice/cri-containerd-3eecf53ecc1c160678bafb4d72b417d37dd7356fd9d8404bef4229b6c5157105.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c6d0a1a_af39_4ace_8f98_ded2400ffb4d.slice/cri-containerd-a4ceca0b4d3a548eb8150507fe3528e37c5e5dfb81db02cf2cf8a4fc88348852.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c6d0a1a_af39_4ace_8f98_ded2400ffb4d.slice/cri-containerd-69bbab5afbe8794e025b7ce878e77a0488dd479791cc5b013fb6e0c1da368ee7.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c6d0a1a_af39_4ace_8f98_ded2400ffb4d.slice/cri-containerd-8c7ac977ba3c219448a3664255f3d7e9f018e173bee025399ef2b2a7a10ffe44.scope
    623      cgroup_device   multi                                          
