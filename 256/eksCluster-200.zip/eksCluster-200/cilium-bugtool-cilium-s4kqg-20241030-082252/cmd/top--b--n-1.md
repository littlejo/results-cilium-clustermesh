top - 08:22:53 up 30 min,  0 users,  load average: 0.04, 0.11, 0.12
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 25.0 us, 21.4 sy,  0.0 ni, 53.6 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4479.2 free,   1187.7 used,   2147.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6441.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 385000  77816 S   6.7   4.8   0:49.96 cilium-+
    654 root      20   0 1240432  16380  11420 S   6.7   0.2   0:00.03 cilium-+
    414 root      20   0 1229744   7112   2864 S   0.0   0.1   0:01.19 cilium-+
    633 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    640 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
    686 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    693 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    694 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    695 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    734 root      20   0 1228744   3716   3040 S   0.0   0.0   0:00.00 gops
    739 root      20   0 1616008   8332   6256 S   0.0   0.1   0:00.00 runc:[2+
