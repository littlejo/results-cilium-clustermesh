USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         654  0.0  0.2 1240432 16380 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         674  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         677  0.0  0.0   4220   824 ?        R    08:22   0:00  \_ ip a
root         640  0.0  0.0 1228744 3780 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         633  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  4.0  4.8 1606080 385000 ?      Ssl  08:02   0:49 cilium-agent --config-dir=/tmp/cilium/config-map
root         414  0.0  0.0 1229744 7112 ?        Sl   08:02   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
