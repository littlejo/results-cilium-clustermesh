[
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb6ed069a_9cef_454e_b7fc_02191389e2d0.slice/cri-containerd-5f50089b02739331439abb68390bd11d0bf90d0c1470bb5e6a9a9ab9b294e88d.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb6ed069a_9cef_454e_b7fc_02191389e2d0.slice/cri-containerd-0bbc1219b23024ac3f95fa27fa03e41238948cf451232f61b24a97a6063f3028.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb6ed069a_9cef_454e_b7fc_02191389e2d0.slice/cri-containerd-c1ee2e43353df83b324353faa7202bbd0cfe7f63041cd1d823151bf5e2b762bf.scope"
      }
    ],
    "ips": [
      "10.68.0.133"
    ],
    "name": "clustermesh-apiserver-76d7d54646-ck7dv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7835,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9cedb4e1_925d_4b5d_869e_90637fe3241d.slice/cri-containerd-3c64b090f7c9ec86cd7623c8bcc42e0e9adb43df8f45365907f532edfbc73b16.scope"
      }
    ],
    "ips": [
      "10.68.0.78"
    ],
    "name": "coredns-cc6ccd49c-xwfh4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7751,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod02a19dd3_e69c_43ac_8b23_4e4f75116ff9.slice/cri-containerd-bebaefe204df37aaa4fc6432c924e8ad5a102c353dbbca4cae20ad6fee16511a.scope"
      }
    ],
    "ips": [
      "10.68.0.21"
    ],
    "name": "coredns-cc6ccd49c-xxbfs",
    "namespace": "kube-system"
  }
]

