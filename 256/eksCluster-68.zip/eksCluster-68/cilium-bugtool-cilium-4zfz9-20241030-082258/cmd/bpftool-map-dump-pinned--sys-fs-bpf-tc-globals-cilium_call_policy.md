key: 5f 00 00 00  value: 23 02 00 00
key: cf 03 00 00  value: 67 02 00 00
key: e2 0b 00 00  value: 1a 02 00 00
key: 35 0c 00 00  value: 21 02 00 00
Found 4 elements
