xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 499
ens6(5) clsact/ingress cil_from_netdev-ens6 id 511
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 493
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 489
cilium_host(7) clsact/egress cil_from_host-cilium_host id 487
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 553
lxcc916f6343693(12) clsact/ingress cil_from_container-lxcc916f6343693 id 529
lxc21da355caa8c(14) clsact/ingress cil_from_container-lxc21da355caa8c id 541
lxc3e5651455201(18) clsact/ingress cil_from_container-lxc3e5651455201 id 620

flow_dissector:

netfilter:

