REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36936     2920506     677    bpf_overlay.c
Interface                 INGRESS     682328    137578399   1132   bpf_host.c
Success                   EGRESS      16564     1303669     1694   bpf_host.c
Success                   EGRESS      19720     3125924     86     l3.h
Success                   EGRESS      298834    37328438    1308   bpf_lxc.c
Success                   EGRESS      37228     2943761     53     encap.h
Success                   INGRESS     342256    38907970    86     l3.h
Success                   INGRESS     383000    43694847    235    trace.h
Unsupported L3 protocol   EGRESS      41        3022        1492   bpf_lxc.c
