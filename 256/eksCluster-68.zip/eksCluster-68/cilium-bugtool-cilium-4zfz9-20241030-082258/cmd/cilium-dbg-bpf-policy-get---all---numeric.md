Endpoint ID: 95
Path: /sys/fs/bpf/tc/globals/cilium_policy_00095

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1662649   21047     0        
Allow    Ingress     1          ANY          NONE         disabled    25608     298       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 975
Path: /sys/fs/bpf/tc/globals/cilium_policy_00975

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11705887   116779    0        
Allow    Ingress     1          ANY          NONE         disabled    11280347   115510    0        
Allow    Egress      0          ANY          NONE         disabled    13139745   129406    0        


Endpoint ID: 1107
Path: /sys/fs/bpf/tc/globals/cilium_policy_01107

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3042
Path: /sys/fs/bpf/tc/globals/cilium_policy_03042

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    537937   4827      0        
Allow    Ingress     1          ANY          NONE         disabled    176103   2024      0        
Allow    Egress      0          ANY          NONE         disabled    120809   1170      0        


Endpoint ID: 3125
Path: /sys/fs/bpf/tc/globals/cilium_policy_03125

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    560581   5033      0        
Allow    Ingress     1          ANY          NONE         disabled    176631   2032      0        
Allow    Egress      0          ANY          NONE         disabled    125749   1217      0        


