USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         663  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         657  0.0  0.2 1240432 16012 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         687  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         689  0.0  0.0   3852  1296 ?        R    08:22   0:00  \_ bash -c hostname
root         638  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         629  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         625  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.2  5.0 1606272 406228 ?      Ssl  07:52   1:00 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.0  0.0 1229488 6788 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
