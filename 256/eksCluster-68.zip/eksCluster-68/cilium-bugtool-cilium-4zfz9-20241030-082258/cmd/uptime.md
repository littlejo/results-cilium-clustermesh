 08:23:00 up 37 min,  0 users,  load average: 0.08, 0.25, 0.23
