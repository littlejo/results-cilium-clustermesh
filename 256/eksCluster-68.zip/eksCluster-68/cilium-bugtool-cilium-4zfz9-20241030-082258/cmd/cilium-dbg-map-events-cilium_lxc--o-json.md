{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:32.121Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.159.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:32.121Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.164.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:32.121Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:36.912Z",
  "value": "id=95    sec_id=4     flags=0x0000 ifindex=10  mac=E2:EE:9B:D7:CE:94 nodemac=9E:43:B5:AA:3D:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:36.930Z",
  "value": "id=3042  sec_id=2285641 flags=0x0000 ifindex=12  mac=FA:F5:81:52:86:96 nodemac=8A:FF:3D:DF:5F:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:36.959Z",
  "value": "id=3125  sec_id=2285641 flags=0x0000 ifindex=14  mac=7E:2D:6C:2B:30:C0 nodemac=D6:90:AD:20:C5:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:36.962Z",
  "value": "id=3042  sec_id=2285641 flags=0x0000 ifindex=12  mac=FA:F5:81:52:86:96 nodemac=8A:FF:3D:DF:5F:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:36.990Z",
  "value": "id=95    sec_id=4     flags=0x0000 ifindex=10  mac=E2:EE:9B:D7:CE:94 nodemac=9E:43:B5:AA:3D:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:47.503Z",
  "value": "id=3125  sec_id=2285641 flags=0x0000 ifindex=14  mac=7E:2D:6C:2B:30:C0 nodemac=D6:90:AD:20:C5:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:47.504Z",
  "value": "id=3042  sec_id=2285641 flags=0x0000 ifindex=12  mac=FA:F5:81:52:86:96 nodemac=8A:FF:3D:DF:5F:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:47.505Z",
  "value": "id=95    sec_id=4     flags=0x0000 ifindex=10  mac=E2:EE:9B:D7:CE:94 nodemac=9E:43:B5:AA:3D:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:47.535Z",
  "value": "id=292   sec_id=2267562 flags=0x0000 ifindex=16  mac=02:D7:4E:D8:78:0C nodemac=DA:B6:E6:0E:D4:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:48.503Z",
  "value": "id=292   sec_id=2267562 flags=0x0000 ifindex=16  mac=02:D7:4E:D8:78:0C nodemac=DA:B6:E6:0E:D4:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:48.503Z",
  "value": "id=95    sec_id=4     flags=0x0000 ifindex=10  mac=E2:EE:9B:D7:CE:94 nodemac=9E:43:B5:AA:3D:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:48.503Z",
  "value": "id=3042  sec_id=2285641 flags=0x0000 ifindex=12  mac=FA:F5:81:52:86:96 nodemac=8A:FF:3D:DF:5F:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:48.504Z",
  "value": "id=3125  sec_id=2285641 flags=0x0000 ifindex=14  mac=7E:2D:6C:2B:30:C0 nodemac=D6:90:AD:20:C5:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.463Z",
  "value": "id=975   sec_id=2267562 flags=0x0000 ifindex=18  mac=86:83:C7:90:03:DE nodemac=E2:47:77:00:B5:25"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.68.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.640Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.287Z",
  "value": "id=975   sec_id=2267562 flags=0x0000 ifindex=18  mac=86:83:C7:90:03:DE nodemac=E2:47:77:00:B5:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.288Z",
  "value": "id=3042  sec_id=2285641 flags=0x0000 ifindex=12  mac=FA:F5:81:52:86:96 nodemac=8A:FF:3D:DF:5F:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.288Z",
  "value": "id=95    sec_id=4     flags=0x0000 ifindex=10  mac=E2:EE:9B:D7:CE:94 nodemac=9E:43:B5:AA:3D:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.288Z",
  "value": "id=3125  sec_id=2285641 flags=0x0000 ifindex=14  mac=7E:2D:6C:2B:30:C0 nodemac=D6:90:AD:20:C5:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.289Z",
  "value": "id=975   sec_id=2267562 flags=0x0000 ifindex=18  mac=86:83:C7:90:03:DE nodemac=E2:47:77:00:B5:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.289Z",
  "value": "id=95    sec_id=4     flags=0x0000 ifindex=10  mac=E2:EE:9B:D7:CE:94 nodemac=9E:43:B5:AA:3D:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.289Z",
  "value": "id=3042  sec_id=2285641 flags=0x0000 ifindex=12  mac=FA:F5:81:52:86:96 nodemac=8A:FF:3D:DF:5F:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.290Z",
  "value": "id=3125  sec_id=2285641 flags=0x0000 ifindex=14  mac=7E:2D:6C:2B:30:C0 nodemac=D6:90:AD:20:C5:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.291Z",
  "value": "id=975   sec_id=2267562 flags=0x0000 ifindex=18  mac=86:83:C7:90:03:DE nodemac=E2:47:77:00:B5:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.292Z",
  "value": "id=95    sec_id=4     flags=0x0000 ifindex=10  mac=E2:EE:9B:D7:CE:94 nodemac=9E:43:B5:AA:3D:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.292Z",
  "value": "id=3042  sec_id=2285641 flags=0x0000 ifindex=12  mac=FA:F5:81:52:86:96 nodemac=8A:FF:3D:DF:5F:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.293Z",
  "value": "id=3125  sec_id=2285641 flags=0x0000 ifindex=14  mac=7E:2D:6C:2B:30:C0 nodemac=D6:90:AD:20:C5:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.292Z",
  "value": "id=975   sec_id=2267562 flags=0x0000 ifindex=18  mac=86:83:C7:90:03:DE nodemac=E2:47:77:00:B5:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.292Z",
  "value": "id=95    sec_id=4     flags=0x0000 ifindex=10  mac=E2:EE:9B:D7:CE:94 nodemac=9E:43:B5:AA:3D:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.292Z",
  "value": "id=3042  sec_id=2285641 flags=0x0000 ifindex=12  mac=FA:F5:81:52:86:96 nodemac=8A:FF:3D:DF:5F:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.292Z",
  "value": "id=3125  sec_id=2285641 flags=0x0000 ifindex=14  mac=7E:2D:6C:2B:30:C0 nodemac=D6:90:AD:20:C5:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.293Z",
  "value": "id=3042  sec_id=2285641 flags=0x0000 ifindex=12  mac=FA:F5:81:52:86:96 nodemac=8A:FF:3D:DF:5F:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.293Z",
  "value": "id=975   sec_id=2267562 flags=0x0000 ifindex=18  mac=86:83:C7:90:03:DE nodemac=E2:47:77:00:B5:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.293Z",
  "value": "id=3125  sec_id=2285641 flags=0x0000 ifindex=14  mac=7E:2D:6C:2B:30:C0 nodemac=D6:90:AD:20:C5:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.293Z",
  "value": "id=95    sec_id=4     flags=0x0000 ifindex=10  mac=E2:EE:9B:D7:CE:94 nodemac=9E:43:B5:AA:3D:B4"
}

