1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:fa:36:4c:ce:e5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.164.224/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3141sec preferred_lft 3141sec
    inet6 fe80::4fa:36ff:fe4c:cee5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:de:22:69:a9:23 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.159.63/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4de:22ff:fe69:a923/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:87:81:73:4a:ad brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1087:81ff:fe73:4aad/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:15:ef:1e:1a:e2 brd ff:ff:ff:ff:ff:ff
    inet 10.68.0.114/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c415:efff:fe1e:1ae2/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 8e:9f:c8:85:47:5a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8c9f:c8ff:fe85:475a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:43:b5:aa:3d:b4 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::9c43:b5ff:feaa:3db4/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcc916f6343693@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:ff:3d:df:5f:47 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::88ff:3dff:fedf:5f47/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc21da355caa8c@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:90:ad:20:c5:66 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d490:adff:fe20:c566/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc3e5651455201@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:47:77:00:b5:25 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e047:77ff:fe00:b525/64 scope link 
       valid_lft forever preferred_lft forever
