KEY             VALUE
AgentLiveness   2300694053895
UTimeOffset     3379442013671875
