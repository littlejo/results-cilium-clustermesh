IP ADDRESS         LOCAL ENDPOINT INFO
10.68.0.87:0       id=95    sec_id=4     flags=0x0000 ifindex=10  mac=E2:EE:9B:D7:CE:94 nodemac=9E:43:B5:AA:3D:B4     
172.31.164.224:0   (localhost)                                                                                        
10.68.0.78:0       id=3125  sec_id=2285641 flags=0x0000 ifindex=14  mac=7E:2D:6C:2B:30:C0 nodemac=D6:90:AD:20:C5:66   
10.68.0.114:0      (localhost)                                                                                        
172.31.159.63:0    (localhost)                                                                                        
10.68.0.133:0      id=975   sec_id=2267562 flags=0x0000 ifindex=18  mac=86:83:C7:90:03:DE nodemac=E2:47:77:00:B5:25   
10.68.0.21:0       id=3042  sec_id=2285641 flags=0x0000 ifindex=12  mac=FA:F5:81:52:86:96 nodemac=8A:FF:3D:DF:5F:47   
