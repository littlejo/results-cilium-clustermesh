ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.177.64:443 (active)     
                                         2 => 172.31.202.89:443 (active)     
2    10.100.51.123:443    ClusterIP      1 => 172.31.164.224:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.68.0.21:53 (active)         
                                         2 => 10.68.0.78:53 (active)         
4    10.100.0.10:9153     ClusterIP      1 => 10.68.0.21:9153 (active)       
                                         2 => 10.68.0.78:9153 (active)       
5    10.100.51.191:2379   ClusterIP      1 => 10.68.0.133:2379 (active)      
