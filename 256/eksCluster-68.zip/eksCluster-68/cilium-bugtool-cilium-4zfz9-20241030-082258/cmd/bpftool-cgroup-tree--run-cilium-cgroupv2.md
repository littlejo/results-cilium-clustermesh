CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9cedb4e1_925d_4b5d_869e_90637fe3241d.slice/cri-containerd-94dbc1f86a9b78aa69693680af70a2dae964b0f69d1886fc422070765bd56f5e.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9cedb4e1_925d_4b5d_869e_90637fe3241d.slice/cri-containerd-3c64b090f7c9ec86cd7623c8bcc42e0e9adb43df8f45365907f532edfbc73b16.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod02a19dd3_e69c_43ac_8b23_4e4f75116ff9.slice/cri-containerd-61aa57ec5378c133ebec8e1045773fc8fb28f64d79a66801338a7a99e88dd3f6.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod02a19dd3_e69c_43ac_8b23_4e4f75116ff9.slice/cri-containerd-bebaefe204df37aaa4fc6432c924e8ad5a102c353dbbca4cae20ad6fee16511a.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1b309563_1847_45f3_a601_377b77a3d951.slice/cri-containerd-26725e4eb8affe54cc386542d89bcdf2a1fe14b6967cbda8599190c035042861.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1b309563_1847_45f3_a601_377b77a3d951.slice/cri-containerd-dd5f3931ae0ba505987883e7a406803c35bb2dd4f31e76ecd4f04db519b3fe96.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5c82c3cd_dfec_4938_b6c6_4d49458667c8.slice/cri-containerd-f6649fc0488bd71d8328f88c610f9959f0da065b2c88961ad3918e28316871b9.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5c82c3cd_dfec_4938_b6c6_4d49458667c8.slice/cri-containerd-af65f6fc2c848ea76c75d4a78a1db84fdd34669278aecf20cc10b9b2cfab4c1c.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb6ed069a_9cef_454e_b7fc_02191389e2d0.slice/cri-containerd-5f50089b02739331439abb68390bd11d0bf90d0c1470bb5e6a9a9ab9b294e88d.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb6ed069a_9cef_454e_b7fc_02191389e2d0.slice/cri-containerd-c1ee2e43353df83b324353faa7202bbd0cfe7f63041cd1d823151bf5e2b762bf.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb6ed069a_9cef_454e_b7fc_02191389e2d0.slice/cri-containerd-0bbc1219b23024ac3f95fa27fa03e41238948cf451232f61b24a97a6063f3028.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb6ed069a_9cef_454e_b7fc_02191389e2d0.slice/cri-containerd-7ae28b39b50b6fd034e42671efc21162011702e57acf3d0e9f0c4b6883089be4.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd593501_508e_4977_bd34_d31b03bcfb5f.slice/cri-containerd-9735cee0d20f00cecd9d3d071fca8f2b1db9f85d6c0a79192aa9a6c3bf25be9b.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd593501_508e_4977_bd34_d31b03bcfb5f.slice/cri-containerd-2d6b9f80f614b492c2ea6de95aaf08359c4b7647a3bc76f2fbd63fdd175b8e60.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf3e4e103_bf62_4641_8c5e_02e28db8e620.slice/cri-containerd-f500261d73c6580bb38d20be52072a5a7bcd8c9a8fa8ecf27aec5f244f94e9cd.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf3e4e103_bf62_4641_8c5e_02e28db8e620.slice/cri-containerd-fc0570b2c5ab0e5dd4f131c0b48a50d5e0ee3db7b3f35914c48c0c0d3abe46f5.scope
    106      cgroup_device   multi                                          
