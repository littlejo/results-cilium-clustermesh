Total: 682
TCP:   1885 (estab 449, closed 1417, orphaned 0, timewait 565)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  468       456       12       
INET	  478       462       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:32030 sk:40a cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15178 sk:40b cgroup:unreachable:f3c <->                                    
UNCONN 0      0                            127.0.0.1:43159      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:31974 sk:40c fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.164.224%ens5:68         0.0.0.0:*    uid:192 ino:75349 sk:40d cgroup:unreachable:c4e <->                            
UNCONN 0      0                                 [::]:8472          [::]:*    ino:32029 sk:40e cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15179 sk:40f cgroup:unreachable:f3c v6only:1 <->                           
UNCONN 0      0      [fe80::4fa:36ff:fe4c:cee5]%ens5:546           [::]:*    uid:192 ino:16447 sk:410 cgroup:unreachable:c4e v6only:1 <->                   
