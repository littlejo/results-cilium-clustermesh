alloc: 167.10MB (175217920 bytes)
total-alloc: 2.54GB (2725754496 bytes)
sys: 332.96MB (349131108 bytes)
lookups: 0
mallocs: 67741707
frees: 65772864
heap-alloc: 167.10MB (175217920 bytes)
heap-sys: 251.54MB (263757824 bytes)
heap-idle: 53.74MB (56352768 bytes)
heap-in-use: 197.80MB (207405056 bytes)
heap-released: 3.14MB (3293184 bytes)
heap-objects: 1968843
stack-in-use: 68.44MB (71761920 bytes)
stack-sys: 68.44MB (71761920 bytes)
stack-mspan-inuse: 3.39MB (3554400 bytes)
stack-mspan-sys: 3.94MB (4128960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.09MB (1145785 bytes)
gc-sys: 5.94MB (6225384 bytes)
next-gc: when heap-alloc >= 212.07MB (222375752 bytes)
last-gc: 2024-10-30 08:23:01.870035264 +0000 UTC
gc-pause-total: 32.104006ms
gc-pause: 116777
gc-pause-end: 1730276581870035264
num-gc: 88
num-forced-gc: 0
gc-cpu-fraction: 0.00044217838030219544
enable-gc: true
debug-gc: false
