top - 08:23:00 up 37 min,  0 users,  load average: 0.08, 0.25, 0.23
Tasks:  11 total,   3 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 53.3 us, 43.3 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4415.8 free,   1250.8 used,   2147.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6378.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606272 413092  78396 S  73.3   5.2   1:00.33 cilium-+
    625 root      20   0 1229704  25368   4004 S  20.0   0.3   0:00.03 gops
    703 root      20   0 1244340  20048  13692 S  13.3   0.3   0:00.03 hubble
    395 root      20   0 1229488   6788   2924 S   0.0   0.1   0:01.17 cilium-+
    629 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    638 root      20   0 1229000   4052   3392 R   0.0   0.1   0:00.00 gops
    657 root      20   0 1240432  16012  10768 S   0.0   0.2   0:00.03 cilium-+
    663 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    691 root      20   0    2208    784    704 S   0.0   0.0   0:00.00 timeout
    708 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    727 root      20   0       0      0      0 R   0.0   0.0   0:00.00 ipset
