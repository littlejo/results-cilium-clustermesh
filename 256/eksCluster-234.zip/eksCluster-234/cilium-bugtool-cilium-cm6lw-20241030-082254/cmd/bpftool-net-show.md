xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 575
ens6(5) clsact/ingress cil_from_netdev-ens6 id 583
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 569
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 560
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 482
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 502
lxcf5b4a79cc73d(12) clsact/ingress cil_from_container-lxcf5b4a79cc73d id 534
lxce8d1443ee25b(14) clsact/ingress cil_from_container-lxce8d1443ee25b id 543
lxce93a1dd13bd9(18) clsact/ingress cil_from_container-lxce93a1dd13bd9 id 627

flow_dissector:

netfilter:

