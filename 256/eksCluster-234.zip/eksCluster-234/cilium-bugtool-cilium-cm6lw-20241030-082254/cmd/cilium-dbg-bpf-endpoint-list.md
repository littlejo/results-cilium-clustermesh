IP ADDRESS         LOCAL ENDPOINT INFO
172.31.158.159:0   (localhost)                                                                                        
10.234.0.97:0      id=977   sec_id=4     flags=0x0000 ifindex=10  mac=5E:FA:49:C4:FC:C5 nodemac=AE:0A:CF:A2:25:DD     
10.234.0.1:0       id=1709  sec_id=7704526 flags=0x0000 ifindex=14  mac=BA:85:9F:6E:61:56 nodemac=EE:E4:C2:3C:B3:AD   
10.234.0.102:0     id=1369  sec_id=7704526 flags=0x0000 ifindex=12  mac=52:D9:4E:54:2D:D3 nodemac=36:7B:37:BA:C0:4F   
172.31.167.143:0   (localhost)                                                                                        
10.234.0.91:0      (localhost)                                                                                        
10.234.0.176:0     id=571   sec_id=7706306 flags=0x0000 ifindex=18  mac=3E:60:F9:C0:2D:F7 nodemac=6A:EB:FF:6F:F1:77   
