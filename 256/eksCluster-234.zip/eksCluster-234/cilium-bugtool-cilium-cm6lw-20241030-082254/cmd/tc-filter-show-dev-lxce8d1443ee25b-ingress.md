filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxce8d1443ee25b direct-action not_in_hw id 543 tag e370e76aebf755dc jited 
