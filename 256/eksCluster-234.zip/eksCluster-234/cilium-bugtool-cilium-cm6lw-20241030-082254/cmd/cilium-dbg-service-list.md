ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.164.156:443 (active)    
                                         2 => 172.31.202.153:443 (active)    
2    10.100.39.12:443     ClusterIP      1 => 172.31.167.143:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.234.0.1:9153 (active)       
                                         2 => 10.234.0.102:9153 (active)     
4    10.100.0.10:53       ClusterIP      1 => 10.234.0.1:53 (active)         
                                         2 => 10.234.0.102:53 (active)       
5    10.100.33.217:2379   ClusterIP      1 => 10.234.0.176:2379 (active)     
