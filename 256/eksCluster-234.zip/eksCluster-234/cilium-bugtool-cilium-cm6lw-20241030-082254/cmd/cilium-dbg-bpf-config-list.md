KEY             VALUE
AgentLiveness   1635571774177
UTimeOffset     3379443302734375
