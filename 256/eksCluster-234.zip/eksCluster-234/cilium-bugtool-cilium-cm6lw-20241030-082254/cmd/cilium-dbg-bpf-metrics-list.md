REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35651     2815812     677    bpf_overlay.c
Interface                 INGRESS     619970    128534557   1132   bpf_host.c
Success                   EGRESS      15255     1196888     1694   bpf_host.c
Success                   EGRESS      16060     2545274     86     l3.h
Success                   EGRESS      259665    33122684    1308   bpf_lxc.c
Success                   EGRESS      35036     2773410     53     encap.h
Success                   INGRESS     301148    33807264    86     l3.h
Success                   INGRESS     338255    38015508    235    trace.h
Unsupported L3 protocol   EGRESS      38        2812        1492   bpf_lxc.c
