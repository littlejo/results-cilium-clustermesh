alloc: 144.40MB (151413064 bytes)
total-alloc: 2.21GB (2375945952 bytes)
sys: 336.96MB (353328500 bytes)
lookups: 0
mallocs: 63041434
frees: 61873431
heap-alloc: 144.40MB (151413064 bytes)
heap-sys: 259.41MB (272015360 bytes)
heap-idle: 78.18MB (81977344 bytes)
heap-in-use: 181.23MB (190038016 bytes)
heap-released: 15.63MB (16392192 bytes)
heap-objects: 1168003
stack-in-use: 64.56MB (67698688 bytes)
stack-sys: 64.56MB (67698688 bytes)
stack-mspan-inuse: 2.81MB (2950560 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.04MB (1088841 bytes)
gc-sys: 6.17MB (6465920 bytes)
next-gc: when heap-alloc >= 212.06MB (222365480 bytes)
last-gc: 2024-10-30 08:23:13.936344365 +0000 UTC
gc-pause-total: 6.461411ms
gc-pause: 144281
gc-pause-end: 1730276593936344365
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0004854463786864575
enable-gc: true
debug-gc: false
