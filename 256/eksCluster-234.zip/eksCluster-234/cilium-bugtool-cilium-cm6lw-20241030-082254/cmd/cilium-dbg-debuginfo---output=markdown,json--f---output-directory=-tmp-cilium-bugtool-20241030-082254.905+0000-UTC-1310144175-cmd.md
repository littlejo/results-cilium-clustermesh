markdown output at /tmp/cilium-bugtool-20241030-082254.905+0000-UTC-1310144175/cmd/cilium-debuginfo-20241030-082326.258+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082254.905+0000-UTC-1310144175/cmd/cilium-debuginfo-20241030-082326.258+0000-UTC.json
