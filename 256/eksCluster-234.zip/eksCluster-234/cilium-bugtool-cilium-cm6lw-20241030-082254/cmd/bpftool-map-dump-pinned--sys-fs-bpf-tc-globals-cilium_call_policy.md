key: 3b 02 00 00  value: 79 02 00 00
key: d1 03 00 00  value: 05 02 00 00
key: 59 05 00 00  value: 09 02 00 00
key: ad 06 00 00  value: 1e 02 00 00
Found 4 elements
