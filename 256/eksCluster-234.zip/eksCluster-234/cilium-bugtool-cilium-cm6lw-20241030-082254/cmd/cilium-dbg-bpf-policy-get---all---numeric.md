Endpoint ID: 571
Path: /sys/fs/bpf/tc/globals/cilium_policy_00571

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11192398   108972    0        
Allow    Ingress     1          ANY          NONE         disabled    9303853    97346     0        
Allow    Egress      0          ANY          NONE         disabled    10630210   106077    0        


Endpoint ID: 977
Path: /sys/fs/bpf/tc/globals/cilium_policy_00977

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1666096   21087     0        
Allow    Ingress     1          ANY          NONE         disabled    16978     199       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1369
Path: /sys/fs/bpf/tc/globals/cilium_policy_01369

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    449697   4032      0        
Allow    Ingress     1          ANY          NONE         disabled    109951   1262      0        
Allow    Egress      0          ANY          NONE         disabled    113464   1078      0        


Endpoint ID: 1709
Path: /sys/fs/bpf/tc/globals/cilium_policy_01709

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    444727   3998      0        
Allow    Ingress     1          ANY          NONE         disabled    108379   1245      0        
Allow    Egress      0          ANY          NONE         disabled    112985   1076      0        


Endpoint ID: 3342
Path: /sys/fs/bpf/tc/globals/cilium_policy_03342

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


