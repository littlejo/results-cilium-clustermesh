CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poded144d46_1bea_47fa_b305_7615ce0fa218.slice/cri-containerd-8d1199df2f39e3d222937c148dedc563fa607a21d690b9be271fa5bdb4bfb5f1.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poded144d46_1bea_47fa_b305_7615ce0fa218.slice/cri-containerd-bb36de59f9f9764bd8a7a316d94e96552b1632e91c6916d9c4d9467df555b16f.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda6d75106_dc50_495c_9c1b_1a20cf76b60f.slice/cri-containerd-507ffcd1d63220ec8d9deb7e3db109d4fca761bb96e463ff231d6fa53bc85f3c.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda6d75106_dc50_495c_9c1b_1a20cf76b60f.slice/cri-containerd-c947dd1b72c049153ba63bd95fd0c982dd2f473cc9be43966ea43236c41b7feb.scope
    531      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd40f8ed7_9d49_4d04_8a74_c2c14fe5f3ba.slice/cri-containerd-72a0228458143057a4f9178136fd5d099c5a5eee1fba9b5036ec3cf1f3a30416.scope
    525      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd40f8ed7_9d49_4d04_8a74_c2c14fe5f3ba.slice/cri-containerd-9af5c1dc55b6a1c9ed2ab611f136ce2b6458584e8c3f6e3f595beb59fc852554.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbe208a2c_16d0_4b96_9ea2_be0315a0b319.slice/cri-containerd-14eb0342604ffad2641ae40bbe6236cc2a467430e38bfe393582e6fed600cab8.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbe208a2c_16d0_4b96_9ea2_be0315a0b319.slice/cri-containerd-3bd10bc00dbcfa66193e954202446309b271f8d4f610cf38c96b656562439ce3.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ef3af3_453c_4285_8a01_9359ce4f81af.slice/cri-containerd-57a1c7f27ff5a64c05455844bb227be07aba730f8ae3654157bb7708de7741fa.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ef3af3_453c_4285_8a01_9359ce4f81af.slice/cri-containerd-88d7eaecb23827e99946d4a7d21fd9e4c3cd71c1925a9d66e511734b2b37cc7a.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57c4795b_3c01_4f4c_8edd_1601aa0fdec5.slice/cri-containerd-9c784a00f7749b6c7f482b5fbb2a80cec32bbaa5c43f8262bbbdce30ab8fabfe.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57c4795b_3c01_4f4c_8edd_1601aa0fdec5.slice/cri-containerd-5446f74d158ccc19003a1f0a4f3cd2199923e1abafd00938b501131e0480ed84.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57c4795b_3c01_4f4c_8edd_1601aa0fdec5.slice/cri-containerd-eaae8730f39890405539b86eaa5513e386d32944a9f4481db4343b240fc894e0.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57c4795b_3c01_4f4c_8edd_1601aa0fdec5.slice/cri-containerd-a4f5bbb140a6d6f056eb90d5aa39fbe8491e6adb15ee844ebda66efe879e8dfc.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod20114d32_a3d9_4d0d_bdff_16854c74a027.slice/cri-containerd-3c0011f08872efa832b9c894416ad8a20a5b2ea1415f3a93fb473db15e5de120.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod20114d32_a3d9_4d0d_bdff_16854c74a027.slice/cri-containerd-f4708fd1eb5f456cb29cf2728d9b9e0d34c3ce6b5e83ea471703572c2328198d.scope
    94       cgroup_device   multi                                          
