[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57c4795b_3c01_4f4c_8edd_1601aa0fdec5.slice/cri-containerd-9c784a00f7749b6c7f482b5fbb2a80cec32bbaa5c43f8262bbbdce30ab8fabfe.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57c4795b_3c01_4f4c_8edd_1601aa0fdec5.slice/cri-containerd-5446f74d158ccc19003a1f0a4f3cd2199923e1abafd00938b501131e0480ed84.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57c4795b_3c01_4f4c_8edd_1601aa0fdec5.slice/cri-containerd-a4f5bbb140a6d6f056eb90d5aa39fbe8491e6adb15ee844ebda66efe879e8dfc.scope"
      }
    ],
    "ips": [
      "10.234.0.176"
    ],
    "name": "clustermesh-apiserver-68df665464-v4p86",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda6d75106_dc50_495c_9c1b_1a20cf76b60f.slice/cri-containerd-507ffcd1d63220ec8d9deb7e3db109d4fca761bb96e463ff231d6fa53bc85f3c.scope"
      }
    ],
    "ips": [
      "10.234.0.1"
    ],
    "name": "coredns-cc6ccd49c-2mtc8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd40f8ed7_9d49_4d04_8a74_c2c14fe5f3ba.slice/cri-containerd-9af5c1dc55b6a1c9ed2ab611f136ce2b6458584e8c3f6e3f595beb59fc852554.scope"
      }
    ],
    "ips": [
      "10.234.0.102"
    ],
    "name": "coredns-cc6ccd49c-x9f6t",
    "namespace": "kube-system"
  }
]

