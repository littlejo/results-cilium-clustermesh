{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:14.007Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.158.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:14.007Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.167.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:14.007Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:18.419Z",
  "value": "id=1369  sec_id=7704526 flags=0x0000 ifindex=12  mac=52:D9:4E:54:2D:D3 nodemac=36:7B:37:BA:C0:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:18.446Z",
  "value": "id=1709  sec_id=7704526 flags=0x0000 ifindex=14  mac=BA:85:9F:6E:61:56 nodemac=EE:E4:C2:3C:B3:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:18.483Z",
  "value": "id=977   sec_id=4     flags=0x0000 ifindex=10  mac=5E:FA:49:C4:FC:C5 nodemac=AE:0A:CF:A2:25:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:18.573Z",
  "value": "id=1369  sec_id=7704526 flags=0x0000 ifindex=12  mac=52:D9:4E:54:2D:D3 nodemac=36:7B:37:BA:C0:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:18.618Z",
  "value": "id=1709  sec_id=7704526 flags=0x0000 ifindex=14  mac=BA:85:9F:6E:61:56 nodemac=EE:E4:C2:3C:B3:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:23.824Z",
  "value": "id=977   sec_id=4     flags=0x0000 ifindex=10  mac=5E:FA:49:C4:FC:C5 nodemac=AE:0A:CF:A2:25:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:23.825Z",
  "value": "id=1369  sec_id=7704526 flags=0x0000 ifindex=12  mac=52:D9:4E:54:2D:D3 nodemac=36:7B:37:BA:C0:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:23.826Z",
  "value": "id=1709  sec_id=7704526 flags=0x0000 ifindex=14  mac=BA:85:9F:6E:61:56 nodemac=EE:E4:C2:3C:B3:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:23.856Z",
  "value": "id=1893  sec_id=7706306 flags=0x0000 ifindex=16  mac=D6:9E:33:BA:D4:F4 nodemac=76:64:2A:D7:01:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:23.857Z",
  "value": "id=1893  sec_id=7706306 flags=0x0000 ifindex=16  mac=D6:9E:33:BA:D4:F4 nodemac=76:64:2A:D7:01:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:24.824Z",
  "value": "id=1893  sec_id=7706306 flags=0x0000 ifindex=16  mac=D6:9E:33:BA:D4:F4 nodemac=76:64:2A:D7:01:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:24.824Z",
  "value": "id=1369  sec_id=7704526 flags=0x0000 ifindex=12  mac=52:D9:4E:54:2D:D3 nodemac=36:7B:37:BA:C0:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:24.824Z",
  "value": "id=1709  sec_id=7704526 flags=0x0000 ifindex=14  mac=BA:85:9F:6E:61:56 nodemac=EE:E4:C2:3C:B3:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:24.825Z",
  "value": "id=977   sec_id=4     flags=0x0000 ifindex=10  mac=5E:FA:49:C4:FC:C5 nodemac=AE:0A:CF:A2:25:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.867Z",
  "value": "id=571   sec_id=7706306 flags=0x0000 ifindex=18  mac=3E:60:F9:C0:2D:F7 nodemac=6A:EB:FF:6F:F1:77"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.234.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.398Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.647Z",
  "value": "id=1369  sec_id=7704526 flags=0x0000 ifindex=12  mac=52:D9:4E:54:2D:D3 nodemac=36:7B:37:BA:C0:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.647Z",
  "value": "id=1709  sec_id=7704526 flags=0x0000 ifindex=14  mac=BA:85:9F:6E:61:56 nodemac=EE:E4:C2:3C:B3:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.647Z",
  "value": "id=977   sec_id=4     flags=0x0000 ifindex=10  mac=5E:FA:49:C4:FC:C5 nodemac=AE:0A:CF:A2:25:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.648Z",
  "value": "id=571   sec_id=7706306 flags=0x0000 ifindex=18  mac=3E:60:F9:C0:2D:F7 nodemac=6A:EB:FF:6F:F1:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.647Z",
  "value": "id=571   sec_id=7706306 flags=0x0000 ifindex=18  mac=3E:60:F9:C0:2D:F7 nodemac=6A:EB:FF:6F:F1:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.648Z",
  "value": "id=1369  sec_id=7704526 flags=0x0000 ifindex=12  mac=52:D9:4E:54:2D:D3 nodemac=36:7B:37:BA:C0:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.648Z",
  "value": "id=1709  sec_id=7704526 flags=0x0000 ifindex=14  mac=BA:85:9F:6E:61:56 nodemac=EE:E4:C2:3C:B3:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.648Z",
  "value": "id=977   sec_id=4     flags=0x0000 ifindex=10  mac=5E:FA:49:C4:FC:C5 nodemac=AE:0A:CF:A2:25:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.647Z",
  "value": "id=571   sec_id=7706306 flags=0x0000 ifindex=18  mac=3E:60:F9:C0:2D:F7 nodemac=6A:EB:FF:6F:F1:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.648Z",
  "value": "id=1369  sec_id=7704526 flags=0x0000 ifindex=12  mac=52:D9:4E:54:2D:D3 nodemac=36:7B:37:BA:C0:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.648Z",
  "value": "id=1709  sec_id=7704526 flags=0x0000 ifindex=14  mac=BA:85:9F:6E:61:56 nodemac=EE:E4:C2:3C:B3:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.648Z",
  "value": "id=977   sec_id=4     flags=0x0000 ifindex=10  mac=5E:FA:49:C4:FC:C5 nodemac=AE:0A:CF:A2:25:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.648Z",
  "value": "id=1369  sec_id=7704526 flags=0x0000 ifindex=12  mac=52:D9:4E:54:2D:D3 nodemac=36:7B:37:BA:C0:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.648Z",
  "value": "id=1709  sec_id=7704526 flags=0x0000 ifindex=14  mac=BA:85:9F:6E:61:56 nodemac=EE:E4:C2:3C:B3:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.649Z",
  "value": "id=977   sec_id=4     flags=0x0000 ifindex=10  mac=5E:FA:49:C4:FC:C5 nodemac=AE:0A:CF:A2:25:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.234.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.649Z",
  "value": "id=571   sec_id=7706306 flags=0x0000 ifindex=18  mac=3E:60:F9:C0:2D:F7 nodemac=6A:EB:FF:6F:F1:77"
}

