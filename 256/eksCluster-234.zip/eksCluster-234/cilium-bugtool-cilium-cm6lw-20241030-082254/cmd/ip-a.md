1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d9:12:b0:81:8d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.167.143/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2007sec preferred_lft 2007sec
    inet6 fe80::4d9:12ff:feb0:818d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:53:77:8d:2d:63 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.158.159/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::453:77ff:fe8d:2d63/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:88:eb:8b:5f:34 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::cc88:ebff:fe8b:5f34/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:61:26:41:00:3d brd ff:ff:ff:ff:ff:ff
    inet 10.234.0.91/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::2861:26ff:fe41:3d/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ae:ee:10:89:38:7e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::acee:10ff:fe89:387e/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:0a:cf:a2:25:dd brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::ac0a:cfff:fea2:25dd/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf5b4a79cc73d@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:7b:37:ba:c0:4f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::347b:37ff:feba:c04f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce8d1443ee25b@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:e4:c2:3c:b3:ad brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::ece4:c2ff:fe3c:b3ad/64 scope link 
       valid_lft forever preferred_lft forever
18: lxce93a1dd13bd9@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:eb:ff:6f:f1:77 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::68eb:ffff:fe6f:f177/64 scope link 
       valid_lft forever preferred_lft forever
