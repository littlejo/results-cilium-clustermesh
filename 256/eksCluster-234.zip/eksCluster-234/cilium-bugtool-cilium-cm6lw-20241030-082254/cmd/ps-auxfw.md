USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         603  0.0  0.2 1240176 16312 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         621  0.0  0.0   6408  1648 ?        R    08:22   0:00  \_ ps auxfw
root         623  0.0  0.0   3728   488 ?        R    08:22   0:00  \_ bash -c ip a
root           1  3.8  4.7 1606208 379476 ?      Ssl  08:04   0:43 cilium-agent --config-dir=/tmp/cilium/config-map
root         417  0.1  0.1 1229744 8020 ?        Sl   08:04   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
