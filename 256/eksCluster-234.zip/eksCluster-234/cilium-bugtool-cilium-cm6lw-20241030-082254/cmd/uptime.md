 08:22:55 up 26 min,  0 users,  load average: 0.48, 0.31, 0.22
