top - 08:22:55 up 26 min,  0 users,  load average: 0.48, 0.31, 0.22
Tasks:   8 total,   2 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 23.3 us, 63.3 sy,  0.0 ni,  6.7 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   7814.2 total,   4492.3 free,   1176.8 used,   2145.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6452.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606208 380624  79040 R  20.0   4.8   0:43.05 cilium-+
    417 root      20   0 1229744   8020   3836 S   0.0   0.1   0:01.14 cilium-+
    603 root      20   0 1240176  16312  11228 S   0.0   0.2   0:00.02 cilium-+
    642 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    657 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    681 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    693 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
    712 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
