key: 5c 02 00 00  value: f8 01 00 00
key: 24 0b 00 00  value: 6c 02 00 00
key: 8a 0b 00 00  value: 19 02 00 00
key: f4 0c 00 00  value: 0b 02 00 00
Found 4 elements
