KEY             VALUE
AgentLiveness   1679464349609
UTimeOffset     3379443220703125
