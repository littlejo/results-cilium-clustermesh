{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:53.906Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.194.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:53.906Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.214.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:53.906Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:58.353Z",
  "value": "id=3316  sec_id=8335639 flags=0x0000 ifindex=12  mac=8E:30:AA:AC:72:F5 nodemac=E6:FE:95:7E:8D:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:58.359Z",
  "value": "id=2954  sec_id=8335639 flags=0x0000 ifindex=14  mac=E6:DC:0A:84:87:2A nodemac=86:87:F2:40:DB:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:58.454Z",
  "value": "id=604   sec_id=4     flags=0x0000 ifindex=10  mac=A2:D2:6E:E4:7C:50 nodemac=02:51:AE:70:DB:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:58.492Z",
  "value": "id=3316  sec_id=8335639 flags=0x0000 ifindex=12  mac=8E:30:AA:AC:72:F5 nodemac=E6:FE:95:7E:8D:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:58.577Z",
  "value": "id=2954  sec_id=8335639 flags=0x0000 ifindex=14  mac=E6:DC:0A:84:87:2A nodemac=86:87:F2:40:DB:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:00.506Z",
  "value": "id=3316  sec_id=8335639 flags=0x0000 ifindex=12  mac=8E:30:AA:AC:72:F5 nodemac=E6:FE:95:7E:8D:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:00.507Z",
  "value": "id=2954  sec_id=8335639 flags=0x0000 ifindex=14  mac=E6:DC:0A:84:87:2A nodemac=86:87:F2:40:DB:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:00.507Z",
  "value": "id=604   sec_id=4     flags=0x0000 ifindex=10  mac=A2:D2:6E:E4:7C:50 nodemac=02:51:AE:70:DB:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:00.536Z",
  "value": "id=3091  sec_id=8327731 flags=0x0000 ifindex=16  mac=8E:EE:4D:F3:D3:68 nodemac=9E:94:02:C2:10:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:01.507Z",
  "value": "id=3091  sec_id=8327731 flags=0x0000 ifindex=16  mac=8E:EE:4D:F3:D3:68 nodemac=9E:94:02:C2:10:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:01.507Z",
  "value": "id=3316  sec_id=8335639 flags=0x0000 ifindex=12  mac=8E:30:AA:AC:72:F5 nodemac=E6:FE:95:7E:8D:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:01.507Z",
  "value": "id=2954  sec_id=8335639 flags=0x0000 ifindex=14  mac=E6:DC:0A:84:87:2A nodemac=86:87:F2:40:DB:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:01.507Z",
  "value": "id=604   sec_id=4     flags=0x0000 ifindex=10  mac=A2:D2:6E:E4:7C:50 nodemac=02:51:AE:70:DB:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.147Z",
  "value": "id=2852  sec_id=8327731 flags=0x0000 ifindex=18  mac=46:2D:C8:C1:3A:4F nodemac=56:9C:B2:95:69:8D"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.253.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.594Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.097Z",
  "value": "id=2852  sec_id=8327731 flags=0x0000 ifindex=18  mac=46:2D:C8:C1:3A:4F nodemac=56:9C:B2:95:69:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.098Z",
  "value": "id=3316  sec_id=8335639 flags=0x0000 ifindex=12  mac=8E:30:AA:AC:72:F5 nodemac=E6:FE:95:7E:8D:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.098Z",
  "value": "id=2954  sec_id=8335639 flags=0x0000 ifindex=14  mac=E6:DC:0A:84:87:2A nodemac=86:87:F2:40:DB:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.098Z",
  "value": "id=604   sec_id=4     flags=0x0000 ifindex=10  mac=A2:D2:6E:E4:7C:50 nodemac=02:51:AE:70:DB:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.105Z",
  "value": "id=3316  sec_id=8335639 flags=0x0000 ifindex=12  mac=8E:30:AA:AC:72:F5 nodemac=E6:FE:95:7E:8D:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.105Z",
  "value": "id=2954  sec_id=8335639 flags=0x0000 ifindex=14  mac=E6:DC:0A:84:87:2A nodemac=86:87:F2:40:DB:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.105Z",
  "value": "id=604   sec_id=4     flags=0x0000 ifindex=10  mac=A2:D2:6E:E4:7C:50 nodemac=02:51:AE:70:DB:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.106Z",
  "value": "id=2852  sec_id=8327731 flags=0x0000 ifindex=18  mac=46:2D:C8:C1:3A:4F nodemac=56:9C:B2:95:69:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.105Z",
  "value": "id=2852  sec_id=8327731 flags=0x0000 ifindex=18  mac=46:2D:C8:C1:3A:4F nodemac=56:9C:B2:95:69:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.105Z",
  "value": "id=3316  sec_id=8335639 flags=0x0000 ifindex=12  mac=8E:30:AA:AC:72:F5 nodemac=E6:FE:95:7E:8D:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.106Z",
  "value": "id=2954  sec_id=8335639 flags=0x0000 ifindex=14  mac=E6:DC:0A:84:87:2A nodemac=86:87:F2:40:DB:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.106Z",
  "value": "id=604   sec_id=4     flags=0x0000 ifindex=10  mac=A2:D2:6E:E4:7C:50 nodemac=02:51:AE:70:DB:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.106Z",
  "value": "id=604   sec_id=4     flags=0x0000 ifindex=10  mac=A2:D2:6E:E4:7C:50 nodemac=02:51:AE:70:DB:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.106Z",
  "value": "id=2852  sec_id=8327731 flags=0x0000 ifindex=18  mac=46:2D:C8:C1:3A:4F nodemac=56:9C:B2:95:69:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.106Z",
  "value": "id=3316  sec_id=8335639 flags=0x0000 ifindex=12  mac=8E:30:AA:AC:72:F5 nodemac=E6:FE:95:7E:8D:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.253.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.107Z",
  "value": "id=2954  sec_id=8335639 flags=0x0000 ifindex=14  mac=E6:DC:0A:84:87:2A nodemac=86:87:F2:40:DB:E8"
}

