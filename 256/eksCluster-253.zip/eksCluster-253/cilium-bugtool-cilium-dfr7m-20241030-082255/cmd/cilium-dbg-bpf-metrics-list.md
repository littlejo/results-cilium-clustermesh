REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35551     2812771     677    bpf_overlay.c
Interface                 INGRESS     617267    128426025   1132   bpf_host.c
Success                   EGRESS      15319     1201320     1694   bpf_host.c
Success                   EGRESS      260205    32948358    1308   bpf_lxc.c
Success                   EGRESS      34928     2766949     53     encap.h
Success                   INGRESS     300442    33799878    86     l3.h
Success                   INGRESS     321324    35455309    235    trace.h
Unsupported L3 protocol   EGRESS      38        2812        1492   bpf_lxc.c
