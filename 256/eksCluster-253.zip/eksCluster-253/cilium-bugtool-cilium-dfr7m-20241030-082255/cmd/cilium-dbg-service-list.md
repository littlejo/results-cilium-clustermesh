ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.156.249:443 (active)    
                                         2 => 172.31.242.150:443 (active)    
2    10.100.32.154:443    ClusterIP      1 => 172.31.194.196:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.253.0.247:53 (active)       
                                         2 => 10.253.0.225:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.253.0.247:9153 (active)     
                                         2 => 10.253.0.225:9153 (active)     
5    10.100.36.135:2379   ClusterIP      1 => 10.253.0.121:2379 (active)     
