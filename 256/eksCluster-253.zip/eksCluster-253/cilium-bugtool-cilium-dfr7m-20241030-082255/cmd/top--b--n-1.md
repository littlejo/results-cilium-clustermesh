top - 08:22:57 up 27 min,  0 users,  load average: 0.37, 0.39, 0.26
Tasks:  11 total,   2 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 56.7 us, 36.7 sy,  0.0 ni,  6.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4488.3 free,   1181.0 used,   2145.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6448.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 383920  78252 S  80.0   4.8   0:46.19 cilium-+
    649 root      20   0 1240432  16568  11356 S   6.7   0.2   0:00.03 cilium-+
    718 root      20   0 1244340  21276  14144 S   6.7   0.3   0:00.03 hubble
    403 root      20   0 1229744   7960   3904 S   0.0   0.1   0:01.15 cilium-+
    648 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    665 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    671 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
    705 root      20   0    2208    784    704 S   0.0   0.0   0:00.00 timeout
    731 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    746 root      20   0 1616264   9236   6520 R   0.0   0.1   0:00.00 runc:[2+
    756 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
