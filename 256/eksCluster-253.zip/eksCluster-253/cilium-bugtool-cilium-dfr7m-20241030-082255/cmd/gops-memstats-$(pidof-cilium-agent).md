alloc: 105.12MB (110229232 bytes)
total-alloc: 2.17GB (2326436200 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 62139190
frees: 61336013
heap-alloc: 105.12MB (110229232 bytes)
heap-sys: 247.63MB (259661824 bytes)
heap-idle: 87.77MB (92037120 bytes)
heap-in-use: 159.86MB (167624704 bytes)
heap-released: 13.21MB (13852672 bytes)
heap-objects: 803177
stack-in-use: 64.34MB (67469312 bytes)
stack-sys: 64.34MB (67469312 bytes)
stack-mspan-inuse: 2.74MB (2870560 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.00MB (1049009 bytes)
gc-sys: 5.99MB (6278584 bytes)
next-gc: when heap-alloc >= 214.00MB (224395752 bytes)
last-gc: 2024-10-30 08:23:24.015817917 +0000 UTC
gc-pause-total: 8.053876ms
gc-pause: 65764
gc-pause-end: 1730276604015817917
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005916779316899703
enable-gc: true
debug-gc: false
