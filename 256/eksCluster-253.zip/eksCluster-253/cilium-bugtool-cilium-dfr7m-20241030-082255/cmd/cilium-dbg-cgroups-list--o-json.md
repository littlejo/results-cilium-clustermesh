[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9639965f_5732_4908_a5ef_63dc0ebfb8ca.slice/cri-containerd-e16fd4825843c058d9687d3a354995a1407a458ed8ec82f2c4bac92a9602c6b4.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9639965f_5732_4908_a5ef_63dc0ebfb8ca.slice/cri-containerd-f2b10210271c3ddbc62da8a709474c4d1d7b20656c02af85e89c12450b6c1c1f.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9639965f_5732_4908_a5ef_63dc0ebfb8ca.slice/cri-containerd-a60848858073506997d0b2254ed1f6c8458ef89bfac5bbbcd5c4939cab7febd0.scope"
      }
    ],
    "ips": [
      "10.253.0.121"
    ],
    "name": "clustermesh-apiserver-77cbfdfbc-7nw4s",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod85f50a6b_e708_4e52_aa90_1e14a1859345.slice/cri-containerd-a5b8cc51fbe419f42b8af8980283d4b818a0f65bf6d6f1561e90c432aa9a8b1f.scope"
      }
    ],
    "ips": [
      "10.253.0.225"
    ],
    "name": "coredns-cc6ccd49c-tlq56",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod81736ff0_af2e_487c_ac09_950588bfd5d5.slice/cri-containerd-e36987b12c0cd89480246147bd66692dd2a0eed09cfd906959dc9daa9021e77c.scope"
      }
    ],
    "ips": [
      "10.253.0.247"
    ],
    "name": "coredns-cc6ccd49c-pftjw",
    "namespace": "kube-system"
  }
]

