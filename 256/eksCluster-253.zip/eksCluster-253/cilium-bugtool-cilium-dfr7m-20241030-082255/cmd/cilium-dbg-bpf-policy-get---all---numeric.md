Endpoint ID: 604
Path: /sys/fs/bpf/tc/globals/cilium_policy_00604

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1660598   20946     0        
Allow    Ingress     1          ANY          NONE         disabled    17296     203       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 869
Path: /sys/fs/bpf/tc/globals/cilium_policy_00869

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2852
Path: /sys/fs/bpf/tc/globals/cilium_policy_02852

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11419704   112423    0        
Allow    Ingress     1          ANY          NONE         disabled    9219643    96289     0        
Allow    Egress      0          ANY          NONE         disabled    11418289   113395    0        


Endpoint ID: 2954
Path: /sys/fs/bpf/tc/globals/cilium_policy_02954

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    111811   1283      0        
Allow    Egress      0          ANY          NONE         disabled    15729    169       0        


Endpoint ID: 3316
Path: /sys/fs/bpf/tc/globals/cilium_policy_03316

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    111745   1282      0        
Allow    Egress      0          ANY          NONE         disabled    15868    171       0        


