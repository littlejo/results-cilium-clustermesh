CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod81736ff0_af2e_487c_ac09_950588bfd5d5.slice/cri-containerd-e36987b12c0cd89480246147bd66692dd2a0eed09cfd906959dc9daa9021e77c.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod81736ff0_af2e_487c_ac09_950588bfd5d5.slice/cri-containerd-f72eedf942bfdc66d493c97add095cbacf0bf71595f6b5e1a6135c7bc78c9d9d.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode35e7ddc_67e5_448e_aef9_c8bae72a0d83.slice/cri-containerd-d56e7889afa48a1c0a8e9109d8a14fa0f310c9d133c1c923239e85dad9609d15.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode35e7ddc_67e5_448e_aef9_c8bae72a0d83.slice/cri-containerd-c20e8144443cacb78c4c63f7b9f378b1804be31640ebc0af18fb53b170a448cc.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod461235db_b561_4daa_8d30_84900c99c223.slice/cri-containerd-6f833e3ad51653f07fd7e3b0075c0bb02c8a769b146504badc9f1b46f6e5ef72.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod461235db_b561_4daa_8d30_84900c99c223.slice/cri-containerd-888421c467526e4b0ed8923c19298bd8641760cd43b88d93900495b7212687f5.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod85f50a6b_e708_4e52_aa90_1e14a1859345.slice/cri-containerd-a5b8cc51fbe419f42b8af8980283d4b818a0f65bf6d6f1561e90c432aa9a8b1f.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod85f50a6b_e708_4e52_aa90_1e14a1859345.slice/cri-containerd-063e0947dc1f8b7a1b2cffd6b9d85c1c4dcec0a3d3eb384579617cb1e38575d3.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40062d97_fa3a_4e2f_af9a_fdcc6905938c.slice/cri-containerd-0b1319e1d476e27592f612d5c3b45a2594e9b1140ded05b5d1c3e340dc7d5260.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40062d97_fa3a_4e2f_af9a_fdcc6905938c.slice/cri-containerd-f3a03f469c2af4959543fd52cc8b3e412f2606322d923a9bfc1d50871c8d4ce7.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9639965f_5732_4908_a5ef_63dc0ebfb8ca.slice/cri-containerd-e16fd4825843c058d9687d3a354995a1407a458ed8ec82f2c4bac92a9602c6b4.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9639965f_5732_4908_a5ef_63dc0ebfb8ca.slice/cri-containerd-f2b10210271c3ddbc62da8a709474c4d1d7b20656c02af85e89c12450b6c1c1f.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9639965f_5732_4908_a5ef_63dc0ebfb8ca.slice/cri-containerd-a60848858073506997d0b2254ed1f6c8458ef89bfac5bbbcd5c4939cab7febd0.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9639965f_5732_4908_a5ef_63dc0ebfb8ca.slice/cri-containerd-e9690d9bb27dd1f0a0a3d57f503b4453e6533d67717b71838798a46c79d2e8e6.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod87b8388f_fc9e_4bd0_9268_1f9c1c8fcc46.slice/cri-containerd-4855d833826fcd84b26deef4e91b79a8f2967f2ccb591cdc7fb936d87a8323f3.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod87b8388f_fc9e_4bd0_9268_1f9c1c8fcc46.slice/cri-containerd-69028280f6a58fb60a3e4013c5484279830432012098664ea70e5c9792c02e81.scope
    99       cgroup_device   multi                                          
