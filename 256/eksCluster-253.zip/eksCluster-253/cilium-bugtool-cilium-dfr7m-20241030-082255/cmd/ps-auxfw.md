USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         705  0.0  0.1 1616264 8848 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         671  0.0  0.0 1228744 3780 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         665  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         649  0.0  0.2 1240432 16568 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         712  0.0  0.0   6408  1648 ?        R    08:22   0:00  \_ ps auxfw
root         648  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         643  0.0  0.0 1229000 4744 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root           1  3.9  4.7 1606080 380504 ?      Ssl  08:03   0:45 cilium-agent --config-dir=/tmp/cilium/config-map
root         403  0.1  0.0 1229744 7960 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
