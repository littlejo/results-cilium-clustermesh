filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcadfe4e017f60 direct-action not_in_hw id 621 tag d4c9df6227cb64e0 jited 
