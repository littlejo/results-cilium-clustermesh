IP ADDRESS         LOCAL ENDPOINT INFO
10.253.0.247:0     id=3316  sec_id=8335639 flags=0x0000 ifindex=12  mac=8E:30:AA:AC:72:F5 nodemac=E6:FE:95:7E:8D:88   
10.253.0.108:0     (localhost)                                                                                        
10.253.0.121:0     id=2852  sec_id=8327731 flags=0x0000 ifindex=18  mac=46:2D:C8:C1:3A:4F nodemac=56:9C:B2:95:69:8D   
172.31.214.173:0   (localhost)                                                                                        
172.31.194.196:0   (localhost)                                                                                        
10.253.0.105:0     id=604   sec_id=4     flags=0x0000 ifindex=10  mac=A2:D2:6E:E4:7C:50 nodemac=02:51:AE:70:DB:81     
10.253.0.225:0     id=2954  sec_id=8335639 flags=0x0000 ifindex=14  mac=E6:DC:0A:84:87:2A nodemac=86:87:F2:40:DB:E8   
