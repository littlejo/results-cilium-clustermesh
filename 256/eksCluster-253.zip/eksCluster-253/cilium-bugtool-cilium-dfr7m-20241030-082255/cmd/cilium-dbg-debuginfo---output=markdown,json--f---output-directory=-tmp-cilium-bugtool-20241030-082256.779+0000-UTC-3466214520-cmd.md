markdown output at /tmp/cilium-bugtool-20241030-082256.779+0000-UTC-3466214520/cmd/cilium-debuginfo-20241030-082328.164+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082256.779+0000-UTC-3466214520/cmd/cilium-debuginfo-20241030-082328.164+0000-UTC.json
