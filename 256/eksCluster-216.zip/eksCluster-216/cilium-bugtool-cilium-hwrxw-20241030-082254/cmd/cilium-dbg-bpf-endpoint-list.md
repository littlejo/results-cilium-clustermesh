IP ADDRESS         LOCAL ENDPOINT INFO
10.216.0.107:0     id=472   sec_id=7136860 flags=0x0000 ifindex=12  mac=9E:AB:0E:D0:D6:73 nodemac=BE:57:57:26:1D:EB   
10.216.0.222:0     (localhost)                                                                                        
172.31.158.127:0   (localhost)                                                                                        
10.216.0.132:0     id=60    sec_id=7136860 flags=0x0000 ifindex=14  mac=42:1B:92:08:B1:64 nodemac=7E:FC:AB:AB:87:50   
10.216.0.142:0     id=4066  sec_id=4     flags=0x0000 ifindex=10  mac=DE:7B:2B:68:E1:88 nodemac=76:8F:1A:7B:CB:74     
172.31.142.17:0    (localhost)                                                                                        
10.216.0.99:0      id=2536  sec_id=7124775 flags=0x0000 ifindex=18  mac=46:2B:D3:9E:8F:86 nodemac=B2:8E:B2:BE:F3:6F   
