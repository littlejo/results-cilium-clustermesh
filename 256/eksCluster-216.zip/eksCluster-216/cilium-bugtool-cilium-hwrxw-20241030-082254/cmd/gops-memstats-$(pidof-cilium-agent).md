alloc: 207.21MB (217278800 bytes)
total-alloc: 2.37GB (2540775632 bytes)
sys: 352.84MB (369974644 bytes)
lookups: 0
mallocs: 65259481
frees: 63266259
heap-alloc: 207.21MB (217278800 bytes)
heap-sys: 274.98MB (288342016 bytes)
heap-idle: 41.25MB (43253760 bytes)
heap-in-use: 233.73MB (245088256 bytes)
heap-released: 12.50MB (13107200 bytes)
heap-objects: 1993222
stack-in-use: 64.97MB (68124672 bytes)
stack-sys: 64.97MB (68124672 bytes)
stack-mspan-inuse: 3.44MB (3606560 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1012.59KB (1036897 bytes)
gc-sys: 6.08MB (6377976 bytes)
next-gc: when heap-alloc >= 222.09MB (232873512 bytes)
last-gc: 2024-10-30 08:22:55.410074188 +0000 UTC
gc-pause-total: 24.608774ms
gc-pause: 763613
gc-pause-end: 1730276575410074188
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005417752497123081
enable-gc: true
debug-gc: false
