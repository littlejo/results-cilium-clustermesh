REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37687     2993485     677    bpf_overlay.c
Interface                 INGRESS     673001    136219973   1132   bpf_host.c
Success                   EGRESS      17623     1393872     1694   bpf_host.c
Success                   EGRESS      291149    35760636    1308   bpf_lxc.c
Success                   EGRESS      38760     3068736     53     encap.h
Success                   INGRESS     334383    38039117    86     l3.h
Success                   INGRESS     355097    39682706    235    trace.h
Unsupported L3 protocol   EGRESS      39        2902        1492   bpf_lxc.c
