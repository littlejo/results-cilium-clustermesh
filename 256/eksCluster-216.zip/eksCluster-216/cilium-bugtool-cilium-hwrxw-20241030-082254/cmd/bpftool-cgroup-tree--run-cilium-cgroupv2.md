CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08b46a35_4c6f_40c7_81bf_f471ea0c79ae.slice/cri-containerd-26e0d3f3b8b3cacfef5eb998ba03a8ad8846caa312d76c9249cf8e044742605f.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08b46a35_4c6f_40c7_81bf_f471ea0c79ae.slice/cri-containerd-a62e842901d6f2e2b1eaa30cfd7d7590648490d73ba964fbca64fa3b40a00c4f.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podedf7167e_ab23_4a11_b06c_a83a16cf7fcb.slice/cri-containerd-5358465d267348f5c6843ce67c735103c376f6ed381d34d30fb5aceb897015f6.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podedf7167e_ab23_4a11_b06c_a83a16cf7fcb.slice/cri-containerd-da22c2acd6be701720ec0e7ef69759d966f6d15219a1a81586a800bbb116038e.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5c412f31_e87a_49d9_b6a4_e4fb5902ebb4.slice/cri-containerd-590d1f1073a5d396c4d7ecd2884f67b88cba9a2473f7d5e775e4cd29197689bd.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5c412f31_e87a_49d9_b6a4_e4fb5902ebb4.slice/cri-containerd-11cbae8970b38755152ab1efcf8d528b2dc608955185be37f65e8a91742d484f.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod135a6f60_235b_487b_ab9c_63242e040f56.slice/cri-containerd-b99972b82235e3cde6ad174d97096ae71c36e8962cdb19e2e32dedf2eef7b5b9.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod135a6f60_235b_487b_ab9c_63242e040f56.slice/cri-containerd-2808b97ee7a0211b11812ce307e842839e320956e9dc338d0ccd30677e4dd363.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod70da36c6_d372_49f5_ae77_b6c03a3317e5.slice/cri-containerd-c5f7e9041f5a44be573b522b01f9dc8f3c03e53b12b31686b50d40a5c194bc78.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod70da36c6_d372_49f5_ae77_b6c03a3317e5.slice/cri-containerd-892950f387efbe5c04594490c2b6d812174985d08d587f4c2cd4e4efc0604d31.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71b1ba59_df9c_46d8_b9bb_7bd4a99213a5.slice/cri-containerd-7b67220d9334a2e84dbab8d8494c6a5ec7458ea7d6818bd0d4613413b5821720.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71b1ba59_df9c_46d8_b9bb_7bd4a99213a5.slice/cri-containerd-95b26e5e1eeb14d1f406c99bc0413f341bcd4b1e7acce21ccca6738b9d98a858.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71b1ba59_df9c_46d8_b9bb_7bd4a99213a5.slice/cri-containerd-3cad0110259038b0fa114f507f9626eb80c848d829f94ca70e906141e9f66ff9.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71b1ba59_df9c_46d8_b9bb_7bd4a99213a5.slice/cri-containerd-46d4d84661b293b6bb43c74965c32442f1e5584af83bd450d3932e6296d297f5.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf4207f51_8d56_479f_b5e2_f97940dcfe4d.slice/cri-containerd-d9453ad61a07109bdb5fae619cb55842ff7d66263f75a5f736ba2a9d467f0f68.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf4207f51_8d56_479f_b5e2_f97940dcfe4d.slice/cri-containerd-d4c17b4c268f09a8d30ff7ea6ba3f1e282030177d40445cec18bcc0d3520bf64.scope
    91       cgroup_device   multi                                          
