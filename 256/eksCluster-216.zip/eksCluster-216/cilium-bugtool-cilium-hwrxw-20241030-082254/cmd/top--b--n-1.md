top - 08:22:56 up 30 min,  0 users,  load average: 0.03, 0.14, 0.18
Tasks:   9 total,   3 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 40.6 us, 50.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  9.4 si,  0.0 st
MiB Mem :   7814.2 total,   4463.5 free,   1203.8 used,   2146.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6425.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    698 root      20   0 1244340  23784  14400 R  50.0   0.3   0:00.18 hubble
      1 root      20   0 1671684 394848  78276 S  12.5   4.9   0:49.35 cilium-+
    682 root      20   0 1240432  16256  11292 S   6.2   0.2   0:00.02 cilium-+
    394 root      20   0 1229744   6988   2864 S   0.0   0.1   0:01.11 cilium-+
    663 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    688 root      20   0    2208    788    708 S   0.0   0.0   0:00.00 timeout
    734 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    752 root      20   0 1539912   8368   6296 S   0.0   0.1   0:00.00 runc:[2+
    759 root      20   0    3852   1272   1116 R   0.0   0.0   0:00.00 bash
