{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:50.667Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.142.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:50.667Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.158.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:50.667Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:55.133Z",
  "value": "id=4066  sec_id=4     flags=0x0000 ifindex=10  mac=DE:7B:2B:68:E1:88 nodemac=76:8F:1A:7B:CB:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:55.135Z",
  "value": "id=472   sec_id=7136860 flags=0x0000 ifindex=12  mac=9E:AB:0E:D0:D6:73 nodemac=BE:57:57:26:1D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:55.168Z",
  "value": "id=4066  sec_id=4     flags=0x0000 ifindex=10  mac=DE:7B:2B:68:E1:88 nodemac=76:8F:1A:7B:CB:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:55.169Z",
  "value": "id=472   sec_id=7136860 flags=0x0000 ifindex=12  mac=9E:AB:0E:D0:D6:73 nodemac=BE:57:57:26:1D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:55.196Z",
  "value": "id=60    sec_id=7136860 flags=0x0000 ifindex=14  mac=42:1B:92:08:B1:64 nodemac=7E:FC:AB:AB:87:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:26.878Z",
  "value": "id=4066  sec_id=4     flags=0x0000 ifindex=10  mac=DE:7B:2B:68:E1:88 nodemac=76:8F:1A:7B:CB:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:26.878Z",
  "value": "id=472   sec_id=7136860 flags=0x0000 ifindex=12  mac=9E:AB:0E:D0:D6:73 nodemac=BE:57:57:26:1D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:26.879Z",
  "value": "id=60    sec_id=7136860 flags=0x0000 ifindex=14  mac=42:1B:92:08:B1:64 nodemac=7E:FC:AB:AB:87:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:26.908Z",
  "value": "id=941   sec_id=7124775 flags=0x0000 ifindex=16  mac=9A:64:3A:31:24:D6 nodemac=56:30:94:29:0E:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:26.909Z",
  "value": "id=941   sec_id=7124775 flags=0x0000 ifindex=16  mac=9A:64:3A:31:24:D6 nodemac=56:30:94:29:0E:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:27.877Z",
  "value": "id=4066  sec_id=4     flags=0x0000 ifindex=10  mac=DE:7B:2B:68:E1:88 nodemac=76:8F:1A:7B:CB:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:27.877Z",
  "value": "id=941   sec_id=7124775 flags=0x0000 ifindex=16  mac=9A:64:3A:31:24:D6 nodemac=56:30:94:29:0E:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:27.878Z",
  "value": "id=472   sec_id=7136860 flags=0x0000 ifindex=12  mac=9E:AB:0E:D0:D6:73 nodemac=BE:57:57:26:1D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:27.878Z",
  "value": "id=60    sec_id=7136860 flags=0x0000 ifindex=14  mac=42:1B:92:08:B1:64 nodemac=7E:FC:AB:AB:87:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:29.592Z",
  "value": "id=2536  sec_id=7124775 flags=0x0000 ifindex=18  mac=46:2B:D3:9E:8F:86 nodemac=B2:8E:B2:BE:F3:6F"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.216.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:39.885Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:06.365Z",
  "value": "id=2536  sec_id=7124775 flags=0x0000 ifindex=18  mac=46:2B:D3:9E:8F:86 nodemac=B2:8E:B2:BE:F3:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:06.366Z",
  "value": "id=4066  sec_id=4     flags=0x0000 ifindex=10  mac=DE:7B:2B:68:E1:88 nodemac=76:8F:1A:7B:CB:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:06.366Z",
  "value": "id=472   sec_id=7136860 flags=0x0000 ifindex=12  mac=9E:AB:0E:D0:D6:73 nodemac=BE:57:57:26:1D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:06.367Z",
  "value": "id=60    sec_id=7136860 flags=0x0000 ifindex=14  mac=42:1B:92:08:B1:64 nodemac=7E:FC:AB:AB:87:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.366Z",
  "value": "id=2536  sec_id=7124775 flags=0x0000 ifindex=18  mac=46:2B:D3:9E:8F:86 nodemac=B2:8E:B2:BE:F3:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.366Z",
  "value": "id=4066  sec_id=4     flags=0x0000 ifindex=10  mac=DE:7B:2B:68:E1:88 nodemac=76:8F:1A:7B:CB:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.366Z",
  "value": "id=472   sec_id=7136860 flags=0x0000 ifindex=12  mac=9E:AB:0E:D0:D6:73 nodemac=BE:57:57:26:1D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.367Z",
  "value": "id=60    sec_id=7136860 flags=0x0000 ifindex=14  mac=42:1B:92:08:B1:64 nodemac=7E:FC:AB:AB:87:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.367Z",
  "value": "id=472   sec_id=7136860 flags=0x0000 ifindex=12  mac=9E:AB:0E:D0:D6:73 nodemac=BE:57:57:26:1D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.367Z",
  "value": "id=4066  sec_id=4     flags=0x0000 ifindex=10  mac=DE:7B:2B:68:E1:88 nodemac=76:8F:1A:7B:CB:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.367Z",
  "value": "id=60    sec_id=7136860 flags=0x0000 ifindex=14  mac=42:1B:92:08:B1:64 nodemac=7E:FC:AB:AB:87:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.216.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.367Z",
  "value": "id=2536  sec_id=7124775 flags=0x0000 ifindex=18  mac=46:2B:D3:9E:8F:86 nodemac=B2:8E:B2:BE:F3:6F"
}

