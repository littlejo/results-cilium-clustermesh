1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:e1:00:5e:4d:e5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.142.17/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3586sec preferred_lft 3586sec
    inet6 fe80::4e1:ff:fe5e:4de5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:e4:94:a2:65:41 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.158.127/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4e4:94ff:fea2:6541/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:2f:6d:91:2f:5e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a82f:6dff:fe91:2f5e/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:95:b4:b5:f3:3c brd ff:ff:ff:ff:ff:ff
    inet 10.216.0.222/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::8895:b4ff:feb5:f33c/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 26:69:ce:30:92:90 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2469:ceff:fe30:9290/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:8f:1a:7b:cb:74 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::748f:1aff:fe7b:cb74/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcda5c0eb590f0@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:57:57:26:1d:eb brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::bc57:57ff:fe26:1deb/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc0d79df856e21@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:fc:ab:ab:87:50 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::7cfc:abff:feab:8750/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcea409bec0c0b@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:8e:b2:be:f3:6f brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::b08e:b2ff:febe:f36f/64 scope link 
       valid_lft forever preferred_lft forever
