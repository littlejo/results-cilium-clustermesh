markdown output at /tmp/cilium-bugtool-20241030-082255.657+0000-UTC-462324828/cmd/cilium-debuginfo-20241030-082326.328+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082255.657+0000-UTC-462324828/cmd/cilium-debuginfo-20241030-082326.328+0000-UTC.json
