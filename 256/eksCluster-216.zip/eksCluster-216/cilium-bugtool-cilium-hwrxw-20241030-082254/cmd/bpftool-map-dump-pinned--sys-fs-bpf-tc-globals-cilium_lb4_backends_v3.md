key: 02 00 00 00  value: ac 1f fa e3 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a d8 00 6b 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a d8 00 63 09 4b 00 00  00 00 00 00
key: 07 00 00 00  value: 0a d8 00 6b 23 c1 00 00  00 00 00 00
key: 04 00 00 00  value: 0a d8 00 84 00 35 00 00  00 00 00 00
key: 03 00 00 00  value: ac 1f 8e 11 10 94 00 00  00 00 00 00
key: 05 00 00 00  value: 0a d8 00 84 23 c1 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 90 41 01 bb 00 00  00 00 00 00
Found 8 elements
