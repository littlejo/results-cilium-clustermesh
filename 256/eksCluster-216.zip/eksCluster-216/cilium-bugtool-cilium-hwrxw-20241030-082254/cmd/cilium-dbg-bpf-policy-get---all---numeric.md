Endpoint ID: 60
Path: /sys/fs/bpf/tc/globals/cilium_policy_00060

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    116995   1340      0        
Allow    Egress      0          ANY          NONE         disabled    16901    183       0        


Endpoint ID: 472
Path: /sys/fs/bpf/tc/globals/cilium_policy_00472

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    116665   1335      0        
Allow    Egress      0          ANY          NONE         disabled    17538    190       0        


Endpoint ID: 1287
Path: /sys/fs/bpf/tc/globals/cilium_policy_01287

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2536
Path: /sys/fs/bpf/tc/globals/cilium_policy_02536

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11502342   116191    0        
Allow    Ingress     1          ANY          NONE         disabled    11271969   119161    0        
Allow    Egress      0          ANY          NONE         disabled    15246748   148648    0        


Endpoint ID: 4066
Path: /sys/fs/bpf/tc/globals/cilium_policy_04066

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1647800   20767     0        
Allow    Ingress     1          ANY          NONE         disabled    18690     221       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


