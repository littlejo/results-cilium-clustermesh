[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71b1ba59_df9c_46d8_b9bb_7bd4a99213a5.slice/cri-containerd-7b67220d9334a2e84dbab8d8494c6a5ec7458ea7d6818bd0d4613413b5821720.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71b1ba59_df9c_46d8_b9bb_7bd4a99213a5.slice/cri-containerd-46d4d84661b293b6bb43c74965c32442f1e5584af83bd450d3932e6296d297f5.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71b1ba59_df9c_46d8_b9bb_7bd4a99213a5.slice/cri-containerd-3cad0110259038b0fa114f507f9626eb80c848d829f94ca70e906141e9f66ff9.scope"
      }
    ],
    "ips": [
      "10.216.0.99"
    ],
    "name": "clustermesh-apiserver-8576475997-p7wpj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod135a6f60_235b_487b_ab9c_63242e040f56.slice/cri-containerd-2808b97ee7a0211b11812ce307e842839e320956e9dc338d0ccd30677e4dd363.scope"
      }
    ],
    "ips": [
      "10.216.0.132"
    ],
    "name": "coredns-cc6ccd49c-msspm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08b46a35_4c6f_40c7_81bf_f471ea0c79ae.slice/cri-containerd-a62e842901d6f2e2b1eaa30cfd7d7590648490d73ba964fbca64fa3b40a00c4f.scope"
      }
    ],
    "ips": [
      "10.216.0.107"
    ],
    "name": "coredns-cc6ccd49c-bd64w",
    "namespace": "kube-system"
  }
]

