key: 3c 00 00 00  value: 27 02 00 00
key: d8 01 00 00  value: 10 02 00 00
key: e8 09 00 00  value: 63 02 00 00
key: e2 0f 00 00  value: 1e 02 00 00
Found 4 elements
