ip-172-31-142-17.eu-west-3.compute.internal
