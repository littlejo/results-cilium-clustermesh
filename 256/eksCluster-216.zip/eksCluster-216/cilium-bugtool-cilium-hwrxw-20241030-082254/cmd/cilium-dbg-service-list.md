ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.144.65:443 (active)    
                                         2 => 172.31.250.227:443 (active)   
2    10.100.54.65:443     ClusterIP      1 => 172.31.142.17:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.216.0.132:53 (active)      
                                         2 => 10.216.0.107:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.216.0.132:9153 (active)    
                                         2 => 10.216.0.107:9153 (active)    
5    10.100.176.15:2379   ClusterIP      1 => 10.216.0.99:2379 (active)     
