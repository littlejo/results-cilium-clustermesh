xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 499
ens6(5) clsact/ingress cil_from_netdev-ens6 id 504
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 490
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 482
cilium_host(7) clsact/egress cil_from_host-cilium_host id 488
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 546
lxcda5c0eb590f0(12) clsact/ingress cil_from_container-lxcda5c0eb590f0 id 518
lxc0d79df856e21(14) clsact/ingress cil_from_container-lxc0d79df856e21 id 553
lxcea409bec0c0b(18) clsact/ingress cil_from_container-lxcea409bec0c0b id 617

flow_dissector:

netfilter:

