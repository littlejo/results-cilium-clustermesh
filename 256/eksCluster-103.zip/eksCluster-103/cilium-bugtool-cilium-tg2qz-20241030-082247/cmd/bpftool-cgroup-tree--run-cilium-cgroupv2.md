CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb8a882af_e43a_4402_8821_85ace7d46114.slice/cri-containerd-eaecd2ec39729aa747cada3c29286beb3cb5df965533b40cea0937abbbda05b2.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb8a882af_e43a_4402_8821_85ace7d46114.slice/cri-containerd-2c35237355c9d438d12add66b59e6bb1f436b207cb3c4e80864db11938f31ba1.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d339024_407c_4c76_b78b_eeb4bc186c2b.slice/cri-containerd-6b3c916ed5428de1a1c357c9e91c4b2e4d832a5fe2a256339d2c8d5a0bfd874e.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d339024_407c_4c76_b78b_eeb4bc186c2b.slice/cri-containerd-03f1194a688a7a8d9996e0ec6a53caba714964226097a2d88db84b8f1a596e15.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podea56083d_b51a_45eb_b3e7_9526f6e6f295.slice/cri-containerd-26874099f993288d5f9c1f4916b02d2deca46a546a1f0d05e7d213107589f5c0.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podea56083d_b51a_45eb_b3e7_9526f6e6f295.slice/cri-containerd-4f27f05fccdf358ea94985701d4703c90619bc584db02c6a09b87a067d3ae19d.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod696aeaee_2b09_40b8_ba2d_27f3d7f7764c.slice/cri-containerd-f776553552c295e932ba78a40a58d70d924d1939caa2f23e84f9e7198a977b45.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod696aeaee_2b09_40b8_ba2d_27f3d7f7764c.slice/cri-containerd-25ecb78bd92a4bd5beb486a6da505776868ed417917c673060afbdf03c866347.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5307468f_d9bc_4783_98f5_1870a09d8d88.slice/cri-containerd-83c0162d051744fd7244d9381cb6f276d6e2e90d3cf9d027f829ec5709c7b5eb.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5307468f_d9bc_4783_98f5_1870a09d8d88.slice/cri-containerd-78f82c49f6b0473c0fbe6d68b36a9ba0ec3a3cc0e9fabccca413fd3cc670251a.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddc2bab22_b55b_42a8_8cf1_207c80e5dc91.slice/cri-containerd-20bf0c9b90b3a90338b5e62d19aef8a64a5d4ec33651ba5a61f968db24d0af17.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddc2bab22_b55b_42a8_8cf1_207c80e5dc91.slice/cri-containerd-bc8cef7643f67eeb18247f6df6bc3c1eab22796d29b0339a124db8fa8d545088.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7fb33f67_21a3_4e34_ab7e_6230c773e924.slice/cri-containerd-eca2f9639978a08e285699079096f1492203cc05f7e7c6468d5cade8b3f6d042.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7fb33f67_21a3_4e34_ab7e_6230c773e924.slice/cri-containerd-8328f62f0bf7e5cd462e383c9d24eecc80d9cb7add70b6ca53ac37d39f62edb1.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7fb33f67_21a3_4e34_ab7e_6230c773e924.slice/cri-containerd-a2a255b17cab7f60c6bedc76ee8b20856509710e33de7f2d48d17afcaea29d22.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7fb33f67_21a3_4e34_ab7e_6230c773e924.slice/cri-containerd-4f6dc6408b91c1c3bc070049d0794b282e24bb6882d9c4ac26db7b25d6a9ce21.scope
    653      cgroup_device   multi                                          
