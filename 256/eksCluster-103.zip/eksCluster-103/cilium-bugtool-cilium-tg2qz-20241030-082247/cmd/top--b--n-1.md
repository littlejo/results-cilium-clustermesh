top - 08:22:48 up 34 min,  0 users,  load average: 0.64, 0.30, 0.21
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s):  6.9 us, 24.1 sy,  0.0 ni, 69.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4503.0 free,   1165.6 used,   2145.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6463.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 380112  77564 S   6.7   4.8   0:47.84 cilium-+
    583 root      20   0 1229744   7904   3904 S   0.0   0.1   0:01.15 cilium-+
    801 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    820 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    836 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    842 root      20   0 1228744   3656   2976 S   0.0   0.0   0:00.00 gops
    843 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    872 root      20   0 1240432  16596  11420 S   0.0   0.2   0:00.02 cilium-+
    898 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    916 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
