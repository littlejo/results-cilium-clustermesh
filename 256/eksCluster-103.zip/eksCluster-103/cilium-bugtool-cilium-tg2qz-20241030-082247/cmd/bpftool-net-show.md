xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 505
ens6(5) clsact/ingress cil_from_netdev-ens6 id 510
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 501
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 489
cilium_host(7) clsact/egress cil_from_host-cilium_host id 493
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 555
lxc065154204eed(12) clsact/ingress cil_from_container-lxc065154204eed id 535
lxc9db56aa8acdb(14) clsact/ingress cil_from_container-lxc9db56aa8acdb id 539
lxc9c7631487cf0(18) clsact/ingress cil_from_container-lxc9c7631487cf0 id 621

flow_dissector:

netfilter:

