KEY             VALUE
AgentLiveness   2085798644043
UTimeOffset     3379442410156250
