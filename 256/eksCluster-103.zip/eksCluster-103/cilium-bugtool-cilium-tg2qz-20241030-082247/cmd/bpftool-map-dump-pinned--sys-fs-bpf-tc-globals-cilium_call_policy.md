key: 02 00 00 00  value: 27 02 00 00
key: 2c 01 00 00  value: 09 02 00 00
key: 07 02 00 00  value: 68 02 00 00
key: 7c 04 00 00  value: 28 02 00 00
Found 4 elements
