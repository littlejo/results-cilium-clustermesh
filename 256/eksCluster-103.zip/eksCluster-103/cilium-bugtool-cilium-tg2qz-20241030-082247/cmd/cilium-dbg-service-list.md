ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.210.132:443 (active)   
                                          2 => 172.31.168.215:443 (active)   
2    10.100.185.149:443    ClusterIP      1 => 172.31.251.68:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.103.0.85:9153 (active)     
                                          2 => 10.103.0.92:9153 (active)     
4    10.100.0.10:53        ClusterIP      1 => 10.103.0.85:53 (active)       
                                          2 => 10.103.0.92:53 (active)       
5    10.100.212.228:2379   ClusterIP      1 => 10.103.0.27:2379 (active)     
