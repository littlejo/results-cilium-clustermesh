IP ADDRESS        LOCAL ENDPOINT INFO
10.103.0.92:0     id=2     sec_id=3419563 flags=0x0000 ifindex=14  mac=E2:DB:CD:4E:CC:0F nodemac=16:FF:5E:64:16:E4   
172.31.201.79:0   (localhost)                                                                                        
10.103.0.97:0     id=1148  sec_id=4     flags=0x0000 ifindex=10  mac=4E:18:36:B5:3C:94 nodemac=C2:2B:92:84:4A:DC     
10.103.0.27:0     id=519   sec_id=3421200 flags=0x0000 ifindex=18  mac=2E:13:36:DF:F3:BB nodemac=3E:F9:FB:E7:90:2E   
10.103.0.85:0     id=300   sec_id=3419563 flags=0x0000 ifindex=12  mac=DA:6B:B7:50:C9:F3 nodemac=A6:19:6A:0D:A4:07   
10.103.0.82:0     (localhost)                                                                                        
172.31.251.68:0   (localhost)                                                                                        
