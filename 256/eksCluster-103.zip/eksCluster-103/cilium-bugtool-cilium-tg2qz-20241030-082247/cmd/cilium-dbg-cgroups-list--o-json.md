[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d339024_407c_4c76_b78b_eeb4bc186c2b.slice/cri-containerd-6b3c916ed5428de1a1c357c9e91c4b2e4d832a5fe2a256339d2c8d5a0bfd874e.scope"
      }
    ],
    "ips": [
      "10.103.0.92"
    ],
    "name": "coredns-cc6ccd49c-mn4bg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7fb33f67_21a3_4e34_ab7e_6230c773e924.slice/cri-containerd-8328f62f0bf7e5cd462e383c9d24eecc80d9cb7add70b6ca53ac37d39f62edb1.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7fb33f67_21a3_4e34_ab7e_6230c773e924.slice/cri-containerd-eca2f9639978a08e285699079096f1492203cc05f7e7c6468d5cade8b3f6d042.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7fb33f67_21a3_4e34_ab7e_6230c773e924.slice/cri-containerd-4f6dc6408b91c1c3bc070049d0794b282e24bb6882d9c4ac26db7b25d6a9ce21.scope"
      }
    ],
    "ips": [
      "10.103.0.27"
    ],
    "name": "clustermesh-apiserver-684594c6c7-zxfml",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod696aeaee_2b09_40b8_ba2d_27f3d7f7764c.slice/cri-containerd-f776553552c295e932ba78a40a58d70d924d1939caa2f23e84f9e7198a977b45.scope"
      }
    ],
    "ips": [
      "10.103.0.85"
    ],
    "name": "coredns-cc6ccd49c-fr9kf",
    "namespace": "kube-system"
  }
]

