Endpoint ID: 2
Path: /sys/fs/bpf/tc/globals/cilium_policy_00002

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    151709   1745      0        
Allow    Egress      0          ANY          NONE         disabled    20293    224       0        


Endpoint ID: 15
Path: /sys/fs/bpf/tc/globals/cilium_policy_00015

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 300
Path: /sys/fs/bpf/tc/globals/cilium_policy_00300

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    151445   1741      0        
Allow    Egress      0          ANY          NONE         disabled    20160    223       0        


Endpoint ID: 519
Path: /sys/fs/bpf/tc/globals/cilium_policy_00519

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11055222   107584    0        
Allow    Ingress     1          ANY          NONE         disabled    9031942    94364     0        
Allow    Egress      0          ANY          NONE         disabled    10445516   103987    0        


Endpoint ID: 1148
Path: /sys/fs/bpf/tc/globals/cilium_policy_01148

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1633432   20640     0        
Allow    Ingress     1          ANY          NONE         disabled    21964     254       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


