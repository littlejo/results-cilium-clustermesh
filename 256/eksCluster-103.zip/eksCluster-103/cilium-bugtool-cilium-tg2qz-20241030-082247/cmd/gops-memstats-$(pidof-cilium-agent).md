alloc: 120.87MB (126743032 bytes)
total-alloc: 2.17GB (2332587112 bytes)
sys: 321.02MB (336613732 bytes)
lookups: 0
mallocs: 61979631
frees: 61223406
heap-alloc: 120.87MB (126743032 bytes)
heap-sys: 247.64MB (259670016 bytes)
heap-idle: 65.03MB (68190208 bytes)
heap-in-use: 182.61MB (191479808 bytes)
heap-released: 2.16MB (2260992 bytes)
heap-objects: 756225
stack-in-use: 60.31MB (63242240 bytes)
stack-sys: 60.31MB (63242240 bytes)
stack-mspan-inuse: 2.83MB (2969120 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.25MB (1314225 bytes)
gc-sys: 6.01MB (6305184 bytes)
next-gc: when heap-alloc >= 214.85MB (225290456 bytes)
last-gc: 2024-10-30 08:23:17.525646544 +0000 UTC
gc-pause-total: 7.583658ms
gc-pause: 152167
gc-pause-end: 1730276597525646544
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.0003577180688030703
enable-gc: true
debug-gc: false
