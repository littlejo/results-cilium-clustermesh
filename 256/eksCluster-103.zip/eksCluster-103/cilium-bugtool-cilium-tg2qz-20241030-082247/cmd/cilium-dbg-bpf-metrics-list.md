REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     33749     2667643     677    bpf_overlay.c
Interface                 INGRESS     608080    127919735   1132   bpf_host.c
Success                   EGRESS      13803     1081699     1694   bpf_host.c
Success                   EGRESS      253748    32531430    1308   bpf_lxc.c
Success                   EGRESS      32546     2580988     53     encap.h
Success                   INGRESS     295906    33132384    86     l3.h
Success                   INGRESS     316503    34762374    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
