markdown output at /tmp/cilium-bugtool-20241030-082248.662+0000-UTC-1822429021/cmd/cilium-debuginfo-20241030-082319.719+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082248.662+0000-UTC-1822429021/cmd/cilium-debuginfo-20241030-082319.719+0000-UTC.json
