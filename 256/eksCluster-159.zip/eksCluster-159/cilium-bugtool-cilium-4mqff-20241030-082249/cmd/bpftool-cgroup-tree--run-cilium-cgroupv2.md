CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c259581_01a9_4f5f_a903_69ad3e3e9e12.slice/cri-containerd-7d9f592c9bf0b8c36868c55ea621fedc57a78db910f37d6a67069550fb763c82.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c259581_01a9_4f5f_a903_69ad3e3e9e12.slice/cri-containerd-a1f32429927a11826cbcacd222589c9113e0f9dc1bf2f1ba7066753b22c5d5da.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9439aeb6_ba5b_4ca1_aa47_142a0ca2d3b4.slice/cri-containerd-00241145e633fd0367a9f6deed538ee3e39631a37ed50c7abedbb12c920a3ef6.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9439aeb6_ba5b_4ca1_aa47_142a0ca2d3b4.slice/cri-containerd-0c8eb9a0d6cf1a9e48de6f39e06baeadb18476357bee70a05fb99c013d90500d.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46c5f1a8_f913_4926_97c7_cddebd991a8a.slice/cri-containerd-8d51b0e4b54fcbd3ce3160de3071f1037f3d6d6b7a0b27a5946723a260e3e262.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46c5f1a8_f913_4926_97c7_cddebd991a8a.slice/cri-containerd-2cba7f872d9a01b434bae3301778a37841206f48031e33414ecfee3fb986cca7.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcfb618ec_2c2b_4875_855b_3bd93c140b39.slice/cri-containerd-b58ddae2fd7556493e71f352903d5b95e1a98720f3dc1e8aeec85dc4367b7c09.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcfb618ec_2c2b_4875_855b_3bd93c140b39.slice/cri-containerd-97b791a61f71936fa74ee674f96987f3005349f753521815e3ff91d22e47ebcf.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode025bef3_ae19_44a5_bd88_dffa1437474b.slice/cri-containerd-a56783fee7bbacb34429d8ce973db2051a005599fcf301a8d46d72718952c7d1.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode025bef3_ae19_44a5_bd88_dffa1437474b.slice/cri-containerd-8727f6e99c2fd04d0cbb20f91aec71fa24e792d3a1fa4057dc724fd031ea68b9.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode025bef3_ae19_44a5_bd88_dffa1437474b.slice/cri-containerd-9ef55cdc4511cc7dac82af0be04eb068f861a315042485df71576673a169cf07.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode025bef3_ae19_44a5_bd88_dffa1437474b.slice/cri-containerd-3db669c376e75a6f573bc615cb8ce082f0f48e6f710bc4baae4001428918b425.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9253c164_bfc0_49ec_a7c8_e3dcfeb406ad.slice/cri-containerd-634366d0219f4ee97347fd14b7d5fd62645062f30410fe1e065d827a1fb7fb3b.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9253c164_bfc0_49ec_a7c8_e3dcfeb406ad.slice/cri-containerd-7b564bd4e89397d3f2feb624c623e569d05f600d2a1be8f7813e901ba6c54685.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0687ad8_7484_46fa_a0d7_6b4c490cf1fd.slice/cri-containerd-72916499aed582ca7b2654fe3023898ff6cafd83eb53c3e1c088b12f024fd2d9.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0687ad8_7484_46fa_a0d7_6b4c490cf1fd.slice/cri-containerd-1f0571bb76074c3026799491fd3ebcce5f13cf200190fb91b871c4cc21ec0555.scope
    110      cgroup_device   multi                                          
