xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 501
ens6(5) clsact/ingress cil_from_netdev-ens6 id 511
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 497
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 486
cilium_host(7) clsact/egress cil_from_host-cilium_host id 491
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 482
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 554
lxce1020f678756(12) clsact/ingress cil_from_container-lxce1020f678756 id 529
lxc497ebc93a7c0(14) clsact/ingress cil_from_container-lxc497ebc93a7c0 id 536
lxcb7474ef23c9d(18) clsact/ingress cil_from_container-lxcb7474ef23c9d id 619

flow_dissector:

netfilter:

