alloc: 170.73MB (179028616 bytes)
total-alloc: 2.42GB (2595708456 bytes)
sys: 337.09MB (353459572 bytes)
lookups: 0
mallocs: 65728062
frees: 64112080
heap-alloc: 170.73MB (179028616 bytes)
heap-sys: 255.73MB (268156928 bytes)
heap-idle: 47.12MB (49414144 bytes)
heap-in-use: 208.61MB (218742784 bytes)
heap-released: 3.28MB (3440640 bytes)
heap-objects: 1615982
stack-in-use: 68.22MB (71532544 bytes)
stack-sys: 68.22MB (71532544 bytes)
stack-mspan-inuse: 3.27MB (3432800 bytes)
stack-mspan-sys: 3.97MB (4161600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.08MB (1135953 bytes)
gc-sys: 6.07MB (6361472 bytes)
next-gc: when heap-alloc >= 217.98MB (228564312 bytes)
last-gc: 2024-10-30 08:22:58.618224675 +0000 UTC
gc-pause-total: 12.691752ms
gc-pause: 168800
gc-pause-end: 1730276578618224675
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.000655682413682005
enable-gc: true
debug-gc: false
