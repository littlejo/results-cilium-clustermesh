KEY             VALUE
AgentLiveness   1916257148097
UTimeOffset     3379442746093750
