{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:48.692Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.231.255:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:48.692Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.243.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:48.692Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:53.414Z",
  "value": "id=11    sec_id=4     flags=0x0000 ifindex=10  mac=DE:2B:0E:7C:03:38 nodemac=46:67:25:B8:95:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:53.415Z",
  "value": "id=3183  sec_id=5248845 flags=0x0000 ifindex=12  mac=0A:AD:B3:3A:05:FF nodemac=A6:9A:D0:0A:72:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:53.477Z",
  "value": "id=11    sec_id=4     flags=0x0000 ifindex=10  mac=DE:2B:0E:7C:03:38 nodemac=46:67:25:B8:95:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:53.477Z",
  "value": "id=1486  sec_id=5248845 flags=0x0000 ifindex=14  mac=22:FA:64:6F:E1:6D nodemac=F6:F4:61:B2:06:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:53.478Z",
  "value": "id=3183  sec_id=5248845 flags=0x0000 ifindex=12  mac=0A:AD:B3:3A:05:FF nodemac=A6:9A:D0:0A:72:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:57.842Z",
  "value": "id=3183  sec_id=5248845 flags=0x0000 ifindex=12  mac=0A:AD:B3:3A:05:FF nodemac=A6:9A:D0:0A:72:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:57.842Z",
  "value": "id=1486  sec_id=5248845 flags=0x0000 ifindex=14  mac=22:FA:64:6F:E1:6D nodemac=F6:F4:61:B2:06:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:57.843Z",
  "value": "id=11    sec_id=4     flags=0x0000 ifindex=10  mac=DE:2B:0E:7C:03:38 nodemac=46:67:25:B8:95:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:57.872Z",
  "value": "id=618   sec_id=5255589 flags=0x0000 ifindex=16  mac=FE:30:86:66:61:24 nodemac=86:1C:F9:0F:6E:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:57.873Z",
  "value": "id=618   sec_id=5255589 flags=0x0000 ifindex=16  mac=FE:30:86:66:61:24 nodemac=86:1C:F9:0F:6E:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:48.764Z",
  "value": "id=3225  sec_id=5255589 flags=0x0000 ifindex=18  mac=D6:53:68:F7:6F:95 nodemac=4A:E0:5E:D0:ED:27"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.159.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.596Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.451Z",
  "value": "id=11    sec_id=4     flags=0x0000 ifindex=10  mac=DE:2B:0E:7C:03:38 nodemac=46:67:25:B8:95:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.452Z",
  "value": "id=3183  sec_id=5248845 flags=0x0000 ifindex=12  mac=0A:AD:B3:3A:05:FF nodemac=A6:9A:D0:0A:72:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.452Z",
  "value": "id=3225  sec_id=5255589 flags=0x0000 ifindex=18  mac=D6:53:68:F7:6F:95 nodemac=4A:E0:5E:D0:ED:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.452Z",
  "value": "id=1486  sec_id=5248845 flags=0x0000 ifindex=14  mac=22:FA:64:6F:E1:6D nodemac=F6:F4:61:B2:06:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.454Z",
  "value": "id=3183  sec_id=5248845 flags=0x0000 ifindex=12  mac=0A:AD:B3:3A:05:FF nodemac=A6:9A:D0:0A:72:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.454Z",
  "value": "id=3225  sec_id=5255589 flags=0x0000 ifindex=18  mac=D6:53:68:F7:6F:95 nodemac=4A:E0:5E:D0:ED:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.455Z",
  "value": "id=11    sec_id=4     flags=0x0000 ifindex=10  mac=DE:2B:0E:7C:03:38 nodemac=46:67:25:B8:95:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.455Z",
  "value": "id=1486  sec_id=5248845 flags=0x0000 ifindex=14  mac=22:FA:64:6F:E1:6D nodemac=F6:F4:61:B2:06:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.454Z",
  "value": "id=1486  sec_id=5248845 flags=0x0000 ifindex=14  mac=22:FA:64:6F:E1:6D nodemac=F6:F4:61:B2:06:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.454Z",
  "value": "id=11    sec_id=4     flags=0x0000 ifindex=10  mac=DE:2B:0E:7C:03:38 nodemac=46:67:25:B8:95:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.455Z",
  "value": "id=3183  sec_id=5248845 flags=0x0000 ifindex=12  mac=0A:AD:B3:3A:05:FF nodemac=A6:9A:D0:0A:72:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.455Z",
  "value": "id=3225  sec_id=5255589 flags=0x0000 ifindex=18  mac=D6:53:68:F7:6F:95 nodemac=4A:E0:5E:D0:ED:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.454Z",
  "value": "id=11    sec_id=4     flags=0x0000 ifindex=10  mac=DE:2B:0E:7C:03:38 nodemac=46:67:25:B8:95:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.454Z",
  "value": "id=3225  sec_id=5255589 flags=0x0000 ifindex=18  mac=D6:53:68:F7:6F:95 nodemac=4A:E0:5E:D0:ED:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.455Z",
  "value": "id=1486  sec_id=5248845 flags=0x0000 ifindex=14  mac=22:FA:64:6F:E1:6D nodemac=F6:F4:61:B2:06:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.159.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.455Z",
  "value": "id=3183  sec_id=5248845 flags=0x0000 ifindex=12  mac=0A:AD:B3:3A:05:FF nodemac=A6:9A:D0:0A:72:73"
}

