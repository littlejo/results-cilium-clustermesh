ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.146.115:443 (active)   
                                         2 => 172.31.215.55:443 (active)    
2    10.100.64.240:443    ClusterIP      1 => 172.31.243.44:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.159.0.182:53 (active)      
                                         2 => 10.159.0.5:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.159.0.182:9153 (active)    
                                         2 => 10.159.0.5:9153 (active)      
5    10.100.191.44:2379   ClusterIP      1 => 10.159.0.137:2379 (active)    
