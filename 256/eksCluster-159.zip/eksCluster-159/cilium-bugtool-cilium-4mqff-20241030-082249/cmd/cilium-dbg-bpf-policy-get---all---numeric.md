Endpoint ID: 11
Path: /sys/fs/bpf/tc/globals/cilium_policy_00011

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1662791   21024     0        
Allow    Ingress     1          ANY          NONE         disabled    19498     230       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1486
Path: /sys/fs/bpf/tc/globals/cilium_policy_01486

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    122531   1410      0        
Allow    Egress      0          ANY          NONE         disabled    17363    189       0        


Endpoint ID: 2418
Path: /sys/fs/bpf/tc/globals/cilium_policy_02418

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3183
Path: /sys/fs/bpf/tc/globals/cilium_policy_03183

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    123103   1411      0        
Allow    Egress      0          ANY          NONE         disabled    16204    175       0        


Endpoint ID: 3225
Path: /sys/fs/bpf/tc/globals/cilium_policy_03225

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11644403   116300    0        
Allow    Ingress     1          ANY          NONE         disabled    11259494   115240    0        
Allow    Egress      0          ANY          NONE         disabled    13167011   129558    0        


