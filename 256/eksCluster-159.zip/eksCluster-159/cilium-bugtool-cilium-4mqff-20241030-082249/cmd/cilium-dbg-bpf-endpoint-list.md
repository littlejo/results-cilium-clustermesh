IP ADDRESS         LOCAL ENDPOINT INFO
172.31.231.255:0   (localhost)                                                                                        
10.159.0.199:0     id=11    sec_id=4     flags=0x0000 ifindex=10  mac=DE:2B:0E:7C:03:38 nodemac=46:67:25:B8:95:43     
10.159.0.137:0     id=3225  sec_id=5255589 flags=0x0000 ifindex=18  mac=D6:53:68:F7:6F:95 nodemac=4A:E0:5E:D0:ED:27   
172.31.243.44:0    (localhost)                                                                                        
10.159.0.5:0       id=1486  sec_id=5248845 flags=0x0000 ifindex=14  mac=22:FA:64:6F:E1:6D nodemac=F6:F4:61:B2:06:75   
10.159.0.194:0     (localhost)                                                                                        
10.159.0.182:0     id=3183  sec_id=5248845 flags=0x0000 ifindex=12  mac=0A:AD:B3:3A:05:FF nodemac=A6:9A:D0:0A:72:73   
