key: 0b 00 00 00  value: 21 02 00 00
key: ce 05 00 00  value: 22 02 00 00
key: 6f 0c 00 00  value: 0d 02 00 00
key: 99 0c 00 00  value: 6a 02 00 00
Found 4 elements
