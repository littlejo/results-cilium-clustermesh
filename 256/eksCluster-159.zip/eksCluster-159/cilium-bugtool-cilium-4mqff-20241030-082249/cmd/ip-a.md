1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:db:3a:b6:e5:d3 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.243.44/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3526sec preferred_lft 3526sec
    inet6 fe80::8db:3aff:feb6:e5d3/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:87:63:17:27:d3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.231.255/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::887:63ff:fe17:27d3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:24:fd:fa:16:49 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b424:fdff:fefa:1649/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:44:ed:b0:43:18 brd ff:ff:ff:ff:ff:ff
    inet 10.159.0.194/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b444:edff:feb0:4318/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 1a:0c:d1:ca:c7:73 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::180c:d1ff:feca:c773/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:67:25:b8:95:43 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::4467:25ff:feb8:9543/64 scope link 
       valid_lft forever preferred_lft forever
12: lxce1020f678756@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:9a:d0:0a:72:73 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a49a:d0ff:fe0a:7273/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc497ebc93a7c0@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:f4:61:b2:06:75 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f4f4:61ff:feb2:675/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb7474ef23c9d@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:e0:5e:d0:ed:27 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::48e0:5eff:fed0:ed27/64 scope link 
       valid_lft forever preferred_lft forever
