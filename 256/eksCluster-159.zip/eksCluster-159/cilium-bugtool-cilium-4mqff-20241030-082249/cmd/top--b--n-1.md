top - 08:22:50 up 31 min,  0 users,  load average: 0.33, 0.24, 0.19
Tasks:  13 total,   2 running,  11 sleeping,   0 stopped,   0 zombie
%Cpu(s): 64.3 us, 28.6 sy,  0.0 ni,  7.1 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4464.2 free,   1203.1 used,   2146.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6426.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    716 root      20   0 1244340  21276  14396 S  26.7   0.3   0:00.04 hubble
      1 root      20   0 1606336 392984  76860 S  13.3   4.9   1:01.70 cilium-+
    394 root      20   0 1229744   6980   2864 S   0.0   0.1   0:01.21 cilium-+
    614 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    632 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    649 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    655 root      20   0 1240432  16180  11164 S   0.0   0.2   0:00.03 cilium-+
    656 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    693 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    695 root      20   0    6576   2420   2096 R   0.0   0.0   0:00.00 top
    705 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    737 root      20   0    3852   1292   1136 S   0.0   0.0   0:00.00 bash
    738 root      20   0    2196    784    704 R   0.0   0.0   0:00.00 pidof
