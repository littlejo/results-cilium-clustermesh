[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46c5f1a8_f913_4926_97c7_cddebd991a8a.slice/cri-containerd-2cba7f872d9a01b434bae3301778a37841206f48031e33414ecfee3fb986cca7.scope"
      }
    ],
    "ips": [
      "10.159.0.182"
    ],
    "name": "coredns-cc6ccd49c-bq5r6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode025bef3_ae19_44a5_bd88_dffa1437474b.slice/cri-containerd-8727f6e99c2fd04d0cbb20f91aec71fa24e792d3a1fa4057dc724fd031ea68b9.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode025bef3_ae19_44a5_bd88_dffa1437474b.slice/cri-containerd-a56783fee7bbacb34429d8ce973db2051a005599fcf301a8d46d72718952c7d1.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode025bef3_ae19_44a5_bd88_dffa1437474b.slice/cri-containerd-3db669c376e75a6f573bc615cb8ce082f0f48e6f710bc4baae4001428918b425.scope"
      }
    ],
    "ips": [
      "10.159.0.137"
    ],
    "name": "clustermesh-apiserver-6cb969ddf4-mtxcv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9439aeb6_ba5b_4ca1_aa47_142a0ca2d3b4.slice/cri-containerd-0c8eb9a0d6cf1a9e48de6f39e06baeadb18476357bee70a05fb99c013d90500d.scope"
      }
    ],
    "ips": [
      "10.159.0.5"
    ],
    "name": "coredns-cc6ccd49c-7r6vn",
    "namespace": "kube-system"
  }
]

