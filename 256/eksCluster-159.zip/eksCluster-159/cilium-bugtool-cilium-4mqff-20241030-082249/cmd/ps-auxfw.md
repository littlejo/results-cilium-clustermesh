USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         656  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         655  0.0  0.2 1240176 16180 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         682  0.0  0.0   6408  1632 ?        R    08:22   0:00  \_ ps auxfw
root         649  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         632  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         614  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  4.8  4.9 1606336 392984 ?      Ssl  08:01   1:01 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.0  0.0 1229744 6980 ?        Sl   08:01   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
