 08:22:49 up 32 min,  0 users,  load average: 0.19, 0.30, 0.20
