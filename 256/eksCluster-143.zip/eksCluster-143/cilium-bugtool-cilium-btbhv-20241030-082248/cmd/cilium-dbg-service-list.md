ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.241.150:443 (active)    
                                         2 => 172.31.152.27:443 (active)     
2    10.100.35.20:443     ClusterIP      1 => 172.31.222.170:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.143.0.148:53 (active)       
                                         2 => 10.143.0.69:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.143.0.148:9153 (active)     
                                         2 => 10.143.0.69:9153 (active)      
5    10.100.132.40:2379   ClusterIP      1 => 10.143.0.197:2379 (active)     
