1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:d8:60:00:cd:bb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.222.170/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3458sec preferred_lft 3458sec
    inet6 fe80::8d8:60ff:fe00:cdbb/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:f6:13:bd:dc:91 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.211.238/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8f6:13ff:febd:dc91/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:62:d5:01:c6:01 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7062:d5ff:fe01:c601/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:ee:6a:aa:e6:ea brd ff:ff:ff:ff:ff:ff
    inet 10.143.0.35/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c8ee:6aff:feaa:e6ea/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6e:15:63:37:33:40 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6c15:63ff:fe37:3340/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:63:6c:46:ad:dc brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::6063:6cff:fe46:addc/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc60d05ebeb0c4@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:33:d4:72:46:a2 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c433:d4ff:fe72:46a2/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc1825e4f74e9e@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:81:f4:ce:ce:9a brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a081:f4ff:fece:ce9a/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc5098b0d28b7c@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:89:29:d7:ca:d5 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::4c89:29ff:fed7:cad5/64 scope link 
       valid_lft forever preferred_lft forever
