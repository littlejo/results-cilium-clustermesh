key: 48 01 00 00  value: 03 02 00 00
key: 16 06 00 00  value: 16 02 00 00
key: c0 0b 00 00  value: 76 02 00 00
key: 3a 0c 00 00  value: 0d 02 00 00
Found 4 elements
