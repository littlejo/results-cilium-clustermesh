KEY             VALUE
AgentLiveness   1984194946518
UTimeOffset     3379442609375000
