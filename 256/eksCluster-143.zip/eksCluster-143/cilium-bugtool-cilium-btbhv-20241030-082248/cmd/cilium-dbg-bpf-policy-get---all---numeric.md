Endpoint ID: 328
Path: /sys/fs/bpf/tc/globals/cilium_policy_00328

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    129040   1483      0        
Allow    Egress      0          ANY          NONE         disabled    18112    196       0        


Endpoint ID: 1100
Path: /sys/fs/bpf/tc/globals/cilium_policy_01100

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1558
Path: /sys/fs/bpf/tc/globals/cilium_policy_01558

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1634362   20654     0        
Allow    Ingress     1          ANY          NONE         disabled    19842     233       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3008
Path: /sys/fs/bpf/tc/globals/cilium_policy_03008

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11395195   112746    0        
Allow    Ingress     1          ANY          NONE         disabled    9788212    102846    0        
Allow    Egress      0          ANY          NONE         disabled    12133054   119960    0        


Endpoint ID: 3130
Path: /sys/fs/bpf/tc/globals/cilium_policy_03130

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    127919   1470      0        
Allow    Egress      0          ANY          NONE         disabled    18210    199       0        


