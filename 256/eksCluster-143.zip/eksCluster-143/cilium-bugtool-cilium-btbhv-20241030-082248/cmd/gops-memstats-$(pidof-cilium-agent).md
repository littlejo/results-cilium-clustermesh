alloc: 135.16MB (141729744 bytes)
total-alloc: 2.22GB (2385108472 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 62969859
frees: 61977660
heap-alloc: 135.16MB (141729744 bytes)
heap-sys: 251.86MB (264093696 bytes)
heap-idle: 64.75MB (67895296 bytes)
heap-in-use: 187.11MB (196198400 bytes)
heap-released: 4.26MB (4464640 bytes)
heap-objects: 992199
stack-in-use: 64.09MB (67207168 bytes)
stack-sys: 64.09MB (67207168 bytes)
stack-mspan-inuse: 2.90MB (3043680 bytes)
stack-mspan-sys: 3.89MB (4080000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.19MB (1251889 bytes)
gc-sys: 6.00MB (6288752 bytes)
next-gc: when heap-alloc >= 216.23MB (226729784 bytes)
last-gc: 2024-10-30 08:23:06.934077469 +0000 UTC
gc-pause-total: 8.076487ms
gc-pause: 104961
gc-pause-end: 1730276586934077469
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0004516788073752066
enable-gc: true
debug-gc: false
