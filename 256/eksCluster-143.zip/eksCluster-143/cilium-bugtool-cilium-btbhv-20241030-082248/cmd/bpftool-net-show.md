xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 574
ens6(5) clsact/ingress cil_from_netdev-ens6 id 582
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 567
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 558
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 536
lxc60d05ebeb0c4(12) clsact/ingress cil_from_container-lxc60d05ebeb0c4 id 522
lxc1825e4f74e9e(14) clsact/ingress cil_from_container-lxc1825e4f74e9e id 508
lxc5098b0d28b7c(18) clsact/ingress cil_from_container-lxc5098b0d28b7c id 623

flow_dissector:

netfilter:

