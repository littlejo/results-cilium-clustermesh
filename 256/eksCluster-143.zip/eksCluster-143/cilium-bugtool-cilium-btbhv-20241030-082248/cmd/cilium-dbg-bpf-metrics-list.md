REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35258     2786956     677    bpf_overlay.c
Interface                 INGRESS     631106    130294251   1132   bpf_host.c
Success                   EGRESS      15287     1199144     1694   bpf_host.c
Success                   EGRESS      265414    33405892    1308   bpf_lxc.c
Success                   EGRESS      34875     2759457     53     encap.h
Success                   INGRESS     308223    34668833    86     l3.h
Success                   INGRESS     328845    36300691    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
