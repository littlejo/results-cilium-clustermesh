CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod30ec68c4_777c_457f_98fb_3660d554eaf9.slice/cri-containerd-8f8029d16c0e444f6355f1793f04b0c65f8b5715405bce3ce42d8cbd26f2cb60.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod30ec68c4_777c_457f_98fb_3660d554eaf9.slice/cri-containerd-f2f3cc9dddca7561e5930dcf8080741131adfc456176577cafa5a7f6913561a3.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad90ffb8_7c45_490e_aa16_6395b30d0ce4.slice/cri-containerd-4e07c5d602435cfc3fa1a5b463d68114bb1c68376264f40d54d8a75becce5828.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad90ffb8_7c45_490e_aa16_6395b30d0ce4.slice/cri-containerd-0f7680bf224a37f74cb107e73f636e150a80f22aa3f2e1e82bd4a2d565d8b28f.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1d1e4ce9_7710_4102_9870_c10e2934d767.slice/cri-containerd-ea76160a0df381a5712f28b44bc9063e7e3a8338f39381b4df701e8eaeedaea2.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1d1e4ce9_7710_4102_9870_c10e2934d767.slice/cri-containerd-03a39f415073b2d64cc30fcc4f4e8710bf73bb3475dd661dc4c6cb253825b490.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10e674d9_4bec_404c_aa02_735308c0c69a.slice/cri-containerd-3a5215dc1ebbbf6391fc5667957b1db79a6994cc1cc6e29698b4f027d6ff05ef.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10e674d9_4bec_404c_aa02_735308c0c69a.slice/cri-containerd-8758141c2b7e25bcd022479a75316a59b87d048c10cd22eb42410f4ed095e4c8.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod49380bea_ab80_4c87_8da2_688e69aa7d4f.slice/cri-containerd-644bc3936e7ff60ad90a7476c006c57a47121a97f0292b173b875329a525ce2a.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod49380bea_ab80_4c87_8da2_688e69aa7d4f.slice/cri-containerd-ae110c2051f277f2119c69dacc6952eb3ac58445555da5237f7778ebde5bf103.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod49380bea_ab80_4c87_8da2_688e69aa7d4f.slice/cri-containerd-169652860b26e710b608e6b20f4ff417b6b67c74c17774ee9c3e7be0e9c5b8a8.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod49380bea_ab80_4c87_8da2_688e69aa7d4f.slice/cri-containerd-4a91563dd79ad0f2c040debae07524bf57b95373f05e73a2f0f98ab97f660607.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb7e398e6_d821_424d_9c0e_74412c953590.slice/cri-containerd-ddfe18aedaccf62e94ee158566952b86a3d0e73b83a63158ef1a1f83b461b339.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb7e398e6_d821_424d_9c0e_74412c953590.slice/cri-containerd-5b57868556bbed02d143315fe1d054cccc5ff086e096b6e7294fa8ae1eecbc23.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb10085a1_dd55_4d1a_a9dc_745cce9e9f8c.slice/cri-containerd-e4a93cb172f2ffb9b9dd62b640bad2ab75b327d8c028ee7b99ca0e84a55da2c2.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb10085a1_dd55_4d1a_a9dc_745cce9e9f8c.slice/cri-containerd-427470f6e5953cc140bc777c0b7fdfbae2db6d8035443913efb42eb5e0ec8673.scope
    98       cgroup_device   multi                                          
