IP ADDRESS         LOCAL ENDPOINT INFO
10.143.0.69:0      id=3130  sec_id=4744577 flags=0x0000 ifindex=12  mac=B2:F8:3E:AF:CE:2C nodemac=C6:33:D4:72:46:A2   
172.31.211.238:0   (localhost)                                                                                        
172.31.222.170:0   (localhost)                                                                                        
10.143.0.197:0     id=3008  sec_id=4724910 flags=0x0000 ifindex=18  mac=CE:07:C8:3C:2F:12 nodemac=4E:89:29:D7:CA:D5   
10.143.0.148:0     id=328   sec_id=4744577 flags=0x0000 ifindex=14  mac=CE:94:D4:1B:C1:E6 nodemac=A2:81:F4:CE:CE:9A   
10.143.0.23:0      id=1558  sec_id=4     flags=0x0000 ifindex=10  mac=EE:4D:F0:07:71:53 nodemac=62:63:6C:46:AD:DC     
10.143.0.35:0      (localhost)                                                                                        
