{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:50.635Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.211.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:50.636Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.222.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:50.636Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:55.157Z",
  "value": "id=3130  sec_id=4744577 flags=0x0000 ifindex=12  mac=B2:F8:3E:AF:CE:2C nodemac=C6:33:D4:72:46:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:55.181Z",
  "value": "id=1558  sec_id=4     flags=0x0000 ifindex=10  mac=EE:4D:F0:07:71:53 nodemac=62:63:6C:46:AD:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:55.242Z",
  "value": "id=328   sec_id=4744577 flags=0x0000 ifindex=14  mac=CE:94:D4:1B:C1:E6 nodemac=A2:81:F4:CE:CE:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:55.296Z",
  "value": "id=3130  sec_id=4744577 flags=0x0000 ifindex=12  mac=B2:F8:3E:AF:CE:2C nodemac=C6:33:D4:72:46:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:55.359Z",
  "value": "id=1558  sec_id=4     flags=0x0000 ifindex=10  mac=EE:4D:F0:07:71:53 nodemac=62:63:6C:46:AD:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:54.782Z",
  "value": "id=1558  sec_id=4     flags=0x0000 ifindex=10  mac=EE:4D:F0:07:71:53 nodemac=62:63:6C:46:AD:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:54.783Z",
  "value": "id=3130  sec_id=4744577 flags=0x0000 ifindex=12  mac=B2:F8:3E:AF:CE:2C nodemac=C6:33:D4:72:46:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:54.783Z",
  "value": "id=328   sec_id=4744577 flags=0x0000 ifindex=14  mac=CE:94:D4:1B:C1:E6 nodemac=A2:81:F4:CE:CE:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:54.812Z",
  "value": "id=1001  sec_id=4724910 flags=0x0000 ifindex=16  mac=A6:F0:89:4C:05:5E nodemac=12:63:67:4E:EE:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:55.781Z",
  "value": "id=1558  sec_id=4     flags=0x0000 ifindex=10  mac=EE:4D:F0:07:71:53 nodemac=62:63:6C:46:AD:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:55.781Z",
  "value": "id=1001  sec_id=4724910 flags=0x0000 ifindex=16  mac=A6:F0:89:4C:05:5E nodemac=12:63:67:4E:EE:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:55.781Z",
  "value": "id=3130  sec_id=4744577 flags=0x0000 ifindex=12  mac=B2:F8:3E:AF:CE:2C nodemac=C6:33:D4:72:46:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:55.782Z",
  "value": "id=328   sec_id=4744577 flags=0x0000 ifindex=14  mac=CE:94:D4:1B:C1:E6 nodemac=A2:81:F4:CE:CE:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:27.892Z",
  "value": "id=3008  sec_id=4724910 flags=0x0000 ifindex=18  mac=CE:07:C8:3C:2F:12 nodemac=4E:89:29:D7:CA:D5"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.143.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:38.227Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.837Z",
  "value": "id=1558  sec_id=4     flags=0x0000 ifindex=10  mac=EE:4D:F0:07:71:53 nodemac=62:63:6C:46:AD:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.837Z",
  "value": "id=3130  sec_id=4744577 flags=0x0000 ifindex=12  mac=B2:F8:3E:AF:CE:2C nodemac=C6:33:D4:72:46:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.838Z",
  "value": "id=328   sec_id=4744577 flags=0x0000 ifindex=14  mac=CE:94:D4:1B:C1:E6 nodemac=A2:81:F4:CE:CE:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.838Z",
  "value": "id=3008  sec_id=4724910 flags=0x0000 ifindex=18  mac=CE:07:C8:3C:2F:12 nodemac=4E:89:29:D7:CA:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.732Z",
  "value": "id=1558  sec_id=4     flags=0x0000 ifindex=10  mac=EE:4D:F0:07:71:53 nodemac=62:63:6C:46:AD:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.732Z",
  "value": "id=3130  sec_id=4744577 flags=0x0000 ifindex=12  mac=B2:F8:3E:AF:CE:2C nodemac=C6:33:D4:72:46:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.733Z",
  "value": "id=328   sec_id=4744577 flags=0x0000 ifindex=14  mac=CE:94:D4:1B:C1:E6 nodemac=A2:81:F4:CE:CE:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.733Z",
  "value": "id=3008  sec_id=4724910 flags=0x0000 ifindex=18  mac=CE:07:C8:3C:2F:12 nodemac=4E:89:29:D7:CA:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.731Z",
  "value": "id=328   sec_id=4744577 flags=0x0000 ifindex=14  mac=CE:94:D4:1B:C1:E6 nodemac=A2:81:F4:CE:CE:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.731Z",
  "value": "id=3008  sec_id=4724910 flags=0x0000 ifindex=18  mac=CE:07:C8:3C:2F:12 nodemac=4E:89:29:D7:CA:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.732Z",
  "value": "id=1558  sec_id=4     flags=0x0000 ifindex=10  mac=EE:4D:F0:07:71:53 nodemac=62:63:6C:46:AD:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.732Z",
  "value": "id=3130  sec_id=4744577 flags=0x0000 ifindex=12  mac=B2:F8:3E:AF:CE:2C nodemac=C6:33:D4:72:46:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.732Z",
  "value": "id=3008  sec_id=4724910 flags=0x0000 ifindex=18  mac=CE:07:C8:3C:2F:12 nodemac=4E:89:29:D7:CA:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.732Z",
  "value": "id=328   sec_id=4744577 flags=0x0000 ifindex=14  mac=CE:94:D4:1B:C1:E6 nodemac=A2:81:F4:CE:CE:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.732Z",
  "value": "id=1558  sec_id=4     flags=0x0000 ifindex=10  mac=EE:4D:F0:07:71:53 nodemac=62:63:6C:46:AD:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.143.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.732Z",
  "value": "id=3130  sec_id=4744577 flags=0x0000 ifindex=12  mac=B2:F8:3E:AF:CE:2C nodemac=C6:33:D4:72:46:A2"
}

