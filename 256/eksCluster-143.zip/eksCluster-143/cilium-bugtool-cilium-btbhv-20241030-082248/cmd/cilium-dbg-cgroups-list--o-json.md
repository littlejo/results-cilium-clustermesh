[
  {
    "containers": [
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod49380bea_ab80_4c87_8da2_688e69aa7d4f.slice/cri-containerd-644bc3936e7ff60ad90a7476c006c57a47121a97f0292b173b875329a525ce2a.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod49380bea_ab80_4c87_8da2_688e69aa7d4f.slice/cri-containerd-ae110c2051f277f2119c69dacc6952eb3ac58445555da5237f7778ebde5bf103.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod49380bea_ab80_4c87_8da2_688e69aa7d4f.slice/cri-containerd-4a91563dd79ad0f2c040debae07524bf57b95373f05e73a2f0f98ab97f660607.scope"
      }
    ],
    "ips": [
      "10.143.0.197"
    ],
    "name": "clustermesh-apiserver-844747ffdc-c5pwz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod30ec68c4_777c_457f_98fb_3660d554eaf9.slice/cri-containerd-f2f3cc9dddca7561e5930dcf8080741131adfc456176577cafa5a7f6913561a3.scope"
      }
    ],
    "ips": [
      "10.143.0.69"
    ],
    "name": "coredns-cc6ccd49c-vr6b2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad90ffb8_7c45_490e_aa16_6395b30d0ce4.slice/cri-containerd-0f7680bf224a37f74cb107e73f636e150a80f22aa3f2e1e82bd4a2d565d8b28f.scope"
      }
    ],
    "ips": [
      "10.143.0.148"
    ],
    "name": "coredns-cc6ccd49c-5pxvl",
    "namespace": "kube-system"
  }
]

