Endpoint ID: 319
Path: /sys/fs/bpf/tc/globals/cilium_policy_00319

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 494
Path: /sys/fs/bpf/tc/globals/cilium_policy_00494

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    148405   1701      0        
Allow    Egress      0          ANY          NONE         disabled    19520    215       0        


Endpoint ID: 1292
Path: /sys/fs/bpf/tc/globals/cilium_policy_01292

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11577249   115717    0        
Allow    Ingress     1          ANY          NONE         disabled    10366174   109324    0        
Allow    Egress      0          ANY          NONE         disabled    13799382   135274    0        


Endpoint ID: 2402
Path: /sys/fs/bpf/tc/globals/cilium_policy_02402

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    149461   1717      0        
Allow    Egress      0          ANY          NONE         disabled    20043    223       0        


Endpoint ID: 2950
Path: /sys/fs/bpf/tc/globals/cilium_policy_02950

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1649560   20843     0        
Allow    Ingress     1          ANY          NONE         disabled    22782     268       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


