 08:22:49 up 33 min,  0 users,  load average: 1.23, 0.65, 0.34
