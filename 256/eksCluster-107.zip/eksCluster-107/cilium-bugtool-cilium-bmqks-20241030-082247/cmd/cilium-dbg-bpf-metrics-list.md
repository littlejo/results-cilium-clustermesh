REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36606     2898989     677    bpf_overlay.c
Interface                 INGRESS     654756    133902390   1132   bpf_host.c
Success                   EGRESS      16466     1297525     1694   bpf_host.c
Success                   EGRESS      278756    34786146    1308   bpf_lxc.c
Success                   EGRESS      37046     2927796     53     encap.h
Success                   INGRESS     320907    36374129    86     l3.h
Success                   INGRESS     341698    38019639    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
