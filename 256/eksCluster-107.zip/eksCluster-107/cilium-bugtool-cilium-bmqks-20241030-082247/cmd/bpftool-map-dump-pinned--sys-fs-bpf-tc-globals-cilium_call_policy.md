key: ee 01 00 00  value: 23 02 00 00
key: 0c 05 00 00  value: 76 02 00 00
key: 62 09 00 00  value: 02 02 00 00
key: 86 0b 00 00  value: 06 02 00 00
Found 4 elements
