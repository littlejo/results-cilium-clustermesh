top - 08:22:49 up 33 min,  0 users,  load average: 1.23, 0.65, 0.34
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 69.0 us, 24.1 sy,  0.0 ni,  6.9 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4463.0 free,   1205.3 used,   2145.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6424.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 393712  78712 S  80.0   4.9   0:53.00 cilium-+
    674 root      20   0 1229640  10672   4004 S   6.7   0.1   0:00.01 gops
    705 root      20   0 1240432  16256  11292 S   6.7   0.2   0:00.03 cilium-+
    756 root      20   0 1243508  19020  13888 S   6.7   0.2   0:00.01 hubble
    405 root      20   0 1229488   7224   2924 S   0.0   0.1   0:01.12 cilium-+
    695 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    715 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    741 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    745 root      20   0    2208    776    696 S   0.0   0.0   0:00.00 timeout
    772 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
