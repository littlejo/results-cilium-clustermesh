xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 571
ens6(5) clsact/ingress cil_from_netdev-ens6 id 582
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 569
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 557
cilium_host(7) clsact/egress cil_from_host-cilium_host id 556
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 521
lxc85a73a30d408(12) clsact/ingress cil_from_container-lxc85a73a30d408 id 541
lxc42b26a9cee29(14) clsact/ingress cil_from_container-lxc42b26a9cee29 id 515
lxc2e8fe324ee80(18) clsact/ingress cil_from_container-lxc2e8fe324ee80 id 624

flow_dissector:

netfilter:

