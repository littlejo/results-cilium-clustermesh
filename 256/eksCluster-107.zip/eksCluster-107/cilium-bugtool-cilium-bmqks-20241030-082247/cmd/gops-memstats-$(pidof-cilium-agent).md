alloc: 158.24MB (165926896 bytes)
total-alloc: 2.30GB (2473077008 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 64307472
frees: 62586609
heap-alloc: 158.24MB (165926896 bytes)
heap-sys: 247.36MB (259375104 bytes)
heap-idle: 59.68MB (62578688 bytes)
heap-in-use: 187.68MB (196796416 bytes)
heap-released: 3.52MB (3694592 bytes)
heap-objects: 1720863
stack-in-use: 64.59MB (67731456 bytes)
stack-sys: 64.59MB (67731456 bytes)
stack-mspan-inuse: 3.17MB (3320320 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.18MB (1239985 bytes)
gc-sys: 6.02MB (6313400 bytes)
next-gc: when heap-alloc >= 213.36MB (223723816 bytes)
last-gc: 2024-10-30 08:22:52.946927709 +0000 UTC
gc-pause-total: 22.336924ms
gc-pause: 85269
gc-pause-end: 1730276572946927709
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.0004364057685631444
enable-gc: true
debug-gc: false
