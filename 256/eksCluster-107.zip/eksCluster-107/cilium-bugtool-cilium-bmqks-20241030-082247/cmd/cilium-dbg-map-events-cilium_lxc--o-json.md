{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:21.175Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.209.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:21.175Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.214.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:21.175Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:25.665Z",
  "value": "id=2950  sec_id=4     flags=0x0000 ifindex=10  mac=1A:BE:5C:20:92:1E nodemac=C6:AE:B1:C9:E9:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:25.668Z",
  "value": "id=494   sec_id=3544052 flags=0x0000 ifindex=12  mac=7E:26:83:94:4C:8C nodemac=3E:E0:6D:95:64:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:25.744Z",
  "value": "id=2402  sec_id=3544052 flags=0x0000 ifindex=14  mac=8E:92:F3:41:7C:B1 nodemac=82:34:4F:BB:32:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:25.833Z",
  "value": "id=2950  sec_id=4     flags=0x0000 ifindex=10  mac=1A:BE:5C:20:92:1E nodemac=C6:AE:B1:C9:E9:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:25.897Z",
  "value": "id=494   sec_id=3544052 flags=0x0000 ifindex=12  mac=7E:26:83:94:4C:8C nodemac=3E:E0:6D:95:64:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:26.966Z",
  "value": "id=494   sec_id=3544052 flags=0x0000 ifindex=12  mac=7E:26:83:94:4C:8C nodemac=3E:E0:6D:95:64:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:26.966Z",
  "value": "id=2950  sec_id=4     flags=0x0000 ifindex=10  mac=1A:BE:5C:20:92:1E nodemac=C6:AE:B1:C9:E9:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:26.966Z",
  "value": "id=2402  sec_id=3544052 flags=0x0000 ifindex=14  mac=8E:92:F3:41:7C:B1 nodemac=82:34:4F:BB:32:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:26.997Z",
  "value": "id=1730  sec_id=3547692 flags=0x0000 ifindex=16  mac=A2:01:B8:0A:7D:92 nodemac=9A:BC:55:6D:54:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:27.966Z",
  "value": "id=1730  sec_id=3547692 flags=0x0000 ifindex=16  mac=A2:01:B8:0A:7D:92 nodemac=9A:BC:55:6D:54:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:27.966Z",
  "value": "id=2402  sec_id=3544052 flags=0x0000 ifindex=14  mac=8E:92:F3:41:7C:B1 nodemac=82:34:4F:BB:32:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:27.966Z",
  "value": "id=494   sec_id=3544052 flags=0x0000 ifindex=12  mac=7E:26:83:94:4C:8C nodemac=3E:E0:6D:95:64:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:27.966Z",
  "value": "id=2950  sec_id=4     flags=0x0000 ifindex=10  mac=1A:BE:5C:20:92:1E nodemac=C6:AE:B1:C9:E9:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.403Z",
  "value": "id=1292  sec_id=3547692 flags=0x0000 ifindex=18  mac=DE:B0:39:1D:9B:11 nodemac=D2:30:26:E9:C0:E3"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.107.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.732Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:16.508Z",
  "value": "id=2402  sec_id=3544052 flags=0x0000 ifindex=14  mac=8E:92:F3:41:7C:B1 nodemac=82:34:4F:BB:32:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:16.509Z",
  "value": "id=1292  sec_id=3547692 flags=0x0000 ifindex=18  mac=DE:B0:39:1D:9B:11 nodemac=D2:30:26:E9:C0:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:16.511Z",
  "value": "id=494   sec_id=3544052 flags=0x0000 ifindex=12  mac=7E:26:83:94:4C:8C nodemac=3E:E0:6D:95:64:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:16.511Z",
  "value": "id=2950  sec_id=4     flags=0x0000 ifindex=10  mac=1A:BE:5C:20:92:1E nodemac=C6:AE:B1:C9:E9:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.534Z",
  "value": "id=2402  sec_id=3544052 flags=0x0000 ifindex=14  mac=8E:92:F3:41:7C:B1 nodemac=82:34:4F:BB:32:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.534Z",
  "value": "id=1292  sec_id=3547692 flags=0x0000 ifindex=18  mac=DE:B0:39:1D:9B:11 nodemac=D2:30:26:E9:C0:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.535Z",
  "value": "id=494   sec_id=3544052 flags=0x0000 ifindex=12  mac=7E:26:83:94:4C:8C nodemac=3E:E0:6D:95:64:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.535Z",
  "value": "id=2950  sec_id=4     flags=0x0000 ifindex=10  mac=1A:BE:5C:20:92:1E nodemac=C6:AE:B1:C9:E9:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.510Z",
  "value": "id=2950  sec_id=4     flags=0x0000 ifindex=10  mac=1A:BE:5C:20:92:1E nodemac=C6:AE:B1:C9:E9:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.510Z",
  "value": "id=494   sec_id=3544052 flags=0x0000 ifindex=12  mac=7E:26:83:94:4C:8C nodemac=3E:E0:6D:95:64:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.510Z",
  "value": "id=2402  sec_id=3544052 flags=0x0000 ifindex=14  mac=8E:92:F3:41:7C:B1 nodemac=82:34:4F:BB:32:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.510Z",
  "value": "id=1292  sec_id=3547692 flags=0x0000 ifindex=18  mac=DE:B0:39:1D:9B:11 nodemac=D2:30:26:E9:C0:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.510Z",
  "value": "id=1292  sec_id=3547692 flags=0x0000 ifindex=18  mac=DE:B0:39:1D:9B:11 nodemac=D2:30:26:E9:C0:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.511Z",
  "value": "id=2950  sec_id=4     flags=0x0000 ifindex=10  mac=1A:BE:5C:20:92:1E nodemac=C6:AE:B1:C9:E9:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.511Z",
  "value": "id=2402  sec_id=3544052 flags=0x0000 ifindex=14  mac=8E:92:F3:41:7C:B1 nodemac=82:34:4F:BB:32:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.511Z",
  "value": "id=494   sec_id=3544052 flags=0x0000 ifindex=12  mac=7E:26:83:94:4C:8C nodemac=3E:E0:6D:95:64:64"
}

