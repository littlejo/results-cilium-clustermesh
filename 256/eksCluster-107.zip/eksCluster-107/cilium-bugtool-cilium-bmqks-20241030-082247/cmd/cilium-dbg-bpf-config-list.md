KEY             VALUE
AgentLiveness   2065734367560
UTimeOffset     3379442449218750
