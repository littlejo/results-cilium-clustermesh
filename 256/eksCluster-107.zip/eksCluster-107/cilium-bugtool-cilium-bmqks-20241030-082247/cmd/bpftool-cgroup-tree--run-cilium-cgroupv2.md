CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode331b12e_e6a9_4c80_a498_96e6585ce0ca.slice/cri-containerd-79642c0b4ac9718185b4d273b06bd196094eb9ee0a76b9387043119bc9099743.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode331b12e_e6a9_4c80_a498_96e6585ce0ca.slice/cri-containerd-f3f1e2a662da3627721702b990f1202cd48feb8f195bfacdbee3c9f526545bc3.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod79d89840_94db_4c71_9a14_df57a4a1ed9d.slice/cri-containerd-4d08964fd9a392d6ea9d170314952ef2a9e444695b9de93dd12cadf872b98897.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod79d89840_94db_4c71_9a14_df57a4a1ed9d.slice/cri-containerd-34e216be5583e06168b824c87d17856e0a92bddbf662fc34cef17f25a3ea71b0.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf328fdc_f30c_4ddc_873d_c3d31b8c6b87.slice/cri-containerd-0e6246f51806982d3a918b7c2745c2acaae541c11e9600dea17324166d8fb3c7.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf328fdc_f30c_4ddc_873d_c3d31b8c6b87.slice/cri-containerd-1ce38baaf31cd9a96c012f1736d2f36193244b8c52a2cb17a7a84084e5702ccf.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode03ca88d_74c9_47e9_8a8a_7e0865c005bc.slice/cri-containerd-aec47b460094c2f930a257364fb5cea69e02e25548558d30d590feecc6d8d0ab.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode03ca88d_74c9_47e9_8a8a_7e0865c005bc.slice/cri-containerd-17d27082a23c6d20e22b85c81830be0b2a253efbfd8867de12bb0a8838dbdac3.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2627e132_ae6f_4ca0_a5e9_122b53a0603b.slice/cri-containerd-cb463773696f939c75aa7de78647148c8fe8ce45fc6946bf01bbdefd58b87a4e.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2627e132_ae6f_4ca0_a5e9_122b53a0603b.slice/cri-containerd-6560f4b7c39295e305dded7385dc339b2223b1e12e553ee61f858c8c7fe2a400.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7bd23877_d7d2_488e_83b8_8e644d830186.slice/cri-containerd-3d7a80c4aff5ae3c06c7aac0574acfb970792a6776049d8f7bfb70f0a205d47b.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7bd23877_d7d2_488e_83b8_8e644d830186.slice/cri-containerd-a9b1c6608fbf9c69007461aba6ded89dab0f73d4d6dabc576b08e66fb9c4c650.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7bd23877_d7d2_488e_83b8_8e644d830186.slice/cri-containerd-6450fba97f825cccd5dffefcab0dd0a01edd3657009b7f3457628e70e08e6712.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7bd23877_d7d2_488e_83b8_8e644d830186.slice/cri-containerd-c26b158a181bbac185f7a805c4187581ee5aa055909af183a898b7a1ba1d4627.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e7b2f74_d88a_489e_ad50_6202764b80ce.slice/cri-containerd-9fe1baca3132adb0acfe2dc2f59171fa125afc27b92794e45e1820e61ab2249a.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e7b2f74_d88a_489e_ad50_6202764b80ce.slice/cri-containerd-f7ec17cfd022714d8b351d05e1ea65d87265409211643f0289ac08f87ec5797d.scope
    98       cgroup_device   multi                                          
