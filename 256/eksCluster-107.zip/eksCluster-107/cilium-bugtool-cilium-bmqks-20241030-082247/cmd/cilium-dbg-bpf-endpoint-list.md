IP ADDRESS         LOCAL ENDPOINT INFO
10.107.0.107:0     id=2402  sec_id=3544052 flags=0x0000 ifindex=14  mac=8E:92:F3:41:7C:B1 nodemac=82:34:4F:BB:32:FE   
172.31.214.227:0   (localhost)                                                                                        
10.107.0.243:0     (localhost)                                                                                        
10.107.0.117:0     id=2950  sec_id=4     flags=0x0000 ifindex=10  mac=1A:BE:5C:20:92:1E nodemac=C6:AE:B1:C9:E9:73     
10.107.0.63:0      id=1292  sec_id=3547692 flags=0x0000 ifindex=18  mac=DE:B0:39:1D:9B:11 nodemac=D2:30:26:E9:C0:E3   
172.31.209.79:0    (localhost)                                                                                        
10.107.0.166:0     id=494   sec_id=3544052 flags=0x0000 ifindex=12  mac=7E:26:83:94:4C:8C nodemac=3E:E0:6D:95:64:64   
