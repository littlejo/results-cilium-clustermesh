USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         715  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         705  0.0  0.2 1240432 16256 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         730  0.0  0.0   6408  1648 ?        R    08:22   0:00  \_ ps auxfw
root         731  0.0  0.2 1240432 16256 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         695  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         674  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.4  4.8 1606336 386848 ?      Ssl  07:57   0:52 cilium-agent --config-dir=/tmp/cilium/config-map
root         405  0.0  0.0 1229488 7224 ?        Sl   07:57   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
