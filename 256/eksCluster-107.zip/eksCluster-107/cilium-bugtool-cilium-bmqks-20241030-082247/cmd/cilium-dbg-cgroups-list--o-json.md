[
  {
    "containers": [
      {
        "cgroup-id": 9268,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7bd23877_d7d2_488e_83b8_8e644d830186.slice/cri-containerd-a9b1c6608fbf9c69007461aba6ded89dab0f73d4d6dabc576b08e66fb9c4c650.scope"
      },
      {
        "cgroup-id": 9184,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7bd23877_d7d2_488e_83b8_8e644d830186.slice/cri-containerd-3d7a80c4aff5ae3c06c7aac0574acfb970792a6776049d8f7bfb70f0a205d47b.scope"
      },
      {
        "cgroup-id": 9352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7bd23877_d7d2_488e_83b8_8e644d830186.slice/cri-containerd-c26b158a181bbac185f7a805c4187581ee5aa055909af183a898b7a1ba1d4627.scope"
      }
    ],
    "ips": [
      "10.107.0.63"
    ],
    "name": "clustermesh-apiserver-5f895b5fbf-g4dvn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode03ca88d_74c9_47e9_8a8a_7e0865c005bc.slice/cri-containerd-17d27082a23c6d20e22b85c81830be0b2a253efbfd8867de12bb0a8838dbdac3.scope"
      }
    ],
    "ips": [
      "10.107.0.166"
    ],
    "name": "coredns-cc6ccd49c-b5xdl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod79d89840_94db_4c71_9a14_df57a4a1ed9d.slice/cri-containerd-4d08964fd9a392d6ea9d170314952ef2a9e444695b9de93dd12cadf872b98897.scope"
      }
    ],
    "ips": [
      "10.107.0.107"
    ],
    "name": "coredns-cc6ccd49c-fklrg",
    "namespace": "kube-system"
  }
]

