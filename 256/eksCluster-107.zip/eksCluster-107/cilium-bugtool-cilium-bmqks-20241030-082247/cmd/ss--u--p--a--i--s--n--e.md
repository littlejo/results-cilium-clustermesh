Total: 692
TCP:   1877 (estab 441, closed 1417, orphaned 0, timewait 563)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  460       450       10       
INET	  470       456       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.214.227%ens5:68         0.0.0.0:*    uid:192 ino:72768 sk:401 cgroup:unreachable:c4e <->                            
UNCONN 0      0                            127.0.0.1:32853      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:33204 sk:402 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:33316 sk:403 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:14793 sk:404 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:33315 sk:405 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:14794 sk:406 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::85d:31ff:fea0:7465]%ens5:546           [::]:*    uid:192 ino:16030 sk:407 cgroup:unreachable:c4e v6only:1 <->                   
