ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.221.209:443 (active)    
                                         2 => 172.31.188.33:443 (active)     
2    10.100.193.75:443    ClusterIP      1 => 172.31.214.227:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.107.0.107:53 (active)       
                                         2 => 10.107.0.166:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.107.0.107:9153 (active)     
                                         2 => 10.107.0.166:9153 (active)     
5    10.100.134.92:2379   ClusterIP      1 => 10.107.0.63:2379 (active)      
