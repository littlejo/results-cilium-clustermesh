[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1da9327_b335_479c_9754_7765b268ba73.slice/cri-containerd-0e68ecb751a387abe9ea03713c277b82a0be6bd92ae14456989a9d85f1e5001d.scope"
      }
    ],
    "ips": [
      "10.230.0.159"
    ],
    "name": "coredns-cc6ccd49c-wl2ts",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab8c9b2f_4e55_4e7b_b1a4_057a98220e07.slice/cri-containerd-8bc75f80b02adc3d305cdcdb1d6ea9cc060ccaee5f542eecec2ed19359202816.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab8c9b2f_4e55_4e7b_b1a4_057a98220e07.slice/cri-containerd-6b4eb5b732600b5629bc1d8818916c6744b15d334ea288c3b18fb5bd219fa013.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab8c9b2f_4e55_4e7b_b1a4_057a98220e07.slice/cri-containerd-cd7f84176cfe9a2e87ba4fa0b1cd8bea37e3cb0f68b068344103ad62f1384136.scope"
      }
    ],
    "ips": [
      "10.230.0.207"
    ],
    "name": "clustermesh-apiserver-6bfd779db8-ntqmb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeae2b01c_c3d2_4db9_890a_9e98108cbb7d.slice/cri-containerd-a994930db631a6c0b0c34fcfc278bfb8312b6991f959d4915570a49667552deb.scope"
      }
    ],
    "ips": [
      "10.230.0.185"
    ],
    "name": "coredns-cc6ccd49c-zqqz8",
    "namespace": "kube-system"
  }
]

