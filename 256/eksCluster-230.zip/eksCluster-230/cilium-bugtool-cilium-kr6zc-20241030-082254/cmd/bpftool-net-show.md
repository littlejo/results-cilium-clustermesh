xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 573
ens6(5) clsact/ingress cil_from_netdev-ens6 id 579
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 565
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 556
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 511
lxc5b9c42fba010(12) clsact/ingress cil_from_container-lxc5b9c42fba010 id 522
lxc7df3b75a61ee(14) clsact/ingress cil_from_container-lxc7df3b75a61ee id 541
lxcacece83349e2(18) clsact/ingress cil_from_container-lxcacece83349e2 id 625

flow_dissector:

netfilter:

