top - 08:22:55 up 27 min,  0 users,  load average: 0.41, 0.26, 0.17
Tasks:  11 total,   2 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 40.0 us, 50.0 sy,  0.0 ni,  3.3 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   7814.2 total,   4480.8 free,   1187.6 used,   2145.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6441.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    727 root      20   0 1244340  21360  14208 S  33.3   0.3   0:00.05 hubble
      1 root      20   0 1606144 388048  77560 S  26.7   4.8   0:38.75 cilium-+
    417 root      20   0 1229744   8180   3836 S   0.0   0.1   0:01.05 cilium-+
    642 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    656 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    664 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    674 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    686 root      20   0 1240176  15856  11100 S   0.0   0.2   0:00.02 cilium-+
    716 root      20   0    2208    792    716 S   0.0   0.0   0:00.00 timeout
    723 root      20   0    6576   2420   2096 R   0.0   0.0   0:00.00 top
    748 root      20   0    4220    828    720 R   0.0   0.0   0:00.00 ip
