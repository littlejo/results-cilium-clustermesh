 08:22:55 up 27 min,  0 users,  load average: 0.41, 0.26, 0.17
