alloc: 206.95MB (217000776 bytes)
total-alloc: 2.18GB (2342223168 bytes)
sys: 340.90MB (357457268 bytes)
lookups: 0
mallocs: 62129905
frees: 60127467
heap-alloc: 206.95MB (217000776 bytes)
heap-sys: 263.77MB (276578304 bytes)
heap-idle: 31.31MB (32833536 bytes)
heap-in-use: 232.45MB (243744768 bytes)
heap-released: 64.00KB (65536 bytes)
heap-objects: 2002438
stack-in-use: 64.19MB (67305472 bytes)
stack-sys: 64.19MB (67305472 bytes)
stack-mspan-inuse: 3.42MB (3582720 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 974.81KB (998201 bytes)
gc-sys: 6.14MB (6437272 bytes)
next-gc: when heap-alloc >= 218.55MB (229163368 bytes)
last-gc: 2024-10-30 08:22:56.8848147 +0000 UTC
gc-pause-total: 15.493099ms
gc-pause: 8350792
gc-pause-end: 1730276576884814700
num-gc: 79
num-forced-gc: 0
gc-cpu-fraction: 0.000517736098619747
enable-gc: true
debug-gc: false
