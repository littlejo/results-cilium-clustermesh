key: c1 00 00 00  value: 08 02 00 00
key: 2a 02 00 00  value: 6d 02 00 00
key: 83 02 00 00  value: 19 02 00 00
key: 6f 0a 00 00  value: f8 01 00 00
Found 4 elements
