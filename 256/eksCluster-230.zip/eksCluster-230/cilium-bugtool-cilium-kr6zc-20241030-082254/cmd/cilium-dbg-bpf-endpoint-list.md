IP ADDRESS        LOCAL ENDPOINT INFO
10.230.0.159:0    id=193   sec_id=7585810 flags=0x0000 ifindex=12  mac=26:76:29:E4:2C:5E nodemac=26:E8:F8:94:1D:67   
172.31.130.29:0   (localhost)                                                                                        
10.230.0.207:0    id=554   sec_id=7575767 flags=0x0000 ifindex=18  mac=4A:75:14:7F:9F:62 nodemac=56:9F:E0:C5:23:FB   
10.230.0.189:0    id=2671  sec_id=4     flags=0x0000 ifindex=10  mac=EA:2B:19:D3:AA:95 nodemac=1A:A2:48:EC:30:A1     
172.31.138.46:0   (localhost)                                                                                        
10.230.0.152:0    (localhost)                                                                                        
10.230.0.185:0    id=643   sec_id=7585810 flags=0x0000 ifindex=14  mac=AE:CC:7E:F8:1A:75 nodemac=C2:D3:B2:3E:9A:A3   
