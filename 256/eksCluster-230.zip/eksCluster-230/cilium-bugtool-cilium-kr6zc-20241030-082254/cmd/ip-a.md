1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:4c:19:58:91:8d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.138.46/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1957sec preferred_lft 1957sec
    inet6 fe80::44c:19ff:fe58:918d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:04:29:57:27:97 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.130.29/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::404:29ff:fe57:2797/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:a2:ca:42:8f:97 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::30a2:caff:fe42:8f97/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:b5:66:92:2b:85 brd ff:ff:ff:ff:ff:ff
    inet 10.230.0.152/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::84b5:66ff:fe92:2b85/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 26:37:b6:95:df:22 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2437:b6ff:fe95:df22/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:a2:48:ec:30:a1 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::18a2:48ff:feec:30a1/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc5b9c42fba010@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:e8:f8:94:1d:67 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::24e8:f8ff:fe94:1d67/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc7df3b75a61ee@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:d3:b2:3e:9a:a3 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c0d3:b2ff:fe3e:9aa3/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcacece83349e2@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:9f:e0:c5:23:fb brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::549f:e0ff:fec5:23fb/64 scope link 
       valid_lft forever preferred_lft forever
