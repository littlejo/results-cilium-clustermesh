KEY             VALUE
AgentLiveness   1684643299915
UTimeOffset     3379443207031250
