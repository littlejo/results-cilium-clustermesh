{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:53.080Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.130.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:53.080Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.138.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:53.080Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:57.294Z",
  "value": "id=193   sec_id=7585810 flags=0x0000 ifindex=12  mac=26:76:29:E4:2C:5E nodemac=26:E8:F8:94:1D:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:57.305Z",
  "value": "id=643   sec_id=7585810 flags=0x0000 ifindex=14  mac=AE:CC:7E:F8:1A:75 nodemac=C2:D3:B2:3E:9A:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:57.346Z",
  "value": "id=2671  sec_id=4     flags=0x0000 ifindex=10  mac=EA:2B:19:D3:AA:95 nodemac=1A:A2:48:EC:30:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:57.399Z",
  "value": "id=193   sec_id=7585810 flags=0x0000 ifindex=12  mac=26:76:29:E4:2C:5E nodemac=26:E8:F8:94:1D:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:57.510Z",
  "value": "id=643   sec_id=7585810 flags=0x0000 ifindex=14  mac=AE:CC:7E:F8:1A:75 nodemac=C2:D3:B2:3E:9A:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:54.931Z",
  "value": "id=193   sec_id=7585810 flags=0x0000 ifindex=12  mac=26:76:29:E4:2C:5E nodemac=26:E8:F8:94:1D:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:54.931Z",
  "value": "id=643   sec_id=7585810 flags=0x0000 ifindex=14  mac=AE:CC:7E:F8:1A:75 nodemac=C2:D3:B2:3E:9A:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:54.931Z",
  "value": "id=2671  sec_id=4     flags=0x0000 ifindex=10  mac=EA:2B:19:D3:AA:95 nodemac=1A:A2:48:EC:30:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:54.960Z",
  "value": "id=2298  sec_id=7575767 flags=0x0000 ifindex=16  mac=52:6C:A2:BC:CD:6E nodemac=D6:E2:A7:45:62:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:54.960Z",
  "value": "id=2298  sec_id=7575767 flags=0x0000 ifindex=16  mac=52:6C:A2:BC:CD:6E nodemac=D6:E2:A7:45:62:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:55.931Z",
  "value": "id=2298  sec_id=7575767 flags=0x0000 ifindex=16  mac=52:6C:A2:BC:CD:6E nodemac=D6:E2:A7:45:62:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:55.931Z",
  "value": "id=193   sec_id=7585810 flags=0x0000 ifindex=12  mac=26:76:29:E4:2C:5E nodemac=26:E8:F8:94:1D:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:55.932Z",
  "value": "id=643   sec_id=7585810 flags=0x0000 ifindex=14  mac=AE:CC:7E:F8:1A:75 nodemac=C2:D3:B2:3E:9A:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:55.932Z",
  "value": "id=2671  sec_id=4     flags=0x0000 ifindex=10  mac=EA:2B:19:D3:AA:95 nodemac=1A:A2:48:EC:30:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.839Z",
  "value": "id=554   sec_id=7575767 flags=0x0000 ifindex=18  mac=4A:75:14:7F:9F:62 nodemac=56:9F:E0:C5:23:FB"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.230.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.305Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.872Z",
  "value": "id=193   sec_id=7585810 flags=0x0000 ifindex=12  mac=26:76:29:E4:2C:5E nodemac=26:E8:F8:94:1D:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.873Z",
  "value": "id=643   sec_id=7585810 flags=0x0000 ifindex=14  mac=AE:CC:7E:F8:1A:75 nodemac=C2:D3:B2:3E:9A:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.873Z",
  "value": "id=2671  sec_id=4     flags=0x0000 ifindex=10  mac=EA:2B:19:D3:AA:95 nodemac=1A:A2:48:EC:30:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.873Z",
  "value": "id=554   sec_id=7575767 flags=0x0000 ifindex=18  mac=4A:75:14:7F:9F:62 nodemac=56:9F:E0:C5:23:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.876Z",
  "value": "id=554   sec_id=7575767 flags=0x0000 ifindex=18  mac=4A:75:14:7F:9F:62 nodemac=56:9F:E0:C5:23:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.881Z",
  "value": "id=193   sec_id=7585810 flags=0x0000 ifindex=12  mac=26:76:29:E4:2C:5E nodemac=26:E8:F8:94:1D:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.881Z",
  "value": "id=643   sec_id=7585810 flags=0x0000 ifindex=14  mac=AE:CC:7E:F8:1A:75 nodemac=C2:D3:B2:3E:9A:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.882Z",
  "value": "id=2671  sec_id=4     flags=0x0000 ifindex=10  mac=EA:2B:19:D3:AA:95 nodemac=1A:A2:48:EC:30:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.872Z",
  "value": "id=193   sec_id=7585810 flags=0x0000 ifindex=12  mac=26:76:29:E4:2C:5E nodemac=26:E8:F8:94:1D:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.873Z",
  "value": "id=554   sec_id=7575767 flags=0x0000 ifindex=18  mac=4A:75:14:7F:9F:62 nodemac=56:9F:E0:C5:23:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.873Z",
  "value": "id=643   sec_id=7585810 flags=0x0000 ifindex=14  mac=AE:CC:7E:F8:1A:75 nodemac=C2:D3:B2:3E:9A:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.873Z",
  "value": "id=2671  sec_id=4     flags=0x0000 ifindex=10  mac=EA:2B:19:D3:AA:95 nodemac=1A:A2:48:EC:30:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.873Z",
  "value": "id=554   sec_id=7575767 flags=0x0000 ifindex=18  mac=4A:75:14:7F:9F:62 nodemac=56:9F:E0:C5:23:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.873Z",
  "value": "id=2671  sec_id=4     flags=0x0000 ifindex=10  mac=EA:2B:19:D3:AA:95 nodemac=1A:A2:48:EC:30:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.874Z",
  "value": "id=193   sec_id=7585810 flags=0x0000 ifindex=12  mac=26:76:29:E4:2C:5E nodemac=26:E8:F8:94:1D:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.230.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.874Z",
  "value": "id=643   sec_id=7585810 flags=0x0000 ifindex=14  mac=AE:CC:7E:F8:1A:75 nodemac=C2:D3:B2:3E:9A:A3"
}

