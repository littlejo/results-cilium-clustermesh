REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35434     2804569     677    bpf_overlay.c
Interface                 INGRESS     624085    128780965   1132   bpf_host.c
Success                   EGRESS      15337     1202448     1694   bpf_host.c
Success                   EGRESS      260550    33092126    1308   bpf_lxc.c
Success                   EGRESS      34824     2759617     53     encap.h
Success                   INGRESS     302717    33955722    86     l3.h
Success                   INGRESS     323464    35601819    235    trace.h
Unsupported L3 protocol   EGRESS      38        2796        1492   bpf_lxc.c
