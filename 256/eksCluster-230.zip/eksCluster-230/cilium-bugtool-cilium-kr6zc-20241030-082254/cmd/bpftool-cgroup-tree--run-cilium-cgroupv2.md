CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d54a5d4_bf07_47db_9cc4_7c01293a76f0.slice/cri-containerd-d1447d6cc80d70701fae3ccbe56e2e4caf31175793f5f35f11b653a8e7c315ea.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d54a5d4_bf07_47db_9cc4_7c01293a76f0.slice/cri-containerd-880e1bcdf43b3d73face72a21cd5cc709246eea2c7c9947258bf63922cda96b3.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1da9327_b335_479c_9754_7765b268ba73.slice/cri-containerd-0e68ecb751a387abe9ea03713c277b82a0be6bd92ae14456989a9d85f1e5001d.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1da9327_b335_479c_9754_7765b268ba73.slice/cri-containerd-a33e27981c6c8bd339d97e20f5e97f498546f9e9d05bd794daf8948946e73781.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod572ed862_39f4_4c0a_91aa_0abf08905da2.slice/cri-containerd-c9d07c0d9ffefeff418730d1b827bef062abde601d0a3e309f57b1a26a02c7b9.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod572ed862_39f4_4c0a_91aa_0abf08905da2.slice/cri-containerd-4e3fe2f5ab165f02fd8a6f5f85fbbc41e8ce8ab58b100d4529452c9abf35b8c6.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeae2b01c_c3d2_4db9_890a_9e98108cbb7d.slice/cri-containerd-67f9695153cf09d6c14b3414de632432734e85d38c8c69519b0312695ca85a95.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeae2b01c_c3d2_4db9_890a_9e98108cbb7d.slice/cri-containerd-a994930db631a6c0b0c34fcfc278bfb8312b6991f959d4915570a49667552deb.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab8c9b2f_4e55_4e7b_b1a4_057a98220e07.slice/cri-containerd-6b4eb5b732600b5629bc1d8818916c6744b15d334ea288c3b18fb5bd219fa013.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab8c9b2f_4e55_4e7b_b1a4_057a98220e07.slice/cri-containerd-cd7f84176cfe9a2e87ba4fa0b1cd8bea37e3cb0f68b068344103ad62f1384136.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab8c9b2f_4e55_4e7b_b1a4_057a98220e07.slice/cri-containerd-8bc75f80b02adc3d305cdcdb1d6ea9cc060ccaee5f542eecec2ed19359202816.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab8c9b2f_4e55_4e7b_b1a4_057a98220e07.slice/cri-containerd-27851b3624c0c48490b3ca1b8c9f365ff6baaf918eb40481991daca3aa754d28.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3c01e85e_8386_4f65_a09c_baf3925d9774.slice/cri-containerd-815a8982ef3bf3b39bbb4f8c26d12ce754947024619fbe3c46ae1e837dae52c6.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3c01e85e_8386_4f65_a09c_baf3925d9774.slice/cri-containerd-ffcee1f50d3e7fa305d6cda4d5a4f46cf619787be414e2c4fd8954a9a0837bb1.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2acac8c8_caf3_42e6_b436_b948bad948af.slice/cri-containerd-66723b036c93b6559f391bc27d6d6d9916930daa7d3a6c4eb129c69d71df1416.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2acac8c8_caf3_42e6_b436_b948bad948af.slice/cri-containerd-16743725527e1b85c7772dc7910df1fa1cb588c4479b6c78739daa743d1d86da.scope
    91       cgroup_device   multi                                          
