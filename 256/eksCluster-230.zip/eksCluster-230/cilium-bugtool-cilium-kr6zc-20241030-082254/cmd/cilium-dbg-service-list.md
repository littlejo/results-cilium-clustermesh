ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.128.249:443 (active)   
                                          2 => 172.31.249.219:443 (active)   
2    10.100.80.229:443     ClusterIP      1 => 172.31.138.46:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.230.0.185:53 (active)      
                                          2 => 10.230.0.159:53 (active)      
4    10.100.0.10:9153      ClusterIP      1 => 10.230.0.185:9153 (active)    
                                          2 => 10.230.0.159:9153 (active)    
5    10.100.127.142:2379   ClusterIP      1 => 10.230.0.207:2379 (active)    
