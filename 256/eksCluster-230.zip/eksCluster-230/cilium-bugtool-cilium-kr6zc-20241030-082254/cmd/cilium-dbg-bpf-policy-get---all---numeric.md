Endpoint ID: 193
Path: /sys/fs/bpf/tc/globals/cilium_policy_00193

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    110161   1258      0        
Allow    Egress      0          ANY          NONE         disabled    16022    173       0        


Endpoint ID: 464
Path: /sys/fs/bpf/tc/globals/cilium_policy_00464

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 554
Path: /sys/fs/bpf/tc/globals/cilium_policy_00554

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11413060   112079    0        
Allow    Ingress     1          ANY          NONE         disabled    9321248    97668     0        
Allow    Egress      0          ANY          NONE         disabled    11243897   111800    0        


Endpoint ID: 643
Path: /sys/fs/bpf/tc/globals/cilium_policy_00643

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    110359   1261      0        
Allow    Egress      0          ANY          NONE         disabled    15352    165       0        


Endpoint ID: 2671
Path: /sys/fs/bpf/tc/globals/cilium_policy_02671

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1649051   20786     0        
Allow    Ingress     1          ANY          NONE         disabled    16744     195       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


