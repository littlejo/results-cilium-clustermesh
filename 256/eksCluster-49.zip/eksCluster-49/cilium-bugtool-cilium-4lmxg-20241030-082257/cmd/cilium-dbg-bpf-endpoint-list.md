IP ADDRESS         LOCAL ENDPOINT INFO
10.49.0.77:0       id=968   sec_id=4     flags=0x0000 ifindex=10  mac=02:72:69:5E:EB:1A nodemac=9E:82:62:28:F5:03     
172.31.216.105:0   (localhost)                                                                                        
10.49.0.63:0       id=2139  sec_id=1660249 flags=0x0000 ifindex=12  mac=6A:C3:32:EB:37:DF nodemac=32:85:C4:6D:4E:A6   
10.49.0.181:0      id=3036  sec_id=1642853 flags=0x0000 ifindex=18  mac=56:64:46:14:60:DB nodemac=02:98:6E:4B:06:B8   
10.49.0.249:0      (localhost)                                                                                        
172.31.252.31:0    (localhost)                                                                                        
10.49.0.211:0      id=246   sec_id=1660249 flags=0x0000 ifindex=14  mac=B2:ED:A5:1E:0F:E8 nodemac=36:42:73:58:DB:CE   
