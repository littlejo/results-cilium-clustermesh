key: f6 00 00 00  value: 05 02 00 00
key: c8 03 00 00  value: 1e 02 00 00
key: 5b 08 00 00  value: 11 02 00 00
key: dc 0b 00 00  value: 7c 02 00 00
Found 4 elements
