 08:22:59 up 34 min,  0 users,  load average: 0.19, 0.27, 0.21
