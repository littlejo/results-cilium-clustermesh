CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda8adcfcf_8783_4d63_b3e1_4738e169e04b.slice/cri-containerd-068df5c1838c6b791dd413dbd65353af750b4d0ab4d20309c6e166d28411aa2e.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda8adcfcf_8783_4d63_b3e1_4738e169e04b.slice/cri-containerd-07f3d92eed3be189316ce5aab91293dbb5807a4a3fc195ef132fa307fdd641fd.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75b5c308_2758_4ec0_950a_a689f11c3e3e.slice/cri-containerd-699aadac62dce45714d1896f046a52065bdc744fd43c31a3191141bbd8984eca.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75b5c308_2758_4ec0_950a_a689f11c3e3e.slice/cri-containerd-bf8177db9826984d0b54a1bad1953b6a735d9a2f4a4d560c09466617d27efc32.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf2d17265_93f2_4a5f_a471_ab48333320c1.slice/cri-containerd-d15377eeedbb90e5a9183fb7432fdfb550700393541c23031dd50bc25beba112.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf2d17265_93f2_4a5f_a471_ab48333320c1.slice/cri-containerd-c0723bb014858f03ed23829cd95cc493538c599b2146c3d5448022f2e7c9ce5f.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8b291bf0_33e6_4e53_98a0_6123b2020aac.slice/cri-containerd-e8c8d6e9f27723e914b845217541b7a5bf41ff109a3c11f87b0a5480e7bd166a.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8b291bf0_33e6_4e53_98a0_6123b2020aac.slice/cri-containerd-9ea56ee1eea3d50574485ca60dd26e192b0173d49f0ef01d12da6a746a2ecb7e.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb849bef4_d73f_4c45_b353_fcbaf0f90736.slice/cri-containerd-c2dab84384daa4eff604d7252f61f5d4de2f7e05e2cd3906928a74103c891b35.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb849bef4_d73f_4c45_b353_fcbaf0f90736.slice/cri-containerd-74743a0197fdd87121443ec391ce538ecec3cfe1629f65b25031ea52ee203a22.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb831099e_d7f5_4a15_9bc4_4455a4f11315.slice/cri-containerd-04ffd43f48145934efd1cdf3a3347883112391789a985067b469517aecd02aa8.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb831099e_d7f5_4a15_9bc4_4455a4f11315.slice/cri-containerd-6b08f9a556b08510e4ac73b79c8adfafb4218e304c206c14c5f567e4c36d33e4.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9970615_0a0a_468f_a3b0_810f0147f170.slice/cri-containerd-958af94115b82149e9a697cecfa44a1a214ed54452a6d59f463e1834aaa32f60.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9970615_0a0a_468f_a3b0_810f0147f170.slice/cri-containerd-a043b16351762e5bc6c24ce627db3ada3c3c6c826b2ffdaacfd045367e8a240f.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9970615_0a0a_468f_a3b0_810f0147f170.slice/cri-containerd-83a80818d0b721af21bab7d1ec6793676964947b7b87c630450d0794a9cc2ba5.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9970615_0a0a_468f_a3b0_810f0147f170.slice/cri-containerd-c294bc3ae0593ae99e832cfb0bbf86c663779276e847c76f1152366f1bdc6456.scope
    664      cgroup_device   multi                                          
