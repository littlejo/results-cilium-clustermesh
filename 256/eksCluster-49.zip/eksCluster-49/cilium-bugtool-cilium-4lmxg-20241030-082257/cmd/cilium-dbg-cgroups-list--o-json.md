[
  {
    "containers": [
      {
        "cgroup-id": 9268,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9970615_0a0a_468f_a3b0_810f0147f170.slice/cri-containerd-958af94115b82149e9a697cecfa44a1a214ed54452a6d59f463e1834aaa32f60.scope"
      },
      {
        "cgroup-id": 9184,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9970615_0a0a_468f_a3b0_810f0147f170.slice/cri-containerd-a043b16351762e5bc6c24ce627db3ada3c3c6c826b2ffdaacfd045367e8a240f.scope"
      },
      {
        "cgroup-id": 9352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9970615_0a0a_468f_a3b0_810f0147f170.slice/cri-containerd-c294bc3ae0593ae99e832cfb0bbf86c663779276e847c76f1152366f1bdc6456.scope"
      }
    ],
    "ips": [
      "10.49.0.181"
    ],
    "name": "clustermesh-apiserver-54dc545f6-ddvm8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf2d17265_93f2_4a5f_a471_ab48333320c1.slice/cri-containerd-d15377eeedbb90e5a9183fb7432fdfb550700393541c23031dd50bc25beba112.scope"
      }
    ],
    "ips": [
      "10.49.0.63"
    ],
    "name": "coredns-cc6ccd49c-lrh6b",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda8adcfcf_8783_4d63_b3e1_4738e169e04b.slice/cri-containerd-07f3d92eed3be189316ce5aab91293dbb5807a4a3fc195ef132fa307fdd641fd.scope"
      }
    ],
    "ips": [
      "10.49.0.211"
    ],
    "name": "coredns-cc6ccd49c-2h82t",
    "namespace": "kube-system"
  }
]

