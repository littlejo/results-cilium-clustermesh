REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38223     3024140     677    bpf_overlay.c
Interface                 INGRESS     683181    137231296   1132   bpf_host.c
Success                   EGRESS      17829     1406400     1694   bpf_host.c
Success                   EGRESS      293875    36062003    1308   bpf_lxc.c
Success                   EGRESS      39382     3109196     53     encap.h
Success                   INGRESS     336142    38197367    86     l3.h
Success                   INGRESS     357187    39859153    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
