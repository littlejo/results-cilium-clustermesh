KEY             VALUE
AgentLiveness   2076348338640
UTimeOffset     3379442449218750
