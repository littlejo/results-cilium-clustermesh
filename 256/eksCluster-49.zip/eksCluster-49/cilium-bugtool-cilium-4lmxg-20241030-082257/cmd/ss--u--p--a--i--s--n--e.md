Total: 672
TCP:   1871 (estab 434, closed 1418, orphaned 0, timewait 572)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  453       442       11       
INET	  463       448       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:42495      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:33549 sk:3f8 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.216.105%ens5:68         0.0.0.0:*    uid:192 ino:72227 sk:3f9 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:33637 sk:3fa cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15453 sk:3fb cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:33636 sk:3fc cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15454 sk:3fd cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::8d4:cbff:fe94:b7c9]%ens5:546           [::]:*    uid:192 ino:15661 sk:3fe cgroup:unreachable:c4e v6only:1 <->                   
