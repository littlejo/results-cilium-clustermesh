USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         707  0.0  0.2 1240432 16420 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         723  0.0  0.0   6408  1644 ?        R    08:22   0:00  \_ ps auxfw
root         724  0.0  0.0      4     4 ?        R    08:22   0:00  \_ cat /proc/net/xfrm_stat
root         694  0.0  0.0 1228744 4044 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         682  0.0  0.0   2208   796 ?        Ss   08:22   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         688 29.0  0.2 1244596 21460 ?       Sl   08:22   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root         672  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  4.1  4.8 1606080 390688 ?      Ssl  07:57   1:04 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.0 1229744 7280 ?        Sl   07:57   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
