alloc: 185.23MB (194227160 bytes)
total-alloc: 2.39GB (2568662656 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 65796780
frees: 63660753
heap-alloc: 185.23MB (194227160 bytes)
heap-sys: 246.86MB (258850816 bytes)
heap-idle: 39.88MB (41811968 bytes)
heap-in-use: 206.98MB (217038848 bytes)
heap-released: 2.91MB (3047424 bytes)
heap-objects: 2136027
stack-in-use: 65.09MB (68255744 bytes)
stack-sys: 65.09MB (68255744 bytes)
stack-mspan-inuse: 3.50MB (3668640 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 950.18KB (972985 bytes)
gc-sys: 6.05MB (6346360 bytes)
next-gc: when heap-alloc >= 214.77MB (225198056 bytes)
last-gc: 2024-10-30 08:23:00.546161946 +0000 UTC
gc-pause-total: 14.389899ms
gc-pause: 444446
gc-pause-end: 1730276580546161946
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.0004295020280248815
enable-gc: true
debug-gc: false
