{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:16.788Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.216.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:16.789Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.252.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:16.789Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:21.418Z",
  "value": "id=2139  sec_id=1660249 flags=0x0000 ifindex=12  mac=6A:C3:32:EB:37:DF nodemac=32:85:C4:6D:4E:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:21.427Z",
  "value": "id=968   sec_id=4     flags=0x0000 ifindex=10  mac=02:72:69:5E:EB:1A nodemac=9E:82:62:28:F5:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:21.472Z",
  "value": "id=246   sec_id=1660249 flags=0x0000 ifindex=14  mac=B2:ED:A5:1E:0F:E8 nodemac=36:42:73:58:DB:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:21.528Z",
  "value": "id=2139  sec_id=1660249 flags=0x0000 ifindex=12  mac=6A:C3:32:EB:37:DF nodemac=32:85:C4:6D:4E:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:21.628Z",
  "value": "id=968   sec_id=4     flags=0x0000 ifindex=10  mac=02:72:69:5E:EB:1A nodemac=9E:82:62:28:F5:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:10.327Z",
  "value": "id=968   sec_id=4     flags=0x0000 ifindex=10  mac=02:72:69:5E:EB:1A nodemac=9E:82:62:28:F5:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:10.327Z",
  "value": "id=2139  sec_id=1660249 flags=0x0000 ifindex=12  mac=6A:C3:32:EB:37:DF nodemac=32:85:C4:6D:4E:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:10.328Z",
  "value": "id=246   sec_id=1660249 flags=0x0000 ifindex=14  mac=B2:ED:A5:1E:0F:E8 nodemac=36:42:73:58:DB:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:10.364Z",
  "value": "id=132   sec_id=1642853 flags=0x0000 ifindex=16  mac=DE:66:85:3C:35:3C nodemac=A2:AA:18:FB:AE:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:11.327Z",
  "value": "id=132   sec_id=1642853 flags=0x0000 ifindex=16  mac=DE:66:85:3C:35:3C nodemac=A2:AA:18:FB:AE:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:11.327Z",
  "value": "id=2139  sec_id=1660249 flags=0x0000 ifindex=12  mac=6A:C3:32:EB:37:DF nodemac=32:85:C4:6D:4E:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:11.327Z",
  "value": "id=968   sec_id=4     flags=0x0000 ifindex=10  mac=02:72:69:5E:EB:1A nodemac=9E:82:62:28:F5:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:11.328Z",
  "value": "id=246   sec_id=1660249 flags=0x0000 ifindex=14  mac=B2:ED:A5:1E:0F:E8 nodemac=36:42:73:58:DB:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:29.894Z",
  "value": "id=3036  sec_id=1642853 flags=0x0000 ifindex=18  mac=56:64:46:14:60:DB nodemac=02:98:6E:4B:06:B8"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.49.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.256Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:14.547Z",
  "value": "id=3036  sec_id=1642853 flags=0x0000 ifindex=18  mac=56:64:46:14:60:DB nodemac=02:98:6E:4B:06:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:14.548Z",
  "value": "id=968   sec_id=4     flags=0x0000 ifindex=10  mac=02:72:69:5E:EB:1A nodemac=9E:82:62:28:F5:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:14.548Z",
  "value": "id=2139  sec_id=1660249 flags=0x0000 ifindex=12  mac=6A:C3:32:EB:37:DF nodemac=32:85:C4:6D:4E:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:14.549Z",
  "value": "id=246   sec_id=1660249 flags=0x0000 ifindex=14  mac=B2:ED:A5:1E:0F:E8 nodemac=36:42:73:58:DB:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:15.553Z",
  "value": "id=2139  sec_id=1660249 flags=0x0000 ifindex=12  mac=6A:C3:32:EB:37:DF nodemac=32:85:C4:6D:4E:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:15.569Z",
  "value": "id=246   sec_id=1660249 flags=0x0000 ifindex=14  mac=B2:ED:A5:1E:0F:E8 nodemac=36:42:73:58:DB:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:15.569Z",
  "value": "id=3036  sec_id=1642853 flags=0x0000 ifindex=18  mac=56:64:46:14:60:DB nodemac=02:98:6E:4B:06:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:15.570Z",
  "value": "id=968   sec_id=4     flags=0x0000 ifindex=10  mac=02:72:69:5E:EB:1A nodemac=9E:82:62:28:F5:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:16.549Z",
  "value": "id=246   sec_id=1660249 flags=0x0000 ifindex=14  mac=B2:ED:A5:1E:0F:E8 nodemac=36:42:73:58:DB:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:16.550Z",
  "value": "id=968   sec_id=4     flags=0x0000 ifindex=10  mac=02:72:69:5E:EB:1A nodemac=9E:82:62:28:F5:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:16.550Z",
  "value": "id=3036  sec_id=1642853 flags=0x0000 ifindex=18  mac=56:64:46:14:60:DB nodemac=02:98:6E:4B:06:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:16.550Z",
  "value": "id=2139  sec_id=1660249 flags=0x0000 ifindex=12  mac=6A:C3:32:EB:37:DF nodemac=32:85:C4:6D:4E:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:17.550Z",
  "value": "id=968   sec_id=4     flags=0x0000 ifindex=10  mac=02:72:69:5E:EB:1A nodemac=9E:82:62:28:F5:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:17.550Z",
  "value": "id=3036  sec_id=1642853 flags=0x0000 ifindex=18  mac=56:64:46:14:60:DB nodemac=02:98:6E:4B:06:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:17.551Z",
  "value": "id=2139  sec_id=1660249 flags=0x0000 ifindex=12  mac=6A:C3:32:EB:37:DF nodemac=32:85:C4:6D:4E:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.49.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:17.551Z",
  "value": "id=246   sec_id=1660249 flags=0x0000 ifindex=14  mac=B2:ED:A5:1E:0F:E8 nodemac=36:42:73:58:DB:CE"
}

