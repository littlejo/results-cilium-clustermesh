1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:d4:cb:94:b7:c9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.216.105/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3366sec preferred_lft 3366sec
    inet6 fe80::8d4:cbff:fe94:b7c9/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:a1:d5:70:73:bf brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.252.31/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8a1:d5ff:fe70:73bf/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:48:83:f5:0d:1d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4c48:83ff:fef5:d1d/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:28:89:e6:20:95 brd ff:ff:ff:ff:ff:ff
    inet 10.49.0.249/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::8828:89ff:fee6:2095/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 36:c1:bd:35:7e:88 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::34c1:bdff:fe35:7e88/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:82:62:28:f5:03 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::9c82:62ff:fe28:f503/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc90d6720bff0a@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:85:c4:6d:4e:a6 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::3085:c4ff:fe6d:4ea6/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcbe11ac26cce5@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:42:73:58:db:ce brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::3442:73ff:fe58:dbce/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc3cf4d61d1a39@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:98:6e:4b:06:b8 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::98:6eff:fe4b:6b8/64 scope link 
       valid_lft forever preferred_lft forever
