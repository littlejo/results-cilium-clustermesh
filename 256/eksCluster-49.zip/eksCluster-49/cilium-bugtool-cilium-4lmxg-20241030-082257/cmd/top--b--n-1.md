top - 08:22:59 up 34 min,  0 users,  load average: 0.19, 0.27, 0.21
Tasks:   9 total,   2 running,   6 sleeping,   0 stopped,   1 zombie
%Cpu(s): 60.0 us, 36.7 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4458.3 free,   1208.3 used,   2147.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6420.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    688 root      20   0 1244596  22388  14648 S  40.0   0.3   0:00.41 hubble
      1 root      20   0 1606080 390688  78204 S   6.7   4.9   1:04.44 cilium-+
    393 root      20   0 1229744   7280   3052 S   0.0   0.1   0:01.20 cilium-+
    672 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    682 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    694 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    707 root      20   0 1240432  16420  11024 R   0.0   0.2   0:00.02 cilium-+
    735 root      20   0    6576   2420   2096 R   0.0   0.0   0:00.00 top
    751 root      20   0       0      0      0 Z   0.0   0.0   0:00.00 ip
