Endpoint ID: 246
Path: /sys/fs/bpf/tc/globals/cilium_policy_00246

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    149832   1720      0        
Allow    Egress      0          ANY          NONE         disabled    18704    207       0        


Endpoint ID: 968
Path: /sys/fs/bpf/tc/globals/cilium_policy_00968

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1663937   21073     0        
Allow    Ingress     1          ANY          NONE         disabled    23385     277       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1772
Path: /sys/fs/bpf/tc/globals/cilium_policy_01772

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2139
Path: /sys/fs/bpf/tc/globals/cilium_policy_02139

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    148863   1710      0        
Allow    Egress      0          ANY          NONE         disabled    19485    216       0        


Endpoint ID: 3036
Path: /sys/fs/bpf/tc/globals/cilium_policy_03036

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11527022   116272    0        
Allow    Ingress     1          ANY          NONE         disabled    11247139   119043    0        
Allow    Egress      0          ANY          NONE         disabled    15233515   148508    0        


