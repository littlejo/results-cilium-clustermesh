Endpoint ID: 472
Path: /sys/fs/bpf/tc/globals/cilium_policy_00472

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    156229   1785      0        
Allow    Egress      0          ANY          NONE         disabled    20880    233       0        


Endpoint ID: 609
Path: /sys/fs/bpf/tc/globals/cilium_policy_00609

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11638474   116684    0        
Allow    Ingress     1          ANY          NONE         disabled    10793040   114236    0        
Allow    Egress      0          ANY          NONE         disabled    13873224   136109    0        


Endpoint ID: 814
Path: /sys/fs/bpf/tc/globals/cilium_policy_00814

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1003
Path: /sys/fs/bpf/tc/globals/cilium_policy_01003

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1657951   20991     0        
Allow    Ingress     1          ANY          NONE         disabled    23788     279       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1555
Path: /sys/fs/bpf/tc/globals/cilium_policy_01555

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    156628   1796      0        
Allow    Egress      0          ANY          NONE         disabled    20886    234       0        


