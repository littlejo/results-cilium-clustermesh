alloc: 116.84MB (122513936 bytes)
total-alloc: 2.36GB (2539238368 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 65227949
frees: 64220748
heap-alloc: 116.84MB (122513936 bytes)
heap-sys: 247.54MB (259563520 bytes)
heap-idle: 84.09MB (88178688 bytes)
heap-in-use: 163.45MB (171384832 bytes)
heap-released: 2.99MB (3137536 bytes)
heap-objects: 1007201
stack-in-use: 64.44MB (67567616 bytes)
stack-sys: 64.44MB (67567616 bytes)
stack-mspan-inuse: 2.77MB (2899840 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.02MB (1072769 bytes)
gc-sys: 5.98MB (6270320 bytes)
next-gc: when heap-alloc >= 215.94MB (226424504 bytes)
last-gc: 2024-10-30 08:23:14.058534589 +0000 UTC
gc-pause-total: 11.076742ms
gc-pause: 103214
gc-pause-end: 1730276594058534589
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0004113748718294163
enable-gc: true
debug-gc: false
