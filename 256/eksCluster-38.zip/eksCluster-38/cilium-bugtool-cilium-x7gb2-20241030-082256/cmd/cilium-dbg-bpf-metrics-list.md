REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37991     3008903     677    bpf_overlay.c
Interface                 INGRESS     663499    134780383   1132   bpf_host.c
Success                   EGRESS      17703     1399145     1694   bpf_host.c
Success                   EGRESS      283349    35175095    1308   bpf_lxc.c
Success                   EGRESS      39000     3085264     53     encap.h
Success                   INGRESS     327133    36879147    86     l3.h
Success                   INGRESS     348072    38532951    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
