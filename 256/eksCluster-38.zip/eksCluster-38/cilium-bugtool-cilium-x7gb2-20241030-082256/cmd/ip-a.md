1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:87:96:50:73:c5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.189.138/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3317sec preferred_lft 3317sec
    inet6 fe80::487:96ff:fe50:73c5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a5:90:4a:b6:19 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.144.190/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4a5:90ff:fe4a:b619/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:4b:2e:56:2a:c5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e44b:2eff:fe56:2ac5/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:d2:9f:a4:6e:cc brd ff:ff:ff:ff:ff:ff
    inet 10.38.0.10/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b0d2:9fff:fea4:6ecc/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 5a:1a:b4:28:16:1b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::581a:b4ff:fe28:161b/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:9d:e0:cf:35:6f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::449d:e0ff:fecf:356f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc6b1dfdf8cb66@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:35:49:fc:5b:3f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::9c35:49ff:fefc:5b3f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc6b9a55458a90@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:9f:b8:fb:5d:bb brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::209f:b8ff:fefb:5dbb/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb5ade6118b0f@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:3d:13:13:ee:95 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::143d:13ff:fe13:ee95/64 scope link 
       valid_lft forever preferred_lft forever
