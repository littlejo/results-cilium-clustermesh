ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.181.100:443 (active)    
                                         2 => 172.31.255.103:443 (active)    
2    10.100.217.169:443   ClusterIP      1 => 172.31.189.138:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.38.0.151:53 (active)        
                                         2 => 10.38.0.26:53 (active)         
4    10.100.0.10:9153     ClusterIP      1 => 10.38.0.151:9153 (active)      
                                         2 => 10.38.0.26:9153 (active)       
5    10.100.84.120:2379   ClusterIP      1 => 10.38.0.152:2379 (active)      
