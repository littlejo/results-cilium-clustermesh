{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:47.085Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.144.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:47.085Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.189.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:47.085Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:50.339Z",
  "value": "id=472   sec_id=1310493 flags=0x0000 ifindex=12  mac=2A:90:BA:4C:9D:2D nodemac=9E:35:49:FC:5B:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:53.480Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=52:66:EE:B7:BC:16 nodemac=46:9D:E0:CF:35:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:53.484Z",
  "value": "id=1555  sec_id=1310493 flags=0x0000 ifindex=14  mac=1E:34:E6:17:E8:2D nodemac=22:9F:B8:FB:5D:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:53.540Z",
  "value": "id=472   sec_id=1310493 flags=0x0000 ifindex=12  mac=2A:90:BA:4C:9D:2D nodemac=9E:35:49:FC:5B:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:53.581Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=52:66:EE:B7:BC:16 nodemac=46:9D:E0:CF:35:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:53.635Z",
  "value": "id=1555  sec_id=1310493 flags=0x0000 ifindex=14  mac=1E:34:E6:17:E8:2D nodemac=22:9F:B8:FB:5D:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:43.025Z",
  "value": "id=1555  sec_id=1310493 flags=0x0000 ifindex=14  mac=1E:34:E6:17:E8:2D nodemac=22:9F:B8:FB:5D:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:43.025Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=52:66:EE:B7:BC:16 nodemac=46:9D:E0:CF:35:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:43.025Z",
  "value": "id=472   sec_id=1310493 flags=0x0000 ifindex=12  mac=2A:90:BA:4C:9D:2D nodemac=9E:35:49:FC:5B:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:43.058Z",
  "value": "id=3360  sec_id=1308366 flags=0x0000 ifindex=16  mac=B6:C8:F0:99:D1:97 nodemac=7E:FD:2C:9A:C0:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.025Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=52:66:EE:B7:BC:16 nodemac=46:9D:E0:CF:35:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.025Z",
  "value": "id=1555  sec_id=1310493 flags=0x0000 ifindex=14  mac=1E:34:E6:17:E8:2D nodemac=22:9F:B8:FB:5D:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.025Z",
  "value": "id=3360  sec_id=1308366 flags=0x0000 ifindex=16  mac=B6:C8:F0:99:D1:97 nodemac=7E:FD:2C:9A:C0:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.025Z",
  "value": "id=472   sec_id=1310493 flags=0x0000 ifindex=12  mac=2A:90:BA:4C:9D:2D nodemac=9E:35:49:FC:5B:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.152Z",
  "value": "id=609   sec_id=1308366 flags=0x0000 ifindex=18  mac=A2:68:10:75:90:91 nodemac=16:3D:13:13:EE:95"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.38.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.596Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.419Z",
  "value": "id=472   sec_id=1310493 flags=0x0000 ifindex=12  mac=2A:90:BA:4C:9D:2D nodemac=9E:35:49:FC:5B:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.420Z",
  "value": "id=1555  sec_id=1310493 flags=0x0000 ifindex=14  mac=1E:34:E6:17:E8:2D nodemac=22:9F:B8:FB:5D:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.420Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=52:66:EE:B7:BC:16 nodemac=46:9D:E0:CF:35:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.421Z",
  "value": "id=609   sec_id=1308366 flags=0x0000 ifindex=18  mac=A2:68:10:75:90:91 nodemac=16:3D:13:13:EE:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:47.429Z",
  "value": "id=609   sec_id=1308366 flags=0x0000 ifindex=18  mac=A2:68:10:75:90:91 nodemac=16:3D:13:13:EE:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:47.432Z",
  "value": "id=472   sec_id=1310493 flags=0x0000 ifindex=12  mac=2A:90:BA:4C:9D:2D nodemac=9E:35:49:FC:5B:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:47.432Z",
  "value": "id=1555  sec_id=1310493 flags=0x0000 ifindex=14  mac=1E:34:E6:17:E8:2D nodemac=22:9F:B8:FB:5D:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:47.433Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=52:66:EE:B7:BC:16 nodemac=46:9D:E0:CF:35:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:48.419Z",
  "value": "id=472   sec_id=1310493 flags=0x0000 ifindex=12  mac=2A:90:BA:4C:9D:2D nodemac=9E:35:49:FC:5B:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:48.419Z",
  "value": "id=609   sec_id=1308366 flags=0x0000 ifindex=18  mac=A2:68:10:75:90:91 nodemac=16:3D:13:13:EE:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:48.420Z",
  "value": "id=1555  sec_id=1310493 flags=0x0000 ifindex=14  mac=1E:34:E6:17:E8:2D nodemac=22:9F:B8:FB:5D:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:48.420Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=52:66:EE:B7:BC:16 nodemac=46:9D:E0:CF:35:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.420Z",
  "value": "id=472   sec_id=1310493 flags=0x0000 ifindex=12  mac=2A:90:BA:4C:9D:2D nodemac=9E:35:49:FC:5B:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.420Z",
  "value": "id=609   sec_id=1308366 flags=0x0000 ifindex=18  mac=A2:68:10:75:90:91 nodemac=16:3D:13:13:EE:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.421Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=52:66:EE:B7:BC:16 nodemac=46:9D:E0:CF:35:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.421Z",
  "value": "id=1555  sec_id=1310493 flags=0x0000 ifindex=14  mac=1E:34:E6:17:E8:2D nodemac=22:9F:B8:FB:5D:BB"
}

