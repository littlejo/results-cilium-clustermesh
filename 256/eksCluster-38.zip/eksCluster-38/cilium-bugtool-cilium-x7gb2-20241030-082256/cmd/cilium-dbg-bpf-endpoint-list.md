IP ADDRESS         LOCAL ENDPOINT INFO
10.38.0.45:0       id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=52:66:EE:B7:BC:16 nodemac=46:9D:E0:CF:35:6F     
10.38.0.152:0      id=609   sec_id=1308366 flags=0x0000 ifindex=18  mac=A2:68:10:75:90:91 nodemac=16:3D:13:13:EE:95   
172.31.189.138:0   (localhost)                                                                                        
172.31.144.190:0   (localhost)                                                                                        
10.38.0.10:0       (localhost)                                                                                        
10.38.0.151:0      id=472   sec_id=1310493 flags=0x0000 ifindex=12  mac=2A:90:BA:4C:9D:2D nodemac=9E:35:49:FC:5B:3F   
10.38.0.26:0       id=1555  sec_id=1310493 flags=0x0000 ifindex=14  mac=1E:34:E6:17:E8:2D nodemac=22:9F:B8:FB:5D:BB   
