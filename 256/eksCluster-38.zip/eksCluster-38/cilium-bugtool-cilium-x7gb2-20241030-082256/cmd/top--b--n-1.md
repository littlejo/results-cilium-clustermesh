top - 08:22:58 up 34 min,  0 users,  load average: 0.33, 0.37, 0.27
Tasks:   9 total,   2 running,   6 sleeping,   0 stopped,   1 zombie
%Cpu(s): 43.3 us, 50.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   7814.2 total,   4459.8 free,   1208.9 used,   2145.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6420.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    740 root      20   0 1244340  22420  14324 S  46.7   0.3   0:00.16 hubble
      1 root      20   0 1606080 391684  78712 S  13.3   4.9   0:57.08 cilium-+
    722 root      20   0 1240432  15676  10896 S   6.7   0.2   0:00.03 cilium-+
    408 root      20   0 1229744   7908   3836 S   0.0   0.1   0:01.16 cilium-+
    689 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    731 root      20   0    2208    776    696 S   0.0   0.0   0:00.00 timeout
    775 root      20   0    6576   2412   2088 R   0.0   0.0   0:00.00 top
    781 root      20   0       0      0      0 Z   0.0   0.0   0:00.00 iptable+
    784 root      20   0    3852   1296   1136 R   0.0   0.0   0:00.00 bash
