key: d8 01 00 00  value: 0e 02 00 00
key: 61 02 00 00  value: 78 02 00 00
key: eb 03 00 00  value: 20 02 00 00
key: 13 06 00 00  value: 22 02 00 00
Found 4 elements
