markdown output at /tmp/cilium-bugtool-20241030-082257.652+0000-UTC-2734673075/cmd/cilium-debuginfo-20241030-082328.28+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082257.652+0000-UTC-2734673075/cmd/cilium-debuginfo-20241030-082328.28+0000-UTC.json
