Total: 656
TCP:   1840 (estab 419, closed 1402, orphaned 0, timewait 566)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  438       428       10       
INET	  448       434       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:46251      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:32824 sk:389 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.189.138%ens5:68         0.0.0.0:*    uid:192 ino:70176 sk:38a cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:32913 sk:38b cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15591 sk:38c cgroup:unreachable:f0c <->                                    
UNCONN 0      0      [fe80::487:96ff:fe50:73c5]%ens5:546           [::]:*    uid:192 ino:15298 sk:38d cgroup:unreachable:c4e v6only:1 <->                   
UNCONN 0      0                                 [::]:8472          [::]:*    ino:32912 sk:38e cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15592 sk:38f cgroup:unreachable:f0c v6only:1 <->                           
