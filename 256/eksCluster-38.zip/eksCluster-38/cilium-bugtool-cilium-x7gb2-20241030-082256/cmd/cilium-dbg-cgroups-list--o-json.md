[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod27a97393_8fa1_4b2f_9c3b_40464e2f9c4e.slice/cri-containerd-2b647ef7119647723e5a036f9818b0291e1d13cbc6f6323c776a1fcf46a18523.scope"
      }
    ],
    "ips": [
      "10.38.0.26"
    ],
    "name": "coredns-cc6ccd49c-x552m",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod415c5b7e_f115_40b2_b4e2_9c97f0e4995e.slice/cri-containerd-e8c713bade178f4b927aa0c8de53b92152a97ecbad4ee28a1c2c8c1407628d91.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod415c5b7e_f115_40b2_b4e2_9c97f0e4995e.slice/cri-containerd-a664560fadaac05ebbbc9813903e4b5a000a35c390bfea2cf37d9fb7a60fc841.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod415c5b7e_f115_40b2_b4e2_9c97f0e4995e.slice/cri-containerd-e7cb35c3b9f9061039bf846dad8241c84b7c02092afbe24737eb5c538ee6a091.scope"
      }
    ],
    "ips": [
      "10.38.0.152"
    ],
    "name": "clustermesh-apiserver-b4999ccd-rhzlt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7614,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a8c5f2a_5633_4188_8071_ab9f8563a067.slice/cri-containerd-f7d1bbfaa0ae3b1498b9e032ba23c2d45ee2b2744908271a59c105eac172703b.scope"
      }
    ],
    "ips": [
      "10.38.0.151"
    ],
    "name": "coredns-cc6ccd49c-szrg2",
    "namespace": "kube-system"
  }
]

