CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a8c5f2a_5633_4188_8071_ab9f8563a067.slice/cri-containerd-ced0c24bbf03879f936d10b736a2a18ed2acc82e8a8d2ce118e204e2590d4a5c.scope
    492      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a8c5f2a_5633_4188_8071_ab9f8563a067.slice/cri-containerd-f7d1bbfaa0ae3b1498b9e032ba23c2d45ee2b2744908271a59c105eac172703b.scope
    496      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8bb458b0_5554_4bd8_8b97_a0f27a481269.slice/cri-containerd-bac34d61a1f3523935d79e6982b1c557a85da4759f2267a9e8b83aebff188d16.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8bb458b0_5554_4bd8_8b97_a0f27a481269.slice/cri-containerd-c73a674ea9b717ee71409f3d1e514c7806de06c7ac6aa522782eb13a4539f52b.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod27a97393_8fa1_4b2f_9c3b_40464e2f9c4e.slice/cri-containerd-de4187a71faace0fd34c0934087637a8cc11642a844283ad9de1955bcd24e95b.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod27a97393_8fa1_4b2f_9c3b_40464e2f9c4e.slice/cri-containerd-2b647ef7119647723e5a036f9818b0291e1d13cbc6f6323c776a1fcf46a18523.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod48224551_c70b_4015_a871_d3d97adf6143.slice/cri-containerd-69da8ee66cf01b975d3b6560f0d443a90dcc4c38a8d9d02e347931c85319f9f3.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod48224551_c70b_4015_a871_d3d97adf6143.slice/cri-containerd-5c769b6f275811bf137960717ef623acf1eb72ee6a20959ab13b1fde1e4f5745.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod415c5b7e_f115_40b2_b4e2_9c97f0e4995e.slice/cri-containerd-05d98b78c7e5b94ad8b6afaee58f5896852b04092b42e6a39fe026af47089609.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod415c5b7e_f115_40b2_b4e2_9c97f0e4995e.slice/cri-containerd-e7cb35c3b9f9061039bf846dad8241c84b7c02092afbe24737eb5c538ee6a091.scope
    669      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod415c5b7e_f115_40b2_b4e2_9c97f0e4995e.slice/cri-containerd-e8c713bade178f4b927aa0c8de53b92152a97ecbad4ee28a1c2c8c1407628d91.scope
    665      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod415c5b7e_f115_40b2_b4e2_9c97f0e4995e.slice/cri-containerd-a664560fadaac05ebbbc9813903e4b5a000a35c390bfea2cf37d9fb7a60fc841.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c376d98_3b20_44cc_98f2_7f71503ced2c.slice/cri-containerd-d556ac84fa32743f7525522a114ba7e311c214d8535e8e599c2ba9560e9d7409.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c376d98_3b20_44cc_98f2_7f71503ced2c.slice/cri-containerd-5858cc7bb1282409aff1613807a4ddb63cd0dacfab24e1ec69d4cf63ea8d4283.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podedec30bb_1a62_4e49_879c_d199d6426cfb.slice/cri-containerd-27e76ed4ced3afe1fdbb18d10abec3c5b50e4d9770e5c0752080c88ef5ca5fc2.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podedec30bb_1a62_4e49_879c_d199d6426cfb.slice/cri-containerd-5530fc187cced37cc59e83f94ba1a0cac5f8d5be959e5396bb52bbb0dc341aca.scope
    99       cgroup_device   multi                                          
