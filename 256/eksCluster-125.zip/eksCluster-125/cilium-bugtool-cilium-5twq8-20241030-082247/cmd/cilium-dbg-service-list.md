ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.194.104:443 (active)   
                                          2 => 172.31.189.61:443 (active)    
2    10.100.168.211:443    ClusterIP      1 => 172.31.225.47:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.125.0.242:53 (active)      
                                          2 => 10.125.0.86:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.125.0.242:9153 (active)    
                                          2 => 10.125.0.86:9153 (active)     
5    10.100.251.138:2379   ClusterIP      1 => 10.125.0.186:2379 (active)    
