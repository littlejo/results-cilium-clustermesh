 08:22:49 up 36 min,  0 users,  load average: 0.05, 0.08, 0.08
