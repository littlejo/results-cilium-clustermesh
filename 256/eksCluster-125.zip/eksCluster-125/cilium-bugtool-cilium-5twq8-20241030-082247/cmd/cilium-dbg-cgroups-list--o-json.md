[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod76bd3e89_ee5e_41f2_865b_5bf49455d6ed.slice/cri-containerd-48df76eb197d31482302e7acffdca3f3079cba73ba22d28453fa4846f52da4c3.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod76bd3e89_ee5e_41f2_865b_5bf49455d6ed.slice/cri-containerd-f56f0e3d413d743e965b1e2de47370265f0e9c47fa605141cccf13f1ac5d3635.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod76bd3e89_ee5e_41f2_865b_5bf49455d6ed.slice/cri-containerd-922cd3bcf7c2daeab9c6302ab7f2dd2e598024130fe4cce331226667e81e67fd.scope"
      }
    ],
    "ips": [
      "10.125.0.186"
    ],
    "name": "clustermesh-apiserver-7568db8c9f-wzx7t",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50b091ea_810a_41b5_9624_8f5bfaf2eb53.slice/cri-containerd-f677f261dd384afee59f985a74baec9d202b34e7691ec3855dccf679ea0103c7.scope"
      }
    ],
    "ips": [
      "10.125.0.242"
    ],
    "name": "coredns-cc6ccd49c-mhbl8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod30cd3689_7ade_4da0_bc7f_d550b3a1d1b5.slice/cri-containerd-d2dda31501f4520c4efba64a669064344eee1b605f5206f1d41a8e34cadfccee.scope"
      }
    ],
    "ips": [
      "10.125.0.86"
    ],
    "name": "coredns-cc6ccd49c-5hftt",
    "namespace": "kube-system"
  }
]

