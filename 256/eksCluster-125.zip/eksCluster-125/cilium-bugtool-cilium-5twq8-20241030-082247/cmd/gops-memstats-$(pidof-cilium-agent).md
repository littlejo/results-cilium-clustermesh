alloc: 124.05MB (130080864 bytes)
total-alloc: 2.28GB (2449618024 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 63737436
frees: 62665194
heap-alloc: 124.05MB (130080864 bytes)
heap-sys: 251.42MB (263634944 bytes)
heap-idle: 80.22MB (84115456 bytes)
heap-in-use: 171.20MB (179519488 bytes)
heap-released: 2.06MB (2162688 bytes)
heap-objects: 1072242
stack-in-use: 64.53MB (67665920 bytes)
stack-sys: 64.53MB (67665920 bytes)
stack-mspan-inuse: 2.88MB (3018720 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.17MB (1228369 bytes)
gc-sys: 6.05MB (6348336 bytes)
next-gc: when heap-alloc >= 211.45MB (221724040 bytes)
last-gc: 2024-10-30 08:23:05.150372052 +0000 UTC
gc-pause-total: 21.507723ms
gc-pause: 178841
gc-pause-end: 1730276585150372052
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00036553402216119723
enable-gc: true
debug-gc: false
