key: 05 04 00 00  value: 76 02 00 00
key: 0b 04 00 00  value: 20 02 00 00
key: 0a 08 00 00  value: 0d 02 00 00
key: 0b 0e 00 00  value: 04 02 00 00
Found 4 elements
