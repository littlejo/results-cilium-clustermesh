CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod30cd3689_7ade_4da0_bc7f_d550b3a1d1b5.slice/cri-containerd-d2dda31501f4520c4efba64a669064344eee1b605f5206f1d41a8e34cadfccee.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod30cd3689_7ade_4da0_bc7f_d550b3a1d1b5.slice/cri-containerd-5e4bdaa2206341ce5e1a4b8995b09f6b6f82173edb87fd09cbee844caa1197df.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6d9e778a_830a_4407_83e2_5f677270e2a4.slice/cri-containerd-ab7c14ef9a87b3234e8f5144500bc5f5094ece1c4c29bd855d32af77d650116c.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6d9e778a_830a_4407_83e2_5f677270e2a4.slice/cri-containerd-27a2c06da8e0d8c708b3751dec204497c4f4eb048fa595f02f64f6425f485de0.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode28e2211_891f_4b19_be3d_5126dc0fa194.slice/cri-containerd-3628e79b174e81cc0f7c6af73856e1bf086e9d3de655dfc0ae91051a8e31aae4.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode28e2211_891f_4b19_be3d_5126dc0fa194.slice/cri-containerd-c89de2befab60ae86c160bf41d7a078dad820911b5bb1aff9518d8bbf0cb04c3.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50b091ea_810a_41b5_9624_8f5bfaf2eb53.slice/cri-containerd-be3ca9c039713b8884a0b78717d9e709e2895ee1811f8b9fb37a5f4b27ccd9ab.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50b091ea_810a_41b5_9624_8f5bfaf2eb53.slice/cri-containerd-f677f261dd384afee59f985a74baec9d202b34e7691ec3855dccf679ea0103c7.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod76bd3e89_ee5e_41f2_865b_5bf49455d6ed.slice/cri-containerd-48df76eb197d31482302e7acffdca3f3079cba73ba22d28453fa4846f52da4c3.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod76bd3e89_ee5e_41f2_865b_5bf49455d6ed.slice/cri-containerd-f56f0e3d413d743e965b1e2de47370265f0e9c47fa605141cccf13f1ac5d3635.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod76bd3e89_ee5e_41f2_865b_5bf49455d6ed.slice/cri-containerd-922cd3bcf7c2daeab9c6302ab7f2dd2e598024130fe4cce331226667e81e67fd.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod76bd3e89_ee5e_41f2_865b_5bf49455d6ed.slice/cri-containerd-ea395066308e77867d5ccc7ef5ab65037fe5219ac59289fa1f2a705a05dc0257.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc81295b8_f6e9_48f6_a627_60aeafdebb43.slice/cri-containerd-5e86a41e035da92aa9b53bb07e49d1b46a2640dbd99eed786e92dd8b436c6cfe.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc81295b8_f6e9_48f6_a627_60aeafdebb43.slice/cri-containerd-4da0e8de26df3b4f9ad37485a6a17f37728ac062a82f72c1d7f653b9fb19a27f.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod154c6a33_1b8d_4777_9b08_63bb40b0e70d.slice/cri-containerd-f0dd54e7dac2bf5b4600f13ad13509ee10998b0e19109a1776b0040af12ff1a0.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod154c6a33_1b8d_4777_9b08_63bb40b0e70d.slice/cri-containerd-2b58e6c782dbdadcc0f08fb3a0bc4e11892dc36b9e15fc1652f24286e4ba54d6.scope
    98       cgroup_device   multi                                          
