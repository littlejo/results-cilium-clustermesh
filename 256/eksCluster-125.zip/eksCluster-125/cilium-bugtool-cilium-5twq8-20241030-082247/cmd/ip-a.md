1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:b2:34:55:08:d1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.225.47/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3196sec preferred_lft 3196sec
    inet6 fe80::8b2:34ff:fe55:8d1/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:b7:8e:26:bb:93 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.209.45/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8b7:8eff:fe26:bb93/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:ee:e3:0d:67:f8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::dcee:e3ff:fe0d:67f8/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:13:87:c3:bb:3d brd ff:ff:ff:ff:ff:ff
    inet 10.125.0.74/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::7c13:87ff:fec3:bb3d/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3e:79:3d:ed:40:5c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3c79:3dff:feed:405c/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:0a:58:d1:d9:fe brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::e80a:58ff:fed1:d9fe/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcc73b0a2aef34@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:9c:32:0e:44:fc brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::1c9c:32ff:fe0e:44fc/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc9765e5e91ca7@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:3a:9f:14:01:cf brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::743a:9fff:fe14:1cf/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc3b7df88ded43@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:2b:ee:f8:a5:fa brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::f02b:eeff:fef8:a5fa/64 scope link 
       valid_lft forever preferred_lft forever
