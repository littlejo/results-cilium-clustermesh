KEY             VALUE
AgentLiveness   2245254165068
UTimeOffset     3379442099609375
