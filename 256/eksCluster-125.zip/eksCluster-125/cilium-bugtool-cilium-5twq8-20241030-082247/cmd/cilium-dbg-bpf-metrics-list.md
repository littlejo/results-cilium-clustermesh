REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36462     2886595     677    bpf_overlay.c
Interface                 INGRESS     636400    131081010   1132   bpf_host.c
Success                   EGRESS      16444     1295767     1694   bpf_host.c
Success                   EGRESS      265693    33522837    1308   bpf_lxc.c
Success                   EGRESS      36633     2902294     53     encap.h
Success                   INGRESS     308250    34640573    86     l3.h
Success                   INGRESS     328919    36275447    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
