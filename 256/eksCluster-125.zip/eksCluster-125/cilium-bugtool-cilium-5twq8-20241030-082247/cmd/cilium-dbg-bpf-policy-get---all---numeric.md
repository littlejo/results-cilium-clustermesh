Endpoint ID: 1029
Path: /sys/fs/bpf/tc/globals/cilium_policy_01029

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11403195   112935    0        
Allow    Ingress     1          ANY          NONE         disabled    9667747    101340    0        
Allow    Egress      0          ANY          NONE         disabled    11995065   118602    0        


Endpoint ID: 1035
Path: /sys/fs/bpf/tc/globals/cilium_policy_01035

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174472   1999      0        
Allow    Egress      0          ANY          NONE         disabled    22089    249       0        


Endpoint ID: 2058
Path: /sys/fs/bpf/tc/globals/cilium_policy_02058

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1637386   20701     0        
Allow    Ingress     1          ANY          NONE         disabled    25816     300       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3114
Path: /sys/fs/bpf/tc/globals/cilium_policy_03114

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3595
Path: /sys/fs/bpf/tc/globals/cilium_policy_03595

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174773   2009      0        
Allow    Egress      0          ANY          NONE         disabled    19693    221       0        


