top - 08:22:49 up 36 min,  0 users,  load average: 0.05, 0.08, 0.08
Tasks:  11 total,   3 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 60.0 us, 30.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi, 10.0 si,  0.0 st
MiB Mem :   7814.2 total,   4454.3 free,   1213.3 used,   2146.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6415.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 399132  78468 S  53.3   5.0   0:51.77 cilium-+
    642 root      20   0 1229640  32484   4004 R  20.0   0.4   0:00.03 gops
    728 root      20   0 1244084  19984  14008 S  20.0   0.2   0:00.03 hubble
    689 root      20   0 1240432  16408  11292 S   6.7   0.2   0:00.03 cilium-+
    394 root      20   0 1229744   6952   2864 S   0.0   0.1   0:01.14 cilium-+
    648 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    673 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    683 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    718 root      20   0    6576   2424   2100 R   0.0   0.0   0:00.00 top
    719 root      20   0    2208    792    712 S   0.0   0.0   0:00.00 timeout
    749 root      20   0    3728    488    436 R   0.0   0.0   0:00.00 bash
