xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 572
ens6(5) clsact/ingress cil_from_netdev-ens6 id 583
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 568
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 560
cilium_host(7) clsact/egress cil_from_host-cilium_host id 556
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 530
lxcc73b0a2aef34(12) clsact/ingress cil_from_container-lxcc73b0a2aef34 id 542
lxc9765e5e91ca7(14) clsact/ingress cil_from_container-lxc9765e5e91ca7 id 511
lxc3b7df88ded43(18) clsact/ingress cil_from_container-lxc3b7df88ded43 id 626

flow_dissector:

netfilter:

