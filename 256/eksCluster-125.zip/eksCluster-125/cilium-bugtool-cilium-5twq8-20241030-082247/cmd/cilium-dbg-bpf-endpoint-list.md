IP ADDRESS        LOCAL ENDPOINT INFO
10.125.0.74:0     (localhost)                                                                                        
172.31.209.45:0   (localhost)                                                                                        
10.125.0.76:0     id=2058  sec_id=4     flags=0x0000 ifindex=10  mac=EE:48:DE:08:96:32 nodemac=EA:0A:58:D1:D9:FE     
172.31.225.47:0   (localhost)                                                                                        
10.125.0.186:0    id=1029  sec_id=4131531 flags=0x0000 ifindex=18  mac=F6:55:55:26:8B:87 nodemac=F2:2B:EE:F8:A5:FA   
10.125.0.86:0     id=3595  sec_id=4137807 flags=0x0000 ifindex=14  mac=D6:BD:AB:2C:2D:A7 nodemac=76:3A:9F:14:01:CF   
10.125.0.242:0    id=1035  sec_id=4137807 flags=0x0000 ifindex=12  mac=A2:4B:41:81:6B:35 nodemac=1E:9C:32:0E:44:FC   
