35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:47:13+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:47:13+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:47:14+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:47:14+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:47:14+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:47:14+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:47:18+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:47:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:47:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:47:28+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name tail_handle_ipv4  tag d604e150b7f5d3c1  gpl
	loaded_at 2024-10-30T07:53:50+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
485: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:53:50+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
486: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:53:50+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 126
487: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:53:50+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
510: sched_cls  name tail_handle_ipv4_cont  tag 776f24ad25a42863  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,107,41,106,82,83,39,76,74,77,108,40,37,38,81
	btf_id 153
511: sched_cls  name handle_policy  tag 95e8f7792376f916  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,108,82,83,107,41,80,106,39,84,75,40,37,38
	btf_id 154
512: sched_cls  name tail_handle_ipv4  tag 4b01a524cd5a1036  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 155
513: sched_cls  name tail_ipv4_ct_ingress  tag 8a529952ddb71f36  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 156
515: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 158
516: sched_cls  name tail_handle_arp  tag 8e774354e8e08839  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 159
517: sched_cls  name __send_drop_notify  tag b83aee80db3ae089  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 160
518: sched_cls  name cil_from_container  tag ed152455fd64c5f8  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,76
	btf_id 161
519: sched_cls  name tail_ipv4_ct_egress  tag d769ea29325e865f  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 162
520: sched_cls  name tail_ipv4_to_endpoint  tag 267d4f7e7b671198  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,107,41,82,83,80,106,39,108,40,37,38
	btf_id 163
521: sched_cls  name tail_handle_ipv4_cont  tag a0388b0aba0579d8  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,109,41,101,82,83,39,76,74,77,110,40,37,38,81
	btf_id 165
522: sched_cls  name tail_ipv4_ct_ingress  tag c3792d2c76c26f82  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 166
523: sched_cls  name cil_from_container  tag 7f232d9d5dcd0295  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 110,76
	btf_id 167
524: sched_cls  name tail_ipv4_to_endpoint  tag f9b38e184d23e06f  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,109,41,82,83,80,101,39,110,40,37,38
	btf_id 168
525: sched_cls  name __send_drop_notify  tag 611d64fe29f2c8dd  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 169
526: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
529: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
530: sched_cls  name tail_handle_ipv4  tag 1211ff7c783a9b80  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 170
531: sched_cls  name handle_policy  tag 601e21aadafe70b8  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,110,82,83,109,41,80,101,39,84,75,40,37,38
	btf_id 171
532: sched_cls  name tail_handle_arp  tag c89617dc9d00bb54  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 172
534: sched_cls  name tail_ipv4_ct_egress  tag d769ea29325e865f  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 174
535: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 175
536: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 177
537: sched_cls  name tail_handle_ipv4  tag a5393b6db5d64625  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 178
538: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
541: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
543: sched_cls  name handle_policy  tag 9edcbf9f4a077ed5  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,113,82,83,112,41,80,100,39,84,75,40,37,38
	btf_id 180
544: sched_cls  name tail_ipv4_to_endpoint  tag 15155cf2fe740a06  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,112,41,82,83,80,100,39,113,40,37,38
	btf_id 181
545: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 182
546: sched_cls  name __send_drop_notify  tag c4d6ba72da4450ec  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 183
547: sched_cls  name tail_ipv4_ct_ingress  tag be7cfb7427c2bcdb  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 184
548: sched_cls  name tail_handle_arp  tag b0a280719e75baee  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 185
549: sched_cls  name tail_handle_ipv4_cont  tag 51532a5801ab3740  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,112,41,100,82,83,39,76,74,77,113,40,37,38,81
	btf_id 186
550: sched_cls  name cil_from_container  tag e3f9983f73d1631a  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 113,76
	btf_id 187
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
561: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 191
562: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,117
	btf_id 192
563: sched_cls  name tail_handle_ipv4_from_host  tag 1147f0afd9100865  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 193
564: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 194
565: sched_cls  name __send_drop_notify  tag 3d57005f872b340f  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 195
566: sched_cls  name tail_handle_ipv4_from_host  tag 1147f0afd9100865  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 197
567: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 198
568: sched_cls  name __send_drop_notify  tag 3d57005f872b340f  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
571: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 202
573: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 205
574: sched_cls  name __send_drop_notify  tag 3d57005f872b340f  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
575: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 207
579: sched_cls  name tail_handle_ipv4_from_host  tag 1147f0afd9100865  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 211
581: sched_cls  name tail_handle_ipv4_from_host  tag 1147f0afd9100865  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 214
582: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 215
583: sched_cls  name __send_drop_notify  tag 3d57005f872b340f  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 216
584: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 217
626: sched_cls  name tail_ipv4_to_endpoint  tag 2d440a4a72fae335  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 233
627: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 234
628: sched_cls  name tail_handle_arp  tag b0a1bf72cccd947b  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 235
629: sched_cls  name tail_ipv4_ct_egress  tag 115de49bccc7faab  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 236
630: sched_cls  name handle_policy  tag f823407a866b8e76  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 237
631: sched_cls  name cil_from_container  tag 9033cf0d4e3555a6  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 238
632: sched_cls  name __send_drop_notify  tag 3f896592b98f8189  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 239
633: sched_cls  name tail_ipv4_ct_ingress  tag b58e83e1f90392c4  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 240
634: sched_cls  name tail_handle_ipv4_cont  tag c8b8895b56bff7e0  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 241
635: sched_cls  name tail_handle_ipv4  tag 3d95f3eb7c0060de  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 242
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
