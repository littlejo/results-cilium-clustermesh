key: 02 00 00 00  value: ac 1f d8 9e 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 60 00 c2 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 60 00 df 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 60 00 68 09 4b 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 98 ba 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 60 00 c2 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 60 00 df 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f af f6 10 94 00 00  00 00 00 00
Found 8 elements
