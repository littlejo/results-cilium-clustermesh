CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeed28225_a687_4ea9_baf1_6316c99b5905.slice/cri-containerd-afe065c29e066943ca81c8cfbd75ab86e1df526c5daf1978a016f8c1bc2a3ce8.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeed28225_a687_4ea9_baf1_6316c99b5905.slice/cri-containerd-6be2ad3d2a6a6290d9fe60f63ff37f8431edf454a474e14bd024992af1b329ec.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0cd336fd_4c20_4742_a41e_1e574e34e2c3.slice/cri-containerd-d7a688baa79f01185f130a99651948c352d8a5794f9fc140601764ecb4f64ffd.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0cd336fd_4c20_4742_a41e_1e574e34e2c3.slice/cri-containerd-c0049e6b663df82581974657f66df3065785431fb579e7833014487b534aa856.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod147c6b20_1a74_489b_a917_c36f56c68de5.slice/cri-containerd-c1a277c6a00bc659e8e8a8c847d86fd10b0478ad4ed403cc9959f438d7d362fe.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod147c6b20_1a74_489b_a917_c36f56c68de5.slice/cri-containerd-3e217fb6e616cb28a7ef990f9981fc13668999ca8ab15952c1a6e51b82d45944.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f85aaf5_9838_4bdd_a0cb_b2aaafd98df3.slice/cri-containerd-9c1911e62ebca91443b40f9882df7abc1b7f7f6f0f2bda1e359f92c887950aae.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f85aaf5_9838_4bdd_a0cb_b2aaafd98df3.slice/cri-containerd-58b38fd13222124384912f234107d275d16c7091775481d7941e12507e506c98.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5a46fb3_e123_4254_9197_71f87230378c.slice/cri-containerd-9d21596f88c6fed05e7b0bfc27d52ccd3ba03a26b6947fda81c3b38574b16e7f.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5a46fb3_e123_4254_9197_71f87230378c.slice/cri-containerd-fb0d65bc1e24011cd5d13b238220c0f6b591b0e761fd3d8d5aff3a06a1119f70.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5a46fb3_e123_4254_9197_71f87230378c.slice/cri-containerd-fa2e2807b64dd743a3179943f9fb0841d32eb90f962f57ca1042f9d460f10ba3.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5a46fb3_e123_4254_9197_71f87230378c.slice/cri-containerd-55082b26d540e1f1e41ad128343b85d9485a3ff7c62f39bb78a6869a560b2b43.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7d4489e1_4509_46ee_b504_52acebcffe9e.slice/cri-containerd-b265c9726c1b1873e040220c451f2c605edb95a426ef1070495587b3aca58ea2.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7d4489e1_4509_46ee_b504_52acebcffe9e.slice/cri-containerd-79318b8c65d5ed54bc903f138188481bc3b2b8b0e1fc2efb934c6580cdd3ab28.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc91dd458_e2f3_4583_9dee_fb80fe066901.slice/cri-containerd-0c70c493c4a76ff7ac72cf262f004b3a9a095d70c4ca246c50b2a76c996fa565.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc91dd458_e2f3_4583_9dee_fb80fe066901.slice/cri-containerd-5173861708ec3d236f4a69ffcc43c90bded6e7e6c26343338550ac893a48b843.scope
    105      cgroup_device   multi                                          
