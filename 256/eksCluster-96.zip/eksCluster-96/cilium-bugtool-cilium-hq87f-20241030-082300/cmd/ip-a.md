1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:78:46:3d:04:29 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.175.246/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3260sec preferred_lft 3260sec
    inet6 fe80::478:46ff:fe3d:429/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:3b:1e:09:65:a3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.186.95/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::43b:1eff:fe09:65a3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:1d:69:57:cf:ab brd ff:ff:ff:ff:ff:ff
    inet6 fe80::81d:69ff:fe57:cfab/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:3f:05:0e:0e:87 brd ff:ff:ff:ff:ff:ff
    inet 10.96.0.152/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::343f:5ff:fe0e:e87/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 4a:cc:63:65:75:a0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::48cc:63ff:fe65:75a0/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:62:f8:4d:e3:4e brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::862:f8ff:fe4d:e34e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcc55b5a012418@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:b3:54:ee:8b:22 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::90b3:54ff:feee:8b22/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcfa1543751c7e@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:88:65:10:ea:bd brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::9c88:65ff:fe10:eabd/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcaaf9d7d51788@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:59:c6:bf:0f:6d brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::1c59:c6ff:febf:f6d/64 scope link 
       valid_lft forever preferred_lft forever
