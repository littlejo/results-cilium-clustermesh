ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.152.186:443 (active)    
                                        2 => 172.31.216.158:443 (active)    
2    10.100.89.113:443   ClusterIP      1 => 172.31.175.246:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.96.0.223:53 (active)        
                                        2 => 10.96.0.194:53 (active)        
4    10.100.0.10:9153    ClusterIP      1 => 10.96.0.223:9153 (active)      
                                        2 => 10.96.0.194:9153 (active)      
5    10.100.46.78:2379   ClusterIP      1 => 10.96.0.104:2379 (active)      
