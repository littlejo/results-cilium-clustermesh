{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:48.435Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.175.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:48.435Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.186.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:48.435Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.682Z",
  "value": "id=3262  sec_id=3208251 flags=0x0000 ifindex=12  mac=7E:40:6B:51:2A:4B nodemac=92:B3:54:EE:8B:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.685Z",
  "value": "id=151   sec_id=4     flags=0x0000 ifindex=10  mac=7A:50:2E:85:15:37 nodemac=0A:62:F8:4D:E3:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.755Z",
  "value": "id=1488  sec_id=3208251 flags=0x0000 ifindex=14  mac=EA:10:80:08:66:FB nodemac=9E:88:65:10:EA:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.823Z",
  "value": "id=3262  sec_id=3208251 flags=0x0000 ifindex=12  mac=7E:40:6B:51:2A:4B nodemac=92:B3:54:EE:8B:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.902Z",
  "value": "id=151   sec_id=4     flags=0x0000 ifindex=10  mac=7A:50:2E:85:15:37 nodemac=0A:62:F8:4D:E3:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:14.636Z",
  "value": "id=1488  sec_id=3208251 flags=0x0000 ifindex=14  mac=EA:10:80:08:66:FB nodemac=9E:88:65:10:EA:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:14.637Z",
  "value": "id=151   sec_id=4     flags=0x0000 ifindex=10  mac=7A:50:2E:85:15:37 nodemac=0A:62:F8:4D:E3:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:14.637Z",
  "value": "id=3262  sec_id=3208251 flags=0x0000 ifindex=12  mac=7E:40:6B:51:2A:4B nodemac=92:B3:54:EE:8B:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:14.666Z",
  "value": "id=391   sec_id=3182759 flags=0x0000 ifindex=16  mac=6A:6D:0E:5C:77:BE nodemac=72:9B:9C:D5:D5:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:15.637Z",
  "value": "id=3262  sec_id=3208251 flags=0x0000 ifindex=12  mac=7E:40:6B:51:2A:4B nodemac=92:B3:54:EE:8B:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:15.637Z",
  "value": "id=151   sec_id=4     flags=0x0000 ifindex=10  mac=7A:50:2E:85:15:37 nodemac=0A:62:F8:4D:E3:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:15.637Z",
  "value": "id=1488  sec_id=3208251 flags=0x0000 ifindex=14  mac=EA:10:80:08:66:FB nodemac=9E:88:65:10:EA:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:15.637Z",
  "value": "id=391   sec_id=3182759 flags=0x0000 ifindex=16  mac=6A:6D:0E:5C:77:BE nodemac=72:9B:9C:D5:D5:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.495Z",
  "value": "id=657   sec_id=3182759 flags=0x0000 ifindex=18  mac=8A:CC:C0:AD:01:D4 nodemac=1E:59:C6:BF:0F:6D"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.96.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.956Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:27.105Z",
  "value": "id=1488  sec_id=3208251 flags=0x0000 ifindex=14  mac=EA:10:80:08:66:FB nodemac=9E:88:65:10:EA:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:27.105Z",
  "value": "id=657   sec_id=3182759 flags=0x0000 ifindex=18  mac=8A:CC:C0:AD:01:D4 nodemac=1E:59:C6:BF:0F:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:27.105Z",
  "value": "id=151   sec_id=4     flags=0x0000 ifindex=10  mac=7A:50:2E:85:15:37 nodemac=0A:62:F8:4D:E3:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:27.106Z",
  "value": "id=3262  sec_id=3208251 flags=0x0000 ifindex=12  mac=7E:40:6B:51:2A:4B nodemac=92:B3:54:EE:8B:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:28.108Z",
  "value": "id=657   sec_id=3182759 flags=0x0000 ifindex=18  mac=8A:CC:C0:AD:01:D4 nodemac=1E:59:C6:BF:0F:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:28.110Z",
  "value": "id=151   sec_id=4     flags=0x0000 ifindex=10  mac=7A:50:2E:85:15:37 nodemac=0A:62:F8:4D:E3:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:28.110Z",
  "value": "id=3262  sec_id=3208251 flags=0x0000 ifindex=12  mac=7E:40:6B:51:2A:4B nodemac=92:B3:54:EE:8B:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:28.110Z",
  "value": "id=1488  sec_id=3208251 flags=0x0000 ifindex=14  mac=EA:10:80:08:66:FB nodemac=9E:88:65:10:EA:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.103Z",
  "value": "id=151   sec_id=4     flags=0x0000 ifindex=10  mac=7A:50:2E:85:15:37 nodemac=0A:62:F8:4D:E3:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.103Z",
  "value": "id=657   sec_id=3182759 flags=0x0000 ifindex=18  mac=8A:CC:C0:AD:01:D4 nodemac=1E:59:C6:BF:0F:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.103Z",
  "value": "id=1488  sec_id=3208251 flags=0x0000 ifindex=14  mac=EA:10:80:08:66:FB nodemac=9E:88:65:10:EA:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.103Z",
  "value": "id=3262  sec_id=3208251 flags=0x0000 ifindex=12  mac=7E:40:6B:51:2A:4B nodemac=92:B3:54:EE:8B:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:30.104Z",
  "value": "id=151   sec_id=4     flags=0x0000 ifindex=10  mac=7A:50:2E:85:15:37 nodemac=0A:62:F8:4D:E3:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:30.104Z",
  "value": "id=657   sec_id=3182759 flags=0x0000 ifindex=18  mac=8A:CC:C0:AD:01:D4 nodemac=1E:59:C6:BF:0F:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:30.104Z",
  "value": "id=1488  sec_id=3208251 flags=0x0000 ifindex=14  mac=EA:10:80:08:66:FB nodemac=9E:88:65:10:EA:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:30.104Z",
  "value": "id=3262  sec_id=3208251 flags=0x0000 ifindex=12  mac=7E:40:6B:51:2A:4B nodemac=92:B3:54:EE:8B:22"
}

