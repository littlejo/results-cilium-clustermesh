key: 97 00 00 00  value: 1f 02 00 00
key: 91 02 00 00  value: 76 02 00 00
key: d0 05 00 00  value: ff 01 00 00
key: be 0c 00 00  value: 13 02 00 00
Found 4 elements
