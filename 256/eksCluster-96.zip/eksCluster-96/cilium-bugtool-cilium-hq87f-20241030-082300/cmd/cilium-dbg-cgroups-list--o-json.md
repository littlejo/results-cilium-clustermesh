[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5a46fb3_e123_4254_9197_71f87230378c.slice/cri-containerd-55082b26d540e1f1e41ad128343b85d9485a3ff7c62f39bb78a6869a560b2b43.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5a46fb3_e123_4254_9197_71f87230378c.slice/cri-containerd-fa2e2807b64dd743a3179943f9fb0841d32eb90f962f57ca1042f9d460f10ba3.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5a46fb3_e123_4254_9197_71f87230378c.slice/cri-containerd-9d21596f88c6fed05e7b0bfc27d52ccd3ba03a26b6947fda81c3b38574b16e7f.scope"
      }
    ],
    "ips": [
      "10.96.0.104"
    ],
    "name": "clustermesh-apiserver-7cb4fc585f-hlpj2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f85aaf5_9838_4bdd_a0cb_b2aaafd98df3.slice/cri-containerd-9c1911e62ebca91443b40f9882df7abc1b7f7f6f0f2bda1e359f92c887950aae.scope"
      }
    ],
    "ips": [
      "10.96.0.194"
    ],
    "name": "coredns-cc6ccd49c-4vv7p",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod147c6b20_1a74_489b_a917_c36f56c68de5.slice/cri-containerd-c1a277c6a00bc659e8e8a8c847d86fd10b0478ad4ed403cc9959f438d7d362fe.scope"
      }
    ],
    "ips": [
      "10.96.0.223"
    ],
    "name": "coredns-cc6ccd49c-t4qgj",
    "namespace": "kube-system"
  }
]

