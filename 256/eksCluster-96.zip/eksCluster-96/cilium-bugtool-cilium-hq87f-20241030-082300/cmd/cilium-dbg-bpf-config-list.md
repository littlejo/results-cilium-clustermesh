KEY             VALUE
AgentLiveness   2181993716389
UTimeOffset     3379442246093750
