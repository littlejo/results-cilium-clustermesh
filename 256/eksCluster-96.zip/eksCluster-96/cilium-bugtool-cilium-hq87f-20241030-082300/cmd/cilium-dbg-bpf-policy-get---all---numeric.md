Endpoint ID: 151
Path: /sys/fs/bpf/tc/globals/cilium_policy_00151

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1668064   21116     0        
Allow    Ingress     1          ANY          NONE         disabled    24836     289       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 657
Path: /sys/fs/bpf/tc/globals/cilium_policy_00657

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11606502   115378    0        
Allow    Ingress     1          ANY          NONE         disabled    9605278    100811    0        
Allow    Egress      0          ANY          NONE         disabled    12661842   124993    0        


Endpoint ID: 1488
Path: /sys/fs/bpf/tc/globals/cilium_policy_01488

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    170929   1965      0        
Allow    Egress      0          ANY          NONE         disabled    19650    218       0        


Endpoint ID: 1724
Path: /sys/fs/bpf/tc/globals/cilium_policy_01724

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3262
Path: /sys/fs/bpf/tc/globals/cilium_policy_03262

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    171193   1969      0        
Allow    Egress      0          ANY          NONE         disabled    22477    253       0        


