IP ADDRESS         LOCAL ENDPOINT INFO
10.96.0.152:0      (localhost)                                                                                        
10.96.0.68:0       id=151   sec_id=4     flags=0x0000 ifindex=10  mac=7A:50:2E:85:15:37 nodemac=0A:62:F8:4D:E3:4E     
10.96.0.194:0      id=1488  sec_id=3208251 flags=0x0000 ifindex=14  mac=EA:10:80:08:66:FB nodemac=9E:88:65:10:EA:BD   
172.31.175.246:0   (localhost)                                                                                        
10.96.0.223:0      id=3262  sec_id=3208251 flags=0x0000 ifindex=12  mac=7E:40:6B:51:2A:4B nodemac=92:B3:54:EE:8B:22   
10.96.0.104:0      id=657   sec_id=3182759 flags=0x0000 ifindex=18  mac=8A:CC:C0:AD:01:D4 nodemac=1E:59:C6:BF:0F:6D   
172.31.186.95:0    (localhost)                                                                                        
