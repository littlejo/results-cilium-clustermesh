REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35784     2824211     677    bpf_overlay.c
Interface                 INGRESS     640302    132464878   1132   bpf_host.c
Success                   EGRESS      15396     1206394     1694   bpf_host.c
Success                   EGRESS      270566    33866710    1308   bpf_lxc.c
Success                   EGRESS      35224     2787017     53     encap.h
Success                   INGRESS     311835    35165566    86     l3.h
Success                   INGRESS     332874    36827429    235    trace.h
Unsupported L3 protocol   EGRESS      42        3112        1492   bpf_lxc.c
