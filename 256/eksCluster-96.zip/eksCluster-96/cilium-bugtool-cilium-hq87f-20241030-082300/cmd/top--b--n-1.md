top - 08:23:01 up 35 min,  0 users,  load average: 0.01, 0.07, 0.07
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s):  9.4 us, 31.2 sy,  0.0 ni, 59.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4473.1 free,   1195.4 used,   2145.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6433.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 378740  78272 S   6.7   4.7   0:45.36 cilium-+
    644 root      20   0 1240432  16556  11356 S   6.7   0.2   0:00.02 cilium-+
    395 root      20   0 1229744   8124   3836 S   0.0   0.1   0:01.08 cilium-+
    610 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    616 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    629 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    630 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    655 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    692 root      20   0    6576   2420   2096 R   0.0   0.0   0:00.00 top
    710 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
