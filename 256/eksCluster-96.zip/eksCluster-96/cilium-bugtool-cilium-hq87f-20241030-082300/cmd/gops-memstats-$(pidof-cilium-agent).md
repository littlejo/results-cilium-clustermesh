alloc: 144.59MB (151616632 bytes)
total-alloc: 2.26GB (2431400016 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 63576458
frees: 62419119
heap-alloc: 144.59MB (151616632 bytes)
heap-sys: 251.86MB (264093696 bytes)
heap-idle: 68.91MB (72261632 bytes)
heap-in-use: 182.95MB (191832064 bytes)
heap-released: 7.88MB (8257536 bytes)
heap-objects: 1157339
stack-in-use: 64.09MB (67207168 bytes)
stack-sys: 64.09MB (67207168 bytes)
stack-mspan-inuse: 2.79MB (2922560 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 994.47KB (1018337 bytes)
gc-sys: 6.02MB (6317544 bytes)
next-gc: when heap-alloc >= 211.86MB (222155336 bytes)
last-gc: 2024-10-30 08:23:12.663831594 +0000 UTC
gc-pause-total: 12.040087ms
gc-pause: 64026
gc-pause-end: 1730276592663831594
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00033814392560571263
enable-gc: true
debug-gc: false
