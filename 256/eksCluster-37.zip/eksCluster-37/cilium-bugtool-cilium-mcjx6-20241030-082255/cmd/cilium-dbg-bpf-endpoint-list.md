IP ADDRESS         LOCAL ENDPOINT INFO
10.37.0.35:0       id=1008  sec_id=1253390 flags=0x0000 ifindex=18  mac=46:4C:F7:76:C5:CC nodemac=5E:BA:E9:56:62:1C   
172.31.246.63:0    (localhost)                                                                                        
10.37.0.125:0      id=1177  sec_id=4     flags=0x0000 ifindex=10  mac=76:23:6D:BD:C3:97 nodemac=9E:B7:BA:A9:31:CA     
10.37.0.230:0      id=43    sec_id=1252425 flags=0x0000 ifindex=12  mac=0E:9F:6F:E3:0B:C8 nodemac=66:D6:A4:4D:BC:E7   
10.37.0.187:0      (localhost)                                                                                        
172.31.227.217:0   (localhost)                                                                                        
10.37.0.99:0       id=105   sec_id=1252425 flags=0x0000 ifindex=14  mac=C6:85:91:72:B5:E9 nodemac=DE:66:BA:32:6A:29   
