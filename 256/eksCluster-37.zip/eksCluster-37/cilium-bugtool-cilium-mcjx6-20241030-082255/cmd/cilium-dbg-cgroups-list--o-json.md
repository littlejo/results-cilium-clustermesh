[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbadae077_6b5f_4679_ad22_8f752cbd5538.slice/cri-containerd-b46940dc3560636144d4e5bed79fa0ee26246b1564694d20b7e2efb9fe4ed4a3.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbadae077_6b5f_4679_ad22_8f752cbd5538.slice/cri-containerd-71032e0a83275c25e423a6ba6fa56acce88517ce5ca7c306031c64d1324a1886.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbadae077_6b5f_4679_ad22_8f752cbd5538.slice/cri-containerd-ad4aa46b5fdc7d0a680a2ba2ca65ea5a507711acf9ef3e87f08ea0864c58786e.scope"
      }
    ],
    "ips": [
      "10.37.0.35"
    ],
    "name": "clustermesh-apiserver-96b6f88d4-x9dbb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8a846e4d_1cec_4641_b4e5_b00765becad9.slice/cri-containerd-a147c87b5f5a3e6a99a03f991f09e3472b7ae72f97875e5481e37a64d1ad4adf.scope"
      }
    ],
    "ips": [
      "10.37.0.230"
    ],
    "name": "coredns-cc6ccd49c-j2dgd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddaaf2193_7009_4781_9e12_ae72377bd999.slice/cri-containerd-4c2f58f6a71020ef1ad556ee4b31ef807276e7b5218960a0d74ebefc4d390f77.scope"
      }
    ],
    "ips": [
      "10.37.0.99"
    ],
    "name": "coredns-cc6ccd49c-ssdrc",
    "namespace": "kube-system"
  }
]

