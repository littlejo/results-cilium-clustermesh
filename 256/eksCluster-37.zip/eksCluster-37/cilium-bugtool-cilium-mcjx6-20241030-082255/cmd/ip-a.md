1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:fc:2b:88:c3:85 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.227.217/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3134sec preferred_lft 3134sec
    inet6 fe80::8fc:2bff:fe88:c385/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:2b:32:30:60:cf brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.246.63/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::82b:32ff:fe30:60cf/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:b5:31:4e:73:04 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4cb5:31ff:fe4e:7304/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:94:8a:38:79:f5 brd ff:ff:ff:ff:ff:ff
    inet 10.37.0.187/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::9494:8aff:fe38:79f5/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 32:d1:40:d2:5d:77 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::30d1:40ff:fed2:5d77/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:b7:ba:a9:31:ca brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::9cb7:baff:fea9:31ca/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca41221cbb8a9@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:d6:a4:4d:bc:e7 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::64d6:a4ff:fe4d:bce7/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcfa0f91383e7f@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:66:ba:32:6a:29 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::dc66:baff:fe32:6a29/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc29b1c2fd7f64@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:ba:e9:56:62:1c brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::5cba:e9ff:fe56:621c/64 scope link 
       valid_lft forever preferred_lft forever
