top - 08:22:57 up 37 min,  0 users,  load average: 0.32, 0.34, 0.25
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 55.2 us, 20.7 sy,  0.0 ni, 17.2 id,  0.0 wa,  0.0 hi,  6.9 si,  0.0 st
MiB Mem :   7814.2 total,   4475.2 free,   1191.4 used,   2147.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6437.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606144 385632  77692 S  86.7   4.8   0:56.37 cilium-+
    634 root      20   0 1240432  16748  11484 S   6.7   0.2   0:00.03 cilium-+
    393 root      20   0 1229744   7008   2928 S   0.0   0.1   0:01.15 cilium-+
    610 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    621 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    659 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    665 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    690 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    714 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
