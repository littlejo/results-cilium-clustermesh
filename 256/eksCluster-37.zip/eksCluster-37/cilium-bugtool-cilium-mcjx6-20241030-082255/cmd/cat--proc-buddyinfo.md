Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal      1     38     38     28     10      3     12     15      6      2    859 
