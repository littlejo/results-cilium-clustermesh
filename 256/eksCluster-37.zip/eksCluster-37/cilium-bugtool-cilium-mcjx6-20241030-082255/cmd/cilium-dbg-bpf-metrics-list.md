REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37012     2926502     677    bpf_overlay.c
Interface                 INGRESS     679170    137300942   1132   bpf_host.c
Success                   EGRESS      16605     1305936     1694   bpf_host.c
Success                   EGRESS      294258    36120016    1308   bpf_lxc.c
Success                   EGRESS      37607     2965207     53     encap.h
Success                   INGRESS     338183    38389375    86     l3.h
Success                   INGRESS     359241    40053987    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
