ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.151.35:443 (active)     
                                        2 => 172.31.228.220:443 (active)    
2    10.100.90.134:443   ClusterIP      1 => 172.31.227.217:4244 (active)   
3    10.100.0.10:9153    ClusterIP      1 => 10.37.0.230:9153 (active)      
                                        2 => 10.37.0.99:9153 (active)       
4    10.100.0.10:53      ClusterIP      1 => 10.37.0.230:53 (active)        
                                        2 => 10.37.0.99:53 (active)         
5    10.100.3.214:2379   ClusterIP      1 => 10.37.0.35:2379 (active)       
