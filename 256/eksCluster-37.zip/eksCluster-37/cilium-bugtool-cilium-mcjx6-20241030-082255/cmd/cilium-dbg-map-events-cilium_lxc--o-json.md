{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:32.867Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.227.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:32.867Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.246.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:32.867Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:37.623Z",
  "value": "id=1177  sec_id=4     flags=0x0000 ifindex=10  mac=76:23:6D:BD:C3:97 nodemac=9E:B7:BA:A9:31:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:37.632Z",
  "value": "id=43    sec_id=1252425 flags=0x0000 ifindex=12  mac=0E:9F:6F:E3:0B:C8 nodemac=66:D6:A4:4D:BC:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:37.691Z",
  "value": "id=105   sec_id=1252425 flags=0x0000 ifindex=14  mac=C6:85:91:72:B5:E9 nodemac=DE:66:BA:32:6A:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:37.709Z",
  "value": "id=1177  sec_id=4     flags=0x0000 ifindex=10  mac=76:23:6D:BD:C3:97 nodemac=9E:B7:BA:A9:31:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:49.209Z",
  "value": "id=1177  sec_id=4     flags=0x0000 ifindex=10  mac=76:23:6D:BD:C3:97 nodemac=9E:B7:BA:A9:31:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:49.210Z",
  "value": "id=43    sec_id=1252425 flags=0x0000 ifindex=12  mac=0E:9F:6F:E3:0B:C8 nodemac=66:D6:A4:4D:BC:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:49.211Z",
  "value": "id=105   sec_id=1252425 flags=0x0000 ifindex=14  mac=C6:85:91:72:B5:E9 nodemac=DE:66:BA:32:6A:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:49.240Z",
  "value": "id=45    sec_id=1253390 flags=0x0000 ifindex=16  mac=BE:8E:2F:FB:3A:7A nodemac=4A:A3:39:9A:CD:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:50.209Z",
  "value": "id=45    sec_id=1253390 flags=0x0000 ifindex=16  mac=BE:8E:2F:FB:3A:7A nodemac=4A:A3:39:9A:CD:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:50.210Z",
  "value": "id=1177  sec_id=4     flags=0x0000 ifindex=10  mac=76:23:6D:BD:C3:97 nodemac=9E:B7:BA:A9:31:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:50.210Z",
  "value": "id=43    sec_id=1252425 flags=0x0000 ifindex=12  mac=0E:9F:6F:E3:0B:C8 nodemac=66:D6:A4:4D:BC:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:50.210Z",
  "value": "id=105   sec_id=1252425 flags=0x0000 ifindex=14  mac=C6:85:91:72:B5:E9 nodemac=DE:66:BA:32:6A:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:28.688Z",
  "value": "id=1008  sec_id=1253390 flags=0x0000 ifindex=18  mac=46:4C:F7:76:C5:CC nodemac=5E:BA:E9:56:62:1C"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.37.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:39.035Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:58.147Z",
  "value": "id=105   sec_id=1252425 flags=0x0000 ifindex=14  mac=C6:85:91:72:B5:E9 nodemac=DE:66:BA:32:6A:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:58.148Z",
  "value": "id=1177  sec_id=4     flags=0x0000 ifindex=10  mac=76:23:6D:BD:C3:97 nodemac=9E:B7:BA:A9:31:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:58.148Z",
  "value": "id=1008  sec_id=1253390 flags=0x0000 ifindex=18  mac=46:4C:F7:76:C5:CC nodemac=5E:BA:E9:56:62:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:58.148Z",
  "value": "id=43    sec_id=1252425 flags=0x0000 ifindex=12  mac=0E:9F:6F:E3:0B:C8 nodemac=66:D6:A4:4D:BC:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:59.148Z",
  "value": "id=43    sec_id=1252425 flags=0x0000 ifindex=12  mac=0E:9F:6F:E3:0B:C8 nodemac=66:D6:A4:4D:BC:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:59.148Z",
  "value": "id=105   sec_id=1252425 flags=0x0000 ifindex=14  mac=C6:85:91:72:B5:E9 nodemac=DE:66:BA:32:6A:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:59.149Z",
  "value": "id=1008  sec_id=1253390 flags=0x0000 ifindex=18  mac=46:4C:F7:76:C5:CC nodemac=5E:BA:E9:56:62:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:59.149Z",
  "value": "id=1177  sec_id=4     flags=0x0000 ifindex=10  mac=76:23:6D:BD:C3:97 nodemac=9E:B7:BA:A9:31:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:00.148Z",
  "value": "id=43    sec_id=1252425 flags=0x0000 ifindex=12  mac=0E:9F:6F:E3:0B:C8 nodemac=66:D6:A4:4D:BC:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:00.148Z",
  "value": "id=1177  sec_id=4     flags=0x0000 ifindex=10  mac=76:23:6D:BD:C3:97 nodemac=9E:B7:BA:A9:31:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:00.149Z",
  "value": "id=105   sec_id=1252425 flags=0x0000 ifindex=14  mac=C6:85:91:72:B5:E9 nodemac=DE:66:BA:32:6A:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:00.149Z",
  "value": "id=1008  sec_id=1253390 flags=0x0000 ifindex=18  mac=46:4C:F7:76:C5:CC nodemac=5E:BA:E9:56:62:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:01.149Z",
  "value": "id=1177  sec_id=4     flags=0x0000 ifindex=10  mac=76:23:6D:BD:C3:97 nodemac=9E:B7:BA:A9:31:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:01.149Z",
  "value": "id=1008  sec_id=1253390 flags=0x0000 ifindex=18  mac=46:4C:F7:76:C5:CC nodemac=5E:BA:E9:56:62:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:01.149Z",
  "value": "id=105   sec_id=1252425 flags=0x0000 ifindex=14  mac=C6:85:91:72:B5:E9 nodemac=DE:66:BA:32:6A:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:01.149Z",
  "value": "id=43    sec_id=1252425 flags=0x0000 ifindex=12  mac=0E:9F:6F:E3:0B:C8 nodemac=66:D6:A4:4D:BC:E7"
}

