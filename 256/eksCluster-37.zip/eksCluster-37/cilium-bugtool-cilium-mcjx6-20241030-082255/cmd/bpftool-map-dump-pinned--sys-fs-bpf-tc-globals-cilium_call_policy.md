key: 2b 00 00 00  value: 02 02 00 00
key: 69 00 00 00  value: 31 02 00 00
key: f0 03 00 00  value: 83 02 00 00
key: 99 04 00 00  value: 3f 02 00 00
Found 4 elements
