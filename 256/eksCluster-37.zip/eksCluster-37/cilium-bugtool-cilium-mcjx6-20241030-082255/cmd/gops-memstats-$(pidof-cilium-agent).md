alloc: 182.52MB (191385824 bytes)
total-alloc: 2.42GB (2598731736 bytes)
sys: 332.83MB (349000036 bytes)
lookups: 0
mallocs: 66163691
frees: 64151748
heap-alloc: 182.52MB (191385824 bytes)
heap-sys: 255.26MB (267657216 bytes)
heap-idle: 48.01MB (50339840 bytes)
heap-in-use: 207.25MB (217317376 bytes)
heap-released: 1.98MB (2080768 bytes)
heap-objects: 2011943
stack-in-use: 64.72MB (67862528 bytes)
stack-sys: 64.72MB (67862528 bytes)
stack-mspan-inuse: 3.37MB (3533920 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 995.52KB (1019409 bytes)
gc-sys: 6.08MB (6372888 bytes)
next-gc: when heap-alloc >= 228.61MB (239718920 bytes)
last-gc: 2024-10-30 08:22:57.341676556 +0000 UTC
gc-pause-total: 17.454478ms
gc-pause: 102020
gc-pause-end: 1730276577341676556
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00040585150935639364
enable-gc: true
debug-gc: false
