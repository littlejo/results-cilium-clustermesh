xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 555
ens6(5) clsact/ingress cil_from_netdev-ens6 id 564
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 545
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 535
cilium_host(7) clsact/egress cil_from_host-cilium_host id 543
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 577
lxca41221cbb8a9(12) clsact/ingress cil_from_container-lxca41221cbb8a9 id 534
lxcfa0f91383e7f(14) clsact/ingress cil_from_container-lxcfa0f91383e7f id 544
lxc29b1c2fd7f64(18) clsact/ingress cil_from_container-lxc29b1c2fd7f64 id 638

flow_dissector:

netfilter:

