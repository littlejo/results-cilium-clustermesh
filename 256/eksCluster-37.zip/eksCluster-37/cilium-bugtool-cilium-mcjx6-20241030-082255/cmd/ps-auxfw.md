USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         665  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         659  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         634  0.0  0.2 1240432 16748 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         678  0.0  0.2 1240432 16748 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         679  0.0  0.0   6408  1648 ?        R    08:22   0:00  \_ ps auxfw
root         621  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         610  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.0  4.7 1606144 378444 ?      Ssl  07:52   0:56 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.0 1229744 7008 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
