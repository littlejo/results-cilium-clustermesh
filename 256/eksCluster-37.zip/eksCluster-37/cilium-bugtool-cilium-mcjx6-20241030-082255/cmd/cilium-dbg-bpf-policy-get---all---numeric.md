Endpoint ID: 43
Path: /sys/fs/bpf/tc/globals/cilium_policy_00043

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    175610   2011      0        
Allow    Egress      0          ANY          NONE         disabled    22725    257       0        


Endpoint ID: 105
Path: /sys/fs/bpf/tc/globals/cilium_policy_00105

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176433   2029      0        
Allow    Egress      0          ANY          NONE         disabled    21717    245       0        


Endpoint ID: 365
Path: /sys/fs/bpf/tc/globals/cilium_policy_00365

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1008
Path: /sys/fs/bpf/tc/globals/cilium_policy_01008

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11509093   116231    0        
Allow    Ingress     1          ANY          NONE         disabled    11362264   120321    0        
Allow    Egress      0          ANY          NONE         disabled    15269804   149001    0        


Endpoint ID: 1177
Path: /sys/fs/bpf/tc/globals/cilium_policy_01177

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1669088   21115     0        
Allow    Ingress     1          ANY          NONE         disabled    26250     308       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


