KEY             VALUE
AgentLiveness   2309425298866
UTimeOffset     3379441990234375
