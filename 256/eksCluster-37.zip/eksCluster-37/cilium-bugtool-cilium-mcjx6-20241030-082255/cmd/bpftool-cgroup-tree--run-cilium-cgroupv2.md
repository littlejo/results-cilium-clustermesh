CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ac663fc_2080_402b_8119_d941d76ab889.slice/cri-containerd-c69cbcc15a788868241b319ba5233d38805dc476f6332a578bb7f49f45d49d03.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ac663fc_2080_402b_8119_d941d76ab889.slice/cri-containerd-265a272db16c0e24909f95447d1e4950c054abee13fdca58835f3b954098ba40.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1472e6f_b746_4ece_82bf_33f12a7d8428.slice/cri-containerd-0fbd232d30c91f00444806d7ef34de6d89cb74848773e1587b7d0f37aa76ed15.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1472e6f_b746_4ece_82bf_33f12a7d8428.slice/cri-containerd-ed76e4e7b215a0b31acfe014db36576ce66c492134d6bedc9639b4d46411caf3.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8a846e4d_1cec_4641_b4e5_b00765becad9.slice/cri-containerd-a147c87b5f5a3e6a99a03f991f09e3472b7ae72f97875e5481e37a64d1ad4adf.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8a846e4d_1cec_4641_b4e5_b00765becad9.slice/cri-containerd-53e30d87584ce8cdf8759859f452a0651cfce7b5bab3bc1855e2c00a447f78e1.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddaaf2193_7009_4781_9e12_ae72377bd999.slice/cri-containerd-4c2f58f6a71020ef1ad556ee4b31ef807276e7b5218960a0d74ebefc4d390f77.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddaaf2193_7009_4781_9e12_ae72377bd999.slice/cri-containerd-a4cedd51801d9d40379b896470ce68e3bd0cbcfec98afbc392ee57db713b0d32.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod979a2bb3_0380_403c_b940_1e2988bc31a8.slice/cri-containerd-b2b625c52beb8b7a8efd640fe1ad10178e8cfa5575a1bd5f004af992dd2ccd45.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod979a2bb3_0380_403c_b940_1e2988bc31a8.slice/cri-containerd-dbc7ce07cba6b3e834184ae288e39297bec03ec1936a06f309453caf70e2f097.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbadae077_6b5f_4679_ad22_8f752cbd5538.slice/cri-containerd-b46940dc3560636144d4e5bed79fa0ee26246b1564694d20b7e2efb9fe4ed4a3.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbadae077_6b5f_4679_ad22_8f752cbd5538.slice/cri-containerd-8bcf92ccfa93ccac3eda4a168370128f72fa9796d380f507175354dd2a0a2ec2.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbadae077_6b5f_4679_ad22_8f752cbd5538.slice/cri-containerd-ad4aa46b5fdc7d0a680a2ba2ca65ea5a507711acf9ef3e87f08ea0864c58786e.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbadae077_6b5f_4679_ad22_8f752cbd5538.slice/cri-containerd-71032e0a83275c25e423a6ba6fa56acce88517ce5ca7c306031c64d1324a1886.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod531ef991_7cb8_43a5_a59f_47713d66dfd1.slice/cri-containerd-30c7a00ef0f7d55f0c2c8fb2d0787b7b30d37da23a4adb9c4377eff47344de47.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod531ef991_7cb8_43a5_a59f_47713d66dfd1.slice/cri-containerd-ac11bcc5e4947fc17a95800ef069230f5c5575c83db20a6eba0f9a9f8c984896.scope
    103      cgroup_device   multi                                          
