 08:22:56 up 37 min,  0 users,  load average: 0.32, 0.34, 0.25
