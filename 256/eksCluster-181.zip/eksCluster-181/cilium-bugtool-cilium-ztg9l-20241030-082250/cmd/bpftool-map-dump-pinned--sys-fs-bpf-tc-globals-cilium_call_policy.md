key: c8 00 00 00  value: 19 02 00 00
key: 07 08 00 00  value: 0d 02 00 00
key: 1e 08 00 00  value: 01 02 00 00
key: ed 08 00 00  value: 72 02 00 00
Found 4 elements
