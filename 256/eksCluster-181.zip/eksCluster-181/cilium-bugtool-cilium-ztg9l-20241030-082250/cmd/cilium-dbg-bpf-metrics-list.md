REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35609     2822836     677    bpf_overlay.c
Interface                 INGRESS     603723    126632624   1132   bpf_host.c
Success                   EGRESS      16401     1292945     1694   bpf_host.c
Success                   EGRESS      261881    31684847    1308   bpf_lxc.c
Success                   EGRESS      36230     2866436     53     encap.h
Success                   INGRESS     303774    33557993    86     l3.h
Success                   INGRESS     323633    35131930    235    trace.h
Unsupported L3 protocol   EGRESS      40        2972        1492   bpf_lxc.c
