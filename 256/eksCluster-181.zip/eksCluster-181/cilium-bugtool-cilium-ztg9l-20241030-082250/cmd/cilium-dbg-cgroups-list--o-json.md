[
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46cf1f92_c984_4569_a602_f4d4443eef44.slice/cri-containerd-2ab94634fffcc8b4b84060d50ddd461017fe3b66d5ed1ee8ba92741680a55c95.scope"
      }
    ],
    "ips": [
      "10.181.0.192"
    ],
    "name": "coredns-cc6ccd49c-slzgm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9400,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86a7e438_9be3_4417_b0dc_347c2f117874.slice/cri-containerd-22b520ef550e47643a9a534b4359a19ed65056cd3d974730a8a26f5d53739410.scope"
      },
      {
        "cgroup-id": 9316,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86a7e438_9be3_4417_b0dc_347c2f117874.slice/cri-containerd-df41713fccb44d631627c4168455c56738eb1af06097674b28e3fcb183004f43.scope"
      },
      {
        "cgroup-id": 9232,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86a7e438_9be3_4417_b0dc_347c2f117874.slice/cri-containerd-dc49ff5a20f03ecbda084534984eed551f5c56687774feeb8e73cf9e748fa83b.scope"
      }
    ],
    "ips": [
      "10.181.0.125"
    ],
    "name": "clustermesh-apiserver-7d97bddd97-9nd67",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1213274_c29b_4229_b85a_79df6e8d2dda.slice/cri-containerd-a506ea596e46d703db31bd4d6963b94cd46da6cd6f7600a37d3028812194b47a.scope"
      }
    ],
    "ips": [
      "10.181.0.51"
    ],
    "name": "coredns-cc6ccd49c-9bhpp",
    "namespace": "kube-system"
  }
]

