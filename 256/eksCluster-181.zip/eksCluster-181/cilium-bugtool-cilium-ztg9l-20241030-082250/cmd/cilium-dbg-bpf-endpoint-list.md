IP ADDRESS         LOCAL ENDPOINT INFO
10.181.0.57:0      (localhost)                                                                                        
10.181.0.192:0     id=200   sec_id=5972053 flags=0x0000 ifindex=12  mac=EE:07:3C:D9:B5:B8 nodemac=EE:B3:B7:1A:19:71   
10.181.0.125:0     id=2285  sec_id=5994369 flags=0x0000 ifindex=18  mac=56:1E:8E:CA:17:F2 nodemac=3A:EC:8D:E3:E2:11   
10.181.0.51:0      id=2078  sec_id=5972053 flags=0x0000 ifindex=14  mac=C2:51:7C:94:81:43 nodemac=4E:38:1E:87:ED:CB   
10.181.0.226:0     id=2055  sec_id=4     flags=0x0000 ifindex=10  mac=BE:F4:D1:10:C7:6E nodemac=0E:CE:E0:C3:A1:EA     
172.31.242.223:0   (localhost)                                                                                        
172.31.194.217:0   (localhost)                                                                                        
