alloc: 151.79MB (159166680 bytes)
total-alloc: 2.21GB (2377594504 bytes)
sys: 328.64MB (344609124 bytes)
lookups: 0
mallocs: 63050021
frees: 61515138
heap-alloc: 151.79MB (159166680 bytes)
heap-sys: 251.04MB (263233536 bytes)
heap-idle: 66.22MB (69435392 bytes)
heap-in-use: 184.82MB (193798144 bytes)
heap-released: 19.27MB (20201472 bytes)
heap-objects: 1534883
stack-in-use: 64.94MB (68091904 bytes)
stack-sys: 64.94MB (68091904 bytes)
stack-mspan-inuse: 3.13MB (3279520 bytes)
stack-mspan-sys: 3.78MB (3965760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.03MB (1076353 bytes)
gc-sys: 5.88MB (6168112 bytes)
next-gc: when heap-alloc >= 208.26MB (218378344 bytes)
last-gc: 2024-10-30 08:22:22.290208647 +0000 UTC
gc-pause-total: 9.257129ms
gc-pause: 98747
gc-pause-end: 1730276542290208647
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0004898387610172888
enable-gc: true
debug-gc: false
