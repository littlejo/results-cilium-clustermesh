1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:7d:60:1c:3b:e5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.194.217/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3522sec preferred_lft 3522sec
    inet6 fe80::87d:60ff:fe1c:3be5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:36:ff:7b:59:4f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.242.223/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::836:ffff:fe7b:594f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:0e:18:f5:28:6e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8c0e:18ff:fef5:286e/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:53:cd:1d:b2:e3 brd ff:ff:ff:ff:ff:ff
    inet 10.181.0.57/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::f453:cdff:fe1d:b2e3/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 4a:8b:56:d4:fa:88 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::488b:56ff:fed4:fa88/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:ce:e0:c3:a1:ea brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::cce:e0ff:fec3:a1ea/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcae06afd9fd70@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:b3:b7:1a:19:71 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ecb3:b7ff:fe1a:1971/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcdd561febc700@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:38:1e:87:ed:cb brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::4c38:1eff:fe87:edcb/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf4fb77fea314@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:ec:8d:e3:e2:11 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::38ec:8dff:fee3:e211/64 scope link 
       valid_lft forever preferred_lft forever
