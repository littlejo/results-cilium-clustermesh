{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.827Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.194.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.827Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.242.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.827Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:43.408Z",
  "value": "id=2055  sec_id=4     flags=0x0000 ifindex=10  mac=BE:F4:D1:10:C7:6E nodemac=0E:CE:E0:C3:A1:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:43.411Z",
  "value": "id=200   sec_id=5972053 flags=0x0000 ifindex=12  mac=EE:07:3C:D9:B5:B8 nodemac=EE:B3:B7:1A:19:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:43.467Z",
  "value": "id=2078  sec_id=5972053 flags=0x0000 ifindex=14  mac=C2:51:7C:94:81:43 nodemac=4E:38:1E:87:ED:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:43.517Z",
  "value": "id=2055  sec_id=4     flags=0x0000 ifindex=10  mac=BE:F4:D1:10:C7:6E nodemac=0E:CE:E0:C3:A1:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:43.614Z",
  "value": "id=200   sec_id=5972053 flags=0x0000 ifindex=12  mac=EE:07:3C:D9:B5:B8 nodemac=EE:B3:B7:1A:19:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:43.439Z",
  "value": "id=2055  sec_id=4     flags=0x0000 ifindex=10  mac=BE:F4:D1:10:C7:6E nodemac=0E:CE:E0:C3:A1:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:43.439Z",
  "value": "id=200   sec_id=5972053 flags=0x0000 ifindex=12  mac=EE:07:3C:D9:B5:B8 nodemac=EE:B3:B7:1A:19:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:43.439Z",
  "value": "id=2078  sec_id=5972053 flags=0x0000 ifindex=14  mac=C2:51:7C:94:81:43 nodemac=4E:38:1E:87:ED:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:43.471Z",
  "value": "id=303   sec_id=5994369 flags=0x0000 ifindex=16  mac=A6:AF:77:DD:29:DE nodemac=1A:2D:4B:0F:B8:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:44.439Z",
  "value": "id=200   sec_id=5972053 flags=0x0000 ifindex=12  mac=EE:07:3C:D9:B5:B8 nodemac=EE:B3:B7:1A:19:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:44.439Z",
  "value": "id=2055  sec_id=4     flags=0x0000 ifindex=10  mac=BE:F4:D1:10:C7:6E nodemac=0E:CE:E0:C3:A1:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:44.439Z",
  "value": "id=2078  sec_id=5972053 flags=0x0000 ifindex=14  mac=C2:51:7C:94:81:43 nodemac=4E:38:1E:87:ED:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:44.439Z",
  "value": "id=303   sec_id=5994369 flags=0x0000 ifindex=16  mac=A6:AF:77:DD:29:DE nodemac=1A:2D:4B:0F:B8:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.647Z",
  "value": "id=2285  sec_id=5994369 flags=0x0000 ifindex=18  mac=56:1E:8E:CA:17:F2 nodemac=3A:EC:8D:E3:E2:11"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.181.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.023Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.364Z",
  "value": "id=2285  sec_id=5994369 flags=0x0000 ifindex=18  mac=56:1E:8E:CA:17:F2 nodemac=3A:EC:8D:E3:E2:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.366Z",
  "value": "id=2055  sec_id=4     flags=0x0000 ifindex=10  mac=BE:F4:D1:10:C7:6E nodemac=0E:CE:E0:C3:A1:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.367Z",
  "value": "id=200   sec_id=5972053 flags=0x0000 ifindex=12  mac=EE:07:3C:D9:B5:B8 nodemac=EE:B3:B7:1A:19:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.370Z",
  "value": "id=2078  sec_id=5972053 flags=0x0000 ifindex=14  mac=C2:51:7C:94:81:43 nodemac=4E:38:1E:87:ED:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.372Z",
  "value": "id=2055  sec_id=4     flags=0x0000 ifindex=10  mac=BE:F4:D1:10:C7:6E nodemac=0E:CE:E0:C3:A1:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.372Z",
  "value": "id=200   sec_id=5972053 flags=0x0000 ifindex=12  mac=EE:07:3C:D9:B5:B8 nodemac=EE:B3:B7:1A:19:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.373Z",
  "value": "id=2078  sec_id=5972053 flags=0x0000 ifindex=14  mac=C2:51:7C:94:81:43 nodemac=4E:38:1E:87:ED:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.373Z",
  "value": "id=2285  sec_id=5994369 flags=0x0000 ifindex=18  mac=56:1E:8E:CA:17:F2 nodemac=3A:EC:8D:E3:E2:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.371Z",
  "value": "id=2055  sec_id=4     flags=0x0000 ifindex=10  mac=BE:F4:D1:10:C7:6E nodemac=0E:CE:E0:C3:A1:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.371Z",
  "value": "id=200   sec_id=5972053 flags=0x0000 ifindex=12  mac=EE:07:3C:D9:B5:B8 nodemac=EE:B3:B7:1A:19:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.371Z",
  "value": "id=2078  sec_id=5972053 flags=0x0000 ifindex=14  mac=C2:51:7C:94:81:43 nodemac=4E:38:1E:87:ED:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.371Z",
  "value": "id=2285  sec_id=5994369 flags=0x0000 ifindex=18  mac=56:1E:8E:CA:17:F2 nodemac=3A:EC:8D:E3:E2:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.372Z",
  "value": "id=2285  sec_id=5994369 flags=0x0000 ifindex=18  mac=56:1E:8E:CA:17:F2 nodemac=3A:EC:8D:E3:E2:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.372Z",
  "value": "id=2078  sec_id=5972053 flags=0x0000 ifindex=14  mac=C2:51:7C:94:81:43 nodemac=4E:38:1E:87:ED:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.372Z",
  "value": "id=200   sec_id=5972053 flags=0x0000 ifindex=12  mac=EE:07:3C:D9:B5:B8 nodemac=EE:B3:B7:1A:19:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.181.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.373Z",
  "value": "id=2055  sec_id=4     flags=0x0000 ifindex=10  mac=BE:F4:D1:10:C7:6E nodemac=0E:CE:E0:C3:A1:EA"
}

