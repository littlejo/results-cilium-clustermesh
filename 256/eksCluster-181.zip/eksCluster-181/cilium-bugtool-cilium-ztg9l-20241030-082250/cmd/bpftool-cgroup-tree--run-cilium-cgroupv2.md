CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1213274_c29b_4229_b85a_79df6e8d2dda.slice/cri-containerd-a506ea596e46d703db31bd4d6963b94cd46da6cd6f7600a37d3028812194b47a.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1213274_c29b_4229_b85a_79df6e8d2dda.slice/cri-containerd-3a2b04a068579bf0234c5c796afdf573ebc7784ce68aa6d5e2993548bc1fa9a6.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f9e2e79_d60b_4a35_850a_802623a73248.slice/cri-containerd-e7769e6fb9b1c557781176121f7fe9308869f715a1eda39ade740a40a818c234.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f9e2e79_d60b_4a35_850a_802623a73248.slice/cri-containerd-6c36d014ef46958757d4c316418d3ea887b447629f15136a0ea4f78e0c1d9e35.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7c90124d_ff82_4a91_904e_271ec2b5c41b.slice/cri-containerd-741ff3a9dd04ed347a7612861efe1860481ad71d901e635cd2cd0dd205af3c33.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7c90124d_ff82_4a91_904e_271ec2b5c41b.slice/cri-containerd-6dfe694ed92ceb93cb77d5773d545a0a698776507457aad8e2c8342fc544a1f3.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46cf1f92_c984_4569_a602_f4d4443eef44.slice/cri-containerd-2ab94634fffcc8b4b84060d50ddd461017fe3b66d5ed1ee8ba92741680a55c95.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46cf1f92_c984_4569_a602_f4d4443eef44.slice/cri-containerd-a0e736c970d0151956d164e298112e350d2fa59a4d8723157c49f63465f065be.scope
    530      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31346be6_c643_4c84_9446_b3fc646ae1c9.slice/cri-containerd-d65ab167fcc447baf10afaed3f141cfe86797614877dd6326f166d7202d24e6e.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31346be6_c643_4c84_9446_b3fc646ae1c9.slice/cri-containerd-007f864419e50b4421c4c4b2417857b430e16fafce035e753f6f1d2c2bfa9c75.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf91d10f1_1d09_4c6f_93b3_c32f397e95ed.slice/cri-containerd-071cf3f13ee4a2b7894c2e82916c5d00d4033000b7bc9ee94b921ce1c49c5ef1.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf91d10f1_1d09_4c6f_93b3_c32f397e95ed.slice/cri-containerd-bb6d6cbd8a04d273cb09486ed8057f21d35d8d58bc2fba211d127292e5058c6f.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86a7e438_9be3_4417_b0dc_347c2f117874.slice/cri-containerd-df41713fccb44d631627c4168455c56738eb1af06097674b28e3fcb183004f43.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86a7e438_9be3_4417_b0dc_347c2f117874.slice/cri-containerd-8a2baa21eb364e8ff5403fea0b1f4a97dd7e02a47d199e6997e7c50e33a4159c.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86a7e438_9be3_4417_b0dc_347c2f117874.slice/cri-containerd-22b520ef550e47643a9a534b4359a19ed65056cd3d974730a8a26f5d53739410.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86a7e438_9be3_4417_b0dc_347c2f117874.slice/cri-containerd-dc49ff5a20f03ecbda084534984eed551f5c56687774feeb8e73cf9e748fa83b.scope
    650      cgroup_device   multi                                          
