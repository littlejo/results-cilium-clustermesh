Endpoint ID: 200
Path: /sys/fs/bpf/tc/globals/cilium_policy_00200

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    121969   1401      0        
Allow    Egress      0          ANY          NONE         disabled    17227    187       0        


Endpoint ID: 649
Path: /sys/fs/bpf/tc/globals/cilium_policy_00649

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2055
Path: /sys/fs/bpf/tc/globals/cilium_policy_02055

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1577802   19910     0        
Allow    Ingress     1          ANY          NONE         disabled    19144     225       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2078
Path: /sys/fs/bpf/tc/globals/cilium_policy_02078

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    120202   1378      0        
Allow    Egress      0          ANY          NONE         disabled    16013    172       0        


Endpoint ID: 2285
Path: /sys/fs/bpf/tc/globals/cilium_policy_02285

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    10315020   106614    0        
Allow    Ingress     1          ANY          NONE         disabled    10517894   110956    0        
Allow    Egress      0          ANY          NONE         disabled    12605156   127176    0        


