KEY             VALUE
AgentLiveness   1893386217057
UTimeOffset     3379442736328125
