top - 08:22:51 up 31 min,  0 users,  load average: 0.66, 0.39, 0.24
Tasks:   5 total,   1 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 37.9 us, 44.8 sy,  0.0 ni, 17.2 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4493.4 free,   1173.3 used,   2147.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6455.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1605952 382228  79288 S   6.7   4.8   0:59.63 cilium-+
    618 root      20   0 1240432  16292  11356 S   6.7   0.2   0:00.03 cilium-+
    394 root      20   0 1229744   7240   2924 S   0.0   0.1   0:01.20 cilium-+
    645 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    684 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
