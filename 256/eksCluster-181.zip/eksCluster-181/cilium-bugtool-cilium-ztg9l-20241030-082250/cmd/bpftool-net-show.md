xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 572
ens6(5) clsact/ingress cil_from_netdev-ens6 id 577
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 565
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 558
cilium_host(7) clsact/egress cil_from_host-cilium_host id 553
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 518
lxcae06afd9fd70(12) clsact/ingress cil_from_container-lxcae06afd9fd70 id 544
lxcdd561febc700(14) clsact/ingress cil_from_container-lxcdd561febc700 id 504
lxcf4fb77fea314(18) clsact/ingress cil_from_container-lxcf4fb77fea314 id 628

flow_dissector:

netfilter:

