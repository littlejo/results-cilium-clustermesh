alloc: 121.09MB (126976992 bytes)
total-alloc: 2.36GB (2534508336 bytes)
sys: 333.02MB (349196644 bytes)
lookups: 0
mallocs: 64475151
frees: 63644560
heap-alloc: 121.09MB (126976992 bytes)
heap-sys: 254.66MB (267034624 bytes)
heap-idle: 70.95MB (74391552 bytes)
heap-in-use: 183.72MB (192643072 bytes)
heap-released: 3.72MB (3899392 bytes)
heap-objects: 830591
stack-in-use: 65.31MB (68485120 bytes)
stack-sys: 65.31MB (68485120 bytes)
stack-mspan-inuse: 2.90MB (3045440 bytes)
stack-mspan-sys: 3.97MB (4161600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.02MB (1072489 bytes)
gc-sys: 6.03MB (6325904 bytes)
next-gc: when heap-alloc >= 211.94MB (222239000 bytes)
last-gc: 2024-10-30 08:23:11.352397827 +0000 UTC
gc-pause-total: 17.604181ms
gc-pause: 130142
gc-pause-end: 1730276591352397827
num-gc: 89
num-forced-gc: 0
gc-cpu-fraction: 0.0003821244658087883
enable-gc: true
debug-gc: false
