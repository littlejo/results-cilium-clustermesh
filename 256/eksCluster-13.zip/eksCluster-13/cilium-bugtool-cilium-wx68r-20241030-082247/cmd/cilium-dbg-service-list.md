ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.178.85:443 (active)     
                                          2 => 172.31.241.97:443 (active)     
2    10.100.38.157:443     ClusterIP      1 => 172.31.193.152:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.13.0.179:53 (active)        
                                          2 => 10.13.0.85:53 (active)         
4    10.100.0.10:9153      ClusterIP      1 => 10.13.0.179:9153 (active)      
                                          2 => 10.13.0.85:9153 (active)       
5    10.100.109.244:2379   ClusterIP      1 => 10.13.0.72:2379 (active)       
