key: 65 01 00 00  value: 1c 02 00 00
key: bc 06 00 00  value: 6f 02 00 00
key: dd 0b 00 00  value: 0e 02 00 00
key: 69 0c 00 00  value: 04 02 00 00
Found 4 elements
