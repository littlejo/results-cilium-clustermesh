IP ADDRESS         LOCAL ENDPOINT INFO
172.31.193.152:0   (localhost)                                                                                       
10.13.0.72:0       id=1724  sec_id=477137 flags=0x0000 ifindex=18  mac=16:07:F0:20:C2:BB nodemac=E6:39:A7:74:F6:15   
10.13.0.250:0      (localhost)                                                                                       
10.13.0.179:0      id=3177  sec_id=461033 flags=0x0000 ifindex=14  mac=AA:7A:F4:6C:0B:80 nodemac=F2:DD:C9:E5:EF:4E   
10.13.0.138:0      id=3037  sec_id=4     flags=0x0000 ifindex=10  mac=DE:F3:55:65:69:BD nodemac=A6:5C:F2:A3:AE:CA    
10.13.0.85:0       id=357   sec_id=461033 flags=0x0000 ifindex=12  mac=56:B9:F5:F9:94:51 nodemac=36:92:E1:28:A4:EC   
172.31.210.91:0    (localhost)                                                                                       
