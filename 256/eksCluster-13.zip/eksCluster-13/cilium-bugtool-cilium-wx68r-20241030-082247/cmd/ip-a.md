1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:6b:6a:6a:1f:11 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.193.152/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3096sec preferred_lft 3096sec
    inet6 fe80::86b:6aff:fe6a:1f11/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:27:66:41:8d:35 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.210.91/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::827:66ff:fe41:8d35/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:d3:97:45:93:84 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::18d3:97ff:fe45:9384/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:b8:59:61:a1:de brd ff:ff:ff:ff:ff:ff
    inet 10.13.0.250/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::4cb8:59ff:fe61:a1de/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 02:47:17:7a:e3:d4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::47:17ff:fe7a:e3d4/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:5c:f2:a3:ae:ca brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a45c:f2ff:fea3:aeca/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc6ba53967772f@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:92:e1:28:a4:ec brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::3492:e1ff:fe28:a4ec/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc2df18ea64476@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:dd:c9:e5:ef:4e brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f0dd:c9ff:fee5:ef4e/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcd45de6fe15e8@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:39:a7:74:f6:15 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e439:a7ff:fe74:f615/64 scope link 
       valid_lft forever preferred_lft forever
