{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:26.599Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.193.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:26.599Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.210.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:26.599Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:31.454Z",
  "value": "id=3037  sec_id=4     flags=0x0000 ifindex=10  mac=DE:F3:55:65:69:BD nodemac=A6:5C:F2:A3:AE:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:31.467Z",
  "value": "id=357   sec_id=461033 flags=0x0000 ifindex=12  mac=56:B9:F5:F9:94:51 nodemac=36:92:E1:28:A4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:31.548Z",
  "value": "id=3177  sec_id=461033 flags=0x0000 ifindex=14  mac=AA:7A:F4:6C:0B:80 nodemac=F2:DD:C9:E5:EF:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:31.622Z",
  "value": "id=3037  sec_id=4     flags=0x0000 ifindex=10  mac=DE:F3:55:65:69:BD nodemac=A6:5C:F2:A3:AE:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:31.702Z",
  "value": "id=357   sec_id=461033 flags=0x0000 ifindex=12  mac=56:B9:F5:F9:94:51 nodemac=36:92:E1:28:A4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:49.236Z",
  "value": "id=3177  sec_id=461033 flags=0x0000 ifindex=14  mac=AA:7A:F4:6C:0B:80 nodemac=F2:DD:C9:E5:EF:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:49.237Z",
  "value": "id=3037  sec_id=4     flags=0x0000 ifindex=10  mac=DE:F3:55:65:69:BD nodemac=A6:5C:F2:A3:AE:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:49.238Z",
  "value": "id=357   sec_id=461033 flags=0x0000 ifindex=12  mac=56:B9:F5:F9:94:51 nodemac=36:92:E1:28:A4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:49.268Z",
  "value": "id=830   sec_id=477137 flags=0x0000 ifindex=16  mac=6E:14:A5:8D:4B:E1 nodemac=9A:67:93:1A:6D:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:50.238Z",
  "value": "id=830   sec_id=477137 flags=0x0000 ifindex=16  mac=6E:14:A5:8D:4B:E1 nodemac=9A:67:93:1A:6D:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:50.238Z",
  "value": "id=3037  sec_id=4     flags=0x0000 ifindex=10  mac=DE:F3:55:65:69:BD nodemac=A6:5C:F2:A3:AE:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:50.238Z",
  "value": "id=357   sec_id=461033 flags=0x0000 ifindex=12  mac=56:B9:F5:F9:94:51 nodemac=36:92:E1:28:A4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:50.239Z",
  "value": "id=3177  sec_id=461033 flags=0x0000 ifindex=14  mac=AA:7A:F4:6C:0B:80 nodemac=F2:DD:C9:E5:EF:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:34.148Z",
  "value": "id=1724  sec_id=477137 flags=0x0000 ifindex=18  mac=16:07:F0:20:C2:BB nodemac=E6:39:A7:74:F6:15"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.13.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.046Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.422Z",
  "value": "id=3177  sec_id=461033 flags=0x0000 ifindex=14  mac=AA:7A:F4:6C:0B:80 nodemac=F2:DD:C9:E5:EF:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.423Z",
  "value": "id=1724  sec_id=477137 flags=0x0000 ifindex=18  mac=16:07:F0:20:C2:BB nodemac=E6:39:A7:74:F6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.423Z",
  "value": "id=3037  sec_id=4     flags=0x0000 ifindex=10  mac=DE:F3:55:65:69:BD nodemac=A6:5C:F2:A3:AE:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.424Z",
  "value": "id=357   sec_id=461033 flags=0x0000 ifindex=12  mac=56:B9:F5:F9:94:51 nodemac=36:92:E1:28:A4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.425Z",
  "value": "id=3037  sec_id=4     flags=0x0000 ifindex=10  mac=DE:F3:55:65:69:BD nodemac=A6:5C:F2:A3:AE:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.426Z",
  "value": "id=357   sec_id=461033 flags=0x0000 ifindex=12  mac=56:B9:F5:F9:94:51 nodemac=36:92:E1:28:A4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.426Z",
  "value": "id=3177  sec_id=461033 flags=0x0000 ifindex=14  mac=AA:7A:F4:6C:0B:80 nodemac=F2:DD:C9:E5:EF:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.426Z",
  "value": "id=1724  sec_id=477137 flags=0x0000 ifindex=18  mac=16:07:F0:20:C2:BB nodemac=E6:39:A7:74:F6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.425Z",
  "value": "id=3037  sec_id=4     flags=0x0000 ifindex=10  mac=DE:F3:55:65:69:BD nodemac=A6:5C:F2:A3:AE:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.426Z",
  "value": "id=1724  sec_id=477137 flags=0x0000 ifindex=18  mac=16:07:F0:20:C2:BB nodemac=E6:39:A7:74:F6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.427Z",
  "value": "id=357   sec_id=461033 flags=0x0000 ifindex=12  mac=56:B9:F5:F9:94:51 nodemac=36:92:E1:28:A4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.428Z",
  "value": "id=3177  sec_id=461033 flags=0x0000 ifindex=14  mac=AA:7A:F4:6C:0B:80 nodemac=F2:DD:C9:E5:EF:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:00.425Z",
  "value": "id=1724  sec_id=477137 flags=0x0000 ifindex=18  mac=16:07:F0:20:C2:BB nodemac=E6:39:A7:74:F6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:00.426Z",
  "value": "id=3037  sec_id=4     flags=0x0000 ifindex=10  mac=DE:F3:55:65:69:BD nodemac=A6:5C:F2:A3:AE:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:00.426Z",
  "value": "id=357   sec_id=461033 flags=0x0000 ifindex=12  mac=56:B9:F5:F9:94:51 nodemac=36:92:E1:28:A4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:00.427Z",
  "value": "id=3177  sec_id=461033 flags=0x0000 ifindex=14  mac=AA:7A:F4:6C:0B:80 nodemac=F2:DD:C9:E5:EF:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.426Z",
  "value": "id=3037  sec_id=4     flags=0x0000 ifindex=10  mac=DE:F3:55:65:69:BD nodemac=A6:5C:F2:A3:AE:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.426Z",
  "value": "id=1724  sec_id=477137 flags=0x0000 ifindex=18  mac=16:07:F0:20:C2:BB nodemac=E6:39:A7:74:F6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.426Z",
  "value": "id=357   sec_id=461033 flags=0x0000 ifindex=12  mac=56:B9:F5:F9:94:51 nodemac=36:92:E1:28:A4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.427Z",
  "value": "id=3177  sec_id=461033 flags=0x0000 ifindex=14  mac=AA:7A:F4:6C:0B:80 nodemac=F2:DD:C9:E5:EF:4E"
}

