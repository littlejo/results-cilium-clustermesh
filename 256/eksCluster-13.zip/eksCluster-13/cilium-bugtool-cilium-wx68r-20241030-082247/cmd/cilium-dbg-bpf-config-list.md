KEY             VALUE
AgentLiveness   2348162051972
UTimeOffset     3379441898437500
