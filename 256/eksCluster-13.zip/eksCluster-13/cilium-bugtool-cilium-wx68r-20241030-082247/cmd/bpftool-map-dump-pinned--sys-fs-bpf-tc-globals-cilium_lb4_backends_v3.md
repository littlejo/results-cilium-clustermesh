key: 02 00 00 00  value: ac 1f f1 61 01 bb 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f b2 55 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 0d 00 55 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 0d 00 48 09 4b 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 0d 00 b3 23 c1 00 00  00 00 00 00
key: 04 00 00 00  value: 0a 0d 00 b3 00 35 00 00  00 00 00 00
key: 03 00 00 00  value: ac 1f c1 98 10 94 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 0d 00 55 00 35 00 00  00 00 00 00
Found 8 elements
