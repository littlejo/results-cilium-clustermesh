top - 08:22:49 up 38 min,  0 users,  load average: 0.09, 0.25, 0.20
Tasks:  10 total,   2 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 34.5 us, 55.2 sy,  0.0 ni,  3.4 id,  0.0 wa,  0.0 hi,  6.9 si,  0.0 st
MiB Mem :   7814.2 total,   4458.0 free,   1208.5 used,   2147.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6420.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    744 root      20   0 1244596  21976  14528 S  46.7   0.3   0:00.13 hubble
      1 root      20   0 1606336 399712  78460 S   6.7   5.0   0:57.48 cilium-+
    414 root      20   0 1229744   8164   3904 S   0.0   0.1   0:01.19 cilium-+
    687 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    696 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    706 root      20   0 1240432  16756  11484 S   0.0   0.2   0:00.02 cilium-+
    737 root      20   0    2208    792    716 S   0.0   0.0   0:00.00 timeout
    753 root      20   0    6576   2412   2088 R   0.0   0.0   0:00.00 top
    772 root      20   0       4      4      0 R   0.0   0.0   0:00.00 runc:[2+
    784 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
