CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d30d24d_cb3e_4b5c_9385_5955461afbb7.slice/cri-containerd-f9489ee32e7f9b5a21cbc92e7b59f9f17d5193b122a4bd180bc40458e276ec58.scope
    531      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d30d24d_cb3e_4b5c_9385_5955461afbb7.slice/cri-containerd-19db4fb6942181a8e9161c172aa24afeb6e17cbc09f14b625e22364d009ca4f7.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9d1b6916_02c4_40b4_b2dc_d61ea3d7fd54.slice/cri-containerd-57c6a2b15ee2f78352bbacda87cba5153868c75d233299decf2440fa30fd4cc7.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9d1b6916_02c4_40b4_b2dc_d61ea3d7fd54.slice/cri-containerd-e6318c29e4a0f07c6968174e2ee0d6eb3391b52d140abdb1d009795f8ede3070.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e940cf8_1d40_409c_8b7f_b256d5522b12.slice/cri-containerd-b5083fa9b5454715d3d849d3e19f4bff1c755b1a7bf433ef30804aec26fae02d.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e940cf8_1d40_409c_8b7f_b256d5522b12.slice/cri-containerd-fe8a7a8c3004afd2d5cfde97f64d6d2bed47d4d054fe5fd01846d00bd9a5966b.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5cbab9ab_869c_417c_8122_c6ff038fa253.slice/cri-containerd-586d514b32ff21fce2c09062d2c05dc0ea07ef9d7b1e52601c11bae638717e71.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5cbab9ab_869c_417c_8122_c6ff038fa253.slice/cri-containerd-9ea7047bc7a555dee3ea01b0a113bd48137bb2045fb2e32f4da6442c02a35873.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb6615d3d_b8be_4ed2_8494_12014584cec3.slice/cri-containerd-d44aca82d3e2a4844941eb7eafd11b5e07fd72cfb30833d7158fbe615e9c6bb7.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb6615d3d_b8be_4ed2_8494_12014584cec3.slice/cri-containerd-1c8de3df330a2e9fdf2acbe654cd4915612ef54ecf1afa4bd2d0a2b963e6df09.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5f7f20e7_41e4_4332_8c71_3cfd482aaeb3.slice/cri-containerd-aa15671ac973e13883a5533d06735d297071dc80711cac36d6773dafe554b99c.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5f7f20e7_41e4_4332_8c71_3cfd482aaeb3.slice/cri-containerd-951694f67c61a645fac92ae6aefaef2a88eed044cc79f0770f4a1ef96c716c98.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b2ae801_900e_4738_905d_03ec20ac9e57.slice/cri-containerd-21c28063bb4ac325918afc0b84c93a7f2be2b479197469630eb983a3c3823e4a.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b2ae801_900e_4738_905d_03ec20ac9e57.slice/cri-containerd-f19276e18a8077d445a4b95c41019fe43af4f19e7e251ef05902deabcf62696e.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b2ae801_900e_4738_905d_03ec20ac9e57.slice/cri-containerd-ad93af36637462e3d8fb44c46bf55235a21c64d09a58b947ee078dcba814aca4.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b2ae801_900e_4738_905d_03ec20ac9e57.slice/cri-containerd-7e8aebdd403f17e4a7b07667c94cf426789bab64529ffd412686d94b2635d7b0.scope
    661      cgroup_device   multi                                          
