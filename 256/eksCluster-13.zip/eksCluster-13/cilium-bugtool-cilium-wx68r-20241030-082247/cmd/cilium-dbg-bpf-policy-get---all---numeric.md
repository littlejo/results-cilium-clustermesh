Endpoint ID: 156
Path: /sys/fs/bpf/tc/globals/cilium_policy_00156

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 357
Path: /sys/fs/bpf/tc/globals/cilium_policy_00357

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    175385   2013      0        
Allow    Egress      0          ANY          NONE         disabled    21819    246       0        


Endpoint ID: 1724
Path: /sys/fs/bpf/tc/globals/cilium_policy_01724

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11171895   108983    0        
Allow    Ingress     1          ANY          NONE         disabled    9861076    99865     0        
Allow    Egress      0          ANY          NONE         disabled    10519273   104896    0        


Endpoint ID: 3037
Path: /sys/fs/bpf/tc/globals/cilium_policy_03037

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1640034   20738     0        
Allow    Ingress     1          ANY          NONE         disabled    25932     302       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3177
Path: /sys/fs/bpf/tc/globals/cilium_policy_03177

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176872   2030      0        
Allow    Egress      0          ANY          NONE         disabled    25890    278       0        


