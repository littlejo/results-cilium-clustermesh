REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34037     2687243     677    bpf_overlay.c
Interface                 INGRESS     637539    131792965   1132   bpf_host.c
Success                   EGRESS      13979     1093459     1694   bpf_host.c
Success                   EGRESS      278775    35547206    1308   bpf_lxc.c
Success                   EGRESS      32914     2605486     53     encap.h
Success                   INGRESS     319531    35950488    86     l3.h
Success                   INGRESS     340240    37588318    235    trace.h
Unsupported L3 protocol   EGRESS      41        3022        1492   bpf_lxc.c
