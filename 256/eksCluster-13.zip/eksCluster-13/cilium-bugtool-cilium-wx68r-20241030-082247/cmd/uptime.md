 08:22:49 up 38 min,  0 users,  load average: 0.09, 0.25, 0.20
