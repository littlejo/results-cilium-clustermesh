[
  {
    "containers": [
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b2ae801_900e_4738_905d_03ec20ac9e57.slice/cri-containerd-f19276e18a8077d445a4b95c41019fe43af4f19e7e251ef05902deabcf62696e.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b2ae801_900e_4738_905d_03ec20ac9e57.slice/cri-containerd-7e8aebdd403f17e4a7b07667c94cf426789bab64529ffd412686d94b2635d7b0.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b2ae801_900e_4738_905d_03ec20ac9e57.slice/cri-containerd-21c28063bb4ac325918afc0b84c93a7f2be2b479197469630eb983a3c3823e4a.scope"
      }
    ],
    "ips": [
      "10.13.0.72"
    ],
    "name": "clustermesh-apiserver-64675d99bb-nmb9r",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9d1b6916_02c4_40b4_b2dc_d61ea3d7fd54.slice/cri-containerd-57c6a2b15ee2f78352bbacda87cba5153868c75d233299decf2440fa30fd4cc7.scope"
      }
    ],
    "ips": [
      "10.13.0.179"
    ],
    "name": "coredns-cc6ccd49c-d8tnd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d30d24d_cb3e_4b5c_9385_5955461afbb7.slice/cri-containerd-19db4fb6942181a8e9161c172aa24afeb6e17cbc09f14b625e22364d009ca4f7.scope"
      }
    ],
    "ips": [
      "10.13.0.85"
    ],
    "name": "coredns-cc6ccd49c-6z2d4",
    "namespace": "kube-system"
  }
]

