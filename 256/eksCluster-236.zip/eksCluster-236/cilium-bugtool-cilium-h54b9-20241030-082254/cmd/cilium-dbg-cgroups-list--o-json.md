[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod439780c1_8f2d_4ba7_a7b0_19cea608c10a.slice/cri-containerd-cbcaebd079e47d5756277c14d36de163084079656b98864a5f694655b37850c4.scope"
      }
    ],
    "ips": [
      "10.236.0.141"
    ],
    "name": "coredns-cc6ccd49c-7fgcs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8b3aebf3_b5a8_4547_be3a_880655637381.slice/cri-containerd-2b55788030c420daf277e8586ff4404f50bf1db58d8ff76eff422853d4d85f04.scope"
      }
    ],
    "ips": [
      "10.236.0.109"
    ],
    "name": "coredns-cc6ccd49c-fq5xc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0de6559d_1ca4_4eef_befd_a60645533ec7.slice/cri-containerd-bffdaecaf0860e0ad3ac38388947f3c8ce9eab567c75065ebd043ae21a75e933.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0de6559d_1ca4_4eef_befd_a60645533ec7.slice/cri-containerd-93845ea48dc517252a2ea5768a59ae896896201fc163c5974f3f31ce42693471.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0de6559d_1ca4_4eef_befd_a60645533ec7.slice/cri-containerd-da5bbd59b30940d57386973ca39922c57c24bd83a2a85ec95f70481cd75e51e6.scope"
      }
    ],
    "ips": [
      "10.236.0.94"
    ],
    "name": "clustermesh-apiserver-6fd876c594-rdw8s",
    "namespace": "kube-system"
  }
]

