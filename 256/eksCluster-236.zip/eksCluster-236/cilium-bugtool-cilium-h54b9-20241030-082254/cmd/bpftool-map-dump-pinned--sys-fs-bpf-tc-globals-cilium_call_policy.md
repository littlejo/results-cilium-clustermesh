key: 1d 00 00 00  value: 03 02 00 00
key: be 02 00 00  value: 1e 02 00 00
key: f5 04 00 00  value: 70 02 00 00
key: 62 0c 00 00  value: 0b 02 00 00
Found 4 elements
