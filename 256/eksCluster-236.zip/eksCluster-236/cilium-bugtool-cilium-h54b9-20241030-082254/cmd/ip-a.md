1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:87:66:f3:6b:57 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.134.110/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1943sec preferred_lft 1943sec
    inet6 fe80::487:66ff:fef3:6b57/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a7:b9:d7:6a:f7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.183.31/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4a7:b9ff:fed7:6af7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:a0:2f:21:f6:ce brd ff:ff:ff:ff:ff:ff
    inet6 fe80::48a0:2fff:fe21:f6ce/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:c7:31:1c:f8:4f brd ff:ff:ff:ff:ff:ff
    inet 10.236.0.22/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::f0c7:31ff:fe1c:f84f/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f6:18:3a:50:87:de brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f418:3aff:fe50:87de/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:2c:5e:97:31:28 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::5c2c:5eff:fe97:3128/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcfa822f3d9536@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:3e:a6:52:c7:25 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4c3e:a6ff:fe52:c725/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc271aab2e9e74@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:ed:75:a5:0c:7e brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::64ed:75ff:fea5:c7e/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf40cd4963509@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:b4:86:fa:ad:0b brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::b4b4:86ff:fefa:ad0b/64 scope link 
       valid_lft forever preferred_lft forever
