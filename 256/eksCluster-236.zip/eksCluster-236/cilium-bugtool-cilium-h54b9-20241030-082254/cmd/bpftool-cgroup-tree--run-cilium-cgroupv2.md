CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode915f818_d5c1_4872_ae40_4feb862524e7.slice/cri-containerd-cdc11dfe3b76c227a745f943e5c4632adc08bf2c795eef98e96749b358ecc0fd.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode915f818_d5c1_4872_ae40_4feb862524e7.slice/cri-containerd-1ece97e90d22d2e8b9716f13cd963619c070375feee3c731a58a78fa9a724854.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf9a2fad1_e3ab_456e_9cf8_696e76240460.slice/cri-containerd-73515d405d84781d77aeca4e78630523eeb813d8df118e22203d64495f2b3adc.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf9a2fad1_e3ab_456e_9cf8_696e76240460.slice/cri-containerd-1b73d2a23cfc8ff874606ed5ad884cee4254e2f3de6b12716071e88b36061c82.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8b3aebf3_b5a8_4547_be3a_880655637381.slice/cri-containerd-2b55788030c420daf277e8586ff4404f50bf1db58d8ff76eff422853d4d85f04.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8b3aebf3_b5a8_4547_be3a_880655637381.slice/cri-containerd-0b1be869d9b66739722514885f2b813fa0327f508179233a2b6f7ed09d42c401.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod439780c1_8f2d_4ba7_a7b0_19cea608c10a.slice/cri-containerd-cbcaebd079e47d5756277c14d36de163084079656b98864a5f694655b37850c4.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod439780c1_8f2d_4ba7_a7b0_19cea608c10a.slice/cri-containerd-03c9990971e626196303baee266cce06f0ca2f0efccb5777d80998e5053d7d4a.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a5016a9_b846_4fdf_8505_fce92d2e3543.slice/cri-containerd-2900dd602bba41fb3f50e0acb022ca28ced30bfffc187b4d48e084b6647719d9.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a5016a9_b846_4fdf_8505_fce92d2e3543.slice/cri-containerd-08bc2f338af673615561838c1f1339a4c5ec7f4ada334e59b7f2d6864d240c33.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0de6559d_1ca4_4eef_befd_a60645533ec7.slice/cri-containerd-bffdaecaf0860e0ad3ac38388947f3c8ce9eab567c75065ebd043ae21a75e933.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0de6559d_1ca4_4eef_befd_a60645533ec7.slice/cri-containerd-93845ea48dc517252a2ea5768a59ae896896201fc163c5974f3f31ce42693471.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0de6559d_1ca4_4eef_befd_a60645533ec7.slice/cri-containerd-da5bbd59b30940d57386973ca39922c57c24bd83a2a85ec95f70481cd75e51e6.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0de6559d_1ca4_4eef_befd_a60645533ec7.slice/cri-containerd-139dfb12ca0c0d344f24152e4c0fc331dbb061651f577aba15cb39519b40f918.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podce88939d_0523_49a4_802e_f10cbf0ad660.slice/cri-containerd-6642e6dc23433f1ee8a197f41d54dd449dbb4a3fc1d6141852a0e4cf49c9f4ca.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podce88939d_0523_49a4_802e_f10cbf0ad660.slice/cri-containerd-5d6d14ece4c40c03177253b27aaf61f6a03739e67efe3b56c525e667f76d0bed.scope
    106      cgroup_device   multi                                          
