KEY             VALUE
AgentLiveness   1699059617055
UTimeOffset     3379443179687500
