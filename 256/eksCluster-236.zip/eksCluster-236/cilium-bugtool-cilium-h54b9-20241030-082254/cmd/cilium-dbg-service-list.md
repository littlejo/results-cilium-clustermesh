ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.133.108:443 (active)    
                                         2 => 172.31.231.28:443 (active)     
2    10.100.244.230:443   ClusterIP      1 => 172.31.134.110:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.236.0.109:53 (active)       
                                         2 => 10.236.0.141:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.236.0.109:9153 (active)     
                                         2 => 10.236.0.141:9153 (active)     
5    10.100.182.11:2379   ClusterIP      1 => 10.236.0.94:2379 (active)      
