{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:41.498Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.134.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:41.498Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.183.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:41.498Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:46.083Z",
  "value": "id=3170  sec_id=7767442 flags=0x0000 ifindex=14  mac=D2:9D:12:65:76:D0 nodemac=66:ED:75:A5:0C:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:46.084Z",
  "value": "id=702   sec_id=7767442 flags=0x0000 ifindex=12  mac=36:A3:73:1D:1A:BD nodemac=4E:3E:A6:52:C7:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:46.198Z",
  "value": "id=29    sec_id=4     flags=0x0000 ifindex=10  mac=6E:8B:65:EE:AF:DC nodemac=5E:2C:5E:97:31:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:46.240Z",
  "value": "id=3170  sec_id=7767442 flags=0x0000 ifindex=14  mac=D2:9D:12:65:76:D0 nodemac=66:ED:75:A5:0C:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:46.313Z",
  "value": "id=702   sec_id=7767442 flags=0x0000 ifindex=12  mac=36:A3:73:1D:1A:BD nodemac=4E:3E:A6:52:C7:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:41.985Z",
  "value": "id=702   sec_id=7767442 flags=0x0000 ifindex=12  mac=36:A3:73:1D:1A:BD nodemac=4E:3E:A6:52:C7:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:41.985Z",
  "value": "id=3170  sec_id=7767442 flags=0x0000 ifindex=14  mac=D2:9D:12:65:76:D0 nodemac=66:ED:75:A5:0C:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:41.985Z",
  "value": "id=29    sec_id=4     flags=0x0000 ifindex=10  mac=6E:8B:65:EE:AF:DC nodemac=5E:2C:5E:97:31:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:42.016Z",
  "value": "id=119   sec_id=7766085 flags=0x0000 ifindex=16  mac=36:2B:54:3E:77:23 nodemac=82:5D:16:3C:E4:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:42.985Z",
  "value": "id=3170  sec_id=7767442 flags=0x0000 ifindex=14  mac=D2:9D:12:65:76:D0 nodemac=66:ED:75:A5:0C:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:42.985Z",
  "value": "id=702   sec_id=7767442 flags=0x0000 ifindex=12  mac=36:A3:73:1D:1A:BD nodemac=4E:3E:A6:52:C7:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:42.986Z",
  "value": "id=119   sec_id=7766085 flags=0x0000 ifindex=16  mac=36:2B:54:3E:77:23 nodemac=82:5D:16:3C:E4:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:42.986Z",
  "value": "id=29    sec_id=4     flags=0x0000 ifindex=10  mac=6E:8B:65:EE:AF:DC nodemac=5E:2C:5E:97:31:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.331Z",
  "value": "id=1269  sec_id=7766085 flags=0x0000 ifindex=18  mac=C2:5B:32:6B:45:82 nodemac=B6:B4:86:FA:AD:0B"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.236.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.695Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:05.756Z",
  "value": "id=702   sec_id=7767442 flags=0x0000 ifindex=12  mac=36:A3:73:1D:1A:BD nodemac=4E:3E:A6:52:C7:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:05.758Z",
  "value": "id=3170  sec_id=7767442 flags=0x0000 ifindex=14  mac=D2:9D:12:65:76:D0 nodemac=66:ED:75:A5:0C:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:05.759Z",
  "value": "id=29    sec_id=4     flags=0x0000 ifindex=10  mac=6E:8B:65:EE:AF:DC nodemac=5E:2C:5E:97:31:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:05.759Z",
  "value": "id=1269  sec_id=7766085 flags=0x0000 ifindex=18  mac=C2:5B:32:6B:45:82 nodemac=B6:B4:86:FA:AD:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:06.751Z",
  "value": "id=29    sec_id=4     flags=0x0000 ifindex=10  mac=6E:8B:65:EE:AF:DC nodemac=5E:2C:5E:97:31:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:06.751Z",
  "value": "id=1269  sec_id=7766085 flags=0x0000 ifindex=18  mac=C2:5B:32:6B:45:82 nodemac=B6:B4:86:FA:AD:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:06.752Z",
  "value": "id=3170  sec_id=7767442 flags=0x0000 ifindex=14  mac=D2:9D:12:65:76:D0 nodemac=66:ED:75:A5:0C:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:06.752Z",
  "value": "id=702   sec_id=7767442 flags=0x0000 ifindex=12  mac=36:A3:73:1D:1A:BD nodemac=4E:3E:A6:52:C7:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:07.750Z",
  "value": "id=1269  sec_id=7766085 flags=0x0000 ifindex=18  mac=C2:5B:32:6B:45:82 nodemac=B6:B4:86:FA:AD:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:07.750Z",
  "value": "id=702   sec_id=7767442 flags=0x0000 ifindex=12  mac=36:A3:73:1D:1A:BD nodemac=4E:3E:A6:52:C7:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:07.751Z",
  "value": "id=3170  sec_id=7767442 flags=0x0000 ifindex=14  mac=D2:9D:12:65:76:D0 nodemac=66:ED:75:A5:0C:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:07.751Z",
  "value": "id=29    sec_id=4     flags=0x0000 ifindex=10  mac=6E:8B:65:EE:AF:DC nodemac=5E:2C:5E:97:31:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:08.750Z",
  "value": "id=3170  sec_id=7767442 flags=0x0000 ifindex=14  mac=D2:9D:12:65:76:D0 nodemac=66:ED:75:A5:0C:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:08.751Z",
  "value": "id=29    sec_id=4     flags=0x0000 ifindex=10  mac=6E:8B:65:EE:AF:DC nodemac=5E:2C:5E:97:31:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:08.751Z",
  "value": "id=1269  sec_id=7766085 flags=0x0000 ifindex=18  mac=C2:5B:32:6B:45:82 nodemac=B6:B4:86:FA:AD:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.236.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:08.752Z",
  "value": "id=702   sec_id=7767442 flags=0x0000 ifindex=12  mac=36:A3:73:1D:1A:BD nodemac=4E:3E:A6:52:C7:25"
}

