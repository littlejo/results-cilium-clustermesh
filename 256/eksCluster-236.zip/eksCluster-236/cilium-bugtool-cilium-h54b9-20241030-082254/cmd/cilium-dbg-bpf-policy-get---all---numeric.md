Endpoint ID: 29
Path: /sys/fs/bpf/tc/globals/cilium_policy_00029

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1655678   20922     0        
Allow    Ingress     1          ANY          NONE         disabled    16970     199       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 702
Path: /sys/fs/bpf/tc/globals/cilium_policy_00702

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    111454   1274      0        
Allow    Egress      0          ANY          NONE         disabled    16570    178       0        


Endpoint ID: 1269
Path: /sys/fs/bpf/tc/globals/cilium_policy_01269

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11471750   113178    0        
Allow    Ingress     1          ANY          NONE         disabled    9059964    94377     0        
Allow    Egress      0          ANY          NONE         disabled    11855843   117414    0        


Endpoint ID: 1438
Path: /sys/fs/bpf/tc/globals/cilium_policy_01438

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3170
Path: /sys/fs/bpf/tc/globals/cilium_policy_03170

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    111784   1279      0        
Allow    Egress      0          ANY          NONE         disabled    16089    175       0        


