IP ADDRESS         LOCAL ENDPOINT INFO
10.236.0.141:0     id=702   sec_id=7767442 flags=0x0000 ifindex=12  mac=36:A3:73:1D:1A:BD nodemac=4E:3E:A6:52:C7:25   
172.31.183.31:0    (localhost)                                                                                        
172.31.134.110:0   (localhost)                                                                                        
10.236.0.109:0     id=3170  sec_id=7767442 flags=0x0000 ifindex=14  mac=D2:9D:12:65:76:D0 nodemac=66:ED:75:A5:0C:7E   
10.236.0.94:0      id=1269  sec_id=7766085 flags=0x0000 ifindex=18  mac=C2:5B:32:6B:45:82 nodemac=B6:B4:86:FA:AD:0B   
10.236.0.22:0      (localhost)                                                                                        
10.236.0.21:0      id=29    sec_id=4     flags=0x0000 ifindex=10  mac=6E:8B:65:EE:AF:DC nodemac=5E:2C:5E:97:31:28     
