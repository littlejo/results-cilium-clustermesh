alloc: 102.36MB (107332832 bytes)
total-alloc: 2.14GB (2299604024 bytes)
sys: 328.89MB (344871268 bytes)
lookups: 0
mallocs: 61789117
frees: 61111744
heap-alloc: 102.36MB (107332832 bytes)
heap-sys: 256.09MB (268533760 bytes)
heap-idle: 93.98MB (98549760 bytes)
heap-in-use: 162.11MB (169984000 bytes)
heap-released: 3.99MB (4186112 bytes)
heap-objects: 677373
stack-in-use: 59.91MB (62816256 bytes)
stack-sys: 59.91MB (62816256 bytes)
stack-mspan-inuse: 2.70MB (2835520 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.04MB (1095505 bytes)
gc-sys: 6.09MB (6380984 bytes)
next-gc: when heap-alloc >= 226.54MB (237539528 bytes)
last-gc: 2024-10-30 08:23:25.967204473 +0000 UTC
gc-pause-total: 9.916055ms
gc-pause: 147612
gc-pause-end: 1730276605967204473
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.00052498999232235
enable-gc: true
debug-gc: false
