filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc2068904aa254 direct-action not_in_hw id 611 tag 0c9257b60c0d7ba6 jited 
