{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:20.404Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.141.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:20.404Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.146.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:20.404Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.123Z",
  "value": "id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=5E:E3:07:39:DA:45 nodemac=A2:DB:B0:68:E2:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.127Z",
  "value": "id=415   sec_id=1505428 flags=0x0000 ifindex=12  mac=22:D8:4C:D1:45:BF nodemac=62:8D:3C:4F:EC:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.176Z",
  "value": "id=3140  sec_id=1505428 flags=0x0000 ifindex=14  mac=C2:13:18:33:57:D5 nodemac=7E:70:7E:23:16:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.181Z",
  "value": "id=415   sec_id=1505428 flags=0x0000 ifindex=12  mac=22:D8:4C:D1:45:BF nodemac=62:8D:3C:4F:EC:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.192Z",
  "value": "id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=5E:E3:07:39:DA:45 nodemac=A2:DB:B0:68:E2:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:29.499Z",
  "value": "id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=5E:E3:07:39:DA:45 nodemac=A2:DB:B0:68:E2:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:29.499Z",
  "value": "id=415   sec_id=1505428 flags=0x0000 ifindex=12  mac=22:D8:4C:D1:45:BF nodemac=62:8D:3C:4F:EC:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:29.499Z",
  "value": "id=3140  sec_id=1505428 flags=0x0000 ifindex=14  mac=C2:13:18:33:57:D5 nodemac=7E:70:7E:23:16:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:29.531Z",
  "value": "id=744   sec_id=1503317 flags=0x0000 ifindex=16  mac=6E:EA:A0:6C:5B:4B nodemac=7E:56:3E:A0:B4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:30.499Z",
  "value": "id=744   sec_id=1503317 flags=0x0000 ifindex=16  mac=6E:EA:A0:6C:5B:4B nodemac=7E:56:3E:A0:B4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:30.499Z",
  "value": "id=415   sec_id=1505428 flags=0x0000 ifindex=12  mac=22:D8:4C:D1:45:BF nodemac=62:8D:3C:4F:EC:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:30.500Z",
  "value": "id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=5E:E3:07:39:DA:45 nodemac=A2:DB:B0:68:E2:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:30.500Z",
  "value": "id=3140  sec_id=1505428 flags=0x0000 ifindex=14  mac=C2:13:18:33:57:D5 nodemac=7E:70:7E:23:16:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:30.898Z",
  "value": "id=539   sec_id=1503317 flags=0x0000 ifindex=18  mac=22:0A:6A:B0:B8:5B nodemac=66:54:4B:A1:2A:CD"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.44.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.492Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:23.177Z",
  "value": "id=539   sec_id=1503317 flags=0x0000 ifindex=18  mac=22:0A:6A:B0:B8:5B nodemac=66:54:4B:A1:2A:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:23.178Z",
  "value": "id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=5E:E3:07:39:DA:45 nodemac=A2:DB:B0:68:E2:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:23.179Z",
  "value": "id=415   sec_id=1505428 flags=0x0000 ifindex=12  mac=22:D8:4C:D1:45:BF nodemac=62:8D:3C:4F:EC:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:23.179Z",
  "value": "id=3140  sec_id=1505428 flags=0x0000 ifindex=14  mac=C2:13:18:33:57:D5 nodemac=7E:70:7E:23:16:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:24.177Z",
  "value": "id=539   sec_id=1503317 flags=0x0000 ifindex=18  mac=22:0A:6A:B0:B8:5B nodemac=66:54:4B:A1:2A:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:24.180Z",
  "value": "id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=5E:E3:07:39:DA:45 nodemac=A2:DB:B0:68:E2:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:24.180Z",
  "value": "id=415   sec_id=1505428 flags=0x0000 ifindex=12  mac=22:D8:4C:D1:45:BF nodemac=62:8D:3C:4F:EC:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:24.181Z",
  "value": "id=3140  sec_id=1505428 flags=0x0000 ifindex=14  mac=C2:13:18:33:57:D5 nodemac=7E:70:7E:23:16:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:25.191Z",
  "value": "id=415   sec_id=1505428 flags=0x0000 ifindex=12  mac=22:D8:4C:D1:45:BF nodemac=62:8D:3C:4F:EC:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:25.191Z",
  "value": "id=3140  sec_id=1505428 flags=0x0000 ifindex=14  mac=C2:13:18:33:57:D5 nodemac=7E:70:7E:23:16:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:25.191Z",
  "value": "id=539   sec_id=1503317 flags=0x0000 ifindex=18  mac=22:0A:6A:B0:B8:5B nodemac=66:54:4B:A1:2A:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:25.192Z",
  "value": "id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=5E:E3:07:39:DA:45 nodemac=A2:DB:B0:68:E2:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:26.191Z",
  "value": "id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=5E:E3:07:39:DA:45 nodemac=A2:DB:B0:68:E2:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:26.191Z",
  "value": "id=415   sec_id=1505428 flags=0x0000 ifindex=12  mac=22:D8:4C:D1:45:BF nodemac=62:8D:3C:4F:EC:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:26.191Z",
  "value": "id=539   sec_id=1503317 flags=0x0000 ifindex=18  mac=22:0A:6A:B0:B8:5B nodemac=66:54:4B:A1:2A:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:26.191Z",
  "value": "id=3140  sec_id=1505428 flags=0x0000 ifindex=14  mac=C2:13:18:33:57:D5 nodemac=7E:70:7E:23:16:CC"
}

