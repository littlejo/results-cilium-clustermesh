top - 08:23:03 up 38 min,  0 users,  load average: 0.11, 0.18, 0.16
Tasks:  12 total,   2 running,   9 sleeping,   0 stopped,   1 zombie
%Cpu(s): 61.8 us, 38.2 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4404.1 free,   1264.5 used,   2145.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6364.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606272 380184  78596 S  41.2   4.8   0:48.29 cilium-+
    393 root      20   0 1229744   6792   2864 S   0.0   0.1   0:01.22 cilium-+
    601 root      20   0 1240432  16656  11484 S   0.0   0.2   0:00.02 cilium-+
    618 root      20   0    2208    780    700 S   0.0   0.0   0:00.00 timeout
    636 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    641 root      20   0 1243764  17680  12732 S   0.0   0.2   0:00.00 hubble
    644 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
    645 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    665 root      20   0    6576   2420   2092 R   0.0   0.0   0:00.00 top
    692 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    705 root      20   0       0      0      0 Z   0.0   0.0   0:00.00 bpftool
    707 root      20   0 1240432  16656  11484 R   0.0   0.2   0:00.00 cilium-+
