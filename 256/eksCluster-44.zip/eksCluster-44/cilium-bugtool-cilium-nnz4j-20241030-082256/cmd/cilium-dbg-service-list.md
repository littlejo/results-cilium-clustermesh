ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.182.222:443 (active)    
                                        2 => 172.31.199.136:443 (active)    
2    10.100.191.38:443   ClusterIP      1 => 172.31.146.155:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.44.0.223:53 (active)        
                                        2 => 10.44.0.157:53 (active)        
4    10.100.0.10:9153    ClusterIP      1 => 10.44.0.223:9153 (active)      
                                        2 => 10.44.0.157:9153 (active)      
5    10.100.25.29:2379   ClusterIP      1 => 10.44.0.185:2379 (active)      
