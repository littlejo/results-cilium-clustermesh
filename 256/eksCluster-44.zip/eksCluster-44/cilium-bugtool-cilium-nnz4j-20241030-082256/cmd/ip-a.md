1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:56:cc:02:62:d9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.146.155/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3092sec preferred_lft 3092sec
    inet6 fe80::456:ccff:fe02:62d9/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ea:e9:8f:b3:11 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.141.62/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4ea:e9ff:fe8f:b311/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:5f:10:cc:1b:26 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2c5f:10ff:fecc:1b26/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:c9:0a:38:80:b7 brd ff:ff:ff:ff:ff:ff
    inet 10.44.0.86/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::38c9:aff:fe38:80b7/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ae:50:b9:b8:dc:13 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ac50:b9ff:feb8:dc13/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:db:b0:68:e2:75 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a0db:b0ff:fe68:e275/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc65f0f288a8b8@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:8d:3c:4f:ec:ea brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::608d:3cff:fe4f:ecea/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcb695a331430e@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:70:7e:23:16:cc brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::7c70:7eff:fe23:16cc/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc2068904aa254@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:54:4b:a1:2a:cd brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::6454:4bff:fea1:2acd/64 scope link 
       valid_lft forever preferred_lft forever
