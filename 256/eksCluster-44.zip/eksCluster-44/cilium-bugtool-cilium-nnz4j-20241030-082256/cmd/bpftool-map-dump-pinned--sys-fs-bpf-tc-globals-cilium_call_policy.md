key: 9f 01 00 00  value: 12 02 00 00
key: 1b 02 00 00  value: 62 02 00 00
key: 93 0a 00 00  value: 22 02 00 00
key: 44 0c 00 00  value: 17 02 00 00
Found 4 elements
