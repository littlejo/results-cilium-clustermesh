REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34310     2709352     677    bpf_overlay.c
Interface                 INGRESS     623389    130028411   1132   bpf_host.c
Success                   EGRESS      13795     1081283     1694   bpf_host.c
Success                   EGRESS      23524     3728030     86     l3.h
Success                   EGRESS      264690    33545495    1308   bpf_lxc.c
Success                   EGRESS      32920     2611590     53     encap.h
Success                   INGRESS     302434    33951259    86     l3.h
Success                   INGRESS     347124    39351404    235    trace.h
Unsupported L3 protocol   EGRESS      43        3202        1492   bpf_lxc.c
