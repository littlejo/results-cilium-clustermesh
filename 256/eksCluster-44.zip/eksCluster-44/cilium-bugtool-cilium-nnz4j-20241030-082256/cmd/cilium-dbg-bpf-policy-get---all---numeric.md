Endpoint ID: 320
Path: /sys/fs/bpf/tc/globals/cilium_policy_00320

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 415
Path: /sys/fs/bpf/tc/globals/cilium_policy_00415

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    664355   5953      0        
Allow    Ingress     1          ANY          NONE         disabled    179710   2066      0        
Allow    Egress      0          ANY          NONE         disabled    126481   1221      0        


Endpoint ID: 539
Path: /sys/fs/bpf/tc/globals/cilium_policy_00539

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11395406   111393    0        
Allow    Ingress     1          ANY          NONE         disabled    9017224    94470     0        
Allow    Egress      0          ANY          NONE         disabled    10755273   107570    0        


Endpoint ID: 2707
Path: /sys/fs/bpf/tc/globals/cilium_policy_02707

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1675749   21212     0        
Allow    Ingress     1          ANY          NONE         disabled    26396     307       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3140
Path: /sys/fs/bpf/tc/globals/cilium_policy_03140

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    645671   5809      0        
Allow    Ingress     1          ANY          NONE         disabled    179842   2068      0        
Allow    Egress      0          ANY          NONE         disabled    125129   1209      0        


