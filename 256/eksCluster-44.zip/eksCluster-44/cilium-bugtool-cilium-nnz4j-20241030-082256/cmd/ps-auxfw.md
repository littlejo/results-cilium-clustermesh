USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         618  0.0  0.0  13060  1228 ?        R    08:23   0:00 /usr/sbin/runc init
root         601  0.0  0.2 1240432 16656 ?       Ssl  08:23   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         619  0.0  0.0      0     0 ?        Z    08:23   0:00  \_ [cat] <defunct>
root         620  0.0  0.0   6408  1648 ?        R    08:23   0:00  \_ ps auxfw
root           1  2.6  4.7 1606272 380184 ?      Ssl  07:52   0:48 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.0 1229744 6792 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
