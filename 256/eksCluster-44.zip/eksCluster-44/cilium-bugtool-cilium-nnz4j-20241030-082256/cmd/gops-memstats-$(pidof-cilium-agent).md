alloc: 155.74MB (163304144 bytes)
total-alloc: 2.27GB (2441482040 bytes)
sys: 324.96MB (340742500 bytes)
lookups: 0
mallocs: 63859011
frees: 62205805
heap-alloc: 155.74MB (163304144 bytes)
heap-sys: 247.16MB (259170304 bytes)
heap-idle: 69.17MB (72531968 bytes)
heap-in-use: 177.99MB (186638336 bytes)
heap-released: 2.47MB (2588672 bytes)
heap-objects: 1653206
stack-in-use: 64.81MB (67960832 bytes)
stack-sys: 64.81MB (67960832 bytes)
stack-mspan-inuse: 3.02MB (3162560 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.02MB (1072017 bytes)
gc-sys: 6.19MB (6485480 bytes)
next-gc: when heap-alloc >= 213.78MB (224161096 bytes)
last-gc: 2024-10-30 08:23:07.812083867 +0000 UTC
gc-pause-total: 19.159758ms
gc-pause: 218186
gc-pause-end: 1730276587812083867
num-gc: 88
num-forced-gc: 0
gc-cpu-fraction: 0.0003228540011024143
enable-gc: true
debug-gc: false
