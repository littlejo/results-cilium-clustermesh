CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf6dc9fad_5bc5_446f_8dee_b70f65b0c2e1.slice/cri-containerd-9424be3ad6c47470592d3a05c960d008f442e0dc79e3383ae37e833f6c60e2ac.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf6dc9fad_5bc5_446f_8dee_b70f65b0c2e1.slice/cri-containerd-080ad7cca4498d3fcf930d90fd447e2ec51b5aca276e95a1a9c1be5d324ad89c.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfc63e7cf_7b9b_4a9d_ba40_0345c1ae519b.slice/cri-containerd-0a623e2675dd5dbae35a7b2a381f31ce38b873ee0d3cb177d406d538953c1f0f.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfc63e7cf_7b9b_4a9d_ba40_0345c1ae519b.slice/cri-containerd-2435abe879d70a8d84c8c0cf4d673a3775db099d3e7098b4c2338f26ac79130c.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a27553d_250c_4117_b4e6_a3db01739b9f.slice/cri-containerd-74d04abcfe2d27b296fa76b886b62600e1bfc9754e6fff2d2553143e03dccbea.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a27553d_250c_4117_b4e6_a3db01739b9f.slice/cri-containerd-1bc422e95a316d813acc0e7b09b3d85787cd2354aff0ee03baad70dd4a7d7800.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfa050824_edc1_454a_96e0_c27512e6974e.slice/cri-containerd-9176ca1afe292989cfbc76d7f7dd10b20ce8f8295e7ceddd8f7919032c2c0f70.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfa050824_edc1_454a_96e0_c27512e6974e.slice/cri-containerd-b4171fa6eb1df6d3b193805a1794ae777d9139e4d25748488870734daf057a77.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod90ca492d_f51c_4c15_a704_58fe6ed42e95.slice/cri-containerd-c412aff9c003e51e09203e4c1a52390c42a227ec7b3053bc2b4bf57f722a9676.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod90ca492d_f51c_4c15_a704_58fe6ed42e95.slice/cri-containerd-58b6fc87f3b1dbb7cb254a5779fef2e8c9bb403aa8cf7bb71eaea8696539b064.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e0e8ede_8d14_46ca_8ca1_98aef5393b7d.slice/cri-containerd-f8f471ef3e041155241a07d3a27e11c9c170f455f5af6e65c8aac508ad285dcb.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e0e8ede_8d14_46ca_8ca1_98aef5393b7d.slice/cri-containerd-cc5f064652cf93720f09b5a3193cd7228382dfbd89bcdb3acb1e414a6b07acf2.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e0e8ede_8d14_46ca_8ca1_98aef5393b7d.slice/cri-containerd-09bd49ef4007afca143a708226bc0e64d64824dd3e6230e8b44cdb2410a85cdc.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e0e8ede_8d14_46ca_8ca1_98aef5393b7d.slice/cri-containerd-50b9405ffa6613a4fd218cae4113b19a0a7f7651d9ce66a8418b7b188ec412ec.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc35d221f_29c0_43b5_8ba3_6777bc56ad95.slice/cri-containerd-57281412d411104247e35b67c6a24ca5438e50667aad33b64c549bc04b869351.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc35d221f_29c0_43b5_8ba3_6777bc56ad95.slice/cri-containerd-fb6853e9e28349035fd80ac9646693047bb2f8ed1cba61246026843c2472fd30.scope
    87       cgroup_device   multi                                          
