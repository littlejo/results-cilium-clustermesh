IP ADDRESS         LOCAL ENDPOINT INFO
10.44.0.185:0      id=539   sec_id=1503317 flags=0x0000 ifindex=18  mac=22:0A:6A:B0:B8:5B nodemac=66:54:4B:A1:2A:CD   
172.31.141.62:0    (localhost)                                                                                        
10.44.0.157:0      id=3140  sec_id=1505428 flags=0x0000 ifindex=14  mac=C2:13:18:33:57:D5 nodemac=7E:70:7E:23:16:CC   
10.44.0.81:0       id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=5E:E3:07:39:DA:45 nodemac=A2:DB:B0:68:E2:75     
10.44.0.223:0      id=415   sec_id=1505428 flags=0x0000 ifindex=12  mac=22:D8:4C:D1:45:BF nodemac=62:8D:3C:4F:EC:EA   
10.44.0.86:0       (localhost)                                                                                        
172.31.146.155:0   (localhost)                                                                                        
