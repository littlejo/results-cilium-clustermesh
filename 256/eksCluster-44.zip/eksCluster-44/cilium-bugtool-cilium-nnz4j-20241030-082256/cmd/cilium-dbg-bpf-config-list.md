KEY             VALUE
AgentLiveness   2350964097815
UTimeOffset     3379441921875000
