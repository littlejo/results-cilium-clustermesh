[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf6dc9fad_5bc5_446f_8dee_b70f65b0c2e1.slice/cri-containerd-080ad7cca4498d3fcf930d90fd447e2ec51b5aca276e95a1a9c1be5d324ad89c.scope"
      }
    ],
    "ips": [
      "10.44.0.157"
    ],
    "name": "coredns-cc6ccd49c-jx9g7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfc63e7cf_7b9b_4a9d_ba40_0345c1ae519b.slice/cri-containerd-0a623e2675dd5dbae35a7b2a381f31ce38b873ee0d3cb177d406d538953c1f0f.scope"
      }
    ],
    "ips": [
      "10.44.0.223"
    ],
    "name": "coredns-cc6ccd49c-gz86d",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e0e8ede_8d14_46ca_8ca1_98aef5393b7d.slice/cri-containerd-cc5f064652cf93720f09b5a3193cd7228382dfbd89bcdb3acb1e414a6b07acf2.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e0e8ede_8d14_46ca_8ca1_98aef5393b7d.slice/cri-containerd-09bd49ef4007afca143a708226bc0e64d64824dd3e6230e8b44cdb2410a85cdc.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e0e8ede_8d14_46ca_8ca1_98aef5393b7d.slice/cri-containerd-f8f471ef3e041155241a07d3a27e11c9c170f455f5af6e65c8aac508ad285dcb.scope"
      }
    ],
    "ips": [
      "10.44.0.185"
    ],
    "name": "clustermesh-apiserver-85c468447-2qczv",
    "namespace": "kube-system"
  }
]

