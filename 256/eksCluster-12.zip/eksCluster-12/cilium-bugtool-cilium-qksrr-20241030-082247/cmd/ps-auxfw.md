USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         685  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         678  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         662  0.0  0.2 1240432 16544 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         703  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         704  0.0  0.2 1240432 16544 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         658  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         638  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         632  0.0  0.0 1228744 3656 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  2.5  4.7 1606144 379584 ?      Ssl  07:52   0:46 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.1 1229744 8228 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
