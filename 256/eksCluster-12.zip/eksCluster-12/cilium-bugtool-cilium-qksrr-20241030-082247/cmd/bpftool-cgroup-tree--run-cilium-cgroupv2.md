CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod05eacbdd_c2c6_4989_aa12_0aa84249d576.slice/cri-containerd-9dd598fd735fd07a5288ca4420679a92159a18a6226638313defc795c0a712e0.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod05eacbdd_c2c6_4989_aa12_0aa84249d576.slice/cri-containerd-4807820e9ce1e14fc116f6df5bc3ace86b8d6d362cff211fa24bc6ff0052eff8.scope
    547      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod358c660c_0652_42d1_aa83_f3620c42cdc8.slice/cri-containerd-9ef05d3df18b9f5f883040416600b9a91e522b43e141bf593c25f8c8c72d6646.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod358c660c_0652_42d1_aa83_f3620c42cdc8.slice/cri-containerd-c583dd278f1f4d193107a7823d3559e7ce789a4c35a90cc98b57fef38b05f3ee.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb74d8f60_f8a9_413a_90c1_39b787a666d0.slice/cri-containerd-0824cf522cc5fed20a372f3f904e7c594319931111ba5b0912daaa58eacf60df.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb74d8f60_f8a9_413a_90c1_39b787a666d0.slice/cri-containerd-f2d236fdd1e209735145483276eb866ea8dbc654f6b6c148b55e6d0accc094e6.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda3cca98b_e683_464e_8924_9ee4a833d358.slice/cri-containerd-5a1d2290a1aa55ec571fe99a495986f367a41d222a90a991eeee950e72eaa839.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda3cca98b_e683_464e_8924_9ee4a833d358.slice/cri-containerd-ac5862329ba0830af24149b74aaf7435f02472570f384f5e19fb3d829079cc23.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f6851ce_f7ce_405b_83e5_59931c1eaa56.slice/cri-containerd-a7014b958e5d56ca84fa14c0eb3933b75f0c7a7efde09ccaa9cf7da132c0ae5c.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f6851ce_f7ce_405b_83e5_59931c1eaa56.slice/cri-containerd-69c04b6cb4ef9ff86d1f6a020ce185ec3f32417ad7d0b1e385a74349906046ce.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f6851ce_f7ce_405b_83e5_59931c1eaa56.slice/cri-containerd-47574f50b7caa9d16f456a6c5bbb74d1e3669856df1f1e1c802efe7f9af9b806.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f6851ce_f7ce_405b_83e5_59931c1eaa56.slice/cri-containerd-847bb9e849fce2bc45796428933d502447a882ada6ebee9b7e815f56625eabe6.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode4b19085_de0c_4f3d_982b_22f080affaf4.slice/cri-containerd-4daa764560d68f2e7f99771cf66312c749f6406883a62ab4c11a7d2257aaeb99.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode4b19085_de0c_4f3d_982b_22f080affaf4.slice/cri-containerd-bdfc213da676ac8df1ab3698ac248603ea547b29d2e62dbe6300ba3ccce6da23.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddaa1be99_a536_4705_bbd8_f19377edbc32.slice/cri-containerd-31091612a4cea9c577113b23b011e14fc0f6c46c19b536521e3eda7fe98e1a9b.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddaa1be99_a536_4705_bbd8_f19377edbc32.slice/cri-containerd-da356e29d32155636c62cdf43a958ef667d8e17073ee1cee0edccc8fa2dcacdd.scope
    94       cgroup_device   multi                                          
