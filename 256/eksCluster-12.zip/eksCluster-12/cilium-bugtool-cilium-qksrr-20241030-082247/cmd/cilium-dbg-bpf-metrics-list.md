REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     33997     2684471     677    bpf_overlay.c
Interface                 INGRESS     623675    130164745   1132   bpf_host.c
Success                   EGRESS      13880     1086013     1694   bpf_host.c
Success                   EGRESS      264817    33486569    1308   bpf_lxc.c
Success                   EGRESS      33007     2610722     53     encap.h
Success                   INGRESS     306924    34489027    86     l3.h
Success                   INGRESS     327565    36122133    235    trace.h
Unsupported L3 protocol   EGRESS      41        3022        1492   bpf_lxc.c
