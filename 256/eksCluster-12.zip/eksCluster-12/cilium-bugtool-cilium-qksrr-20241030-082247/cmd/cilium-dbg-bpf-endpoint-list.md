IP ADDRESS         LOCAL ENDPOINT INFO
172.31.150.159:0   (localhost)                                                                                       
10.12.0.158:0      id=1732  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4F:0C:7F:FD:C7 nodemac=C2:1D:C9:6F:FE:FF    
10.12.0.163:0      id=831   sec_id=431579 flags=0x0000 ifindex=14  mac=72:C5:81:6F:7B:A1 nodemac=2E:0D:EA:82:2D:C7   
10.12.0.102:0      id=17    sec_id=431579 flags=0x0000 ifindex=12  mac=CE:9F:E3:D4:A8:94 nodemac=AA:46:02:E6:F1:D7   
172.31.151.115:0   (localhost)                                                                                       
10.12.0.231:0      (localhost)                                                                                       
10.12.0.106:0      id=583   sec_id=433695 flags=0x0000 ifindex=18  mac=5E:4C:C6:79:1B:3B nodemac=D2:BF:F3:EA:8B:5F   
