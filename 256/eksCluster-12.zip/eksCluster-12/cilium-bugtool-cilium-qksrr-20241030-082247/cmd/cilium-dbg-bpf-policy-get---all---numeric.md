Endpoint ID: 17
Path: /sys/fs/bpf/tc/globals/cilium_policy_00017

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    178316   2052      0        
Allow    Egress      0          ANY          NONE         disabled    21877    246       0        


Endpoint ID: 583
Path: /sys/fs/bpf/tc/globals/cilium_policy_00583

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11355502   111995    0        
Allow    Ingress     1          ANY          NONE         disabled    9632104    100995    0        
Allow    Egress      0          ANY          NONE         disabled    11766328   116343    0        


Endpoint ID: 831
Path: /sys/fs/bpf/tc/globals/cilium_policy_00831

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    177392   2038      0        
Allow    Egress      0          ANY          NONE         disabled    21408    241       0        


Endpoint ID: 1217
Path: /sys/fs/bpf/tc/globals/cilium_policy_01217

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1732
Path: /sys/fs/bpf/tc/globals/cilium_policy_01732

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1635536   20672     0        
Allow    Ingress     1          ANY          NONE         disabled    25800     300       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


