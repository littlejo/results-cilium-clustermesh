 08:22:48 up 38 min,  0 users,  load average: 0.68, 0.35, 0.21
