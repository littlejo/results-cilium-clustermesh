KEY             VALUE
AgentLiveness   2325480039945
UTimeOffset     3379441941406250
