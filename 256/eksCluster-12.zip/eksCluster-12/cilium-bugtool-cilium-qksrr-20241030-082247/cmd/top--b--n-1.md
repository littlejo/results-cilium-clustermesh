top - 08:22:48 up 38 min,  0 users,  load average: 0.68, 0.35, 0.21
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 67.7 us, 16.1 sy,  0.0 ni, 16.1 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4478.0 free,   1189.9 used,   2146.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6439.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606144 386712  78532 S  93.3   4.8   0:46.80 cilium-+
    662 root      20   0 1240432  16760  11356 S   6.7   0.2   0:00.02 cilium-+
    393 root      20   0 1229744   8228   3900 S   0.0   0.1   0:01.11 cilium-+
    632 root      20   0 1228744   3656   2976 S   0.0   0.0   0:00.00 gops
    638 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    658 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    678 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    685 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    714 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    732 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    738 root      20   0 1616008   8424   6348 S   0.0   0.1   0:00.00 runc:[2+
