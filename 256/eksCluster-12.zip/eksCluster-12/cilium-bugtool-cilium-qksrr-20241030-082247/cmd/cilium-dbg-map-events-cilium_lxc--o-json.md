{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:20.917Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.150.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:20.917Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.151.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:20.917Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.391Z",
  "value": "id=1732  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4F:0C:7F:FD:C7 nodemac=C2:1D:C9:6F:FE:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.392Z",
  "value": "id=17    sec_id=431579 flags=0x0000 ifindex=12  mac=CE:9F:E3:D4:A8:94 nodemac=AA:46:02:E6:F1:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.445Z",
  "value": "id=831   sec_id=431579 flags=0x0000 ifindex=14  mac=72:C5:81:6F:7B:A1 nodemac=2E:0D:EA:82:2D:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.502Z",
  "value": "id=1732  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4F:0C:7F:FD:C7 nodemac=C2:1D:C9:6F:FE:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.550Z",
  "value": "id=17    sec_id=431579 flags=0x0000 ifindex=12  mac=CE:9F:E3:D4:A8:94 nodemac=AA:46:02:E6:F1:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:34.697Z",
  "value": "id=1732  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4F:0C:7F:FD:C7 nodemac=C2:1D:C9:6F:FE:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:34.698Z",
  "value": "id=17    sec_id=431579 flags=0x0000 ifindex=12  mac=CE:9F:E3:D4:A8:94 nodemac=AA:46:02:E6:F1:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:34.698Z",
  "value": "id=831   sec_id=431579 flags=0x0000 ifindex=14  mac=72:C5:81:6F:7B:A1 nodemac=2E:0D:EA:82:2D:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:34.727Z",
  "value": "id=3263  sec_id=433695 flags=0x0000 ifindex=16  mac=F2:FC:5A:24:1D:39 nodemac=CA:27:23:CD:90:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:34.727Z",
  "value": "id=3263  sec_id=433695 flags=0x0000 ifindex=16  mac=F2:FC:5A:24:1D:39 nodemac=CA:27:23:CD:90:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:35.698Z",
  "value": "id=3263  sec_id=433695 flags=0x0000 ifindex=16  mac=F2:FC:5A:24:1D:39 nodemac=CA:27:23:CD:90:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:35.698Z",
  "value": "id=17    sec_id=431579 flags=0x0000 ifindex=12  mac=CE:9F:E3:D4:A8:94 nodemac=AA:46:02:E6:F1:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:35.698Z",
  "value": "id=1732  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4F:0C:7F:FD:C7 nodemac=C2:1D:C9:6F:FE:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:35.699Z",
  "value": "id=831   sec_id=431579 flags=0x0000 ifindex=14  mac=72:C5:81:6F:7B:A1 nodemac=2E:0D:EA:82:2D:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.502Z",
  "value": "id=583   sec_id=433695 flags=0x0000 ifindex=18  mac=5E:4C:C6:79:1B:3B nodemac=D2:BF:F3:EA:8B:5F"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.12.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.894Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:23.972Z",
  "value": "id=1732  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4F:0C:7F:FD:C7 nodemac=C2:1D:C9:6F:FE:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:23.973Z",
  "value": "id=17    sec_id=431579 flags=0x0000 ifindex=12  mac=CE:9F:E3:D4:A8:94 nodemac=AA:46:02:E6:F1:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:23.973Z",
  "value": "id=831   sec_id=431579 flags=0x0000 ifindex=14  mac=72:C5:81:6F:7B:A1 nodemac=2E:0D:EA:82:2D:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:23.974Z",
  "value": "id=583   sec_id=433695 flags=0x0000 ifindex=18  mac=5E:4C:C6:79:1B:3B nodemac=D2:BF:F3:EA:8B:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.968Z",
  "value": "id=1732  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4F:0C:7F:FD:C7 nodemac=C2:1D:C9:6F:FE:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.968Z",
  "value": "id=17    sec_id=431579 flags=0x0000 ifindex=12  mac=CE:9F:E3:D4:A8:94 nodemac=AA:46:02:E6:F1:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.969Z",
  "value": "id=831   sec_id=431579 flags=0x0000 ifindex=14  mac=72:C5:81:6F:7B:A1 nodemac=2E:0D:EA:82:2D:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.969Z",
  "value": "id=583   sec_id=433695 flags=0x0000 ifindex=18  mac=5E:4C:C6:79:1B:3B nodemac=D2:BF:F3:EA:8B:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:25.967Z",
  "value": "id=583   sec_id=433695 flags=0x0000 ifindex=18  mac=5E:4C:C6:79:1B:3B nodemac=D2:BF:F3:EA:8B:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:25.967Z",
  "value": "id=831   sec_id=431579 flags=0x0000 ifindex=14  mac=72:C5:81:6F:7B:A1 nodemac=2E:0D:EA:82:2D:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:25.967Z",
  "value": "id=17    sec_id=431579 flags=0x0000 ifindex=12  mac=CE:9F:E3:D4:A8:94 nodemac=AA:46:02:E6:F1:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:25.968Z",
  "value": "id=1732  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4F:0C:7F:FD:C7 nodemac=C2:1D:C9:6F:FE:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:26.968Z",
  "value": "id=17    sec_id=431579 flags=0x0000 ifindex=12  mac=CE:9F:E3:D4:A8:94 nodemac=AA:46:02:E6:F1:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:26.968Z",
  "value": "id=583   sec_id=433695 flags=0x0000 ifindex=18  mac=5E:4C:C6:79:1B:3B nodemac=D2:BF:F3:EA:8B:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:26.968Z",
  "value": "id=831   sec_id=431579 flags=0x0000 ifindex=14  mac=72:C5:81:6F:7B:A1 nodemac=2E:0D:EA:82:2D:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.12.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:26.968Z",
  "value": "id=1732  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4F:0C:7F:FD:C7 nodemac=C2:1D:C9:6F:FE:FF"
}

