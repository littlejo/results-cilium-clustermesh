key: 11 00 00 00  value: 12 02 00 00
key: 47 02 00 00  value: 77 02 00 00
key: 3f 03 00 00  value: fc 01 00 00
key: c4 06 00 00  value: 06 02 00 00
Found 4 elements
