[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb74d8f60_f8a9_413a_90c1_39b787a666d0.slice/cri-containerd-0824cf522cc5fed20a372f3f904e7c594319931111ba5b0912daaa58eacf60df.scope"
      }
    ],
    "ips": [
      "10.12.0.163"
    ],
    "name": "coredns-cc6ccd49c-7zmpr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod05eacbdd_c2c6_4989_aa12_0aa84249d576.slice/cri-containerd-9dd598fd735fd07a5288ca4420679a92159a18a6226638313defc795c0a712e0.scope"
      }
    ],
    "ips": [
      "10.12.0.102"
    ],
    "name": "coredns-cc6ccd49c-pn9jb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f6851ce_f7ce_405b_83e5_59931c1eaa56.slice/cri-containerd-69c04b6cb4ef9ff86d1f6a020ce185ec3f32417ad7d0b1e385a74349906046ce.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f6851ce_f7ce_405b_83e5_59931c1eaa56.slice/cri-containerd-47574f50b7caa9d16f456a6c5bbb74d1e3669856df1f1e1c802efe7f9af9b806.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f6851ce_f7ce_405b_83e5_59931c1eaa56.slice/cri-containerd-a7014b958e5d56ca84fa14c0eb3933b75f0c7a7efde09ccaa9cf7da132c0ae5c.scope"
      }
    ],
    "ips": [
      "10.12.0.106"
    ],
    "name": "clustermesh-apiserver-6d555985b8-v65qb",
    "namespace": "kube-system"
  }
]

