32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:44:36+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:44:36+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:44:36+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:44:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:44:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:44:37+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:44:38+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:44:38+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:44:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:44:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:44:38+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:44:38+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:44:41+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:44:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:44:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:44:53+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name tail_handle_ipv4  tag b3b292ebce062901  gpl
	loaded_at 2024-10-30T07:52:23+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
482: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:52:23+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
483: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:52:23+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 126
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:52:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
507: sched_cls  name tail_ipv4_ct_ingress  tag e78461486b46530f  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 153
508: sched_cls  name handle_policy  tag 11cb389044a23442  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,108,82,83,107,41,80,106,39,84,75,40,37,38
	btf_id 154
509: sched_cls  name tail_handle_arp  tag 4801163bb468dce8  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 155
510: sched_cls  name tail_ipv4_to_endpoint  tag 85d6a2cedb8068c3  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,107,41,82,83,80,106,39,108,40,37,38
	btf_id 156
511: sched_cls  name tail_handle_ipv4  tag 46ac3ccadeeacbec  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 157
513: sched_cls  name tail_ipv4_ct_egress  tag ce06da27ea9b073b  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 159
514: sched_cls  name __send_drop_notify  tag 3f8c9723ccb98ff2  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 160
515: sched_cls  name tail_handle_ipv4_cont  tag 3e3d0cdb9b66e836  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,107,41,106,82,83,39,76,74,77,108,40,37,38,81
	btf_id 161
516: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 162
517: sched_cls  name cil_from_container  tag 35b89ac58f2c6b1d  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,76
	btf_id 163
518: sched_cls  name handle_policy  tag c919c5da257d5954  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,109,82,83,110,41,80,101,39,84,75,40,37,38
	btf_id 165
519: sched_cls  name cil_from_container  tag de193b315c74a0de  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 109,76
	btf_id 166
520: sched_cls  name __send_drop_notify  tag 3c883ab54dd98307  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 167
521: sched_cls  name tail_handle_arp  tag 9fcfacd4e65e0720  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 168
523: sched_cls  name tail_handle_ipv4_cont  tag 100c749d28a6d935  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,110,41,101,82,83,39,76,74,77,109,40,37,38,81
	btf_id 170
524: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 171
525: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 172
526: sched_cls  name tail_ipv4_ct_ingress  tag 7b4225626621a650  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 173
527: sched_cls  name tail_ipv4_to_endpoint  tag 78104ff0e93045a2  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,110,41,82,83,80,101,39,109,40,37,38
	btf_id 174
528: sched_cls  name tail_handle_ipv4  tag a9fd2ae05f6cb1e0  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 175
529: sched_cls  name tail_handle_arp  tag 30a7674a8c4ab371  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 177
530: sched_cls  name handle_policy  tag 1b27537b6e182670  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,112,41,80,100,39,84,75,40,37,38
	btf_id 178
531: sched_cls  name tail_ipv4_to_endpoint  tag 9b7ec3f2685fbcd9  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,100,39,111,40,37,38
	btf_id 179
532: sched_cls  name tail_ipv4_ct_egress  tag ce06da27ea9b073b  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 180
534: sched_cls  name __send_drop_notify  tag fbb414562a98eb44  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 182
535: sched_cls  name cil_from_container  tag edfa079dfbbf5133  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 183
536: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 184
537: sched_cls  name tail_handle_ipv4  tag a0b3d05ab5ceaaea  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 185
538: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
541: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
542: sched_cls  name tail_ipv4_ct_ingress  tag a8c01ea2f5cce89c  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 186
543: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
544: sched_cls  name tail_handle_ipv4_cont  tag 706b76411144df52  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,112,41,100,82,83,39,76,74,77,111,40,37,38,81
	btf_id 187
547: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
548: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
551: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
552: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
555: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
556: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 189
557: sched_cls  name __send_drop_notify  tag 001a39d3db5176da  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 190
558: sched_cls  name tail_handle_ipv4_from_host  tag 8700ec7305c93e56  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 191
559: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 192
561: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,117
	btf_id 194
565: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 199
566: sched_cls  name __send_drop_notify  tag 001a39d3db5176da  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 200
567: sched_cls  name tail_handle_ipv4_from_host  tag 8700ec7305c93e56  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 201
568: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 202
570: sched_cls  name __send_drop_notify  tag 001a39d3db5176da  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
571: sched_cls  name tail_handle_ipv4_from_host  tag 8700ec7305c93e56  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 206
572: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 207
573: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 208
577: sched_cls  name tail_handle_ipv4_from_host  tag 8700ec7305c93e56  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 213
578: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 214
579: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 215
583: sched_cls  name __send_drop_notify  tag 001a39d3db5176da  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 219
623: sched_cls  name tail_handle_ipv4  tag 17a2b81d53c22c20  gpl
	loaded_at 2024-10-30T08:11:44+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 233
625: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:11:44+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 235
626: sched_cls  name tail_handle_arp  tag 457f2b5ab719ccb5  gpl
	loaded_at 2024-10-30T08:11:44+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 236
627: sched_cls  name cil_from_container  tag f951cc61f2f4c9fd  gpl
	loaded_at 2024-10-30T08:11:44+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 237
628: sched_cls  name tail_ipv4_ct_ingress  tag 99859e77e0df21f6  gpl
	loaded_at 2024-10-30T08:11:44+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 238
629: sched_cls  name tail_ipv4_to_endpoint  tag 4f0c6341bc4948e5  gpl
	loaded_at 2024-10-30T08:11:44+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 239
630: sched_cls  name __send_drop_notify  tag 65fc6583476301fd  gpl
	loaded_at 2024-10-30T08:11:44+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 240
631: sched_cls  name handle_policy  tag 449c52b24cc8b248  gpl
	loaded_at 2024-10-30T08:11:44+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 241
632: sched_cls  name tail_ipv4_ct_egress  tag 1e553f36c5946350  gpl
	loaded_at 2024-10-30T08:11:44+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 242
633: sched_cls  name tail_handle_ipv4_cont  tag afa417d841dc3df2  gpl
	loaded_at 2024-10-30T08:11:44+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 243
634: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
637: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
658: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
661: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
