Total: 693
TCP:   1875 (estab 443, closed 1413, orphaned 0, timewait 567)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  462       450       12       
INET	  472       456       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                  Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                 172.31.151.115%ens5:68         0.0.0.0:*    uid:192 ino:63904 sk:1 cgroup:unreachable:c4e <->                            
UNCONN 0      0                             0.0.0.0:8472       0.0.0.0:*    ino:33142 sk:2 cgroup:/ <->                                                  
UNCONN 0      0                           127.0.0.1:323        0.0.0.0:*    ino:15188 sk:3 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                           127.0.0.1:41475      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:32998 sk:4 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                [::]:8472          [::]:*    ino:33141 sk:3fe cgroup:/ v6only:1 <->                                       
UNCONN 0      0                               [::1]:323           [::]:*    ino:15189 sk:3ff cgroup:unreachable:f0c v6only:1 <->                         
UNCONN 0      0      [fe80::4a6:56ff:feb7:d11]%ens5:546           [::]:*    uid:192 ino:15675 sk:400 cgroup:unreachable:c4e v6only:1 <->                 
