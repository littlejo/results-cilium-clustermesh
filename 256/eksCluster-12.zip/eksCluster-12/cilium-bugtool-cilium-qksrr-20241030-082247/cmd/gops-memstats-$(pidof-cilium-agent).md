alloc: 130.74MB (137091712 bytes)
total-alloc: 2.24GB (2407965416 bytes)
sys: 328.83MB (344805732 bytes)
lookups: 0
mallocs: 63116570
frees: 61903196
heap-alloc: 130.74MB (137091712 bytes)
heap-sys: 251.61MB (263831552 bytes)
heap-idle: 85.40MB (89546752 bytes)
heap-in-use: 166.21MB (174284800 bytes)
heap-released: 8.88MB (9314304 bytes)
heap-objects: 1213374
stack-in-use: 64.34MB (67469312 bytes)
stack-sys: 64.34MB (67469312 bytes)
stack-mspan-inuse: 2.78MB (2913440 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.04MB (1086937 bytes)
gc-sys: 6.07MB (6360456 bytes)
next-gc: when heap-alloc >= 212.12MB (222426120 bytes)
last-gc: 2024-10-30 08:23:02.542575442 +0000 UTC
gc-pause-total: 8.101134ms
gc-pause: 67259
gc-pause-end: 1730276582542575442
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00031161088406359786
enable-gc: true
debug-gc: false
