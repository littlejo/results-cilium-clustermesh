markdown output at /tmp/cilium-bugtool-20241030-082300.461+0000-UTC-1572747316/cmd/cilium-debuginfo-20241030-082331.731+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082300.461+0000-UTC-1572747316/cmd/cilium-debuginfo-20241030-082331.731+0000-UTC.json
