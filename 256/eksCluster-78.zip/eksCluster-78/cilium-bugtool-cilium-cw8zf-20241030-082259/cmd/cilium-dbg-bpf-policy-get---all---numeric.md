Endpoint ID: 11
Path: /sys/fs/bpf/tc/globals/cilium_policy_00011

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11465827   113215    0        
Allow    Ingress     1          ANY          NONE         disabled    9276435    96914     0        
Allow    Egress      0          ANY          NONE         disabled    11854301   117670    0        


Endpoint ID: 741
Path: /sys/fs/bpf/tc/globals/cilium_policy_00741

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 785
Path: /sys/fs/bpf/tc/globals/cilium_policy_00785

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    161718   1859      0        
Allow    Egress      0          ANY          NONE         disabled    21340    239       0        


Endpoint ID: 2022
Path: /sys/fs/bpf/tc/globals/cilium_policy_02022

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    162317   1863      0        
Allow    Egress      0          ANY          NONE         disabled    19531    218       0        


Endpoint ID: 3690
Path: /sys/fs/bpf/tc/globals/cilium_policy_03690

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1667746   21073     0        
Allow    Ingress     1          ANY          NONE         disabled    23824     276       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


