[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod394ff986_592c_4778_9de2_1e1e5a99ccda.slice/cri-containerd-2cffd945efb4a41390d50309d7a423b46ecc0a70bb4e8310a9f337900b45b450.scope"
      }
    ],
    "ips": [
      "10.78.0.196"
    ],
    "name": "coredns-cc6ccd49c-gjkbz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5865e617_b4b9_4469_b1a7_91a5e698a392.slice/cri-containerd-e460d186de7af8cab44294b48e56122b98d5b38d9bbf1e6e340075372032714a.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5865e617_b4b9_4469_b1a7_91a5e698a392.slice/cri-containerd-b45ba42e2eb6e9ce2e16cd763e5ee45e71e09a6cbec4dd26e4e3514d2493de1e.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5865e617_b4b9_4469_b1a7_91a5e698a392.slice/cri-containerd-0fa93892eed3d1cde5db58e44477a859ddaca0b8cc3e3b15b2371711f6982cfa.scope"
      }
    ],
    "ips": [
      "10.78.0.177"
    ],
    "name": "clustermesh-apiserver-5cf6d5db64-rzxrj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode2691792_27e6_4679_a298_489e99a4930b.slice/cri-containerd-9937e66d404f7c7490d5f8ba1b2f290286b5ac270de80f1292523323b3f5cd45.scope"
      }
    ],
    "ips": [
      "10.78.0.24"
    ],
    "name": "coredns-cc6ccd49c-2kzp4",
    "namespace": "kube-system"
  }
]

