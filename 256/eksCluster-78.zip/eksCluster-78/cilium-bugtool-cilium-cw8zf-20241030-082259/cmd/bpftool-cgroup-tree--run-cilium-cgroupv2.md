CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod574e4f9b_9728_4e6a_bebc_b474849f5081.slice/cri-containerd-fd6a7623257e08b4daf5b527ff633616330be0ca4620b366c54804e55babc2dc.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod574e4f9b_9728_4e6a_bebc_b474849f5081.slice/cri-containerd-935098515b8e2c1cebcb8b6f824226d01987f0dd0a9e15a84dd752c5366b2a5e.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod394ff986_592c_4778_9de2_1e1e5a99ccda.slice/cri-containerd-2cffd945efb4a41390d50309d7a423b46ecc0a70bb4e8310a9f337900b45b450.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod394ff986_592c_4778_9de2_1e1e5a99ccda.slice/cri-containerd-c82910f4f793b4423549479714d741a6c094be888c2717c0259b134a889d489f.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode2691792_27e6_4679_a298_489e99a4930b.slice/cri-containerd-d8fb6832490f4ba30433d32a67aa0df1b99da280fcc8657754fc1728a287561e.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode2691792_27e6_4679_a298_489e99a4930b.slice/cri-containerd-9937e66d404f7c7490d5f8ba1b2f290286b5ac270de80f1292523323b3f5cd45.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod858a8aa8_c918_4f88_b8c2_cfe15044e890.slice/cri-containerd-6b753607e7e10a0c94d246ed28f67dd172951bdcb925232e29043fe0f358e5ec.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod858a8aa8_c918_4f88_b8c2_cfe15044e890.slice/cri-containerd-4e22c0cfe043c98168a569cad311156f3d373c68b599615247eaa390d5715de4.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7118dbae_d75d_4a3c_86ee_b906b17ea2e1.slice/cri-containerd-bde6eb73cf01e030784774879f90cc02dc3f1f969e2de9909528b0f220d4d228.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7118dbae_d75d_4a3c_86ee_b906b17ea2e1.slice/cri-containerd-65030dc987f1af6dc9ab3509b0211222c6081829765bb64ff185ff9e49ba80f5.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod177599f1_c5ee_4884_ab8a_a42152e9df01.slice/cri-containerd-16606c547d0c23d8f25e9fc336084259a6fa4995881da9b8ee5ecedd5b2225b1.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod177599f1_c5ee_4884_ab8a_a42152e9df01.slice/cri-containerd-e046ffd58b22d52f42d8d0a969e7fca0ef90c224128f19ea12063ed37c9eeb5d.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5865e617_b4b9_4469_b1a7_91a5e698a392.slice/cri-containerd-e460d186de7af8cab44294b48e56122b98d5b38d9bbf1e6e340075372032714a.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5865e617_b4b9_4469_b1a7_91a5e698a392.slice/cri-containerd-0fa93892eed3d1cde5db58e44477a859ddaca0b8cc3e3b15b2371711f6982cfa.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5865e617_b4b9_4469_b1a7_91a5e698a392.slice/cri-containerd-862d3a13f6aa07e9795bd498ad6a20c7c592359a79c5069a2d7ef819ee40c9df.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5865e617_b4b9_4469_b1a7_91a5e698a392.slice/cri-containerd-b45ba42e2eb6e9ce2e16cd763e5ee45e71e09a6cbec4dd26e4e3514d2493de1e.scope
    654      cgroup_device   multi                                          
