KEY             VALUE
AgentLiveness   2140604457400
UTimeOffset     3379442326171875
