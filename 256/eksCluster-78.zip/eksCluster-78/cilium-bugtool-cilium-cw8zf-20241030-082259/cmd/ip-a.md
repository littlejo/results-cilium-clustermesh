1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:31:c0:e0:5d:81 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.151.179/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3301sec preferred_lft 3301sec
    inet6 fe80::431:c0ff:fee0:5d81/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:56:b3:5e:4a:39 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.150.60/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::456:b3ff:fe5e:4a39/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:b3:8f:93:da:d3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::84b3:8fff:fe93:dad3/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:ba:91:a6:70:67 brd ff:ff:ff:ff:ff:ff
    inet 10.78.0.187/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::58ba:91ff:fea6:7067/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether e6:bd:1d:4e:f8:8d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e4bd:1dff:fe4e:f88d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:c7:cc:b3:1f:c7 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4cc7:ccff:feb3:1fc7/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc1bcc5aa1d51f@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:9f:21:92:0c:40 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::589f:21ff:fe92:c40/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce44ca16e0022@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:1c:6a:f4:c3:a8 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::6c1c:6aff:fef4:c3a8/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcd650356749b9@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:0e:c3:a9:0d:45 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::400e:c3ff:fea9:d45/64 scope link 
       valid_lft forever preferred_lft forever
