alloc: 137.33MB (144003992 bytes)
total-alloc: 2.23GB (2394539232 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 63020592
frees: 61685528
heap-alloc: 137.33MB (144003992 bytes)
heap-sys: 251.57MB (263790592 bytes)
heap-idle: 84.70MB (88809472 bytes)
heap-in-use: 166.88MB (174981120 bytes)
heap-released: 10.47MB (10977280 bytes)
heap-objects: 1335064
stack-in-use: 64.41MB (67534848 bytes)
stack-sys: 64.41MB (67534848 bytes)
stack-mspan-inuse: 2.82MB (2961920 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.02MB (1066825 bytes)
gc-sys: 6.01MB (6301232 bytes)
next-gc: when heap-alloc >= 211.55MB (221828824 bytes)
last-gc: 2024-10-30 08:23:11.654996068 +0000 UTC
gc-pause-total: 10.177776ms
gc-pause: 64345
gc-pause-end: 1730276591654996068
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.0003502887750327696
enable-gc: true
debug-gc: false
