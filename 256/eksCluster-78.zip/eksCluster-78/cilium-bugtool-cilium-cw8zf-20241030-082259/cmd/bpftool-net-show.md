xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 569
ens6(5) clsact/ingress cil_from_netdev-ens6 id 580
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 566
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 557
cilium_host(7) clsact/egress cil_from_host-cilium_host id 558
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 516
lxc1bcc5aa1d51f(12) clsact/ingress cil_from_container-lxc1bcc5aa1d51f id 530
lxce44ca16e0022(14) clsact/ingress cil_from_container-lxce44ca16e0022 id 513
lxcd650356749b9(18) clsact/ingress cil_from_container-lxcd650356749b9 id 626

flow_dissector:

netfilter:

