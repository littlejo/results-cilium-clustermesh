 08:23:00 up 35 min,  0 users,  load average: 0.36, 0.38, 0.22
