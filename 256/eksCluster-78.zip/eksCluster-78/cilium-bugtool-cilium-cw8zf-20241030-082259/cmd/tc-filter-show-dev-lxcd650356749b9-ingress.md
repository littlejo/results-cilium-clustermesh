filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcd650356749b9 direct-action not_in_hw id 626 tag 7a08cc62e1a05a09 jited 
