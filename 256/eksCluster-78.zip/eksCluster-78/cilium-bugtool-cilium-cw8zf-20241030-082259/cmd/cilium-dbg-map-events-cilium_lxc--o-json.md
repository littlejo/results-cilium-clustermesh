{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:11.046Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.150.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:11.046Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.151.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:11.046Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:15.480Z",
  "value": "id=3690  sec_id=4     flags=0x0000 ifindex=10  mac=0E:A0:D0:91:E0:34 nodemac=4E:C7:CC:B3:1F:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:15.482Z",
  "value": "id=2022  sec_id=2604109 flags=0x0000 ifindex=12  mac=92:3F:9D:67:22:39 nodemac=5A:9F:21:92:0C:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:15.541Z",
  "value": "id=785   sec_id=2604109 flags=0x0000 ifindex=14  mac=EE:8A:C9:6D:E7:D1 nodemac=6E:1C:6A:F4:C3:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:15.635Z",
  "value": "id=3690  sec_id=4     flags=0x0000 ifindex=10  mac=0E:A0:D0:91:E0:34 nodemac=4E:C7:CC:B3:1F:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:15.681Z",
  "value": "id=2022  sec_id=2604109 flags=0x0000 ifindex=12  mac=92:3F:9D:67:22:39 nodemac=5A:9F:21:92:0C:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:23.990Z",
  "value": "id=2022  sec_id=2604109 flags=0x0000 ifindex=12  mac=92:3F:9D:67:22:39 nodemac=5A:9F:21:92:0C:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:23.990Z",
  "value": "id=3690  sec_id=4     flags=0x0000 ifindex=10  mac=0E:A0:D0:91:E0:34 nodemac=4E:C7:CC:B3:1F:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:23.992Z",
  "value": "id=785   sec_id=2604109 flags=0x0000 ifindex=14  mac=EE:8A:C9:6D:E7:D1 nodemac=6E:1C:6A:F4:C3:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:24.021Z",
  "value": "id=1752  sec_id=2591046 flags=0x0000 ifindex=16  mac=9A:D1:12:40:2D:2F nodemac=72:08:CB:19:4B:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.754Z",
  "value": "id=11    sec_id=2591046 flags=0x0000 ifindex=18  mac=9E:BD:63:18:50:68 nodemac=42:0E:C3:A9:0D:45"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.78.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.155Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:51.917Z",
  "value": "id=11    sec_id=2591046 flags=0x0000 ifindex=18  mac=9E:BD:63:18:50:68 nodemac=42:0E:C3:A9:0D:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:51.919Z",
  "value": "id=3690  sec_id=4     flags=0x0000 ifindex=10  mac=0E:A0:D0:91:E0:34 nodemac=4E:C7:CC:B3:1F:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:51.919Z",
  "value": "id=2022  sec_id=2604109 flags=0x0000 ifindex=12  mac=92:3F:9D:67:22:39 nodemac=5A:9F:21:92:0C:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:51.920Z",
  "value": "id=785   sec_id=2604109 flags=0x0000 ifindex=14  mac=EE:8A:C9:6D:E7:D1 nodemac=6E:1C:6A:F4:C3:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:52.918Z",
  "value": "id=3690  sec_id=4     flags=0x0000 ifindex=10  mac=0E:A0:D0:91:E0:34 nodemac=4E:C7:CC:B3:1F:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:52.919Z",
  "value": "id=2022  sec_id=2604109 flags=0x0000 ifindex=12  mac=92:3F:9D:67:22:39 nodemac=5A:9F:21:92:0C:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:52.919Z",
  "value": "id=785   sec_id=2604109 flags=0x0000 ifindex=14  mac=EE:8A:C9:6D:E7:D1 nodemac=6E:1C:6A:F4:C3:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:52.920Z",
  "value": "id=11    sec_id=2591046 flags=0x0000 ifindex=18  mac=9E:BD:63:18:50:68 nodemac=42:0E:C3:A9:0D:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:53.917Z",
  "value": "id=11    sec_id=2591046 flags=0x0000 ifindex=18  mac=9E:BD:63:18:50:68 nodemac=42:0E:C3:A9:0D:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:53.918Z",
  "value": "id=3690  sec_id=4     flags=0x0000 ifindex=10  mac=0E:A0:D0:91:E0:34 nodemac=4E:C7:CC:B3:1F:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:53.918Z",
  "value": "id=2022  sec_id=2604109 flags=0x0000 ifindex=12  mac=92:3F:9D:67:22:39 nodemac=5A:9F:21:92:0C:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:53.919Z",
  "value": "id=785   sec_id=2604109 flags=0x0000 ifindex=14  mac=EE:8A:C9:6D:E7:D1 nodemac=6E:1C:6A:F4:C3:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.918Z",
  "value": "id=3690  sec_id=4     flags=0x0000 ifindex=10  mac=0E:A0:D0:91:E0:34 nodemac=4E:C7:CC:B3:1F:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.919Z",
  "value": "id=785   sec_id=2604109 flags=0x0000 ifindex=14  mac=EE:8A:C9:6D:E7:D1 nodemac=6E:1C:6A:F4:C3:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.919Z",
  "value": "id=11    sec_id=2591046 flags=0x0000 ifindex=18  mac=9E:BD:63:18:50:68 nodemac=42:0E:C3:A9:0D:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.919Z",
  "value": "id=2022  sec_id=2604109 flags=0x0000 ifindex=12  mac=92:3F:9D:67:22:39 nodemac=5A:9F:21:92:0C:40"
}

