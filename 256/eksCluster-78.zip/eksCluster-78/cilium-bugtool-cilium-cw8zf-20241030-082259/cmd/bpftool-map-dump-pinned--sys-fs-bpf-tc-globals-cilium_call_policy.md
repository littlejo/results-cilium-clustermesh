key: 0b 00 00 00  value: 6f 02 00 00
key: 11 03 00 00  value: fd 01 00 00
key: e6 07 00 00  value: 18 02 00 00
key: 6a 0e 00 00  value: 0e 02 00 00
Found 4 elements
