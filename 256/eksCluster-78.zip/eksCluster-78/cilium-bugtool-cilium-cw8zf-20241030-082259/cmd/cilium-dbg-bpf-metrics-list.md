REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35673     2819696     677    bpf_overlay.c
Interface                 INGRESS     626218    130313323   1132   bpf_host.c
Success                   EGRESS      15292     1199306     1694   bpf_host.c
Success                   EGRESS      264742    33316271    1308   bpf_lxc.c
Success                   EGRESS      34978     2771518     53     encap.h
Success                   INGRESS     304401    34269404    86     l3.h
Success                   INGRESS     325433    35933840    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
