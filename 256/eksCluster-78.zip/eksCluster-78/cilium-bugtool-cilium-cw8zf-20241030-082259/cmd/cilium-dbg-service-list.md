ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.128.80:443 (active)     
                                         2 => 172.31.208.82:443 (active)     
2    10.100.231.198:443   ClusterIP      1 => 172.31.151.179:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.78.0.196:9153 (active)      
                                         2 => 10.78.0.24:9153 (active)       
4    10.100.0.10:53       ClusterIP      1 => 10.78.0.196:53 (active)        
                                         2 => 10.78.0.24:53 (active)         
5    10.100.73.1:2379     ClusterIP      1 => 10.78.0.177:2379 (active)      
