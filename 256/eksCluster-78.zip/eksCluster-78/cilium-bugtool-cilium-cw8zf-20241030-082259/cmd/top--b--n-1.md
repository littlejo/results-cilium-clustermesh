top - 08:23:00 up 35 min,  0 users,  load average: 0.81, 0.47, 0.25
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 57.1 us, 17.9 sy,  0.0 ni, 17.9 id,  0.0 wa,  0.0 hi,  7.1 si,  0.0 st
MiB Mem :   7814.2 total,   4485.0 free,   1184.0 used,   2145.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6445.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 381452  79168 S 100.0   4.8   0:50.40 cilium-+
    640 root      20   0 1240432  16448  11484 S   6.7   0.2   0:00.03 cilium-+
    409 root      20   0 1229744   7048   2864 S   0.0   0.1   0:01.17 cilium-+
    634 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    660 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    672 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    673 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    674 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    715 root      20   0    6576   2416   2092 R   0.0   0.0   0:00.00 top
    733 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
