IP ADDRESS         LOCAL ENDPOINT INFO
10.78.0.187:0      (localhost)                                                                                        
10.78.0.194:0      id=3690  sec_id=4     flags=0x0000 ifindex=10  mac=0E:A0:D0:91:E0:34 nodemac=4E:C7:CC:B3:1F:C7     
172.31.151.179:0   (localhost)                                                                                        
172.31.150.60:0    (localhost)                                                                                        
10.78.0.24:0       id=785   sec_id=2604109 flags=0x0000 ifindex=14  mac=EE:8A:C9:6D:E7:D1 nodemac=6E:1C:6A:F4:C3:A8   
10.78.0.196:0      id=2022  sec_id=2604109 flags=0x0000 ifindex=12  mac=92:3F:9D:67:22:39 nodemac=5A:9F:21:92:0C:40   
10.78.0.177:0      id=11    sec_id=2591046 flags=0x0000 ifindex=18  mac=9E:BD:63:18:50:68 nodemac=42:0E:C3:A9:0D:45   
