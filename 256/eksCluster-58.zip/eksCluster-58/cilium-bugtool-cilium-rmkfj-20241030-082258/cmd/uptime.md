 08:22:59 up 34 min,  0 users,  load average: 0.09, 0.12, 0.09
