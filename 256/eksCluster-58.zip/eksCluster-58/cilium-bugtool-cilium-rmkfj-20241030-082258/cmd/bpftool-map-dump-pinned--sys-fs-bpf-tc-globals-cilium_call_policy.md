key: ed 03 00 00  value: 01 02 00 00
key: 80 05 00 00  value: 7d 02 00 00
key: 4f 06 00 00  value: 44 02 00 00
key: fa 0b 00 00  value: 1b 02 00 00
Found 4 elements
