KEY             VALUE
AgentLiveness   2106882970087
UTimeOffset     3379442390625000
