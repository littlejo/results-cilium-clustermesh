CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod405d78b9_6f01_4e76_b3c4_a1a033a2dffb.slice/cri-containerd-bda8da453f5bfee031b6c0be6b3a317a2eb165514d581bb37cae608d04926e07.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod405d78b9_6f01_4e76_b3c4_a1a033a2dffb.slice/cri-containerd-04b3fd7f75be47ee4eb4f7e50548545a88033e9e1a6390a60363ea31589db3cb.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd9c7bcda_0b01_422d_b584_e280820afe3c.slice/cri-containerd-5283ed42296a20b22b7b8826f5432241e11a2e07c3a4f35b85bd5bf50a439aa6.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd9c7bcda_0b01_422d_b584_e280820afe3c.slice/cri-containerd-a18cde8adc8c13fe74adee37361e52769ff1c84ed4316fec1e365b5b125900a4.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod84d53bea_98fd_4cb4_83ce_539622d129c2.slice/cri-containerd-835f7c5cd7b6274db210ca3ca9db38be9d9be57b57e3f6680ddc900dcb74e6e3.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod84d53bea_98fd_4cb4_83ce_539622d129c2.slice/cri-containerd-4517fea550458132c1d3409f6b9e0be0c78c6a33b37fc0be948bb81caf6a9cb1.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7bb69092_cff5_45a5_9466_97190e356af2.slice/cri-containerd-e083550b64343e61934bb40891d9fc036650dc01b91c8dea1699053cde67123e.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7bb69092_cff5_45a5_9466_97190e356af2.slice/cri-containerd-ab4e3fc4f900143e2296e0ada42d010ab8f24d25f5a1bffe3b4c2ea633413d97.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2cb3cf63_de78_4916_a0e6_8d04882405ca.slice/cri-containerd-b8af974e63dd1daa1bd0be938e270bd4e12ece9e2f916d24ca17a0a354b5b06c.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2cb3cf63_de78_4916_a0e6_8d04882405ca.slice/cri-containerd-793bea9eddc638e614628144b0673a9745ca40d129828dab99715749fe85002f.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2cb3cf63_de78_4916_a0e6_8d04882405ca.slice/cri-containerd-f7126e39a243d27dc5be81e824622499867ec7a3241778ab6fbf75fb55c8237c.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2cb3cf63_de78_4916_a0e6_8d04882405ca.slice/cri-containerd-ffb3f1151f2c0cabcd005e422f1337026c69d17bd8f5a10622c1d2a398857ea7.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf61bdc27_898e_407d_8cdf_b21e0909136f.slice/cri-containerd-ea8b56f710cc52863739ebb9df515d3088d11ec5bbbe326e8210f51cb678f944.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf61bdc27_898e_407d_8cdf_b21e0909136f.slice/cri-containerd-20615c183e340ddcd79eb2ad9cd8deb417afe14711067ca67c812b30eab6fbd3.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0022396a_f7d0_4477_8503_be72e57bd116.slice/cri-containerd-2881b074089485d084009fde56e40b922172c3e2ce75a58339c3d7429361d847.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0022396a_f7d0_4477_8503_be72e57bd116.slice/cri-containerd-af2697c29975a107c452850cdac087878b2416239276cafd51ca48cd9f8b04b1.scope
    99       cgroup_device   multi                                          
