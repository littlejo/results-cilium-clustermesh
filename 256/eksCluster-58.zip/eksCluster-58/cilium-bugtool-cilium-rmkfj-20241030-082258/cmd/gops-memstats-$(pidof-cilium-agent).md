alloc: 172.22MB (180583344 bytes)
total-alloc: 2.48GB (2662890368 bytes)
sys: 337.02MB (353394036 bytes)
lookups: 0
mallocs: 66585442
frees: 64631865
heap-alloc: 172.22MB (180583344 bytes)
heap-sys: 256.20MB (268640256 bytes)
heap-idle: 53.76MB (56369152 bytes)
heap-in-use: 202.44MB (212271104 bytes)
heap-released: 5.22MB (5472256 bytes)
heap-objects: 1953577
stack-in-use: 67.78MB (71073792 bytes)
stack-sys: 67.78MB (71073792 bytes)
stack-mspan-inuse: 3.44MB (3607520 bytes)
stack-mspan-sys: 3.95MB (4145280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.05MB (1101369 bytes)
gc-sys: 6.03MB (6320728 bytes)
next-gc: when heap-alloc >= 217.39MB (227950568 bytes)
last-gc: 2024-10-30 08:23:00.017235204 +0000 UTC
gc-pause-total: 18.235799ms
gc-pause: 91226
gc-pause-end: 1730276580017235204
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.0005062011412659565
enable-gc: true
debug-gc: false
