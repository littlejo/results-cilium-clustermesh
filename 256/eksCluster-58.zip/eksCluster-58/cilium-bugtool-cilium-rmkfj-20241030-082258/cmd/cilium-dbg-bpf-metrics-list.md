REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37101     2933899     677    bpf_overlay.c
Interface                 INGRESS     675889    136007359   1132   bpf_host.c
Success                   EGRESS      16555     1301951     1694   bpf_host.c
Success                   EGRESS      297561    37305822    1308   bpf_lxc.c
Success                   EGRESS      37396     2954659     53     encap.h
Success                   INGRESS     342396    38737013    86     l3.h
Success                   INGRESS     363466    40403609    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
