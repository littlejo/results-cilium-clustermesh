IP ADDRESS         LOCAL ENDPOINT INFO
172.31.163.207:0   (localhost)                                                                                        
10.58.0.104:0      id=1005  sec_id=1946482 flags=0x0000 ifindex=12  mac=F2:A8:E3:11:44:2F nodemac=0A:21:CE:03:3D:17   
172.31.157.22:0    (localhost)                                                                                        
10.58.0.217:0      id=1615  sec_id=4     flags=0x0000 ifindex=10  mac=4A:40:EE:07:48:08 nodemac=06:D9:F6:88:70:DA     
10.58.0.15:0       (localhost)                                                                                        
10.58.0.197:0      id=1408  sec_id=1963970 flags=0x0000 ifindex=18  mac=9E:F8:33:F8:BB:9B nodemac=5E:95:2C:E0:B5:20   
10.58.0.221:0      id=3066  sec_id=1946482 flags=0x0000 ifindex=14  mac=76:7D:A2:2B:50:40 nodemac=1A:79:9C:61:F4:50   
