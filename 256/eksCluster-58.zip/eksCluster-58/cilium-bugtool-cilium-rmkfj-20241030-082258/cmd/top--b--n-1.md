top - 08:22:59 up 34 min,  0 users,  load average: 0.09, 0.12, 0.09
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 64.5 us, 32.3 sy,  0.0 ni,  3.2 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4458.8 free,   1209.8 used,   2145.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6419.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1671876 404048  78520 S  86.7   5.0   0:53.91 cilium-+
    640 root      20   0 1240432  16464  11292 S   6.7   0.2   0:00.03 cilium-+
    395 root      20   0 1229744   7012   2924 S   0.0   0.1   0:01.12 cilium-+
    616 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    646 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    654 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    680 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    699 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    710 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    723 root      20   0 1243508  17664  12932 S   0.0   0.2   0:00.00 hubble
    724 root      20   0 1229000   4020   3356 S   0.0   0.1   0:00.00 gops
