Endpoint ID: 1005
Path: /sys/fs/bpf/tc/globals/cilium_policy_01005

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    152905   1756      0        
Allow    Egress      0          ANY          NONE         disabled    19847    219       0        


Endpoint ID: 1408
Path: /sys/fs/bpf/tc/globals/cilium_policy_01408

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11702146   116944    0        
Allow    Ingress     1          ANY          NONE         disabled    11376552   116771    0        
Allow    Egress      0          ANY          NONE         disabled    13237907   130294    0        


Endpoint ID: 1615
Path: /sys/fs/bpf/tc/globals/cilium_policy_01615

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1668368   21094     0        
Allow    Ingress     1          ANY          NONE         disabled    23118     271       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3066
Path: /sys/fs/bpf/tc/globals/cilium_policy_03066

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    153631   1767      0        
Allow    Egress      0          ANY          NONE         disabled    19640    217       0        


Endpoint ID: 3655
Path: /sys/fs/bpf/tc/globals/cilium_policy_03655

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


