[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2cb3cf63_de78_4916_a0e6_8d04882405ca.slice/cri-containerd-b8af974e63dd1daa1bd0be938e270bd4e12ece9e2f916d24ca17a0a354b5b06c.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2cb3cf63_de78_4916_a0e6_8d04882405ca.slice/cri-containerd-ffb3f1151f2c0cabcd005e422f1337026c69d17bd8f5a10622c1d2a398857ea7.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2cb3cf63_de78_4916_a0e6_8d04882405ca.slice/cri-containerd-f7126e39a243d27dc5be81e824622499867ec7a3241778ab6fbf75fb55c8237c.scope"
      }
    ],
    "ips": [
      "10.58.0.197"
    ],
    "name": "clustermesh-apiserver-66bd9f84ff-7dcnd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod84d53bea_98fd_4cb4_83ce_539622d129c2.slice/cri-containerd-835f7c5cd7b6274db210ca3ca9db38be9d9be57b57e3f6680ddc900dcb74e6e3.scope"
      }
    ],
    "ips": [
      "10.58.0.221"
    ],
    "name": "coredns-cc6ccd49c-54fpn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod405d78b9_6f01_4e76_b3c4_a1a033a2dffb.slice/cri-containerd-bda8da453f5bfee031b6c0be6b3a317a2eb165514d581bb37cae608d04926e07.scope"
      }
    ],
    "ips": [
      "10.58.0.104"
    ],
    "name": "coredns-cc6ccd49c-5ls5v",
    "namespace": "kube-system"
  }
]

