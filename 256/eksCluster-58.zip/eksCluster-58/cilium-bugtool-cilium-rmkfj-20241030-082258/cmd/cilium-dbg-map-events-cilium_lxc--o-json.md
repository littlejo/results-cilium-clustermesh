{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:41.325Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.157.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:41.325Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.163.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:41.325Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:45.936Z",
  "value": "id=1615  sec_id=4     flags=0x0000 ifindex=10  mac=4A:40:EE:07:48:08 nodemac=06:D9:F6:88:70:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:45.945Z",
  "value": "id=1005  sec_id=1946482 flags=0x0000 ifindex=12  mac=F2:A8:E3:11:44:2F nodemac=0A:21:CE:03:3D:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:46.003Z",
  "value": "id=3066  sec_id=1946482 flags=0x0000 ifindex=14  mac=76:7D:A2:2B:50:40 nodemac=1A:79:9C:61:F4:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:46.012Z",
  "value": "id=1615  sec_id=4     flags=0x0000 ifindex=10  mac=4A:40:EE:07:48:08 nodemac=06:D9:F6:88:70:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:32.170Z",
  "value": "id=1615  sec_id=4     flags=0x0000 ifindex=10  mac=4A:40:EE:07:48:08 nodemac=06:D9:F6:88:70:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:32.171Z",
  "value": "id=1005  sec_id=1946482 flags=0x0000 ifindex=12  mac=F2:A8:E3:11:44:2F nodemac=0A:21:CE:03:3D:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:32.172Z",
  "value": "id=3066  sec_id=1946482 flags=0x0000 ifindex=14  mac=76:7D:A2:2B:50:40 nodemac=1A:79:9C:61:F4:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:32.199Z",
  "value": "id=409   sec_id=1963970 flags=0x0000 ifindex=16  mac=9A:1B:FC:50:BC:E1 nodemac=76:02:B3:A3:B4:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:32.200Z",
  "value": "id=409   sec_id=1963970 flags=0x0000 ifindex=16  mac=9A:1B:FC:50:BC:E1 nodemac=76:02:B3:A3:B4:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:33.170Z",
  "value": "id=409   sec_id=1963970 flags=0x0000 ifindex=16  mac=9A:1B:FC:50:BC:E1 nodemac=76:02:B3:A3:B4:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:33.170Z",
  "value": "id=1005  sec_id=1946482 flags=0x0000 ifindex=12  mac=F2:A8:E3:11:44:2F nodemac=0A:21:CE:03:3D:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:33.170Z",
  "value": "id=1615  sec_id=4     flags=0x0000 ifindex=10  mac=4A:40:EE:07:48:08 nodemac=06:D9:F6:88:70:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:33.170Z",
  "value": "id=3066  sec_id=1946482 flags=0x0000 ifindex=14  mac=76:7D:A2:2B:50:40 nodemac=1A:79:9C:61:F4:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.680Z",
  "value": "id=1408  sec_id=1963970 flags=0x0000 ifindex=18  mac=9E:F8:33:F8:BB:9B nodemac=5E:95:2C:E0:B5:20"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.58.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.081Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.647Z",
  "value": "id=1615  sec_id=4     flags=0x0000 ifindex=10  mac=4A:40:EE:07:48:08 nodemac=06:D9:F6:88:70:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.647Z",
  "value": "id=1005  sec_id=1946482 flags=0x0000 ifindex=12  mac=F2:A8:E3:11:44:2F nodemac=0A:21:CE:03:3D:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.647Z",
  "value": "id=3066  sec_id=1946482 flags=0x0000 ifindex=14  mac=76:7D:A2:2B:50:40 nodemac=1A:79:9C:61:F4:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.648Z",
  "value": "id=1408  sec_id=1963970 flags=0x0000 ifindex=18  mac=9E:F8:33:F8:BB:9B nodemac=5E:95:2C:E0:B5:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.647Z",
  "value": "id=1615  sec_id=4     flags=0x0000 ifindex=10  mac=4A:40:EE:07:48:08 nodemac=06:D9:F6:88:70:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.648Z",
  "value": "id=1408  sec_id=1963970 flags=0x0000 ifindex=18  mac=9E:F8:33:F8:BB:9B nodemac=5E:95:2C:E0:B5:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.649Z",
  "value": "id=1005  sec_id=1946482 flags=0x0000 ifindex=12  mac=F2:A8:E3:11:44:2F nodemac=0A:21:CE:03:3D:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.650Z",
  "value": "id=3066  sec_id=1946482 flags=0x0000 ifindex=14  mac=76:7D:A2:2B:50:40 nodemac=1A:79:9C:61:F4:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.647Z",
  "value": "id=3066  sec_id=1946482 flags=0x0000 ifindex=14  mac=76:7D:A2:2B:50:40 nodemac=1A:79:9C:61:F4:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.648Z",
  "value": "id=1615  sec_id=4     flags=0x0000 ifindex=10  mac=4A:40:EE:07:48:08 nodemac=06:D9:F6:88:70:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.648Z",
  "value": "id=1408  sec_id=1963970 flags=0x0000 ifindex=18  mac=9E:F8:33:F8:BB:9B nodemac=5E:95:2C:E0:B5:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.648Z",
  "value": "id=1005  sec_id=1946482 flags=0x0000 ifindex=12  mac=F2:A8:E3:11:44:2F nodemac=0A:21:CE:03:3D:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.648Z",
  "value": "id=1615  sec_id=4     flags=0x0000 ifindex=10  mac=4A:40:EE:07:48:08 nodemac=06:D9:F6:88:70:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.648Z",
  "value": "id=3066  sec_id=1946482 flags=0x0000 ifindex=14  mac=76:7D:A2:2B:50:40 nodemac=1A:79:9C:61:F4:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.649Z",
  "value": "id=1408  sec_id=1963970 flags=0x0000 ifindex=18  mac=9E:F8:33:F8:BB:9B nodemac=5E:95:2C:E0:B5:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.649Z",
  "value": "id=1005  sec_id=1946482 flags=0x0000 ifindex=12  mac=F2:A8:E3:11:44:2F nodemac=0A:21:CE:03:3D:17"
}

