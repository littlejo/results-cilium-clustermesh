filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc2160320d8e08 direct-action not_in_hw id 524 tag 59e287bad6535182 jited 
