IP ADDRESS         LOCAL ENDPOINT INFO
10.83.0.135:0      id=444   sec_id=2783030 flags=0x0000 ifindex=14  mac=E6:95:A4:18:37:96 nodemac=CA:5C:E5:D0:C8:CC   
172.31.227.191:0   (localhost)                                                                                        
172.31.210.93:0    (localhost)                                                                                        
10.83.0.48:0       id=1163  sec_id=2783030 flags=0x0000 ifindex=12  mac=42:2C:A1:A7:D7:A2 nodemac=36:6A:F8:25:8A:B1   
10.83.0.71:0       id=13    sec_id=2755544 flags=0x0000 ifindex=18  mac=9A:48:3F:A4:05:91 nodemac=4A:27:59:15:BC:BA   
10.83.0.201:0      id=3589  sec_id=4     flags=0x0000 ifindex=10  mac=06:00:CA:6F:86:5A nodemac=7E:3F:58:31:4A:2E     
10.83.0.165:0      (localhost)                                                                                        
