REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35743     2824236     677    bpf_overlay.c
Interface                 INGRESS     642694    131949691   1132   bpf_host.c
Success                   EGRESS      15349     1203244     1694   bpf_host.c
Success                   EGRESS      268878    33869493    1308   bpf_lxc.c
Success                   EGRESS      35232     2787066     53     encap.h
Success                   INGRESS     312200    35060788    86     l3.h
Success                   INGRESS     333245    36725826    235    trace.h
Unsupported L3 protocol   EGRESS      43        3202        1492   bpf_lxc.c
