{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:43.824Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.210.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:43.825Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.227.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:43.825Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:48.305Z",
  "value": "id=3589  sec_id=4     flags=0x0000 ifindex=10  mac=06:00:CA:6F:86:5A nodemac=7E:3F:58:31:4A:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:48.314Z",
  "value": "id=444   sec_id=2783030 flags=0x0000 ifindex=14  mac=E6:95:A4:18:37:96 nodemac=CA:5C:E5:D0:C8:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:48.343Z",
  "value": "id=1163  sec_id=2783030 flags=0x0000 ifindex=12  mac=42:2C:A1:A7:D7:A2 nodemac=36:6A:F8:25:8A:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:48.344Z",
  "value": "id=444   sec_id=2783030 flags=0x0000 ifindex=14  mac=E6:95:A4:18:37:96 nodemac=CA:5C:E5:D0:C8:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:48.397Z",
  "value": "id=3589  sec_id=4     flags=0x0000 ifindex=10  mac=06:00:CA:6F:86:5A nodemac=7E:3F:58:31:4A:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:34.240Z",
  "value": "id=3589  sec_id=4     flags=0x0000 ifindex=10  mac=06:00:CA:6F:86:5A nodemac=7E:3F:58:31:4A:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:34.240Z",
  "value": "id=444   sec_id=2783030 flags=0x0000 ifindex=14  mac=E6:95:A4:18:37:96 nodemac=CA:5C:E5:D0:C8:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:34.241Z",
  "value": "id=1163  sec_id=2783030 flags=0x0000 ifindex=12  mac=42:2C:A1:A7:D7:A2 nodemac=36:6A:F8:25:8A:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:34.270Z",
  "value": "id=415   sec_id=2755544 flags=0x0000 ifindex=16  mac=EA:48:DB:B4:42:AF nodemac=96:E3:00:32:BE:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:35.240Z",
  "value": "id=415   sec_id=2755544 flags=0x0000 ifindex=16  mac=EA:48:DB:B4:42:AF nodemac=96:E3:00:32:BE:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:35.240Z",
  "value": "id=3589  sec_id=4     flags=0x0000 ifindex=10  mac=06:00:CA:6F:86:5A nodemac=7E:3F:58:31:4A:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:35.241Z",
  "value": "id=444   sec_id=2783030 flags=0x0000 ifindex=14  mac=E6:95:A4:18:37:96 nodemac=CA:5C:E5:D0:C8:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:35.241Z",
  "value": "id=1163  sec_id=2783030 flags=0x0000 ifindex=12  mac=42:2C:A1:A7:D7:A2 nodemac=36:6A:F8:25:8A:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.517Z",
  "value": "id=13    sec_id=2755544 flags=0x0000 ifindex=18  mac=9A:48:3F:A4:05:91 nodemac=4A:27:59:15:BC:BA"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.83.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:36.045Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.013Z",
  "value": "id=1163  sec_id=2783030 flags=0x0000 ifindex=12  mac=42:2C:A1:A7:D7:A2 nodemac=36:6A:F8:25:8A:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.013Z",
  "value": "id=13    sec_id=2755544 flags=0x0000 ifindex=18  mac=9A:48:3F:A4:05:91 nodemac=4A:27:59:15:BC:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.014Z",
  "value": "id=3589  sec_id=4     flags=0x0000 ifindex=10  mac=06:00:CA:6F:86:5A nodemac=7E:3F:58:31:4A:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.023Z",
  "value": "id=444   sec_id=2783030 flags=0x0000 ifindex=14  mac=E6:95:A4:18:37:96 nodemac=CA:5C:E5:D0:C8:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.017Z",
  "value": "id=3589  sec_id=4     flags=0x0000 ifindex=10  mac=06:00:CA:6F:86:5A nodemac=7E:3F:58:31:4A:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.019Z",
  "value": "id=444   sec_id=2783030 flags=0x0000 ifindex=14  mac=E6:95:A4:18:37:96 nodemac=CA:5C:E5:D0:C8:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.019Z",
  "value": "id=1163  sec_id=2783030 flags=0x0000 ifindex=12  mac=42:2C:A1:A7:D7:A2 nodemac=36:6A:F8:25:8A:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.019Z",
  "value": "id=13    sec_id=2755544 flags=0x0000 ifindex=18  mac=9A:48:3F:A4:05:91 nodemac=4A:27:59:15:BC:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.014Z",
  "value": "id=13    sec_id=2755544 flags=0x0000 ifindex=18  mac=9A:48:3F:A4:05:91 nodemac=4A:27:59:15:BC:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.014Z",
  "value": "id=1163  sec_id=2783030 flags=0x0000 ifindex=12  mac=42:2C:A1:A7:D7:A2 nodemac=36:6A:F8:25:8A:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.015Z",
  "value": "id=444   sec_id=2783030 flags=0x0000 ifindex=14  mac=E6:95:A4:18:37:96 nodemac=CA:5C:E5:D0:C8:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.015Z",
  "value": "id=3589  sec_id=4     flags=0x0000 ifindex=10  mac=06:00:CA:6F:86:5A nodemac=7E:3F:58:31:4A:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.015Z",
  "value": "id=3589  sec_id=4     flags=0x0000 ifindex=10  mac=06:00:CA:6F:86:5A nodemac=7E:3F:58:31:4A:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.016Z",
  "value": "id=13    sec_id=2755544 flags=0x0000 ifindex=18  mac=9A:48:3F:A4:05:91 nodemac=4A:27:59:15:BC:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.016Z",
  "value": "id=444   sec_id=2783030 flags=0x0000 ifindex=14  mac=E6:95:A4:18:37:96 nodemac=CA:5C:E5:D0:C8:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.016Z",
  "value": "id=1163  sec_id=2783030 flags=0x0000 ifindex=12  mac=42:2C:A1:A7:D7:A2 nodemac=36:6A:F8:25:8A:B1"
}

