ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.241.219:443 (active)   
                                         2 => 172.31.128.234:443 (active)   
2    10.100.169.67:443    ClusterIP      1 => 172.31.210.93:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.83.0.135:53 (active)       
                                         2 => 10.83.0.48:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.83.0.135:9153 (active)     
                                         2 => 10.83.0.48:9153 (active)      
5    10.100.35.229:2379   ClusterIP      1 => 10.83.0.71:2379 (active)      
