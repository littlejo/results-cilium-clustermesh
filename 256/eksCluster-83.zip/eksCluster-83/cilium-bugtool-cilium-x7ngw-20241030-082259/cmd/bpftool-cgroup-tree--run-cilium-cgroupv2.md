CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod31990d08_1ea5_4e8a_9952_cda492ddaae0.slice/cri-containerd-35c4b2966adf88c5bb10df28c1a8b679232cdb3b0829ea26a34edc1da4a6d46f.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod31990d08_1ea5_4e8a_9952_cda492ddaae0.slice/cri-containerd-61c27f77fe23aaba21101eb8928d6619e0820958310c93735f56a379328b19df.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod30090a20_48bd_4fc5_b977_19b4e8f7db4c.slice/cri-containerd-e940d5d6b620d30d9733b486f98afa5b6247644732129945edb1c1ac21880bd2.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod30090a20_48bd_4fc5_b977_19b4e8f7db4c.slice/cri-containerd-be56103fe82106dad69e7f4a38929c53e962a68701a1308cfd11bcba119e421d.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f9998bf_bd9d_4c79_a7d3_44762a3bacad.slice/cri-containerd-3fe33039f279823d663077ded588bd1644a062e31832b40d3f9678e8482261cc.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f9998bf_bd9d_4c79_a7d3_44762a3bacad.slice/cri-containerd-7a026b08a9addf6042797c4ae72120025ce702358e595502e4f6d57645313213.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda4dddac3_4f7e_4f41_b74f_3fd6ff6dd2ce.slice/cri-containerd-3e670c849055ffa1882d29c602ade7869f7e8054369950c25425d605f0db4769.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda4dddac3_4f7e_4f41_b74f_3fd6ff6dd2ce.slice/cri-containerd-d01b74d13e8688001be632b9618611b7e472787deb416e7d1d4c45a5412677b3.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e37ce0a_164e_4efe_a4c9_35fc2a6a565a.slice/cri-containerd-6c1dd0c020d5ac8cd4f239ad5ff78d8f18ed0db776d02928959c365ffbc870d1.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e37ce0a_164e_4efe_a4c9_35fc2a6a565a.slice/cri-containerd-bb85abc7edfd056f5f371696a493d45012e04c6cb6e13752fa4811d467e9d7d0.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3cc5bb22_d7fc_4d43_9e12_e3fad73cb120.slice/cri-containerd-e5a54d97a041300dd23fde8899b414c99509c30c018cc8346f2c92516ad434ac.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3cc5bb22_d7fc_4d43_9e12_e3fad73cb120.slice/cri-containerd-49d090d3ac8e67870d394814755cc1cf4291389107b6e12a722faf3ff56f5420.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58a66304_24e2_4aef_9050_e19c93ef4600.slice/cri-containerd-e4cce065bf84d9295bae7bf7bf5a7cee2ede31eb710cba17f691eec6af0c3957.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58a66304_24e2_4aef_9050_e19c93ef4600.slice/cri-containerd-e9f404387b68403dc41d74ddebc697be8040473569bee9cedffe5e8082c2a320.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58a66304_24e2_4aef_9050_e19c93ef4600.slice/cri-containerd-c9086259ee9b71d4b35890720e8dedbf16fc3fa98a6cc115c8533a22e5f47732.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58a66304_24e2_4aef_9050_e19c93ef4600.slice/cri-containerd-48c06068613f7d34662fbc52f512a1be47f3808432301872a467bb1265adfd2f.scope
    643      cgroup_device   multi                                          
