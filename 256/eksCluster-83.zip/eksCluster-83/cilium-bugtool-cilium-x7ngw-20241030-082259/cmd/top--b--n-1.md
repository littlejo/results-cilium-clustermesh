top - 08:23:01 up 33 min,  0 users,  load average: 0.33, 0.25, 0.18
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s):  3.3 us, 40.0 sy,  0.0 ni, 50.0 id,  3.3 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4493.4 free,   1173.8 used,   2147.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6455.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    684 root      20   0 1240432  16232  11228 S   6.7   0.2   0:00.03 cilium-+
      1 root      20   0 1606080 378452  79100 S   0.0   4.7   0:50.91 cilium-+
    413 root      20   0 1229744   8260   3904 S   0.0   0.1   0:01.16 cilium-+
    641 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    654 root      20   0 1228744   3588   2912 S   0.0   0.0   0:00.00 gops
    669 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    678 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    718 root      20   0    6576   2432   2104 R   0.0   0.0   0:00.00 top
    743 root      20   0 1228744   3712   3040 S   0.0   0.0   0:00.00 gops
