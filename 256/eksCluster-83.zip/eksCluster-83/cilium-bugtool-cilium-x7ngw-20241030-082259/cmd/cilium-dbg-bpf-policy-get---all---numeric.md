Endpoint ID: 13
Path: /sys/fs/bpf/tc/globals/cilium_policy_00013

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11628219   115378    0        
Allow    Ingress     1          ANY          NONE         disabled    9843611    103626    0        
Allow    Egress      0          ANY          NONE         disabled    12334171   122156    0        


Endpoint ID: 444
Path: /sys/fs/bpf/tc/globals/cilium_policy_00444

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    147799   1700      0        
Allow    Egress      0          ANY          NONE         disabled    19608    216       0        


Endpoint ID: 698
Path: /sys/fs/bpf/tc/globals/cilium_policy_00698

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1163
Path: /sys/fs/bpf/tc/globals/cilium_policy_01163

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    146176   1680      0        
Allow    Egress      0          ANY          NONE         disabled    19530    215       0        


Endpoint ID: 3589
Path: /sys/fs/bpf/tc/globals/cilium_policy_03589

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1671908   21129     0        
Allow    Ingress     1          ANY          NONE         disabled    21982     257       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


