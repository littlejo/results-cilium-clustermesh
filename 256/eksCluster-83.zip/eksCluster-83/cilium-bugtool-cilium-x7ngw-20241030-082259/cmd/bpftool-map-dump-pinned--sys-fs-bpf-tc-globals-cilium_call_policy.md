key: 0d 00 00 00  value: 6b 02 00 00
key: bc 01 00 00  value: 0f 02 00 00
key: 8b 04 00 00  value: 1a 02 00 00
key: 05 0e 00 00  value: 1d 02 00 00
Found 4 elements
