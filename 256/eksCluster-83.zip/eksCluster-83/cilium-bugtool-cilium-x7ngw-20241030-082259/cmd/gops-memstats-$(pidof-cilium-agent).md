alloc: 201.74MB (211536608 bytes)
total-alloc: 2.25GB (2413633616 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63404939
frees: 61253805
heap-alloc: 201.74MB (211536608 bytes)
heap-sys: 247.45MB (259473408 bytes)
heap-idle: 23.25MB (24379392 bytes)
heap-in-use: 224.20MB (235094016 bytes)
heap-released: 2.30MB (2416640 bytes)
heap-objects: 2151134
stack-in-use: 64.50MB (67633152 bytes)
stack-sys: 64.50MB (67633152 bytes)
stack-mspan-inuse: 3.49MB (3664160 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 978.73KB (1002217 bytes)
gc-sys: 6.04MB (6334000 bytes)
next-gc: when heap-alloc >= 208.05MB (218161272 bytes)
last-gc: 2024-10-30 08:22:55.508601093 +0000 UTC
gc-pause-total: 12.20678ms
gc-pause: 473821
gc-pause-end: 1730276575508601093
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.00035508319215251527
enable-gc: true
debug-gc: false
