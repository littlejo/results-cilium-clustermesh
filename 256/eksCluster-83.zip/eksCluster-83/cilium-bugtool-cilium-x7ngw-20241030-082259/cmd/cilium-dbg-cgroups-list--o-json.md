[
  {
    "containers": [
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58a66304_24e2_4aef_9050_e19c93ef4600.slice/cri-containerd-e4cce065bf84d9295bae7bf7bf5a7cee2ede31eb710cba17f691eec6af0c3957.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58a66304_24e2_4aef_9050_e19c93ef4600.slice/cri-containerd-e9f404387b68403dc41d74ddebc697be8040473569bee9cedffe5e8082c2a320.scope"
      },
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod58a66304_24e2_4aef_9050_e19c93ef4600.slice/cri-containerd-48c06068613f7d34662fbc52f512a1be47f3808432301872a467bb1265adfd2f.scope"
      }
    ],
    "ips": [
      "10.83.0.71"
    ],
    "name": "clustermesh-apiserver-6f4db8cc9c-g485j",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod31990d08_1ea5_4e8a_9952_cda492ddaae0.slice/cri-containerd-35c4b2966adf88c5bb10df28c1a8b679232cdb3b0829ea26a34edc1da4a6d46f.scope"
      }
    ],
    "ips": [
      "10.83.0.135"
    ],
    "name": "coredns-cc6ccd49c-f75ft",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod30090a20_48bd_4fc5_b977_19b4e8f7db4c.slice/cri-containerd-be56103fe82106dad69e7f4a38929c53e962a68701a1308cfd11bcba119e421d.scope"
      }
    ],
    "ips": [
      "10.83.0.48"
    ],
    "name": "coredns-cc6ccd49c-5qpqn",
    "namespace": "kube-system"
  }
]

