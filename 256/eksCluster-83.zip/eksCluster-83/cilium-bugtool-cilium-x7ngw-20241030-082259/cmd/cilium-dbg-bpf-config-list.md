KEY             VALUE
AgentLiveness   2060386003488
UTimeOffset     3379442484375000
