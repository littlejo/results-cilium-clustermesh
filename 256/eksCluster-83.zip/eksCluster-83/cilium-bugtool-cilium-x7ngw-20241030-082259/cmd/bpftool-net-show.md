xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 497
ens6(5) clsact/ingress cil_from_netdev-ens6 id 505
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 492
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 487
cilium_host(7) clsact/egress cil_from_host-cilium_host id 486
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 479
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 547
lxc0a61d35fa4c2(12) clsact/ingress cil_from_container-lxc0a61d35fa4c2 id 543
lxc385cd2fac929(14) clsact/ingress cil_from_container-lxc385cd2fac929 id 528
lxc2331a84f9675(18) clsact/ingress cil_from_container-lxc2331a84f9675 id 609

flow_dissector:

netfilter:

