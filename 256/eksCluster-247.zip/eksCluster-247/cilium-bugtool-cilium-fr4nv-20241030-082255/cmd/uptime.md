 08:22:56 up 29 min,  0 users,  load average: 0.31, 0.34, 0.23
