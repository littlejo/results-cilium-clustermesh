Endpoint ID: 1734
Path: /sys/fs/bpf/tc/globals/cilium_policy_01734

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    116587   1341      0        
Allow    Egress      0          ANY          NONE         disabled    16745    181       0        


Endpoint ID: 2127
Path: /sys/fs/bpf/tc/globals/cilium_policy_02127

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1652808   20880     0        
Allow    Ingress     1          ANY          NONE         disabled    18732     222       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2405
Path: /sys/fs/bpf/tc/globals/cilium_policy_02405

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11576564   115499    0        
Allow    Ingress     1          ANY          NONE         disabled    10558939   111216    0        
Allow    Egress      0          ANY          NONE         disabled    13199260   129830    0        


Endpoint ID: 3157
Path: /sys/fs/bpf/tc/globals/cilium_policy_03157

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    116020   1336      0        
Allow    Egress      0          ANY          NONE         disabled    16132    174       0        


Endpoint ID: 3338
Path: /sys/fs/bpf/tc/globals/cilium_policy_03338

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


