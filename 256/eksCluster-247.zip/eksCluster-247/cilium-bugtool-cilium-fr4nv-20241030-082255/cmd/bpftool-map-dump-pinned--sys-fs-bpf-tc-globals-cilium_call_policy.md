key: c6 06 00 00  value: 09 02 00 00
key: 4f 08 00 00  value: 25 02 00 00
key: 65 09 00 00  value: 77 02 00 00
key: 55 0c 00 00  value: fe 01 00 00
Found 4 elements
