USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         683  0.0  0.0 1228488 1756 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         674  0.0  0.0 1228744 3600 ?        Rsl  08:22   0:00 /bin/gops pprof-cpu 1
root         668  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         638  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         637  0.0  0.2 1240432 16176 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         692  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         698  0.0  0.2 1240432 16176 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         630  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  4.1  4.7 1606080 380788 ?      Ssl  08:03   0:49 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.0  0.0 1229744 7112 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
