alloc: 199.35MB (209033872 bytes)
total-alloc: 2.29GB (2462558320 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 64238269
frees: 62046025
heap-alloc: 199.35MB (209033872 bytes)
heap-sys: 251.17MB (263372800 bytes)
heap-idle: 32.49MB (34070528 bytes)
heap-in-use: 218.68MB (229302272 bytes)
heap-released: 6.05MB (6348800 bytes)
heap-objects: 2192244
stack-in-use: 64.78MB (67928064 bytes)
stack-sys: 64.78MB (67928064 bytes)
stack-mspan-inuse: 3.54MB (3708480 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 996.49KB (1020409 bytes)
gc-sys: 6.03MB (6319616 bytes)
next-gc: when heap-alloc >= 231.16MB (242387688 bytes)
last-gc: 2024-10-30 08:22:56.649299418 +0000 UTC
gc-pause-total: 11.424881ms
gc-pause: 101737
gc-pause-end: 1730276576649299418
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.000587548913139176
enable-gc: true
debug-gc: false
