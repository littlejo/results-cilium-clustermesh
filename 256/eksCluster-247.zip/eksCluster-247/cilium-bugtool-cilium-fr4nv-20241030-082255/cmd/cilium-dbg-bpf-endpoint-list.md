IP ADDRESS         LOCAL ENDPOINT INFO
10.247.0.75:0      id=3157  sec_id=8126776 flags=0x0000 ifindex=14  mac=86:B5:CF:D8:68:6B nodemac=D2:85:84:5D:4D:CF   
10.247.0.77:0      id=2127  sec_id=4     flags=0x0000 ifindex=10  mac=F2:D5:17:32:AD:71 nodemac=22:B5:16:3E:86:01     
10.247.0.69:0      (localhost)                                                                                        
172.31.249.125:0   (localhost)                                                                                        
10.247.0.185:0     id=1734  sec_id=8126776 flags=0x0000 ifindex=12  mac=9E:B3:C3:0A:23:EC nodemac=36:0B:4E:0F:38:A7   
10.247.0.144:0     id=2405  sec_id=8149046 flags=0x0000 ifindex=18  mac=4E:45:F3:02:98:34 nodemac=52:47:B5:50:BB:CC   
172.31.217.105:0   (localhost)                                                                                        
