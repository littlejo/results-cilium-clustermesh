{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:13.917Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.217.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:13.917Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.249.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:13.917Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.448Z",
  "value": "id=1734  sec_id=8126776 flags=0x0000 ifindex=12  mac=9E:B3:C3:0A:23:EC nodemac=36:0B:4E:0F:38:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.449Z",
  "value": "id=2127  sec_id=4     flags=0x0000 ifindex=10  mac=F2:D5:17:32:AD:71 nodemac=22:B5:16:3E:86:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.503Z",
  "value": "id=3157  sec_id=8126776 flags=0x0000 ifindex=14  mac=86:B5:CF:D8:68:6B nodemac=D2:85:84:5D:4D:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.564Z",
  "value": "id=1734  sec_id=8126776 flags=0x0000 ifindex=12  mac=9E:B3:C3:0A:23:EC nodemac=36:0B:4E:0F:38:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.653Z",
  "value": "id=2127  sec_id=4     flags=0x0000 ifindex=10  mac=F2:D5:17:32:AD:71 nodemac=22:B5:16:3E:86:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:05.870Z",
  "value": "id=1734  sec_id=8126776 flags=0x0000 ifindex=12  mac=9E:B3:C3:0A:23:EC nodemac=36:0B:4E:0F:38:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:05.871Z",
  "value": "id=2127  sec_id=4     flags=0x0000 ifindex=10  mac=F2:D5:17:32:AD:71 nodemac=22:B5:16:3E:86:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:05.871Z",
  "value": "id=3157  sec_id=8126776 flags=0x0000 ifindex=14  mac=86:B5:CF:D8:68:6B nodemac=D2:85:84:5D:4D:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:05.899Z",
  "value": "id=1542  sec_id=8149046 flags=0x0000 ifindex=16  mac=AE:CD:0F:43:D2:23 nodemac=6E:0D:13:E3:F6:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:05.899Z",
  "value": "id=1542  sec_id=8149046 flags=0x0000 ifindex=16  mac=AE:CD:0F:43:D2:23 nodemac=6E:0D:13:E3:F6:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:06.870Z",
  "value": "id=1542  sec_id=8149046 flags=0x0000 ifindex=16  mac=AE:CD:0F:43:D2:23 nodemac=6E:0D:13:E3:F6:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:06.870Z",
  "value": "id=3157  sec_id=8126776 flags=0x0000 ifindex=14  mac=86:B5:CF:D8:68:6B nodemac=D2:85:84:5D:4D:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:06.870Z",
  "value": "id=1734  sec_id=8126776 flags=0x0000 ifindex=12  mac=9E:B3:C3:0A:23:EC nodemac=36:0B:4E:0F:38:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:06.871Z",
  "value": "id=2127  sec_id=4     flags=0x0000 ifindex=10  mac=F2:D5:17:32:AD:71 nodemac=22:B5:16:3E:86:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.437Z",
  "value": "id=2405  sec_id=8149046 flags=0x0000 ifindex=18  mac=4E:45:F3:02:98:34 nodemac=52:47:B5:50:BB:CC"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.247.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.825Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.689Z",
  "value": "id=1734  sec_id=8126776 flags=0x0000 ifindex=12  mac=9E:B3:C3:0A:23:EC nodemac=36:0B:4E:0F:38:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.689Z",
  "value": "id=3157  sec_id=8126776 flags=0x0000 ifindex=14  mac=86:B5:CF:D8:68:6B nodemac=D2:85:84:5D:4D:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.690Z",
  "value": "id=2405  sec_id=8149046 flags=0x0000 ifindex=18  mac=4E:45:F3:02:98:34 nodemac=52:47:B5:50:BB:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.690Z",
  "value": "id=2127  sec_id=4     flags=0x0000 ifindex=10  mac=F2:D5:17:32:AD:71 nodemac=22:B5:16:3E:86:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.688Z",
  "value": "id=2127  sec_id=4     flags=0x0000 ifindex=10  mac=F2:D5:17:32:AD:71 nodemac=22:B5:16:3E:86:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.689Z",
  "value": "id=1734  sec_id=8126776 flags=0x0000 ifindex=12  mac=9E:B3:C3:0A:23:EC nodemac=36:0B:4E:0F:38:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.689Z",
  "value": "id=3157  sec_id=8126776 flags=0x0000 ifindex=14  mac=86:B5:CF:D8:68:6B nodemac=D2:85:84:5D:4D:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.689Z",
  "value": "id=2405  sec_id=8149046 flags=0x0000 ifindex=18  mac=4E:45:F3:02:98:34 nodemac=52:47:B5:50:BB:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.688Z",
  "value": "id=3157  sec_id=8126776 flags=0x0000 ifindex=14  mac=86:B5:CF:D8:68:6B nodemac=D2:85:84:5D:4D:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.688Z",
  "value": "id=2405  sec_id=8149046 flags=0x0000 ifindex=18  mac=4E:45:F3:02:98:34 nodemac=52:47:B5:50:BB:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.689Z",
  "value": "id=2127  sec_id=4     flags=0x0000 ifindex=10  mac=F2:D5:17:32:AD:71 nodemac=22:B5:16:3E:86:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.689Z",
  "value": "id=1734  sec_id=8126776 flags=0x0000 ifindex=12  mac=9E:B3:C3:0A:23:EC nodemac=36:0B:4E:0F:38:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.689Z",
  "value": "id=1734  sec_id=8126776 flags=0x0000 ifindex=12  mac=9E:B3:C3:0A:23:EC nodemac=36:0B:4E:0F:38:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.689Z",
  "value": "id=3157  sec_id=8126776 flags=0x0000 ifindex=14  mac=86:B5:CF:D8:68:6B nodemac=D2:85:84:5D:4D:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.690Z",
  "value": "id=2405  sec_id=8149046 flags=0x0000 ifindex=18  mac=4E:45:F3:02:98:34 nodemac=52:47:B5:50:BB:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.247.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.690Z",
  "value": "id=2127  sec_id=4     flags=0x0000 ifindex=10  mac=F2:D5:17:32:AD:71 nodemac=22:B5:16:3E:86:01"
}

