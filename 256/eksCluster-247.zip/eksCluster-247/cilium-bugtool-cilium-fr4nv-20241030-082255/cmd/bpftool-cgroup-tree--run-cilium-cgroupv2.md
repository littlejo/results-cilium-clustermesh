CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podef953b9f_c2f5_4d7f_8493_46ab1215e456.slice/cri-containerd-7e1caa9778cafb4bb1bef96a5ffcfe81f6ee50de5451052899ff1d161fe29aad.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podef953b9f_c2f5_4d7f_8493_46ab1215e456.slice/cri-containerd-4035a2869d18cf6e82611a025c15cef87108e232ca9f5e065de08a26191c9bc7.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda631768d_28c4_4ecf_a90a_b2fa82af4d84.slice/cri-containerd-d2db928b482933f26589c53e5b87cd7253f37d4f50b5b601395fab2a96ca18e0.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda631768d_28c4_4ecf_a90a_b2fa82af4d84.slice/cri-containerd-6253539f79030de4d298d921b7a6b6ca4d05b6074808ba22f9c5c5a22f7982cd.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad940d35_26c6_4723_9128_e832bb39caf6.slice/cri-containerd-da83f6e09874fccdd68f085b17f3ad668af24da501926c3900c6c7d7c8522333.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad940d35_26c6_4723_9128_e832bb39caf6.slice/cri-containerd-a786f78221eea9f2177d166aa2806131f860d3e094e2894c175a0a11735f427d.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poded02ac76_5bfd_4819_8608_6c4cb3ec71fc.slice/cri-containerd-30d7f358348785273dbfd2853b1fd5e108290cb8c65a2fc17ae2b51cb64b88fa.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poded02ac76_5bfd_4819_8608_6c4cb3ec71fc.slice/cri-containerd-add30c9c74ce16c3a683db749c217d313c4131bf4bd0c0ed4a77a3680026372c.scope
    543      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode027750a_6edc_41f6_9c00_e4868b656c94.slice/cri-containerd-871a8c24ae9e47b7d71022497e413db4c82f9243c7db9044007e59547cf1b9d4.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode027750a_6edc_41f6_9c00_e4868b656c94.slice/cri-containerd-e4aba1a347b9a88d4fc631dfc5b52921fb49d96df048adf6db3d058d965120f7.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca177c2f_3d1f_4a4b_af63_d193c0dfdca3.slice/cri-containerd-61f90491fca79f4db395f6f7bd0e19e19438d9e2d0f6030ff22dc6f9139d67ad.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca177c2f_3d1f_4a4b_af63_d193c0dfdca3.slice/cri-containerd-169c75f6f65a8e3eb300b5afceb36db4fd536ea25c550e2c1a5743380f11fce3.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca177c2f_3d1f_4a4b_af63_d193c0dfdca3.slice/cri-containerd-cca2fc67f3d2726dbb04c74f499dd7d0502d0698262317b121a301aa4f011fef.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca177c2f_3d1f_4a4b_af63_d193c0dfdca3.slice/cri-containerd-eef4fa42b3e9943173231af195df90ddcf21394fd455b56f0a11a00a6eccab51.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd15784a1_5be6_4fb2_b612_7f75638214b1.slice/cri-containerd-12f630b9ff0e16b1f08486fa4e7a26aa8c8ae3ad2d0b90d3b5a99bcb1e4c9ea5.scope
    117      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd15784a1_5be6_4fb2_b612_7f75638214b1.slice/cri-containerd-3219e0240db3078d49fc2ef60dc7f8b9a048b4f03520e3650052cd086ebf7eca.scope
    101      cgroup_device   multi                                          
