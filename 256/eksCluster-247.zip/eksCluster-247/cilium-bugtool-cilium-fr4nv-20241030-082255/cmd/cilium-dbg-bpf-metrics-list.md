REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37854     3001318     677    bpf_overlay.c
Interface                 INGRESS     652972    132766236   1132   bpf_host.c
Success                   EGRESS      17673     1396352     1694   bpf_host.c
Success                   EGRESS      276308    34576246    1308   bpf_lxc.c
Success                   EGRESS      38762     3069409     53     encap.h
Success                   INGRESS     320605    36123043    86     l3.h
Success                   INGRESS     341437    37772055    235    trace.h
Unsupported L3 protocol   EGRESS      38        2796        1492   bpf_lxc.c
