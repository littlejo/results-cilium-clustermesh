1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:ce:45:f4:14:5f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.217.105/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1849sec preferred_lft 1849sec
    inet6 fe80::8ce:45ff:fef4:145f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:b4:8a:0c:c9:c9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.249.125/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8b4:8aff:fe0c:c9c9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:35:a1:06:fc:12 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::bc35:a1ff:fe06:fc12/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:46:f8:53:7c:cb brd ff:ff:ff:ff:ff:ff
    inet 10.247.0.69/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e846:f8ff:fe53:7ccb/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 9e:36:e3:09:7d:7b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9c36:e3ff:fe09:7d7b/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:b5:16:3e:86:01 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::20b5:16ff:fe3e:8601/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc7c45dcc9a82d@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:0b:4e:0f:38:a7 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::340b:4eff:fe0f:38a7/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc04c5181acda6@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:85:84:5d:4d:cf brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d085:84ff:fe5d:4dcf/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc93e0eea1e34a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:47:b5:50:bb:cc brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::5047:b5ff:fe50:bbcc/64 scope link 
       valid_lft forever preferred_lft forever
