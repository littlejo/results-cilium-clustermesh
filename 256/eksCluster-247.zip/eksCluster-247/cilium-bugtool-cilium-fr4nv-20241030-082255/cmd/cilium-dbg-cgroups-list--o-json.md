[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poded02ac76_5bfd_4819_8608_6c4cb3ec71fc.slice/cri-containerd-30d7f358348785273dbfd2853b1fd5e108290cb8c65a2fc17ae2b51cb64b88fa.scope"
      }
    ],
    "ips": [
      "10.247.0.75"
    ],
    "name": "coredns-cc6ccd49c-rcq2v",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca177c2f_3d1f_4a4b_af63_d193c0dfdca3.slice/cri-containerd-eef4fa42b3e9943173231af195df90ddcf21394fd455b56f0a11a00a6eccab51.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca177c2f_3d1f_4a4b_af63_d193c0dfdca3.slice/cri-containerd-61f90491fca79f4db395f6f7bd0e19e19438d9e2d0f6030ff22dc6f9139d67ad.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca177c2f_3d1f_4a4b_af63_d193c0dfdca3.slice/cri-containerd-cca2fc67f3d2726dbb04c74f499dd7d0502d0698262317b121a301aa4f011fef.scope"
      }
    ],
    "ips": [
      "10.247.0.144"
    ],
    "name": "clustermesh-apiserver-75b5f7b5f8-zc6h8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda631768d_28c4_4ecf_a90a_b2fa82af4d84.slice/cri-containerd-d2db928b482933f26589c53e5b87cd7253f37d4f50b5b601395fab2a96ca18e0.scope"
      }
    ],
    "ips": [
      "10.247.0.185"
    ],
    "name": "coredns-cc6ccd49c-grm7b",
    "namespace": "kube-system"
  }
]

