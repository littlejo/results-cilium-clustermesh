{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:43.463Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.210.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:43.463Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.232.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:43.463Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:48.254Z",
  "value": "id=176   sec_id=4     flags=0x0000 ifindex=10  mac=C2:54:6D:A4:29:33 nodemac=5E:90:58:A9:2B:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:48.264Z",
  "value": "id=3320  sec_id=6512494 flags=0x0000 ifindex=12  mac=BE:58:DF:E0:BF:FC nodemac=AE:66:B8:83:A6:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:48.293Z",
  "value": "id=3563  sec_id=6512494 flags=0x0000 ifindex=14  mac=F6:10:FA:58:6A:F7 nodemac=4A:A4:81:B3:7E:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:48.312Z",
  "value": "id=176   sec_id=4     flags=0x0000 ifindex=10  mac=C2:54:6D:A4:29:33 nodemac=5E:90:58:A9:2B:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:26.909Z",
  "value": "id=3563  sec_id=6512494 flags=0x0000 ifindex=14  mac=F6:10:FA:58:6A:F7 nodemac=4A:A4:81:B3:7E:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:26.910Z",
  "value": "id=176   sec_id=4     flags=0x0000 ifindex=10  mac=C2:54:6D:A4:29:33 nodemac=5E:90:58:A9:2B:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:26.910Z",
  "value": "id=3320  sec_id=6512494 flags=0x0000 ifindex=12  mac=BE:58:DF:E0:BF:FC nodemac=AE:66:B8:83:A6:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:26.939Z",
  "value": "id=126   sec_id=6496639 flags=0x0000 ifindex=16  mac=72:8E:D6:21:F1:D8 nodemac=A2:50:32:39:BF:05"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:26.939Z",
  "value": "id=126   sec_id=6496639 flags=0x0000 ifindex=16  mac=72:8E:D6:21:F1:D8 nodemac=A2:50:32:39:BF:05"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:27.908Z",
  "value": "id=126   sec_id=6496639 flags=0x0000 ifindex=16  mac=72:8E:D6:21:F1:D8 nodemac=A2:50:32:39:BF:05"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:27.909Z",
  "value": "id=3320  sec_id=6512494 flags=0x0000 ifindex=12  mac=BE:58:DF:E0:BF:FC nodemac=AE:66:B8:83:A6:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:27.909Z",
  "value": "id=176   sec_id=4     flags=0x0000 ifindex=10  mac=C2:54:6D:A4:29:33 nodemac=5E:90:58:A9:2B:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:27.909Z",
  "value": "id=3563  sec_id=6512494 flags=0x0000 ifindex=14  mac=F6:10:FA:58:6A:F7 nodemac=4A:A4:81:B3:7E:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.191Z",
  "value": "id=2239  sec_id=6496639 flags=0x0000 ifindex=18  mac=9A:0F:93:CF:BD:68 nodemac=16:8E:27:4C:2D:0D"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.197.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.816Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.630Z",
  "value": "id=2239  sec_id=6496639 flags=0x0000 ifindex=18  mac=9A:0F:93:CF:BD:68 nodemac=16:8E:27:4C:2D:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.631Z",
  "value": "id=176   sec_id=4     flags=0x0000 ifindex=10  mac=C2:54:6D:A4:29:33 nodemac=5E:90:58:A9:2B:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.631Z",
  "value": "id=3320  sec_id=6512494 flags=0x0000 ifindex=12  mac=BE:58:DF:E0:BF:FC nodemac=AE:66:B8:83:A6:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.632Z",
  "value": "id=3563  sec_id=6512494 flags=0x0000 ifindex=14  mac=F6:10:FA:58:6A:F7 nodemac=4A:A4:81:B3:7E:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:50.680Z",
  "value": "id=176   sec_id=4     flags=0x0000 ifindex=10  mac=C2:54:6D:A4:29:33 nodemac=5E:90:58:A9:2B:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:50.692Z",
  "value": "id=3320  sec_id=6512494 flags=0x0000 ifindex=12  mac=BE:58:DF:E0:BF:FC nodemac=AE:66:B8:83:A6:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:50.693Z",
  "value": "id=3563  sec_id=6512494 flags=0x0000 ifindex=14  mac=F6:10:FA:58:6A:F7 nodemac=4A:A4:81:B3:7E:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:50.693Z",
  "value": "id=2239  sec_id=6496639 flags=0x0000 ifindex=18  mac=9A:0F:93:CF:BD:68 nodemac=16:8E:27:4C:2D:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:51.632Z",
  "value": "id=176   sec_id=4     flags=0x0000 ifindex=10  mac=C2:54:6D:A4:29:33 nodemac=5E:90:58:A9:2B:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:51.632Z",
  "value": "id=3320  sec_id=6512494 flags=0x0000 ifindex=12  mac=BE:58:DF:E0:BF:FC nodemac=AE:66:B8:83:A6:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:51.632Z",
  "value": "id=2239  sec_id=6496639 flags=0x0000 ifindex=18  mac=9A:0F:93:CF:BD:68 nodemac=16:8E:27:4C:2D:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:51.632Z",
  "value": "id=3563  sec_id=6512494 flags=0x0000 ifindex=14  mac=F6:10:FA:58:6A:F7 nodemac=4A:A4:81:B3:7E:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:52.633Z",
  "value": "id=3563  sec_id=6512494 flags=0x0000 ifindex=14  mac=F6:10:FA:58:6A:F7 nodemac=4A:A4:81:B3:7E:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:52.633Z",
  "value": "id=2239  sec_id=6496639 flags=0x0000 ifindex=18  mac=9A:0F:93:CF:BD:68 nodemac=16:8E:27:4C:2D:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:52.634Z",
  "value": "id=176   sec_id=4     flags=0x0000 ifindex=10  mac=C2:54:6D:A4:29:33 nodemac=5E:90:58:A9:2B:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.197.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:52.634Z",
  "value": "id=3320  sec_id=6512494 flags=0x0000 ifindex=12  mac=BE:58:DF:E0:BF:FC nodemac=AE:66:B8:83:A6:EB"
}

