ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.165.244:443 (active)    
                                        2 => 172.31.227.47:443 (active)     
2    10.100.210.27:443   ClusterIP      1 => 172.31.232.195:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.197.0.98:53 (active)        
                                        2 => 10.197.0.233:53 (active)       
4    10.100.0.10:9153    ClusterIP      1 => 10.197.0.98:9153 (active)      
                                        2 => 10.197.0.233:9153 (active)     
5    10.100.61.49:2379   ClusterIP      1 => 10.197.0.211:2379 (active)     
