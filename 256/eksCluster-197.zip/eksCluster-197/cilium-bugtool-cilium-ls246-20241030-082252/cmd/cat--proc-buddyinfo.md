Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal     84     84     89      0     12    122     53     28     12      6    855 
