xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 504
ens6(5) clsact/ingress cil_from_netdev-ens6 id 507
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 497
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 485
cilium_host(7) clsact/egress cil_from_host-cilium_host id 491
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 544
lxc0797281262bc(12) clsact/ingress cil_from_container-lxc0797281262bc id 514
lxcaa83e4bf1f53(14) clsact/ingress cil_from_container-lxcaa83e4bf1f53 id 550
lxc551bcce60e84(18) clsact/ingress cil_from_container-lxc551bcce60e84 id 621

flow_dissector:

netfilter:

