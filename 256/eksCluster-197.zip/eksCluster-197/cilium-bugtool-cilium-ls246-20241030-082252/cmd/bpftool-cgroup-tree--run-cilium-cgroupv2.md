CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9296dc23_ce62_47eb_85af_4ba38c901fae.slice/cri-containerd-f1529aecbbc0d3e6d749793be7865929defc7ac4529d3b78a4860ea6a91dc0d0.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9296dc23_ce62_47eb_85af_4ba38c901fae.slice/cri-containerd-dd8b5e2e2e3951521de89502788a089ee7f407b16b48f819bc20812011497269.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad1b2288_64b2_4019_9e17_b985f3e66adf.slice/cri-containerd-6f05ef86b6d01a26d1577b3bbb15eeb99911935bd9f94439cd9cf9948bd9ae11.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad1b2288_64b2_4019_9e17_b985f3e66adf.slice/cri-containerd-ca80b50894893f373e0c2fc6687a8684ccb9ff972b1db339599b25c36550ca3a.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod58480a2c_00b2_4e15_bbab_e12ab323a6a7.slice/cri-containerd-59ee00a3800a476ff52717fe45deb76d36d31a52b9fd4711d778084743b95099.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod58480a2c_00b2_4e15_bbab_e12ab323a6a7.slice/cri-containerd-aa0b64cd26fa2492fd0a0232a46a63a35721b6bc8d09949efcaee0ec87c62ca5.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad1ae588_843d_48cf_9152_901a6cfde666.slice/cri-containerd-25d43969f69c7f61345023037b575d40e8db8d1d9571144d3ec2b11a07872d31.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad1ae588_843d_48cf_9152_901a6cfde666.slice/cri-containerd-262262ec91c6553beccdf71734f78d4a953306765fabab0084555d33852aae10.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9e9f61d_67cb_4396_897e_93de6a6f58c0.slice/cri-containerd-db173790b56fde91cc659ebe9f050c3f5b045806c22a0a3d9b43495b626aa4d7.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9e9f61d_67cb_4396_897e_93de6a6f58c0.slice/cri-containerd-52ccbf4a68e58a35aeef3de18051ddeca462b8037886ac486e06bca9b7cc3d73.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod47fa9aa2_7601_44ef_a72d_966055f7018e.slice/cri-containerd-f672b506a43955bf4d05b4c52cab5d47ee90c33cd6b4a18f3e0d7b74e8f4961d.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod47fa9aa2_7601_44ef_a72d_966055f7018e.slice/cri-containerd-dfbd6ed7a3eb123b39e00131f035dd80942aa01ef723d19c0669c985266daa4d.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod47fa9aa2_7601_44ef_a72d_966055f7018e.slice/cri-containerd-fc7279a94bb0bcd2d96d5fe0b9acd4b6b6310178a8f025b26514ec5e85be9c7c.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod47fa9aa2_7601_44ef_a72d_966055f7018e.slice/cri-containerd-1f70c5b3941c34debfcf7a879d990bcf7e946cf366c97fe6ec70c90e6eb8d863.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode311e847_801a_4c52_a6eb_cb2ee0d69a4f.slice/cri-containerd-37e625ff781bb6a5ef61d0041dec8da48a68b443302a24caf6c040bbeb0f44ad.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode311e847_801a_4c52_a6eb_cb2ee0d69a4f.slice/cri-containerd-04d078a0dbc341e08570187dbb40b1195b14a5bc7c2b2f3415e8dfa02232e8b8.scope
    94       cgroup_device   multi                                          
