Endpoint ID: 176
Path: /sys/fs/bpf/tc/globals/cilium_policy_00176

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1657374   20961     0        
Allow    Ingress     1          ANY          NONE         disabled    18048     212       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 439
Path: /sys/fs/bpf/tc/globals/cilium_policy_00439

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2239
Path: /sys/fs/bpf/tc/globals/cilium_policy_02239

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11205827   109224    0        
Allow    Ingress     1          ANY          NONE         disabled    9115072    95058     0        
Allow    Egress      0          ANY          NONE         disabled    10647407   106101    0        


Endpoint ID: 3320
Path: /sys/fs/bpf/tc/globals/cilium_policy_03320

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    119542   1375      0        
Allow    Egress      0          ANY          NONE         disabled    17479    190       0        


Endpoint ID: 3563
Path: /sys/fs/bpf/tc/globals/cilium_policy_03563

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    118111   1357      0        
Allow    Egress      0          ANY          NONE         disabled    15519    165       0        


