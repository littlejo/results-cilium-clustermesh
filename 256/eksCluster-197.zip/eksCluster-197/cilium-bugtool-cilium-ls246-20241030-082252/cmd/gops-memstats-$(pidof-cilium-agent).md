alloc: 169.29MB (177509232 bytes)
total-alloc: 2.15GB (2310775824 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 61858255
frees: 59945496
heap-alloc: 169.29MB (177509232 bytes)
heap-sys: 247.35MB (259366912 bytes)
heap-idle: 52.41MB (54951936 bytes)
heap-in-use: 194.95MB (204414976 bytes)
heap-released: 3.13MB (3284992 bytes)
heap-objects: 1912759
stack-in-use: 64.62MB (67764224 bytes)
stack-sys: 64.62MB (67764224 bytes)
stack-mspan-inuse: 3.31MB (3467680 bytes)
stack-mspan-sys: 3.91MB (4096320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.17MB (1226481 bytes)
gc-sys: 6.01MB (6297112 bytes)
next-gc: when heap-alloc >= 217.17MB (227718248 bytes)
last-gc: 2024-10-30 08:22:54.769814385 +0000 UTC
gc-pause-total: 7.089305ms
gc-pause: 134197
gc-pause-end: 1730276574769814385
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005417178739129787
enable-gc: true
debug-gc: false
