KEY             VALUE
AgentLiveness   1859023066880
UTimeOffset     3379442863281250
