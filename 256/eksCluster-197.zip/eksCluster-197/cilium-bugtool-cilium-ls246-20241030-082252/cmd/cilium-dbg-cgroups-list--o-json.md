[
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod47fa9aa2_7601_44ef_a72d_966055f7018e.slice/cri-containerd-1f70c5b3941c34debfcf7a879d990bcf7e946cf366c97fe6ec70c90e6eb8d863.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod47fa9aa2_7601_44ef_a72d_966055f7018e.slice/cri-containerd-fc7279a94bb0bcd2d96d5fe0b9acd4b6b6310178a8f025b26514ec5e85be9c7c.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod47fa9aa2_7601_44ef_a72d_966055f7018e.slice/cri-containerd-f672b506a43955bf4d05b4c52cab5d47ee90c33cd6b4a18f3e0d7b74e8f4961d.scope"
      }
    ],
    "ips": [
      "10.197.0.211"
    ],
    "name": "clustermesh-apiserver-8469f7878b-j6tpf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad1ae588_843d_48cf_9152_901a6cfde666.slice/cri-containerd-262262ec91c6553beccdf71734f78d4a953306765fabab0084555d33852aae10.scope"
      }
    ],
    "ips": [
      "10.197.0.98"
    ],
    "name": "coredns-cc6ccd49c-9mrz6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod58480a2c_00b2_4e15_bbab_e12ab323a6a7.slice/cri-containerd-59ee00a3800a476ff52717fe45deb76d36d31a52b9fd4711d778084743b95099.scope"
      }
    ],
    "ips": [
      "10.197.0.233"
    ],
    "name": "coredns-cc6ccd49c-g7jlz",
    "namespace": "kube-system"
  }
]

