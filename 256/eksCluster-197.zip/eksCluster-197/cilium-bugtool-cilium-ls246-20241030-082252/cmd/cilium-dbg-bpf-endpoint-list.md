IP ADDRESS         LOCAL ENDPOINT INFO
10.197.0.233:0     id=3320  sec_id=6512494 flags=0x0000 ifindex=12  mac=BE:58:DF:E0:BF:FC nodemac=AE:66:B8:83:A6:EB   
172.31.232.195:0   (localhost)                                                                                        
10.197.0.51:0      id=176   sec_id=4     flags=0x0000 ifindex=10  mac=C2:54:6D:A4:29:33 nodemac=5E:90:58:A9:2B:ED     
172.31.210.47:0    (localhost)                                                                                        
10.197.0.247:0     (localhost)                                                                                        
10.197.0.98:0      id=3563  sec_id=6512494 flags=0x0000 ifindex=14  mac=F6:10:FA:58:6A:F7 nodemac=4A:A4:81:B3:7E:AB   
10.197.0.211:0     id=2239  sec_id=6496639 flags=0x0000 ifindex=18  mac=9A:0F:93:CF:BD:68 nodemac=16:8E:27:4C:2D:0D   
