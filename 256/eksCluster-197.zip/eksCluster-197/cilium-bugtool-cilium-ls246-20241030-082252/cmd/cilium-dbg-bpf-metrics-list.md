REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34252     2703765     677    bpf_overlay.c
Interface                 INGRESS     610549    127754033   1132   bpf_host.c
Success                   EGRESS      13982     1093713     1694   bpf_host.c
Success                   EGRESS      256828    32908655    1308   bpf_lxc.c
Success                   EGRESS      33110     2620040     53     encap.h
Success                   INGRESS     297827    33379731    86     l3.h
Success                   INGRESS     318748    35033829    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
