key: b0 00 00 00  value: 23 02 00 00
key: bf 08 00 00  value: 68 02 00 00
key: f8 0c 00 00  value: 14 02 00 00
key: eb 0d 00 00  value: 19 02 00 00
Found 4 elements
