REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35743     2821016     677    bpf_overlay.c
Interface                 INGRESS     630622    130925643   1132   bpf_host.c
Success                   EGRESS      15396     1206362     1694   bpf_host.c
Success                   EGRESS      265830    33417308    1308   bpf_lxc.c
Success                   EGRESS      35156     2782570     53     encap.h
Success                   INGRESS     306454    34490148    86     l3.h
Success                   INGRESS     327452    36148848    235    trace.h
Unsupported L3 protocol   EGRESS      44        3292        1492   bpf_lxc.c
