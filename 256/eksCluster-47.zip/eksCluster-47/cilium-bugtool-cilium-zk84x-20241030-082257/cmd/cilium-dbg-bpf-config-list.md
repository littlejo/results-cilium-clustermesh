KEY             VALUE
AgentLiveness   2097663058448
UTimeOffset     3379442406250000
