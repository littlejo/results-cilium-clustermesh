Endpoint ID: 129
Path: /sys/fs/bpf/tc/globals/cilium_policy_00129

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    149766   1712      0        
Allow    Egress      0          ANY          NONE         disabled    18834    207       0        


Endpoint ID: 810
Path: /sys/fs/bpf/tc/globals/cilium_policy_00810

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1660354   21020     0        
Allow    Ingress     1          ANY          NONE         disabled    23256     274       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2320
Path: /sys/fs/bpf/tc/globals/cilium_policy_02320

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    150360   1721      0        
Allow    Egress      0          ANY          NONE         disabled    20404    226       0        


Endpoint ID: 2642
Path: /sys/fs/bpf/tc/globals/cilium_policy_02642

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11562127   114362    0        
Allow    Ingress     1          ANY          NONE         disabled    9420585    98689     0        
Allow    Egress      0          ANY          NONE         disabled    11936353   118187    0        


Endpoint ID: 3902
Path: /sys/fs/bpf/tc/globals/cilium_policy_03902

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


