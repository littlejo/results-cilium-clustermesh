1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c1:43:1b:96:59 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.253.19/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3344sec preferred_lft 3344sec
    inet6 fe80::8c1:43ff:fe1b:9659/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:21:dd:03:eb:5f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.245.31/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::821:ddff:fe03:eb5f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:c3:31:8d:6e:54 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a8c3:31ff:fe8d:6e54/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:f1:9d:57:6f:0b brd ff:ff:ff:ff:ff:ff
    inet 10.47.0.179/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::ecf1:9dff:fe57:6f0b/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 22:e1:bb:fd:8e:26 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::20e1:bbff:fefd:8e26/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:2b:62:d1:f8:d4 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::582b:62ff:fed1:f8d4/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc249789499a34@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:e4:6e:17:a6:be brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::88e4:6eff:fe17:a6be/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc9991497e3b46@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:9e:25:27:bd:74 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b09e:25ff:fe27:bd74/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb876be33544e@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:e8:3b:6e:bc:72 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::20e8:3bff:fe6e:bc72/64 scope link 
       valid_lft forever preferred_lft forever
