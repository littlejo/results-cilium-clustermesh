{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:53.105Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.245.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:53.105Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.253.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:53.105Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:57.673Z",
  "value": "id=810   sec_id=4     flags=0x0000 ifindex=10  mac=4A:59:83:6B:98:8E nodemac=5A:2B:62:D1:F8:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:57.675Z",
  "value": "id=129   sec_id=1575285 flags=0x0000 ifindex=12  mac=CE:EC:9A:15:3A:6E nodemac=8A:E4:6E:17:A6:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:57.713Z",
  "value": "id=810   sec_id=4     flags=0x0000 ifindex=10  mac=4A:59:83:6B:98:8E nodemac=5A:2B:62:D1:F8:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:57.714Z",
  "value": "id=129   sec_id=1575285 flags=0x0000 ifindex=12  mac=CE:EC:9A:15:3A:6E nodemac=8A:E4:6E:17:A6:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:57.741Z",
  "value": "id=2320  sec_id=1575285 flags=0x0000 ifindex=14  mac=3E:11:96:54:45:34 nodemac=B2:9E:25:27:BD:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:44.238Z",
  "value": "id=129   sec_id=1575285 flags=0x0000 ifindex=12  mac=CE:EC:9A:15:3A:6E nodemac=8A:E4:6E:17:A6:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:44.238Z",
  "value": "id=2320  sec_id=1575285 flags=0x0000 ifindex=14  mac=3E:11:96:54:45:34 nodemac=B2:9E:25:27:BD:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:44.239Z",
  "value": "id=810   sec_id=4     flags=0x0000 ifindex=10  mac=4A:59:83:6B:98:8E nodemac=5A:2B:62:D1:F8:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:44.272Z",
  "value": "id=2227  sec_id=1586988 flags=0x0000 ifindex=16  mac=72:3E:73:3D:96:FA nodemac=F6:89:F9:6A:6E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:45.239Z",
  "value": "id=2227  sec_id=1586988 flags=0x0000 ifindex=16  mac=72:3E:73:3D:96:FA nodemac=F6:89:F9:6A:6E:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:45.239Z",
  "value": "id=810   sec_id=4     flags=0x0000 ifindex=10  mac=4A:59:83:6B:98:8E nodemac=5A:2B:62:D1:F8:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:45.239Z",
  "value": "id=129   sec_id=1575285 flags=0x0000 ifindex=12  mac=CE:EC:9A:15:3A:6E nodemac=8A:E4:6E:17:A6:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:45.240Z",
  "value": "id=2320  sec_id=1575285 flags=0x0000 ifindex=14  mac=3E:11:96:54:45:34 nodemac=B2:9E:25:27:BD:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.281Z",
  "value": "id=2642  sec_id=1586988 flags=0x0000 ifindex=18  mac=56:7D:B5:D6:72:39 nodemac=22:E8:3B:6E:BC:72"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.47.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.684Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.313Z",
  "value": "id=2642  sec_id=1586988 flags=0x0000 ifindex=18  mac=56:7D:B5:D6:72:39 nodemac=22:E8:3B:6E:BC:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.314Z",
  "value": "id=810   sec_id=4     flags=0x0000 ifindex=10  mac=4A:59:83:6B:98:8E nodemac=5A:2B:62:D1:F8:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.315Z",
  "value": "id=129   sec_id=1575285 flags=0x0000 ifindex=12  mac=CE:EC:9A:15:3A:6E nodemac=8A:E4:6E:17:A6:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.315Z",
  "value": "id=2320  sec_id=1575285 flags=0x0000 ifindex=14  mac=3E:11:96:54:45:34 nodemac=B2:9E:25:27:BD:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.335Z",
  "value": "id=810   sec_id=4     flags=0x0000 ifindex=10  mac=4A:59:83:6B:98:8E nodemac=5A:2B:62:D1:F8:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.336Z",
  "value": "id=129   sec_id=1575285 flags=0x0000 ifindex=12  mac=CE:EC:9A:15:3A:6E nodemac=8A:E4:6E:17:A6:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.337Z",
  "value": "id=2320  sec_id=1575285 flags=0x0000 ifindex=14  mac=3E:11:96:54:45:34 nodemac=B2:9E:25:27:BD:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.338Z",
  "value": "id=2642  sec_id=1586988 flags=0x0000 ifindex=18  mac=56:7D:B5:D6:72:39 nodemac=22:E8:3B:6E:BC:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.307Z",
  "value": "id=2642  sec_id=1586988 flags=0x0000 ifindex=18  mac=56:7D:B5:D6:72:39 nodemac=22:E8:3B:6E:BC:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.308Z",
  "value": "id=810   sec_id=4     flags=0x0000 ifindex=10  mac=4A:59:83:6B:98:8E nodemac=5A:2B:62:D1:F8:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.308Z",
  "value": "id=129   sec_id=1575285 flags=0x0000 ifindex=12  mac=CE:EC:9A:15:3A:6E nodemac=8A:E4:6E:17:A6:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.309Z",
  "value": "id=2320  sec_id=1575285 flags=0x0000 ifindex=14  mac=3E:11:96:54:45:34 nodemac=B2:9E:25:27:BD:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.309Z",
  "value": "id=129   sec_id=1575285 flags=0x0000 ifindex=12  mac=CE:EC:9A:15:3A:6E nodemac=8A:E4:6E:17:A6:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.310Z",
  "value": "id=810   sec_id=4     flags=0x0000 ifindex=10  mac=4A:59:83:6B:98:8E nodemac=5A:2B:62:D1:F8:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.310Z",
  "value": "id=2320  sec_id=1575285 flags=0x0000 ifindex=14  mac=3E:11:96:54:45:34 nodemac=B2:9E:25:27:BD:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.311Z",
  "value": "id=2642  sec_id=1586988 flags=0x0000 ifindex=18  mac=56:7D:B5:D6:72:39 nodemac=22:E8:3B:6E:BC:72"
}

