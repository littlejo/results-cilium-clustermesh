2024-10-30T07:48:32,000000+00:00 Booting Linux on physical CPU 0x0000000000 [0x413fd0c1]
2024-10-30T07:48:32,000000+00:00 Linux version 6.1.112-122.189.amzn2023.aarch64 (mockbuild@ip-10-0-39-248) (gcc (GCC) 11.4.1 20230605 (Red Hat 11.4.1-2), GNU ld version 2.39-6.amzn2023.0.10) #1 SMP Tue Oct  8 17:01:34 UTC 2024
2024-10-30T07:48:32,000000+00:00 efi: EFI v2.70 by EDK II
2024-10-30T07:48:32,000000+00:00 efi: SMBIOS=0x7bed0000 SMBIOS 3.0=0x7beb0000 ACPI=0x786e0000 ACPI 2.0=0x786e0014 MEMATTR=0x7aff0a98 RNG=0x74ca0018 MEMRESERVE=0x784d0d98 
2024-10-30T07:48:32,000000+00:00 random: crng init done
2024-10-30T07:48:32,000000+00:00 ACPI: Early table checksum verification disabled
2024-10-30T07:48:32,000000+00:00 ACPI: RSDP 0x00000000786E0014 000024 (v02 AMAZON)
2024-10-30T07:48:32,000000+00:00 ACPI: XSDT 0x00000000786D00E8 000064 (v01 AMAZON AMZNFACP 00000001      01000013)
2024-10-30T07:48:32,000000+00:00 ACPI: FACP 0x00000000786B0000 000114 (v06 AMAZON AMZNFACP 00000001 AMZN 00000001)
2024-10-30T07:48:32,000000+00:00 ACPI: DSDT 0x0000000078640000 00159D (v02 AMAZON AMZNDSDT 00000001 INTL 20160527)
2024-10-30T07:48:32,000000+00:00 ACPI: FACS 0x0000000078630000 000040
2024-10-30T07:48:32,000000+00:00 ACPI: APIC 0x00000000786C0000 000108 (v04 AMAZON AMZNAPIC 00000001 AMZN 00000001)
2024-10-30T07:48:32,000000+00:00 ACPI: SPCR 0x00000000786A0000 000050 (v02 AMAZON AMZNSPCR 00000001 AMZN 00000001)
2024-10-30T07:48:32,000000+00:00 ACPI: GTDT 0x0000000078690000 000060 (v02 AMAZON AMZNGTDT 00000001 AMZN 00000001)
2024-10-30T07:48:32,000000+00:00 ACPI: MCFG 0x0000000078680000 00003C (v02 AMAZON AMZNMCFG 00000001 AMZN 00000001)
2024-10-30T07:48:32,000000+00:00 ACPI: SLIT 0x0000000078670000 00002D (v01 AMAZON AMZNSLIT 00000001 AMZN 00000001)
2024-10-30T07:48:32,000000+00:00 ACPI: IORT 0x0000000078660000 000078 (v01 AMAZON AMZNIORT 00000001 AMZN 00000001)
2024-10-30T07:48:32,000000+00:00 ACPI: PPTT 0x0000000078650000 0000D4 (v02 AMAZON AMZNPPTT 00000001 AMZN 00000001)
2024-10-30T07:48:32,000000+00:00 ACPI: SPCR: console: uart,mmio,0x90a0000,115200
2024-10-30T07:48:32,000000+00:00 NUMA: Failed to initialise from firmware
2024-10-30T07:48:32,000000+00:00 NUMA: Faking a node at [mem 0x0000000040000000-0x00000005b8ffffff]
2024-10-30T07:48:32,000000+00:00 NUMA: NODE_DATA [mem 0x5b802a7c0-0x5b802cfff]
2024-10-30T07:48:32,000000+00:00 Zone ranges:
2024-10-30T07:48:32,000000+00:00   DMA      [mem 0x0000000040000000-0x00000000ffffffff]
2024-10-30T07:48:32,000000+00:00   DMA32    empty
2024-10-30T07:48:32,000000+00:00   Normal   [mem 0x0000000100000000-0x00000005b8ffffff]
2024-10-30T07:48:32,000000+00:00   Device   empty
2024-10-30T07:48:32,000000+00:00 Movable zone start for each node
2024-10-30T07:48:32,000000+00:00 Early memory node ranges
2024-10-30T07:48:32,000000+00:00   node   0: [mem 0x0000000040000000-0x000000007862ffff]
2024-10-30T07:48:32,000000+00:00   node   0: [mem 0x0000000078630000-0x000000007863ffff]
2024-10-30T07:48:32,000000+00:00   node   0: [mem 0x0000000078640000-0x00000000786effff]
2024-10-30T07:48:32,000000+00:00   node   0: [mem 0x00000000786f0000-0x000000007872ffff]
2024-10-30T07:48:32,000000+00:00   node   0: [mem 0x0000000078730000-0x000000007bbfffff]
2024-10-30T07:48:32,000000+00:00   node   0: [mem 0x000000007bc00000-0x000000007bfdffff]
2024-10-30T07:48:32,000000+00:00   node   0: [mem 0x000000007bfe0000-0x000000007fffffff]
2024-10-30T07:48:32,000000+00:00   node   0: [mem 0x0000000400000000-0x00000005b8ffffff]
2024-10-30T07:48:32,000000+00:00 Initmem setup node 0 [mem 0x0000000040000000-0x00000005b8ffffff]
2024-10-30T07:48:32,000000+00:00 On node 0, zone Normal: 28672 pages in unavailable ranges
2024-10-30T07:48:32,000000+00:00 cma: Reserved 64 MiB at 0x000000007c000000 on node -1
2024-10-30T07:48:32,000000+00:00 psci: probing for conduit method from ACPI.
2024-10-30T07:48:32,000000+00:00 psci: PSCIv1.0 detected in firmware.
2024-10-30T07:48:32,000000+00:00 psci: Using standard PSCI v0.2 function IDs
2024-10-30T07:48:32,000000+00:00 psci: Trusted OS migration not required
2024-10-30T07:48:32,000000+00:00 psci: SMC Calling Convention v1.1
2024-10-30T07:48:32,000000+00:00 percpu: Embedded 31 pages/cpu s86440 r8192 d32344 u126976
2024-10-30T07:48:32,000000+00:00 pcpu-alloc: s86440 r8192 d32344 u126976 alloc=31*4096
2024-10-30T07:48:32,000000+00:00 pcpu-alloc: [0] 0 [0] 1 
2024-10-30T07:48:32,000000+00:00 Detected PIPT I-cache on CPU0
2024-10-30T07:48:32,000000+00:00 CPU features: detected: GIC system register CPU interface
2024-10-30T07:48:32,000000+00:00 CPU features: detected: Hardware dirty bit management
2024-10-30T07:48:32,000000+00:00 CPU features: detected: Spectre-v4
2024-10-30T07:48:32,000000+00:00 CPU features: detected: Spectre-BHB
2024-10-30T07:48:32,000000+00:00 CPU features: detected: ARM erratum 1418040
2024-10-30T07:48:32,000000+00:00 CPU features: detected: ARM erratum 1542419 (kernel portion)
2024-10-30T07:48:32,000000+00:00 CPU features: detected: SSBS not fully self-synchronizing
2024-10-30T07:48:32,000000+00:00 alternatives: applying boot alternatives
2024-10-30T07:48:32,000000+00:00 Fallback order for Node 0: 0 
2024-10-30T07:48:32,000000+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 2036160
2024-10-30T07:48:32,000000+00:00 Policy zone: Normal
2024-10-30T07:48:32,000000+00:00 Kernel command line: BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64 root=UUID=b5c7fae5-1de8-4038-8408-06c720e69aff ro console=tty0 console=ttyS0,115200n8 nvme_core.io_timeout=4294967295 rd.emergency=poweroff rd.shell=0 selinux=1 security=selinux quiet numa_cma=1:64M
2024-10-30T07:48:32,000000+00:00 Unknown kernel command line parameters "BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64", will be passed to user space.
2024-10-30T07:48:32,000000+00:00 Dentry cache hash table entries: 1048576 (order: 11, 8388608 bytes, linear)
2024-10-30T07:48:32,000000+00:00 Inode-cache hash table entries: 524288 (order: 10, 4194304 bytes, linear)
2024-10-30T07:48:32,000000+00:00 mem auto-init: stack:off, heap alloc:off, heap free:off
2024-10-30T07:48:32,000000+00:00 software IO TLB: area num 2.
2024-10-30T07:48:32,000000+00:00 software IO TLB: mapped [mem 0x000000006de00000-0x0000000071e00000] (64MB)
2024-10-30T07:48:32,000000+00:00 Memory: 7919828K/8273920K available (12096K kernel code, 8838K rwdata, 8416K rodata, 4480K init, 11359K bss, 288556K reserved, 65536K cma-reserved)
2024-10-30T07:48:32,000000+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=2, Nodes=1
2024-10-30T07:48:32,000000+00:00 ftrace: allocating 40237 entries in 158 pages
2024-10-30T07:48:32,000000+00:00 ftrace: allocated 158 pages with 5 groups
2024-10-30T07:48:32,000000+00:00 trace event string verifier disabled
2024-10-30T07:48:32,000000+00:00 rcu: Hierarchical RCU implementation.
2024-10-30T07:48:32,000000+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=4096 to nr_cpu_ids=2.
2024-10-30T07:48:32,000000+00:00 	Rude variant of Tasks RCU enabled.
2024-10-30T07:48:32,000000+00:00 	Tracing variant of Tasks RCU enabled.
2024-10-30T07:48:32,000000+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 10 jiffies.
2024-10-30T07:48:32,000000+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=2
2024-10-30T07:48:32,000000+00:00 NR_IRQS: 64, nr_irqs: 64, preallocated irqs: 0
2024-10-30T07:48:32,000000+00:00 GICv3: 96 SPIs implemented
2024-10-30T07:48:32,000000+00:00 GICv3: 0 Extended SPIs implemented
2024-10-30T07:48:32,000000+00:00 Root IRQ handler: gic_handle_irq
2024-10-30T07:48:32,000000+00:00 GICv3: GICv3 features: 16 PPIs
2024-10-30T07:48:32,000000+00:00 GICv3: CPU0: found redistributor 0 region 0:0x0000000010200000
2024-10-30T07:48:32,000000+00:00 ITS [mem 0x10080000-0x1009ffff]
2024-10-30T07:48:32,000000+00:00 ITS@0x0000000010080000: allocated 8192 Devices @4001a0000 (indirect, esz 8, psz 64K, shr 1)
2024-10-30T07:48:32,000000+00:00 ITS@0x0000000010080000: allocated 8192 Interrupt Collections @4001b0000 (flat, esz 8, psz 64K, shr 1)
2024-10-30T07:48:32,000000+00:00 GICv3: using LPI property table @0x00000004001c0000
2024-10-30T07:48:32,000000+00:00 ITS: Using hypervisor restricted LPI range [128]
2024-10-30T07:48:32,000000+00:00 GICv3: CPU0: using allocated LPI pending table @0x00000004001d0000
2024-10-30T07:48:32,000000+00:00 rcu: srcu_init: Setting srcu_struct sizes based on contention.
2024-10-30T07:48:32,000000+00:00 arch_timer: Enabling local workaround for ARM erratum 1418040
2024-10-30T07:48:32,000000+00:00 arch_timer: cp15 timer(s) running at 121.87MHz (virt).
2024-10-30T07:48:32,000000+00:00 clocksource: arch_sys_counter: mask: 0x3ffffffffffffff max_cycles: 0x383759f8ff, max_idle_ns: 881590415659 ns
2024-10-30T07:48:32,000000+00:00 sched_clock: 58 bits at 122MHz, resolution 8ns, wraps every 4398046511103ns
2024-10-30T07:48:32,000019+00:00 arm-pv: using stolen time PV
2024-10-30T07:48:32,000076+00:00 Console: colour dummy device 80x25
2024-10-30T07:48:32,000090+00:00 printk: console [tty0] enabled
2024-10-30T07:48:32,000108+00:00 ACPI: Core revision 20220331
2024-10-30T07:48:32,000141+00:00 Calibrating delay loop (skipped), value calculated using timer frequency.. 243.75 BogoMIPS (lpj=1218750)
2024-10-30T07:48:32,000143+00:00 pid_max: default: 32768 minimum: 301
2024-10-30T07:48:32,000163+00:00 LSM: Security Framework initializing
2024-10-30T07:48:32,000180+00:00 Yama: becoming mindful.
2024-10-30T07:48:32,000185+00:00 SELinux:  Initializing.
2024-10-30T07:48:32,000199+00:00 LSM support for eBPF active
2024-10-30T07:48:32,000218+00:00 Mount-cache hash table entries: 16384 (order: 5, 131072 bytes, linear)
2024-10-30T07:48:32,000223+00:00 Mountpoint-cache hash table entries: 16384 (order: 5, 131072 bytes, linear)
2024-10-30T07:48:32,000546+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-10-30T07:48:32,000548+00:00 cblist_init_generic: Setting shift to 1 and lim to 1.
2024-10-30T07:48:32,000560+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-10-30T07:48:32,000561+00:00 cblist_init_generic: Setting shift to 1 and lim to 1.
2024-10-30T07:48:32,000600+00:00 rcu: Hierarchical SRCU implementation.
2024-10-30T07:48:32,000601+00:00 rcu: 	Max phase no-delay instances is 1000.
2024-10-30T07:48:32,000792+00:00 Platform MSI: ITS@0x10080000 domain created
2024-10-30T07:48:32,000797+00:00 PCI/MSI: ITS@0x10080000 domain created
2024-10-30T07:48:32,000800+00:00 Remapping and enabling EFI services.
2024-10-30T07:48:32,000903+00:00 smp: Bringing up secondary CPUs ...
2024-10-30T07:48:32,001061+00:00 Detected PIPT I-cache on CPU1
2024-10-30T07:48:32,001089+00:00 GICv3: CPU1: found redistributor 1 region 0:0x0000000010220000
2024-10-30T07:48:32,001118+00:00 GICv3: CPU1: using allocated LPI pending table @0x00000004001e0000
2024-10-30T07:48:32,001134+00:00 arch_timer: Enabling local workaround for ARM erratum 1418040
2024-10-30T07:48:32,001148+00:00 CPU1: Booted secondary processor 0x0000000001 [0x413fd0c1]
2024-10-30T07:48:32,001256+00:00 smp: Brought up 1 node, 2 CPUs
2024-10-30T07:48:32,001260+00:00 SMP: Total of 2 processors activated.
2024-10-30T07:48:32,001262+00:00 CPU features: detected: 32-bit EL0 Support
2024-10-30T07:48:32,001263+00:00 CPU features: detected: Instruction cache invalidation not required for I/D coherence
2024-10-30T07:48:32,001264+00:00 CPU features: detected: Data cache clean to the PoU not required for I/D coherence
2024-10-30T07:48:32,001265+00:00 CPU features: detected: Common not Private translations
2024-10-30T07:48:32,001266+00:00 CPU features: detected: CRC32 instructions
2024-10-30T07:48:32,001268+00:00 CPU features: detected: RCpc load-acquire (LDAPR)
2024-10-30T07:48:32,001269+00:00 CPU features: detected: LSE atomic instructions
2024-10-30T07:48:32,001270+00:00 CPU features: detected: Privileged Access Never
2024-10-30T07:48:32,001271+00:00 CPU features: detected: RAS Extension Support
2024-10-30T07:48:32,001272+00:00 CPU features: detected: Speculative Store Bypassing Safe (SSBS)
2024-10-30T07:48:32,001318+00:00 CPU: All CPU(s) started at EL1
2024-10-30T07:48:32,001322+00:00 alternatives: applying system-wide alternatives
2024-10-30T07:48:32,003453+00:00 devtmpfs: initialized
2024-10-30T07:48:32,004146+00:00 Registered cp15_barrier emulation handler
2024-10-30T07:48:32,004156+00:00 Registered setend emulation handler
2024-10-30T07:48:32,004190+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 19112604462750000 ns
2024-10-30T07:48:32,004193+00:00 futex hash table entries: 512 (order: 3, 32768 bytes, linear)
2024-10-30T07:48:32,004411+00:00 pinctrl core: initialized pinctrl subsystem
2024-10-30T07:48:32,004455+00:00 SMBIOS 3.0.0 present.
2024-10-30T07:48:32,004458+00:00 DMI: Amazon EC2 t4g.large/, BIOS 1.0 11/1/2018
2024-10-30T07:48:32,004559+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2024-10-30T07:48:32,004730+00:00 DMA: preallocated 1024 KiB GFP_KERNEL pool for atomic allocations
2024-10-30T07:48:32,004765+00:00 DMA: preallocated 1024 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2024-10-30T07:48:32,004825+00:00 DMA: preallocated 1024 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2024-10-30T07:48:32,004834+00:00 audit: initializing netlink subsys (disabled)
2024-10-30T07:48:32,004884+00:00 audit: type=2000 audit(0.000:1): state=initialized audit_enabled=0 res=1
2024-10-30T07:48:32,004936+00:00 thermal_sys: Registered thermal governor 'fair_share'
2024-10-30T07:48:32,004937+00:00 thermal_sys: Registered thermal governor 'step_wise'
2024-10-30T07:48:32,004938+00:00 thermal_sys: Registered thermal governor 'user_space'
2024-10-30T07:48:32,004946+00:00 cpuidle: using governor ladder
2024-10-30T07:48:32,004950+00:00 cpuidle: using governor menu
2024-10-30T07:48:32,004985+00:00 hw-breakpoint: found 6 breakpoint and 4 watchpoint registers.
2024-10-30T07:48:32,005017+00:00 ASID allocator initialised with 65536 entries
2024-10-30T07:48:32,005023+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2024-10-30T07:48:32,005035+00:00 Serial: AMBA PL011 UART driver
2024-10-30T07:48:32,010168+00:00 HugeTLB: registered 1.00 GiB page size, pre-allocated 0 pages
2024-10-30T07:48:32,010170+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 1.00 GiB page
2024-10-30T07:48:32,010172+00:00 HugeTLB: registered 32.0 MiB page size, pre-allocated 0 pages
2024-10-30T07:48:32,010173+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 32.0 MiB page
2024-10-30T07:48:32,010174+00:00 HugeTLB: registered 2.00 MiB page size, pre-allocated 0 pages
2024-10-30T07:48:32,010175+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 2.00 MiB page
2024-10-30T07:48:32,010176+00:00 HugeTLB: registered 64.0 KiB page size, pre-allocated 0 pages
2024-10-30T07:48:32,010177+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 64.0 KiB page
2024-10-30T07:48:32,010693+00:00 ACPI: Added _OSI(Module Device)
2024-10-30T07:48:32,010695+00:00 ACPI: Added _OSI(Processor Device)
2024-10-30T07:48:32,010696+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2024-10-30T07:48:32,010697+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2024-10-30T07:48:32,011271+00:00 ACPI: 1 ACPI AML tables successfully acquired and loaded
2024-10-30T07:48:32,011660+00:00 ACPI: Interpreter enabled
2024-10-30T07:48:32,011661+00:00 ACPI: Using GIC for interrupt routing
2024-10-30T07:48:32,011671+00:00 ACPI: MCFG table detected, 1 entries
2024-10-30T07:48:32,013126+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-0f])
2024-10-30T07:48:32,013135+00:00 acpi PNP0A08:00: _OSC: OS supports [ExtendedConfig ASPM ClockPM Segments MSI HPX-Type3]
2024-10-30T07:48:32,013173+00:00 acpi PNP0A08:00: _OSC: platform does not support [SHPCHotplug LTR]
2024-10-30T07:48:32,013225+00:00 acpi PNP0A08:00: _OSC: OS now controls [PCIeHotplug PME PCIeCapability]
2024-10-30T07:48:32,013300+00:00 acpi PNP0A08:00: ECAM area [mem 0x20000000-0x20ffffff] reserved by PNP0C02:00
2024-10-30T07:48:32,013306+00:00 acpi PNP0A08:00: ECAM at [mem 0x20000000-0x20ffffff] for [bus 00-0f]
2024-10-30T07:48:32,013320+00:00 ACPI: Remapped I/O 0x000000001fff0000 to [io  0x0000-0xffff window]
2024-10-30T07:48:32,013564+00:00 acpiphp: Slot [1] registered
2024-10-30T07:48:32,013575+00:00 acpiphp: Slot [2] registered
2024-10-30T07:48:32,013585+00:00 acpiphp: Slot [3] registered
2024-10-30T07:48:32,013595+00:00 acpiphp: Slot [4] registered
2024-10-30T07:48:32,013605+00:00 acpiphp: Slot [5] registered
2024-10-30T07:48:32,013615+00:00 acpiphp: Slot [6] registered
2024-10-30T07:48:32,013625+00:00 acpiphp: Slot [7] registered
2024-10-30T07:48:32,013635+00:00 acpiphp: Slot [8] registered
2024-10-30T07:48:32,013644+00:00 acpiphp: Slot [9] registered
2024-10-30T07:48:32,013654+00:00 acpiphp: Slot [10] registered
2024-10-30T07:48:32,013664+00:00 acpiphp: Slot [11] registered
2024-10-30T07:48:32,013673+00:00 acpiphp: Slot [12] registered
2024-10-30T07:48:32,013683+00:00 acpiphp: Slot [13] registered
2024-10-30T07:48:32,013693+00:00 acpiphp: Slot [14] registered
2024-10-30T07:48:32,013703+00:00 acpiphp: Slot [15] registered
2024-10-30T07:48:32,013713+00:00 acpiphp: Slot [16] registered
2024-10-30T07:48:32,013722+00:00 acpiphp: Slot [17] registered
2024-10-30T07:48:32,013731+00:00 acpiphp: Slot [18] registered
2024-10-30T07:48:32,013741+00:00 acpiphp: Slot [19] registered
2024-10-30T07:48:32,013751+00:00 acpiphp: Slot [20] registered
2024-10-30T07:48:32,013760+00:00 acpiphp: Slot [21] registered
2024-10-30T07:48:32,013769+00:00 acpiphp: Slot [22] registered
2024-10-30T07:48:32,013778+00:00 acpiphp: Slot [23] registered
2024-10-30T07:48:32,013787+00:00 acpiphp: Slot [24] registered
2024-10-30T07:48:32,013798+00:00 acpiphp: Slot [25] registered
2024-10-30T07:48:32,013808+00:00 acpiphp: Slot [26] registered
2024-10-30T07:48:32,013817+00:00 acpiphp: Slot [27] registered
2024-10-30T07:48:32,013827+00:00 acpiphp: Slot [28] registered
2024-10-30T07:48:32,013836+00:00 acpiphp: Slot [29] registered
2024-10-30T07:48:32,013845+00:00 acpiphp: Slot [30] registered
2024-10-30T07:48:32,013855+00:00 acpiphp: Slot [31] registered
2024-10-30T07:48:32,013870+00:00 PCI host bridge to bus 0000:00
2024-10-30T07:48:32,013872+00:00 pci_bus 0000:00: root bus resource [mem 0x80000000-0xffffffff window]
2024-10-30T07:48:32,013874+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0xffff window]
2024-10-30T07:48:32,013875+00:00 pci_bus 0000:00: root bus resource [mem 0x400000000000-0x407fffffffff window]
2024-10-30T07:48:32,013877+00:00 pci_bus 0000:00: root bus resource [bus 00-0f]
2024-10-30T07:48:32,013913+00:00 pci 0000:00:00.0: [1d0f:0200] type 00 class 0x060000
2024-10-30T07:48:32,014150+00:00 pci 0000:00:01.0: [1d0f:8250] type 00 class 0x070003
2024-10-30T07:48:32,014199+00:00 pci 0000:00:01.0: reg 0x10: [mem 0x80008000-0x80008fff]
2024-10-30T07:48:32,014400+00:00 pci 0000:00:04.0: [1d0f:8061] type 00 class 0x010802
2024-10-30T07:48:32,015844+00:00 pci 0000:00:04.0: reg 0x10: [mem 0x80004000-0x80007fff]
2024-10-30T07:48:32,021855+00:00 pci 0000:00:04.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-30T07:48:32,022045+00:00 pci 0000:00:05.0: [1d0f:ec20] type 00 class 0x020000
2024-10-30T07:48:32,022087+00:00 pci 0000:00:05.0: reg 0x10: [mem 0x80000000-0x80003fff]
2024-10-30T07:48:32,022289+00:00 pci 0000:00:05.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-30T07:48:32,022460+00:00 pci 0000:00:04.0: BAR 0: assigned [mem 0x80000000-0x80003fff]
2024-10-30T07:48:32,023002+00:00 pci 0000:00:05.0: BAR 0: assigned [mem 0x80004000-0x80007fff]
2024-10-30T07:48:32,023011+00:00 pci 0000:00:01.0: BAR 0: assigned [mem 0x80008000-0x80008fff]
2024-10-30T07:48:32,023019+00:00 pci_bus 0000:00: resource 4 [mem 0x80000000-0xffffffff window]
2024-10-30T07:48:32,023021+00:00 pci_bus 0000:00: resource 5 [io  0x0000-0xffff window]
2024-10-30T07:48:32,023023+00:00 pci_bus 0000:00: resource 6 [mem 0x400000000000-0x407fffffffff window]
2024-10-30T07:48:32,023054+00:00 ACPI: PCI: Interrupt link GSI0 configured for IRQ 35
2024-10-30T07:48:32,023061+00:00 ACPI: PCI: Interrupt link GSI1 configured for IRQ 36
2024-10-30T07:48:32,023066+00:00 ACPI: PCI: Interrupt link GSI2 configured for IRQ 37
2024-10-30T07:48:32,023072+00:00 ACPI: PCI: Interrupt link GSI3 configured for IRQ 38
2024-10-30T07:48:32,023438+00:00 iommu: Default domain type: Translated 
2024-10-30T07:48:32,023440+00:00 iommu: DMA domain TLB invalidation policy: lazy mode 
2024-10-30T07:48:32,023475+00:00 pps_core: LinuxPPS API ver. 1 registered
2024-10-30T07:48:32,023476+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2024-10-30T07:48:32,023479+00:00 PTP clock support registered
2024-10-30T07:48:32,023507+00:00 EDAC MC: Ver: 3.0.0
2024-10-30T07:48:32,023680+00:00 Registered efivars operations
2024-10-30T07:48:32,023866+00:00 NetLabel: Initializing
2024-10-30T07:48:32,023868+00:00 NetLabel:  domain hash size = 128
2024-10-30T07:48:32,023868+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2024-10-30T07:48:32,023878+00:00 NetLabel:  unlabeled traffic allowed by default
2024-10-30T07:48:32,023922+00:00 vgaarb: loaded
2024-10-30T07:48:32,024016+00:00 clocksource: Switched to clocksource arch_sys_counter
2024-10-30T07:48:32,024087+00:00 VFS: Disk quotas dquot_6.6.0
2024-10-30T07:48:32,024096+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2024-10-30T07:48:32,024149+00:00 pnp: PnP ACPI init
2024-10-30T07:48:32,024220+00:00 system 00:00: [mem 0x20000000-0x2fffffff] could not be reserved
2024-10-30T07:48:32,024230+00:00 pnp: PnP ACPI: found 1 devices
2024-10-30T07:48:32,030912+00:00 NET: Registered PF_INET protocol family
2024-10-30T07:48:32,030965+00:00 IP idents hash table entries: 131072 (order: 8, 1048576 bytes, linear)
2024-10-30T07:48:32,032377+00:00 tcp_listen_portaddr_hash hash table entries: 4096 (order: 4, 65536 bytes, linear)
2024-10-30T07:48:32,032400+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2024-10-30T07:48:32,032403+00:00 TCP established hash table entries: 65536 (order: 7, 524288 bytes, linear)
2024-10-30T07:48:32,032570+00:00 TCP bind hash table entries: 65536 (order: 9, 2097152 bytes, linear)
2024-10-30T07:48:32,033184+00:00 TCP: Hash tables configured (established 65536 bind 65536)
2024-10-30T07:48:32,033221+00:00 MPTCP token hash table entries: 8192 (order: 5, 196608 bytes, linear)
2024-10-30T07:48:32,033246+00:00 UDP hash table entries: 4096 (order: 5, 131072 bytes, linear)
2024-10-30T07:48:32,033306+00:00 UDP-Lite hash table entries: 4096 (order: 5, 131072 bytes, linear)
2024-10-30T07:48:32,033388+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2024-10-30T07:48:32,033398+00:00 NET: Registered PF_XDP protocol family
2024-10-30T07:48:32,033440+00:00 PCI: CLS 0 bytes, default 64
2024-10-30T07:48:32,033578+00:00 Trying to unpack rootfs image as initramfs...
2024-10-30T07:48:32,044356+00:00 hw perfevents: enabled with armv8_pmuv3_0 PMU driver, 3 counters available
2024-10-30T07:48:32,044384+00:00 kvm [1]: HYP mode not available
2024-10-30T07:48:32,044604+00:00 Initialise system trusted keyrings
2024-10-30T07:48:32,044609+00:00 Key type blacklist registered
2024-10-30T07:48:32,044820+00:00 workingset: timestamp_bits=44 max_order=21 bucket_order=0
2024-10-30T07:48:32,045796+00:00 zbud: loaded
2024-10-30T07:48:32,045928+00:00 SGI XFS with ACLs, security attributes, quota, no debug enabled
2024-10-30T07:48:32,046401+00:00 integrity: Platform Keyring initialized
2024-10-30T07:48:32,053415+00:00 Key type asymmetric registered
2024-10-30T07:48:32,053418+00:00 Asymmetric key parser 'x509' registered
2024-10-30T07:48:32,053434+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 248)
2024-10-30T07:48:32,053468+00:00 io scheduler mq-deadline registered
2024-10-30T07:48:32,053469+00:00 io scheduler kyber registered
2024-10-30T07:48:32,053491+00:00 io scheduler bfq registered
2024-10-30T07:48:32,055183+00:00 pl061_gpio ARMH0061:00: PL061 GPIO chip registered
2024-10-30T07:48:32,055229+00:00 shpchp: Standard Hot Plug PCI Controller Driver version: 0.4
2024-10-30T07:48:32,056443+00:00 Serial: 8250/16550 driver, 4 ports, IRQ sharing disabled
2024-10-30T07:48:32,056906+00:00 ACPI: \_SB_.PCI0.GSI2: Enabled at IRQ 37
2024-10-30T07:48:32,056933+00:00 serial 0000:00:01.0: enabling device (0010 -> 0012)
2024-10-30T07:48:32,057225+00:00 printk: console [ttyS0] disabled
2024-10-30T07:48:32,057371+00:00 0000:00:01.0: ttyS0 at MMIO 0x80008000 (irq = 14, base_baud = 115200) is a 16550A
2024-10-30T07:48:32,057467+00:00 printk: console [ttyS0] enabled
2024-10-30T07:48:32,058218+00:00 ACPI: \_SB_.PCI0.GSI0: Enabled at IRQ 35
2024-10-30T07:48:32,058301+00:00 nvme nvme0: pci function 0000:00:04.0
2024-10-30T07:48:32,058841+00:00 rtc-efi rtc-efi.0: registered as rtc0
2024-10-30T07:48:32,058870+00:00 rtc-efi rtc-efi.0: setting system clock to 2024-10-30T07:48:32 UTC (1730274512)
2024-10-30T07:48:32,058930+00:00 pstore: Registered efi as persistent store backend
2024-10-30T07:48:32,058942+00:00 hid: raw HID events driver (C) Jiri Kosina
2024-10-30T07:48:32,068063+00:00 nvme nvme0: 2/0/0 default/read/poll queues
2024-10-30T07:48:32,068511+00:00 NET: Registered PF_INET6 protocol family
2024-10-30T07:48:32,075739+00:00  nvme0n1: p1 p128
2024-10-30T07:48:32,141934+00:00 Freeing initrd memory: 11908K
2024-10-30T07:48:32,148146+00:00 Segment Routing with IPv6
2024-10-30T07:48:32,148161+00:00 In-situ OAM (IOAM) with IPv6
2024-10-30T07:48:32,148196+00:00 NET: Registered PF_PACKET protocol family
2024-10-30T07:48:32,148403+00:00 registered taskstats version 1
2024-10-30T07:48:32,148411+00:00 Loading compiled-in X.509 certificates
2024-10-30T07:48:32,160168+00:00 Loaded X.509 cert 'Amazon.com: Amazon Linux Kernel Signing Key: 3c3163dcb84c1049cf8b75ca4bcf01c5583dbccb'
2024-10-30T07:48:32,160292+00:00 zswap: loaded using pool lzo/zbud
2024-10-30T07:48:32,160418+00:00 Key type .fscrypt registered
2024-10-30T07:48:32,160420+00:00 Key type fscrypt-provisioning registered
2024-10-30T07:48:32,160613+00:00 pstore: Using crash dump compression: deflate
2024-10-30T07:48:32,160926+00:00 ima: secureboot mode disabled
2024-10-30T07:48:32,160929+00:00 ima: No TPM chip found, activating TPM-bypass!
2024-10-30T07:48:32,160933+00:00 ima: Allocated hash algorithm: sha256
2024-10-30T07:48:32,160943+00:00 ima: No architecture policies found
2024-10-30T07:48:32,302053+00:00 clk: Disabling unused clocks
2024-10-30T07:48:32,303331+00:00 Freeing unused kernel memory: 4480K
2024-10-30T07:48:32,303353+00:00 Run /init as init process
2024-10-30T07:48:32,303354+00:00   with arguments:
2024-10-30T07:48:32,303356+00:00     /init
2024-10-30T07:48:32,303358+00:00   with environment:
2024-10-30T07:48:32,303358+00:00     HOME=/
2024-10-30T07:48:32,303359+00:00     TERM=linux
2024-10-30T07:48:32,303360+00:00     BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64
2024-10-30T07:48:32,329991+00:00 systemd[1]: systemd 252.23-2.amzn2023 running in system mode (+PAM +AUDIT +SELINUX -APPARMOR +IMA +SMACK +SECCOMP -GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN -IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 -BZIP2 -LZ4 +XZ -ZLIB -ZSTD +BPF_FRAMEWORK +XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2024-10-30T07:48:32,329997+00:00 systemd[1]: Detected virtualization amazon.
2024-10-30T07:48:32,330001+00:00 systemd[1]: Detected architecture arm64.
2024-10-30T07:48:32,330004+00:00 systemd[1]: Running in initrd.
2024-10-30T07:48:32,330101+00:00 systemd[1]: No hostname configured, using default hostname.
2024-10-30T07:48:32,330141+00:00 systemd[1]: Hostname set to <localhost>.
2024-10-30T07:48:32,330215+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-10-30T07:48:32,419649+00:00 systemd[1]: Queued start job for default target initrd.target.
2024-10-30T07:48:32,464602+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2024-10-30T07:48:32,464650+00:00 systemd[1]: Expecting device dev-disk-by\x2duuid-b5c7fae5\x2d1de8\x2d4038\x2d8408\x2d06c720e69aff.device - /dev/disk/by-uuid/b5c7fae5-1de8-4038-8408-06c720e69aff...
2024-10-30T07:48:32,464679+00:00 systemd[1]: Reached target initrd-usr-fs.target - Initrd /usr File System.
2024-10-30T07:48:32,464696+00:00 systemd[1]: Reached target local-fs.target - Local File Systems.
2024-10-30T07:48:32,464706+00:00 systemd[1]: Reached target paths.target - Path Units.
2024-10-30T07:48:32,464727+00:00 systemd[1]: Reached target slices.target - Slice Units.
2024-10-30T07:48:32,464742+00:00 systemd[1]: Reached target swap.target - Swaps.
2024-10-30T07:48:32,464754+00:00 systemd[1]: Reached target timers.target - Timer Units.
2024-10-30T07:48:32,465027+00:00 systemd[1]: Listening on systemd-journald-audit.socket - Journal Audit Socket.
2024-10-30T07:48:32,465131+00:00 systemd[1]: Listening on systemd-journald-dev-log.socket - Journal Socket (/dev/log).
2024-10-30T07:48:32,465208+00:00 systemd[1]: Listening on systemd-journald.socket - Journal Socket.
2024-10-30T07:48:32,465296+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2024-10-30T07:48:32,465359+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2024-10-30T07:48:32,465374+00:00 systemd[1]: Reached target sockets.target - Socket Units.
2024-10-30T07:48:32,465425+00:00 systemd[1]: kmod-static-nodes.service - Create List of Static Device Nodes was skipped because of an unmet condition check (ConditionFileNotEmpty=/lib/modules/6.1.112-122.189.amzn2023.aarch64/modules.devname).
2024-10-30T07:48:32,466270+00:00 systemd[1]: Started rngd.service - Hardware RNG Entropy Gatherer Daemon.
2024-10-30T07:48:32,467528+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2024-10-30T07:48:32,467651+00:00 systemd[1]: systemd-modules-load.service - Load Kernel Modules was skipped because no trigger condition checks were met.
2024-10-30T07:48:32,468336+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2024-10-30T07:48:32,469005+00:00 systemd[1]: Starting systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev...
2024-10-30T07:48:32,469697+00:00 systemd[1]: Starting systemd-vconsole-setup.service - Setup Virtual Console...
2024-10-30T07:48:32,482826+00:00 systemd[1]: Finished systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev.
2024-10-30T07:48:32,483534+00:00 systemd[1]: Finished systemd-vconsole-setup.service - Setup Virtual Console.
2024-10-30T07:48:32,483641+00:00 systemd[1]: dracut-cmdline-ask.service - dracut ask for additional cmdline parameters was skipped because no trigger condition checks were met.
2024-10-30T07:48:32,484423+00:00 systemd[1]: Starting dracut-cmdline.service - dracut cmdline hook...
2024-10-30T07:48:32,488741+00:00 systemd[1]: Finished systemd-sysctl.service - Apply Kernel Variables.
2024-10-30T07:48:32,499409+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2024-10-30T07:48:32,500456+00:00 audit: type=1130 audit(1730274512.929:2): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-journald comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:48:32,508239+00:00 audit: type=1130 audit(1730274512.939:3): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-tmpfiles-setup comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:48:32,542733+00:00 audit: type=1130 audit(1730274512.969:4): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=dracut-cmdline comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:48:32,542740+00:00 audit: type=1334 audit(1730274512.969:5): prog-id=6 op=LOAD
2024-10-30T07:48:32,542742+00:00 audit: type=1334 audit(1730274512.969:6): prog-id=7 op=LOAD
2024-10-30T07:48:32,590732+00:00 audit: type=1130 audit(1730274513.019:7): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-udevd comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:48:32,663573+00:00 audit: type=1130 audit(1730274513.089:8): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-udev-trigger comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:48:33,575859+00:00 XFS (nvme0n1p1): Mounting V5 Filesystem
2024-10-30T07:48:33,680467+00:00 XFS (nvme0n1p1): Ending clean mount
2024-10-30T07:48:33,747830+00:00 audit: type=1130 audit(1730274514.179:9): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=initrd-parse-etc comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:48:33,747839+00:00 audit: type=1131 audit(1730274514.179:10): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=initrd-parse-etc comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:48:34,035794+00:00 systemd-journald[324]: Received SIGTERM from PID 1 (systemd).
2024-10-30T07:48:34,380623+00:00 SELinux:  Class user_namespace not defined in policy.
2024-10-30T07:48:34,380629+00:00 SELinux: the above unknown classes and permissions will be allowed
2024-10-30T07:48:34,383621+00:00 SELinux:  policy capability network_peer_controls=1
2024-10-30T07:48:34,383625+00:00 SELinux:  policy capability open_perms=1
2024-10-30T07:48:34,383626+00:00 SELinux:  policy capability extended_socket_class=1
2024-10-30T07:48:34,383628+00:00 SELinux:  policy capability always_check_network=0
2024-10-30T07:48:34,383629+00:00 SELinux:  policy capability cgroup_seclabel=1
2024-10-30T07:48:34,383630+00:00 SELinux:  policy capability nnp_nosuid_transition=1
2024-10-30T07:48:34,383631+00:00 SELinux:  policy capability genfs_seclabel_symlinks=1
2024-10-30T07:48:34,383631+00:00 SELinux:  policy capability ioctl_skip_cloexec=0
2024-10-30T07:48:34,489804+00:00 systemd[1]: Successfully loaded SELinux policy in 194.834ms.
2024-10-30T07:48:34,624725+00:00 systemd[1]: Relabelled /dev, /dev/shm, /run, /sys/fs/cgroup in 22.247ms.
2024-10-30T07:48:34,655272+00:00 systemd[1]: systemd 252.23-2.amzn2023 running in system mode (+PAM +AUDIT +SELINUX -APPARMOR +IMA +SMACK +SECCOMP -GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN -IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 -BZIP2 -LZ4 +XZ -ZLIB -ZSTD +BPF_FRAMEWORK +XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2024-10-30T07:48:34,655278+00:00 systemd[1]: Detected virtualization amazon.
2024-10-30T07:48:34,655291+00:00 systemd[1]: Detected architecture arm64.
2024-10-30T07:48:34,659092+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-10-30T07:48:34,659169+00:00 systemd[1]: Installed transient /etc/machine-id file.
2024-10-30T07:48:34,775881+00:00 systemd[1]: bpf-lsm: Failed to link program; assuming BPF LSM is not available
2024-10-30T07:48:34,840056+00:00 zram_generator::config[853]: zram0: system has too much memory (7814MB), limit is 800MB, ignoring.
2024-10-30T07:48:35,030036+00:00 systemd[1]: /usr/lib/systemd/system/update-motd.service:40: Invalid CPU quota '25', ignoring.
2024-10-30T07:48:35,299038+00:00 systemd[1]: initrd-switch-root.service: Deactivated successfully.
2024-10-30T07:48:35,299198+00:00 systemd[1]: Stopped initrd-switch-root.service - Switch Root.
2024-10-30T07:48:35,299761+00:00 systemd[1]: systemd-journald.service: Scheduled restart job, restart counter is at 1.
2024-10-30T07:48:35,300244+00:00 systemd[1]: Created slice system-ebs\x2dinitialize\x2dbin.slice - Slice /system/ebs-initialize-bin.
2024-10-30T07:48:35,300584+00:00 systemd[1]: Created slice system-getty.slice - Slice /system/getty.
2024-10-30T07:48:35,300915+00:00 systemd[1]: Created slice system-modprobe.slice - Slice /system/modprobe.
2024-10-30T07:48:35,301239+00:00 systemd[1]: Created slice system-serial\x2dgetty.slice - Slice /system/serial-getty.
2024-10-30T07:48:35,301564+00:00 systemd[1]: Created slice system-sshd\x2dkeygen.slice - Slice /system/sshd-keygen.
2024-10-30T07:48:35,301911+00:00 systemd[1]: Created slice user.slice - User and Session Slice.
2024-10-30T07:48:35,302083+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2024-10-30T07:48:35,302181+00:00 systemd[1]: Started systemd-ask-password-wall.path - Forward Password Requests to Wall Directory Watch.
2024-10-30T07:48:35,302667+00:00 systemd[1]: Set up automount proc-sys-fs-binfmt_misc.automount - Arbitrary Executable File Formats File System Automount Point.
2024-10-30T07:48:35,302691+00:00 systemd[1]: Expecting device dev-ttyS0.device - /dev/ttyS0...
2024-10-30T07:48:35,302720+00:00 systemd[1]: Reached target cryptsetup.target - Local Encrypted Volumes.
2024-10-30T07:48:35,302759+00:00 systemd[1]: Stopped target initrd-switch-root.target - Switch Root.
2024-10-30T07:48:35,302777+00:00 systemd[1]: Stopped target initrd-fs.target - Initrd File Systems.
2024-10-30T07:48:35,302787+00:00 systemd[1]: Stopped target initrd-root-fs.target - Initrd Root File System.
2024-10-30T07:48:35,302799+00:00 systemd[1]: Reached target integritysetup.target - Local Integrity Protected Volumes.
2024-10-30T07:48:35,302840+00:00 systemd[1]: Reached target paths.target - Path Units.
2024-10-30T07:48:35,302867+00:00 systemd[1]: Reached target slices.target - Slice Units.
2024-10-30T07:48:35,302889+00:00 systemd[1]: Reached target swap.target - Swaps.
2024-10-30T07:48:35,302909+00:00 systemd[1]: Reached target veritysetup.target - Local Verity Protected Volumes.
2024-10-30T07:48:35,303436+00:00 systemd[1]: Listening on dm-event.socket - Device-mapper event daemon FIFOs.
2024-10-30T07:48:35,305030+00:00 systemd[1]: Listening on lvm2-lvmpolld.socket - LVM2 poll daemon socket.
2024-10-30T07:48:35,307162+00:00 systemd[1]: Listening on systemd-coredump.socket - Process Core Dump Socket.
2024-10-30T07:48:35,307317+00:00 systemd[1]: Listening on systemd-initctl.socket - initctl Compatibility Named Pipe.
2024-10-30T07:48:35,307618+00:00 systemd[1]: Listening on systemd-networkd.socket - Network Service Netlink Socket.
2024-10-30T07:48:35,309132+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2024-10-30T07:48:35,309530+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2024-10-30T07:48:35,309917+00:00 systemd[1]: Listening on systemd-userdbd.socket - User Database Manager Socket.
2024-10-30T07:48:35,311479+00:00 systemd[1]: Mounting dev-hugepages.mount - Huge Pages File System...
2024-10-30T07:48:35,312976+00:00 systemd[1]: Mounting dev-mqueue.mount - POSIX Message Queue File System...
2024-10-30T07:48:35,314555+00:00 systemd[1]: Mounting sys-kernel-debug.mount - Kernel Debug File System...
2024-10-30T07:48:35,315956+00:00 systemd[1]: Mounting sys-kernel-tracing.mount - Kernel Trace File System...
2024-10-30T07:48:35,317469+00:00 systemd[1]: Mounting tmp.mount - Temporary Directory /tmp...
2024-10-30T07:48:35,317568+00:00 systemd[1]: auth-rpcgss-module.service - Kernel Module supporting RPCSEC_GSS was skipped because of an unmet condition check (ConditionPathExists=/etc/krb5.keytab).
2024-10-30T07:48:35,319202+00:00 systemd[1]: Starting kmod-static-nodes.service - Create List of Static Device Nodes...
2024-10-30T07:48:35,321741+00:00 systemd[1]: Starting lvm2-monitor.service - Monitoring of LVM2 mirrors, snapshots etc. using dmeventd or progress polling...
2024-10-30T07:48:35,323544+00:00 systemd[1]: Starting modprobe@configfs.service - Load Kernel Module configfs...
2024-10-30T07:48:35,325296+00:00 systemd[1]: Starting modprobe@dm_mod.service - Load Kernel Module dm_mod...
2024-10-30T07:48:35,326999+00:00 systemd[1]: Starting modprobe@drm.service - Load Kernel Module drm...
2024-10-30T07:48:35,329365+00:00 systemd[1]: Starting modprobe@efi_pstore.service - Load Kernel Module efi_pstore...
2024-10-30T07:48:35,330743+00:00 systemd[1]: Starting modprobe@fuse.service - Load Kernel Module fuse...
2024-10-30T07:48:35,332130+00:00 systemd[1]: Starting modprobe@loop.service - Load Kernel Module loop...
2024-10-30T07:48:35,333625+00:00 systemd[1]: Starting nfs-convert.service - Preprocess NFS configuration convertion...
2024-10-30T07:48:35,336541+00:00 systemd[1]: Starting systemd-fsck-root.service - File System Check on Root Device...
2024-10-30T07:48:35,336638+00:00 systemd[1]: Stopped systemd-journald.service - Journal Service.
2024-10-30T07:48:35,338965+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2024-10-30T07:48:35,342030+00:00 systemd[1]: Starting systemd-modules-load.service - Load Kernel Modules...
2024-10-30T07:48:35,351433+00:00 systemd[1]: Starting systemd-network-generator.service - Generate network units from Kernel command line...
2024-10-30T07:48:35,353134+00:00 systemd[1]: Starting systemd-udev-trigger.service - Coldplug All udev Devices...
2024-10-30T07:48:35,355018+00:00 systemd[1]: Mounted dev-hugepages.mount - Huge Pages File System.
2024-10-30T07:48:35,355137+00:00 systemd[1]: Mounted dev-mqueue.mount - POSIX Message Queue File System.
2024-10-30T07:48:35,355208+00:00 systemd[1]: Mounted sys-kernel-debug.mount - Kernel Debug File System.
2024-10-30T07:48:35,355275+00:00 systemd[1]: Mounted sys-kernel-tracing.mount - Kernel Trace File System.
2024-10-30T07:48:35,355342+00:00 systemd[1]: Mounted tmp.mount - Temporary Directory /tmp.
2024-10-30T07:48:35,355770+00:00 systemd[1]: modprobe@drm.service: Deactivated successfully.
2024-10-30T07:48:35,355946+00:00 systemd[1]: Finished modprobe@drm.service - Load Kernel Module drm.
2024-10-30T07:48:35,356352+00:00 systemd[1]: Finished kmod-static-nodes.service - Create List of Static Device Nodes.
2024-10-30T07:48:35,356751+00:00 systemd[1]: Finished systemd-modules-load.service - Load Kernel Modules.
2024-10-30T07:48:35,358549+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2024-10-30T07:48:35,362610+00:00 systemd[1]: modprobe@configfs.service: Deactivated successfully.
2024-10-30T07:48:35,362761+00:00 systemd[1]: Finished modprobe@configfs.service - Load Kernel Module configfs.
2024-10-30T07:48:35,364598+00:00 systemd[1]: Mounting sys-kernel-config.mount - Kernel Configuration File System...
2024-10-30T07:48:35,367215+00:00 systemd[1]: Mounted sys-kernel-config.mount - Kernel Configuration File System.
2024-10-30T07:48:35,370070+00:00 systemd[1]: modprobe@efi_pstore.service: Deactivated successfully.
2024-10-30T07:48:35,370222+00:00 systemd[1]: Finished modprobe@efi_pstore.service - Load Kernel Module efi_pstore.
2024-10-30T07:48:35,370544+00:00 systemd[1]: nfs-convert.service: Deactivated successfully.
2024-10-30T07:48:35,370684+00:00 systemd[1]: Finished nfs-convert.service - Preprocess NFS configuration convertion.
2024-10-30T07:48:35,378296+00:00 systemd[1]: Finished systemd-network-generator.service - Generate network units from Kernel command line.
2024-10-30T07:48:35,389694+00:00 device-mapper: core: CONFIG_IMA_DISABLE_HTABLE is disabled. Duplicate IMA measurements will not be recorded in the IMA log.
2024-10-30T07:48:35,389730+00:00 device-mapper: uevent: version 1.0.3
2024-10-30T07:48:35,389931+00:00 device-mapper: ioctl: 4.47.0-ioctl (2022-07-28) initialised: dm-devel@redhat.com
2024-10-30T07:48:35,393420+00:00 systemd[1]: modprobe@dm_mod.service: Deactivated successfully.
2024-10-30T07:48:35,393585+00:00 systemd[1]: Finished modprobe@dm_mod.service - Load Kernel Module dm_mod.
2024-10-30T07:48:35,399986+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2024-10-30T07:48:35,405623+00:00 fuse: init (API version 7.38)
2024-10-30T07:48:35,408456+00:00 loop: module loaded
2024-10-30T07:48:35,534589+00:00 systemd-journald[875]: Received client request to flush runtime journal.
2024-10-30T07:48:35,846718+00:00 ACPI: \_SB_.PCI0.GSI1: Enabled at IRQ 36
2024-10-30T07:48:35,847269+00:00 ena 0000:00:05.0: Elastic Network Adapter (ENA) v2.13.0g
2024-10-30T07:48:35,847917+00:00 ena 0000:00:05.0: enabling device (0010 -> 0012)
2024-10-30T07:48:35,859969+00:00 ena 0000:00:05.0: ENA device version: 0.10
2024-10-30T07:48:35,860555+00:00 ena 0000:00:05.0: ENA controller version: 0.0.1 implementation version 1
2024-10-30T07:48:35,929999+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0C:00/input/input0
2024-10-30T07:48:35,934404+00:00 ACPI: button: Power Button [PWRB]
2024-10-30T07:48:35,934828+00:00 input: Sleep Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0E:00/input/input1
2024-10-30T07:48:35,935979+00:00 ACPI: button: Sleep Button [SLPB]
2024-10-30T07:48:35,954241+00:00 ena 0000:00:05.0: LLQ is not supported Fallback to host mode policy.
2024-10-30T07:48:35,965708+00:00 ena 0000:00:05.0: Elastic Network Adapter (ENA) found at mem 80004000, mac addr 0a:c1:43:1b:96:59
2024-10-30T07:48:36,074203+00:00 ena 0000:00:05.0 ens5: renamed from eth0
2024-10-30T07:48:36,449925+00:00 RPC: Registered named UNIX socket transport module.
2024-10-30T07:48:36,450437+00:00 RPC: Registered udp transport module.
2024-10-30T07:48:36,450803+00:00 RPC: Registered tcp transport module.
2024-10-30T07:48:36,451173+00:00 RPC: Registered tcp NFSv4.1 backchannel transport module.
2024-10-30T07:48:36,757112+00:00 ena 0000:00:05.0 ens5: Local page cache is disabled for less than 16 channels
2024-10-30T07:48:59,715965+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-30T07:48:59,780882+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-30T07:49:00,774325+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eni401e0302410: link becomes ready
2024-10-30T07:49:04,011175+00:00 pci 0000:00:06.0: [1d0f:ec20] type 00 class 0x020000
2024-10-30T07:49:04,011733+00:00 pci 0000:00:06.0: reg 0x10: [mem 0x00000000-0x00003fff]
2024-10-30T07:49:04,012424+00:00 pci 0000:00:06.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-30T07:49:04,013118+00:00 pci 0000:00:06.0: BAR 0: assigned [mem 0x8000c000-0x8000ffff]
2024-10-30T07:49:04,013842+00:00 ena 0000:00:06.0: enabling device (0000 -> 0002)
2024-10-30T07:49:04,025744+00:00 ena 0000:00:06.0: ENA device version: 0.10
2024-10-30T07:49:04,026171+00:00 ena 0000:00:06.0: ENA controller version: 0.0.1 implementation version 1
2024-10-30T07:49:04,103827+00:00 ena 0000:00:06.0: LLQ is not supported Fallback to host mode policy.
2024-10-30T07:49:04,115100+00:00 ena 0000:00:06.0: Elastic Network Adapter (ENA) found at mem 8000c000, mac addr 0a:21:dd:03:eb:5f
2024-10-30T07:49:04,153899+00:00 ena 0000:00:06.0 ens6: renamed from eth0
2024-10-30T07:49:04,200121+00:00 ena 0000:00:06.0 ens6: Local page cache is disabled for less than 16 channels
2024-10-30T07:49:04,202458+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): ens6: link becomes ready
2024-10-30T07:56:49,802717+00:00 Initializing XFRM netlink socket
2024-10-30T07:56:50,212550+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): cilium_host: link becomes ready
2024-10-30T07:56:51,256218+00:00 cilium_vxlan: Caught tx_queue_len zero misconfig
2024-10-30T07:56:52,551594+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2024-10-30T07:56:55,159960+00:00 eth0: renamed from tmp804e8
2024-10-30T07:56:55,203039+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-30T07:56:55,203831+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc249789499a34: link becomes ready
2024-10-30T07:56:55,450079+00:00 eth0: renamed from tmp6e3f6
2024-10-30T07:56:55,490700+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc9991497e3b46: link becomes ready
2024-10-30T08:01:43,457798+00:00 eth0: renamed from tmp08c51
2024-10-30T08:01:43,507769+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-30T08:01:43,508319+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc2d09ef246dcd: link becomes ready
2024-10-30T08:11:40,462493+00:00 eth0: renamed from tmp3df72
2024-10-30T08:11:40,521850+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-30T08:11:40,522409+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcb876be33544e: link becomes ready
2024-10-30T08:22:58,245222+00:00 printk: dmesg (8241): Attempt to access syslog with CAP_SYS_ADMIN but no CAP_SYSLOG (deprecated).
