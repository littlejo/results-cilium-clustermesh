IP ADDRESS        LOCAL ENDPOINT INFO
10.47.0.179:0     (localhost)                                                                                        
10.47.0.5:0       id=2642  sec_id=1586988 flags=0x0000 ifindex=18  mac=56:7D:B5:D6:72:39 nodemac=22:E8:3B:6E:BC:72   
10.47.0.197:0     id=2320  sec_id=1575285 flags=0x0000 ifindex=14  mac=3E:11:96:54:45:34 nodemac=B2:9E:25:27:BD:74   
172.31.253.19:0   (localhost)                                                                                        
172.31.245.31:0   (localhost)                                                                                        
10.47.0.227:0     id=129   sec_id=1575285 flags=0x0000 ifindex=12  mac=CE:EC:9A:15:3A:6E nodemac=8A:E4:6E:17:A6:BE   
10.47.0.17:0      id=810   sec_id=4     flags=0x0000 ifindex=10  mac=4A:59:83:6B:98:8E nodemac=5A:2B:62:D1:F8:D4     
