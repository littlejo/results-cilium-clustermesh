alloc: 165.86MB (173918240 bytes)
total-alloc: 2.22GB (2387481016 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 62971071
frees: 61051872
heap-alloc: 165.86MB (173918240 bytes)
heap-sys: 247.82MB (259858432 bytes)
heap-idle: 56.41MB (59146240 bytes)
heap-in-use: 191.41MB (200712192 bytes)
heap-released: 2.58MB (2703360 bytes)
heap-objects: 1919199
stack-in-use: 64.16MB (67272704 bytes)
stack-sys: 64.16MB (67272704 bytes)
stack-mspan-inuse: 3.28MB (3434880 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.20MB (1257121 bytes)
gc-sys: 5.99MB (6284776 bytes)
next-gc: when heap-alloc >= 213.53MB (223903304 bytes)
last-gc: 2024-10-30 08:23:00.113784517 +0000 UTC
gc-pause-total: 14.431288ms
gc-pause: 812544
gc-pause-end: 1730276580113784517
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0003888795152068244
enable-gc: true
debug-gc: false
