key: 81 00 00 00  value: 16 02 00 00
key: 2a 03 00 00  value: 21 02 00 00
key: 10 09 00 00  value: 2a 02 00 00
key: 52 0a 00 00  value: 6e 02 00 00
Found 4 elements
