ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.182.42:443 (active)    
                                         2 => 172.31.229.186:443 (active)   
2    10.100.103.88:443    ClusterIP      1 => 172.31.253.19:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.47.0.197:9153 (active)     
                                         2 => 10.47.0.227:9153 (active)     
4    10.100.0.10:53       ClusterIP      1 => 10.47.0.197:53 (active)       
                                         2 => 10.47.0.227:53 (active)       
5    10.100.254.58:2379   ClusterIP      1 => 10.47.0.5:2379 (active)       
