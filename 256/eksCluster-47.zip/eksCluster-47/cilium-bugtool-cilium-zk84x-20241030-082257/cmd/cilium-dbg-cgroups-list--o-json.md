[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75152430_d943_4e61_8516_774eaf55ab4c.slice/cri-containerd-4b50ad9b9794a9d98d19ae62aca871bd31204c1d936442a30d5eb55c7aee859f.scope"
      }
    ],
    "ips": [
      "10.47.0.197"
    ],
    "name": "coredns-cc6ccd49c-24xc9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda03bdfc3_04f2_4a31_9ee1_85b277d4b6e0.slice/cri-containerd-09dcdbce1f270a3c7c7bf579f2a460799385e9ad1260ab00e6788ce9d20e7706.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda03bdfc3_04f2_4a31_9ee1_85b277d4b6e0.slice/cri-containerd-d540dd6a81df0e8918d127888539ffa463378f16e3b522e2642af48629b3304b.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda03bdfc3_04f2_4a31_9ee1_85b277d4b6e0.slice/cri-containerd-0409b0189f8e281fc343271bb5a00495cd1bc64a9072ed89960b41da84e794da.scope"
      }
    ],
    "ips": [
      "10.47.0.5"
    ],
    "name": "clustermesh-apiserver-f48dbf596-jf5jm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfed0413f_5bb0_4e83_9349_ec32d33a4b61.slice/cri-containerd-1fcee8c81425aaf93f5467afbe7a4d4cddf412dd304e281c13fe505b819d519d.scope"
      }
    ],
    "ips": [
      "10.47.0.227"
    ],
    "name": "coredns-cc6ccd49c-8njmt",
    "namespace": "kube-system"
  }
]

