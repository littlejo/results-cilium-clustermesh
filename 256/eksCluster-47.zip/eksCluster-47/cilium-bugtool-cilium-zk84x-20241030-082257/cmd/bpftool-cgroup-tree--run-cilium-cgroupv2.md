CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfed0413f_5bb0_4e83_9349_ec32d33a4b61.slice/cri-containerd-1fcee8c81425aaf93f5467afbe7a4d4cddf412dd304e281c13fe505b819d519d.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfed0413f_5bb0_4e83_9349_ec32d33a4b61.slice/cri-containerd-804e8f971c1e7d93bc61af8c5113f89aa5f77a2c69343c4de8f47b02f0b13252.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9b6fb679_a10d_4df4_9b17_119c4dc1924e.slice/cri-containerd-ca04c0dff577ed83c3518ce0943f0da08b84390d6e90901ade5a181f38a6a05e.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9b6fb679_a10d_4df4_9b17_119c4dc1924e.slice/cri-containerd-0bccee70b64a6650a695988c382a133fb62a3e7d025da79abf33bba4d150b6a5.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a44e8df_acd7_4814_8a34_2e61cc675a4b.slice/cri-containerd-805c24ef09674b5e0b01d9ba08fe56695bd5ee93a271076c76cead96eb495de5.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a44e8df_acd7_4814_8a34_2e61cc675a4b.slice/cri-containerd-b8212f066a5da61cb6dd3b013b0c18e35af9b447147bb7ca26c98591b03b5a5c.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75152430_d943_4e61_8516_774eaf55ab4c.slice/cri-containerd-6e3f66905f03798daf7be39a277b835ebd395a7fda13ece1097cf3c1ee32bb7e.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75152430_d943_4e61_8516_774eaf55ab4c.slice/cri-containerd-4b50ad9b9794a9d98d19ae62aca871bd31204c1d936442a30d5eb55c7aee859f.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbb77bd8c_5ecf_4560_b293_3cedf785903a.slice/cri-containerd-b89f0477ae9f0cfef147b613356f9237a377ec52b398852cc46df8949f9a5d6e.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbb77bd8c_5ecf_4560_b293_3cedf785903a.slice/cri-containerd-12f55291a0d264399f64320b38af4e67279ff862b83de60ed79575b48b1bd24f.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod387b3bbc_9209_4e48_a513_c25e5bab78c0.slice/cri-containerd-928353584d37a07d66a4f55ce963fe60d64194ae0e98972c4190f59f5f493e3a.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod387b3bbc_9209_4e48_a513_c25e5bab78c0.slice/cri-containerd-32331b7515f7b42ee9cfe3b453080ba9bb5236cbc37a7813691a6b9353db2110.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda03bdfc3_04f2_4a31_9ee1_85b277d4b6e0.slice/cri-containerd-09dcdbce1f270a3c7c7bf579f2a460799385e9ad1260ab00e6788ce9d20e7706.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda03bdfc3_04f2_4a31_9ee1_85b277d4b6e0.slice/cri-containerd-3df727afd4c3f4a5d0a7b958b5c78b4b7dad910753b35f5c85be503af6af26bc.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda03bdfc3_04f2_4a31_9ee1_85b277d4b6e0.slice/cri-containerd-0409b0189f8e281fc343271bb5a00495cd1bc64a9072ed89960b41da84e794da.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda03bdfc3_04f2_4a31_9ee1_85b277d4b6e0.slice/cri-containerd-d540dd6a81df0e8918d127888539ffa463378f16e3b522e2642af48629b3304b.scope
    642      cgroup_device   multi                                          
