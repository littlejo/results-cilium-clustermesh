alloc: 113.99MB (119527256 bytes)
total-alloc: 2.22GB (2381480432 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 62959700
frees: 62012225
heap-alloc: 113.99MB (119527256 bytes)
heap-sys: 243.45MB (255270912 bytes)
heap-idle: 76.83MB (80560128 bytes)
heap-in-use: 166.62MB (174710784 bytes)
heap-released: 264.00KB (270336 bytes)
heap-objects: 947475
stack-in-use: 64.53MB (67665920 bytes)
stack-sys: 64.53MB (67665920 bytes)
stack-mspan-inuse: 2.84MB (2976640 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 971.57KB (994889 bytes)
gc-sys: 5.98MB (6270392 bytes)
next-gc: when heap-alloc >= 216.39MB (226898088 bytes)
last-gc: 2024-10-30 08:23:08.677145482 +0000 UTC
gc-pause-total: 8.11358ms
gc-pause: 106381
gc-pause-end: 1730276588677145482
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.00048727402670962594
enable-gc: true
debug-gc: false
