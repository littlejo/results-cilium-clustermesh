1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ba:ab:96:2e:17 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.132.52/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3450sec preferred_lft 3450sec
    inet6 fe80::4ba:abff:fe96:2e17/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a2:69:cc:fc:a9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.133.31/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4a2:69ff:fecc:fca9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:3b:2b:6c:d2:03 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::903b:2bff:fe6c:d203/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:21:dd:44:fd:63 brd ff:ff:ff:ff:ff:ff
    inet 10.144.0.121/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::ac21:ddff:fe44:fd63/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3e:55:11:b1:98:bd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3c55:11ff:feb1:98bd/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:57:b9:55:66:ff brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a857:b9ff:fe55:66ff/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcbb2099ed1924@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:f9:fc:1e:00:5a brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::f8f9:fcff:fe1e:5a/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc9e931bfb58e9@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:b5:b7:44:0c:15 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ecb5:b7ff:fe44:c15/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc3bb6961bfb3b@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:08:02:58:2c:3b brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9008:2ff:fe58:2c3b/64 scope link 
       valid_lft forever preferred_lft forever
