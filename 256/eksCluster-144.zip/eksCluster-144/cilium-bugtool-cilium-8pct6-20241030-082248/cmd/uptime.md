 08:22:49 up 32 min,  0 users,  load average: 0.11, 0.22, 0.17
