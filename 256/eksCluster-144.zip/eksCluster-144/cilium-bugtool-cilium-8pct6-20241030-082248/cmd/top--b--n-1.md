top - 08:22:49 up 32 min,  0 users,  load average: 0.11, 0.22, 0.17
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 58.6 us, 24.1 sy,  0.0 ni, 13.8 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   7814.2 total,   4475.3 free,   1192.3 used,   2146.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6436.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 383796  78980 S  80.0   4.8   0:48.56 cilium-+
    403 root      20   0 1229744   8340   3900 S   0.0   0.1   0:01.18 cilium-+
    630 root      20   0 1240432  16352  11356 S   0.0   0.2   0:00.03 cilium-+
    636 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    642 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    679 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    684 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    711 root      20   0    6576   2416   2092 R   0.0   0.0   0:00.00 top
    715 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    740 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
