CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c58dbf8_d9fc_4ff6_9c31_eaf20be0a488.slice/cri-containerd-dc249b4b039b99bf41240f0fa21c03a3938b08ef93f142fe99a2afa9c64e6457.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c58dbf8_d9fc_4ff6_9c31_eaf20be0a488.slice/cri-containerd-f38fd0c70b912b010d97ddd14eef4c3e498b20e9114ca58950595a94c875cf1a.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod892560cd_a8dd_4e9c_adbd_11a654419011.slice/cri-containerd-1d0f1c9d32dd56e50587fcf65d43a221c7326d98a8cbfe1fa28fdbdc22ed3c09.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod892560cd_a8dd_4e9c_adbd_11a654419011.slice/cri-containerd-f255ccaa019108c6320c766008319fccf210530746b4fa9b913272652a203631.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ebf9876_c0fc_49bb_b762_6c377f2b41b8.slice/cri-containerd-b642f42d26e6339ca0bb3b04388110ecbd231d5ad6ae68cd248a7958ac864a1f.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ebf9876_c0fc_49bb_b762_6c377f2b41b8.slice/cri-containerd-540e5ade07656d0fbc85bef12fcc1d6740a40b4e5f1bbf184e01447c38103d45.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod00d2fe77_79a6_46ae_81f1_83e38ab07faa.slice/cri-containerd-afd0c95d1d2609998600ace9a9a5734ccbd3901f83b7ede999c4b81fbe9db544.scope
    545      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod00d2fe77_79a6_46ae_81f1_83e38ab07faa.slice/cri-containerd-5c7e103a585c68a528cdb6fe705fb6fe848b9ed480534b1f7ce8c35f921d31be.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddcdeae17_4ab5_4449_8de5_ee519a240c9c.slice/cri-containerd-82244d76c7e5c140ff2f3a633e1b6bf5783bfe243c975e83e52091ce2870d5dc.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddcdeae17_4ab5_4449_8de5_ee519a240c9c.slice/cri-containerd-562ec217b2109ee3554d50626fcb75deee6208baf626781d2c5c290eedb00de2.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod415795f5_aae7_4a94_8395_9b849af4402e.slice/cri-containerd-8f18f940d74987cb3a2c41441bae97cfcad5837318efd87ff7ce4ab59f17b0e1.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod415795f5_aae7_4a94_8395_9b849af4402e.slice/cri-containerd-5443b6417151d9e1fe2fed9e0d76d9912705061f3627a0f504113078c2f5a50b.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod415795f5_aae7_4a94_8395_9b849af4402e.slice/cri-containerd-2166d4cec53a251f383729e8c9ae3e82dafad79feb75c60bab12a8dd27ee35d5.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod415795f5_aae7_4a94_8395_9b849af4402e.slice/cri-containerd-b60c109839829d2deee76da7b9bf9ca811a8edf6e8783d150c5f6841334bd26c.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod589da988_1057_4515_82c4_ab1324bdc8f1.slice/cri-containerd-9b7c4786caa18b9ab70acccd30d0d131a5a7151933b26703647739ce1387800e.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod589da988_1057_4515_82c4_ab1324bdc8f1.slice/cri-containerd-fa7a1d855a2af6662f98b1ef4ce46f7843e9017a0f54bb5acaa57a539e8e56e5.scope
    97       cgroup_device   multi                                          
