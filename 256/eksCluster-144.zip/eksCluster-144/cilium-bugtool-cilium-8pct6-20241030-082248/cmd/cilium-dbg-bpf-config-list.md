KEY             VALUE
AgentLiveness   1989780441868
UTimeOffset     3379442597656250
