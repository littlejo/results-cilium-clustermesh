Endpoint ID: 73
Path: /sys/fs/bpf/tc/globals/cilium_policy_00073

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    128022   1468      0        
Allow    Egress      0          ANY          NONE         disabled    17271    187       0        


Endpoint ID: 550
Path: /sys/fs/bpf/tc/globals/cilium_policy_00550

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1639784   20734     0        
Allow    Ingress     1          ANY          NONE         disabled    19084     222       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1212
Path: /sys/fs/bpf/tc/globals/cilium_policy_01212

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11516829   114715    0        
Allow    Ingress     1          ANY          NONE         disabled    9719146    102135    0        
Allow    Egress      0          ANY          NONE         disabled    12773482   125837    0        


Endpoint ID: 1511
Path: /sys/fs/bpf/tc/globals/cilium_policy_01511

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2187
Path: /sys/fs/bpf/tc/globals/cilium_policy_02187

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    129144   1485      0        
Allow    Egress      0          ANY          NONE         disabled    17702    193       0        


