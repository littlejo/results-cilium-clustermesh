REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35439     2799456     677    bpf_overlay.c
Interface                 INGRESS     633244    130808865   1132   bpf_host.c
Success                   EGRESS      15387     1205936     1694   bpf_host.c
Success                   EGRESS      268695    33602458    1308   bpf_lxc.c
Success                   EGRESS      35027     2770050     53     encap.h
Success                   INGRESS     309704    34972197    86     l3.h
Success                   INGRESS     330407    36609763    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
