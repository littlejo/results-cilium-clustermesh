key: 49 00 00 00  value: ff 01 00 00
key: 26 02 00 00  value: 10 02 00 00
key: bc 04 00 00  value: 77 02 00 00
key: 8b 08 00 00  value: 22 02 00 00
Found 4 elements
