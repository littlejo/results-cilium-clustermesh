{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:42.220Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.132.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:42.220Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.133.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:42.220Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:46.850Z",
  "value": "id=550   sec_id=4     flags=0x0000 ifindex=10  mac=FA:D1:C8:68:88:8B nodemac=AA:57:B9:55:66:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:46.851Z",
  "value": "id=2187  sec_id=4776656 flags=0x0000 ifindex=14  mac=2A:B7:16:29:39:ED nodemac=EE:B5:B7:44:0C:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:46.913Z",
  "value": "id=73    sec_id=4776656 flags=0x0000 ifindex=12  mac=6E:B4:B8:26:78:47 nodemac=FA:F9:FC:1E:00:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:46.966Z",
  "value": "id=550   sec_id=4     flags=0x0000 ifindex=10  mac=FA:D1:C8:68:88:8B nodemac=AA:57:B9:55:66:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:47.044Z",
  "value": "id=2187  sec_id=4776656 flags=0x0000 ifindex=14  mac=2A:B7:16:29:39:ED nodemac=EE:B5:B7:44:0C:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:00.949Z",
  "value": "id=550   sec_id=4     flags=0x0000 ifindex=10  mac=FA:D1:C8:68:88:8B nodemac=AA:57:B9:55:66:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:00.949Z",
  "value": "id=2187  sec_id=4776656 flags=0x0000 ifindex=14  mac=2A:B7:16:29:39:ED nodemac=EE:B5:B7:44:0C:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:00.950Z",
  "value": "id=73    sec_id=4776656 flags=0x0000 ifindex=12  mac=6E:B4:B8:26:78:47 nodemac=FA:F9:FC:1E:00:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:00.980Z",
  "value": "id=652   sec_id=4777828 flags=0x0000 ifindex=16  mac=26:ED:A6:6C:47:A8 nodemac=5E:9C:58:9A:03:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:01.947Z",
  "value": "id=2187  sec_id=4776656 flags=0x0000 ifindex=14  mac=2A:B7:16:29:39:ED nodemac=EE:B5:B7:44:0C:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:01.947Z",
  "value": "id=550   sec_id=4     flags=0x0000 ifindex=10  mac=FA:D1:C8:68:88:8B nodemac=AA:57:B9:55:66:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:01.947Z",
  "value": "id=73    sec_id=4776656 flags=0x0000 ifindex=12  mac=6E:B4:B8:26:78:47 nodemac=FA:F9:FC:1E:00:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:01.948Z",
  "value": "id=652   sec_id=4777828 flags=0x0000 ifindex=16  mac=26:ED:A6:6C:47:A8 nodemac=5E:9C:58:9A:03:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.315Z",
  "value": "id=1212  sec_id=4777828 flags=0x0000 ifindex=18  mac=DE:AE:F7:B3:DF:E5 nodemac=92:08:02:58:2C:3B"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.144.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.666Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.866Z",
  "value": "id=1212  sec_id=4777828 flags=0x0000 ifindex=18  mac=DE:AE:F7:B3:DF:E5 nodemac=92:08:02:58:2C:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.867Z",
  "value": "id=550   sec_id=4     flags=0x0000 ifindex=10  mac=FA:D1:C8:68:88:8B nodemac=AA:57:B9:55:66:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.867Z",
  "value": "id=2187  sec_id=4776656 flags=0x0000 ifindex=14  mac=2A:B7:16:29:39:ED nodemac=EE:B5:B7:44:0C:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.867Z",
  "value": "id=73    sec_id=4776656 flags=0x0000 ifindex=12  mac=6E:B4:B8:26:78:47 nodemac=FA:F9:FC:1E:00:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.869Z",
  "value": "id=1212  sec_id=4777828 flags=0x0000 ifindex=18  mac=DE:AE:F7:B3:DF:E5 nodemac=92:08:02:58:2C:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.870Z",
  "value": "id=550   sec_id=4     flags=0x0000 ifindex=10  mac=FA:D1:C8:68:88:8B nodemac=AA:57:B9:55:66:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.871Z",
  "value": "id=2187  sec_id=4776656 flags=0x0000 ifindex=14  mac=2A:B7:16:29:39:ED nodemac=EE:B5:B7:44:0C:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.871Z",
  "value": "id=73    sec_id=4776656 flags=0x0000 ifindex=12  mac=6E:B4:B8:26:78:47 nodemac=FA:F9:FC:1E:00:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.882Z",
  "value": "id=73    sec_id=4776656 flags=0x0000 ifindex=12  mac=6E:B4:B8:26:78:47 nodemac=FA:F9:FC:1E:00:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.882Z",
  "value": "id=1212  sec_id=4777828 flags=0x0000 ifindex=18  mac=DE:AE:F7:B3:DF:E5 nodemac=92:08:02:58:2C:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.883Z",
  "value": "id=550   sec_id=4     flags=0x0000 ifindex=10  mac=FA:D1:C8:68:88:8B nodemac=AA:57:B9:55:66:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.884Z",
  "value": "id=2187  sec_id=4776656 flags=0x0000 ifindex=14  mac=2A:B7:16:29:39:ED nodemac=EE:B5:B7:44:0C:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.867Z",
  "value": "id=550   sec_id=4     flags=0x0000 ifindex=10  mac=FA:D1:C8:68:88:8B nodemac=AA:57:B9:55:66:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.867Z",
  "value": "id=1212  sec_id=4777828 flags=0x0000 ifindex=18  mac=DE:AE:F7:B3:DF:E5 nodemac=92:08:02:58:2C:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.867Z",
  "value": "id=2187  sec_id=4776656 flags=0x0000 ifindex=14  mac=2A:B7:16:29:39:ED nodemac=EE:B5:B7:44:0C:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.868Z",
  "value": "id=73    sec_id=4776656 flags=0x0000 ifindex=12  mac=6E:B4:B8:26:78:47 nodemac=FA:F9:FC:1E:00:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.867Z",
  "value": "id=550   sec_id=4     flags=0x0000 ifindex=10  mac=FA:D1:C8:68:88:8B nodemac=AA:57:B9:55:66:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.867Z",
  "value": "id=73    sec_id=4776656 flags=0x0000 ifindex=12  mac=6E:B4:B8:26:78:47 nodemac=FA:F9:FC:1E:00:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.868Z",
  "value": "id=1212  sec_id=4777828 flags=0x0000 ifindex=18  mac=DE:AE:F7:B3:DF:E5 nodemac=92:08:02:58:2C:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.144.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.868Z",
  "value": "id=2187  sec_id=4776656 flags=0x0000 ifindex=14  mac=2A:B7:16:29:39:ED nodemac=EE:B5:B7:44:0C:15"
}

