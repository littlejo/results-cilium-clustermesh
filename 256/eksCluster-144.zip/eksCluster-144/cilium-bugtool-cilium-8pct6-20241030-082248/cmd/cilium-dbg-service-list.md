ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.179.59:443 (active)    
                                         2 => 172.31.217.59:443 (active)    
2    10.100.148.233:443   ClusterIP      1 => 172.31.132.52:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.144.0.15:53 (active)       
                                         2 => 10.144.0.91:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.144.0.15:9153 (active)     
                                         2 => 10.144.0.91:9153 (active)     
5    10.100.133.21:2379   ClusterIP      1 => 10.144.0.163:2379 (active)    
