[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ebf9876_c0fc_49bb_b762_6c377f2b41b8.slice/cri-containerd-540e5ade07656d0fbc85bef12fcc1d6740a40b4e5f1bbf184e01447c38103d45.scope"
      }
    ],
    "ips": [
      "10.144.0.15"
    ],
    "name": "coredns-cc6ccd49c-sg7zk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod00d2fe77_79a6_46ae_81f1_83e38ab07faa.slice/cri-containerd-5c7e103a585c68a528cdb6fe705fb6fe848b9ed480534b1f7ce8c35f921d31be.scope"
      }
    ],
    "ips": [
      "10.144.0.91"
    ],
    "name": "coredns-cc6ccd49c-n4pww",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod415795f5_aae7_4a94_8395_9b849af4402e.slice/cri-containerd-b60c109839829d2deee76da7b9bf9ca811a8edf6e8783d150c5f6841334bd26c.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod415795f5_aae7_4a94_8395_9b849af4402e.slice/cri-containerd-5443b6417151d9e1fe2fed9e0d76d9912705061f3627a0f504113078c2f5a50b.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod415795f5_aae7_4a94_8395_9b849af4402e.slice/cri-containerd-8f18f940d74987cb3a2c41441bae97cfcad5837318efd87ff7ce4ab59f17b0e1.scope"
      }
    ],
    "ips": [
      "10.144.0.163"
    ],
    "name": "clustermesh-apiserver-588855dd79-f9hml",
    "namespace": "kube-system"
  }
]

