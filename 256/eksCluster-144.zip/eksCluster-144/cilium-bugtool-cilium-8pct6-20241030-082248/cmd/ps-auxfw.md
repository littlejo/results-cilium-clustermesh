USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         684  0.0  0.0  13060  1228 ?        Rs   08:22   0:00 /usr/sbin/runc init
root         679  0.0  0.0  13060  1228 ?        Rs   08:22   0:00 /usr/sbin/runc init
root         678  0.0  0.1 1408840 8364 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         642  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         636  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         630  0.0  0.2 1240432 16352 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         677  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         685  0.0  0.0   3728   488 ?        R    08:22   0:00  \_ bash -c hostname
root           1  3.6  4.7 1606080 380864 ?      Ssl  08:00   0:48 cilium-agent --config-dir=/tmp/cilium/config-map
root         403  0.0  0.1 1229744 8340 ?        Sl   08:00   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
