KEY             VALUE
AgentLiveness   2163914646003
UTimeOffset     3379442257812500
