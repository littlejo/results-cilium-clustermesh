Endpoint ID: 103
Path: /sys/fs/bpf/tc/globals/cilium_policy_00103

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    71197    639       0        
Allow    Ingress     1          ANY          NONE         disabled    169354   1943      0        
Allow    Egress      0          ANY          NONE         disabled    47788    482       0        


Endpoint ID: 1541
Path: /sys/fs/bpf/tc/globals/cilium_policy_01541

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1550
Path: /sys/fs/bpf/tc/globals/cilium_policy_01550

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    67183    603       0        
Allow    Ingress     1          ANY          NONE         disabled    169997   1958      0        
Allow    Egress      0          ANY          NONE         disabled    46615    476       0        


Endpoint ID: 3335
Path: /sys/fs/bpf/tc/globals/cilium_policy_03335

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1650414   20894     0        
Allow    Ingress     1          ANY          NONE         disabled    25884     304       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3845
Path: /sys/fs/bpf/tc/globals/cilium_policy_03845

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11462345   115828    0        
Allow    Ingress     1          ANY          NONE         disabled    11287569   119683    0        
Allow    Egress      0          ANY          NONE         disabled    15104425   146973    0        


