1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:dd:01:45:87:29 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.210.31/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3277sec preferred_lft 3277sec
    inet6 fe80::8dd:1ff:fe45:8729/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:1a:cb:7e:98:f7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.235.223/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::81a:cbff:fe7e:98f7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:97:27:d2:61:6f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f897:27ff:fed2:616f/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:28:c9:18:3f:0b brd ff:ff:ff:ff:ff:ff
    inet 10.123.0.107/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::7028:c9ff:fe18:3f0b/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether d6:2f:23:22:d7:1f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d42f:23ff:fe22:d71f/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:b4:a1:27:56:75 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::acb4:a1ff:fe27:5675/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc2cf3d04a2026@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:de:ea:e1:18:d7 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::30de:eaff:fee1:18d7/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc1e6972f8b864@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:f1:c0:7e:90:90 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::88f1:c0ff:fe7e:9090/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcc9016adcca5b@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:aa:49:64:f1:68 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::70aa:49ff:fe64:f168/64 scope link 
       valid_lft forever preferred_lft forever
