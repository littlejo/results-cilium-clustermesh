REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37736     2990653     677    bpf_overlay.c
Interface                 INGRESS     674974    137301174   1132   bpf_host.c
Success                   EGRESS      17553     1389069     1694   bpf_host.c
Success                   EGRESS      2484      393742      86     l3.h
Success                   EGRESS      292685    35883517    1308   bpf_lxc.c
Success                   EGRESS      38838     3071458     53     encap.h
Success                   INGRESS     336705    38217336    86     l3.h
Success                   INGRESS     360023    40256708    235    trace.h
Unsupported L3 protocol   EGRESS      44        3292        1492   bpf_lxc.c
