key: 67 00 00 00  value: 0f 02 00 00
key: 0e 06 00 00  value: 27 02 00 00
key: 07 0d 00 00  value: 1e 02 00 00
key: 05 0f 00 00  value: 66 02 00 00
Found 4 elements
