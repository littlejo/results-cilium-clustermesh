ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.180.99:443 (active)    
                                         2 => 172.31.226.141:443 (active)   
2    10.100.103.102:443   ClusterIP      1 => 172.31.210.31:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.123.0.113:9153 (active)    
                                         2 => 10.123.0.26:9153 (active)     
4    10.100.0.10:53       ClusterIP      1 => 10.123.0.113:53 (active)      
                                         2 => 10.123.0.26:53 (active)       
5    10.100.133.38:2379   ClusterIP      1 => 10.123.0.148:2379 (active)    
