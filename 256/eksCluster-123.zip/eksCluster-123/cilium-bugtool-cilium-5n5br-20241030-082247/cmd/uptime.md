 08:22:48 up 35 min,  0 users,  load average: 0.23, 0.22, 0.18
