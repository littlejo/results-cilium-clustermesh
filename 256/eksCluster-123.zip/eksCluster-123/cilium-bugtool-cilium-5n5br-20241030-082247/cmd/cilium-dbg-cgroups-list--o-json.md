[
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff9d120a_9bd4_4674_92a2_d3e951a18216.slice/cri-containerd-96cd0cd30990983ced2b21b4fc411c117dc53462b55f4729616827ec200c562b.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff9d120a_9bd4_4674_92a2_d3e951a18216.slice/cri-containerd-51242679deb4e2cd7da63259214c1fc8c5695147dac1d19b2a17daf1245194c3.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff9d120a_9bd4_4674_92a2_d3e951a18216.slice/cri-containerd-fd823ee4f93c731ffeb26bd5c59f020dca150a65678881bc8abf1ca8f1fda571.scope"
      }
    ],
    "ips": [
      "10.123.0.148"
    ],
    "name": "clustermesh-apiserver-5d5ff4779b-mds4z",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9b5c0c49_d11b_44b0_95c8_2e100c967519.slice/cri-containerd-285034370fb181e9aec5191c34ba31ece42e73ffb1b1f60ded824ab46c760a14.scope"
      }
    ],
    "ips": [
      "10.123.0.113"
    ],
    "name": "coredns-cc6ccd49c-fwf7l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa040d06_2524_4878_bd0f_2867c09da7fc.slice/cri-containerd-e92e3b7c3b78f557fec27573354b39b1ee2b1e9ab153899ca07759fd434fc016.scope"
      }
    ],
    "ips": [
      "10.123.0.26"
    ],
    "name": "coredns-cc6ccd49c-w4dh5",
    "namespace": "kube-system"
  }
]

