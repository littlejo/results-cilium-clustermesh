xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 499
ens6(5) clsact/ingress cil_from_netdev-ens6 id 507
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 492
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 484
cilium_host(7) clsact/egress cil_from_host-cilium_host id 482
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 537
lxc2cf3d04a2026(12) clsact/ingress cil_from_container-lxc2cf3d04a2026 id 512
lxc1e6972f8b864(14) clsact/ingress cil_from_container-lxc1e6972f8b864 id 532
lxcc9016adcca5b(18) clsact/ingress cil_from_container-lxcc9016adcca5b id 617

flow_dissector:

netfilter:

