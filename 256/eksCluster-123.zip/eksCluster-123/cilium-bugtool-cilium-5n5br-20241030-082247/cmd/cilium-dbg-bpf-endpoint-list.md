IP ADDRESS         LOCAL ENDPOINT INFO
172.31.235.223:0   (localhost)                                                                                        
10.123.0.26:0      id=1550  sec_id=4083128 flags=0x0000 ifindex=14  mac=E2:11:A9:90:82:6B nodemac=8A:F1:C0:7E:90:90   
172.31.210.31:0    (localhost)                                                                                        
10.123.0.107:0     (localhost)                                                                                        
10.123.0.63:0      id=3335  sec_id=4     flags=0x0000 ifindex=10  mac=02:09:0F:DF:57:B9 nodemac=AE:B4:A1:27:56:75     
10.123.0.148:0     id=3845  sec_id=4070604 flags=0x0000 ifindex=18  mac=5E:2A:DE:2B:8F:CB nodemac=72:AA:49:64:F1:68   
10.123.0.113:0     id=103   sec_id=4083128 flags=0x0000 ifindex=12  mac=76:5E:16:5E:2A:DB nodemac=32:DE:EA:E1:18:D7   
