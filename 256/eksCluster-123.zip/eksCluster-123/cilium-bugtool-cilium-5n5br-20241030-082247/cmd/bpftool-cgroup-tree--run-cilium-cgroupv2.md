CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9b5c0c49_d11b_44b0_95c8_2e100c967519.slice/cri-containerd-aa10c97a87230198b75f6cf489f1addad635aaa1081cda767961c4a259421c04.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9b5c0c49_d11b_44b0_95c8_2e100c967519.slice/cri-containerd-285034370fb181e9aec5191c34ba31ece42e73ffb1b1f60ded824ab46c760a14.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5acbadcc_13c7_43cc_9e16_f56431bf84cc.slice/cri-containerd-4f1f14c89a0745b42fb218063539357755b4eae7dd7a5320e19883303909fe01.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5acbadcc_13c7_43cc_9e16_f56431bf84cc.slice/cri-containerd-cffd9bb69ad9300eeebcbf7183672f9cfd1baa9f1560f8debe13709436c830c5.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa040d06_2524_4878_bd0f_2867c09da7fc.slice/cri-containerd-e92e3b7c3b78f557fec27573354b39b1ee2b1e9ab153899ca07759fd434fc016.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa040d06_2524_4878_bd0f_2867c09da7fc.slice/cri-containerd-4bf172349c3a8ee84596ca836e8140b506d95b40a47e8974fb9d2acaf2000604.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podef45886f_af96_4810_8b25_a898f663f599.slice/cri-containerd-14c98f6bc258287a1bab382ac5f8b1a13b4d4778a5a0fc4ac1b5f1f0d456a519.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podef45886f_af96_4810_8b25_a898f663f599.slice/cri-containerd-795dee84ccc5b757b2f98f08fbca0e2408c06ddff79573a67e56f1846e5037fc.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e685c86_eae9_47c7_bb94_8b9d7e80a8e6.slice/cri-containerd-2b0ad2f363aa418efbf3d681996a40c444dbf40f462d8b6eff785bc73660ad26.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e685c86_eae9_47c7_bb94_8b9d7e80a8e6.slice/cri-containerd-105c3f8a488bff657c354d7a67423fef5b5da63b65f2c3e27b7726db3ad666d6.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod11647f2d_026b_4ded_b298_279b26887ae7.slice/cri-containerd-a9a327ab5cecfdeb31d099f4cae165e25b4901c2ed5d57149cc107c90aea9330.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod11647f2d_026b_4ded_b298_279b26887ae7.slice/cri-containerd-3884c1bf574198da36252fac600a79ca3fb53f80ffcccdc6fcf1ffa4c7379134.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff9d120a_9bd4_4674_92a2_d3e951a18216.slice/cri-containerd-aca9441ca54ee469beb5ace0a8022b3b1f17e5f9c5ec715197e3a4226df4a932.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff9d120a_9bd4_4674_92a2_d3e951a18216.slice/cri-containerd-fd823ee4f93c731ffeb26bd5c59f020dca150a65678881bc8abf1ca8f1fda571.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff9d120a_9bd4_4674_92a2_d3e951a18216.slice/cri-containerd-96cd0cd30990983ced2b21b4fc411c117dc53462b55f4729616827ec200c562b.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff9d120a_9bd4_4674_92a2_d3e951a18216.slice/cri-containerd-51242679deb4e2cd7da63259214c1fc8c5695147dac1d19b2a17daf1245194c3.scope
    643      cgroup_device   multi                                          
