{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:53.356Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.210.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:53.356Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.235.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:53.356Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:57.746Z",
  "value": "id=103   sec_id=4083128 flags=0x0000 ifindex=12  mac=76:5E:16:5E:2A:DB nodemac=32:DE:EA:E1:18:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:57.749Z",
  "value": "id=3335  sec_id=4     flags=0x0000 ifindex=10  mac=02:09:0F:DF:57:B9 nodemac=AE:B4:A1:27:56:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:57.751Z",
  "value": "id=103   sec_id=4083128 flags=0x0000 ifindex=12  mac=76:5E:16:5E:2A:DB nodemac=32:DE:EA:E1:18:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:57.807Z",
  "value": "id=3335  sec_id=4     flags=0x0000 ifindex=10  mac=02:09:0F:DF:57:B9 nodemac=AE:B4:A1:27:56:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:57.826Z",
  "value": "id=1550  sec_id=4083128 flags=0x0000 ifindex=14  mac=E2:11:A9:90:82:6B nodemac=8A:F1:C0:7E:90:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:32.813Z",
  "value": "id=3335  sec_id=4     flags=0x0000 ifindex=10  mac=02:09:0F:DF:57:B9 nodemac=AE:B4:A1:27:56:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:32.814Z",
  "value": "id=103   sec_id=4083128 flags=0x0000 ifindex=12  mac=76:5E:16:5E:2A:DB nodemac=32:DE:EA:E1:18:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:32.814Z",
  "value": "id=1550  sec_id=4083128 flags=0x0000 ifindex=14  mac=E2:11:A9:90:82:6B nodemac=8A:F1:C0:7E:90:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:32.843Z",
  "value": "id=1147  sec_id=4070604 flags=0x0000 ifindex=16  mac=E2:4C:EC:6C:C5:AC nodemac=4A:44:32:3F:0B:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:33.814Z",
  "value": "id=3335  sec_id=4     flags=0x0000 ifindex=10  mac=02:09:0F:DF:57:B9 nodemac=AE:B4:A1:27:56:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:33.814Z",
  "value": "id=1550  sec_id=4083128 flags=0x0000 ifindex=14  mac=E2:11:A9:90:82:6B nodemac=8A:F1:C0:7E:90:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:33.814Z",
  "value": "id=1147  sec_id=4070604 flags=0x0000 ifindex=16  mac=E2:4C:EC:6C:C5:AC nodemac=4A:44:32:3F:0B:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:33.814Z",
  "value": "id=103   sec_id=4083128 flags=0x0000 ifindex=12  mac=76:5E:16:5E:2A:DB nodemac=32:DE:EA:E1:18:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:30.254Z",
  "value": "id=3845  sec_id=4070604 flags=0x0000 ifindex=18  mac=5E:2A:DE:2B:8F:CB nodemac=72:AA:49:64:F1:68"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.123.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.984Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:04.304Z",
  "value": "id=3335  sec_id=4     flags=0x0000 ifindex=10  mac=02:09:0F:DF:57:B9 nodemac=AE:B4:A1:27:56:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:04.309Z",
  "value": "id=103   sec_id=4083128 flags=0x0000 ifindex=12  mac=76:5E:16:5E:2A:DB nodemac=32:DE:EA:E1:18:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:04.310Z",
  "value": "id=1550  sec_id=4083128 flags=0x0000 ifindex=14  mac=E2:11:A9:90:82:6B nodemac=8A:F1:C0:7E:90:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:04.310Z",
  "value": "id=3845  sec_id=4070604 flags=0x0000 ifindex=18  mac=5E:2A:DE:2B:8F:CB nodemac=72:AA:49:64:F1:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:05.266Z",
  "value": "id=103   sec_id=4083128 flags=0x0000 ifindex=12  mac=76:5E:16:5E:2A:DB nodemac=32:DE:EA:E1:18:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:05.315Z",
  "value": "id=1550  sec_id=4083128 flags=0x0000 ifindex=14  mac=E2:11:A9:90:82:6B nodemac=8A:F1:C0:7E:90:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:05.316Z",
  "value": "id=3845  sec_id=4070604 flags=0x0000 ifindex=18  mac=5E:2A:DE:2B:8F:CB nodemac=72:AA:49:64:F1:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:05.318Z",
  "value": "id=3335  sec_id=4     flags=0x0000 ifindex=10  mac=02:09:0F:DF:57:B9 nodemac=AE:B4:A1:27:56:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:06.258Z",
  "value": "id=3335  sec_id=4     flags=0x0000 ifindex=10  mac=02:09:0F:DF:57:B9 nodemac=AE:B4:A1:27:56:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:06.258Z",
  "value": "id=3845  sec_id=4070604 flags=0x0000 ifindex=18  mac=5E:2A:DE:2B:8F:CB nodemac=72:AA:49:64:F1:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:06.259Z",
  "value": "id=103   sec_id=4083128 flags=0x0000 ifindex=12  mac=76:5E:16:5E:2A:DB nodemac=32:DE:EA:E1:18:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:06.259Z",
  "value": "id=1550  sec_id=4083128 flags=0x0000 ifindex=14  mac=E2:11:A9:90:82:6B nodemac=8A:F1:C0:7E:90:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.260Z",
  "value": "id=3845  sec_id=4070604 flags=0x0000 ifindex=18  mac=5E:2A:DE:2B:8F:CB nodemac=72:AA:49:64:F1:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.260Z",
  "value": "id=103   sec_id=4083128 flags=0x0000 ifindex=12  mac=76:5E:16:5E:2A:DB nodemac=32:DE:EA:E1:18:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.260Z",
  "value": "id=1550  sec_id=4083128 flags=0x0000 ifindex=14  mac=E2:11:A9:90:82:6B nodemac=8A:F1:C0:7E:90:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.260Z",
  "value": "id=3335  sec_id=4     flags=0x0000 ifindex=10  mac=02:09:0F:DF:57:B9 nodemac=AE:B4:A1:27:56:75"
}

