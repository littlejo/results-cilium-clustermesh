alloc: 204.22MB (214138136 bytes)
total-alloc: 2.41GB (2590807616 bytes)
sys: 324.58MB (340349284 bytes)
lookups: 0
mallocs: 66087914
frees: 63886527
heap-alloc: 204.22MB (214138136 bytes)
heap-sys: 246.95MB (258949120 bytes)
heap-idle: 19.16MB (20094976 bytes)
heap-in-use: 227.79MB (238854144 bytes)
heap-released: 616.00KB (630784 bytes)
heap-objects: 2201387
stack-in-use: 65.00MB (68157440 bytes)
stack-sys: 65.00MB (68157440 bytes)
stack-mspan-inuse: 3.63MB (3808320 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1055545 bytes)
gc-sys: 5.81MB (6092192 bytes)
next-gc: when heap-alloc >= 237.88MB (249439736 bytes)
last-gc: 2024-10-30 08:22:49.235254548 +0000 UTC
gc-pause-total: 24.815834ms
gc-pause: 223321
gc-pause-end: 1730276569235254548
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.00044751691133711343
enable-gc: true
debug-gc: false
