alloc: 117.72MB (123435128 bytes)
total-alloc: 2.07GB (2218744216 bytes)
sys: 324.89MB (340676964 bytes)
lookups: 0
mallocs: 60240300
frees: 59494901
heap-alloc: 117.72MB (123435128 bytes)
heap-sys: 250.98MB (263168000 bytes)
heap-idle: 78.77MB (82599936 bytes)
heap-in-use: 172.20MB (180568064 bytes)
heap-released: 3.97MB (4161536 bytes)
heap-objects: 745399
stack-in-use: 61.00MB (63963136 bytes)
stack-sys: 61.00MB (63963136 bytes)
stack-mspan-inuse: 2.70MB (2828960 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1063305 bytes)
gc-sys: 6.13MB (6426112 bytes)
next-gc: when heap-alloc >= 211.81MB (222096616 bytes)
last-gc: 2024-10-30 08:22:57.852436119 +0000 UTC
gc-pause-total: 29.861231ms
gc-pause: 145506
gc-pause-end: 1730276577852436119
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.00033991533394542203
enable-gc: true
debug-gc: false
