REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     31990     2526272     677    bpf_overlay.c
Interface                 INGRESS     563124    122202493   1132   bpf_host.c
Success                   EGRESS      12407     970638      1694   bpf_host.c
Success                   EGRESS      240677    30639842    1308   bpf_lxc.c
Success                   EGRESS      30123     2390860     53     encap.h
Success                   INGRESS     275529    30518298    86     l3.h
Success                   INGRESS     295763    32117978    235    trace.h
Unsupported L3 protocol   EGRESS      39        2866        1492   bpf_lxc.c
