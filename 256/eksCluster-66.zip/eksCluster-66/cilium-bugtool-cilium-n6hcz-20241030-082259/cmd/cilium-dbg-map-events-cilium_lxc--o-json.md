{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:41.084Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.159.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:41.084Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.167.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:41.084Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:45.792Z",
  "value": "id=3686  sec_id=2200575 flags=0x0000 ifindex=12  mac=5A:9C:54:73:07:54 nodemac=72:11:EC:D0:A1:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:45.814Z",
  "value": "id=906   sec_id=4     flags=0x0000 ifindex=10  mac=7E:E0:D2:17:3D:64 nodemac=2E:13:62:9B:D1:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:45.865Z",
  "value": "id=2614  sec_id=2200575 flags=0x0000 ifindex=14  mac=C6:FB:CD:74:5A:A0 nodemac=36:3C:E3:29:30:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:45.936Z",
  "value": "id=3686  sec_id=2200575 flags=0x0000 ifindex=12  mac=5A:9C:54:73:07:54 nodemac=72:11:EC:D0:A1:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:46.021Z",
  "value": "id=906   sec_id=4     flags=0x0000 ifindex=10  mac=7E:E0:D2:17:3D:64 nodemac=2E:13:62:9B:D1:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:25.159Z",
  "value": "id=2614  sec_id=2200575 flags=0x0000 ifindex=14  mac=C6:FB:CD:74:5A:A0 nodemac=36:3C:E3:29:30:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:25.160Z",
  "value": "id=3686  sec_id=2200575 flags=0x0000 ifindex=12  mac=5A:9C:54:73:07:54 nodemac=72:11:EC:D0:A1:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:25.161Z",
  "value": "id=906   sec_id=4     flags=0x0000 ifindex=10  mac=7E:E0:D2:17:3D:64 nodemac=2E:13:62:9B:D1:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:25.191Z",
  "value": "id=260   sec_id=2218538 flags=0x0000 ifindex=16  mac=9E:7F:44:4C:D0:E0 nodemac=7A:CF:CB:08:1D:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:26.159Z",
  "value": "id=2614  sec_id=2200575 flags=0x0000 ifindex=14  mac=C6:FB:CD:74:5A:A0 nodemac=36:3C:E3:29:30:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:26.160Z",
  "value": "id=260   sec_id=2218538 flags=0x0000 ifindex=16  mac=9E:7F:44:4C:D0:E0 nodemac=7A:CF:CB:08:1D:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:26.160Z",
  "value": "id=906   sec_id=4     flags=0x0000 ifindex=10  mac=7E:E0:D2:17:3D:64 nodemac=2E:13:62:9B:D1:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:26.160Z",
  "value": "id=3686  sec_id=2200575 flags=0x0000 ifindex=12  mac=5A:9C:54:73:07:54 nodemac=72:11:EC:D0:A1:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:30.914Z",
  "value": "id=791   sec_id=2218538 flags=0x0000 ifindex=18  mac=9E:9B:02:84:75:CF nodemac=32:B8:46:ED:5C:E6"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.66.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.054Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:43.575Z",
  "value": "id=2614  sec_id=2200575 flags=0x0000 ifindex=14  mac=C6:FB:CD:74:5A:A0 nodemac=36:3C:E3:29:30:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:43.575Z",
  "value": "id=791   sec_id=2218538 flags=0x0000 ifindex=18  mac=9E:9B:02:84:75:CF nodemac=32:B8:46:ED:5C:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:43.576Z",
  "value": "id=3686  sec_id=2200575 flags=0x0000 ifindex=12  mac=5A:9C:54:73:07:54 nodemac=72:11:EC:D0:A1:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:43.577Z",
  "value": "id=906   sec_id=4     flags=0x0000 ifindex=10  mac=7E:E0:D2:17:3D:64 nodemac=2E:13:62:9B:D1:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:44.575Z",
  "value": "id=791   sec_id=2218538 flags=0x0000 ifindex=18  mac=9E:9B:02:84:75:CF nodemac=32:B8:46:ED:5C:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:44.576Z",
  "value": "id=906   sec_id=4     flags=0x0000 ifindex=10  mac=7E:E0:D2:17:3D:64 nodemac=2E:13:62:9B:D1:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:44.576Z",
  "value": "id=2614  sec_id=2200575 flags=0x0000 ifindex=14  mac=C6:FB:CD:74:5A:A0 nodemac=36:3C:E3:29:30:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:44.576Z",
  "value": "id=3686  sec_id=2200575 flags=0x0000 ifindex=12  mac=5A:9C:54:73:07:54 nodemac=72:11:EC:D0:A1:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:45.576Z",
  "value": "id=906   sec_id=4     flags=0x0000 ifindex=10  mac=7E:E0:D2:17:3D:64 nodemac=2E:13:62:9B:D1:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:45.576Z",
  "value": "id=3686  sec_id=2200575 flags=0x0000 ifindex=12  mac=5A:9C:54:73:07:54 nodemac=72:11:EC:D0:A1:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:45.576Z",
  "value": "id=791   sec_id=2218538 flags=0x0000 ifindex=18  mac=9E:9B:02:84:75:CF nodemac=32:B8:46:ED:5C:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:45.577Z",
  "value": "id=2614  sec_id=2200575 flags=0x0000 ifindex=14  mac=C6:FB:CD:74:5A:A0 nodemac=36:3C:E3:29:30:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:46.576Z",
  "value": "id=791   sec_id=2218538 flags=0x0000 ifindex=18  mac=9E:9B:02:84:75:CF nodemac=32:B8:46:ED:5C:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:46.577Z",
  "value": "id=3686  sec_id=2200575 flags=0x0000 ifindex=12  mac=5A:9C:54:73:07:54 nodemac=72:11:EC:D0:A1:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:46.577Z",
  "value": "id=906   sec_id=4     flags=0x0000 ifindex=10  mac=7E:E0:D2:17:3D:64 nodemac=2E:13:62:9B:D1:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:46.577Z",
  "value": "id=2614  sec_id=2200575 flags=0x0000 ifindex=14  mac=C6:FB:CD:74:5A:A0 nodemac=36:3C:E3:29:30:7F"
}

