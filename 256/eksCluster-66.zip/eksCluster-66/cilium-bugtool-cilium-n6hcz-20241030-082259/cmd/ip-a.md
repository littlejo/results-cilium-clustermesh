1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:8f:7f:70:37:3b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.159.51/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3334sec preferred_lft 3334sec
    inet6 fe80::48f:7fff:fe70:373b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:1c:29:15:40:df brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.167.175/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::41c:29ff:fe15:40df/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:7a:3d:89:af:b2 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::247a:3dff:fe89:afb2/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:75:0d:54:76:89 brd ff:ff:ff:ff:ff:ff
    inet 10.66.0.136/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::7475:dff:fe54:7689/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether da:e8:bb:62:92:6e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d8e8:bbff:fe62:926e/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:13:62:9b:d1:65 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::2c13:62ff:fe9b:d165/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc5496edc7545c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:11:ec:d0:a1:6d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::7011:ecff:fed0:a16d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc110b6767b0c8@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:3c:e3:29:30:7f brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::343c:e3ff:fe29:307f/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc559d7ead5c8f@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:b8:46:ed:5c:e6 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::30b8:46ff:feed:5ce6/64 scope link 
       valid_lft forever preferred_lft forever
