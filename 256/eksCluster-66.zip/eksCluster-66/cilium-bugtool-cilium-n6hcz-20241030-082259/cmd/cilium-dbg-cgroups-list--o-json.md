[
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode714d527_efd7_4f87_af51_8a3a22d25a30.slice/cri-containerd-729a679b26a83a83ee69a6e263375a974f45f175362725abf0437ae38e0def1e.scope"
      }
    ],
    "ips": [
      "10.66.0.92"
    ],
    "name": "coredns-cc6ccd49c-qlxgc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode8b9a5d1_a4d5_404d_8018_8c1a9cb7b34d.slice/cri-containerd-4d369ae6dacd0cbc377e3eadb1bfbe552bd52334ba5a0521506f8af8fc536712.scope"
      }
    ],
    "ips": [
      "10.66.0.225"
    ],
    "name": "coredns-cc6ccd49c-kbn5j",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9268,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17e57da0_4f49_41b5_93a4_5122a1ef6e50.slice/cri-containerd-d929f05edb7abed29c70e1f5b627b40a302bc1a717e1b093ec342ec0b69cc04e.scope"
      },
      {
        "cgroup-id": 9184,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17e57da0_4f49_41b5_93a4_5122a1ef6e50.slice/cri-containerd-94b1eb60ce778d5b480a8afc8eb41d52395866b799b0f1b02f9275c737cd6472.scope"
      },
      {
        "cgroup-id": 9352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17e57da0_4f49_41b5_93a4_5122a1ef6e50.slice/cri-containerd-ed06c2a1c50b302110c2c009b4ad62c4e7410ba35d5268ad1912f74541935e57.scope"
      }
    ],
    "ips": [
      "10.66.0.224"
    ],
    "name": "clustermesh-apiserver-8464788f56-qndqp",
    "namespace": "kube-system"
  }
]

