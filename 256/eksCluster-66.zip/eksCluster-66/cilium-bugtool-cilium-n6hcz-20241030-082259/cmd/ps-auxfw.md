USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         637  0.0  0.1 1240176 15984 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         659  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         660  0.0  0.0   3852  1296 ?        R    08:22   0:00  \_ bash -c hostname
root           1  3.0  4.7 1606208 381044 ?      Ssl  07:56   0:48 cilium-agent --config-dir=/tmp/cilium/config-map
root         403  0.0  0.1 1229744 8068 ?        Sl   07:56   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
