ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.129.126:443 (active)   
                                         2 => 172.31.222.167:443 (active)   
2    10.100.108.63:443    ClusterIP      1 => 172.31.159.51:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.66.0.92:53 (active)        
                                         2 => 10.66.0.225:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.66.0.92:9153 (active)      
                                         2 => 10.66.0.225:9153 (active)     
5    10.100.187.85:2379   ClusterIP      1 => 10.66.0.224:2379 (active)     
