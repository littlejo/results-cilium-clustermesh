CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode714d527_efd7_4f87_af51_8a3a22d25a30.slice/cri-containerd-729a679b26a83a83ee69a6e263375a974f45f175362725abf0437ae38e0def1e.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode714d527_efd7_4f87_af51_8a3a22d25a30.slice/cri-containerd-f0be5c2dfce1db9b09c0c8c1949ec1604063345b99278c9d59aca0a4206bb796.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode8b9a5d1_a4d5_404d_8018_8c1a9cb7b34d.slice/cri-containerd-4d369ae6dacd0cbc377e3eadb1bfbe552bd52334ba5a0521506f8af8fc536712.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode8b9a5d1_a4d5_404d_8018_8c1a9cb7b34d.slice/cri-containerd-527eeff439eb8b90d80aec72cdde8af6656969287e43091f8bc95f7d5608f7bd.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod483679bb_f332_4458_8d80_2da9a3c33938.slice/cri-containerd-0667d2b89bca4f7e4b2f79f9b32c03420ef2a1780a2c0fba2fa13cdfc4e7042d.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod483679bb_f332_4458_8d80_2da9a3c33938.slice/cri-containerd-0c7ff0f3b72d3d167fe8f349ce303fb39469e7c610852c295d829774b5700cb1.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6badda39_b3fb_4ebc_95ae_5db31e6ad9e8.slice/cri-containerd-40e5e99db1a863a29a3ac6a90978e101c02a0e67b623f18fa93d102a2da19c7c.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6badda39_b3fb_4ebc_95ae_5db31e6ad9e8.slice/cri-containerd-9391ec7c3453726b2d47649c3ee87aa767a281ee9e9420913815e9857bef0395.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod18f5ab33_b077_4462_bd21_d3c471f33436.slice/cri-containerd-dfe4d03064c32f137df005a9eda841e2c41f296277ee42e1770f2790e77711b6.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod18f5ab33_b077_4462_bd21_d3c471f33436.slice/cri-containerd-2bc035e9764d48184d687a9e2f847ce6bab1ef3c3a38bac07283932923b27090.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17e57da0_4f49_41b5_93a4_5122a1ef6e50.slice/cri-containerd-dd32bf2cf0a029c858b366b601df26353971f31dfbc4af4a95335c9283af6f1b.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17e57da0_4f49_41b5_93a4_5122a1ef6e50.slice/cri-containerd-ed06c2a1c50b302110c2c009b4ad62c4e7410ba35d5268ad1912f74541935e57.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17e57da0_4f49_41b5_93a4_5122a1ef6e50.slice/cri-containerd-d929f05edb7abed29c70e1f5b627b40a302bc1a717e1b093ec342ec0b69cc04e.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17e57da0_4f49_41b5_93a4_5122a1ef6e50.slice/cri-containerd-94b1eb60ce778d5b480a8afc8eb41d52395866b799b0f1b02f9275c737cd6472.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda7e253a5_cdc2_4484_b4e3_6fcc6ba5f3ff.slice/cri-containerd-5bd55d7edb7783767554ec0d4d8a74a0598305634d2ca43a0587ecf9544061cb.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda7e253a5_cdc2_4484_b4e3_6fcc6ba5f3ff.slice/cri-containerd-b06748ebf491b6539b4ff3a2a76d7027399de0c713394fb744d6f8dcb4af7977.scope
    105      cgroup_device   multi                                          
