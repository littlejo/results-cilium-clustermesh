Endpoint ID: 791
Path: /sys/fs/bpf/tc/globals/cilium_policy_00791

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    10530698   103805    0        
Allow    Ingress     1          ANY          NONE         disabled    8318325    86360     0        
Allow    Egress      0          ANY          NONE         disabled    9629415    98887     0        


Endpoint ID: 906
Path: /sys/fs/bpf/tc/globals/cilium_policy_00906

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1602880   20275     0        
Allow    Ingress     1          ANY          NONE         disabled    22442     261       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2104
Path: /sys/fs/bpf/tc/globals/cilium_policy_02104

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2614
Path: /sys/fs/bpf/tc/globals/cilium_policy_02614

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    151464   1746      0        
Allow    Egress      0          ANY          NONE         disabled    19971    222       0        


Endpoint ID: 3686
Path: /sys/fs/bpf/tc/globals/cilium_policy_03686

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    151841   1747      0        
Allow    Egress      0          ANY          NONE         disabled    19278    213       0        


