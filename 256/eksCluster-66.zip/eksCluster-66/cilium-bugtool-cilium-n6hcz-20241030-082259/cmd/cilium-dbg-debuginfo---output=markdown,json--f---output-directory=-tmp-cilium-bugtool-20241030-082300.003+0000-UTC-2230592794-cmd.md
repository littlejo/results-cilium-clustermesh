markdown output at /tmp/cilium-bugtool-20241030-082300.003+0000-UTC-2230592794/cmd/cilium-debuginfo-20241030-082302.724+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082300.003+0000-UTC-2230592794/cmd/cilium-debuginfo-20241030-082302.724+0000-UTC.json
