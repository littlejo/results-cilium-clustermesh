filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc110b6767b0c8 direct-action not_in_hw id 519 tag d64c2b4c7be72ebb jited 
