key: 17 03 00 00  value: 78 02 00 00
key: 8a 03 00 00  value: 23 02 00 00
key: 36 0a 00 00  value: ff 01 00 00
key: 66 0e 00 00  value: 17 02 00 00
Found 4 elements
