xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 577
ens6(5) clsact/ingress cil_from_netdev-ens6 id 582
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 570
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 564
cilium_host(7) clsact/egress cil_from_host-cilium_host id 562
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 536
lxc5496edc7545c(12) clsact/ingress cil_from_container-lxc5496edc7545c id 528
lxc110b6767b0c8(14) clsact/ingress cil_from_container-lxc110b6767b0c8 id 519
lxc559d7ead5c8f(18) clsact/ingress cil_from_container-lxc559d7ead5c8f id 630

flow_dissector:

netfilter:

