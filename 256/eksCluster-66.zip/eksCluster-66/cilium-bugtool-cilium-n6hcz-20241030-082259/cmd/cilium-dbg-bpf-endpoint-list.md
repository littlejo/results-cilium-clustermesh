IP ADDRESS         LOCAL ENDPOINT INFO
10.66.0.224:0      id=791   sec_id=2218538 flags=0x0000 ifindex=18  mac=9E:9B:02:84:75:CF nodemac=32:B8:46:ED:5C:E6   
10.66.0.92:0       id=2614  sec_id=2200575 flags=0x0000 ifindex=14  mac=C6:FB:CD:74:5A:A0 nodemac=36:3C:E3:29:30:7F   
10.66.0.136:0      (localhost)                                                                                        
172.31.167.175:0   (localhost)                                                                                        
10.66.0.225:0      id=3686  sec_id=2200575 flags=0x0000 ifindex=12  mac=5A:9C:54:73:07:54 nodemac=72:11:EC:D0:A1:6D   
172.31.159.51:0    (localhost)                                                                                        
10.66.0.226:0      id=906   sec_id=4     flags=0x0000 ifindex=10  mac=7E:E0:D2:17:3D:64 nodemac=2E:13:62:9B:D1:65     
