ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.128.209:443 (active)   
                                         2 => 172.31.245.250:443 (active)   
2    10.100.172.215:443   ClusterIP      1 => 172.31.242.15:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.179.0.108:53 (active)      
                                         2 => 10.179.0.230:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.179.0.108:9153 (active)    
                                         2 => 10.179.0.230:9153 (active)    
5    10.100.203.11:2379   ClusterIP      1 => 10.179.0.75:2379 (active)     
