IP ADDRESS         LOCAL ENDPOINT INFO
10.179.0.108:0     id=2402  sec_id=5921965 flags=0x0000 ifindex=12  mac=8A:BC:DE:DE:AB:DF nodemac=66:74:5D:7B:87:83   
172.31.192.220:0   (localhost)                                                                                        
10.179.0.191:0     (localhost)                                                                                        
10.179.0.230:0     id=545   sec_id=5921965 flags=0x0000 ifindex=14  mac=72:1B:7A:33:C8:39 nodemac=62:D0:0B:C5:E8:13   
172.31.242.15:0    (localhost)                                                                                        
10.179.0.75:0      id=234   sec_id=5927497 flags=0x0000 ifindex=18  mac=D2:BA:EF:08:47:5C nodemac=A2:6C:37:4B:08:C3   
10.179.0.91:0      id=963   sec_id=4     flags=0x0000 ifindex=10  mac=4E:F9:D7:3B:B6:67 nodemac=82:2C:4E:FF:6A:39     
