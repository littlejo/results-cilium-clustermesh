KEY             VALUE
AgentLiveness   1919587759083
UTimeOffset     3379442738281250
