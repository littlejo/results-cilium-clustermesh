key: ea 00 00 00  value: 87 02 00 00
key: 21 02 00 00  value: 3b 02 00 00
key: c3 03 00 00  value: 42 02 00 00
key: 62 09 00 00  value: 16 02 00 00
Found 4 elements
