top - 08:22:51 up 31 min,  0 users,  load average: 0.26, 0.19, 0.15
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 25.0 us, 37.5 sy,  0.0 ni, 37.5 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4510.9 free,   1187.1 used,   2116.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6442.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    612 root      20   0 1240432  15568  10768 S  13.3   0.2   0:00.03 cilium-+
      1 root      20   0 1606080 386264  79364 S   0.0   4.8   0:40.44 cilium-+
    394 root      20   0 1229744   8016   3836 S   0.0   0.1   0:01.09 cilium-+
    631 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    665 root      20   0    6576   2424   2100 R   0.0   0.0   0:00.00 top
    702 root      20   0 1228744   3716   3040 S   0.0   0.0   0:00.00 gops
