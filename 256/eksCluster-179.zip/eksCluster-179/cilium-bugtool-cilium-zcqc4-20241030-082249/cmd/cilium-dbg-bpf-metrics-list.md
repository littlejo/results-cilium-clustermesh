REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35475     2802310     677    bpf_overlay.c
Interface                 INGRESS     621680    128987299   1132   bpf_host.c
Success                   EGRESS      15339     1202656     1694   bpf_host.c
Success                   EGRESS      259001    32968062    1308   bpf_lxc.c
Success                   EGRESS      34943     2765649     53     encap.h
Success                   INGRESS     302717    33931232    86     l3.h
Success                   INGRESS     323504    35574932    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
