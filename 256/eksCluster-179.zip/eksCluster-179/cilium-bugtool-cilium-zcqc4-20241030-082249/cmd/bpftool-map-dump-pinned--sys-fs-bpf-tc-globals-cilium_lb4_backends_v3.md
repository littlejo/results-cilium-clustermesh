key: 05 00 00 00  value: ac 1f f2 0f 10 94 00 00  00 00 00 00
key: 08 00 00 00  value: 0a b3 00 e6 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f f5 fa 01 bb 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 80 d1 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: 0a b3 00 6c 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a b3 00 4b 09 4b 00 00  00 00 00 00
key: 09 00 00 00  value: 0a b3 00 e6 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a b3 00 6c 00 35 00 00  00 00 00 00
Found 8 elements
