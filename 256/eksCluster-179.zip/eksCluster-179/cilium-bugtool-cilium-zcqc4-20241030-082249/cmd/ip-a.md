1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:1b:e8:2b:31:37 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.242.15/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3521sec preferred_lft 3521sec
    inet6 fe80::81b:e8ff:fe2b:3137/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:5c:2e:27:30:5f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.192.220/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::85c:2eff:fe27:305f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:33:be:51:9d:27 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f833:beff:fe51:9d27/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:2b:53:ce:0e:a1 brd ff:ff:ff:ff:ff:ff
    inet 10.179.0.191/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::182b:53ff:fece:ea1/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f2:92:92:4a:7f:f3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f092:92ff:fe4a:7ff3/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:2c:4e:ff:6a:39 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::802c:4eff:feff:6a39/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcfb10f4ea9338@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:74:5d:7b:87:83 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::6474:5dff:fe7b:8783/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc5756ba18d5d4@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:d0:0b:c5:e8:13 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::60d0:bff:fec5:e813/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf65c07b6aab8@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:6c:37:4b:08:c3 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a06c:37ff:fe4b:8c3/64 scope link 
       valid_lft forever preferred_lft forever
