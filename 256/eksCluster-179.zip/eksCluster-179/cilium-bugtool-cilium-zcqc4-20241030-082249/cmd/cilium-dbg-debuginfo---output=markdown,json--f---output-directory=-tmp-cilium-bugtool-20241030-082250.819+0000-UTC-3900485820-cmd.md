markdown output at /tmp/cilium-bugtool-20241030-082250.819+0000-UTC-3900485820/cmd/cilium-debuginfo-20241030-082322.008+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082250.819+0000-UTC-3900485820/cmd/cilium-debuginfo-20241030-082322.008+0000-UTC.json
