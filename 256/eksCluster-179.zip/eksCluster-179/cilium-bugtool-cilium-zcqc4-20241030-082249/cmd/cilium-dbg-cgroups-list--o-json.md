[
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40d813c5_054e_4274_9b69_88e3311208f7.slice/cri-containerd-05d52e33344c2b1bf12d065868e434d01ffd5c3601fe0779359b8ed9c196cbfb.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40d813c5_054e_4274_9b69_88e3311208f7.slice/cri-containerd-2d6b7c13af3d02e70acad6b715c863f0352dfc522259ca2f784d9b7b6341c2a5.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40d813c5_054e_4274_9b69_88e3311208f7.slice/cri-containerd-3285bcd12274bad5dad25a9536ab0ce764ffceaeaf30e132ba47274ce514c68e.scope"
      }
    ],
    "ips": [
      "10.179.0.75"
    ],
    "name": "clustermesh-apiserver-95d69cf57-4p45p",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6256f6bc_cd85_47ab_a696_8732c98a578d.slice/cri-containerd-280da6001880d73e4d91ddbaa69b2105f750dadf0ec62e44940460a862e8039f.scope"
      }
    ],
    "ips": [
      "10.179.0.230"
    ],
    "name": "coredns-cc6ccd49c-mb86b",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod286a0a7e_45b4_408c_a687_24872ebd3657.slice/cri-containerd-8004f7128e3d75e8f1af5f221e8a0cff42132a23f8f25b487cddb806369198bb.scope"
      }
    ],
    "ips": [
      "10.179.0.108"
    ],
    "name": "coredns-cc6ccd49c-sn5xb",
    "namespace": "kube-system"
  }
]

