{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.028Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.192.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.029Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.242.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.029Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:46.677Z",
  "value": "id=963   sec_id=4     flags=0x0000 ifindex=10  mac=4E:F9:D7:3B:B6:67 nodemac=82:2C:4E:FF:6A:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:46.687Z",
  "value": "id=2402  sec_id=5921965 flags=0x0000 ifindex=12  mac=8A:BC:DE:DE:AB:DF nodemac=66:74:5D:7B:87:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:46.722Z",
  "value": "id=545   sec_id=5921965 flags=0x0000 ifindex=14  mac=72:1B:7A:33:C8:39 nodemac=62:D0:0B:C5:E8:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:46.754Z",
  "value": "id=963   sec_id=4     flags=0x0000 ifindex=10  mac=4E:F9:D7:3B:B6:67 nodemac=82:2C:4E:FF:6A:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:44.802Z",
  "value": "id=2402  sec_id=5921965 flags=0x0000 ifindex=12  mac=8A:BC:DE:DE:AB:DF nodemac=66:74:5D:7B:87:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:44.803Z",
  "value": "id=545   sec_id=5921965 flags=0x0000 ifindex=14  mac=72:1B:7A:33:C8:39 nodemac=62:D0:0B:C5:E8:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:44.803Z",
  "value": "id=963   sec_id=4     flags=0x0000 ifindex=10  mac=4E:F9:D7:3B:B6:67 nodemac=82:2C:4E:FF:6A:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:44.833Z",
  "value": "id=150   sec_id=5927497 flags=0x0000 ifindex=16  mac=CE:9B:29:A8:32:38 nodemac=DE:CE:DC:6C:E8:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:45.803Z",
  "value": "id=150   sec_id=5927497 flags=0x0000 ifindex=16  mac=CE:9B:29:A8:32:38 nodemac=DE:CE:DC:6C:E8:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:45.803Z",
  "value": "id=545   sec_id=5921965 flags=0x0000 ifindex=14  mac=72:1B:7A:33:C8:39 nodemac=62:D0:0B:C5:E8:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:45.803Z",
  "value": "id=2402  sec_id=5921965 flags=0x0000 ifindex=12  mac=8A:BC:DE:DE:AB:DF nodemac=66:74:5D:7B:87:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:45.803Z",
  "value": "id=963   sec_id=4     flags=0x0000 ifindex=10  mac=4E:F9:D7:3B:B6:67 nodemac=82:2C:4E:FF:6A:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.220Z",
  "value": "id=234   sec_id=5927497 flags=0x0000 ifindex=18  mac=D2:BA:EF:08:47:5C nodemac=A2:6C:37:4B:08:C3"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.179.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.582Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.661Z",
  "value": "id=234   sec_id=5927497 flags=0x0000 ifindex=18  mac=D2:BA:EF:08:47:5C nodemac=A2:6C:37:4B:08:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.662Z",
  "value": "id=963   sec_id=4     flags=0x0000 ifindex=10  mac=4E:F9:D7:3B:B6:67 nodemac=82:2C:4E:FF:6A:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.662Z",
  "value": "id=2402  sec_id=5921965 flags=0x0000 ifindex=12  mac=8A:BC:DE:DE:AB:DF nodemac=66:74:5D:7B:87:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.662Z",
  "value": "id=545   sec_id=5921965 flags=0x0000 ifindex=14  mac=72:1B:7A:33:C8:39 nodemac=62:D0:0B:C5:E8:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.766Z",
  "value": "id=234   sec_id=5927497 flags=0x0000 ifindex=18  mac=D2:BA:EF:08:47:5C nodemac=A2:6C:37:4B:08:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.770Z",
  "value": "id=963   sec_id=4     flags=0x0000 ifindex=10  mac=4E:F9:D7:3B:B6:67 nodemac=82:2C:4E:FF:6A:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.770Z",
  "value": "id=2402  sec_id=5921965 flags=0x0000 ifindex=12  mac=8A:BC:DE:DE:AB:DF nodemac=66:74:5D:7B:87:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.771Z",
  "value": "id=545   sec_id=5921965 flags=0x0000 ifindex=14  mac=72:1B:7A:33:C8:39 nodemac=62:D0:0B:C5:E8:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.663Z",
  "value": "id=234   sec_id=5927497 flags=0x0000 ifindex=18  mac=D2:BA:EF:08:47:5C nodemac=A2:6C:37:4B:08:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.664Z",
  "value": "id=963   sec_id=4     flags=0x0000 ifindex=10  mac=4E:F9:D7:3B:B6:67 nodemac=82:2C:4E:FF:6A:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.664Z",
  "value": "id=2402  sec_id=5921965 flags=0x0000 ifindex=12  mac=8A:BC:DE:DE:AB:DF nodemac=66:74:5D:7B:87:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.664Z",
  "value": "id=545   sec_id=5921965 flags=0x0000 ifindex=14  mac=72:1B:7A:33:C8:39 nodemac=62:D0:0B:C5:E8:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.664Z",
  "value": "id=234   sec_id=5927497 flags=0x0000 ifindex=18  mac=D2:BA:EF:08:47:5C nodemac=A2:6C:37:4B:08:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.664Z",
  "value": "id=963   sec_id=4     flags=0x0000 ifindex=10  mac=4E:F9:D7:3B:B6:67 nodemac=82:2C:4E:FF:6A:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.664Z",
  "value": "id=2402  sec_id=5921965 flags=0x0000 ifindex=12  mac=8A:BC:DE:DE:AB:DF nodemac=66:74:5D:7B:87:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.179.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.664Z",
  "value": "id=545   sec_id=5921965 flags=0x0000 ifindex=14  mac=72:1B:7A:33:C8:39 nodemac=62:D0:0B:C5:E8:13"
}

