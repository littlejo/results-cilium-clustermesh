CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddf2e224b_822d_446a_849e_252d8f9602d7.slice/cri-containerd-1685381c12756f15c37f91b4d53079b436013edb0b4a23632e48320f68ca1696.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddf2e224b_822d_446a_849e_252d8f9602d7.slice/cri-containerd-10096558f996e29456c8bccf34af1e94a7e5e6e02d12136d3680cb2ae9b6581e.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod174ae7e4_7cba_407b_bf35_d784db43548b.slice/cri-containerd-32124b27104661fa49d68f2387c781ad611048c21fbb5720c77deecd69569f50.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod174ae7e4_7cba_407b_bf35_d784db43548b.slice/cri-containerd-446cf8767e054ababc8a78c3ca6e2eb2cab2a537d5c509ccb87cf4476655bf97.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6256f6bc_cd85_47ab_a696_8732c98a578d.slice/cri-containerd-280da6001880d73e4d91ddbaa69b2105f750dadf0ec62e44940460a862e8039f.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6256f6bc_cd85_47ab_a696_8732c98a578d.slice/cri-containerd-b35667bb5992c4b2b61d9d63f0499efd381c14054937a8421d07c186248012c6.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod286a0a7e_45b4_408c_a687_24872ebd3657.slice/cri-containerd-8004f7128e3d75e8f1af5f221e8a0cff42132a23f8f25b487cddb806369198bb.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod286a0a7e_45b4_408c_a687_24872ebd3657.slice/cri-containerd-611deaac1173b4f9daccb1aa60909ba32e082cc954dc810e2f6a6fbfd3a89b7a.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61a3b7dd_c33c_4262_bc6f_b03e24a963b6.slice/cri-containerd-ccd5694c39188c487daefda5109b4582e34bb1566a72d4d2be96cc4ef1f3a840.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61a3b7dd_c33c_4262_bc6f_b03e24a963b6.slice/cri-containerd-e4b9fec3200ab04fb6cecee207ea7f6c11f89eeea357a3eb589524abeba8ce14.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40d813c5_054e_4274_9b69_88e3311208f7.slice/cri-containerd-05d52e33344c2b1bf12d065868e434d01ffd5c3601fe0779359b8ed9c196cbfb.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40d813c5_054e_4274_9b69_88e3311208f7.slice/cri-containerd-2d6b7c13af3d02e70acad6b715c863f0352dfc522259ca2f784d9b7b6341c2a5.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40d813c5_054e_4274_9b69_88e3311208f7.slice/cri-containerd-3285bcd12274bad5dad25a9536ab0ce764ffceaeaf30e132ba47274ce514c68e.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40d813c5_054e_4274_9b69_88e3311208f7.slice/cri-containerd-9aef57991548d2a6e836b38007f74b75bc8606983d124eb86f9e68a47cae4c0a.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a7297f4_556d_4019_84ea_e5409887a2f1.slice/cri-containerd-f5f00675fd21d75a8702cca71bd54e57bf074ca33c37308040ca83b9fdd4801b.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a7297f4_556d_4019_84ea_e5409887a2f1.slice/cri-containerd-702c3ff4a22f05ff3ebec7b84dd568605f826120f3cacfdd8e37b0a431190969.scope
    107      cgroup_device   multi                                          
