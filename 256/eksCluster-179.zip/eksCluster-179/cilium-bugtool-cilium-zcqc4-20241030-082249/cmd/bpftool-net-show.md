xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 553
ens6(5) clsact/ingress cil_from_netdev-ens6 id 563
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 551
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 539
cilium_host(7) clsact/egress cil_from_host-cilium_host id 542
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 478
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 574
lxcfb10f4ea9338(12) clsact/ingress cil_from_container-lxcfb10f4ea9338 id 527
lxc5756ba18d5d4(14) clsact/ingress cil_from_container-lxc5756ba18d5d4 id 530
lxcf65c07b6aab8(18) clsact/ingress cil_from_container-lxcf65c07b6aab8 id 642

flow_dissector:

netfilter:

