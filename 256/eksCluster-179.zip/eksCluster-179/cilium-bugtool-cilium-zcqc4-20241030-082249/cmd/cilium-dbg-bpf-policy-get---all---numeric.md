Endpoint ID: 234
Path: /sys/fs/bpf/tc/globals/cilium_policy_00234

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11314391   111172    0        
Allow    Ingress     1          ANY          NONE         disabled    9424720    98858     0        
Allow    Egress      0          ANY          NONE         disabled    11197222   111147    0        


Endpoint ID: 245
Path: /sys/fs/bpf/tc/globals/cilium_policy_00245

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 545
Path: /sys/fs/bpf/tc/globals/cilium_policy_00545

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    121915   1393      0        
Allow    Egress      0          ANY          NONE         disabled    16824    182       0        


Endpoint ID: 963
Path: /sys/fs/bpf/tc/globals/cilium_policy_00963

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1648952   20856     0        
Allow    Ingress     1          ANY          NONE         disabled    18632     218       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2402
Path: /sys/fs/bpf/tc/globals/cilium_policy_02402

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    123235   1413      0        
Allow    Egress      0          ANY          NONE         disabled    17491    191       0        


