alloc: 186.20MB (195244664 bytes)
total-alloc: 2.16GB (2324393464 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 62299060
frees: 60142837
heap-alloc: 186.20MB (195244664 bytes)
heap-sys: 243.64MB (255475712 bytes)
heap-idle: 34.39MB (36061184 bytes)
heap-in-use: 209.25MB (219414528 bytes)
heap-released: 5.80MB (6078464 bytes)
heap-objects: 2156223
stack-in-use: 64.31MB (67436544 bytes)
stack-sys: 64.31MB (67436544 bytes)
stack-mspan-inuse: 3.51MB (3676640 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 980.95KB (1004497 bytes)
gc-sys: 6.03MB (6325808 bytes)
next-gc: when heap-alloc >= 208.15MB (218257976 bytes)
last-gc: 2024-10-30 08:22:46.243572275 +0000 UTC
gc-pause-total: 22.248967ms
gc-pause: 96986
gc-pause-end: 1730276566243572275
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0004534458432066764
enable-gc: true
debug-gc: false
