ip-172-31-242-15.eu-west-3.compute.internal
