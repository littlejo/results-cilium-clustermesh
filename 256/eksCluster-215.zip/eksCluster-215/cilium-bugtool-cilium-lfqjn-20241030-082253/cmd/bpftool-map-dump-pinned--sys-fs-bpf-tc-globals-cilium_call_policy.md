key: f5 00 00 00  value: 13 02 00 00
key: f1 04 00 00  value: 21 02 00 00
key: bf 07 00 00  value: 6b 02 00 00
key: f8 08 00 00  value: 20 02 00 00
Found 4 elements
