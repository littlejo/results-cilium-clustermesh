KEY             VALUE
AgentLiveness   1873266527797
UTimeOffset     3379442835937500
