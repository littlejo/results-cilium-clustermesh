 08:22:54 up 30 min,  0 users,  load average: 0.29, 0.18, 0.12
