[
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod167355b4_0c04_42dd_9453_99ad27ac587b.slice/cri-containerd-7ad262f6bf838afe8774856661199814e36241339f7fd796274c2e84d60b8b11.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod167355b4_0c04_42dd_9453_99ad27ac587b.slice/cri-containerd-2209ee81591b26412a2d7741056b22dea6e6456d7134c703ae1a4bf52cea8b0f.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod167355b4_0c04_42dd_9453_99ad27ac587b.slice/cri-containerd-a67cf1c1423042524208b46ecd58e69ddcdc5d92d107ecc83051e00029ee67e5.scope"
      }
    ],
    "ips": [
      "10.215.0.178"
    ],
    "name": "clustermesh-apiserver-cc8456bf7-ckxz8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod32054778_5d6c_46eb_a6bb_b4dfb957d515.slice/cri-containerd-ccbd750ed9bd9b9e681a1e564c689dbc45f9df74996b610b2b8fe6c9514eb297.scope"
      }
    ],
    "ips": [
      "10.215.0.141"
    ],
    "name": "coredns-cc6ccd49c-h8w9l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod57c39869_cd38_4d70_aac5_e1bb285b95fb.slice/cri-containerd-45ece9a2c7c50adc4077c6724c6eafd0c165f8064eda6e982bd29861ebc726f2.scope"
      }
    ],
    "ips": [
      "10.215.0.71"
    ],
    "name": "coredns-cc6ccd49c-xlgcm",
    "namespace": "kube-system"
  }
]

