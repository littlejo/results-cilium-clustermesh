CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod57c39869_cd38_4d70_aac5_e1bb285b95fb.slice/cri-containerd-0d14824606de991582894a92939e34663162f4eba4ea15f91f5e757cd14d4957.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod57c39869_cd38_4d70_aac5_e1bb285b95fb.slice/cri-containerd-45ece9a2c7c50adc4077c6724c6eafd0c165f8064eda6e982bd29861ebc726f2.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda5467396_f0fd_4b77_a3c2_0246b01d57a9.slice/cri-containerd-1d34050caf4556bd8e11b31a65f111650a5d1037b8436a370833e45f063260d5.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda5467396_f0fd_4b77_a3c2_0246b01d57a9.slice/cri-containerd-e44a447926ecb3be04d540e263579c01ca0b130677beacaf358eb4ab5e684bc8.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod32054778_5d6c_46eb_a6bb_b4dfb957d515.slice/cri-containerd-aab04ca8acb3d273f54feeadf16ad6b819cfb6e296f9dcf44f93c2bc0ade5a2f.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod32054778_5d6c_46eb_a6bb_b4dfb957d515.slice/cri-containerd-ccbd750ed9bd9b9e681a1e564c689dbc45f9df74996b610b2b8fe6c9514eb297.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod558643fd_ffbb_460f_aac8_8a747d796558.slice/cri-containerd-c6cd1e11badef5e4f603f932b6ff15a141ba405f206c7a01c2db6246100ed679.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod558643fd_ffbb_460f_aac8_8a747d796558.slice/cri-containerd-cf86fadb83149b346d3cfab80e43a05d899ba66d334c64d440fbb8eb91851811.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod167355b4_0c04_42dd_9453_99ad27ac587b.slice/cri-containerd-2209ee81591b26412a2d7741056b22dea6e6456d7134c703ae1a4bf52cea8b0f.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod167355b4_0c04_42dd_9453_99ad27ac587b.slice/cri-containerd-d9a81704cccbeee171bd832b8f65fc0731c3c84021cfa151a112e1f8f24914d7.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod167355b4_0c04_42dd_9453_99ad27ac587b.slice/cri-containerd-a67cf1c1423042524208b46ecd58e69ddcdc5d92d107ecc83051e00029ee67e5.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod167355b4_0c04_42dd_9453_99ad27ac587b.slice/cri-containerd-7ad262f6bf838afe8774856661199814e36241339f7fd796274c2e84d60b8b11.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod823322b1_93b7_4970_b125_f7ab98c8dd26.slice/cri-containerd-4c924ee480c0f621017d1eff49b094b44c323ddc2dc0eaed99ad2ebad2eeb8b7.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod823322b1_93b7_4970_b125_f7ab98c8dd26.slice/cri-containerd-bc5b5f070ae3251a70efcd31ec9e6544404bb4d32ec770e7bdef3775233dce24.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod622bd537_fe25_4449_80cd_db13bb78a0c1.slice/cri-containerd-a3831a6b72059db0c4acf7b9d07dd62e6810e775d1fce259fdb83c2021d497ba.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod622bd537_fe25_4449_80cd_db13bb78a0c1.slice/cri-containerd-a4b4d2ebcf33f2bd64d00ff1ad5dd4b786bbc9fe7855afec0398dcbd49fdadde.scope
    91       cgroup_device   multi                                          
