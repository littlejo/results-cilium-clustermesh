REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34080     2692227     677    bpf_overlay.c
Interface                 INGRESS     610426    127780842   1132   bpf_host.c
Success                   EGRESS      13789     1080871     1694   bpf_host.c
Success                   EGRESS      253982    32381393    1308   bpf_lxc.c
Success                   EGRESS      32634     2589253     53     encap.h
Success                   INGRESS     292441    32878969    86     l3.h
Success                   INGRESS     313383    34534371    235    trace.h
Unsupported L3 protocol   EGRESS      43        3222        1492   bpf_lxc.c
