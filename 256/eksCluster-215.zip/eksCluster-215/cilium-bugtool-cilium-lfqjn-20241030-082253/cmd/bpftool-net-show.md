xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 501
ens6(5) clsact/ingress cil_from_netdev-ens6 id 503
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 495
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 484
cilium_host(7) clsact/egress cil_from_host-cilium_host id 482
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 535
lxce7981debf65b(12) clsact/ingress cil_from_container-lxce7981debf65b id 510
lxc48989d0b1fcc(14) clsact/ingress cil_from_container-lxc48989d0b1fcc id 548
lxcf72a336e2a65(18) clsact/ingress cil_from_container-lxcf72a336e2a65 id 612

flow_dissector:

netfilter:

