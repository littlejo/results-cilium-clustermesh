top - 08:22:54 up 30 min,  0 users,  load average: 0.29, 0.18, 0.12
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 56.7 us, 36.7 sy,  0.0 ni,  3.3 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4486.0 free,   1182.9 used,   2145.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6446.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 390732  80120 S  66.7   4.9   0:42.69 cilium-+
    673 root      20   0 1240432  16528  11356 S   6.7   0.2   0:00.03 cilium-+
    396 root      20   0 1229744   8264   4028 S   0.0   0.1   0:01.15 cilium-+
    615 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    639 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    661 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    710 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    722 root      20   0    2208    792    716 S   0.0   0.0   0:00.00 timeout
    733 root      20   0 1243764  17632  12924 S   0.0   0.2   0:00.00 hubble
    747 root      20   0 1229000   4016   3356 S   0.0   0.1   0:00.00 gops
