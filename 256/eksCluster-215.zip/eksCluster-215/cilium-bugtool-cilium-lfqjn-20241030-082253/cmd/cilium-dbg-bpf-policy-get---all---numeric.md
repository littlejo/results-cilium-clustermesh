Endpoint ID: 245
Path: /sys/fs/bpf/tc/globals/cilium_policy_00245

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    120412   1381      0        
Allow    Egress      0          ANY          NONE         disabled    16109    175       0        


Endpoint ID: 483
Path: /sys/fs/bpf/tc/globals/cilium_policy_00483

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1265
Path: /sys/fs/bpf/tc/globals/cilium_policy_01265

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    119967   1378      0        
Allow    Egress      0          ANY          NONE         disabled    16942    185       0        


Endpoint ID: 1983
Path: /sys/fs/bpf/tc/globals/cilium_policy_01983

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11216641   109430    0        
Allow    Ingress     1          ANY          NONE         disabled    8578326    89265     0        
Allow    Egress      0          ANY          NONE         disabled    10634617   106188    0        


Endpoint ID: 2296
Path: /sys/fs/bpf/tc/globals/cilium_policy_02296

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1658252   20979     0        
Allow    Ingress     1          ANY          NONE         disabled    18830     221       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


