Total: 674
TCP:   1857 (estab 435, closed 1403, orphaned 0, timewait 558)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  454       443       11       
INET	  464       449       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.248.161%ens5:68         0.0.0.0:*    uid:192 ino:75690 sk:3ea cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:36303 sk:3eb cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:45375      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:35467 sk:3ec fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15426 sk:3ed cgroup:unreachable:f0c <->                                    
UNCONN 0      0      [fe80::83f:d8ff:fe80:c40d]%ens5:546           [::]:*    uid:192 ino:15646 sk:3ee cgroup:unreachable:c4e v6only:1 <->                   
UNCONN 0      0                                 [::]:8472          [::]:*    ino:36302 sk:3ef cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15427 sk:3f0 cgroup:unreachable:f0c v6only:1 <->                           
