ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.180.121:443 (active)    
                                          2 => 172.31.216.80:443 (active)     
2    10.100.246.65:443     ClusterIP      1 => 172.31.248.161:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.215.0.141:53 (active)       
                                          2 => 10.215.0.71:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.215.0.141:9153 (active)     
                                          2 => 10.215.0.71:9153 (active)      
5    10.100.112.237:2379   ClusterIP      1 => 10.215.0.178:2379 (active)     
