alloc: 174.72MB (183211592 bytes)
total-alloc: 2.12GB (2271569832 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 61276687
frees: 59211102
heap-alloc: 174.72MB (183211592 bytes)
heap-sys: 251.20MB (263397376 bytes)
heap-idle: 54.12MB (56745984 bytes)
heap-in-use: 197.08MB (206651392 bytes)
heap-released: 5.66MB (5931008 bytes)
heap-objects: 2065585
stack-in-use: 64.78MB (67928064 bytes)
stack-sys: 64.78MB (67928064 bytes)
stack-mspan-inuse: 3.38MB (3545440 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.22MB (1275657 bytes)
gc-sys: 5.99MB (6284752 bytes)
next-gc: when heap-alloc >= 212.16MB (222463080 bytes)
last-gc: 2024-10-30 08:22:56.819168722 +0000 UTC
gc-pause-total: 13.699023ms
gc-pause: 3346632
gc-pause-end: 1730276576819168722
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005220913685553248
enable-gc: true
debug-gc: false
