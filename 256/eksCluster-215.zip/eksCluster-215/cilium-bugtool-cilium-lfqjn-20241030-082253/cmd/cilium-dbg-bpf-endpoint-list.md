IP ADDRESS         LOCAL ENDPOINT INFO
172.31.248.161:0   (localhost)                                                                                        
10.215.0.187:0     (localhost)                                                                                        
172.31.218.254:0   (localhost)                                                                                        
10.215.0.41:0      id=2296  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E0:7A:F4:64:69 nodemac=E6:F7:4B:EC:2B:39     
10.215.0.141:0     id=245   sec_id=7079208 flags=0x0000 ifindex=12  mac=A6:D8:5B:5C:E0:AA nodemac=02:80:23:CE:8E:FA   
10.215.0.71:0      id=1265  sec_id=7079208 flags=0x0000 ifindex=14  mac=EA:7B:49:1E:18:AA nodemac=BA:03:B0:66:15:00   
10.215.0.178:0     id=1983  sec_id=7090583 flags=0x0000 ifindex=18  mac=02:9E:1D:34:41:05 nodemac=36:82:4C:00:F8:C7   
