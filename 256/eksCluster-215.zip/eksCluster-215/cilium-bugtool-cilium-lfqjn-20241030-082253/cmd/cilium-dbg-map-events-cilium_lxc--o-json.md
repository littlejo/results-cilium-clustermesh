{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:19.704Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.218.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:19.704Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.248.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:19.704Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:24.311Z",
  "value": "id=2296  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E0:7A:F4:64:69 nodemac=E6:F7:4B:EC:2B:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:24.313Z",
  "value": "id=245   sec_id=7079208 flags=0x0000 ifindex=12  mac=A6:D8:5B:5C:E0:AA nodemac=02:80:23:CE:8E:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:24.348Z",
  "value": "id=2296  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E0:7A:F4:64:69 nodemac=E6:F7:4B:EC:2B:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:24.349Z",
  "value": "id=245   sec_id=7079208 flags=0x0000 ifindex=12  mac=A6:D8:5B:5C:E0:AA nodemac=02:80:23:CE:8E:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:24.369Z",
  "value": "id=1265  sec_id=7079208 flags=0x0000 ifindex=14  mac=EA:7B:49:1E:18:AA nodemac=BA:03:B0:66:15:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:22.997Z",
  "value": "id=2296  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E0:7A:F4:64:69 nodemac=E6:F7:4B:EC:2B:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:22.997Z",
  "value": "id=245   sec_id=7079208 flags=0x0000 ifindex=12  mac=A6:D8:5B:5C:E0:AA nodemac=02:80:23:CE:8E:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:22.997Z",
  "value": "id=1265  sec_id=7079208 flags=0x0000 ifindex=14  mac=EA:7B:49:1E:18:AA nodemac=BA:03:B0:66:15:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:23.027Z",
  "value": "id=959   sec_id=7090583 flags=0x0000 ifindex=16  mac=9A:9C:34:2A:E5:18 nodemac=7E:02:A6:23:E6:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:23.027Z",
  "value": "id=959   sec_id=7090583 flags=0x0000 ifindex=16  mac=9A:9C:34:2A:E5:18 nodemac=7E:02:A6:23:E6:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.768Z",
  "value": "id=1983  sec_id=7090583 flags=0x0000 ifindex=18  mac=02:9E:1D:34:41:05 nodemac=36:82:4C:00:F8:C7"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.215.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.216Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:36.994Z",
  "value": "id=2296  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E0:7A:F4:64:69 nodemac=E6:F7:4B:EC:2B:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:36.994Z",
  "value": "id=245   sec_id=7079208 flags=0x0000 ifindex=12  mac=A6:D8:5B:5C:E0:AA nodemac=02:80:23:CE:8E:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:36.995Z",
  "value": "id=1983  sec_id=7090583 flags=0x0000 ifindex=18  mac=02:9E:1D:34:41:05 nodemac=36:82:4C:00:F8:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:36.996Z",
  "value": "id=1265  sec_id=7079208 flags=0x0000 ifindex=14  mac=EA:7B:49:1E:18:AA nodemac=BA:03:B0:66:15:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:38.000Z",
  "value": "id=245   sec_id=7079208 flags=0x0000 ifindex=12  mac=A6:D8:5B:5C:E0:AA nodemac=02:80:23:CE:8E:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:38.000Z",
  "value": "id=1265  sec_id=7079208 flags=0x0000 ifindex=14  mac=EA:7B:49:1E:18:AA nodemac=BA:03:B0:66:15:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:38.001Z",
  "value": "id=1983  sec_id=7090583 flags=0x0000 ifindex=18  mac=02:9E:1D:34:41:05 nodemac=36:82:4C:00:F8:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:38.001Z",
  "value": "id=2296  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E0:7A:F4:64:69 nodemac=E6:F7:4B:EC:2B:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:39.001Z",
  "value": "id=1983  sec_id=7090583 flags=0x0000 ifindex=18  mac=02:9E:1D:34:41:05 nodemac=36:82:4C:00:F8:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:39.001Z",
  "value": "id=1265  sec_id=7079208 flags=0x0000 ifindex=14  mac=EA:7B:49:1E:18:AA nodemac=BA:03:B0:66:15:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:39.002Z",
  "value": "id=245   sec_id=7079208 flags=0x0000 ifindex=12  mac=A6:D8:5B:5C:E0:AA nodemac=02:80:23:CE:8E:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:39.002Z",
  "value": "id=2296  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E0:7A:F4:64:69 nodemac=E6:F7:4B:EC:2B:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:40.002Z",
  "value": "id=1265  sec_id=7079208 flags=0x0000 ifindex=14  mac=EA:7B:49:1E:18:AA nodemac=BA:03:B0:66:15:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:40.002Z",
  "value": "id=1983  sec_id=7090583 flags=0x0000 ifindex=18  mac=02:9E:1D:34:41:05 nodemac=36:82:4C:00:F8:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:40.002Z",
  "value": "id=2296  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E0:7A:F4:64:69 nodemac=E6:F7:4B:EC:2B:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.215.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:40.002Z",
  "value": "id=245   sec_id=7079208 flags=0x0000 ifindex=12  mac=A6:D8:5B:5C:E0:AA nodemac=02:80:23:CE:8E:FA"
}

