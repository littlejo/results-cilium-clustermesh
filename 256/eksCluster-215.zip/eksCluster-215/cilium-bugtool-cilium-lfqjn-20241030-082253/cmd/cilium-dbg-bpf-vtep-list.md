error dumping contents of map: loading pinned map /sys/fs/bpf/tc/globals/cilium_vtep_map: no such file or directory
> Error while running 'cilium-dbg bpf vtep list':  exit status 1

