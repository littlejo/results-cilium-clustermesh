KEY             VALUE
AgentLiveness   1923504474234
UTimeOffset     3379442730468750
