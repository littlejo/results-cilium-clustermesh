Found 255 cluster configurations

Cluster "cmesh1":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh1

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh10":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh10

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh100":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh100

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh101":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh101

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh102":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh102

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh103":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh103

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh104":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh104

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh105":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh105

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh106":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh106

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh107":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh107

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh108":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh108

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh109":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh109

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh11":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh11

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh110":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh110

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh111":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh111

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh112":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh112

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh113":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh113

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh114":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh114

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh115":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh115

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh116":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh116

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh117":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh117

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh118":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh118

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh119":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh119

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh12":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh12

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh120":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh120

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh121":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh121

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh122":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh122

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh123":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh123

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh124":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh124

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh125":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh125

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh126":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh126

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh127":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh127

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh128":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh128

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh129":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh129

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh13":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh13

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh130":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh130

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh131":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh131

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh132":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh132

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh133":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh133

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh134":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh134

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh135":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh135

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh136":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh136

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh137":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh137

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh138":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh138

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh139":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh139

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh14":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh14

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh140":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh140

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh141":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh141

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh142":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh142

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh143":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh143

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh144":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh144

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh145":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh145

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh146":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh146

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh147":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh147

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh148":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh148

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh149":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh149

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh15":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh15

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh150":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh150

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh151":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh151

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh152":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh152

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh153":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh153

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh154":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh154

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh155":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh155

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh156":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh156

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh157":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh157

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh158":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh158

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh159":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh159

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh16":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh16

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh160":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh160

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh161":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh161

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh162":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh162

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh163":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh163

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh164":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh164

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh165":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh165

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh166":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh166

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh168":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh168

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh169":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh169

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh17":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh17

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh170":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh170

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh171":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh171

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh172":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh172

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh173":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh173

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh174":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh174

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh175":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh175

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh176":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh176

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh177":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh177

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh178":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh178

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh179":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh179

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh18":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh18

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh180":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh180

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh181":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh181

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh182":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh182

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh183":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh183

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh184":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh184

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh185":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh185

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh186":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh186

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh187":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh187

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh188":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh188

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh189":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh189

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh19":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh19

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh190":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh190

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh191":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh191

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh192":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh192

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh193":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh193

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh194":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh194

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh195":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh195

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh196":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh196

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh197":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh197

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh198":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh198

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh199":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh199

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh2":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh2

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh20":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh20

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh200":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh200

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh201":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh201

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh202":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh202

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh203":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh203

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh204":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh204

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh205":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh205

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh206":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh206

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh207":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh207

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh208":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh208

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh209":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh209

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh21":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh21

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh210":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh210

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh211":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh211

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh212":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh212

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh213":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh213

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh214":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh214

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh215":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh215

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh216":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh216

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh217":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh217

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh218":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh218

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh219":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh219

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh22":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh22

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh220":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh220

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh221":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh221

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh222":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh222

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh223":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh223

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh224":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh224

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh225":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh225

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh226":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh226

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh227":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh227

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh228":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh228

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh229":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh229

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh23":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh23

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh230":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh230

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh231":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh231

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh232":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh232

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh233":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh233

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh234":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh234

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh235":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh235

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh236":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh236

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh237":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh237

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh238":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh238

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh239":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh239

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh24":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh24

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh240":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh240

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh241":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh241

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh242":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh242

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh243":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh243

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh244":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh244

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh245":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh245

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh246":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh246

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh247":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh247

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh248":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh248

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh249":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh249

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh25":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh25

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh250":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh250

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh251":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh251

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh252":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh252

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh253":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh253

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh254":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh254

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh255":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh255

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh256":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh256

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh26":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh26

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh27":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh27

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh28":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh28

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh29":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh29

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh3":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh3

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh30":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh30

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh31":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh31

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh32":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh32

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh33":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh33

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh34":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh34

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh35":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh35

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh36":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh36

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh37":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh37

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh38":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh38

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh39":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh39

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh4":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh4

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh40":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh40

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh41":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh41

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh42":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh42

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh43":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh43

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh44":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh44

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh45":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh45

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh46":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh46

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh47":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh47

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh48":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh48

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh49":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh49

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh5":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh5

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh50":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh50

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh51":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh51

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh52":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh52

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh53":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh53

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh54":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh54

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh55":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh55

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh56":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh56

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh57":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh57

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh58":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh58

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh59":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh59

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh6":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh6

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh60":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh60

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh61":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh61

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh62":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh62

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh63":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh63

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh64":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh64

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh65":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh65

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh66":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh66

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh67":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh67

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh68":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh68

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh69":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh69

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh7":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh7

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh70":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh70

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh71":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh71

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh72":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh72

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh73":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh73

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh74":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh74

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh75":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh75

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh76":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh76

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh77":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh77

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh78":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh78

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh79":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh79

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh8":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh8

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh80":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh80

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh81":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh81

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh82":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh82

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh83":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh83

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh84":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh84

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh85":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh85

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh86":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh86

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh87":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh87

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh88":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh88

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh89":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh89

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh9":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh9

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh90":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh90

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh91":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh91

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh92":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh92

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh93":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh93

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh94":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh94

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh95":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh95

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh96":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh96

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh97":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh97

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh98":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh98

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88

Cluster "cmesh99":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh99

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.95
     ✅ TCP connection successfully established to 10.100.199.95:2379
     ✅ TLS connection successfully established to 10.100.199.95:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       6a:45:95:18:e2:c7:d4:bc:ba:78:76:cf:b9:34:96:bc:bd:18:b0:b2
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 07:33:11 +0000 UTC
          Not after:   2027-10-30 07:33:11 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       43:37:eb:3a:32:05:36:bb:58:cf:d5:a0:8d:aa:db:14:ec:c6:9e:ef
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-30 08:06:00 +0000 UTC
          Not after:   2027-10-30 08:06:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 3e2469814d8dce88
