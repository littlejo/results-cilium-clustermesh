CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2a74e52f_3848_48ba_b7a2_f55ca8d75b64.slice/cri-containerd-61a13511436c8f6550baaceff5d49075bbe8c7ea6956baed3dd60f6cb305ad1e.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2a74e52f_3848_48ba_b7a2_f55ca8d75b64.slice/cri-containerd-37bdbbad625a4bb68fed13027da66041ebd7c4cf4477b597b8d9fc6b29a11fd6.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4821f317_be78_40c5_8105_7fdfdfbc805f.slice/cri-containerd-f78b8d1768727a4642410b779e37f0a4c363fb0156f17bdefbb7ccd602085963.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4821f317_be78_40c5_8105_7fdfdfbc805f.slice/cri-containerd-f6e31aa0392a8ecb3d83d9e1366537498287fd3a7fabc7ac6b006e9d914d85f8.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod05828db9_17d5_4791_be78_ea5d5f950051.slice/cri-containerd-ed5ed49d9a11f5d16e3e833989e68a79f66ad6f1f8930475cd5b123c44565965.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod05828db9_17d5_4791_be78_ea5d5f950051.slice/cri-containerd-873900299efc1ef34941aaed169589f6eb20914e2b81b177faa6a5e08af149e2.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf3c0c8cc_06e9_4956_b22e_8bfbf4b8272b.slice/cri-containerd-08ae84f7a5c47b8554c39b5ca38465af3c33966c5aa3738f1af40d054b844508.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf3c0c8cc_06e9_4956_b22e_8bfbf4b8272b.slice/cri-containerd-5166c53f0e43096af9ccb9109d9699d4f06b709a0d5499ef52fe2ec75f22ea31.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36467df3_93f3_4512_b38e_8b7e4768c9c2.slice/cri-containerd-db3bc5c9196a35bebe0b35ece8d724d6ddfe18b7f8977e1c9b27a8acf691e089.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36467df3_93f3_4512_b38e_8b7e4768c9c2.slice/cri-containerd-b2878109775984c762a651da4ab258c1a742f62da013e3d472a800016967ffab.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd96c482e_c858_4852_9715_7aab76746c69.slice/cri-containerd-a8e586da3d5b3784f6dd5dabf423fbda42a2faa2346b026c40a41a1c247d0686.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd96c482e_c858_4852_9715_7aab76746c69.slice/cri-containerd-470485bf54fe866c66e1184607e334dce43cf027749dd689ab06db6566cadc32.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd10d854b_47b0_4809_87b3_71b9284a634a.slice/cri-containerd-5f5bd7a2a2c75059b8da0fd4e8ccc38016c06cf23515b550899206b124892d38.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd10d854b_47b0_4809_87b3_71b9284a634a.slice/cri-containerd-c8ca5ca9db5425a19c90f9199aa2e27af320ec99b6fb165ea24b29de1c5b4ab3.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd10d854b_47b0_4809_87b3_71b9284a634a.slice/cri-containerd-770760a1a4c1ba00725ffef5fde513a589c49ca41012f93f3aee834b2f25bf2c.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd10d854b_47b0_4809_87b3_71b9284a634a.slice/cri-containerd-d7e7d8f05c5c638505c49888a1f4c8a77ec2f9ac88a39a6effb1f356fa7a0fb3.scope
    642      cgroup_device   multi                                          
