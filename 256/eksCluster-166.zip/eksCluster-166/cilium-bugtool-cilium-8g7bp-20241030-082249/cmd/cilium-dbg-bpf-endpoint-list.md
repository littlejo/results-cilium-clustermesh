IP ADDRESS        LOCAL ENDPOINT INFO
10.166.0.205:0    id=1706  sec_id=4     flags=0x0000 ifindex=10  mac=02:6E:78:3A:45:60 nodemac=E6:9A:A9:AF:79:B1     
10.166.0.47:0     id=2404  sec_id=5473048 flags=0x0000 ifindex=14  mac=46:93:D5:8D:15:15 nodemac=3A:E7:A8:0B:10:E5   
172.31.174.28:0   (localhost)                                                                                        
172.31.178.44:0   (localhost)                                                                                        
10.166.0.92:0     id=1925  sec_id=5480899 flags=0x0000 ifindex=18  mac=0E:6B:E0:9C:95:17 nodemac=66:F0:46:FF:B2:2D   
10.166.0.247:0    (localhost)                                                                                        
10.166.0.169:0    id=2744  sec_id=5473048 flags=0x0000 ifindex=12  mac=EE:5B:F8:CA:B9:0E nodemac=32:DE:AF:02:36:80   
