top - 08:22:50 up 31 min,  0 users,  load average: 0.20, 0.26, 0.20
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 25.0 us, 53.6 sy,  0.0 ni, 21.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4459.2 free,   1208.9 used,   2146.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6420.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 388920  78460 S   6.7   4.9   0:46.26 cilium-+
    635 root      20   0 1240432  16208  11228 S   6.7   0.2   0:00.03 cilium-+
    394 root      20   0 1229488   7180   3052 S   0.0   0.1   0:01.10 cilium-+
    677 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    681 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    686 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    722 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
