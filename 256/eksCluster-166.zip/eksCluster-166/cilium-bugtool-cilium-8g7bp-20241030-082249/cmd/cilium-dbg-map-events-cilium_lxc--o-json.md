{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:36.945Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.174.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:36.945Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.178.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:36.945Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.749Z",
  "value": "id=1706  sec_id=4     flags=0x0000 ifindex=10  mac=02:6E:78:3A:45:60 nodemac=E6:9A:A9:AF:79:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.752Z",
  "value": "id=2404  sec_id=5473048 flags=0x0000 ifindex=14  mac=46:93:D5:8D:15:15 nodemac=3A:E7:A8:0B:10:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.810Z",
  "value": "id=1706  sec_id=4     flags=0x0000 ifindex=10  mac=02:6E:78:3A:45:60 nodemac=E6:9A:A9:AF:79:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.818Z",
  "value": "id=2404  sec_id=5473048 flags=0x0000 ifindex=14  mac=46:93:D5:8D:15:15 nodemac=3A:E7:A8:0B:10:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.830Z",
  "value": "id=2744  sec_id=5473048 flags=0x0000 ifindex=12  mac=EE:5B:F8:CA:B9:0E nodemac=32:DE:AF:02:36:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:31.363Z",
  "value": "id=1706  sec_id=4     flags=0x0000 ifindex=10  mac=02:6E:78:3A:45:60 nodemac=E6:9A:A9:AF:79:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:31.364Z",
  "value": "id=2404  sec_id=5473048 flags=0x0000 ifindex=14  mac=46:93:D5:8D:15:15 nodemac=3A:E7:A8:0B:10:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:31.364Z",
  "value": "id=2744  sec_id=5473048 flags=0x0000 ifindex=12  mac=EE:5B:F8:CA:B9:0E nodemac=32:DE:AF:02:36:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:31.394Z",
  "value": "id=1871  sec_id=5480899 flags=0x0000 ifindex=16  mac=66:C4:2B:CE:16:EF nodemac=62:E2:4F:C1:6B:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:32.364Z",
  "value": "id=1706  sec_id=4     flags=0x0000 ifindex=10  mac=02:6E:78:3A:45:60 nodemac=E6:9A:A9:AF:79:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:32.364Z",
  "value": "id=2404  sec_id=5473048 flags=0x0000 ifindex=14  mac=46:93:D5:8D:15:15 nodemac=3A:E7:A8:0B:10:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:32.364Z",
  "value": "id=1871  sec_id=5480899 flags=0x0000 ifindex=16  mac=66:C4:2B:CE:16:EF nodemac=62:E2:4F:C1:6B:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:32.364Z",
  "value": "id=2744  sec_id=5473048 flags=0x0000 ifindex=12  mac=EE:5B:F8:CA:B9:0E nodemac=32:DE:AF:02:36:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.687Z",
  "value": "id=1925  sec_id=5480899 flags=0x0000 ifindex=18  mac=0E:6B:E0:9C:95:17 nodemac=66:F0:46:FF:B2:2D"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.166.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.115Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.036Z",
  "value": "id=2744  sec_id=5473048 flags=0x0000 ifindex=12  mac=EE:5B:F8:CA:B9:0E nodemac=32:DE:AF:02:36:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.036Z",
  "value": "id=1925  sec_id=5480899 flags=0x0000 ifindex=18  mac=0E:6B:E0:9C:95:17 nodemac=66:F0:46:FF:B2:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.037Z",
  "value": "id=1706  sec_id=4     flags=0x0000 ifindex=10  mac=02:6E:78:3A:45:60 nodemac=E6:9A:A9:AF:79:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.037Z",
  "value": "id=2404  sec_id=5473048 flags=0x0000 ifindex=14  mac=46:93:D5:8D:15:15 nodemac=3A:E7:A8:0B:10:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.041Z",
  "value": "id=1925  sec_id=5480899 flags=0x0000 ifindex=18  mac=0E:6B:E0:9C:95:17 nodemac=66:F0:46:FF:B2:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.043Z",
  "value": "id=1706  sec_id=4     flags=0x0000 ifindex=10  mac=02:6E:78:3A:45:60 nodemac=E6:9A:A9:AF:79:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.044Z",
  "value": "id=2404  sec_id=5473048 flags=0x0000 ifindex=14  mac=46:93:D5:8D:15:15 nodemac=3A:E7:A8:0B:10:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.045Z",
  "value": "id=2744  sec_id=5473048 flags=0x0000 ifindex=12  mac=EE:5B:F8:CA:B9:0E nodemac=32:DE:AF:02:36:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.036Z",
  "value": "id=1706  sec_id=4     flags=0x0000 ifindex=10  mac=02:6E:78:3A:45:60 nodemac=E6:9A:A9:AF:79:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.037Z",
  "value": "id=1925  sec_id=5480899 flags=0x0000 ifindex=18  mac=0E:6B:E0:9C:95:17 nodemac=66:F0:46:FF:B2:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.037Z",
  "value": "id=2404  sec_id=5473048 flags=0x0000 ifindex=14  mac=46:93:D5:8D:15:15 nodemac=3A:E7:A8:0B:10:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.037Z",
  "value": "id=2744  sec_id=5473048 flags=0x0000 ifindex=12  mac=EE:5B:F8:CA:B9:0E nodemac=32:DE:AF:02:36:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.036Z",
  "value": "id=1706  sec_id=4     flags=0x0000 ifindex=10  mac=02:6E:78:3A:45:60 nodemac=E6:9A:A9:AF:79:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.037Z",
  "value": "id=2404  sec_id=5473048 flags=0x0000 ifindex=14  mac=46:93:D5:8D:15:15 nodemac=3A:E7:A8:0B:10:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.037Z",
  "value": "id=1925  sec_id=5480899 flags=0x0000 ifindex=18  mac=0E:6B:E0:9C:95:17 nodemac=66:F0:46:FF:B2:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.166.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.037Z",
  "value": "id=2744  sec_id=5473048 flags=0x0000 ifindex=12  mac=EE:5B:F8:CA:B9:0E nodemac=32:DE:AF:02:36:80"
}

