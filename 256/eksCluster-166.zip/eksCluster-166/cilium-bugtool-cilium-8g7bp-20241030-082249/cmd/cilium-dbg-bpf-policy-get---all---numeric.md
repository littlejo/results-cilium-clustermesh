Endpoint ID: 842
Path: /sys/fs/bpf/tc/globals/cilium_policy_00842

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1706
Path: /sys/fs/bpf/tc/globals/cilium_policy_01706

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1642686   20726     0        
Allow    Ingress     1          ANY          NONE         disabled    18888     221       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1925
Path: /sys/fs/bpf/tc/globals/cilium_policy_01925

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11555626   115228    0        
Allow    Ingress     1          ANY          NONE         disabled    9876262    103886    0        
Allow    Egress      0          ANY          NONE         disabled    13109797   128719    0        


Endpoint ID: 2404
Path: /sys/fs/bpf/tc/globals/cilium_policy_02404

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    123943   1424      0        
Allow    Egress      0          ANY          NONE         disabled    16271    176       0        


Endpoint ID: 2744
Path: /sys/fs/bpf/tc/globals/cilium_policy_02744

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    123802   1418      0        
Allow    Egress      0          ANY          NONE         disabled    16596    180       0        


