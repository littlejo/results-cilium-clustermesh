key: aa 06 00 00  value: 2a 02 00 00
key: 85 07 00 00  value: 64 02 00 00
key: 64 09 00 00  value: 10 02 00 00
key: b8 0a 00 00  value: 27 02 00 00
Found 4 elements
