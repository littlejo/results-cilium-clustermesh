1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:26:64:fc:8d:c9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.178.44/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3517sec preferred_lft 3517sec
    inet6 fe80::426:64ff:fefc:8dc9/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:26:dd:4c:07:6b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.174.28/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::426:ddff:fe4c:76b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:ae:29:43:07:44 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ae:29ff:fe43:744/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:b1:73:93:6a:26 brd ff:ff:ff:ff:ff:ff
    inet 10.166.0.247/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::38b1:73ff:fe93:6a26/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether b6:8a:23:0d:63:39 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b48a:23ff:fe0d:6339/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:9a:a9:af:79:b1 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::e49a:a9ff:feaf:79b1/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc3002d7fe5894@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:de:af:02:36:80 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::30de:afff:fe02:3680/64 scope link 
       valid_lft forever preferred_lft forever
14: lxccb539f59b9b4@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:e7:a8:0b:10:e5 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::38e7:a8ff:fe0b:10e5/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcffd5deb8bcbf@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:f0:46:ff:b2:2d brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::64f0:46ff:feff:b22d/64 scope link 
       valid_lft forever preferred_lft forever
