USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         635  0.0  0.1 1240176 15912 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         666  0.0  0.0   6408  1648 ?        R    08:22   0:00  \_ ps auxfw
root         667  0.0  0.0   3852  1284 ?        R    08:22   0:00  \_ bash -c hostname
root           1  3.6  4.8 1606080 388920 ?      Ssl  08:01   0:46 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.0  0.0 1229488 7180 ?        Sl   08:01   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
