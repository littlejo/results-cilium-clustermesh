[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd10d854b_47b0_4809_87b3_71b9284a634a.slice/cri-containerd-770760a1a4c1ba00725ffef5fde513a589c49ca41012f93f3aee834b2f25bf2c.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd10d854b_47b0_4809_87b3_71b9284a634a.slice/cri-containerd-d7e7d8f05c5c638505c49888a1f4c8a77ec2f9ac88a39a6effb1f356fa7a0fb3.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd10d854b_47b0_4809_87b3_71b9284a634a.slice/cri-containerd-5f5bd7a2a2c75059b8da0fd4e8ccc38016c06cf23515b550899206b124892d38.scope"
      }
    ],
    "ips": [
      "10.166.0.92"
    ],
    "name": "clustermesh-apiserver-864bb86858-k7w45",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4821f317_be78_40c5_8105_7fdfdfbc805f.slice/cri-containerd-f78b8d1768727a4642410b779e37f0a4c363fb0156f17bdefbb7ccd602085963.scope"
      }
    ],
    "ips": [
      "10.166.0.47"
    ],
    "name": "coredns-cc6ccd49c-z775t",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2a74e52f_3848_48ba_b7a2_f55ca8d75b64.slice/cri-containerd-61a13511436c8f6550baaceff5d49075bbe8c7ea6956baed3dd60f6cb305ad1e.scope"
      }
    ],
    "ips": [
      "10.166.0.169"
    ],
    "name": "coredns-cc6ccd49c-pxbpd",
    "namespace": "kube-system"
  }
]

