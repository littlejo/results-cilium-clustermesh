REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35362     2797065     677    bpf_overlay.c
Interface                 INGRESS     636568    131405959   1132   bpf_host.c
Success                   EGRESS      15352     1203650     1694   bpf_host.c
Success                   EGRESS      270465    33755180    1308   bpf_lxc.c
Success                   EGRESS      34992     2767445     53     encap.h
Success                   INGRESS     312392    35352779    86     l3.h
Success                   INGRESS     333053    36990240    235    trace.h
Unsupported L3 protocol   EGRESS      39        2886        1492   bpf_lxc.c
