ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.151.87:443 (active)    
                                         2 => 172.31.241.226:443 (active)   
2    10.100.187.189:443   ClusterIP      1 => 172.31.178.44:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.166.0.169:53 (active)      
                                         2 => 10.166.0.47:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.166.0.169:9153 (active)    
                                         2 => 10.166.0.47:9153 (active)     
5    10.100.199.95:2379   ClusterIP      1 => 10.166.0.92:2379 (active)     
