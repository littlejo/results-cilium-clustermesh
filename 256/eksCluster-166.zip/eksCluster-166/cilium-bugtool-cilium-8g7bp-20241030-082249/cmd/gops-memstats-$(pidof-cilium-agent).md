alloc: 168.19MB (176359184 bytes)
total-alloc: 2.22GB (2385366272 bytes)
sys: 333.02MB (349196644 bytes)
lookups: 0
mallocs: 63064763
frees: 61134613
heap-alloc: 168.19MB (176359184 bytes)
heap-sys: 255.82MB (268247040 bytes)
heap-idle: 65.31MB (68485120 bytes)
heap-in-use: 190.51MB (199761920 bytes)
heap-released: 13.77MB (14442496 bytes)
heap-objects: 1930150
stack-in-use: 64.16MB (67272704 bytes)
stack-sys: 64.16MB (67272704 bytes)
stack-mspan-inuse: 3.22MB (3376640 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.28MB (1342569 bytes)
gc-sys: 5.99MB (6276512 bytes)
next-gc: when heap-alloc >= 214.04MB (224432728 bytes)
last-gc: 2024-10-30 08:22:51.355553673 +0000 UTC
gc-pause-total: 16.768994ms
gc-pause: 512680
gc-pause-end: 1730276571355553673
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0004977971451529844
enable-gc: true
debug-gc: false
