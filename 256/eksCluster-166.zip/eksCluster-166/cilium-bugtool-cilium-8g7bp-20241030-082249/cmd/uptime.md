 08:22:50 up 31 min,  0 users,  load average: 0.20, 0.26, 0.20
