markdown output at /tmp/cilium-bugtool-20241030-082250.562+0000-UTC-3337041362/cmd/cilium-debuginfo-20241030-082321.519+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082250.562+0000-UTC-3337041362/cmd/cilium-debuginfo-20241030-082321.519+0000-UTC.json
