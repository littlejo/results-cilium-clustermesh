ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.221.143:443 (active)    
                                         2 => 172.31.140.55:443 (active)     
2    10.100.155.163:443   ClusterIP      1 => 172.31.202.148:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.129.0.185:53 (active)       
                                         2 => 10.129.0.76:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.129.0.185:9153 (active)     
                                         2 => 10.129.0.76:9153 (active)      
5    10.100.128.68:2379   ClusterIP      1 => 10.129.0.187:2379 (active)     
