Endpoint ID: 941
Path: /sys/fs/bpf/tc/globals/cilium_policy_00941

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    147415   1686      0        
Allow    Egress      0          ANY          NONE         disabled    19513    216       0        


Endpoint ID: 1212
Path: /sys/fs/bpf/tc/globals/cilium_policy_01212

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    148958   1714      0        
Allow    Egress      0          ANY          NONE         disabled    19878    219       0        


Endpoint ID: 1760
Path: /sys/fs/bpf/tc/globals/cilium_policy_01760

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3437
Path: /sys/fs/bpf/tc/globals/cilium_policy_03437

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11490713   116074    0        
Allow    Ingress     1          ANY          NONE         disabled    12235873   126217    0        
Allow    Egress      0          ANY          NONE         disabled    15118374   147321    0        


Endpoint ID: 3768
Path: /sys/fs/bpf/tc/globals/cilium_policy_03768

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1638992   20683     0        
Allow    Ingress     1          ANY          NONE         disabled    22621     267       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


