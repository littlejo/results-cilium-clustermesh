key: ad 03 00 00  value: 00 02 00 00
key: bc 04 00 00  value: 1c 02 00 00
key: 6d 0d 00 00  value: 76 02 00 00
key: b8 0e 00 00  value: 05 02 00 00
Found 4 elements
