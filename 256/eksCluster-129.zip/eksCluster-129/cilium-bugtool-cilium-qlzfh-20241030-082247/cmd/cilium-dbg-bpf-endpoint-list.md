IP ADDRESS         LOCAL ENDPOINT INFO
172.31.221.156:0   (localhost)                                                                                        
10.129.0.76:0      id=1212  sec_id=4265237 flags=0x0000 ifindex=12  mac=52:9B:76:7D:74:41 nodemac=6E:26:70:7A:75:08   
10.129.0.145:0     id=3768  sec_id=4     flags=0x0000 ifindex=10  mac=E2:DD:06:B5:5A:59 nodemac=26:34:00:E7:87:3B     
10.129.0.187:0     id=3437  sec_id=4272680 flags=0x0000 ifindex=18  mac=82:18:B8:CD:E0:6B nodemac=62:38:C0:51:45:87   
10.129.0.185:0     id=941   sec_id=4265237 flags=0x0000 ifindex=14  mac=C2:11:6E:9B:C3:0A nodemac=1A:C2:F0:61:CC:5B   
10.129.0.100:0     (localhost)                                                                                        
172.31.202.148:0   (localhost)                                                                                        
