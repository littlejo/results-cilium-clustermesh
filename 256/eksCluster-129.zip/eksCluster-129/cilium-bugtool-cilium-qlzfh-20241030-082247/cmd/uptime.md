 08:22:49 up 33 min,  0 users,  load average: 0.78, 0.40, 0.26
