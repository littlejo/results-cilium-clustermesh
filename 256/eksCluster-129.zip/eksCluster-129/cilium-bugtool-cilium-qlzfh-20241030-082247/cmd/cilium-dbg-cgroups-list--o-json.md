[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod24415660_7792_42b2_ac4b_ffa7fd43f92d.slice/cri-containerd-c89ee4ac0b40d4bc7856c66c521e2742d7e3f9766613edead19b30d49d491ece.scope"
      }
    ],
    "ips": [
      "10.129.0.185"
    ],
    "name": "coredns-cc6ccd49c-t2t6w",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29166d59_d6dd_4aa1_a36b_86a993e62fce.slice/cri-containerd-7f9e0ee586a8ec8d5d8c214f4a3c5f45de5e292c8f4adb4604dbdd9178f6b00d.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29166d59_d6dd_4aa1_a36b_86a993e62fce.slice/cri-containerd-796e68b3fb00e22d162da5c5074f66cdc1134d1ec74fa378e2845d2162b4540b.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29166d59_d6dd_4aa1_a36b_86a993e62fce.slice/cri-containerd-47295df720193aece4ef2baa0d19f69dd9c2afd115c6e358610db9f1baf79a71.scope"
      }
    ],
    "ips": [
      "10.129.0.187"
    ],
    "name": "clustermesh-apiserver-c6959798f-5v8lx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8eea1e47_772f_4b2a_89a5_f2980b664c96.slice/cri-containerd-f4c8639bb00a9effb118f2ca7a92f44633627692ea893648451212833255af6d.scope"
      }
    ],
    "ips": [
      "10.129.0.76"
    ],
    "name": "coredns-cc6ccd49c-dpdhw",
    "namespace": "kube-system"
  }
]

