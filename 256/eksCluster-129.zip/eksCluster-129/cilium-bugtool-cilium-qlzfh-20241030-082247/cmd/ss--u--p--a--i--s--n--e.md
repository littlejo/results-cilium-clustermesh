Total: 683
TCP:   1857 (estab 435, closed 1403, orphaned 0, timewait 563)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  454       442       12       
INET	  464       448       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                            127.0.0.1:45083      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:34427 sk:1001 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.202.148%ens5:68         0.0.0.0:*    uid:192 ino:74229 sk:1002 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:34572 sk:1003 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15422 sk:1004 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:34571 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15423 sk:1006 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::8c1:57ff:fe47:4db7]%ens5:546           [::]:*    uid:192 ino:15583 sk:1007 cgroup:unreachable:c4e v6only:1 <->                   
