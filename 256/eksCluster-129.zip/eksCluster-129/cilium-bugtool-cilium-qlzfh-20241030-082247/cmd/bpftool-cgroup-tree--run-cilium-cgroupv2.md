CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0948d8d8_1579_4bcb_a3de_0cdf9bacf668.slice/cri-containerd-e3ad28be6fe3aaa64e0460c37fb5f855f1e08907dfb0a82251c77d13abeb3db1.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0948d8d8_1579_4bcb_a3de_0cdf9bacf668.slice/cri-containerd-bc262c2fb3085ec404d313f0d0092ac361163e679437de231a806d004e07a68a.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod24415660_7792_42b2_ac4b_ffa7fd43f92d.slice/cri-containerd-d0a73d59ddd4919d72b16d340b962a0cf1c65bc8cd7d298467f6366c5798e635.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod24415660_7792_42b2_ac4b_ffa7fd43f92d.slice/cri-containerd-c89ee4ac0b40d4bc7856c66c521e2742d7e3f9766613edead19b30d49d491ece.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8eea1e47_772f_4b2a_89a5_f2980b664c96.slice/cri-containerd-f4c8639bb00a9effb118f2ca7a92f44633627692ea893648451212833255af6d.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8eea1e47_772f_4b2a_89a5_f2980b664c96.slice/cri-containerd-f53811a025688681f2012ad2bc1d324b52b47d68bb793f15564b4a76a388d5fe.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad12d227_fe37_47d0_ac83_80aa2983c33e.slice/cri-containerd-9b5d630c149af7f33e68a4c04ec2b9fb3770459920a61e5f5e4293832d662833.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad12d227_fe37_47d0_ac83_80aa2983c33e.slice/cri-containerd-1fcf8beafd766c61648794ba737e640e6945bf8c3b90180e66ae84227f4934e9.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod273a2004_6cd3_4240_bb93_f616869f3a1d.slice/cri-containerd-716bed1ec67ac65e6b1af2025683ae7f095b7a2d89da2459ec0ec5bc29c416a9.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod273a2004_6cd3_4240_bb93_f616869f3a1d.slice/cri-containerd-773d850d041c8fc13c1f93ad5a031a33d7c8c20fa9d5567a983ca719edb698f1.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29166d59_d6dd_4aa1_a36b_86a993e62fce.slice/cri-containerd-47295df720193aece4ef2baa0d19f69dd9c2afd115c6e358610db9f1baf79a71.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29166d59_d6dd_4aa1_a36b_86a993e62fce.slice/cri-containerd-d06195b995c5dae6bf6ff6213ee926502a6401e792e842f8ae1fca7dbe755ee7.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29166d59_d6dd_4aa1_a36b_86a993e62fce.slice/cri-containerd-7f9e0ee586a8ec8d5d8c214f4a3c5f45de5e292c8f4adb4604dbdd9178f6b00d.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29166d59_d6dd_4aa1_a36b_86a993e62fce.slice/cri-containerd-796e68b3fb00e22d162da5c5074f66cdc1134d1ec74fa378e2845d2162b4540b.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod28a0d507_dbab_4bf1_be79_0b4f81d13d32.slice/cri-containerd-1fa34b97b803034acde5fdadce5228fa8208a09a9264527ba8998329ca9f12a0.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod28a0d507_dbab_4bf1_be79_0b4f81d13d32.slice/cri-containerd-920e59f74f973b53213641eac42c51a8d04a650e3a1e9f71ae4f4e89eaaac3b5.scope
    103      cgroup_device   multi                                          
