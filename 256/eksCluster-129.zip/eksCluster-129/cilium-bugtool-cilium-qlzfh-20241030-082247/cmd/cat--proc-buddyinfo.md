Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal     12    206     28     64     19     48     18      6      2      3    865 
