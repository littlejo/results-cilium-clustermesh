KEY             VALUE
AgentLiveness   2057340068095
UTimeOffset     3379442466796875
