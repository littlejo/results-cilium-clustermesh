alloc: 135.37MB (141941232 bytes)
total-alloc: 2.54GB (2729112464 bytes)
sys: 337.09MB (353459572 bytes)
lookups: 0
mallocs: 67664223
frees: 66297525
heap-alloc: 135.37MB (141941232 bytes)
heap-sys: 255.95MB (268378112 bytes)
heap-idle: 80.03MB (83918848 bytes)
heap-in-use: 175.91MB (184459264 bytes)
heap-released: 8.07MB (8462336 bytes)
heap-objects: 1366698
stack-in-use: 68.03MB (71335936 bytes)
stack-sys: 68.03MB (71335936 bytes)
stack-mspan-inuse: 3.01MB (3153600 bytes)
stack-mspan-sys: 3.98MB (4177920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.03MB (1078593 bytes)
gc-sys: 6.08MB (6375976 bytes)
next-gc: when heap-alloc >= 212.16MB (222470408 bytes)
last-gc: 2024-10-30 08:22:59.161646969 +0000 UTC
gc-pause-total: 25.589904ms
gc-pause: 130910
gc-pause-end: 1730276579161646969
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0005664411356955852
enable-gc: true
debug-gc: false
