REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36626     2899924     677    bpf_overlay.c
Interface                 INGRESS     694238    138956078   1132   bpf_host.c
Success                   EGRESS      16631     1307911     1694   bpf_host.c
Success                   EGRESS      311199    38418742    1308   bpf_lxc.c
Success                   EGRESS      37322     2943660     53     encap.h
Success                   INGRESS     356139    40636972    86     l3.h
Success                   INGRESS     376785    42273031    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
