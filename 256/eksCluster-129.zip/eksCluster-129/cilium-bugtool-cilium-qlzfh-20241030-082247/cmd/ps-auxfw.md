USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         736  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         731  0.0  0.0   2208   796 ?        Ss   08:22   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         745  0.0  0.0 1242676 7496 ?        Rl   08:22   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root         717  0.0  0.2 1240432 16384 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         743  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         750  0.0  0.2 1240432 16384 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         695  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         689  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         683  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root           1  4.3  4.9 1606336 393076 ?      Ssl  07:57   1:05 cilium-agent --config-dir=/tmp/cilium/config-map
root         397  0.0  0.1 1229744 8324 ?        Sl   07:57   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
