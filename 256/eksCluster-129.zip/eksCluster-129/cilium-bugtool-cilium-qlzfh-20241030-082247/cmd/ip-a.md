1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c1:57:47:4d:b7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.202.148/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3385sec preferred_lft 3385sec
    inet6 fe80::8c1:57ff:fe47:4db7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:02:a0:b5:e6:35 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.221.156/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::802:a0ff:feb5:e635/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:9f:56:26:04:3e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::789f:56ff:fe26:43e/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:35:6a:05:39:c0 brd ff:ff:ff:ff:ff:ff
    inet 10.129.0.100/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::9435:6aff:fe05:39c0/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 0a:36:ec:4d:d1:4d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::836:ecff:fe4d:d14d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:34:00:e7:87:3b brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::2434:ff:fee7:873b/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc28e85fb2f7ae@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:26:70:7a:75:08 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::6c26:70ff:fe7a:7508/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc3425a1d5a203@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:c2:f0:61:cc:5b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::18c2:f0ff:fe61:cc5b/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc746148bd925f@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:38:c0:51:45:87 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::6038:c0ff:fe51:4587/64 scope link 
       valid_lft forever preferred_lft forever
