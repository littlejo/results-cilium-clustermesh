USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         660  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         659  0.0  0.2 1240432 16244 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         681  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         682  0.0  0.2 1240432 16244 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         634  0.0  0.0 1228744 4044 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         633  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         626  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         614  0.0  0.0 1228744 3656 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.3  4.8 1606080 387644 ?      Ssl  07:52   1:00 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.0  0.0 1229488 6776 ?        Sl   07:53   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
