filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc2789260f10ed direct-action not_in_hw id 550 tag 3555b37cfc8d1f9b jited 
