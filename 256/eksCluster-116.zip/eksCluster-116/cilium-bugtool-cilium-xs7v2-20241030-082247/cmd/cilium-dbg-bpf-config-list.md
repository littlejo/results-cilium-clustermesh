KEY             VALUE
AgentLiveness   2233193746077
UTimeOffset     3379442123046875
