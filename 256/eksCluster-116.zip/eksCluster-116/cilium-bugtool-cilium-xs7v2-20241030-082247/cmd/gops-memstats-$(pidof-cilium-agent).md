alloc: 181.73MB (190556592 bytes)
total-alloc: 2.42GB (2594235400 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 66044622
frees: 63962198
heap-alloc: 181.73MB (190556592 bytes)
heap-sys: 247.23MB (259244032 bytes)
heap-idle: 41.16MB (43163648 bytes)
heap-in-use: 206.07MB (216080384 bytes)
heap-released: 0 bytes
heap-objects: 2082424
stack-in-use: 64.72MB (67862528 bytes)
stack-sys: 64.72MB (67862528 bytes)
stack-mspan-inuse: 3.50MB (3667840 bytes)
stack-mspan-sys: 3.94MB (4128960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 899.84KB (921433 bytes)
gc-sys: 6.02MB (6311352 bytes)
next-gc: when heap-alloc >= 212.19MB (222498872 bytes)
last-gc: 2024-10-30 08:22:50.961296138 +0000 UTC
gc-pause-total: 10.817122ms
gc-pause: 90046
gc-pause-end: 1730276570961296138
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0003729444408898835
enable-gc: true
debug-gc: false
