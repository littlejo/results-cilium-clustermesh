Endpoint ID: 60
Path: /sys/fs/bpf/tc/globals/cilium_policy_00060

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    175027   2011      0        
Allow    Egress      0          ANY          NONE         disabled    21577    243       0        


Endpoint ID: 93
Path: /sys/fs/bpf/tc/globals/cilium_policy_00093

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    173575   1989      0        
Allow    Egress      0          ANY          NONE         disabled    22136    248       0        


Endpoint ID: 1096
Path: /sys/fs/bpf/tc/globals/cilium_policy_01096

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1532
Path: /sys/fs/bpf/tc/globals/cilium_policy_01532

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1645759   20786     0        
Allow    Ingress     1          ANY          NONE         disabled    26565     312       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3760
Path: /sys/fs/bpf/tc/globals/cilium_policy_03760

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11434430   115427    0        
Allow    Ingress     1          ANY          NONE         disabled    11349262   120001    0        
Allow    Egress      0          ANY          NONE         disabled    15143208   147536    0        


