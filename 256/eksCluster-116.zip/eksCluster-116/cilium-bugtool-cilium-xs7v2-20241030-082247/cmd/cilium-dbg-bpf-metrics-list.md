REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37760     2994457     677    bpf_overlay.c
Interface                 INGRESS     679869    137252696   1132   bpf_host.c
Success                   EGRESS      17666     1396068     1694   bpf_host.c
Success                   EGRESS      292259    35920662    1308   bpf_lxc.c
Success                   EGRESS      39087     3085829     53     encap.h
Success                   INGRESS     336459    38212722    86     l3.h
Success                   INGRESS     357204    39855157    235    trace.h
Unsupported L3 protocol   EGRESS      41        3022        1492   bpf_lxc.c
