CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f7d20fa_8081_4595_b696_f2df5cbb231c.slice/cri-containerd-1dc42986cfec5ee170eb0fa1898269516f9c4d72c1b7b68a04b4790661680692.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f7d20fa_8081_4595_b696_f2df5cbb231c.slice/cri-containerd-1b5a2ef73ff3dcd4a166e5ca6e52abcf62f38b6982c8ccab32498a1a00ccb65c.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod38602818_c65d_44a2_814d_4f5e9990ec30.slice/cri-containerd-1d1f0dc82c619f63572baa2c31360b5573effa0fae22637be6e2f5acfa5b0fa8.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod38602818_c65d_44a2_814d_4f5e9990ec30.slice/cri-containerd-6d19600d951232d60b5b991e9fa00e5ce6b57908d464b0fd29c6139ad08e0229.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8078f018_3b0d_42fe_9f23_cd27a7b18b88.slice/cri-containerd-6e9a3c053bd87873c287e4d70392c487f9a8b30dbdd131645fac3ae2ac65416e.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8078f018_3b0d_42fe_9f23_cd27a7b18b88.slice/cri-containerd-493bc3212aece8284ddb1714bdb6b1e7a486aef0bbbe09bd2afb758d59625268.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67d12962_1394_4af7_b1cf_5f12a1b5b2ec.slice/cri-containerd-cba38f237ac5a1c07a9ebb81ff26e85a85c30cc8cbea37b54f782405e1a709a3.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67d12962_1394_4af7_b1cf_5f12a1b5b2ec.slice/cri-containerd-d2035a5263f583ce25c3de400b3073d2ddb4b8b183d222ff62a87b921f0cef09.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b11afbb_875d_4aeb_b262_bf2702269dc5.slice/cri-containerd-f438cf8b91c69861810bd188637f149dab231bbfefd36dd992c7f18a4f4d7414.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b11afbb_875d_4aeb_b262_bf2702269dc5.slice/cri-containerd-e76725a844a287595ea14f17606ad1f26da995729dddd10f58d3e09fd22d9c20.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda05260dd_cc8a_423e_8e9a_290bacbd77b3.slice/cri-containerd-4f93b71a5f3c6021ebeaf4ae16b329815e7a0bb250e0d91b284d368b5254a27e.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda05260dd_cc8a_423e_8e9a_290bacbd77b3.slice/cri-containerd-8c66e167cebe3b1a6fe26b84f29c2bb7b4049a61d3862c90b76b6122d26d5eb4.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda05260dd_cc8a_423e_8e9a_290bacbd77b3.slice/cri-containerd-ec8346c2050558162c5307e9278efddafcdb3756b941235ec9980b39894be5ee.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda05260dd_cc8a_423e_8e9a_290bacbd77b3.slice/cri-containerd-d5904ed2badd8546ba5d110d38b8ba6f678fe856d2a8a7a5cb1719a9ed947b73.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd19c18a8_cb2b_4535_aa64_93801a1713c1.slice/cri-containerd-f7f565b79f7caadcf52639e37d01ecf104d407d5dda59b9c5adaacdbf3d95396.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd19c18a8_cb2b_4535_aa64_93801a1713c1.slice/cri-containerd-821261d8c3199a591b3d19eb52437a3799f5d5b39b750ec811e837b735d51fc0.scope
    95       cgroup_device   multi                                          
