[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda05260dd_cc8a_423e_8e9a_290bacbd77b3.slice/cri-containerd-8c66e167cebe3b1a6fe26b84f29c2bb7b4049a61d3862c90b76b6122d26d5eb4.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda05260dd_cc8a_423e_8e9a_290bacbd77b3.slice/cri-containerd-4f93b71a5f3c6021ebeaf4ae16b329815e7a0bb250e0d91b284d368b5254a27e.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda05260dd_cc8a_423e_8e9a_290bacbd77b3.slice/cri-containerd-ec8346c2050558162c5307e9278efddafcdb3756b941235ec9980b39894be5ee.scope"
      }
    ],
    "ips": [
      "10.116.0.230"
    ],
    "name": "clustermesh-apiserver-759c664458-4x5k2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67d12962_1394_4af7_b1cf_5f12a1b5b2ec.slice/cri-containerd-d2035a5263f583ce25c3de400b3073d2ddb4b8b183d222ff62a87b921f0cef09.scope"
      }
    ],
    "ips": [
      "10.116.0.126"
    ],
    "name": "coredns-cc6ccd49c-nvsnq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8078f018_3b0d_42fe_9f23_cd27a7b18b88.slice/cri-containerd-493bc3212aece8284ddb1714bdb6b1e7a486aef0bbbe09bd2afb758d59625268.scope"
      }
    ],
    "ips": [
      "10.116.0.218"
    ],
    "name": "coredns-cc6ccd49c-8jbcg",
    "namespace": "kube-system"
  }
]

