ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.244.26:443 (active)     
                                         2 => 172.31.154.139:443 (active)    
2    10.100.175.101:443   ClusterIP      1 => 172.31.150.111:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.116.0.126:53 (active)       
                                         2 => 10.116.0.218:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.116.0.126:9153 (active)     
                                         2 => 10.116.0.218:9153 (active)     
5    10.100.232.11:2379   ClusterIP      1 => 10.116.0.230:2379 (active)     
