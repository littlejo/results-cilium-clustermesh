{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:00.635Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.150.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:00.635Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.150.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:00.635Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.386Z",
  "value": "id=1532  sec_id=4     flags=0x0000 ifindex=10  mac=2E:22:4D:79:64:E8 nodemac=2E:9A:94:4D:85:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.391Z",
  "value": "id=60    sec_id=3838350 flags=0x0000 ifindex=12  mac=FE:E1:76:70:4F:9F nodemac=62:4A:13:0C:50:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.430Z",
  "value": "id=93    sec_id=3838350 flags=0x0000 ifindex=14  mac=4E:B9:28:0F:66:59 nodemac=FA:B2:88:5A:45:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.473Z",
  "value": "id=1532  sec_id=4     flags=0x0000 ifindex=10  mac=2E:22:4D:79:64:E8 nodemac=2E:9A:94:4D:85:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:21.035Z",
  "value": "id=1532  sec_id=4     flags=0x0000 ifindex=10  mac=2E:22:4D:79:64:E8 nodemac=2E:9A:94:4D:85:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:21.037Z",
  "value": "id=60    sec_id=3838350 flags=0x0000 ifindex=12  mac=FE:E1:76:70:4F:9F nodemac=62:4A:13:0C:50:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:21.037Z",
  "value": "id=93    sec_id=3838350 flags=0x0000 ifindex=14  mac=4E:B9:28:0F:66:59 nodemac=FA:B2:88:5A:45:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:21.065Z",
  "value": "id=777   sec_id=3840837 flags=0x0000 ifindex=16  mac=DE:8D:E5:04:43:35 nodemac=CA:0B:18:44:BC:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:22.035Z",
  "value": "id=777   sec_id=3840837 flags=0x0000 ifindex=16  mac=DE:8D:E5:04:43:35 nodemac=CA:0B:18:44:BC:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:22.036Z",
  "value": "id=1532  sec_id=4     flags=0x0000 ifindex=10  mac=2E:22:4D:79:64:E8 nodemac=2E:9A:94:4D:85:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:22.036Z",
  "value": "id=60    sec_id=3838350 flags=0x0000 ifindex=12  mac=FE:E1:76:70:4F:9F nodemac=62:4A:13:0C:50:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:22.036Z",
  "value": "id=93    sec_id=3838350 flags=0x0000 ifindex=14  mac=4E:B9:28:0F:66:59 nodemac=FA:B2:88:5A:45:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:29.948Z",
  "value": "id=3760  sec_id=3840837 flags=0x0000 ifindex=18  mac=72:5E:D5:3D:34:8D nodemac=66:1C:0A:47:69:D7"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.116.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.292Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:59.144Z",
  "value": "id=3760  sec_id=3840837 flags=0x0000 ifindex=18  mac=72:5E:D5:3D:34:8D nodemac=66:1C:0A:47:69:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:59.145Z",
  "value": "id=1532  sec_id=4     flags=0x0000 ifindex=10  mac=2E:22:4D:79:64:E8 nodemac=2E:9A:94:4D:85:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:59.145Z",
  "value": "id=93    sec_id=3838350 flags=0x0000 ifindex=14  mac=4E:B9:28:0F:66:59 nodemac=FA:B2:88:5A:45:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:59.145Z",
  "value": "id=60    sec_id=3838350 flags=0x0000 ifindex=12  mac=FE:E1:76:70:4F:9F nodemac=62:4A:13:0C:50:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:00.157Z",
  "value": "id=1532  sec_id=4     flags=0x0000 ifindex=10  mac=2E:22:4D:79:64:E8 nodemac=2E:9A:94:4D:85:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:00.161Z",
  "value": "id=3760  sec_id=3840837 flags=0x0000 ifindex=18  mac=72:5E:D5:3D:34:8D nodemac=66:1C:0A:47:69:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:00.163Z",
  "value": "id=93    sec_id=3838350 flags=0x0000 ifindex=14  mac=4E:B9:28:0F:66:59 nodemac=FA:B2:88:5A:45:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:00.164Z",
  "value": "id=60    sec_id=3838350 flags=0x0000 ifindex=12  mac=FE:E1:76:70:4F:9F nodemac=62:4A:13:0C:50:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:01.148Z",
  "value": "id=3760  sec_id=3840837 flags=0x0000 ifindex=18  mac=72:5E:D5:3D:34:8D nodemac=66:1C:0A:47:69:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:01.149Z",
  "value": "id=1532  sec_id=4     flags=0x0000 ifindex=10  mac=2E:22:4D:79:64:E8 nodemac=2E:9A:94:4D:85:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:01.149Z",
  "value": "id=60    sec_id=3838350 flags=0x0000 ifindex=12  mac=FE:E1:76:70:4F:9F nodemac=62:4A:13:0C:50:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:01.149Z",
  "value": "id=93    sec_id=3838350 flags=0x0000 ifindex=14  mac=4E:B9:28:0F:66:59 nodemac=FA:B2:88:5A:45:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:02.148Z",
  "value": "id=60    sec_id=3838350 flags=0x0000 ifindex=12  mac=FE:E1:76:70:4F:9F nodemac=62:4A:13:0C:50:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:02.149Z",
  "value": "id=1532  sec_id=4     flags=0x0000 ifindex=10  mac=2E:22:4D:79:64:E8 nodemac=2E:9A:94:4D:85:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:02.149Z",
  "value": "id=3760  sec_id=3840837 flags=0x0000 ifindex=18  mac=72:5E:D5:3D:34:8D nodemac=66:1C:0A:47:69:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.116.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:02.149Z",
  "value": "id=93    sec_id=3838350 flags=0x0000 ifindex=14  mac=4E:B9:28:0F:66:59 nodemac=FA:B2:88:5A:45:02"
}

