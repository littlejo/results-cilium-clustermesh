1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:92:a6:2f:3d:9b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.150.111/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3209sec preferred_lft 3209sec
    inet6 fe80::492:a6ff:fe2f:3d9b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:61:7f:4c:8f:65 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.150.77/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::461:7fff:fe4c:8f65/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:5b:3f:9c:ae:1c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5b:3fff:fe9c:ae1c/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:1c:c4:be:81:ad brd ff:ff:ff:ff:ff:ff
    inet 10.116.0.83/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::301c:c4ff:febe:81ad/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether fa:36:90:ae:29:b4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f836:90ff:feae:29b4/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:9a:94:4d:85:0b brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::2c9a:94ff:fe4d:850b/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc0e29fd6a3d3e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:4a:13:0c:50:b2 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::604a:13ff:fe0c:50b2/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc2789260f10ed@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:b2:88:5a:45:02 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f8b2:88ff:fe5a:4502/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc66d9ad0f998a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:1c:0a:47:69:d7 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::641c:aff:fe47:69d7/64 scope link 
       valid_lft forever preferred_lft forever
