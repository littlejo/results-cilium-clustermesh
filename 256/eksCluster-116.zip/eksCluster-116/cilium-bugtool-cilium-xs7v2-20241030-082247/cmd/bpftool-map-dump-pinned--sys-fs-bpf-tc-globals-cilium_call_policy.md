key: 3c 00 00 00  value: 05 02 00 00
key: 5d 00 00 00  value: 24 02 00 00
key: fc 05 00 00  value: 3b 02 00 00
key: b0 0e 00 00  value: 81 02 00 00
Found 4 elements
