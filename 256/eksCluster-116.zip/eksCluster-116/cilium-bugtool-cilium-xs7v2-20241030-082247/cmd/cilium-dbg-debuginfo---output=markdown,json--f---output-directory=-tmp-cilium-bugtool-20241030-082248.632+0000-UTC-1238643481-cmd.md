markdown output at /tmp/cilium-bugtool-20241030-082248.632+0000-UTC-1238643481/cmd/cilium-debuginfo-20241030-082319.742+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082248.632+0000-UTC-1238643481/cmd/cilium-debuginfo-20241030-082319.742+0000-UTC.json
