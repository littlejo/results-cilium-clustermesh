Total: 694
TCP:   1873 (estab 443, closed 1411, orphaned 0, timewait 565)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  462       450       12       
INET	  472       456       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:36395      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=43)) ino:31453 sk:3f8 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.150.111%ens5:68         0.0.0.0:*    uid:192 ino:66849 sk:3f9 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:31501 sk:3fa cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15446 sk:3fb cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:31500 sk:3fc cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15447 sk:3fd cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::492:a6ff:fe2f:3d9b]%ens5:546           [::]:*    uid:192 ino:16446 sk:3fe cgroup:unreachable:c4e v6only:1 <->                   
