IP ADDRESS         LOCAL ENDPOINT INFO
10.116.0.83:0      (localhost)                                                                                        
10.116.0.230:0     id=3760  sec_id=3840837 flags=0x0000 ifindex=18  mac=72:5E:D5:3D:34:8D nodemac=66:1C:0A:47:69:D7   
10.116.0.126:0     id=60    sec_id=3838350 flags=0x0000 ifindex=12  mac=FE:E1:76:70:4F:9F nodemac=62:4A:13:0C:50:B2   
172.31.150.111:0   (localhost)                                                                                        
172.31.150.77:0    (localhost)                                                                                        
10.116.0.211:0     id=1532  sec_id=4     flags=0x0000 ifindex=10  mac=2E:22:4D:79:64:E8 nodemac=2E:9A:94:4D:85:0B     
10.116.0.218:0     id=93    sec_id=3838350 flags=0x0000 ifindex=14  mac=4E:B9:28:0F:66:59 nodemac=FA:B2:88:5A:45:02   
