{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:57.410Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.199.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:57.410Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.214.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:57.410Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:01.770Z",
  "value": "id=1749  sec_id=4     flags=0x0000 ifindex=10  mac=92:CE:88:C3:E1:69 nodemac=06:CE:4A:3F:C4:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:01.773Z",
  "value": "id=1502  sec_id=6973117 flags=0x0000 ifindex=12  mac=82:9C:96:F4:7C:AF nodemac=06:E7:37:AE:53:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:01.848Z",
  "value": "id=932   sec_id=6973117 flags=0x0000 ifindex=14  mac=AE:1F:75:58:45:D2 nodemac=82:D0:34:6C:D9:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:01.852Z",
  "value": "id=1749  sec_id=4     flags=0x0000 ifindex=10  mac=92:CE:88:C3:E1:69 nodemac=06:CE:4A:3F:C4:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:02.172Z",
  "value": "id=1749  sec_id=4     flags=0x0000 ifindex=10  mac=92:CE:88:C3:E1:69 nodemac=06:CE:4A:3F:C4:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:02.173Z",
  "value": "id=1502  sec_id=6973117 flags=0x0000 ifindex=12  mac=82:9C:96:F4:7C:AF nodemac=06:E7:37:AE:53:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:02.173Z",
  "value": "id=932   sec_id=6973117 flags=0x0000 ifindex=14  mac=AE:1F:75:58:45:D2 nodemac=82:D0:34:6C:D9:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:02.205Z",
  "value": "id=183   sec_id=6947335 flags=0x0000 ifindex=16  mac=5A:16:6C:13:F3:76 nodemac=96:F2:21:CF:93:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:02.205Z",
  "value": "id=183   sec_id=6947335 flags=0x0000 ifindex=16  mac=5A:16:6C:13:F3:76 nodemac=96:F2:21:CF:93:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:28.569Z",
  "value": "id=502   sec_id=6947335 flags=0x0000 ifindex=18  mac=3E:6F:F0:22:74:7F nodemac=22:E1:61:C2:C9:1B"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.211.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:38.756Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.698Z",
  "value": "id=1749  sec_id=4     flags=0x0000 ifindex=10  mac=92:CE:88:C3:E1:69 nodemac=06:CE:4A:3F:C4:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.698Z",
  "value": "id=1502  sec_id=6973117 flags=0x0000 ifindex=12  mac=82:9C:96:F4:7C:AF nodemac=06:E7:37:AE:53:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.699Z",
  "value": "id=932   sec_id=6973117 flags=0x0000 ifindex=14  mac=AE:1F:75:58:45:D2 nodemac=82:D0:34:6C:D9:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.699Z",
  "value": "id=502   sec_id=6947335 flags=0x0000 ifindex=18  mac=3E:6F:F0:22:74:7F nodemac=22:E1:61:C2:C9:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.713Z",
  "value": "id=502   sec_id=6947335 flags=0x0000 ifindex=18  mac=3E:6F:F0:22:74:7F nodemac=22:E1:61:C2:C9:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.714Z",
  "value": "id=1749  sec_id=4     flags=0x0000 ifindex=10  mac=92:CE:88:C3:E1:69 nodemac=06:CE:4A:3F:C4:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.714Z",
  "value": "id=1502  sec_id=6973117 flags=0x0000 ifindex=12  mac=82:9C:96:F4:7C:AF nodemac=06:E7:37:AE:53:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.715Z",
  "value": "id=932   sec_id=6973117 flags=0x0000 ifindex=14  mac=AE:1F:75:58:45:D2 nodemac=82:D0:34:6C:D9:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:13.698Z",
  "value": "id=502   sec_id=6947335 flags=0x0000 ifindex=18  mac=3E:6F:F0:22:74:7F nodemac=22:E1:61:C2:C9:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:13.698Z",
  "value": "id=932   sec_id=6973117 flags=0x0000 ifindex=14  mac=AE:1F:75:58:45:D2 nodemac=82:D0:34:6C:D9:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:13.699Z",
  "value": "id=1502  sec_id=6973117 flags=0x0000 ifindex=12  mac=82:9C:96:F4:7C:AF nodemac=06:E7:37:AE:53:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:13.699Z",
  "value": "id=1749  sec_id=4     flags=0x0000 ifindex=10  mac=92:CE:88:C3:E1:69 nodemac=06:CE:4A:3F:C4:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:14.699Z",
  "value": "id=1749  sec_id=4     flags=0x0000 ifindex=10  mac=92:CE:88:C3:E1:69 nodemac=06:CE:4A:3F:C4:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:14.699Z",
  "value": "id=932   sec_id=6973117 flags=0x0000 ifindex=14  mac=AE:1F:75:58:45:D2 nodemac=82:D0:34:6C:D9:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:14.699Z",
  "value": "id=502   sec_id=6947335 flags=0x0000 ifindex=18  mac=3E:6F:F0:22:74:7F nodemac=22:E1:61:C2:C9:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.211.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:14.699Z",
  "value": "id=1502  sec_id=6973117 flags=0x0000 ifindex=12  mac=82:9C:96:F4:7C:AF nodemac=06:E7:37:AE:53:D5"
}

