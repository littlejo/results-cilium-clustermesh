KEY             VALUE
AgentLiveness   1670968553635
UTimeOffset     3379443230468750
