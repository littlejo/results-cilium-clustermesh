IP ADDRESS         LOCAL ENDPOINT INFO
172.31.214.171:0   (localhost)                                                                                        
10.211.0.239:0     id=1749  sec_id=4     flags=0x0000 ifindex=10  mac=92:CE:88:C3:E1:69 nodemac=06:CE:4A:3F:C4:35     
10.211.0.219:0     id=1502  sec_id=6973117 flags=0x0000 ifindex=12  mac=82:9C:96:F4:7C:AF nodemac=06:E7:37:AE:53:D5   
172.31.199.47:0    (localhost)                                                                                        
10.211.0.19:0      (localhost)                                                                                        
10.211.0.202:0     id=502   sec_id=6947335 flags=0x0000 ifindex=18  mac=3E:6F:F0:22:74:7F nodemac=22:E1:61:C2:C9:1B   
10.211.0.126:0     id=932   sec_id=6973117 flags=0x0000 ifindex=14  mac=AE:1F:75:58:45:D2 nodemac=82:D0:34:6C:D9:17   
