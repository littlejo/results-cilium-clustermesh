key: f6 01 00 00  value: 87 02 00 00
key: a4 03 00 00  value: 2e 02 00 00
key: de 05 00 00  value: 0c 02 00 00
key: d5 06 00 00  value: 3c 02 00 00
Found 4 elements
