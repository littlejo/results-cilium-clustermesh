top - 08:22:54 up 27 min,  0 users,  load average: 0.16, 0.21, 0.18
Tasks:  10 total,   3 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 46.7 us, 43.3 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi, 10.0 si,  0.0 st
MiB Mem :   7814.2 total,   4440.0 free,   1228.0 used,   2146.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6401.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606016 394044  78908 S  40.0   4.9   0:51.99 cilium-+
    698 root      20   0 1244084  21200  14528 R  20.0   0.3   0:00.03 hubble
    624 root      20   0 1229640  32440   4004 S  13.3   0.4   0:00.02 gops
    394 root      20   0 1229744   7912   3836 S   0.0   0.1   0:01.13 cilium-+
    636 root      20   0 1240432  15856  11356 S   0.0   0.2   0:00.02 cilium-+
    658 root      20   0 1228744   3716   3040 S   0.0   0.0   0:00.00 gops
    672 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    691 root      20   0    2208    792    712 S   0.0   0.0   0:00.00 timeout
    699 root      20   0    6576   2416   2092 R   0.0   0.0   0:00.00 top
    717 root      20   0    1452    404    344 R   0.0   0.0   0:00.00 ip6tabl+
