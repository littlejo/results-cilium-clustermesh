ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.150.113:443 (active)    
                                         2 => 172.31.193.187:443 (active)    
2    10.100.142.29:443    ClusterIP      1 => 172.31.214.171:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.211.0.126:53 (active)       
                                         2 => 10.211.0.219:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.211.0.126:9153 (active)     
                                         2 => 10.211.0.219:9153 (active)     
5    10.100.128.87:2379   ClusterIP      1 => 10.211.0.202:2379 (active)     
