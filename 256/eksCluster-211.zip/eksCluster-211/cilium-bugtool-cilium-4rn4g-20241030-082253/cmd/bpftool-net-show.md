xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 562
ens6(5) clsact/ingress cil_from_netdev-ens6 id 565
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 549
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 541
cilium_host(7) clsact/egress cil_from_host-cilium_host id 545
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 580
lxcbfe80d31026e(12) clsact/ingress cil_from_container-lxcbfe80d31026e id 535
lxc55d3381e0070(14) clsact/ingress cil_from_container-lxc55d3381e0070 id 582
lxcc73e634c5f9a(18) clsact/ingress cil_from_container-lxcc73e634c5f9a id 645

flow_dissector:

netfilter:

