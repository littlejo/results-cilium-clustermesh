CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1274741e_22aa_45c5_b434_74e9144faa27.slice/cri-containerd-c53d001b930ea4943b974c770541dfba74870a1ccd5c18a84127bc480e7c7a5f.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1274741e_22aa_45c5_b434_74e9144faa27.slice/cri-containerd-77c23df40f02eb01189fb4fe6f5e8b837164aa329ff4e27db77eed763df17d2b.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod97db7044_af00_4629_9f26_8165f62ba999.slice/cri-containerd-152442c78098be34367c689b2293e14dcb421d6d76abf7a5e21add0918f4fa78.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod97db7044_af00_4629_9f26_8165f62ba999.slice/cri-containerd-455f14e8542e98848c61dbfd475f052a3cb63d4c099d459bd859843e730bd07a.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb45cf0a8_3682_4d4a_9a1b_073e33476251.slice/cri-containerd-12e46b8f312a5aeb0d9bacd6a9f3dbfc283cd97a402c7bf8a7bc55706ac86527.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb45cf0a8_3682_4d4a_9a1b_073e33476251.slice/cri-containerd-db19a5d1f928e78a6dfa3d37f6357e220fa05b354581a34737f9894e53c9066a.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod855bc909_b2cd_4f4e_9d6c_970ddc37515a.slice/cri-containerd-be876a3d312f118229c04b0c8d6bda7340e9c5df1743b05966661c5b0a02f817.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod855bc909_b2cd_4f4e_9d6c_970ddc37515a.slice/cri-containerd-1ea8904a4a9bacb9849708b175c39403e04fd7429d6b75f04e189ceab7b30216.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddaa6c9e8_0530_4f9a_947d_96ea81e89a18.slice/cri-containerd-7083f7431e5bfe68f4d3bc74e2cd642175ba737c5285a9bbb6bd522dee0e09bb.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddaa6c9e8_0530_4f9a_947d_96ea81e89a18.slice/cri-containerd-a4454534eb36c3f250fd7a6ed2b1bef352755bce6cdf721845f920e3d61e4034.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod47538c4f_2f9b_49ac_81be_56a72d1a90aa.slice/cri-containerd-ea1016a234a36a64fd69b2c8878db9d904fedf1189171407fd3db51abd7c6a6b.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod47538c4f_2f9b_49ac_81be_56a72d1a90aa.slice/cri-containerd-f39002c3a168c01027a9030551e76b9941e4b19aef54a31eca5787be436be90b.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5ccd1247_4e05_437e_abd8_1dde48dca6e5.slice/cri-containerd-715066526b15586366cc45dfe3b182ce11f4a3e04c7000b7027b948d4a4d7071.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5ccd1247_4e05_437e_abd8_1dde48dca6e5.slice/cri-containerd-3f92b0229c2e16ace02e6f43dc306dbc8bc07850af58631fa3f7e012df634778.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5ccd1247_4e05_437e_abd8_1dde48dca6e5.slice/cri-containerd-db00f4ae51d313c962dbae2c988acaeb4723dfb17196b5935a50ca1acc5eaf41.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5ccd1247_4e05_437e_abd8_1dde48dca6e5.slice/cri-containerd-10d4f95ee6c75bc6675c53dd30ed6e0ee1aaf9e5adf0e6e4249965be9b18f377.scope
    681      cgroup_device   multi                                          
