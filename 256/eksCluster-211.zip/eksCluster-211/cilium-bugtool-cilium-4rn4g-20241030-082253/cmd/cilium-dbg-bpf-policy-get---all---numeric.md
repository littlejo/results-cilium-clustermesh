Endpoint ID: 502
Path: /sys/fs/bpf/tc/globals/cilium_policy_00502

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11508851   116283    0        
Allow    Ingress     1          ANY          NONE         disabled    11183047   118339    0        
Allow    Egress      0          ANY          NONE         disabled    15203990   148230    0        


Endpoint ID: 932
Path: /sys/fs/bpf/tc/globals/cilium_policy_00932

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    109594   1253      0        
Allow    Egress      0          ANY          NONE         disabled    16421    176       0        


Endpoint ID: 1502
Path: /sys/fs/bpf/tc/globals/cilium_policy_01502

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    109990   1259      0        
Allow    Egress      0          ANY          NONE         disabled    17352    188       0        


Endpoint ID: 1749
Path: /sys/fs/bpf/tc/globals/cilium_policy_01749

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1652038   20836     0        
Allow    Ingress     1          ANY          NONE         disabled    18038     214       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2711
Path: /sys/fs/bpf/tc/globals/cilium_policy_02711

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


