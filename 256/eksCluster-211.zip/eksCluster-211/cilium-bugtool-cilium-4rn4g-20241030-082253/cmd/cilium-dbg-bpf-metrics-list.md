REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37678     2991652     677    bpf_overlay.c
Interface                 INGRESS     672587    135951543   1132   bpf_host.c
Success                   EGRESS      17560     1389362     1694   bpf_host.c
Success                   EGRESS      290489    35745065    1308   bpf_lxc.c
Success                   EGRESS      38690     3063406     53     encap.h
Success                   INGRESS     333633    37926744    86     l3.h
Success                   INGRESS     354401    39573010    235    trace.h
Unsupported L3 protocol   EGRESS      39        2902        1492   bpf_lxc.c
