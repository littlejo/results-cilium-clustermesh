markdown output at /tmp/cilium-bugtool-20241030-082254.403+0000-UTC-2418625880/cmd/cilium-debuginfo-20241030-082325.493+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082254.403+0000-UTC-2418625880/cmd/cilium-debuginfo-20241030-082325.493+0000-UTC.json
