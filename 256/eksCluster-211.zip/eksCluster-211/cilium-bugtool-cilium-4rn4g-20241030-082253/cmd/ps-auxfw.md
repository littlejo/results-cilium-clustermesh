USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         672  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         658  0.0  0.0 1228744 3716 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         642  0.0  0.0 1228744 3660 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         636  2.0  0.1 1240432 15856 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         681  0.0  0.0   6408  1644 ?        R    08:22   0:00  \_ ps auxfw
root         683  0.0  0.0   1756     4 ?        R    08:22   0:00  \_ bash -c hostname
root         624  0.0  0.0 1228744 3780 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  4.5  4.8 1606016 386388 ?      Ssl  08:03   0:51 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.0  0.0 1229744 7912 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
