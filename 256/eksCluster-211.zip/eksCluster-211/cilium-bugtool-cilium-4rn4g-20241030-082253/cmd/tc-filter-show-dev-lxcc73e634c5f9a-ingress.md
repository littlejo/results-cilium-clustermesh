filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc73e634c5f9a direct-action not_in_hw id 645 tag a7d7acf1b6a7f897 jited 
