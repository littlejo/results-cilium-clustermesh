alloc: 178.50MB (187175376 bytes)
total-alloc: 2.36GB (2530093976 bytes)
sys: 328.71MB (344674660 bytes)
lookups: 0
mallocs: 65135788
frees: 63387616
heap-alloc: 178.50MB (187175376 bytes)
heap-sys: 251.48MB (263700480 bytes)
heap-idle: 45.18MB (47374336 bytes)
heap-in-use: 206.30MB (216326144 bytes)
heap-released: 5.12MB (5365760 bytes)
heap-objects: 1748172
stack-in-use: 64.47MB (67600384 bytes)
stack-sys: 64.47MB (67600384 bytes)
stack-mspan-inuse: 3.23MB (3387680 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1002.53KB (1026593 bytes)
gc-sys: 5.98MB (6274608 bytes)
next-gc: when heap-alloc >= 216.78MB (227308968 bytes)
last-gc: 2024-10-30 08:23:00.219657907 +0000 UTC
gc-pause-total: 17.552286ms
gc-pause: 78548
gc-pause-end: 1730276580219657907
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0006227355801677341
enable-gc: true
debug-gc: false
