[
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5ccd1247_4e05_437e_abd8_1dde48dca6e5.slice/cri-containerd-3f92b0229c2e16ace02e6f43dc306dbc8bc07850af58631fa3f7e012df634778.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5ccd1247_4e05_437e_abd8_1dde48dca6e5.slice/cri-containerd-db00f4ae51d313c962dbae2c988acaeb4723dfb17196b5935a50ca1acc5eaf41.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5ccd1247_4e05_437e_abd8_1dde48dca6e5.slice/cri-containerd-10d4f95ee6c75bc6675c53dd30ed6e0ee1aaf9e5adf0e6e4249965be9b18f377.scope"
      }
    ],
    "ips": [
      "10.211.0.202"
    ],
    "name": "clustermesh-apiserver-547d8c58dc-qdmx9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1274741e_22aa_45c5_b434_74e9144faa27.slice/cri-containerd-c53d001b930ea4943b974c770541dfba74870a1ccd5c18a84127bc480e7c7a5f.scope"
      }
    ],
    "ips": [
      "10.211.0.219"
    ],
    "name": "coredns-cc6ccd49c-bv5dx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod855bc909_b2cd_4f4e_9d6c_970ddc37515a.slice/cri-containerd-1ea8904a4a9bacb9849708b175c39403e04fd7429d6b75f04e189ceab7b30216.scope"
      }
    ],
    "ips": [
      "10.211.0.126"
    ],
    "name": "coredns-cc6ccd49c-lkkr7",
    "namespace": "kube-system"
  }
]

