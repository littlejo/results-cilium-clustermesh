{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:49.658Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.145.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:49.658Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.159.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:49.658Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:54.302Z",
  "value": "id=1254  sec_id=4     flags=0x0000 ifindex=10  mac=02:13:3B:FD:15:7E nodemac=FA:C2:E3:B6:0E:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:54.312Z",
  "value": "id=526   sec_id=645524 flags=0x0000 ifindex=12  mac=06:B3:88:6E:6A:03 nodemac=16:16:F8:8F:EF:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:54.363Z",
  "value": "id=3356  sec_id=645524 flags=0x0000 ifindex=14  mac=6A:C1:F3:2F:01:AB nodemac=7A:3D:42:CF:B9:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:54.432Z",
  "value": "id=1254  sec_id=4     flags=0x0000 ifindex=10  mac=02:13:3B:FD:15:7E nodemac=FA:C2:E3:B6:0E:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:54.493Z",
  "value": "id=526   sec_id=645524 flags=0x0000 ifindex=12  mac=06:B3:88:6E:6A:03 nodemac=16:16:F8:8F:EF:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:10.247Z",
  "value": "id=3356  sec_id=645524 flags=0x0000 ifindex=14  mac=6A:C1:F3:2F:01:AB nodemac=7A:3D:42:CF:B9:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:10.247Z",
  "value": "id=1254  sec_id=4     flags=0x0000 ifindex=10  mac=02:13:3B:FD:15:7E nodemac=FA:C2:E3:B6:0E:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:10.248Z",
  "value": "id=526   sec_id=645524 flags=0x0000 ifindex=12  mac=06:B3:88:6E:6A:03 nodemac=16:16:F8:8F:EF:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:10.277Z",
  "value": "id=207   sec_id=650680 flags=0x0000 ifindex=16  mac=7A:2D:C4:CD:FD:F4 nodemac=AA:70:26:C5:50:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:10.278Z",
  "value": "id=207   sec_id=650680 flags=0x0000 ifindex=16  mac=7A:2D:C4:CD:FD:F4 nodemac=AA:70:26:C5:50:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.282Z",
  "value": "id=1113  sec_id=650680 flags=0x0000 ifindex=18  mac=2A:49:66:40:04:2F nodemac=72:F5:D2:22:F5:FC"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.18.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.726Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.148Z",
  "value": "id=1254  sec_id=4     flags=0x0000 ifindex=10  mac=02:13:3B:FD:15:7E nodemac=FA:C2:E3:B6:0E:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.149Z",
  "value": "id=526   sec_id=645524 flags=0x0000 ifindex=12  mac=06:B3:88:6E:6A:03 nodemac=16:16:F8:8F:EF:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.149Z",
  "value": "id=3356  sec_id=645524 flags=0x0000 ifindex=14  mac=6A:C1:F3:2F:01:AB nodemac=7A:3D:42:CF:B9:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.149Z",
  "value": "id=1113  sec_id=650680 flags=0x0000 ifindex=18  mac=2A:49:66:40:04:2F nodemac=72:F5:D2:22:F5:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.152Z",
  "value": "id=1254  sec_id=4     flags=0x0000 ifindex=10  mac=02:13:3B:FD:15:7E nodemac=FA:C2:E3:B6:0E:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.157Z",
  "value": "id=526   sec_id=645524 flags=0x0000 ifindex=12  mac=06:B3:88:6E:6A:03 nodemac=16:16:F8:8F:EF:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.157Z",
  "value": "id=3356  sec_id=645524 flags=0x0000 ifindex=14  mac=6A:C1:F3:2F:01:AB nodemac=7A:3D:42:CF:B9:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.158Z",
  "value": "id=1113  sec_id=650680 flags=0x0000 ifindex=18  mac=2A:49:66:40:04:2F nodemac=72:F5:D2:22:F5:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:56.149Z",
  "value": "id=1113  sec_id=650680 flags=0x0000 ifindex=18  mac=2A:49:66:40:04:2F nodemac=72:F5:D2:22:F5:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:56.150Z",
  "value": "id=1254  sec_id=4     flags=0x0000 ifindex=10  mac=02:13:3B:FD:15:7E nodemac=FA:C2:E3:B6:0E:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:56.150Z",
  "value": "id=526   sec_id=645524 flags=0x0000 ifindex=12  mac=06:B3:88:6E:6A:03 nodemac=16:16:F8:8F:EF:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:56.150Z",
  "value": "id=3356  sec_id=645524 flags=0x0000 ifindex=14  mac=6A:C1:F3:2F:01:AB nodemac=7A:3D:42:CF:B9:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.149Z",
  "value": "id=1254  sec_id=4     flags=0x0000 ifindex=10  mac=02:13:3B:FD:15:7E nodemac=FA:C2:E3:B6:0E:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.150Z",
  "value": "id=1113  sec_id=650680 flags=0x0000 ifindex=18  mac=2A:49:66:40:04:2F nodemac=72:F5:D2:22:F5:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.150Z",
  "value": "id=526   sec_id=645524 flags=0x0000 ifindex=12  mac=06:B3:88:6E:6A:03 nodemac=16:16:F8:8F:EF:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.18.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.150Z",
  "value": "id=3356  sec_id=645524 flags=0x0000 ifindex=14  mac=6A:C1:F3:2F:01:AB nodemac=7A:3D:42:CF:B9:63"
}

