[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca3a55c1_d68c_4019_8cae_56f216fdc1cb.slice/cri-containerd-f0462dc814f05f56ed19d674f69c142a78cb0ae96c90233cfe70aea1f6bb1deb.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca3a55c1_d68c_4019_8cae_56f216fdc1cb.slice/cri-containerd-9ca01f5e566a477f5e3db5bc3e65371e58ef74502257dba29d4c914d72b3ba6c.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca3a55c1_d68c_4019_8cae_56f216fdc1cb.slice/cri-containerd-1b711689b53c45b0cad835ac7aa60bb68cf5cb1843b74126551bc640385e7265.scope"
      }
    ],
    "ips": [
      "10.18.0.25"
    ],
    "name": "clustermesh-apiserver-54d74d7ccf-xbb64",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45790c74_06d2_4fb5_b893_a25b7b48ef67.slice/cri-containerd-5dc412f34cbc774a5194b246343bf5c0968148c4db1c5c2f08c9f2081b87b036.scope"
      }
    ],
    "ips": [
      "10.18.0.146"
    ],
    "name": "coredns-cc6ccd49c-n2rmp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda9aa20cd_a7b9_4be7_92c2_5b0c292427b4.slice/cri-containerd-526634f6e7a1fe08085d2830e2bf03432150f7d5dd637d205c900d0579d77df1.scope"
      }
    ],
    "ips": [
      "10.18.0.160"
    ],
    "name": "coredns-cc6ccd49c-jghpl",
    "namespace": "kube-system"
  }
]

