xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 577
ens6(5) clsact/ingress cil_from_netdev-ens6 id 581
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 570
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 564
cilium_host(7) clsact/egress cil_from_host-cilium_host id 563
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 528
lxc4ab0d9835a1f(12) clsact/ingress cil_from_container-lxc4ab0d9835a1f id 542
lxc745518528b82(14) clsact/ingress cil_from_container-lxc745518528b82 id 513
lxc6affd39a0558(18) clsact/ingress cil_from_container-lxc6affd39a0558 id 634

flow_dissector:

netfilter:

