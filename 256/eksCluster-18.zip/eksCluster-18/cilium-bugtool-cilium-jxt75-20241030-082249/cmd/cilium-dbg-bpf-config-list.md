KEY             VALUE
AgentLiveness   2261218245143
UTimeOffset     3379442072265625
