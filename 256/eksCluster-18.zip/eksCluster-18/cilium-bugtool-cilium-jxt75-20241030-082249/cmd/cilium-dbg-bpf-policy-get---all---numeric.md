Endpoint ID: 526
Path: /sys/fs/bpf/tc/globals/cilium_policy_00526

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    177714   2050      0        
Allow    Egress      0          ANY          NONE         disabled    22064    247       0        


Endpoint ID: 1113
Path: /sys/fs/bpf/tc/globals/cilium_policy_01113

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11532520   115095    0        
Allow    Ingress     1          ANY          NONE         disabled    9906052    104197    0        
Allow    Egress      0          ANY          NONE         disabled    12810107   126242    0        


Endpoint ID: 1254
Path: /sys/fs/bpf/tc/globals/cilium_policy_01254

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1640665   20769     0        
Allow    Ingress     1          ANY          NONE         disabled    25880     302       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2233
Path: /sys/fs/bpf/tc/globals/cilium_policy_02233

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3356
Path: /sys/fs/bpf/tc/globals/cilium_policy_03356

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    175074   2010      0        
Allow    Egress      0          ANY          NONE         disabled    20949    233       0        


