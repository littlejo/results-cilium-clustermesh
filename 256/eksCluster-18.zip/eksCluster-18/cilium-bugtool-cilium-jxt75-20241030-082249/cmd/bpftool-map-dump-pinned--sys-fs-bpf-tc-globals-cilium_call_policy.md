key: 0e 02 00 00  value: 1d 02 00 00
key: 59 04 00 00  value: 7c 02 00 00
key: e6 04 00 00  value: 0d 02 00 00
key: 1c 0d 00 00  value: 04 02 00 00
Found 4 elements
