USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         707  0.0  0.0   2208   776 ?        Ss   08:22   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         713  0.0  0.2 1243764 18856 ?       Sl   08:22   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root         693  0.0  0.2 1240432 16664 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         720  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         669  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.0  4.8 1606080 390288 ?      Ssl  07:52   0:54 cilium-agent --config-dir=/tmp/cilium/config-map
root         407  0.0  0.1 1229744 8036 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
