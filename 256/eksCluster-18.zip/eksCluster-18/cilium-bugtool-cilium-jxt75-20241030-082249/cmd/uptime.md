 08:22:51 up 37 min,  0 users,  load average: 1.05, 0.41, 0.22
