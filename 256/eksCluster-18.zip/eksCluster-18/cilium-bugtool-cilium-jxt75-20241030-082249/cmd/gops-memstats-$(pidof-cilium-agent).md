alloc: 100.10MB (104960584 bytes)
total-alloc: 2.29GB (2454724800 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 63857829
frees: 63128953
heap-alloc: 100.10MB (104960584 bytes)
heap-sys: 247.88MB (259923968 bytes)
heap-idle: 88.89MB (93208576 bytes)
heap-in-use: 158.99MB (166715392 bytes)
heap-released: 888.00KB (909312 bytes)
heap-objects: 728876
stack-in-use: 60.09MB (63012864 bytes)
stack-sys: 60.09MB (63012864 bytes)
stack-mspan-inuse: 2.73MB (2866080 bytes)
stack-mspan-sys: 3.78MB (3965760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.03MB (1080113 bytes)
gc-sys: 6.00MB (6286800 bytes)
next-gc: when heap-alloc >= 212.16MB (222461496 bytes)
last-gc: 2024-10-30 08:23:16.669482808 +0000 UTC
gc-pause-total: 15.810673ms
gc-pause: 121840
gc-pause-end: 1730276596669482808
num-gc: 87
num-forced-gc: 0
gc-cpu-fraction: 0.0003622872465872314
enable-gc: true
debug-gc: false
