IP ADDRESS         LOCAL ENDPOINT INFO
10.18.0.25:0       id=1113  sec_id=650680 flags=0x0000 ifindex=18  mac=2A:49:66:40:04:2F nodemac=72:F5:D2:22:F5:FC   
10.18.0.87:0       id=1254  sec_id=4     flags=0x0000 ifindex=10  mac=02:13:3B:FD:15:7E nodemac=FA:C2:E3:B6:0E:BA    
10.18.0.58:0       (localhost)                                                                                       
172.31.145.191:0   (localhost)                                                                                       
10.18.0.160:0      id=526   sec_id=645524 flags=0x0000 ifindex=12  mac=06:B3:88:6E:6A:03 nodemac=16:16:F8:8F:EF:12   
172.31.159.147:0   (localhost)                                                                                       
10.18.0.146:0      id=3356  sec_id=645524 flags=0x0000 ifindex=14  mac=6A:C1:F3:2F:01:AB nodemac=7A:3D:42:CF:B9:63   
