1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:fc:0a:a2:9f:05 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.159.147/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3179sec preferred_lft 3179sec
    inet6 fe80::4fc:aff:fea2:9f05/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:3b:68:be:bd:d5 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.145.191/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::43b:68ff:febe:bdd5/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:d6:79:bc:40:44 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::dcd6:79ff:febc:4044/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:ba:1d:42:f2:96 brd ff:ff:ff:ff:ff:ff
    inet 10.18.0.58/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::ccba:1dff:fe42:f296/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether e6:6d:45:33:99:44 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e46d:45ff:fe33:9944/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:c2:e3:b6:0e:ba brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f8c2:e3ff:feb6:eba/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc4ab0d9835a1f@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:16:f8:8f:ef:12 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::1416:f8ff:fe8f:ef12/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc745518528b82@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:3d:42:cf:b9:63 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::783d:42ff:fecf:b963/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc6affd39a0558@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:f5:d2:22:f5:fc brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::70f5:d2ff:fe22:f5fc/64 scope link 
       valid_lft forever preferred_lft forever
