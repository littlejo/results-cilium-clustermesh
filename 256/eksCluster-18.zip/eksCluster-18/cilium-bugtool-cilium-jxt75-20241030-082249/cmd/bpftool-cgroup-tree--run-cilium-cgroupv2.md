CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda9aa20cd_a7b9_4be7_92c2_5b0c292427b4.slice/cri-containerd-fdcb940d5a9d5e0ca7e3b5497b5f1659264db7e512fe32a98bac97042ef18c74.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda9aa20cd_a7b9_4be7_92c2_5b0c292427b4.slice/cri-containerd-526634f6e7a1fe08085d2830e2bf03432150f7d5dd637d205c900d0579d77df1.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5839f37f_2bf7_4480_ad9f_5ddc92214cc8.slice/cri-containerd-6844e3dc188462f802717d17944fadbc72ab06bb7793cc51118d0e795c73d7d4.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5839f37f_2bf7_4480_ad9f_5ddc92214cc8.slice/cri-containerd-5142bd24357e7f0e3851afe55ded3b0343144f5f76d518e5bac0a1c222833f15.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9b40a8b5_edc8_4838_91c4_2407840c0f7e.slice/cri-containerd-7c2edf5e0474936deee8a0f62892d398ccff52b3ba809f5d2f591af81512b1f9.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9b40a8b5_edc8_4838_91c4_2407840c0f7e.slice/cri-containerd-14eb7a385c3116fa8ce7de32b862133ce2fcdeccb6f143b5ad6ea964581f4058.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45790c74_06d2_4fb5_b893_a25b7b48ef67.slice/cri-containerd-5dc412f34cbc774a5194b246343bf5c0968148c4db1c5c2f08c9f2081b87b036.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45790c74_06d2_4fb5_b893_a25b7b48ef67.slice/cri-containerd-ea8e68ff65a86b5953523ebca1ae80d4e36fdb2a45b41d4021e3f8382b429bdb.scope
    547      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca3a55c1_d68c_4019_8cae_56f216fdc1cb.slice/cri-containerd-c38f3823edac107ea84504ebdf6eba3fdc4658276c13a0f4f89a6e36f3496979.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca3a55c1_d68c_4019_8cae_56f216fdc1cb.slice/cri-containerd-f0462dc814f05f56ed19d674f69c142a78cb0ae96c90233cfe70aea1f6bb1deb.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca3a55c1_d68c_4019_8cae_56f216fdc1cb.slice/cri-containerd-9ca01f5e566a477f5e3db5bc3e65371e58ef74502257dba29d4c914d72b3ba6c.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca3a55c1_d68c_4019_8cae_56f216fdc1cb.slice/cri-containerd-1b711689b53c45b0cad835ac7aa60bb68cf5cb1843b74126551bc640385e7265.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc9fa1c96_34c5_4535_a152_c8014a9ca5dc.slice/cri-containerd-c6405659f26b46541de01cbf8892250b09cda8d380a4fb4c090187f0d8d081dc.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc9fa1c96_34c5_4535_a152_c8014a9ca5dc.slice/cri-containerd-2e3c06d62d5cbb998f7441a7145c0dba5629598565c74011d4458ea0512b63bc.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7647fa33_0f06_42e9_a7d1_0cb3995161b7.slice/cri-containerd-fae6d3ee83af02fe0bd95035367df38cf196b5f80d4ad73e3240c3f5d5d40e94.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7647fa33_0f06_42e9_a7d1_0cb3995161b7.slice/cri-containerd-06fe804e341f1f9bad99ce566cedeccce27e7f4c0c8126d381bd867c96b9271b.scope
    109      cgroup_device   multi                                          
