REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35297     2787577     677    bpf_overlay.c
Interface                 INGRESS     639004    131971938   1132   bpf_host.c
Success                   EGRESS      15260     1197322     1694   bpf_host.c
Success                   EGRESS      271692    33875728    1308   bpf_lxc.c
Success                   EGRESS      34904     2761821     53     encap.h
Success                   INGRESS     313580    35315208    86     l3.h
Success                   INGRESS     334268    36949509    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
