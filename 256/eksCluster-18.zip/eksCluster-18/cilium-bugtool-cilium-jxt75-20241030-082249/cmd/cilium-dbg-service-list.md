ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.215.80:443 (active)     
                                          2 => 172.31.167.29:443 (active)     
2    10.100.19.186:443     ClusterIP      1 => 172.31.159.147:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.18.0.146:53 (active)        
                                          2 => 10.18.0.160:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.18.0.146:9153 (active)      
                                          2 => 10.18.0.160:9153 (active)      
5    10.100.176.127:2379   ClusterIP      1 => 10.18.0.25:2379 (active)       
