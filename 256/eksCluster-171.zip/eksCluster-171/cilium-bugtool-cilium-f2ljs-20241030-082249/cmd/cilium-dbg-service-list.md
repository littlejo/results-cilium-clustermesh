ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.152.132:443 (active)    
                                          2 => 172.31.200.212:443 (active)    
2    10.100.142.2:443      ClusterIP      1 => 172.31.197.244:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.171.0.226:53 (active)       
                                          2 => 10.171.0.211:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.171.0.226:9153 (active)     
                                          2 => 10.171.0.211:9153 (active)     
5    10.100.220.103:2379   ClusterIP      1 => 10.171.0.30:2379 (active)      
