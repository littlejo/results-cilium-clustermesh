 08:22:50 up 31 min,  0 users,  load average: 0.10, 0.17, 0.17
