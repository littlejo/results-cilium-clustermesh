IP ADDRESS         LOCAL ENDPOINT INFO
10.171.0.30:0      id=3741  sec_id=5636128 flags=0x0000 ifindex=18  mac=86:34:AC:AE:1C:09 nodemac=2E:D3:1B:D7:55:E2   
10.171.0.211:0     id=220   sec_id=5663266 flags=0x0000 ifindex=14  mac=76:4D:62:F1:E2:39 nodemac=BA:9B:D4:90:26:AD   
172.31.197.244:0   (localhost)                                                                                        
10.171.0.216:0     (localhost)                                                                                        
10.171.0.175:0     id=56    sec_id=4     flags=0x0000 ifindex=10  mac=D2:CD:F9:D7:F3:7F nodemac=EA:74:56:59:42:BC     
10.171.0.226:0     id=3354  sec_id=5663266 flags=0x0000 ifindex=12  mac=8E:56:28:24:D2:87 nodemac=12:16:C8:99:1C:55   
172.31.224.126:0   (localhost)                                                                                        
