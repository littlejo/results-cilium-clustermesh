KEY             VALUE
AgentLiveness   1918341626282
UTimeOffset     3379442689453125
