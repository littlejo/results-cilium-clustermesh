[
  {
    "containers": [
      {
        "cgroup-id": 9352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2427a190_6937_455a_b6c7_4d60fb1db4d9.slice/cri-containerd-8107048589ac690529008a85125edb417077f3a176a567f138c85d74d92eaa7b.scope"
      },
      {
        "cgroup-id": 9268,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2427a190_6937_455a_b6c7_4d60fb1db4d9.slice/cri-containerd-1738f4b55a50b0f9671d89f8d8e856a84be59a5c4af01b26b1464da4856fc546.scope"
      },
      {
        "cgroup-id": 9184,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2427a190_6937_455a_b6c7_4d60fb1db4d9.slice/cri-containerd-22ec7dd117dc33cef2023957fccec69d79c8193813314dbdee0eb67983185e12.scope"
      }
    ],
    "ips": [
      "10.171.0.30"
    ],
    "name": "clustermesh-apiserver-545d5b77ff-x88xc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ab98bd3_8882_40fb_acc8_ce7fb26b5da3.slice/cri-containerd-06ed5373a94d7d79fa59f9be51d66ef260043af8f7da526f24d6344822f9741c.scope"
      }
    ],
    "ips": [
      "10.171.0.211"
    ],
    "name": "coredns-cc6ccd49c-lxqq4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0b7eec1c_a20e_484c_9114_6f7c69b57814.slice/cri-containerd-6b28ac7471eb07ac5566765671e948743e8ef2223bd284ac9974e6eeac5ea999.scope"
      }
    ],
    "ips": [
      "10.171.0.226"
    ],
    "name": "coredns-cc6ccd49c-zz2fs",
    "namespace": "kube-system"
  }
]

