REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34476     2728100     677    bpf_overlay.c
Interface                 INGRESS     589192    124039848   1132   bpf_host.c
Success                   EGRESS      15210     1194318     1694   bpf_host.c
Success                   EGRESS      246744    30864652    1308   bpf_lxc.c
Success                   EGRESS      34285     2713298     53     encap.h
Success                   INGRESS     288148    31697991    86     l3.h
Success                   INGRESS     308065    33275819    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
