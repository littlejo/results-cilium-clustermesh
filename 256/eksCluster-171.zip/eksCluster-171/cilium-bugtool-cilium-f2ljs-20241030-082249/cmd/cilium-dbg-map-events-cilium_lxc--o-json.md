{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:30.783Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.197.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:30.783Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.224.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:30.783Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:35.442Z",
  "value": "id=3354  sec_id=5663266 flags=0x0000 ifindex=12  mac=8E:56:28:24:D2:87 nodemac=12:16:C8:99:1C:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:35.443Z",
  "value": "id=56    sec_id=4     flags=0x0000 ifindex=10  mac=D2:CD:F9:D7:F3:7F nodemac=EA:74:56:59:42:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:35.516Z",
  "value": "id=220   sec_id=5663266 flags=0x0000 ifindex=14  mac=76:4D:62:F1:E2:39 nodemac=BA:9B:D4:90:26:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:35.559Z",
  "value": "id=3354  sec_id=5663266 flags=0x0000 ifindex=12  mac=8E:56:28:24:D2:87 nodemac=12:16:C8:99:1C:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:35.607Z",
  "value": "id=56    sec_id=4     flags=0x0000 ifindex=10  mac=D2:CD:F9:D7:F3:7F nodemac=EA:74:56:59:42:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:15.927Z",
  "value": "id=220   sec_id=5663266 flags=0x0000 ifindex=14  mac=76:4D:62:F1:E2:39 nodemac=BA:9B:D4:90:26:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:15.927Z",
  "value": "id=3354  sec_id=5663266 flags=0x0000 ifindex=12  mac=8E:56:28:24:D2:87 nodemac=12:16:C8:99:1C:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:15.928Z",
  "value": "id=56    sec_id=4     flags=0x0000 ifindex=10  mac=D2:CD:F9:D7:F3:7F nodemac=EA:74:56:59:42:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:15.961Z",
  "value": "id=1332  sec_id=5636128 flags=0x0000 ifindex=16  mac=EA:27:35:28:F1:B3 nodemac=2A:4D:B2:CD:AE:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:16.927Z",
  "value": "id=3354  sec_id=5663266 flags=0x0000 ifindex=12  mac=8E:56:28:24:D2:87 nodemac=12:16:C8:99:1C:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:16.927Z",
  "value": "id=56    sec_id=4     flags=0x0000 ifindex=10  mac=D2:CD:F9:D7:F3:7F nodemac=EA:74:56:59:42:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:16.928Z",
  "value": "id=220   sec_id=5663266 flags=0x0000 ifindex=14  mac=76:4D:62:F1:E2:39 nodemac=BA:9B:D4:90:26:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:16.928Z",
  "value": "id=1332  sec_id=5636128 flags=0x0000 ifindex=16  mac=EA:27:35:28:F1:B3 nodemac=2A:4D:B2:CD:AE:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.679Z",
  "value": "id=3741  sec_id=5636128 flags=0x0000 ifindex=18  mac=86:34:AC:AE:1C:09 nodemac=2E:D3:1B:D7:55:E2"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.171.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.130Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.668Z",
  "value": "id=56    sec_id=4     flags=0x0000 ifindex=10  mac=D2:CD:F9:D7:F3:7F nodemac=EA:74:56:59:42:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.668Z",
  "value": "id=3354  sec_id=5663266 flags=0x0000 ifindex=12  mac=8E:56:28:24:D2:87 nodemac=12:16:C8:99:1C:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.669Z",
  "value": "id=220   sec_id=5663266 flags=0x0000 ifindex=14  mac=76:4D:62:F1:E2:39 nodemac=BA:9B:D4:90:26:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.669Z",
  "value": "id=3741  sec_id=5636128 flags=0x0000 ifindex=18  mac=86:34:AC:AE:1C:09 nodemac=2E:D3:1B:D7:55:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.667Z",
  "value": "id=3354  sec_id=5663266 flags=0x0000 ifindex=12  mac=8E:56:28:24:D2:87 nodemac=12:16:C8:99:1C:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.668Z",
  "value": "id=3741  sec_id=5636128 flags=0x0000 ifindex=18  mac=86:34:AC:AE:1C:09 nodemac=2E:D3:1B:D7:55:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.668Z",
  "value": "id=220   sec_id=5663266 flags=0x0000 ifindex=14  mac=76:4D:62:F1:E2:39 nodemac=BA:9B:D4:90:26:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.669Z",
  "value": "id=56    sec_id=4     flags=0x0000 ifindex=10  mac=D2:CD:F9:D7:F3:7F nodemac=EA:74:56:59:42:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.668Z",
  "value": "id=3354  sec_id=5663266 flags=0x0000 ifindex=12  mac=8E:56:28:24:D2:87 nodemac=12:16:C8:99:1C:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.668Z",
  "value": "id=56    sec_id=4     flags=0x0000 ifindex=10  mac=D2:CD:F9:D7:F3:7F nodemac=EA:74:56:59:42:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.669Z",
  "value": "id=3741  sec_id=5636128 flags=0x0000 ifindex=18  mac=86:34:AC:AE:1C:09 nodemac=2E:D3:1B:D7:55:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.669Z",
  "value": "id=220   sec_id=5663266 flags=0x0000 ifindex=14  mac=76:4D:62:F1:E2:39 nodemac=BA:9B:D4:90:26:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.668Z",
  "value": "id=56    sec_id=4     flags=0x0000 ifindex=10  mac=D2:CD:F9:D7:F3:7F nodemac=EA:74:56:59:42:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.668Z",
  "value": "id=3741  sec_id=5636128 flags=0x0000 ifindex=18  mac=86:34:AC:AE:1C:09 nodemac=2E:D3:1B:D7:55:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.669Z",
  "value": "id=3354  sec_id=5663266 flags=0x0000 ifindex=12  mac=8E:56:28:24:D2:87 nodemac=12:16:C8:99:1C:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.171.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.669Z",
  "value": "id=220   sec_id=5663266 flags=0x0000 ifindex=14  mac=76:4D:62:F1:E2:39 nodemac=BA:9B:D4:90:26:AD"
}

