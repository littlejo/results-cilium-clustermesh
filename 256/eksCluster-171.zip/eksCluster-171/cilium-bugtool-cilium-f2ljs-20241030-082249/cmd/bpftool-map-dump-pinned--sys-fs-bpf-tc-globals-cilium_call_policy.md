key: 38 00 00 00  value: 18 02 00 00
key: dc 00 00 00  value: 01 02 00 00
key: 1a 0d 00 00  value: 09 02 00 00
key: 9d 0e 00 00  value: 76 02 00 00
Found 4 elements
