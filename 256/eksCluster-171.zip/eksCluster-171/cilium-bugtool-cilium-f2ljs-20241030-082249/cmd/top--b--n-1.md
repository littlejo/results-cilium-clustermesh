top - 08:22:50 up 31 min,  0 users,  load average: 0.10, 0.17, 0.17
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 30.0 us, 53.3 sy,  0.0 ni, 16.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4479.9 free,   1188.8 used,   2145.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6440.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 379512  79356 S  13.3   4.7   0:46.42 cilium-+
    646 root      20   0 1240432  15928  11164 S   6.7   0.2   0:00.03 cilium-+
    727 root      20   0 1243508  17480  12680 S   6.7   0.2   0:00.01 hubble
    392 root      20   0 1229744   7168   3056 S   0.0   0.1   0:01.14 cilium-+
    672 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    689 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    707 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    721 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
