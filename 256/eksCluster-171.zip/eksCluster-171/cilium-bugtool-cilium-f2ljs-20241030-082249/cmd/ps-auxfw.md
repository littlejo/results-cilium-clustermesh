USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         646  0.0  0.1 1240432 15928 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         660  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         662  0.0  0.0      0     0 ?        R    08:22   0:00  \_ [hostname]
root           1  3.5  4.7 1606080 379248 ?      Ssl  08:01   0:46 cilium-agent --config-dir=/tmp/cilium/config-map
root         392  0.0  0.0 1229744 7168 ?        Sl   08:01   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
