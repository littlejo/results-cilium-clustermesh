1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:40:5e:3c:8f:71 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.197.244/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3496sec preferred_lft 3496sec
    inet6 fe80::840:5eff:fe3c:8f71/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:77:e9:47:ab:93 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.224.126/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::877:e9ff:fe47:ab93/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:b1:57:b7:ab:38 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c0b1:57ff:feb7:ab38/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:de:80:b9:2a:dc brd ff:ff:ff:ff:ff:ff
    inet 10.171.0.216/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a4de:80ff:feb9:2adc/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 4a:56:39:b4:52:fa brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4856:39ff:feb4:52fa/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:74:56:59:42:bc brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::e874:56ff:fe59:42bc/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc6e03ead14c67@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:16:c8:99:1c:55 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::1016:c8ff:fe99:1c55/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc9cfb966a2469@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:9b:d4:90:26:ad brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b89b:d4ff:fe90:26ad/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc5f55dee4bbe3@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:d3:1b:d7:55:e2 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2cd3:1bff:fed7:55e2/64 scope link 
       valid_lft forever preferred_lft forever
