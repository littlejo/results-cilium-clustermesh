CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0b7eec1c_a20e_484c_9114_6f7c69b57814.slice/cri-containerd-6b28ac7471eb07ac5566765671e948743e8ef2223bd284ac9974e6eeac5ea999.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0b7eec1c_a20e_484c_9114_6f7c69b57814.slice/cri-containerd-f8e5aac558a4ad35cb0f33cf0958f1beba27a992c7927fa37adaa23d320df412.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ab98bd3_8882_40fb_acc8_ce7fb26b5da3.slice/cri-containerd-06ed5373a94d7d79fa59f9be51d66ef260043af8f7da526f24d6344822f9741c.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ab98bd3_8882_40fb_acc8_ce7fb26b5da3.slice/cri-containerd-82782536284fd8979e5316cee94f6755c1cd67e5faf783898e275d3a18ee4ee6.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcbb49278_d21d_4972_bb8d_d4ad8e5d4f1f.slice/cri-containerd-9509801cb84939086a06be80f9e4f7dc77a789992280756d33533cfe2df84cb7.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcbb49278_d21d_4972_bb8d_d4ad8e5d4f1f.slice/cri-containerd-a82c6fb5da8bed86a2ad58274207e4e1f76f4fa06a45a28467d936722a731e30.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbc244955_b170_46dc_8965_14aecf3fc11b.slice/cri-containerd-ad1bd15d6964181cf5f36832df4019e3f5c240f3681cdb53c761e74cce030e27.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbc244955_b170_46dc_8965_14aecf3fc11b.slice/cri-containerd-9322392da8b0fbc185f6ad593cd177ba552491a0eab22faca48b053e1f757d6a.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2427a190_6937_455a_b6c7_4d60fb1db4d9.slice/cri-containerd-e9c3415ffa2508d4920f44545d0aa1e29aa7e2d999c1f4046cc46d79e94bdd70.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2427a190_6937_455a_b6c7_4d60fb1db4d9.slice/cri-containerd-22ec7dd117dc33cef2023957fccec69d79c8193813314dbdee0eb67983185e12.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2427a190_6937_455a_b6c7_4d60fb1db4d9.slice/cri-containerd-8107048589ac690529008a85125edb417077f3a176a567f138c85d74d92eaa7b.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2427a190_6937_455a_b6c7_4d60fb1db4d9.slice/cri-containerd-1738f4b55a50b0f9671d89f8d8e856a84be59a5c4af01b26b1464da4856fc546.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc286a690_8256_4867_a046_c16e94ffe866.slice/cri-containerd-1cf1d6fa668d7538c2750eebddc98c245bae488ec2876330b071ca6f2f2ec77d.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc286a690_8256_4867_a046_c16e94ffe866.slice/cri-containerd-a8782eba59fdb95578504f302f2d6e3bd3b68a4f5d95c7a5794ce406b106bbb3.scope
    113      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd998008_be02_49b5_80c4_6379e2eab25f.slice/cri-containerd-8df03cd36b8a6ba3a8f78e4ac20aee98e73cec8f1fa447346011bb9a3bb37b91.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd998008_be02_49b5_80c4_6379e2eab25f.slice/cri-containerd-2572cbadccadd0690dc5bd6f92d3c3a0a9217611af020f46285e5b6ec566f108.scope
    93       cgroup_device   multi                                          
