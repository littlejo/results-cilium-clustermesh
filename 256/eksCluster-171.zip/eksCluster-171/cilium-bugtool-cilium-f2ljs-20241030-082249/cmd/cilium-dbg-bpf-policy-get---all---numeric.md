Endpoint ID: 56
Path: /sys/fs/bpf/tc/globals/cilium_policy_00056

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1581110   19957     0        
Allow    Ingress     1          ANY          NONE         disabled    18674     218       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 220
Path: /sys/fs/bpf/tc/globals/cilium_policy_00220

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    121480   1390      0        
Allow    Egress      0          ANY          NONE         disabled    17122    186       0        


Endpoint ID: 358
Path: /sys/fs/bpf/tc/globals/cilium_policy_00358

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3354
Path: /sys/fs/bpf/tc/globals/cilium_policy_03354

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    122470   1405      0        
Allow    Egress      0          ANY          NONE         disabled    16076    174       0        


Endpoint ID: 3741
Path: /sys/fs/bpf/tc/globals/cilium_policy_03741

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    10410533   104929    0        
Allow    Ingress     1          ANY          NONE         disabled    9319192    97627     0        
Allow    Egress      0          ANY          NONE         disabled    10600455   107443    0        


