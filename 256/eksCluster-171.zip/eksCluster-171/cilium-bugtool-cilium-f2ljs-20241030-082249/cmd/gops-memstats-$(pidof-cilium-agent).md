alloc: 155.23MB (162770784 bytes)
total-alloc: 2.11GB (2270873184 bytes)
sys: 312.77MB (327962980 bytes)
lookups: 0
mallocs: 61359023
frees: 59771092
heap-alloc: 155.23MB (162770784 bytes)
heap-sys: 235.38MB (246816768 bytes)
heap-idle: 55.13MB (57810944 bytes)
heap-in-use: 180.25MB (189005824 bytes)
heap-released: 1.97MB (2064384 bytes)
heap-objects: 1587931
stack-in-use: 64.59MB (67731456 bytes)
stack-sys: 64.59MB (67731456 bytes)
stack-mspan-inuse: 3.03MB (3181280 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.04MB (1085809 bytes)
gc-sys: 6.00MB (6290920 bytes)
next-gc: when heap-alloc >= 210.03MB (220236536 bytes)
last-gc: 2024-10-30 08:22:20.706285128 +0000 UTC
gc-pause-total: 17.78684ms
gc-pause: 184922
gc-pause-end: 1730276540706285128
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.00042058292343121324
enable-gc: true
debug-gc: false
