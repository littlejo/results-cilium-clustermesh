markdown output at /tmp/cilium-bugtool-20241030-082258.548+0000-UTC-1362745785/cmd/cilium-debuginfo-20241030-082329.763+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082258.548+0000-UTC-1362745785/cmd/cilium-debuginfo-20241030-082329.763+0000-UTC.json
