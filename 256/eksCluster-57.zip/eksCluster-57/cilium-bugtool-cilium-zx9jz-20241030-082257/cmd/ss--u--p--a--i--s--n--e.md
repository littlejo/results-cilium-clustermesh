Total: 671
TCP:   1843 (estab 427, closed 1397, orphaned 0, timewait 557)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  446       436       10       
INET	  456       442       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                   172.31.237.78%ens5:68         0.0.0.0:*    uid:192 ino:68073 sk:1001 cgroup:unreachable:c4e <->                            
UNCONN 0      0                            127.0.0.1:37109      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:30681 sk:1002 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:31404 sk:1003 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15505 sk:1004 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:31403 sk:1010 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15506 sk:1011 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::873:ceff:fe88:2e65]%ens5:546           [::]:*    uid:192 ino:16388 sk:1012 cgroup:unreachable:c4e v6only:1 <->                   
