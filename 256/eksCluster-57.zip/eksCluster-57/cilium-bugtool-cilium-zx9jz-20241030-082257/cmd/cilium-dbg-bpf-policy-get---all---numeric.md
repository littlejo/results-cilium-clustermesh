Endpoint ID: 111
Path: /sys/fs/bpf/tc/globals/cilium_policy_00111

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    169836   1952      0        
Allow    Egress      0          ANY          NONE         disabled    20783    234       0        


Endpoint ID: 151
Path: /sys/fs/bpf/tc/globals/cilium_policy_00151

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 865
Path: /sys/fs/bpf/tc/globals/cilium_policy_00865

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    170430   1961      0        
Allow    Egress      0          ANY          NONE         disabled    21670    243       0        


Endpoint ID: 1056
Path: /sys/fs/bpf/tc/globals/cilium_policy_01056

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11610730   116818    0        
Allow    Ingress     1          ANY          NONE         disabled    10951342   116050    0        
Allow    Egress      0          ANY          NONE         disabled    14591434   142704    0        


Endpoint ID: 3655
Path: /sys/fs/bpf/tc/globals/cilium_policy_03655

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1657252   20932     0        
Allow    Ingress     1          ANY          NONE         disabled    25694     301       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


