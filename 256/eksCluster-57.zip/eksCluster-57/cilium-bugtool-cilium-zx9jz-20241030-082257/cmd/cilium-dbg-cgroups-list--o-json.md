[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8b26197_2c61_425c_8e62_e95d93fbccff.slice/cri-containerd-27c2aae76380b2c744ddbdeebdab78e4a60778232ef53d3dcde2ff05966ef9e6.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8b26197_2c61_425c_8e62_e95d93fbccff.slice/cri-containerd-76c3afddd168072669799904becea27165b3c0ce09055cf6c11d2869053ded92.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8b26197_2c61_425c_8e62_e95d93fbccff.slice/cri-containerd-a5e8fef66a07d0afbe4b6e00f2917348288e79473e7aa31e63a4aa397f1aa544.scope"
      }
    ],
    "ips": [
      "10.57.0.132"
    ],
    "name": "clustermesh-apiserver-5967f9fcc6-vg6hr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03ee3c4e_ad7d_4b36_bcf2_5b62ff490c6c.slice/cri-containerd-1d5fc200553261de1f10d7e350c663a66175f76eeed75bd991759c2e37cdd098.scope"
      }
    ],
    "ips": [
      "10.57.0.188"
    ],
    "name": "coredns-cc6ccd49c-9dlbh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod51c12c97_b13d_4f4d_9b98_7989b923aa51.slice/cri-containerd-06aeda25618ea14d775c9d99722797a7ad380c482584d7d01a893af81d49ae59.scope"
      }
    ],
    "ips": [
      "10.57.0.215"
    ],
    "name": "coredns-cc6ccd49c-sr94r",
    "namespace": "kube-system"
  }
]

