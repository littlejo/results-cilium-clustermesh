CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a977bae_3c0d_4cea_84f1_78315ba9e8ea.slice/cri-containerd-c2f7fbfbe6cb189e83632778ef89cfa32ff884b4a50c647c9964415e47eb30d3.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a977bae_3c0d_4cea_84f1_78315ba9e8ea.slice/cri-containerd-d2f892169b28ba8ef98cea7195a72f0c8c1aa29b42c71fd35e0fc89582c9902f.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0d1d1cc9_80d7_4fe3_9c6b_64b7b0988937.slice/cri-containerd-0ce2f6e4febc96b054b2f9d4aa4e25ee4e91354d9a6990af4a72d81262a7901f.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0d1d1cc9_80d7_4fe3_9c6b_64b7b0988937.slice/cri-containerd-414424ec9c45feb82b8b6ab73f593c6e0445f78057b1f053baff1753c6a222ec.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03ee3c4e_ad7d_4b36_bcf2_5b62ff490c6c.slice/cri-containerd-71957edd543c9c828f2ddf02286be350efb74b07cf5b637f4f25634883024664.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03ee3c4e_ad7d_4b36_bcf2_5b62ff490c6c.slice/cri-containerd-1d5fc200553261de1f10d7e350c663a66175f76eeed75bd991759c2e37cdd098.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod51c12c97_b13d_4f4d_9b98_7989b923aa51.slice/cri-containerd-06aeda25618ea14d775c9d99722797a7ad380c482584d7d01a893af81d49ae59.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod51c12c97_b13d_4f4d_9b98_7989b923aa51.slice/cri-containerd-844261e66cb92569e1824d9f4277b4c45555ae11981e09a2624df7cee414bd07.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8b26197_2c61_425c_8e62_e95d93fbccff.slice/cri-containerd-a5e8fef66a07d0afbe4b6e00f2917348288e79473e7aa31e63a4aa397f1aa544.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8b26197_2c61_425c_8e62_e95d93fbccff.slice/cri-containerd-507b9426ed6d025046aea87984fa2996038156266c86cb5592a042628d5b6486.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8b26197_2c61_425c_8e62_e95d93fbccff.slice/cri-containerd-76c3afddd168072669799904becea27165b3c0ce09055cf6c11d2869053ded92.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8b26197_2c61_425c_8e62_e95d93fbccff.slice/cri-containerd-27c2aae76380b2c744ddbdeebdab78e4a60778232ef53d3dcde2ff05966ef9e6.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd74a32be_defa_4d51_b05f_b8c401bc2387.slice/cri-containerd-de5a16ffa6db69db855a7021ac3afe11f429f076cf7b77fe0942b293951a9310.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd74a32be_defa_4d51_b05f_b8c401bc2387.slice/cri-containerd-8f1d59690934b6b6841b87df64d82635e929e9230c11ac9e6ce178e67ed3c5f1.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod42d76c85_8f3e_46c3_9eaa_dea110dca942.slice/cri-containerd-7f8b547c5c057f3b4b15fc3830a5789eb248150046cb1505881abbb95387a080.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod42d76c85_8f3e_46c3_9eaa_dea110dca942.slice/cri-containerd-86a3635e72bcb65d4594e897371bde9b71a6a8a32b6491148ffc56b1619f41f3.scope
    94       cgroup_device   multi                                          
