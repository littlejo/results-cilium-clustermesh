{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:50.731Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.237.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:50.731Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.248.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:50.731Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:55.277Z",
  "value": "id=3655  sec_id=4     flags=0x0000 ifindex=10  mac=8A:E2:17:30:A0:16 nodemac=36:83:CC:24:77:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:55.283Z",
  "value": "id=865   sec_id=1922230 flags=0x0000 ifindex=12  mac=06:71:21:F7:2D:CA nodemac=7A:8A:DF:73:30:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:55.322Z",
  "value": "id=111   sec_id=1922230 flags=0x0000 ifindex=14  mac=BA:93:3F:98:E8:0A nodemac=A2:C4:A0:A7:6E:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:55.324Z",
  "value": "id=865   sec_id=1922230 flags=0x0000 ifindex=12  mac=06:71:21:F7:2D:CA nodemac=7A:8A:DF:73:30:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:55.345Z",
  "value": "id=3655  sec_id=4     flags=0x0000 ifindex=10  mac=8A:E2:17:30:A0:16 nodemac=36:83:CC:24:77:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:21.942Z",
  "value": "id=111   sec_id=1922230 flags=0x0000 ifindex=14  mac=BA:93:3F:98:E8:0A nodemac=A2:C4:A0:A7:6E:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:21.943Z",
  "value": "id=3655  sec_id=4     flags=0x0000 ifindex=10  mac=8A:E2:17:30:A0:16 nodemac=36:83:CC:24:77:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:21.943Z",
  "value": "id=865   sec_id=1922230 flags=0x0000 ifindex=12  mac=06:71:21:F7:2D:CA nodemac=7A:8A:DF:73:30:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:21.977Z",
  "value": "id=1765  sec_id=1900743 flags=0x0000 ifindex=16  mac=F2:C9:0D:DF:CE:79 nodemac=9A:67:DA:05:50:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:22.942Z",
  "value": "id=3655  sec_id=4     flags=0x0000 ifindex=10  mac=8A:E2:17:30:A0:16 nodemac=36:83:CC:24:77:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:22.942Z",
  "value": "id=1765  sec_id=1900743 flags=0x0000 ifindex=16  mac=F2:C9:0D:DF:CE:79 nodemac=9A:67:DA:05:50:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:22.943Z",
  "value": "id=865   sec_id=1922230 flags=0x0000 ifindex=12  mac=06:71:21:F7:2D:CA nodemac=7A:8A:DF:73:30:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:22.943Z",
  "value": "id=111   sec_id=1922230 flags=0x0000 ifindex=14  mac=BA:93:3F:98:E8:0A nodemac=A2:C4:A0:A7:6E:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:56.985Z",
  "value": "id=1056  sec_id=1900743 flags=0x0000 ifindex=18  mac=02:5F:58:F1:97:C7 nodemac=E6:7C:19:1A:78:7A"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.57.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.255Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.291Z",
  "value": "id=3655  sec_id=4     flags=0x0000 ifindex=10  mac=8A:E2:17:30:A0:16 nodemac=36:83:CC:24:77:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.292Z",
  "value": "id=865   sec_id=1922230 flags=0x0000 ifindex=12  mac=06:71:21:F7:2D:CA nodemac=7A:8A:DF:73:30:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.293Z",
  "value": "id=111   sec_id=1922230 flags=0x0000 ifindex=14  mac=BA:93:3F:98:E8:0A nodemac=A2:C4:A0:A7:6E:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.293Z",
  "value": "id=1056  sec_id=1900743 flags=0x0000 ifindex=18  mac=02:5F:58:F1:97:C7 nodemac=E6:7C:19:1A:78:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.288Z",
  "value": "id=1056  sec_id=1900743 flags=0x0000 ifindex=18  mac=02:5F:58:F1:97:C7 nodemac=E6:7C:19:1A:78:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.290Z",
  "value": "id=3655  sec_id=4     flags=0x0000 ifindex=10  mac=8A:E2:17:30:A0:16 nodemac=36:83:CC:24:77:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.291Z",
  "value": "id=865   sec_id=1922230 flags=0x0000 ifindex=12  mac=06:71:21:F7:2D:CA nodemac=7A:8A:DF:73:30:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.292Z",
  "value": "id=111   sec_id=1922230 flags=0x0000 ifindex=14  mac=BA:93:3F:98:E8:0A nodemac=A2:C4:A0:A7:6E:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.256Z",
  "value": "id=111   sec_id=1922230 flags=0x0000 ifindex=14  mac=BA:93:3F:98:E8:0A nodemac=A2:C4:A0:A7:6E:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.256Z",
  "value": "id=1056  sec_id=1900743 flags=0x0000 ifindex=18  mac=02:5F:58:F1:97:C7 nodemac=E6:7C:19:1A:78:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.256Z",
  "value": "id=3655  sec_id=4     flags=0x0000 ifindex=10  mac=8A:E2:17:30:A0:16 nodemac=36:83:CC:24:77:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.257Z",
  "value": "id=865   sec_id=1922230 flags=0x0000 ifindex=12  mac=06:71:21:F7:2D:CA nodemac=7A:8A:DF:73:30:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.257Z",
  "value": "id=3655  sec_id=4     flags=0x0000 ifindex=10  mac=8A:E2:17:30:A0:16 nodemac=36:83:CC:24:77:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.258Z",
  "value": "id=865   sec_id=1922230 flags=0x0000 ifindex=12  mac=06:71:21:F7:2D:CA nodemac=7A:8A:DF:73:30:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.258Z",
  "value": "id=111   sec_id=1922230 flags=0x0000 ifindex=14  mac=BA:93:3F:98:E8:0A nodemac=A2:C4:A0:A7:6E:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.258Z",
  "value": "id=1056  sec_id=1900743 flags=0x0000 ifindex=18  mac=02:5F:58:F1:97:C7 nodemac=E6:7C:19:1A:78:7A"
}

