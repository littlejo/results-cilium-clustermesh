alloc: 161.94MB (169801712 bytes)
total-alloc: 2.38GB (2560178904 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 65582659
frees: 63716927
heap-alloc: 161.94MB (169801712 bytes)
heap-sys: 251.32MB (263528448 bytes)
heap-idle: 61.91MB (64913408 bytes)
heap-in-use: 189.41MB (198615040 bytes)
heap-released: 7.51MB (7872512 bytes)
heap-objects: 1865732
stack-in-use: 64.66MB (67796992 bytes)
stack-sys: 64.66MB (67796992 bytes)
stack-mspan-inuse: 3.23MB (3386400 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1003.55KB (1027633 bytes)
gc-sys: 6.01MB (6297064 bytes)
next-gc: when heap-alloc >= 211.92MB (222209496 bytes)
last-gc: 2024-10-30 08:23:01.498494439 +0000 UTC
gc-pause-total: 15.488972ms
gc-pause: 114603
gc-pause-end: 1730276581498494439
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0004010656286418159
enable-gc: true
debug-gc: false
