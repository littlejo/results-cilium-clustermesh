ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.254.224:443 (active)   
                                          2 => 172.31.163.199:443 (active)   
2    10.100.120.25:443     ClusterIP      1 => 172.31.237.78:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.57.0.215:9153 (active)     
                                          2 => 10.57.0.188:9153 (active)     
4    10.100.0.10:53        ClusterIP      1 => 10.57.0.215:53 (active)       
                                          2 => 10.57.0.188:53 (active)       
5    10.100.145.107:2379   ClusterIP      1 => 10.57.0.132:2379 (active)     
