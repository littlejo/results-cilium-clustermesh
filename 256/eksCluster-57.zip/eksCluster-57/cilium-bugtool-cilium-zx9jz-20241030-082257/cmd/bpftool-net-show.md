xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 500
ens6(5) clsact/ingress cil_from_netdev-ens6 id 506
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 495
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 486
cilium_host(7) clsact/egress cil_from_host-cilium_host id 491
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 482
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 552
lxc5bc1bf121d88(12) clsact/ingress cil_from_container-lxc5bc1bf121d88 id 537
lxccf17046edfbe(14) clsact/ingress cil_from_container-lxccf17046edfbe id 541
lxcd3567dfd0e39(18) clsact/ingress cil_from_container-lxcd3567dfd0e39 id 613

flow_dissector:

netfilter:

