key: 6f 00 00 00  value: 20 02 00 00
key: 61 03 00 00  value: 12 02 00 00
key: 20 04 00 00  value: 66 02 00 00
key: 47 0e 00 00  value: 24 02 00 00
Found 4 elements
