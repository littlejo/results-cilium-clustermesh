1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:73:ce:88:2e:65 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.237.78/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3268sec preferred_lft 3268sec
    inet6 fe80::873:ceff:fe88:2e65/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:29:5d:b8:3a:f3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.248.14/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::829:5dff:feb8:3af3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:b4:aa:38:4a:95 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::14b4:aaff:fe38:4a95/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:bd:b7:54:f0:ce brd ff:ff:ff:ff:ff:ff
    inet 10.57.0.144/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::24bd:b7ff:fe54:f0ce/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether b6:ef:a7:c5:80:4b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b4ef:a7ff:fec5:804b/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:83:cc:24:77:d8 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::3483:ccff:fe24:77d8/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc5bc1bf121d88@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:8a:df:73:30:a5 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::788a:dfff:fe73:30a5/64 scope link 
       valid_lft forever preferred_lft forever
14: lxccf17046edfbe@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:c4:a0:a7:6e:fe brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a0c4:a0ff:fea7:6efe/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcd3567dfd0e39@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:7c:19:1a:78:7a brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e47c:19ff:fe1a:787a/64 scope link 
       valid_lft forever preferred_lft forever
