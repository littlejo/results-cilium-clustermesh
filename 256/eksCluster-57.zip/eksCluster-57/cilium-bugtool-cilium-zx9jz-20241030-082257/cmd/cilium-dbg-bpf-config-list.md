KEY             VALUE
AgentLiveness   2174303946459
UTimeOffset     3379442255859375
