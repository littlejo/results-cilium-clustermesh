REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37939     3009143     677    bpf_overlay.c
Interface                 INGRESS     673976    136788537   1132   bpf_host.c
Success                   EGRESS      17679     1397425     1694   bpf_host.c
Success                   EGRESS      289107    35559382    1308   bpf_lxc.c
Success                   EGRESS      38934     3081632     53     encap.h
Success                   INGRESS     332104    37586384    86     l3.h
Success                   INGRESS     353015    39242148    235    trace.h
Unsupported L3 protocol   EGRESS      47        3542        1492   bpf_lxc.c
