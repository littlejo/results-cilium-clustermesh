IP ADDRESS        LOCAL ENDPOINT INFO
10.57.0.144:0     (localhost)                                                                                        
10.57.0.215:0     id=865   sec_id=1922230 flags=0x0000 ifindex=12  mac=06:71:21:F7:2D:CA nodemac=7A:8A:DF:73:30:A5   
10.57.0.132:0     id=1056  sec_id=1900743 flags=0x0000 ifindex=18  mac=02:5F:58:F1:97:C7 nodemac=E6:7C:19:1A:78:7A   
172.31.237.78:0   (localhost)                                                                                        
172.31.248.14:0   (localhost)                                                                                        
10.57.0.188:0     id=111   sec_id=1922230 flags=0x0000 ifindex=14  mac=BA:93:3F:98:E8:0A nodemac=A2:C4:A0:A7:6E:FE   
10.57.0.192:0     id=3655  sec_id=4     flags=0x0000 ifindex=10  mac=8A:E2:17:30:A0:16 nodemac=36:83:CC:24:77:D8     
