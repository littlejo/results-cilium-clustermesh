[
  {
    "containers": [
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1bf24008_d471_450f_b353_da99ee615255.slice/cri-containerd-78c2dcdcc8e52d515b0a0b3f1289b75ca548f36833f2f10297436be628841730.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1bf24008_d471_450f_b353_da99ee615255.slice/cri-containerd-4440c10ced87cc4ed1c7d9e332c24032e102e18242fc6e8fb400e784efb0e446.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1bf24008_d471_450f_b353_da99ee615255.slice/cri-containerd-312825d0f0a13cf142793129e26a99fc73e7caac8882fecface8641896900113.scope"
      }
    ],
    "ips": [
      "10.156.0.204"
    ],
    "name": "clustermesh-apiserver-6fcd7f4f5d-mcbdd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb7206b64_a6e2_4e6d_bcd3_ab3708c48a75.slice/cri-containerd-5fa9323c59c1383126b623400fe5aa695cf293e8d3d7ee365f86a4fd701a9656.scope"
      }
    ],
    "ips": [
      "10.156.0.98"
    ],
    "name": "coredns-cc6ccd49c-6twlb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc07c9958_8e53_4cf1_94f0_3627b1a7ad7f.slice/cri-containerd-cfa20b659a4e446aa9c3b3233d81f3a1a1e42424308a166cee787c665638e2e9.scope"
      }
    ],
    "ips": [
      "10.156.0.151"
    ],
    "name": "coredns-cc6ccd49c-xz5sp",
    "namespace": "kube-system"
  }
]

