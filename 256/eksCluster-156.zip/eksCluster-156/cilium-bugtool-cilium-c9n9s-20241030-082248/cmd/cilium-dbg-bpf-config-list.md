KEY             VALUE
AgentLiveness   1935485487415
UTimeOffset     3379442707031250
