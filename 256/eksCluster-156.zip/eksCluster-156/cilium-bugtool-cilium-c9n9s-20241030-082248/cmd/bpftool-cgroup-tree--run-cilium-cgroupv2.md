CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod09531318_32f5_4a36_bd15_80d4749f87dd.slice/cri-containerd-d26be7a331350b85a8a53a3db8c34f28d5deffa54900410da4f9805c8c274c20.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod09531318_32f5_4a36_bd15_80d4749f87dd.slice/cri-containerd-c98b5d2cf8f4e66b3010db5c726abe970fe592f467889d7abface25254dd6768.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc07c9958_8e53_4cf1_94f0_3627b1a7ad7f.slice/cri-containerd-cfa20b659a4e446aa9c3b3233d81f3a1a1e42424308a166cee787c665638e2e9.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc07c9958_8e53_4cf1_94f0_3627b1a7ad7f.slice/cri-containerd-21f0fac494ae59513c026ea78df5e5bc4e62abf29833ee83cd592eb36c8bc700.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3df58aad_67a1_4c03_ae5c_2b745d8cdf92.slice/cri-containerd-e7f7e434b3fb81a33adcf66f864a0e675247165de84c8ab40d7d9da99d836bee.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3df58aad_67a1_4c03_ae5c_2b745d8cdf92.slice/cri-containerd-96e07a3823b24dcea8e28eb811780d387258b9a42154132b37d2dcace39a0568.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb7206b64_a6e2_4e6d_bcd3_ab3708c48a75.slice/cri-containerd-5fa9323c59c1383126b623400fe5aa695cf293e8d3d7ee365f86a4fd701a9656.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb7206b64_a6e2_4e6d_bcd3_ab3708c48a75.slice/cri-containerd-a1f7c5cfcb04d0cd53c7e881351c2d4398fbaa345ccf6506266e4978bb42bed3.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1bf24008_d471_450f_b353_da99ee615255.slice/cri-containerd-78c2dcdcc8e52d515b0a0b3f1289b75ca548f36833f2f10297436be628841730.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1bf24008_d471_450f_b353_da99ee615255.slice/cri-containerd-4440c10ced87cc4ed1c7d9e332c24032e102e18242fc6e8fb400e784efb0e446.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1bf24008_d471_450f_b353_da99ee615255.slice/cri-containerd-e98cc656d49b52d2b03075d7cee6ad8d25325f2aafa70811c5c1c32c6705f6e1.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1bf24008_d471_450f_b353_da99ee615255.slice/cri-containerd-312825d0f0a13cf142793129e26a99fc73e7caac8882fecface8641896900113.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0dfd367_4138_4af5_abcb_d29ccf2e67ad.slice/cri-containerd-7cb2e63fb0eeca280cc112be90c662c6a71567b0d230d19db1213a07f59dc4fc.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0dfd367_4138_4af5_abcb_d29ccf2e67ad.slice/cri-containerd-2b53f81dff7fd701eb388b5dba71958ce623fd0856b42ef459effb6cdfaa71e8.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7aa62fcc_24f5_4dd5_a739_b54064869edb.slice/cri-containerd-9d6de79ce965270b97a38f878bdc2ce631fb8db42fa90eebc656071ccdab495d.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7aa62fcc_24f5_4dd5_a739_b54064869edb.slice/cri-containerd-1a27b871937077eb97913c56a60a44ef647da820d1c9e03ef61ec2936bb1c81a.scope
    105      cgroup_device   multi                                          
