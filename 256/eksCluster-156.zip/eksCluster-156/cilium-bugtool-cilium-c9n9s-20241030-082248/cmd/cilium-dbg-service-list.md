ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.145.170:443 (active)   
                                         2 => 172.31.201.86:443 (active)    
2    10.100.238.212:443   ClusterIP      1 => 172.31.161.63:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.156.0.98:9153 (active)     
                                         2 => 10.156.0.151:9153 (active)    
4    10.100.0.10:53       ClusterIP      1 => 10.156.0.98:53 (active)       
                                         2 => 10.156.0.151:53 (active)      
5    10.100.124.13:2379   ClusterIP      1 => 10.156.0.204:2379 (active)    
