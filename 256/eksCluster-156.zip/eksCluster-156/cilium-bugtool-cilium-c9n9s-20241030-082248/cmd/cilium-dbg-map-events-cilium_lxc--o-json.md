{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:30.926Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.134.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:30.927Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.161.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:30.927Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:35.329Z",
  "value": "id=3529  sec_id=5153483 flags=0x0000 ifindex=14  mac=4A:2C:22:55:3F:94 nodemac=06:56:52:33:C0:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:35.331Z",
  "value": "id=3707  sec_id=5153483 flags=0x0000 ifindex=12  mac=C6:59:FB:D0:23:BA nodemac=D2:B6:9B:FA:A1:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:35.397Z",
  "value": "id=204   sec_id=4     flags=0x0000 ifindex=10  mac=62:62:1B:52:C0:C8 nodemac=CE:FF:01:DF:94:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:35.451Z",
  "value": "id=3529  sec_id=5153483 flags=0x0000 ifindex=14  mac=4A:2C:22:55:3F:94 nodemac=06:56:52:33:C0:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:35.513Z",
  "value": "id=3707  sec_id=5153483 flags=0x0000 ifindex=12  mac=C6:59:FB:D0:23:BA nodemac=D2:B6:9B:FA:A1:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.439Z",
  "value": "id=3707  sec_id=5153483 flags=0x0000 ifindex=12  mac=C6:59:FB:D0:23:BA nodemac=D2:B6:9B:FA:A1:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.439Z",
  "value": "id=204   sec_id=4     flags=0x0000 ifindex=10  mac=62:62:1B:52:C0:C8 nodemac=CE:FF:01:DF:94:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.439Z",
  "value": "id=3529  sec_id=5153483 flags=0x0000 ifindex=14  mac=4A:2C:22:55:3F:94 nodemac=06:56:52:33:C0:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.471Z",
  "value": "id=1004  sec_id=5177024 flags=0x0000 ifindex=16  mac=72:31:AF:14:99:E0 nodemac=7A:82:FF:B6:17:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:11.439Z",
  "value": "id=204   sec_id=4     flags=0x0000 ifindex=10  mac=62:62:1B:52:C0:C8 nodemac=CE:FF:01:DF:94:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:11.439Z",
  "value": "id=3707  sec_id=5153483 flags=0x0000 ifindex=12  mac=C6:59:FB:D0:23:BA nodemac=D2:B6:9B:FA:A1:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:11.439Z",
  "value": "id=3529  sec_id=5153483 flags=0x0000 ifindex=14  mac=4A:2C:22:55:3F:94 nodemac=06:56:52:33:C0:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:11.439Z",
  "value": "id=1004  sec_id=5177024 flags=0x0000 ifindex=16  mac=72:31:AF:14:99:E0 nodemac=7A:82:FF:B6:17:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:20.546Z",
  "value": "id=665   sec_id=5177024 flags=0x0000 ifindex=18  mac=A6:E0:BA:E1:B8:5B nodemac=C6:70:C5:02:8B:53"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.156.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.854Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.203Z",
  "value": "id=204   sec_id=4     flags=0x0000 ifindex=10  mac=62:62:1B:52:C0:C8 nodemac=CE:FF:01:DF:94:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.205Z",
  "value": "id=665   sec_id=5177024 flags=0x0000 ifindex=18  mac=A6:E0:BA:E1:B8:5B nodemac=C6:70:C5:02:8B:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.206Z",
  "value": "id=3707  sec_id=5153483 flags=0x0000 ifindex=12  mac=C6:59:FB:D0:23:BA nodemac=D2:B6:9B:FA:A1:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.207Z",
  "value": "id=3529  sec_id=5153483 flags=0x0000 ifindex=14  mac=4A:2C:22:55:3F:94 nodemac=06:56:52:33:C0:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.261Z",
  "value": "id=204   sec_id=4     flags=0x0000 ifindex=10  mac=62:62:1B:52:C0:C8 nodemac=CE:FF:01:DF:94:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.270Z",
  "value": "id=665   sec_id=5177024 flags=0x0000 ifindex=18  mac=A6:E0:BA:E1:B8:5B nodemac=C6:70:C5:02:8B:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.271Z",
  "value": "id=3707  sec_id=5153483 flags=0x0000 ifindex=12  mac=C6:59:FB:D0:23:BA nodemac=D2:B6:9B:FA:A1:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.277Z",
  "value": "id=3529  sec_id=5153483 flags=0x0000 ifindex=14  mac=4A:2C:22:55:3F:94 nodemac=06:56:52:33:C0:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.205Z",
  "value": "id=204   sec_id=4     flags=0x0000 ifindex=10  mac=62:62:1B:52:C0:C8 nodemac=CE:FF:01:DF:94:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.205Z",
  "value": "id=3707  sec_id=5153483 flags=0x0000 ifindex=12  mac=C6:59:FB:D0:23:BA nodemac=D2:B6:9B:FA:A1:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.205Z",
  "value": "id=3529  sec_id=5153483 flags=0x0000 ifindex=14  mac=4A:2C:22:55:3F:94 nodemac=06:56:52:33:C0:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.206Z",
  "value": "id=665   sec_id=5177024 flags=0x0000 ifindex=18  mac=A6:E0:BA:E1:B8:5B nodemac=C6:70:C5:02:8B:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:33.206Z",
  "value": "id=3707  sec_id=5153483 flags=0x0000 ifindex=12  mac=C6:59:FB:D0:23:BA nodemac=D2:B6:9B:FA:A1:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:33.206Z",
  "value": "id=3529  sec_id=5153483 flags=0x0000 ifindex=14  mac=4A:2C:22:55:3F:94 nodemac=06:56:52:33:C0:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:33.206Z",
  "value": "id=665   sec_id=5177024 flags=0x0000 ifindex=18  mac=A6:E0:BA:E1:B8:5B nodemac=C6:70:C5:02:8B:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.156.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:33.206Z",
  "value": "id=204   sec_id=4     flags=0x0000 ifindex=10  mac=62:62:1B:52:C0:C8 nodemac=CE:FF:01:DF:94:E5"
}

