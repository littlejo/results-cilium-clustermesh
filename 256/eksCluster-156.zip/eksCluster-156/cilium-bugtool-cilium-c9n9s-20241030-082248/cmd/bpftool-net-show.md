xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 573
ens6(5) clsact/ingress cil_from_netdev-ens6 id 584
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 571
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 562
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 513
lxc3213477062f2(12) clsact/ingress cil_from_container-lxc3213477062f2 id 542
lxc44e3a3a16479(14) clsact/ingress cil_from_container-lxc44e3a3a16479 id 529
lxc2b751ad6c388(18) clsact/ingress cil_from_container-lxc2b751ad6c388 id 628

flow_dissector:

netfilter:

