filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc2b751ad6c388 direct-action not_in_hw id 628 tag e376e4501d6f72f8 jited 
