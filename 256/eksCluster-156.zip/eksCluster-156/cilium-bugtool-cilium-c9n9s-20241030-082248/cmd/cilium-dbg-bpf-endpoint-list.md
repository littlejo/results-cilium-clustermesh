IP ADDRESS        LOCAL ENDPOINT INFO
10.156.0.114:0    id=204   sec_id=4     flags=0x0000 ifindex=10  mac=62:62:1B:52:C0:C8 nodemac=CE:FF:01:DF:94:E5     
172.31.161.63:0   (localhost)                                                                                        
10.156.0.151:0    id=3529  sec_id=5153483 flags=0x0000 ifindex=14  mac=4A:2C:22:55:3F:94 nodemac=06:56:52:33:C0:B4   
10.156.0.204:0    id=665   sec_id=5177024 flags=0x0000 ifindex=18  mac=A6:E0:BA:E1:B8:5B nodemac=C6:70:C5:02:8B:53   
10.156.0.191:0    (localhost)                                                                                        
172.31.134.78:0   (localhost)                                                                                        
10.156.0.98:0     id=3707  sec_id=5153483 flags=0x0000 ifindex=12  mac=C6:59:FB:D0:23:BA nodemac=D2:B6:9B:FA:A1:D7   
