REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36636     2901321     677    bpf_overlay.c
Interface                 INGRESS     647762    132785234   1132   bpf_host.c
Success                   EGRESS      16489     1298891     1694   bpf_host.c
Success                   EGRESS      276843    34288259    1308   bpf_lxc.c
Success                   EGRESS      36992     2924849     53     encap.h
Success                   INGRESS     317204    36012361    86     l3.h
Success                   INGRESS     338002    37658837    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
