key: cc 00 00 00  value: 07 02 00 00
key: 99 02 00 00  value: 7c 02 00 00
key: c9 0d 00 00  value: 0d 02 00 00
key: 7b 0e 00 00  value: 26 02 00 00
Found 4 elements
