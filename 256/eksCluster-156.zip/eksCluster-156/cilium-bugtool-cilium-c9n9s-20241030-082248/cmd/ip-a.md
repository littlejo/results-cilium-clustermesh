1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:6f:ee:ca:e9:77 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.161.63/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3505sec preferred_lft 3505sec
    inet6 fe80::46f:eeff:feca:e977/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:49:8a:41:0a:01 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.134.78/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::449:8aff:fe41:a01/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:00:e7:00:12:b8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f000:e7ff:fe00:12b8/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:2e:45:a1:12:1a brd ff:ff:ff:ff:ff:ff
    inet 10.156.0.191/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a42e:45ff:fea1:121a/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 96:9d:15:c7:eb:ad brd ff:ff:ff:ff:ff:ff
    inet6 fe80::949d:15ff:fec7:ebad/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:ff:01:df:94:e5 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::ccff:1ff:fedf:94e5/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc3213477062f2@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:b6:9b:fa:a1:d7 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d0b6:9bff:fefa:a1d7/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc44e3a3a16479@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:56:52:33:c0:b4 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::456:52ff:fe33:c0b4/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc2b751ad6c388@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:70:c5:02:8b:53 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c470:c5ff:fe02:8b53/64 scope link 
       valid_lft forever preferred_lft forever
