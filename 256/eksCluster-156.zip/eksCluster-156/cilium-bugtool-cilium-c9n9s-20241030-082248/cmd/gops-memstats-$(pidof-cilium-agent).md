alloc: 205.59MB (215572184 bytes)
total-alloc: 2.27GB (2434397312 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63819679
frees: 61607244
heap-alloc: 205.59MB (215572184 bytes)
heap-sys: 243.20MB (255016960 bytes)
heap-idle: 12.14MB (12730368 bytes)
heap-in-use: 231.06MB (242286592 bytes)
heap-released: 2.38MB (2490368 bytes)
heap-objects: 2212435
stack-in-use: 68.47MB (71794688 bytes)
stack-sys: 68.47MB (71794688 bytes)
stack-mspan-inuse: 3.63MB (3804640 bytes)
stack-mspan-sys: 3.89MB (4080000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 936.19KB (958657 bytes)
gc-sys: 6.30MB (6610384 bytes)
next-gc: when heap-alloc >= 211.72MB (222003672 bytes)
last-gc: 2024-10-30 08:22:42.22394199 +0000 UTC
gc-pause-total: 8.661507ms
gc-pause: 115555
gc-pause-end: 1730276562223941990
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.00045322839791980986
enable-gc: true
debug-gc: false
