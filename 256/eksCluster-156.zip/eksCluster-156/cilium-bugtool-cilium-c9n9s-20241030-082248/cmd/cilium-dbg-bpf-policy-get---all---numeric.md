Endpoint ID: 204
Path: /sys/fs/bpf/tc/globals/cilium_policy_00204

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1650109   20842     0        
Allow    Ingress     1          ANY          NONE         disabled    18872     221       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 665
Path: /sys/fs/bpf/tc/globals/cilium_policy_00665

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11535187   115684    0        
Allow    Ingress     1          ANY          NONE         disabled    10054321   105609    0        
Allow    Egress      0          ANY          NONE         disabled    13887839   136071    0        


Endpoint ID: 3528
Path: /sys/fs/bpf/tc/globals/cilium_policy_03528

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3529
Path: /sys/fs/bpf/tc/globals/cilium_policy_03529

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    124765   1429      0        
Allow    Egress      0          ANY          NONE         disabled    16349    177       0        


Endpoint ID: 3707
Path: /sys/fs/bpf/tc/globals/cilium_policy_03707

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    125498   1444      0        
Allow    Egress      0          ANY          NONE         disabled    16759    182       0        


