IP ADDRESS         LOCAL ENDPOINT INFO
10.224.0.100:0     id=2389  sec_id=7375714 flags=0x0000 ifindex=14  mac=FA:B9:22:E4:9B:4A nodemac=42:2D:BE:CB:66:2B   
10.224.0.123:0     (localhost)                                                                                        
10.224.0.56:0      id=2395  sec_id=7375262 flags=0x0000 ifindex=18  mac=92:77:82:04:9A:17 nodemac=0A:27:69:27:79:06   
10.224.0.31:0      id=2962  sec_id=7375714 flags=0x0000 ifindex=12  mac=C6:F1:6F:77:FA:63 nodemac=E6:5A:33:18:86:1D   
172.31.132.154:0   (localhost)                                                                                        
172.31.161.207:0   (localhost)                                                                                        
10.224.0.20:0      id=3582  sec_id=4     flags=0x0000 ifindex=10  mac=EA:70:81:F3:EA:EE nodemac=72:56:4A:C8:01:64     
