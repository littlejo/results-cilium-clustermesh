{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:32.646Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.132.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:32.646Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.161.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:32.646Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:37.055Z",
  "value": "id=3582  sec_id=4     flags=0x0000 ifindex=10  mac=EA:70:81:F3:EA:EE nodemac=72:56:4A:C8:01:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:37.057Z",
  "value": "id=2962  sec_id=7375714 flags=0x0000 ifindex=12  mac=C6:F1:6F:77:FA:63 nodemac=E6:5A:33:18:86:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:37.096Z",
  "value": "id=2389  sec_id=7375714 flags=0x0000 ifindex=14  mac=FA:B9:22:E4:9B:4A nodemac=42:2D:BE:CB:66:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:37.163Z",
  "value": "id=3582  sec_id=4     flags=0x0000 ifindex=10  mac=EA:70:81:F3:EA:EE nodemac=72:56:4A:C8:01:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:37.222Z",
  "value": "id=2962  sec_id=7375714 flags=0x0000 ifindex=12  mac=C6:F1:6F:77:FA:63 nodemac=E6:5A:33:18:86:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:26.077Z",
  "value": "id=2962  sec_id=7375714 flags=0x0000 ifindex=12  mac=C6:F1:6F:77:FA:63 nodemac=E6:5A:33:18:86:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:26.077Z",
  "value": "id=2389  sec_id=7375714 flags=0x0000 ifindex=14  mac=FA:B9:22:E4:9B:4A nodemac=42:2D:BE:CB:66:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:26.078Z",
  "value": "id=3582  sec_id=4     flags=0x0000 ifindex=10  mac=EA:70:81:F3:EA:EE nodemac=72:56:4A:C8:01:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:26.108Z",
  "value": "id=1586  sec_id=7375262 flags=0x0000 ifindex=16  mac=AA:B5:13:9E:4F:68 nodemac=DA:0F:3F:2C:1A:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:27.077Z",
  "value": "id=2389  sec_id=7375714 flags=0x0000 ifindex=14  mac=FA:B9:22:E4:9B:4A nodemac=42:2D:BE:CB:66:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:27.077Z",
  "value": "id=3582  sec_id=4     flags=0x0000 ifindex=10  mac=EA:70:81:F3:EA:EE nodemac=72:56:4A:C8:01:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:27.077Z",
  "value": "id=1586  sec_id=7375262 flags=0x0000 ifindex=16  mac=AA:B5:13:9E:4F:68 nodemac=DA:0F:3F:2C:1A:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:27.078Z",
  "value": "id=2962  sec_id=7375714 flags=0x0000 ifindex=12  mac=C6:F1:6F:77:FA:63 nodemac=E6:5A:33:18:86:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.360Z",
  "value": "id=2395  sec_id=7375262 flags=0x0000 ifindex=18  mac=92:77:82:04:9A:17 nodemac=0A:27:69:27:79:06"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.224.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:21.769Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:34.089Z",
  "value": "id=2962  sec_id=7375714 flags=0x0000 ifindex=12  mac=C6:F1:6F:77:FA:63 nodemac=E6:5A:33:18:86:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:34.089Z",
  "value": "id=3582  sec_id=4     flags=0x0000 ifindex=10  mac=EA:70:81:F3:EA:EE nodemac=72:56:4A:C8:01:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:34.089Z",
  "value": "id=2389  sec_id=7375714 flags=0x0000 ifindex=14  mac=FA:B9:22:E4:9B:4A nodemac=42:2D:BE:CB:66:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:34.090Z",
  "value": "id=2395  sec_id=7375262 flags=0x0000 ifindex=18  mac=92:77:82:04:9A:17 nodemac=0A:27:69:27:79:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:35.091Z",
  "value": "id=2962  sec_id=7375714 flags=0x0000 ifindex=12  mac=C6:F1:6F:77:FA:63 nodemac=E6:5A:33:18:86:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:35.092Z",
  "value": "id=3582  sec_id=4     flags=0x0000 ifindex=10  mac=EA:70:81:F3:EA:EE nodemac=72:56:4A:C8:01:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:35.092Z",
  "value": "id=2389  sec_id=7375714 flags=0x0000 ifindex=14  mac=FA:B9:22:E4:9B:4A nodemac=42:2D:BE:CB:66:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:35.093Z",
  "value": "id=2395  sec_id=7375262 flags=0x0000 ifindex=18  mac=92:77:82:04:9A:17 nodemac=0A:27:69:27:79:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:36.091Z",
  "value": "id=2395  sec_id=7375262 flags=0x0000 ifindex=18  mac=92:77:82:04:9A:17 nodemac=0A:27:69:27:79:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:36.091Z",
  "value": "id=2389  sec_id=7375714 flags=0x0000 ifindex=14  mac=FA:B9:22:E4:9B:4A nodemac=42:2D:BE:CB:66:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:36.091Z",
  "value": "id=3582  sec_id=4     flags=0x0000 ifindex=10  mac=EA:70:81:F3:EA:EE nodemac=72:56:4A:C8:01:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:36.091Z",
  "value": "id=2962  sec_id=7375714 flags=0x0000 ifindex=12  mac=C6:F1:6F:77:FA:63 nodemac=E6:5A:33:18:86:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.091Z",
  "value": "id=2395  sec_id=7375262 flags=0x0000 ifindex=18  mac=92:77:82:04:9A:17 nodemac=0A:27:69:27:79:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.092Z",
  "value": "id=2962  sec_id=7375714 flags=0x0000 ifindex=12  mac=C6:F1:6F:77:FA:63 nodemac=E6:5A:33:18:86:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.092Z",
  "value": "id=3582  sec_id=4     flags=0x0000 ifindex=10  mac=EA:70:81:F3:EA:EE nodemac=72:56:4A:C8:01:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.224.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.093Z",
  "value": "id=2389  sec_id=7375714 flags=0x0000 ifindex=14  mac=FA:B9:22:E4:9B:4A nodemac=42:2D:BE:CB:66:2B"
}

