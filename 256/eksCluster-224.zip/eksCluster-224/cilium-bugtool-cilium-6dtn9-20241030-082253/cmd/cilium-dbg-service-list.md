ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.229.199:443 (active)    
                                          2 => 172.31.179.219:443 (active)    
2    10.100.70.5:443       ClusterIP      1 => 172.31.132.154:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.224.0.31:53 (active)        
                                          2 => 10.224.0.100:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.224.0.31:9153 (active)      
                                          2 => 10.224.0.100:9153 (active)     
5    10.100.106.144:2379   ClusterIP      1 => 10.224.0.56:2379 (active)      
