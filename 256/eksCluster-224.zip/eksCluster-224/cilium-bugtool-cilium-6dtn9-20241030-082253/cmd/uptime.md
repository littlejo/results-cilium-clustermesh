 08:22:54 up 28 min,  0 users,  load average: 0.27, 0.29, 0.20
