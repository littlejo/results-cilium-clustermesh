key: 55 09 00 00  value: fd 01 00 00
key: 5b 09 00 00  value: 6d 02 00 00
key: 92 0b 00 00  value: 16 02 00 00
key: fe 0d 00 00  value: 0d 02 00 00
Found 4 elements
