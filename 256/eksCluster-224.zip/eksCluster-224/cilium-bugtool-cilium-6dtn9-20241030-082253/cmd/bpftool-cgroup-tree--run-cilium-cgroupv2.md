CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47c2ef20_6f4c_48e6_b641_342c978012b2.slice/cri-containerd-ccb6bb17982cd5c174ded1f2971a0712df64cc4d15b2c7aa5ffcd4287bbcfd6a.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47c2ef20_6f4c_48e6_b641_342c978012b2.slice/cri-containerd-9bae9fa42943a636c93efcd3d4c7eee4217b7ecf639a8f97410b7676eb6e057d.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f919ed7_c45a_4b76_b737_2c7f02b4bca3.slice/cri-containerd-4e2881abf3b6523e13f4bb017a4b1b8bd228b7804bfa043dd34c70c6f2a4f916.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f919ed7_c45a_4b76_b737_2c7f02b4bca3.slice/cri-containerd-751108228f66ab66cc1d07da5f7ded7d9e7ff3165478cd9ef3bcda7a5c985843.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod94b5c4fb_251a_45a6_b197_75fb5fb7d8ea.slice/cri-containerd-26009b6927f73207bc2aab40352bd89f84e9485f0f068850f8e3e364a56a95ab.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod94b5c4fb_251a_45a6_b197_75fb5fb7d8ea.slice/cri-containerd-9e62cbf69b686c03e5c627c4ca21d1a7fb12b009bc558f9adad7638542aafb7b.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbaa118d6_e953_4bad_8b9d_ee8dd9c18619.slice/cri-containerd-fb5a24835ed7980d8bd20be514774542da99ae5422fd5bbd8f93b34c45642eed.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbaa118d6_e953_4bad_8b9d_ee8dd9c18619.slice/cri-containerd-563379e0cd99d78ba389e50c53dd41a7cc9ac115cd52d652dd841cb5a124cb36.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod137af93c_6a42_41b3_a648_40e42447b7ba.slice/cri-containerd-63dd108790803536a8fc4b4c30f93dd30a50e03d0f650e7c6835d8c0bc4a429a.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod137af93c_6a42_41b3_a648_40e42447b7ba.slice/cri-containerd-4993319259a7c955a4a5212240edf09e1cb486db3b68eddf76a058d572cef574.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod662b7ae6_5cc7_4e20_a7bc_10baf2f3f4c9.slice/cri-containerd-1946814dfcdf89a3b31384a190d42914a583ee7c22ece34f7c94fe6c75729428.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod662b7ae6_5cc7_4e20_a7bc_10baf2f3f4c9.slice/cri-containerd-f8f212c2240acc10a880b6f5ceb8ebc426dd2a151582d1526a3ab2efb433e420.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod662b7ae6_5cc7_4e20_a7bc_10baf2f3f4c9.slice/cri-containerd-fcd7c63f2ba889647444a4cac8ecdb013172d273ab93bf03f2bb357d46682f5d.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod662b7ae6_5cc7_4e20_a7bc_10baf2f3f4c9.slice/cri-containerd-8025c662823a753611e092c52386e5f97c64b60967b3c5762c567e55874f9a66.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7eeeafee_2236_4ad6_9986_baf49c46d547.slice/cri-containerd-3f79ae471998e4b6ace347800726e92e56283b8888fe4b8f428e89c26d6e8942.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7eeeafee_2236_4ad6_9986_baf49c46d547.slice/cri-containerd-b706c51908051e9582f562004e399ec536d5062192d6cb247ed4187cd54e2ae8.scope
    99       cgroup_device   multi                                          
