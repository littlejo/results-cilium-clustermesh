[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod94b5c4fb_251a_45a6_b197_75fb5fb7d8ea.slice/cri-containerd-26009b6927f73207bc2aab40352bd89f84e9485f0f068850f8e3e364a56a95ab.scope"
      }
    ],
    "ips": [
      "10.224.0.31"
    ],
    "name": "coredns-cc6ccd49c-bbn5l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod662b7ae6_5cc7_4e20_a7bc_10baf2f3f4c9.slice/cri-containerd-f8f212c2240acc10a880b6f5ceb8ebc426dd2a151582d1526a3ab2efb433e420.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod662b7ae6_5cc7_4e20_a7bc_10baf2f3f4c9.slice/cri-containerd-1946814dfcdf89a3b31384a190d42914a583ee7c22ece34f7c94fe6c75729428.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod662b7ae6_5cc7_4e20_a7bc_10baf2f3f4c9.slice/cri-containerd-fcd7c63f2ba889647444a4cac8ecdb013172d273ab93bf03f2bb357d46682f5d.scope"
      }
    ],
    "ips": [
      "10.224.0.56"
    ],
    "name": "clustermesh-apiserver-659fd6d58f-2pmjc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47c2ef20_6f4c_48e6_b641_342c978012b2.slice/cri-containerd-ccb6bb17982cd5c174ded1f2971a0712df64cc4d15b2c7aa5ffcd4287bbcfd6a.scope"
      }
    ],
    "ips": [
      "10.224.0.100"
    ],
    "name": "coredns-cc6ccd49c-6z5dv",
    "namespace": "kube-system"
  }
]

