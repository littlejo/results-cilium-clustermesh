Endpoint ID: 1284
Path: /sys/fs/bpf/tc/globals/cilium_policy_01284

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2389
Path: /sys/fs/bpf/tc/globals/cilium_policy_02389

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113011   1294      0        
Allow    Egress      0          ANY          NONE         disabled    16531    177       0        


Endpoint ID: 2395
Path: /sys/fs/bpf/tc/globals/cilium_policy_02395

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11394250   111808    0        
Allow    Ingress     1          ANY          NONE         disabled    9419880    98586     0        
Allow    Egress      0          ANY          NONE         disabled    11134446   110568    0        


Endpoint ID: 2962
Path: /sys/fs/bpf/tc/globals/cilium_policy_02962

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112778   1294      0        
Allow    Egress      0          ANY          NONE         disabled    15128    160       0        


Endpoint ID: 3582
Path: /sys/fs/bpf/tc/globals/cilium_policy_03582

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1651096   20863     0        
Allow    Ingress     1          ANY          NONE         disabled    17258     203       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


