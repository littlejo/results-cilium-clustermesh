xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 567
ens6(5) clsact/ingress cil_from_netdev-ens6 id 578
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 560
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 559
cilium_host(7) clsact/egress cil_from_host-cilium_host id 558
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 518
lxc4d6fa4988170(12) clsact/ingress cil_from_container-lxc4d6fa4988170 id 538
lxc7573b21e2838(14) clsact/ingress cil_from_container-lxc7573b21e2838 id 507
lxccaf93ab8eb12(18) clsact/ingress cil_from_container-lxccaf93ab8eb12 id 625

flow_dissector:

netfilter:

