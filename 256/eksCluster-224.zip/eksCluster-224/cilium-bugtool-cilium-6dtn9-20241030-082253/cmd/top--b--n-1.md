top - 08:22:55 up 28 min,  0 users,  load average: 0.27, 0.29, 0.20
Tasks:  10 total,   3 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 50.0 us, 36.7 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi, 13.3 si,  0.0 st
MiB Mem :   7814.2 total,   4491.1 free,   1176.6 used,   2146.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6452.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 393764  78392 S  33.3   4.9   0:39.16 cilium-+
    707 root      20   0 1244596  21764  14332 S  20.0   0.3   0:00.04 hubble
    660 root      20   0 1229000   5024   3876 R   6.7   0.1   0:00.01 gops
    394 root      20   0 1229744   6892   2924 S   0.0   0.1   0:01.07 cilium-+
    666 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    672 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    689 root      20   0 1240432  16364  11228 S   0.0   0.2   0:00.02 cilium-+
    695 root      20   0    2208    776    696 S   0.0   0.0   0:00.00 timeout
    727 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    741 root      20   0 1240432  16364  11228 R   0.0   0.2   0:00.00 cilium-+
