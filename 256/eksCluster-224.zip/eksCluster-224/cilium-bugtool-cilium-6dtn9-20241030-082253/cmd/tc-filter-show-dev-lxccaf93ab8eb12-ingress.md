filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxccaf93ab8eb12 direct-action not_in_hw id 625 tag 9302c0ef1aace1a5 jited 
