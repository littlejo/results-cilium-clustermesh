alloc: 110.13MB (115479968 bytes)
total-alloc: 2.17GB (2330511784 bytes)
sys: 332.77MB (348934500 bytes)
lookups: 0
mallocs: 62188145
frees: 61288577
heap-alloc: 110.13MB (115479968 bytes)
heap-sys: 255.41MB (267821056 bytes)
heap-idle: 90.41MB (94806016 bytes)
heap-in-use: 165.00MB (173015040 bytes)
heap-released: 8.54MB (8953856 bytes)
heap-objects: 899568
stack-in-use: 64.56MB (67698688 bytes)
stack-sys: 64.56MB (67698688 bytes)
stack-mspan-inuse: 2.83MB (2967040 bytes)
stack-mspan-sys: 3.89MB (4080000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 937.55KB (960049 bytes)
gc-sys: 6.02MB (6313592 bytes)
next-gc: when heap-alloc >= 214.27MB (224676920 bytes)
last-gc: 2024-10-30 08:23:15.282532775 +0000 UTC
gc-pause-total: 27.299346ms
gc-pause: 135653
gc-pause-end: 1730276595282532775
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0005886692887416784
enable-gc: true
debug-gc: false
