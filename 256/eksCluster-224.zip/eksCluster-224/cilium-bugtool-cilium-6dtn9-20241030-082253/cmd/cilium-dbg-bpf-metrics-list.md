REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35006     2765035     677    bpf_overlay.c
Interface                 INGRESS     619106    128515655   1132   bpf_host.c
Success                   EGRESS      14718     1152573     1694   bpf_host.c
Success                   EGRESS      260304    33122139    1308   bpf_lxc.c
Success                   EGRESS      34248     2709898     53     encap.h
Success                   INGRESS     302334    33931035    86     l3.h
Success                   INGRESS     323146    35578145    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
