Total: 673
TCP:   1858 (estab 435, closed 1404, orphaned 0, timewait 564)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  454       442       12       
INET	  464       448       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:43193      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=40)) ino:34592 sk:3ef fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.132.154%ens5:68         0.0.0.0:*    uid:192 ino:14181 sk:3f0 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:35009 sk:3f1 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:13969 sk:3f2 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:35008 sk:3f3 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:13970 sk:3f4 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::45e:9cff:fe7d:90c3]%ens5:546           [::]:*    uid:192 ino:15878 sk:3f5 cgroup:unreachable:c4e v6only:1 <->                   
