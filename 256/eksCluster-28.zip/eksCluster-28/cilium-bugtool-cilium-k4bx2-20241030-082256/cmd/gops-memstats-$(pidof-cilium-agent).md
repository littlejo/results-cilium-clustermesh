alloc: 119.13MB (124914344 bytes)
total-alloc: 2.25GB (2411633136 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63240784
frees: 62431883
heap-alloc: 119.13MB (124914344 bytes)
heap-sys: 248.04MB (260087808 bytes)
heap-idle: 76.14MB (79839232 bytes)
heap-in-use: 171.90MB (180248576 bytes)
heap-released: 352.00KB (360448 bytes)
heap-objects: 808901
stack-in-use: 63.94MB (67043328 bytes)
stack-sys: 63.94MB (67043328 bytes)
stack-mspan-inuse: 2.69MB (2817600 bytes)
stack-mspan-sys: 3.78MB (3965760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1021.68KB (1046201 bytes)
gc-sys: 6.01MB (6299160 bytes)
next-gc: when heap-alloc >= 211.11MB (221360712 bytes)
last-gc: 2024-10-30 08:23:21.809571573 +0000 UTC
gc-pause-total: 12.790622ms
gc-pause: 123851
gc-pause-end: 1730276601809571573
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0003530189217100352
enable-gc: true
debug-gc: false
