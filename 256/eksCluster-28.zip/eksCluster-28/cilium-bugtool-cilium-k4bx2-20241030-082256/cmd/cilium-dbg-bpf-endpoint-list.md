IP ADDRESS         LOCAL ENDPOINT INFO
10.28.0.243:0      id=23    sec_id=4     flags=0x0000 ifindex=10  mac=52:C7:74:40:54:9B nodemac=2A:04:13:E6:13:19    
172.31.129.157:0   (localhost)                                                                                       
10.28.0.92:0       id=625   sec_id=967374 flags=0x0000 ifindex=18  mac=1A:D4:43:9B:AC:F8 nodemac=5E:6D:47:59:12:08   
172.31.152.77:0    (localhost)                                                                                       
10.28.0.212:0      id=2240  sec_id=957807 flags=0x0000 ifindex=12  mac=C6:A4:FE:FC:74:24 nodemac=12:B8:C0:5B:26:99   
10.28.0.103:0      id=569   sec_id=957807 flags=0x0000 ifindex=14  mac=D2:83:58:7B:D4:FC nodemac=12:E6:A2:B4:71:26   
10.28.0.148:0      (localhost)                                                                                       
