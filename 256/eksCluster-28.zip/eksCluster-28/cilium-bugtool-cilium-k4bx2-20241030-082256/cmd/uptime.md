 08:22:57 up 35 min,  0 users,  load average: 0.18, 0.14, 0.11
