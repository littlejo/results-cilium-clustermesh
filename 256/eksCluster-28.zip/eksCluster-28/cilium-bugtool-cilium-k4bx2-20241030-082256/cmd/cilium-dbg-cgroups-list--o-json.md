[
  {
    "containers": [
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb453be11_aa91_4c32_97c0_33b2df4039c8.slice/cri-containerd-58018306a9a3709aa00b301995a878fdd6f6ad604aa4aa62434581670b19105e.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb453be11_aa91_4c32_97c0_33b2df4039c8.slice/cri-containerd-0751a2dc0a31f980206d8653af86a65387a4dc425b2f38595b5bfc5eddc71e40.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb453be11_aa91_4c32_97c0_33b2df4039c8.slice/cri-containerd-370203ef9f3e408e3ed50080f6daa92e60d7b0238da793fd0bce3f0b71aaf3ad.scope"
      }
    ],
    "ips": [
      "10.28.0.92"
    ],
    "name": "clustermesh-apiserver-57dbc5c7cf-sthwb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7619,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda41dc36d_8335_4b1b_b89f_db6b577eea68.slice/cri-containerd-2c6bf42971b560bf30cf4bc4a09ad7f4777892b9420e53171a0d02ba2ef5b518.scope"
      }
    ],
    "ips": [
      "10.28.0.212"
    ],
    "name": "coredns-cc6ccd49c-jbw22",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod650e75f4_7e86_4d29_9f2b_4fa50e2f7574.slice/cri-containerd-e83b9cb6e71f3694f2efdcd1592af24379a2fe930ae01cbd77d013ca00720318.scope"
      }
    ],
    "ips": [
      "10.28.0.103"
    ],
    "name": "coredns-cc6ccd49c-8dv99",
    "namespace": "kube-system"
  }
]

