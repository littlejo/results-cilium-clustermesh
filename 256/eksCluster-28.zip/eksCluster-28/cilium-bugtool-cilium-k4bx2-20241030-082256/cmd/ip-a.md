1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:65:10:f8:4e:b9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.152.77/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3304sec preferred_lft 3304sec
    inet6 fe80::465:10ff:fef8:4eb9/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d3:a8:97:9b:c5 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.129.157/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4d3:a8ff:fe97:9bc5/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:a4:2d:57:fd:03 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f0a4:2dff:fe57:fd03/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:f1:cb:f4:51:5f brd ff:ff:ff:ff:ff:ff
    inet 10.28.0.148/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::6cf1:cbff:fef4:515f/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 26:12:f1:81:6c:c0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2412:f1ff:fe81:6cc0/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:04:13:e6:13:19 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::2804:13ff:fee6:1319/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc7958b35ec5f1@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:b8:c0:5b:26:99 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::10b8:c0ff:fe5b:2699/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc176cba9a2fa6@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:e6:a2:b4:71:26 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::10e6:a2ff:feb4:7126/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc4de1cfc5358c@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:6d:47:59:12:08 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::5c6d:47ff:fe59:1208/64 scope link 
       valid_lft forever preferred_lft forever
