CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda41dc36d_8335_4b1b_b89f_db6b577eea68.slice/cri-containerd-2c6bf42971b560bf30cf4bc4a09ad7f4777892b9420e53171a0d02ba2ef5b518.scope
    499      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda41dc36d_8335_4b1b_b89f_db6b577eea68.slice/cri-containerd-c3fbe6801303d746289ea099d05a9e1f14b446649f4326732061a98c35bbb9eb.scope
    495      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b5747bd_cbf9_4d24_b60c_bb29d41d44ed.slice/cri-containerd-1a309fb88eba1142ca4792035e31bce8100b2262137bd2222f835db1f19b8466.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b5747bd_cbf9_4d24_b60c_bb29d41d44ed.slice/cri-containerd-6bc6cd1df36ee05c5a9b3c1ff3fb64322d9672d28cfb38a8188a77bed4e16773.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod650e75f4_7e86_4d29_9f2b_4fa50e2f7574.slice/cri-containerd-e83b9cb6e71f3694f2efdcd1592af24379a2fe930ae01cbd77d013ca00720318.scope
    566      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod650e75f4_7e86_4d29_9f2b_4fa50e2f7574.slice/cri-containerd-59c21dc1923347c89e903edefe5f649427e5ffc01a5e37df1fbb8331bec1762f.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda9f918e_8bc6_4df4_944a_c6e1a1291a96.slice/cri-containerd-054459a020f380f5a0029cb732184544767c7e2ebff9ea65912377a25f001614.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda9f918e_8bc6_4df4_944a_c6e1a1291a96.slice/cri-containerd-620fb675ec1c1a3feb1d8f3d2b2e7db7c90ea5af6b7e80a1f264942ce02c0ef2.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb453be11_aa91_4c32_97c0_33b2df4039c8.slice/cri-containerd-370203ef9f3e408e3ed50080f6daa92e60d7b0238da793fd0bce3f0b71aaf3ad.scope
    668      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb453be11_aa91_4c32_97c0_33b2df4039c8.slice/cri-containerd-0751a2dc0a31f980206d8653af86a65387a4dc425b2f38595b5bfc5eddc71e40.scope
    672      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb453be11_aa91_4c32_97c0_33b2df4039c8.slice/cri-containerd-0610705f5dcaa09a5740bb37a8b64bb380a3b7283e748e2e5c3018e697328deb.scope
    648      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb453be11_aa91_4c32_97c0_33b2df4039c8.slice/cri-containerd-58018306a9a3709aa00b301995a878fdd6f6ad604aa4aa62434581670b19105e.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod287a4a45_d306_4fd7_befc_37e3eb28d7c8.slice/cri-containerd-cf96a209c0d445b4eaa667c877dff1e4458f2457f74ed060c416d71a9e072216.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod287a4a45_d306_4fd7_befc_37e3eb28d7c8.slice/cri-containerd-ae30c0d4c941fcb893c77df6236b5bded5c4979580ad135084d52f9c2f0d5b33.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb223b526_24b8_4b09_84d9_6ec8ca9e1dac.slice/cri-containerd-df0422a325018777e0dda64833f6e112bf88307fe6e6d7fcc5c1f3ad2180a672.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb223b526_24b8_4b09_84d9_6ec8ca9e1dac.slice/cri-containerd-47e75405a822732c22bfaabb66b892af4cd49c05870b98319075e78c2437c847.scope
    90       cgroup_device   multi                                          
