xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 586
ens6(5) clsact/ingress cil_from_netdev-ens6 id 589
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 580
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 568
cilium_host(7) clsact/egress cil_from_host-cilium_host id 572
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 501
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 502
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 556
lxc7958b35ec5f1(12) clsact/ingress cil_from_container-lxc7958b35ec5f1 id 535
lxc176cba9a2fa6(14) clsact/ingress cil_from_container-lxc176cba9a2fa6 id 540
lxc4de1cfc5358c(18) clsact/ingress cil_from_container-lxc4de1cfc5358c id 640

flow_dissector:

netfilter:

