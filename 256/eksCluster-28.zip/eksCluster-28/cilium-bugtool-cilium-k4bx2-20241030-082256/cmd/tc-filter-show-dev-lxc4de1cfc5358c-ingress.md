filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc4de1cfc5358c direct-action not_in_hw id 640 tag ccb08def26a808a4 jited 
