key: 17 00 00 00  value: 30 02 00 00
key: 39 02 00 00  value: 1d 02 00 00
key: 71 02 00 00  value: 7a 02 00 00
key: c0 08 00 00  value: 15 02 00 00
Found 4 elements
