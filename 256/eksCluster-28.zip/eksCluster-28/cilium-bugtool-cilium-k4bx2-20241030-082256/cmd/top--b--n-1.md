top - 08:22:57 up 35 min,  0 users,  load average: 0.18, 0.14, 0.11
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 20.7 us, 41.4 sy,  0.0 ni, 37.9 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4490.5 free,   1178.3 used,   2145.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6450.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 379588  78456 S   6.7   4.7   0:51.83 cilium-+
    396 root      20   0 1229744   7136   2864 S   0.0   0.1   0:01.19 cilium-+
    658 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    668 root      20   0 1240432  16072  11100 S   0.0   0.2   0:00.02 cilium-+
    674 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    695 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    731 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    749 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    761 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    767 root      20   0 1243764  18160  13252 S   0.0   0.2   0:00.00 hubble
