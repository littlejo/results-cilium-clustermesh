{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:01.510Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.129.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:01.510Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.152.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:01.510Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:04.904Z",
  "value": "id=2240  sec_id=957807 flags=0x0000 ifindex=12  mac=C6:A4:FE:FC:74:24 nodemac=12:B8:C0:5B:26:99"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:08.068Z",
  "value": "id=569   sec_id=957807 flags=0x0000 ifindex=14  mac=D2:83:58:7B:D4:FC nodemac=12:E6:A2:B4:71:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:08.110Z",
  "value": "id=23    sec_id=4     flags=0x0000 ifindex=10  mac=52:C7:74:40:54:9B nodemac=2A:04:13:E6:13:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:08.156Z",
  "value": "id=2240  sec_id=957807 flags=0x0000 ifindex=12  mac=C6:A4:FE:FC:74:24 nodemac=12:B8:C0:5B:26:99"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:08.197Z",
  "value": "id=569   sec_id=957807 flags=0x0000 ifindex=14  mac=D2:83:58:7B:D4:FC nodemac=12:E6:A2:B4:71:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:08.271Z",
  "value": "id=23    sec_id=4     flags=0x0000 ifindex=10  mac=52:C7:74:40:54:9B nodemac=2A:04:13:E6:13:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:21.797Z",
  "value": "id=2240  sec_id=957807 flags=0x0000 ifindex=12  mac=C6:A4:FE:FC:74:24 nodemac=12:B8:C0:5B:26:99"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:21.797Z",
  "value": "id=569   sec_id=957807 flags=0x0000 ifindex=14  mac=D2:83:58:7B:D4:FC nodemac=12:E6:A2:B4:71:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:21.798Z",
  "value": "id=23    sec_id=4     flags=0x0000 ifindex=10  mac=52:C7:74:40:54:9B nodemac=2A:04:13:E6:13:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:21.828Z",
  "value": "id=3389  sec_id=967374 flags=0x0000 ifindex=16  mac=82:08:8B:A1:25:FB nodemac=F2:38:B8:A0:18:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:22.797Z",
  "value": "id=3389  sec_id=967374 flags=0x0000 ifindex=16  mac=82:08:8B:A1:25:FB nodemac=F2:38:B8:A0:18:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:22.797Z",
  "value": "id=2240  sec_id=957807 flags=0x0000 ifindex=12  mac=C6:A4:FE:FC:74:24 nodemac=12:B8:C0:5B:26:99"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:22.797Z",
  "value": "id=569   sec_id=957807 flags=0x0000 ifindex=14  mac=D2:83:58:7B:D4:FC nodemac=12:E6:A2:B4:71:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:22.797Z",
  "value": "id=23    sec_id=4     flags=0x0000 ifindex=10  mac=52:C7:74:40:54:9B nodemac=2A:04:13:E6:13:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.044Z",
  "value": "id=625   sec_id=967374 flags=0x0000 ifindex=18  mac=1A:D4:43:9B:AC:F8 nodemac=5E:6D:47:59:12:08"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.28.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.526Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.735Z",
  "value": "id=2240  sec_id=957807 flags=0x0000 ifindex=12  mac=C6:A4:FE:FC:74:24 nodemac=12:B8:C0:5B:26:99"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.740Z",
  "value": "id=569   sec_id=957807 flags=0x0000 ifindex=14  mac=D2:83:58:7B:D4:FC nodemac=12:E6:A2:B4:71:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.741Z",
  "value": "id=23    sec_id=4     flags=0x0000 ifindex=10  mac=52:C7:74:40:54:9B nodemac=2A:04:13:E6:13:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.741Z",
  "value": "id=625   sec_id=967374 flags=0x0000 ifindex=18  mac=1A:D4:43:9B:AC:F8 nodemac=5E:6D:47:59:12:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:30.746Z",
  "value": "id=2240  sec_id=957807 flags=0x0000 ifindex=12  mac=C6:A4:FE:FC:74:24 nodemac=12:B8:C0:5B:26:99"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:30.747Z",
  "value": "id=569   sec_id=957807 flags=0x0000 ifindex=14  mac=D2:83:58:7B:D4:FC nodemac=12:E6:A2:B4:71:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:30.747Z",
  "value": "id=23    sec_id=4     flags=0x0000 ifindex=10  mac=52:C7:74:40:54:9B nodemac=2A:04:13:E6:13:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:30.747Z",
  "value": "id=625   sec_id=967374 flags=0x0000 ifindex=18  mac=1A:D4:43:9B:AC:F8 nodemac=5E:6D:47:59:12:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.729Z",
  "value": "id=625   sec_id=967374 flags=0x0000 ifindex=18  mac=1A:D4:43:9B:AC:F8 nodemac=5E:6D:47:59:12:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.730Z",
  "value": "id=23    sec_id=4     flags=0x0000 ifindex=10  mac=52:C7:74:40:54:9B nodemac=2A:04:13:E6:13:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.730Z",
  "value": "id=569   sec_id=957807 flags=0x0000 ifindex=14  mac=D2:83:58:7B:D4:FC nodemac=12:E6:A2:B4:71:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.730Z",
  "value": "id=2240  sec_id=957807 flags=0x0000 ifindex=12  mac=C6:A4:FE:FC:74:24 nodemac=12:B8:C0:5B:26:99"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.729Z",
  "value": "id=569   sec_id=957807 flags=0x0000 ifindex=14  mac=D2:83:58:7B:D4:FC nodemac=12:E6:A2:B4:71:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.730Z",
  "value": "id=23    sec_id=4     flags=0x0000 ifindex=10  mac=52:C7:74:40:54:9B nodemac=2A:04:13:E6:13:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.730Z",
  "value": "id=625   sec_id=967374 flags=0x0000 ifindex=18  mac=1A:D4:43:9B:AC:F8 nodemac=5E:6D:47:59:12:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.730Z",
  "value": "id=2240  sec_id=957807 flags=0x0000 ifindex=12  mac=C6:A4:FE:FC:74:24 nodemac=12:B8:C0:5B:26:99"
}

