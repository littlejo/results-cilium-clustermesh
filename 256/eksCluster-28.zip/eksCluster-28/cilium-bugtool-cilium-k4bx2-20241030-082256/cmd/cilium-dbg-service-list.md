ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.199.121:443 (active)   
                                        2 => 172.31.188.83:443 (active)    
2    10.100.24.202:443   ClusterIP      1 => 172.31.152.77:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.28.0.212:53 (active)       
                                        2 => 10.28.0.103:53 (active)       
4    10.100.0.10:9153    ClusterIP      1 => 10.28.0.212:9153 (active)     
                                        2 => 10.28.0.103:9153 (active)     
5    10.100.9.17:2379    ClusterIP      1 => 10.28.0.92:2379 (active)      
