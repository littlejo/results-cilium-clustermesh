Endpoint ID: 23
Path: /sys/fs/bpf/tc/globals/cilium_policy_00023

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1672330   21159     0        
Allow    Ingress     1          ANY          NONE         disabled    24088     280       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 61
Path: /sys/fs/bpf/tc/globals/cilium_policy_00061

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 569
Path: /sys/fs/bpf/tc/globals/cilium_policy_00569

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    163505   1881      0        
Allow    Egress      0          ANY          NONE         disabled    20491    229       0        


Endpoint ID: 625
Path: /sys/fs/bpf/tc/globals/cilium_policy_00625

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11459747   113060    0        
Allow    Ingress     1          ANY          NONE         disabled    9508934    99630     0        
Allow    Egress      0          ANY          NONE         disabled    11743686   116541    0        


Endpoint ID: 2240
Path: /sys/fs/bpf/tc/globals/cilium_policy_02240

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    163439   1880      0        
Allow    Egress      0          ANY          NONE         disabled    20297    228       0        


