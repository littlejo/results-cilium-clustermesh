REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35698     2820158     677    bpf_overlay.c
Interface                 INGRESS     630990    130624772   1132   bpf_host.c
Success                   EGRESS      15241     1195868     1694   bpf_host.c
Success                   EGRESS      263151    33355606    1308   bpf_lxc.c
Success                   EGRESS      35101     2778166     53     encap.h
Success                   INGRESS     306616    34402878    86     l3.h
Success                   INGRESS     327724    36071214    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
