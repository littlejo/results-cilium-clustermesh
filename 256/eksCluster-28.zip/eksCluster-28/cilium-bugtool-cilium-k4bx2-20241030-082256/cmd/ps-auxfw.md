USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         695  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         674  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         668  0.0  0.2 1240432 16072 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         712  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         658  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.0  4.7 1606080 379588 ?      Ssl  07:54   0:51 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.0 1229744 7136 ?        Sl   07:55   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
