KEY             VALUE
AgentLiveness   2137073836511
UTimeOffset     3379442326171875
