xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 508
ens6(5) clsact/ingress cil_from_netdev-ens6 id 509
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 496
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 488
cilium_host(7) clsact/egress cil_from_host-cilium_host id 492
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 542
lxcb4be5b2b805e(12) clsact/ingress cil_from_container-lxcb4be5b2b805e id 535
lxc325a9d7006dc(14) clsact/ingress cil_from_container-lxc325a9d7006dc id 557
lxce92349a8753a(18) clsact/ingress cil_from_container-lxce92349a8753a id 615

flow_dissector:

netfilter:

