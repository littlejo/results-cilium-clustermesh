1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:61:fd:17:cd:ef brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.167.218/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3531sec preferred_lft 3531sec
    inet6 fe80::461:fdff:fe17:cdef/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:2b:c4:fa:4c:51 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.159.191/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::42b:c4ff:fefa:4c51/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:9e:9e:a8:8f:6c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b09e:9eff:fea8:8f6c/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:ba:9a:33:33:2f brd ff:ff:ff:ff:ff:ff
    inet 10.194.0.30/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::ecba:9aff:fe33:332f/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 1a:4d:78:0b:64:e7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::184d:78ff:fe0b:64e7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:dc:b0:63:51:9b brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::70dc:b0ff:fe63:519b/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb4be5b2b805e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:a7:2d:9d:54:2b brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8a7:2dff:fe9d:542b/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc325a9d7006dc@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:d6:ce:fc:e8:e2 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::44d6:ceff:fefc:e8e2/64 scope link 
       valid_lft forever preferred_lft forever
18: lxce92349a8753a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:6e:ad:69:e5:27 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e86e:adff:fe69:e527/64 scope link 
       valid_lft forever preferred_lft forever
