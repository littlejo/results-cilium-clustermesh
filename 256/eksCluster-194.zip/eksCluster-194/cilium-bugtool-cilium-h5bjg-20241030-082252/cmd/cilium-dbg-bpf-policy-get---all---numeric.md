Endpoint ID: 1204
Path: /sys/fs/bpf/tc/globals/cilium_policy_01204

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11576855   116656    0        
Allow    Ingress     1          ANY          NONE         disabled    10884462   114897    0        
Allow    Egress      0          ANY          NONE         disabled    14604035   142646    0        


Endpoint ID: 1927
Path: /sys/fs/bpf/tc/globals/cilium_policy_01927

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    123565   1418      0        
Allow    Egress      0          ANY          NONE         disabled    17519    190       0        


Endpoint ID: 2570
Path: /sys/fs/bpf/tc/globals/cilium_policy_02570

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1648764   20799     0        
Allow    Ingress     1          ANY          NONE         disabled    18814     220       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3220
Path: /sys/fs/bpf/tc/globals/cilium_policy_03220

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    123444   1420      0        
Allow    Egress      0          ANY          NONE         disabled    17349    188       0        


Endpoint ID: 3831
Path: /sys/fs/bpf/tc/globals/cilium_policy_03831

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


