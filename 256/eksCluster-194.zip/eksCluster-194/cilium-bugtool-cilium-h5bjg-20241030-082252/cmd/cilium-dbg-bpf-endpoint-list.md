IP ADDRESS         LOCAL ENDPOINT INFO
10.194.0.117:0     id=1204  sec_id=6403296 flags=0x0000 ifindex=18  mac=FA:54:60:60:ED:69 nodemac=EA:6E:AD:69:E5:27   
10.194.0.231:0     id=1927  sec_id=6390709 flags=0x0000 ifindex=12  mac=1E:A0:8B:1C:0D:64 nodemac=0A:A7:2D:9D:54:2B   
10.194.0.247:0     id=2570  sec_id=4     flags=0x0000 ifindex=10  mac=2A:8F:94:6C:E3:C4 nodemac=72:DC:B0:63:51:9B     
10.194.0.81:0      id=3220  sec_id=6390709 flags=0x0000 ifindex=14  mac=5A:DD:30:0E:54:5E nodemac=46:D6:CE:FC:E8:E2   
10.194.0.30:0      (localhost)                                                                                        
172.31.159.191:0   (localhost)                                                                                        
172.31.167.218:0   (localhost)                                                                                        
