[
  {
    "containers": [
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9779fe22_5872_4906_b0d1_702b7a3e071d.slice/cri-containerd-df0d0664ef3ac17a317b9b02f2c42fb8f9027223817d7409598fa040470569fe.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9779fe22_5872_4906_b0d1_702b7a3e071d.slice/cri-containerd-22601459fdd2196089b03b638caa6445601338ca35e180dc840e0671fa2f7b35.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9779fe22_5872_4906_b0d1_702b7a3e071d.slice/cri-containerd-60b31eb3a2014916959ce102a6e0570ff26fffcc08b38d0349dcc8b52a40038e.scope"
      }
    ],
    "ips": [
      "10.194.0.117"
    ],
    "name": "clustermesh-apiserver-75d5476488-6wzd5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0343a0ca_144b_4061_92ae_d9f7d6caacc3.slice/cri-containerd-99b0271c891f5e328c1527c97a228cd8b32338c94df1baae59aa509764eb5424.scope"
      }
    ],
    "ips": [
      "10.194.0.81"
    ],
    "name": "coredns-cc6ccd49c-9gwgs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod622298e1_4d03_4ff5_b449_9033e7921a02.slice/cri-containerd-09dfbdbf4436b51b68a694938676959e1589746dab970e3acbcad698ed712ecc.scope"
      }
    ],
    "ips": [
      "10.194.0.231"
    ],
    "name": "coredns-cc6ccd49c-xvqf9",
    "namespace": "kube-system"
  }
]

