ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.252.102:443 (active)    
                                         2 => 172.31.171.220:443 (active)    
2    10.100.55.240:443    ClusterIP      1 => 172.31.167.218:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.194.0.81:53 (active)        
                                         2 => 10.194.0.231:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.194.0.81:9153 (active)      
                                         2 => 10.194.0.231:9153 (active)     
5    10.100.254.32:2379   ClusterIP      1 => 10.194.0.117:2379 (active)     
