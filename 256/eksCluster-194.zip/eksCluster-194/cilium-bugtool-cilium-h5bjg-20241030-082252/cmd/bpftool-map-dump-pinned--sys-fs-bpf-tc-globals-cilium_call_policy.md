key: b4 04 00 00  value: 71 02 00 00
key: 87 07 00 00  value: 13 02 00 00
key: 0a 0a 00 00  value: 2e 02 00 00
key: 94 0c 00 00  value: 23 02 00 00
Found 4 elements
