 08:22:53 up 31 min,  0 users,  load average: 0.63, 0.35, 0.22
