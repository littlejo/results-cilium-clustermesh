{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:52.524Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.159.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:52.524Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.167.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:52.524Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:57.004Z",
  "value": "id=2570  sec_id=4     flags=0x0000 ifindex=10  mac=2A:8F:94:6C:E3:C4 nodemac=72:DC:B0:63:51:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:57.005Z",
  "value": "id=1927  sec_id=6390709 flags=0x0000 ifindex=12  mac=1E:A0:8B:1C:0D:64 nodemac=0A:A7:2D:9D:54:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:57.056Z",
  "value": "id=3220  sec_id=6390709 flags=0x0000 ifindex=14  mac=5A:DD:30:0E:54:5E nodemac=46:D6:CE:FC:E8:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:57.057Z",
  "value": "id=1927  sec_id=6390709 flags=0x0000 ifindex=12  mac=1E:A0:8B:1C:0D:64 nodemac=0A:A7:2D:9D:54:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:57.064Z",
  "value": "id=2570  sec_id=4     flags=0x0000 ifindex=10  mac=2A:8F:94:6C:E3:C4 nodemac=72:DC:B0:63:51:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:56.144Z",
  "value": "id=3220  sec_id=6390709 flags=0x0000 ifindex=14  mac=5A:DD:30:0E:54:5E nodemac=46:D6:CE:FC:E8:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:56.146Z",
  "value": "id=2570  sec_id=4     flags=0x0000 ifindex=10  mac=2A:8F:94:6C:E3:C4 nodemac=72:DC:B0:63:51:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:56.146Z",
  "value": "id=1927  sec_id=6390709 flags=0x0000 ifindex=12  mac=1E:A0:8B:1C:0D:64 nodemac=0A:A7:2D:9D:54:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:56.173Z",
  "value": "id=2291  sec_id=6403296 flags=0x0000 ifindex=16  mac=16:F0:1A:86:D2:AA nodemac=F2:04:B4:89:E3:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:56.174Z",
  "value": "id=2291  sec_id=6403296 flags=0x0000 ifindex=16  mac=16:F0:1A:86:D2:AA nodemac=F2:04:B4:89:E3:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:57.144Z",
  "value": "id=2291  sec_id=6403296 flags=0x0000 ifindex=16  mac=16:F0:1A:86:D2:AA nodemac=F2:04:B4:89:E3:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:57.145Z",
  "value": "id=3220  sec_id=6390709 flags=0x0000 ifindex=14  mac=5A:DD:30:0E:54:5E nodemac=46:D6:CE:FC:E8:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:57.145Z",
  "value": "id=2570  sec_id=4     flags=0x0000 ifindex=10  mac=2A:8F:94:6C:E3:C4 nodemac=72:DC:B0:63:51:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:57.145Z",
  "value": "id=1927  sec_id=6390709 flags=0x0000 ifindex=12  mac=1E:A0:8B:1C:0D:64 nodemac=0A:A7:2D:9D:54:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:52.056Z",
  "value": "id=1204  sec_id=6403296 flags=0x0000 ifindex=18  mac=FA:54:60:60:ED:69 nodemac=EA:6E:AD:69:E5:27"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.194.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:02.418Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.825Z",
  "value": "id=1204  sec_id=6403296 flags=0x0000 ifindex=18  mac=FA:54:60:60:ED:69 nodemac=EA:6E:AD:69:E5:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.826Z",
  "value": "id=2570  sec_id=4     flags=0x0000 ifindex=10  mac=2A:8F:94:6C:E3:C4 nodemac=72:DC:B0:63:51:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.826Z",
  "value": "id=1927  sec_id=6390709 flags=0x0000 ifindex=12  mac=1E:A0:8B:1C:0D:64 nodemac=0A:A7:2D:9D:54:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.826Z",
  "value": "id=3220  sec_id=6390709 flags=0x0000 ifindex=14  mac=5A:DD:30:0E:54:5E nodemac=46:D6:CE:FC:E8:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.830Z",
  "value": "id=1927  sec_id=6390709 flags=0x0000 ifindex=12  mac=1E:A0:8B:1C:0D:64 nodemac=0A:A7:2D:9D:54:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.832Z",
  "value": "id=3220  sec_id=6390709 flags=0x0000 ifindex=14  mac=5A:DD:30:0E:54:5E nodemac=46:D6:CE:FC:E8:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.832Z",
  "value": "id=1204  sec_id=6403296 flags=0x0000 ifindex=18  mac=FA:54:60:60:ED:69 nodemac=EA:6E:AD:69:E5:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.833Z",
  "value": "id=2570  sec_id=4     flags=0x0000 ifindex=10  mac=2A:8F:94:6C:E3:C4 nodemac=72:DC:B0:63:51:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.826Z",
  "value": "id=1927  sec_id=6390709 flags=0x0000 ifindex=12  mac=1E:A0:8B:1C:0D:64 nodemac=0A:A7:2D:9D:54:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.826Z",
  "value": "id=2570  sec_id=4     flags=0x0000 ifindex=10  mac=2A:8F:94:6C:E3:C4 nodemac=72:DC:B0:63:51:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.826Z",
  "value": "id=3220  sec_id=6390709 flags=0x0000 ifindex=14  mac=5A:DD:30:0E:54:5E nodemac=46:D6:CE:FC:E8:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.827Z",
  "value": "id=1204  sec_id=6403296 flags=0x0000 ifindex=18  mac=FA:54:60:60:ED:69 nodemac=EA:6E:AD:69:E5:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:35.826Z",
  "value": "id=1927  sec_id=6390709 flags=0x0000 ifindex=12  mac=1E:A0:8B:1C:0D:64 nodemac=0A:A7:2D:9D:54:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:35.826Z",
  "value": "id=2570  sec_id=4     flags=0x0000 ifindex=10  mac=2A:8F:94:6C:E3:C4 nodemac=72:DC:B0:63:51:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:35.826Z",
  "value": "id=3220  sec_id=6390709 flags=0x0000 ifindex=14  mac=5A:DD:30:0E:54:5E nodemac=46:D6:CE:FC:E8:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.194.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:35.827Z",
  "value": "id=1204  sec_id=6403296 flags=0x0000 ifindex=18  mac=FA:54:60:60:ED:69 nodemac=EA:6E:AD:69:E5:27"
}

