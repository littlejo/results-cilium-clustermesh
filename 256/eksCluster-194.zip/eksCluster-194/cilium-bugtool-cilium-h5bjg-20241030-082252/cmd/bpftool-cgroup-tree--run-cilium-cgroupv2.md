CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf0a530e7_7fa1_425b_ac93_4c7cae228fd4.slice/cri-containerd-80ab18858841bbfc4294a10cbd226c7a66ff7067239f1fb78e2a4262e7a5c00c.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf0a530e7_7fa1_425b_ac93_4c7cae228fd4.slice/cri-containerd-7ee56041f531db31975792551c4bf39501e8682eced5608c8456dcddd8951134.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod622298e1_4d03_4ff5_b449_9033e7921a02.slice/cri-containerd-09dfbdbf4436b51b68a694938676959e1589746dab970e3acbcad698ed712ecc.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod622298e1_4d03_4ff5_b449_9033e7921a02.slice/cri-containerd-64d9708a6b9086f6a547243dd06eb4c944a501a00d661187e7724c7a2440f6f0.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0343a0ca_144b_4061_92ae_d9f7d6caacc3.slice/cri-containerd-e3279addeeff7be920712e3cdd74e041837fa1d9f6e85665e8ab55b5565375d8.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0343a0ca_144b_4061_92ae_d9f7d6caacc3.slice/cri-containerd-99b0271c891f5e328c1527c97a228cd8b32338c94df1baae59aa509764eb5424.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc319f38f_f534_42f7_8d60_bf00195d8aba.slice/cri-containerd-d56028581da225245e1fbf01f161e09ce634729234b3a8ddceceb6d00dced3d4.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc319f38f_f534_42f7_8d60_bf00195d8aba.slice/cri-containerd-19eecde41f615690b9aa933bd934ed989b896c0595e0d3e2c2b83ee689450d35.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9779fe22_5872_4906_b0d1_702b7a3e071d.slice/cri-containerd-60b31eb3a2014916959ce102a6e0570ff26fffcc08b38d0349dcc8b52a40038e.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9779fe22_5872_4906_b0d1_702b7a3e071d.slice/cri-containerd-df0d0664ef3ac17a317b9b02f2c42fb8f9027223817d7409598fa040470569fe.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9779fe22_5872_4906_b0d1_702b7a3e071d.slice/cri-containerd-22601459fdd2196089b03b638caa6445601338ca35e180dc840e0671fa2f7b35.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9779fe22_5872_4906_b0d1_702b7a3e071d.slice/cri-containerd-fd353e3349431ff1f7bc6dde286bcd19f8306cc4cfef5f7b1a613ecfa0734445.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbaa5351f_680b_4f62_8dcf_39ec5d5aebe4.slice/cri-containerd-40cce1d2fe0dec2c28ff2bcf07054aced904cc48490c2efd5cbed994e68a0524.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbaa5351f_680b_4f62_8dcf_39ec5d5aebe4.slice/cri-containerd-da92bb9b8036205a756ebbb92aa645a6b6b45b58e73fa186941c2eefbb7cde65.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod51a3a79d_a180_4a81_986b_65edf3a829ec.slice/cri-containerd-297259702937b78d443d9f3a09e4adbe29fe0c65982089cbdea16aea1e129598.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod51a3a79d_a180_4a81_986b_65edf3a829ec.slice/cri-containerd-88e8bc4552c9c845dfff70d16d2c4e646411e42b1e0951c2f7cf5873bba26b19.scope
    109      cgroup_device   multi                                          
