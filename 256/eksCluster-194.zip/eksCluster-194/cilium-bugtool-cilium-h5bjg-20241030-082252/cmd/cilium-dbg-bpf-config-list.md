KEY             VALUE
AgentLiveness   1910084258511
UTimeOffset     3379442761718750
