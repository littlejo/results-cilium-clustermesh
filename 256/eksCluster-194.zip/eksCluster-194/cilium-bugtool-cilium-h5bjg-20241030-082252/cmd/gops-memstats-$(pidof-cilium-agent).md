alloc: 119.84MB (125665360 bytes)
total-alloc: 2.33GB (2505025056 bytes)
sys: 332.52MB (348672356 bytes)
lookups: 0
mallocs: 64880713
frees: 63883477
heap-alloc: 119.84MB (125665360 bytes)
heap-sys: 255.45MB (267862016 bytes)
heap-idle: 89.07MB (93396992 bytes)
heap-in-use: 166.38MB (174465024 bytes)
heap-released: 8.62MB (9043968 bytes)
heap-objects: 997236
stack-in-use: 64.50MB (67633152 bytes)
stack-sys: 64.50MB (67633152 bytes)
stack-mspan-inuse: 2.79MB (2921600 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 804.83KB (824145 bytes)
gc-sys: 6.00MB (6288752 bytes)
next-gc: when heap-alloc >= 213.84MB (224226152 bytes)
last-gc: 2024-10-30 08:23:10.719315712 +0000 UTC
gc-pause-total: 13.459105ms
gc-pause: 298311
gc-pause-end: 1730276590719315712
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005288024759726573
enable-gc: true
debug-gc: false
