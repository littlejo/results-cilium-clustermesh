[
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podecf57734_c19d_4ede_b853_133af26bc4b0.slice/cri-containerd-7fafa9e73acdef8c3efe14245b813c253b5c2a2704032f404adb2a6174b89f65.scope"
      }
    ],
    "ips": [
      "10.199.0.152"
    ],
    "name": "coredns-cc6ccd49c-c9tf5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9268,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod707203cc_8898_4b9c_9a81_0dcdae4a7580.slice/cri-containerd-c3efd8c43f3133fed0fb49ed899e7f0228aaba8834646bc20902a1131b03b23f.scope"
      },
      {
        "cgroup-id": 9184,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod707203cc_8898_4b9c_9a81_0dcdae4a7580.slice/cri-containerd-3298949cf7ca8817c4458b4d626fd9e08d9bf0d712b8d61b7da367dc87dd3a61.scope"
      },
      {
        "cgroup-id": 9352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod707203cc_8898_4b9c_9a81_0dcdae4a7580.slice/cri-containerd-b8c7fff82921c0e4cf9f145849c938d2d665b604fe615d199ccbe9687c86278b.scope"
      }
    ],
    "ips": [
      "10.199.0.29"
    ],
    "name": "clustermesh-apiserver-7b9b6467f4-5whnf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod74e6ac9e_5e2d_4aac_802a_c2dec8731407.slice/cri-containerd-040388f952025145688244f18202572058cb5c51462cd6e07fecb6f7a32afd99.scope"
      }
    ],
    "ips": [
      "10.199.0.227"
    ],
    "name": "coredns-cc6ccd49c-hr97j",
    "namespace": "kube-system"
  }
]

