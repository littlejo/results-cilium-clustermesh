ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.255.56:443 (active)    
                                          2 => 172.31.161.130:443 (active)   
2    10.100.172.1:443      ClusterIP      1 => 172.31.205.54:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.199.0.152:9153 (active)    
                                          2 => 10.199.0.227:9153 (active)    
4    10.100.0.10:53        ClusterIP      1 => 10.199.0.152:53 (active)      
                                          2 => 10.199.0.227:53 (active)      
5    10.100.133.189:2379   ClusterIP      1 => 10.199.0.29:2379 (active)     
