IP ADDRESS        LOCAL ENDPOINT INFO
172.31.205.54:0   (localhost)                                                                                        
10.199.0.14:0     (localhost)                                                                                        
10.199.0.92:0     id=1880  sec_id=4     flags=0x0000 ifindex=10  mac=D6:69:B4:FD:BC:E9 nodemac=2A:FB:2D:CD:F3:F3     
10.199.0.227:0    id=3718  sec_id=6561604 flags=0x0000 ifindex=14  mac=92:22:BE:59:D1:7A nodemac=6E:C9:81:84:67:00   
172.31.246.31:0   (localhost)                                                                                        
10.199.0.29:0     id=1173  sec_id=6582984 flags=0x0000 ifindex=18  mac=5A:A7:B7:93:6E:BD nodemac=A6:B1:BC:B3:C1:1F   
10.199.0.152:0    id=290   sec_id=6561604 flags=0x0000 ifindex=12  mac=AA:CF:10:30:32:1C nodemac=FA:10:F3:D7:7F:2C   
