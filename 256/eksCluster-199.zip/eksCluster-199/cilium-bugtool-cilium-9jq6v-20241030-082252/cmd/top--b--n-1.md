top - 08:22:53 up 30 min,  0 users,  load average: 0.90, 0.41, 0.24
Tasks:   8 total,   2 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 51.7 us, 31.0 sy,  0.0 ni, 17.2 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4501.4 free,   1167.4 used,   2145.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6461.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606400 385672  80044 S  93.3   4.8   0:44.79 cilium-+
    396 root      20   0 1229744   7020   2924 S   0.0   0.1   0:01.15 cilium-+
    633 root      20   0 1240432  16168  11292 S   0.0   0.2   0:00.03 cilium-+
    644 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    684 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    690 root      20   0    6576   2420   2096 R   0.0   0.0   0:00.00 top
    712 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    714 root      20   0 1539912   8744   6472 R   0.0   0.1   0:00.00 runc:[2+
