{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:35.586Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.205.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:35.586Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.246.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:35.586Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:40.226Z",
  "value": "id=1880  sec_id=4     flags=0x0000 ifindex=10  mac=D6:69:B4:FD:BC:E9 nodemac=2A:FB:2D:CD:F3:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:40.228Z",
  "value": "id=290   sec_id=6561604 flags=0x0000 ifindex=12  mac=AA:CF:10:30:32:1C nodemac=FA:10:F3:D7:7F:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:40.263Z",
  "value": "id=3718  sec_id=6561604 flags=0x0000 ifindex=14  mac=92:22:BE:59:D1:7A nodemac=6E:C9:81:84:67:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:40.264Z",
  "value": "id=290   sec_id=6561604 flags=0x0000 ifindex=12  mac=AA:CF:10:30:32:1C nodemac=FA:10:F3:D7:7F:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:40.303Z",
  "value": "id=1880  sec_id=4     flags=0x0000 ifindex=10  mac=D6:69:B4:FD:BC:E9 nodemac=2A:FB:2D:CD:F3:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:21.600Z",
  "value": "id=1880  sec_id=4     flags=0x0000 ifindex=10  mac=D6:69:B4:FD:BC:E9 nodemac=2A:FB:2D:CD:F3:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:21.600Z",
  "value": "id=290   sec_id=6561604 flags=0x0000 ifindex=12  mac=AA:CF:10:30:32:1C nodemac=FA:10:F3:D7:7F:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:21.601Z",
  "value": "id=3718  sec_id=6561604 flags=0x0000 ifindex=14  mac=92:22:BE:59:D1:7A nodemac=6E:C9:81:84:67:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:21.631Z",
  "value": "id=990   sec_id=6582984 flags=0x0000 ifindex=16  mac=62:9E:2D:B5:5D:D7 nodemac=CE:87:86:09:CE:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:22.600Z",
  "value": "id=1880  sec_id=4     flags=0x0000 ifindex=10  mac=D6:69:B4:FD:BC:E9 nodemac=2A:FB:2D:CD:F3:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:22.600Z",
  "value": "id=3718  sec_id=6561604 flags=0x0000 ifindex=14  mac=92:22:BE:59:D1:7A nodemac=6E:C9:81:84:67:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:22.600Z",
  "value": "id=290   sec_id=6561604 flags=0x0000 ifindex=12  mac=AA:CF:10:30:32:1C nodemac=FA:10:F3:D7:7F:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:22.600Z",
  "value": "id=990   sec_id=6582984 flags=0x0000 ifindex=16  mac=62:9E:2D:B5:5D:D7 nodemac=CE:87:86:09:CE:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.343Z",
  "value": "id=1173  sec_id=6582984 flags=0x0000 ifindex=18  mac=5A:A7:B7:93:6E:BD nodemac=A6:B1:BC:B3:C1:1F"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.199.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.859Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:04.368Z",
  "value": "id=1173  sec_id=6582984 flags=0x0000 ifindex=18  mac=5A:A7:B7:93:6E:BD nodemac=A6:B1:BC:B3:C1:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:04.369Z",
  "value": "id=1880  sec_id=4     flags=0x0000 ifindex=10  mac=D6:69:B4:FD:BC:E9 nodemac=2A:FB:2D:CD:F3:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:04.370Z",
  "value": "id=290   sec_id=6561604 flags=0x0000 ifindex=12  mac=AA:CF:10:30:32:1C nodemac=FA:10:F3:D7:7F:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:04.377Z",
  "value": "id=3718  sec_id=6561604 flags=0x0000 ifindex=14  mac=92:22:BE:59:D1:7A nodemac=6E:C9:81:84:67:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:05.369Z",
  "value": "id=290   sec_id=6561604 flags=0x0000 ifindex=12  mac=AA:CF:10:30:32:1C nodemac=FA:10:F3:D7:7F:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:05.370Z",
  "value": "id=3718  sec_id=6561604 flags=0x0000 ifindex=14  mac=92:22:BE:59:D1:7A nodemac=6E:C9:81:84:67:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:05.371Z",
  "value": "id=1173  sec_id=6582984 flags=0x0000 ifindex=18  mac=5A:A7:B7:93:6E:BD nodemac=A6:B1:BC:B3:C1:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:05.373Z",
  "value": "id=1880  sec_id=4     flags=0x0000 ifindex=10  mac=D6:69:B4:FD:BC:E9 nodemac=2A:FB:2D:CD:F3:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:06.369Z",
  "value": "id=1880  sec_id=4     flags=0x0000 ifindex=10  mac=D6:69:B4:FD:BC:E9 nodemac=2A:FB:2D:CD:F3:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:06.370Z",
  "value": "id=1173  sec_id=6582984 flags=0x0000 ifindex=18  mac=5A:A7:B7:93:6E:BD nodemac=A6:B1:BC:B3:C1:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:06.370Z",
  "value": "id=290   sec_id=6561604 flags=0x0000 ifindex=12  mac=AA:CF:10:30:32:1C nodemac=FA:10:F3:D7:7F:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:06.370Z",
  "value": "id=3718  sec_id=6561604 flags=0x0000 ifindex=14  mac=92:22:BE:59:D1:7A nodemac=6E:C9:81:84:67:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:07.369Z",
  "value": "id=1880  sec_id=4     flags=0x0000 ifindex=10  mac=D6:69:B4:FD:BC:E9 nodemac=2A:FB:2D:CD:F3:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:07.369Z",
  "value": "id=1173  sec_id=6582984 flags=0x0000 ifindex=18  mac=5A:A7:B7:93:6E:BD nodemac=A6:B1:BC:B3:C1:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:07.369Z",
  "value": "id=3718  sec_id=6561604 flags=0x0000 ifindex=14  mac=92:22:BE:59:D1:7A nodemac=6E:C9:81:84:67:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.199.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:07.369Z",
  "value": "id=290   sec_id=6561604 flags=0x0000 ifindex=12  mac=AA:CF:10:30:32:1C nodemac=FA:10:F3:D7:7F:2C"
}

