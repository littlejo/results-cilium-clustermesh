REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34235     2701997     677    bpf_overlay.c
Interface                 INGRESS     607511    127577869   1132   bpf_host.c
Success                   EGRESS      13964     1092485     1694   bpf_host.c
Success                   EGRESS      255179    32675328    1308   bpf_lxc.c
Success                   EGRESS      33042     2615283     53     encap.h
Success                   INGRESS     295928    33205412    86     l3.h
Success                   INGRESS     316850    34858970    235    trace.h
Unsupported L3 protocol   EGRESS      43        3222        1492   bpf_lxc.c
