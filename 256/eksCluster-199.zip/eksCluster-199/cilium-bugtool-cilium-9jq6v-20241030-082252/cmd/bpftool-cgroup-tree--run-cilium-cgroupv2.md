CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod74e6ac9e_5e2d_4aac_802a_c2dec8731407.slice/cri-containerd-e4663e7e0006f89e905e485953ed1210f258134739df71a1aef9d32876d83fc3.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod74e6ac9e_5e2d_4aac_802a_c2dec8731407.slice/cri-containerd-040388f952025145688244f18202572058cb5c51462cd6e07fecb6f7a32afd99.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podecf57734_c19d_4ede_b853_133af26bc4b0.slice/cri-containerd-29633853b693d0f146a575fdd7bd819d46c9c0753fe6ef4efc2f7f1bd33f55ba.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podecf57734_c19d_4ede_b853_133af26bc4b0.slice/cri-containerd-7fafa9e73acdef8c3efe14245b813c253b5c2a2704032f404adb2a6174b89f65.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0130f735_2703_4b41_8d44_161ad0a6d12a.slice/cri-containerd-c27898a8014cb0280454ccc217d77ff496e620bf2eadb6a82981531ddf471532.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0130f735_2703_4b41_8d44_161ad0a6d12a.slice/cri-containerd-b92cf6536b237b532a7a3e3a6eb3489628d8a98f2bb82b847db05449d8181190.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfe7a9b6a_8796_4bfd_bb82_9bb587a82e88.slice/cri-containerd-eb8dbb4e183fa29d78c7a362db558bd6410054610986cb570a823c79bec57b10.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfe7a9b6a_8796_4bfd_bb82_9bb587a82e88.slice/cri-containerd-f3d66e652b37ca94166dfb0ee3aa6743ed85eea932577440d3569d000cc5cefc.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9f3e68e_bf6b_40e0_8844_a688e18ea405.slice/cri-containerd-ec1ec677ac65e0564f30a6cabdfc36f4e687bd077424a31ac054d6c067549b6f.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9f3e68e_bf6b_40e0_8844_a688e18ea405.slice/cri-containerd-587f76154ac6063106aef383b01851007f434f414dc7e91e83aeb78e23cb2df6.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod21478f6c_7b9b_40d5_b06d_eb1bdfe94299.slice/cri-containerd-7bef6e7382cbf4d17dbf6bfc6087c4ae5437fe413a2bfe3265fe8ac340abab36.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod21478f6c_7b9b_40d5_b06d_eb1bdfe94299.slice/cri-containerd-e1f52625af3be707ff9a91ca1b88feb68b0e41f0c4d6a8417324257cc7af8670.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod707203cc_8898_4b9c_9a81_0dcdae4a7580.slice/cri-containerd-b8c7fff82921c0e4cf9f145849c938d2d665b604fe615d199ccbe9687c86278b.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod707203cc_8898_4b9c_9a81_0dcdae4a7580.slice/cri-containerd-32734654b394eb7e0a01f3363e360a0d9940b85b67a7a74d53da89173651ff4c.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod707203cc_8898_4b9c_9a81_0dcdae4a7580.slice/cri-containerd-3298949cf7ca8817c4458b4d626fd9e08d9bf0d712b8d61b7da367dc87dd3a61.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod707203cc_8898_4b9c_9a81_0dcdae4a7580.slice/cri-containerd-c3efd8c43f3133fed0fb49ed899e7f0228aaba8834646bc20902a1131b03b23f.scope
    649      cgroup_device   multi                                          
