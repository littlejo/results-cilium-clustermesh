Endpoint ID: 290
Path: /sys/fs/bpf/tc/globals/cilium_policy_00290

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    117628   1346      0        
Allow    Egress      0          ANY          NONE         disabled    17342    187       0        


Endpoint ID: 680
Path: /sys/fs/bpf/tc/globals/cilium_policy_00680

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1173
Path: /sys/fs/bpf/tc/globals/cilium_policy_01173

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11174748   108725    0        
Allow    Ingress     1          ANY          NONE         disabled    8941243    93184     0        
Allow    Egress      0          ANY          NONE         disabled    10621943   106070    0        


Endpoint ID: 1880
Path: /sys/fs/bpf/tc/globals/cilium_policy_01880

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1656046   20954     0        
Allow    Ingress     1          ANY          NONE         disabled    17488     204       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3718
Path: /sys/fs/bpf/tc/globals/cilium_policy_03718

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    118354   1357      0        
Allow    Egress      0          ANY          NONE         disabled    17095    185       0        


