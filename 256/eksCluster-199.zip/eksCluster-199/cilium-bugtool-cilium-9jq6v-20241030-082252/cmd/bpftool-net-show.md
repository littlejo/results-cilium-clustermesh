xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 502
ens6(5) clsact/ingress cil_from_netdev-ens6 id 512
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 498
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 493
cilium_host(7) clsact/egress cil_from_host-cilium_host id 489
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 545
lxcf6f44ea46e90(12) clsact/ingress cil_from_container-lxcf6f44ea46e90 id 520
lxc4cecea5952f2(14) clsact/ingress cil_from_container-lxc4cecea5952f2 id 548
lxc2d9a82c1db19(18) clsact/ingress cil_from_container-lxc2d9a82c1db19 id 625

flow_dissector:

netfilter:

