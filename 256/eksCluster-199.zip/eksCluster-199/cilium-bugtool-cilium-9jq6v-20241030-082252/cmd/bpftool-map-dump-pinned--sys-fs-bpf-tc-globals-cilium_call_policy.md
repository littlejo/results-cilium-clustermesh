key: 22 01 00 00  value: 15 02 00 00
key: 95 04 00 00  value: 69 02 00 00
key: 58 07 00 00  value: 2a 02 00 00
key: 86 0e 00 00  value: 27 02 00 00
Found 4 elements
