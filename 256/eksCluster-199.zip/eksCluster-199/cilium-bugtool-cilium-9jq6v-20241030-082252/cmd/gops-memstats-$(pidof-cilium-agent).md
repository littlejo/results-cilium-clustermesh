alloc: 172.08MB (180443000 bytes)
total-alloc: 2.14GB (2298415792 bytes)
sys: 325.08MB (340873572 bytes)
lookups: 0
mallocs: 61683656
frees: 59697926
heap-alloc: 172.08MB (180443000 bytes)
heap-sys: 247.51MB (259530752 bytes)
heap-idle: 50.21MB (52649984 bytes)
heap-in-use: 197.30MB (206880768 bytes)
heap-released: 1.65MB (1728512 bytes)
heap-objects: 1985730
stack-in-use: 64.47MB (67600384 bytes)
stack-sys: 64.47MB (67600384 bytes)
stack-mspan-inuse: 3.34MB (3500800 bytes)
stack-mspan-sys: 3.89MB (4080000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.18MB (1239193 bytes)
gc-sys: 6.07MB (6368768 bytes)
next-gc: when heap-alloc >= 212.84MB (223182040 bytes)
last-gc: 2024-10-30 08:22:53.951538997 +0000 UTC
gc-pause-total: 15.132733ms
gc-pause: 169592
gc-pause-end: 1730276573951538997
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005050327604342315
enable-gc: true
debug-gc: false
