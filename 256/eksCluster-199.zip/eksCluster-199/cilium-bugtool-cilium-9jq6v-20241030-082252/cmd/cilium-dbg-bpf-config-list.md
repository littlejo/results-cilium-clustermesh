KEY             VALUE
AgentLiveness   1864143484544
UTimeOffset     3379442851562500
