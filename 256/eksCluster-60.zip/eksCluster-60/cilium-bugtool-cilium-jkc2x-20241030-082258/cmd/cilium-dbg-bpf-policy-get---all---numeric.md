Endpoint ID: 465
Path: /sys/fs/bpf/tc/globals/cilium_policy_00465

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    172469   1976      0        
Allow    Egress      0          ANY          NONE         disabled    22508    253       0        


Endpoint ID: 509
Path: /sys/fs/bpf/tc/globals/cilium_policy_00509

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1669596   21120     0        
Allow    Ingress     1          ANY          NONE         disabled    26484     310       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 882
Path: /sys/fs/bpf/tc/globals/cilium_policy_00882

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174678   2004      0        
Allow    Egress      0          ANY          NONE         disabled    21015    235       0        


Endpoint ID: 3452
Path: /sys/fs/bpf/tc/globals/cilium_policy_03452

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3963
Path: /sys/fs/bpf/tc/globals/cilium_policy_03963

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11609539   116798    0        
Allow    Ingress     1          ANY          NONE         disabled    10808202   114100    0        
Allow    Egress      0          ANY          NONE         disabled    14561567   142246    0        


