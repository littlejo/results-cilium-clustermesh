1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:3b:0d:38:21:2b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.177.157/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3178sec preferred_lft 3178sec
    inet6 fe80::43b:dff:fe38:212b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:0b:ca:8b:5b:d3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.142.47/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::40b:caff:fe8b:5bd3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:79:82:a7:d7:04 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a879:82ff:fea7:d704/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:c0:e3:fd:0e:43 brd ff:ff:ff:ff:ff:ff
    inet 10.60.0.75/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::6cc0:e3ff:fefd:e43/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether c6:de:05:2d:3f:a3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c4de:5ff:fe2d:3fa3/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:c3:df:84:5a:90 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::68c3:dfff:fe84:5a90/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc7292e3518989@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:3a:79:3f:e0:a7 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f43a:79ff:fe3f:e0a7/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcb40ed7995577@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:78:bc:8f:9d:95 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b478:bcff:fe8f:9d95/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc855c22909c0a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:d0:c6:9f:4d:ff brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::54d0:c6ff:fe9f:4dff/64 scope link 
       valid_lft forever preferred_lft forever
