[
  {
    "containers": [
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcef80b23_0981_4a27_b409_2277d810707e.slice/cri-containerd-2bc8648a4efff8de4bdf3399745520f3fe5c7f80b732b41b69a9e8acd593cf83.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcef80b23_0981_4a27_b409_2277d810707e.slice/cri-containerd-990d4faa0376b7e948064ec2d61c0b5f8f4959dfa30c96b439ccfdf7b5493120.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcef80b23_0981_4a27_b409_2277d810707e.slice/cri-containerd-af06a716a2c05aa0e3af48ee1340d045d48f45495ce3eb668c7d36a577d6822c.scope"
      }
    ],
    "ips": [
      "10.60.0.121"
    ],
    "name": "clustermesh-apiserver-5dcc5996bc-5k5rn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb4b20eca_5601_48ad_b5bc_e3306d638069.slice/cri-containerd-e4b58610b82def3a76ad111c3294381aa0db38acb2f983d0d9fb977c93fc61f2.scope"
      }
    ],
    "ips": [
      "10.60.0.95"
    ],
    "name": "coredns-cc6ccd49c-nm2tc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf150cef6_e072_4505_abe2_dfe31e60db21.slice/cri-containerd-872adea3dac2ddea5a70891bb3901abe14aa35965f064405ba1e5562afa56290.scope"
      }
    ],
    "ips": [
      "10.60.0.240"
    ],
    "name": "coredns-cc6ccd49c-svc6b",
    "namespace": "kube-system"
  }
]

