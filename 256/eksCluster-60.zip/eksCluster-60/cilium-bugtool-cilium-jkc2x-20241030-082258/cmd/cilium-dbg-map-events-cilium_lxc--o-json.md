{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:57.699Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.142.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:57.700Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.177.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:57.700Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:02.357Z",
  "value": "id=465   sec_id=2019411 flags=0x0000 ifindex=12  mac=5E:30:43:28:8C:36 nodemac=F6:3A:79:3F:E0:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:02.370Z",
  "value": "id=509   sec_id=4     flags=0x0000 ifindex=10  mac=02:7F:F6:23:AC:C1 nodemac=6A:C3:DF:84:5A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:02.398Z",
  "value": "id=882   sec_id=2019411 flags=0x0000 ifindex=14  mac=CA:1F:32:8A:C0:50 nodemac=B6:78:BC:8F:9D:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:02.516Z",
  "value": "id=465   sec_id=2019411 flags=0x0000 ifindex=12  mac=5E:30:43:28:8C:36 nodemac=F6:3A:79:3F:E0:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:02.554Z",
  "value": "id=509   sec_id=4     flags=0x0000 ifindex=10  mac=02:7F:F6:23:AC:C1 nodemac=6A:C3:DF:84:5A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:18.127Z",
  "value": "id=882   sec_id=2019411 flags=0x0000 ifindex=14  mac=CA:1F:32:8A:C0:50 nodemac=B6:78:BC:8F:9D:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:18.128Z",
  "value": "id=509   sec_id=4     flags=0x0000 ifindex=10  mac=02:7F:F6:23:AC:C1 nodemac=6A:C3:DF:84:5A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:18.128Z",
  "value": "id=465   sec_id=2019411 flags=0x0000 ifindex=12  mac=5E:30:43:28:8C:36 nodemac=F6:3A:79:3F:E0:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:18.158Z",
  "value": "id=1676  sec_id=2004650 flags=0x0000 ifindex=16  mac=BA:07:00:C8:D9:C6 nodemac=9E:CD:D2:3B:F4:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:19.128Z",
  "value": "id=1676  sec_id=2004650 flags=0x0000 ifindex=16  mac=BA:07:00:C8:D9:C6 nodemac=9E:CD:D2:3B:F4:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:19.128Z",
  "value": "id=882   sec_id=2019411 flags=0x0000 ifindex=14  mac=CA:1F:32:8A:C0:50 nodemac=B6:78:BC:8F:9D:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:19.129Z",
  "value": "id=465   sec_id=2019411 flags=0x0000 ifindex=12  mac=5E:30:43:28:8C:36 nodemac=F6:3A:79:3F:E0:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:19.129Z",
  "value": "id=509   sec_id=4     flags=0x0000 ifindex=10  mac=02:7F:F6:23:AC:C1 nodemac=6A:C3:DF:84:5A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.675Z",
  "value": "id=3963  sec_id=2004650 flags=0x0000 ifindex=18  mac=06:51:50:70:E1:67 nodemac=56:D0:C6:9F:4D:FF"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.60.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.043Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.690Z",
  "value": "id=509   sec_id=4     flags=0x0000 ifindex=10  mac=02:7F:F6:23:AC:C1 nodemac=6A:C3:DF:84:5A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.690Z",
  "value": "id=465   sec_id=2019411 flags=0x0000 ifindex=12  mac=5E:30:43:28:8C:36 nodemac=F6:3A:79:3F:E0:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.690Z",
  "value": "id=882   sec_id=2019411 flags=0x0000 ifindex=14  mac=CA:1F:32:8A:C0:50 nodemac=B6:78:BC:8F:9D:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.691Z",
  "value": "id=3963  sec_id=2004650 flags=0x0000 ifindex=18  mac=06:51:50:70:E1:67 nodemac=56:D0:C6:9F:4D:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:47.698Z",
  "value": "id=3963  sec_id=2004650 flags=0x0000 ifindex=18  mac=06:51:50:70:E1:67 nodemac=56:D0:C6:9F:4D:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:47.701Z",
  "value": "id=509   sec_id=4     flags=0x0000 ifindex=10  mac=02:7F:F6:23:AC:C1 nodemac=6A:C3:DF:84:5A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:47.702Z",
  "value": "id=465   sec_id=2019411 flags=0x0000 ifindex=12  mac=5E:30:43:28:8C:36 nodemac=F6:3A:79:3F:E0:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:47.704Z",
  "value": "id=882   sec_id=2019411 flags=0x0000 ifindex=14  mac=CA:1F:32:8A:C0:50 nodemac=B6:78:BC:8F:9D:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:48.695Z",
  "value": "id=509   sec_id=4     flags=0x0000 ifindex=10  mac=02:7F:F6:23:AC:C1 nodemac=6A:C3:DF:84:5A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:48.695Z",
  "value": "id=882   sec_id=2019411 flags=0x0000 ifindex=14  mac=CA:1F:32:8A:C0:50 nodemac=B6:78:BC:8F:9D:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:48.695Z",
  "value": "id=465   sec_id=2019411 flags=0x0000 ifindex=12  mac=5E:30:43:28:8C:36 nodemac=F6:3A:79:3F:E0:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:48.695Z",
  "value": "id=3963  sec_id=2004650 flags=0x0000 ifindex=18  mac=06:51:50:70:E1:67 nodemac=56:D0:C6:9F:4D:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.695Z",
  "value": "id=3963  sec_id=2004650 flags=0x0000 ifindex=18  mac=06:51:50:70:E1:67 nodemac=56:D0:C6:9F:4D:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.696Z",
  "value": "id=509   sec_id=4     flags=0x0000 ifindex=10  mac=02:7F:F6:23:AC:C1 nodemac=6A:C3:DF:84:5A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.696Z",
  "value": "id=465   sec_id=2019411 flags=0x0000 ifindex=12  mac=5E:30:43:28:8C:36 nodemac=F6:3A:79:3F:E0:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.696Z",
  "value": "id=882   sec_id=2019411 flags=0x0000 ifindex=14  mac=CA:1F:32:8A:C0:50 nodemac=B6:78:BC:8F:9D:95"
}

