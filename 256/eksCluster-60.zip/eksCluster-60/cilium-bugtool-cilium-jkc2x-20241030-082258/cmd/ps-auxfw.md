USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         631  0.0  0.2 1240176 16276 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         646  0.0  0.0   6408  1632 ?        R    08:22   0:00  \_ ps auxfw
root         648  0.0  0.0   1980   464 ?        R    08:22   0:00  \_ ip a
root           1  3.1  4.7 1605824 378792 ?      Ssl  07:52   0:57 cilium-agent --config-dir=/tmp/cilium/config-map
root         405  0.0  0.1 1229744 8212 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
