top - 08:22:59 up 37 min,  0 users,  load average: 0.08, 0.16, 0.16
Tasks:  10 total,   4 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 53.3 us, 46.7 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4476.7 free,   1192.5 used,   2145.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6436.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1605824 379116  78200 S  13.3   4.7   0:57.22 cilium-+
    631 root      20   0 1240432  16276  11420 S   6.7   0.2   0:00.03 cilium-+
    405 root      20   0 1229744   8212   3900 S   0.0   0.1   0:01.17 cilium-+
    657 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    668 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    670 root      20   0 1229000   4748   3876 S   0.0   0.1   0:00.00 gops
    685 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    686 root      20   0 1228488   1756   1456 R   0.0   0.0   0:00.00 gops
    700 root      20   0 1616008   8756   6476 R   0.0   0.1   0:00.00 runc:[2+
    713 root      20   0    3852   1292   1136 R   0.0   0.0   0:00.00 bash
