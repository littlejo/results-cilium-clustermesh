ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.148.38:443 (active)     
                                         2 => 172.31.224.187:443 (active)    
2    10.100.116.57:443    ClusterIP      1 => 172.31.177.157:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.60.0.95:53 (active)         
                                         2 => 10.60.0.240:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.60.0.95:9153 (active)       
                                         2 => 10.60.0.240:9153 (active)      
5    10.100.46.115:2379   ClusterIP      1 => 10.60.0.121:2379 (active)      
