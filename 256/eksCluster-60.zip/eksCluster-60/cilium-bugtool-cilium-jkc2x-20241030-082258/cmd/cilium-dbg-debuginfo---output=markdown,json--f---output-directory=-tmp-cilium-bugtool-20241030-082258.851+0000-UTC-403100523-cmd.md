markdown output at /tmp/cilium-bugtool-20241030-082258.851+0000-UTC-403100523/cmd/cilium-debuginfo-20241030-082330.403+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082258.851+0000-UTC-403100523/cmd/cilium-debuginfo-20241030-082330.403+0000-UTC.json
