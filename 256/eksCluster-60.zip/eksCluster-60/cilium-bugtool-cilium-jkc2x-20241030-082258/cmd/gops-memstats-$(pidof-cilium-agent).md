alloc: 112.03MB (117476704 bytes)
total-alloc: 2.39GB (2564955216 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 65585164
frees: 64900945
heap-alloc: 112.03MB (117476704 bytes)
heap-sys: 255.95MB (268378112 bytes)
heap-idle: 81.67MB (85639168 bytes)
heap-in-use: 174.27MB (182738944 bytes)
heap-released: 3.52MB (3694592 bytes)
heap-objects: 684219
stack-in-use: 60.03MB (62947328 bytes)
stack-sys: 60.03MB (62947328 bytes)
stack-mspan-inuse: 2.75MB (2884320 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.03MB (1083673 bytes)
gc-sys: 5.98MB (6268272 bytes)
next-gc: when heap-alloc >= 211.91MB (222201640 bytes)
last-gc: 2024-10-30 08:23:29.137096797 +0000 UTC
gc-pause-total: 9.40086ms
gc-pause: 119928
gc-pause-end: 1730276609137096797
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00033226897278719735
enable-gc: true
debug-gc: false
