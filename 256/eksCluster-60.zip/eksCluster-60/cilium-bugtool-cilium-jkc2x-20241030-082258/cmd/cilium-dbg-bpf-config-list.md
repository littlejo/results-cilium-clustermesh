KEY             VALUE
AgentLiveness   2262260826956
UTimeOffset     3379442085937500
