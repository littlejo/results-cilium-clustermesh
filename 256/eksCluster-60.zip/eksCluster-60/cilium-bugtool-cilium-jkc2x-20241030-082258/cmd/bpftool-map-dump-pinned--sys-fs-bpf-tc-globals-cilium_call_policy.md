key: d1 01 00 00  value: 06 02 00 00
key: fd 01 00 00  value: 1d 02 00 00
key: 72 03 00 00  value: fb 01 00 00
key: 7b 0f 00 00  value: 71 02 00 00
Found 4 elements
