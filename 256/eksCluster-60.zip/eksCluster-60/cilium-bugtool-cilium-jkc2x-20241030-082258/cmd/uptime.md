 08:22:58 up 37 min,  0 users,  load average: 0.08, 0.16, 0.16
