CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf9ee1e38_28c6_4299_b795_53edc470ebc6.slice/cri-containerd-1e8d119f24490361d04065864b62cdba19c7f3c7ba0674528aa893eaca111b3c.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf9ee1e38_28c6_4299_b795_53edc470ebc6.slice/cri-containerd-e7e20a203695b51c1c636b04fe399af9b6008e386ad506ce1838a8fb4e96a717.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf150cef6_e072_4505_abe2_dfe31e60db21.slice/cri-containerd-872adea3dac2ddea5a70891bb3901abe14aa35965f064405ba1e5562afa56290.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf150cef6_e072_4505_abe2_dfe31e60db21.slice/cri-containerd-656ae865457ed0e3ea93e59e8e1db8e87cc34b34e5757daa98c990783dc52650.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb4b20eca_5601_48ad_b5bc_e3306d638069.slice/cri-containerd-e4b58610b82def3a76ad111c3294381aa0db38acb2f983d0d9fb977c93fc61f2.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb4b20eca_5601_48ad_b5bc_e3306d638069.slice/cri-containerd-76c097a3e82846b21beb4f1f8441ae1ea62919b05532e0af4b8e59dce1c12d00.scope
    526      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod242fc6d8_f2fb_44a4_b4ec_2887eaeec4f0.slice/cri-containerd-b6489ea6e77bf5e9e626beca7a79c2bc50eabb5433e85c21306ddb38002627e3.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod242fc6d8_f2fb_44a4_b4ec_2887eaeec4f0.slice/cri-containerd-0d7ddea21ecb1bfdf01fff9c5f613d90112d101c1a9ec676c44ee547743ecf93.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcdd544ec_d9e5_4899_8f32_7dfc9f80e004.slice/cri-containerd-f6e47daa0cb0168d7d2393a89fb230fbadc5db6dfaffe1e9686d5059fbedfe51.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcdd544ec_d9e5_4899_8f32_7dfc9f80e004.slice/cri-containerd-ca00ec0074d45097d1bd1ad50052ffa1fdafbd554e4e0e2e0b07466ebf737596.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcef80b23_0981_4a27_b409_2277d810707e.slice/cri-containerd-990d4faa0376b7e948064ec2d61c0b5f8f4959dfa30c96b439ccfdf7b5493120.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcef80b23_0981_4a27_b409_2277d810707e.slice/cri-containerd-2bc8648a4efff8de4bdf3399745520f3fe5c7f80b732b41b69a9e8acd593cf83.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcef80b23_0981_4a27_b409_2277d810707e.slice/cri-containerd-7155d7c2d9bfbc739633af499f8f29e75f3633a24c1f92aec7480a5abfc9bca1.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcef80b23_0981_4a27_b409_2277d810707e.slice/cri-containerd-af06a716a2c05aa0e3af48ee1340d045d48f45495ce3eb668c7d36a577d6822c.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod02c3c6ca_0cd7_4ade_934c_fba099710d40.slice/cri-containerd-0a5b3979356ee047091242e0d3e70c4d0317b0d0cde21365b15f5241f04002fd.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod02c3c6ca_0cd7_4ade_934c_fba099710d40.slice/cri-containerd-2c001da21454c994ff494c2751d67f80a7bdaee744005a72c00858bf458ae95e.scope
    99       cgroup_device   multi                                          
