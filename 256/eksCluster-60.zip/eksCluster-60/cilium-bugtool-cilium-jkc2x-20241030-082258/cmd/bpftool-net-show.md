xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 573
ens6(5) clsact/ingress cil_from_netdev-ens6 id 574
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 565
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 559
cilium_host(7) clsact/egress cil_from_host-cilium_host id 555
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 479
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 539
lxc7292e3518989(12) clsact/ingress cil_from_container-lxc7292e3518989 id 522
lxcb40ed7995577(14) clsact/ingress cil_from_container-lxcb40ed7995577 id 513
lxc855c22909c0a(18) clsact/ingress cil_from_container-lxc855c22909c0a id 627

flow_dissector:

netfilter:

