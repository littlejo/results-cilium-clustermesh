IP ADDRESS         LOCAL ENDPOINT INFO
10.60.0.164:0      id=509   sec_id=4     flags=0x0000 ifindex=10  mac=02:7F:F6:23:AC:C1 nodemac=6A:C3:DF:84:5A:90     
10.60.0.121:0      id=3963  sec_id=2004650 flags=0x0000 ifindex=18  mac=06:51:50:70:E1:67 nodemac=56:D0:C6:9F:4D:FF   
172.31.177.157:0   (localhost)                                                                                        
10.60.0.95:0       id=465   sec_id=2019411 flags=0x0000 ifindex=12  mac=5E:30:43:28:8C:36 nodemac=F6:3A:79:3F:E0:A7   
10.60.0.240:0      id=882   sec_id=2019411 flags=0x0000 ifindex=14  mac=CA:1F:32:8A:C0:50 nodemac=B6:78:BC:8F:9D:95   
10.60.0.75:0       (localhost)                                                                                        
172.31.142.47:0    (localhost)                                                                                        
