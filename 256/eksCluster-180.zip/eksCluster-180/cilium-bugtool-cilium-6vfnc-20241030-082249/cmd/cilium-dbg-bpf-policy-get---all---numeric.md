Endpoint ID: 97
Path: /sys/fs/bpf/tc/globals/cilium_policy_00097

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 482
Path: /sys/fs/bpf/tc/globals/cilium_policy_00482

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113211   1297      0        
Allow    Egress      0          ANY          NONE         disabled    16276    176       0        


Endpoint ID: 1011
Path: /sys/fs/bpf/tc/globals/cilium_policy_01011

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11582358   116683    0        
Allow    Ingress     1          ANY          NONE         disabled    10513011   111137    0        
Allow    Egress      0          ANY          NONE         disabled    14556480   142171    0        


Endpoint ID: 1791
Path: /sys/fs/bpf/tc/globals/cilium_policy_01791

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1644449   20749     0        
Allow    Ingress     1          ANY          NONE         disabled    19374     231       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1945
Path: /sys/fs/bpf/tc/globals/cilium_policy_01945

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113908   1304      0        
Allow    Egress      0          ANY          NONE         disabled    16434    177       0        


