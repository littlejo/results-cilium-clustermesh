key: e2 01 00 00  value: 19 02 00 00
key: f3 03 00 00  value: 88 02 00 00
key: ff 06 00 00  value: 48 02 00 00
key: 99 07 00 00  value: 2f 02 00 00
Found 4 elements
