top - 08:22:51 up 29 min,  0 users,  load average: 0.52, 0.28, 0.19
Tasks:  12 total,   3 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 36.7 us, 46.7 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi, 16.7 si,  0.0 st
MiB Mem :   7814.2 total,   4466.7 free,   1199.7 used,   2147.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6429.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    749 root      20   0 1244340  21728  14140 R  53.3   0.3   0:00.10 hubble
      1 root      20   0 1606336 381476  78124 S   6.7   4.8   0:46.89 cilium-+
    670 root      20   0 1240432  16396  11420 S   6.7   0.2   0:00.03 cilium-+
    405 root      20   0 1229744   8228   3836 S   0.0   0.1   0:01.11 cilium-+
    675 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    676 root      20   0 1229000   4048   3392 S   0.0   0.1   0:00.00 gops
    687 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    693 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    694 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    742 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    757 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    776 root      20   0    4104    752    656 R   0.0   0.0   0:00.00 ip
