1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:71:6f:e4:81:13 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.152.115/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1842sec preferred_lft 1842sec
    inet6 fe80::471:6fff:fee4:8113/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:05:f9:a4:18:63 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.168.94/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::405:f9ff:fea4:1863/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:2b:90:e0:7f:60 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d02b:90ff:fee0:7f60/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:41:db:50:5b:f7 brd ff:ff:ff:ff:ff:ff
    inet 10.180.0.30/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b041:dbff:fe50:5bf7/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether da:a0:ad:78:d2:6a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d8a0:adff:fe78:d26a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:39:1c:a6:9c:61 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::8c39:1cff:fea6:9c61/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf4bc5b324dab@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:5b:1e:26:77:82 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::bc5b:1eff:fe26:7782/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcee395b85d28c@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:45:f8:42:cb:94 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d845:f8ff:fe42:cb94/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc91319b155f83@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:fe:bd:d6:d3:bc brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::14fe:bdff:fed6:d3bc/64 scope link 
       valid_lft forever preferred_lft forever
