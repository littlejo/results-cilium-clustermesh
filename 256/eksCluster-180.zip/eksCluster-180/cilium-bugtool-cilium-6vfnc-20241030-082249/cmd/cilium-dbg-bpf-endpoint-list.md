IP ADDRESS         LOCAL ENDPOINT INFO
172.31.168.94:0    (localhost)                                                                                        
10.180.0.59:0      id=482   sec_id=5963373 flags=0x0000 ifindex=12  mac=06:FF:2D:BB:7F:D1 nodemac=BE:5B:1E:26:77:82   
10.180.0.198:0     id=1945  sec_id=5963373 flags=0x0000 ifindex=14  mac=E2:F5:95:7F:6C:F4 nodemac=DA:45:F8:42:CB:94   
10.180.0.30:0      (localhost)                                                                                        
10.180.0.98:0      id=1011  sec_id=5936322 flags=0x0000 ifindex=18  mac=4A:D8:BB:6A:C5:13 nodemac=16:FE:BD:D6:D3:BC   
172.31.152.115:0   (localhost)                                                                                        
10.180.0.150:0     id=1791  sec_id=4     flags=0x0000 ifindex=10  mac=02:3C:6F:2C:25:4D nodemac=8E:39:1C:A6:9C:61     
