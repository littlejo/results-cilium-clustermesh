KEY             VALUE
AgentLiveness   1800446903158
UTimeOffset     3379442972656250
