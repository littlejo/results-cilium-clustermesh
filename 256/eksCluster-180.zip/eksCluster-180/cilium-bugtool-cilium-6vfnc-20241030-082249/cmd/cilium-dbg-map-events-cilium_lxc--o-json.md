{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:14.886Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.152.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:14.886Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.168.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:14.886Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:19.456Z",
  "value": "id=1791  sec_id=4     flags=0x0000 ifindex=10  mac=02:3C:6F:2C:25:4D nodemac=8E:39:1C:A6:9C:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:19.465Z",
  "value": "id=482   sec_id=5963373 flags=0x0000 ifindex=12  mac=06:FF:2D:BB:7F:D1 nodemac=BE:5B:1E:26:77:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:19.496Z",
  "value": "id=1945  sec_id=5963373 flags=0x0000 ifindex=14  mac=E2:F5:95:7F:6C:F4 nodemac=DA:45:F8:42:CB:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:19.539Z",
  "value": "id=1791  sec_id=4     flags=0x0000 ifindex=10  mac=02:3C:6F:2C:25:4D nodemac=8E:39:1C:A6:9C:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:57.951Z",
  "value": "id=482   sec_id=5963373 flags=0x0000 ifindex=12  mac=06:FF:2D:BB:7F:D1 nodemac=BE:5B:1E:26:77:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:57.951Z",
  "value": "id=1945  sec_id=5963373 flags=0x0000 ifindex=14  mac=E2:F5:95:7F:6C:F4 nodemac=DA:45:F8:42:CB:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:57.952Z",
  "value": "id=1791  sec_id=4     flags=0x0000 ifindex=10  mac=02:3C:6F:2C:25:4D nodemac=8E:39:1C:A6:9C:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:57.984Z",
  "value": "id=683   sec_id=5936322 flags=0x0000 ifindex=16  mac=8A:22:F2:31:E2:F0 nodemac=FE:F4:5A:07:F6:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:58.951Z",
  "value": "id=683   sec_id=5936322 flags=0x0000 ifindex=16  mac=8A:22:F2:31:E2:F0 nodemac=FE:F4:5A:07:F6:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:58.951Z",
  "value": "id=482   sec_id=5963373 flags=0x0000 ifindex=12  mac=06:FF:2D:BB:7F:D1 nodemac=BE:5B:1E:26:77:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:58.951Z",
  "value": "id=1791  sec_id=4     flags=0x0000 ifindex=10  mac=02:3C:6F:2C:25:4D nodemac=8E:39:1C:A6:9C:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:58.952Z",
  "value": "id=1945  sec_id=5963373 flags=0x0000 ifindex=14  mac=E2:F5:95:7F:6C:F4 nodemac=DA:45:F8:42:CB:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:52.670Z",
  "value": "id=1011  sec_id=5936322 flags=0x0000 ifindex=18  mac=4A:D8:BB:6A:C5:13 nodemac=16:FE:BD:D6:D3:BC"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.180.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:03.005Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.921Z",
  "value": "id=1945  sec_id=5963373 flags=0x0000 ifindex=14  mac=E2:F5:95:7F:6C:F4 nodemac=DA:45:F8:42:CB:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.924Z",
  "value": "id=1011  sec_id=5936322 flags=0x0000 ifindex=18  mac=4A:D8:BB:6A:C5:13 nodemac=16:FE:BD:D6:D3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.925Z",
  "value": "id=1791  sec_id=4     flags=0x0000 ifindex=10  mac=02:3C:6F:2C:25:4D nodemac=8E:39:1C:A6:9C:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:10.925Z",
  "value": "id=482   sec_id=5963373 flags=0x0000 ifindex=12  mac=06:FF:2D:BB:7F:D1 nodemac=BE:5B:1E:26:77:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.845Z",
  "value": "id=1011  sec_id=5936322 flags=0x0000 ifindex=18  mac=4A:D8:BB:6A:C5:13 nodemac=16:FE:BD:D6:D3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.846Z",
  "value": "id=1791  sec_id=4     flags=0x0000 ifindex=10  mac=02:3C:6F:2C:25:4D nodemac=8E:39:1C:A6:9C:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.846Z",
  "value": "id=482   sec_id=5963373 flags=0x0000 ifindex=12  mac=06:FF:2D:BB:7F:D1 nodemac=BE:5B:1E:26:77:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.847Z",
  "value": "id=1945  sec_id=5963373 flags=0x0000 ifindex=14  mac=E2:F5:95:7F:6C:F4 nodemac=DA:45:F8:42:CB:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.846Z",
  "value": "id=1791  sec_id=4     flags=0x0000 ifindex=10  mac=02:3C:6F:2C:25:4D nodemac=8E:39:1C:A6:9C:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.846Z",
  "value": "id=482   sec_id=5963373 flags=0x0000 ifindex=12  mac=06:FF:2D:BB:7F:D1 nodemac=BE:5B:1E:26:77:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.846Z",
  "value": "id=1945  sec_id=5963373 flags=0x0000 ifindex=14  mac=E2:F5:95:7F:6C:F4 nodemac=DA:45:F8:42:CB:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.846Z",
  "value": "id=1011  sec_id=5936322 flags=0x0000 ifindex=18  mac=4A:D8:BB:6A:C5:13 nodemac=16:FE:BD:D6:D3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.847Z",
  "value": "id=1011  sec_id=5936322 flags=0x0000 ifindex=18  mac=4A:D8:BB:6A:C5:13 nodemac=16:FE:BD:D6:D3:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.847Z",
  "value": "id=1791  sec_id=4     flags=0x0000 ifindex=10  mac=02:3C:6F:2C:25:4D nodemac=8E:39:1C:A6:9C:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.847Z",
  "value": "id=1945  sec_id=5963373 flags=0x0000 ifindex=14  mac=E2:F5:95:7F:6C:F4 nodemac=DA:45:F8:42:CB:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.180.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.847Z",
  "value": "id=482   sec_id=5963373 flags=0x0000 ifindex=12  mac=06:FF:2D:BB:7F:D1 nodemac=BE:5B:1E:26:77:82"
}

