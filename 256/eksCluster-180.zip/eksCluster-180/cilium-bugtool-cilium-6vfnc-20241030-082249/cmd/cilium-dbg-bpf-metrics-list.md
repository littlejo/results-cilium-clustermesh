REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37717     2992629     677    bpf_overlay.c
Interface                 INGRESS     660698    134255322   1132   bpf_host.c
Success                   EGRESS      17665     1395864     1694   bpf_host.c
Success                   EGRESS      281997    34812967    1308   bpf_lxc.c
Success                   EGRESS      38672     3061821     53     encap.h
Success                   INGRESS     323802    36816395    86     l3.h
Success                   INGRESS     344505    38457206    235    trace.h
Unsupported L3 protocol   EGRESS      38        2812        1492   bpf_lxc.c
