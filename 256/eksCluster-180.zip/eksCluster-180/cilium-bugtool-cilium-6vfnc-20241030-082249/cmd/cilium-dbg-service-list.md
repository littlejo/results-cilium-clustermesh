ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.146.123:443 (active)    
                                        2 => 172.31.224.205:443 (active)    
2    10.100.159.45:443   ClusterIP      1 => 172.31.152.115:4244 (active)   
3    10.100.0.10:9153    ClusterIP      1 => 10.180.0.59:9153 (active)      
                                        2 => 10.180.0.198:9153 (active)     
4    10.100.0.10:53      ClusterIP      1 => 10.180.0.59:53 (active)        
                                        2 => 10.180.0.198:53 (active)       
5    10.100.55.64:2379   ClusterIP      1 => 10.180.0.98:2379 (active)      
