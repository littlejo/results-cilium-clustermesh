[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod656e25cb_afe1_4ccc_84cc_2e4766cfaae2.slice/cri-containerd-d80b430d2225ef6b6c977e4fdd1a205bbe3315bfe5338a0f03467463a7987e2c.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod656e25cb_afe1_4ccc_84cc_2e4766cfaae2.slice/cri-containerd-79fb0f6f5d213711907ff3dbff05635907a924731d6e6474d94aa856e469bb5c.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod656e25cb_afe1_4ccc_84cc_2e4766cfaae2.slice/cri-containerd-53cdd2d7e86c337670c7454bb220f49acb1e024d729759b9502788eab7d6ec64.scope"
      }
    ],
    "ips": [
      "10.180.0.98"
    ],
    "name": "clustermesh-apiserver-695cf7ff99-g5s8t",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod031cf4f7_2bb0_4caf_8e0e_69fb238819f8.slice/cri-containerd-b4b1feed89fa4e23827348d5fb0d2a74c9470cedfb782180e419064da3db805a.scope"
      }
    ],
    "ips": [
      "10.180.0.198"
    ],
    "name": "coredns-cc6ccd49c-pzrfx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6abccfd3_e32a_4347_ac6b_aaa965c17219.slice/cri-containerd-9d2871931835bedc0d3be9e9fe600608a2501e98510e4ae5b600d8032e2a5c7e.scope"
      }
    ],
    "ips": [
      "10.180.0.59"
    ],
    "name": "coredns-cc6ccd49c-8mz6w",
    "namespace": "kube-system"
  }
]

