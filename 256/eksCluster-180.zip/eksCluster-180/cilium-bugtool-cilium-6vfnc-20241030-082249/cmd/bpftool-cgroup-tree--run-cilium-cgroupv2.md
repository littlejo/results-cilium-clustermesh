CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod031cf4f7_2bb0_4caf_8e0e_69fb238819f8.slice/cri-containerd-b4b1feed89fa4e23827348d5fb0d2a74c9470cedfb782180e419064da3db805a.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod031cf4f7_2bb0_4caf_8e0e_69fb238819f8.slice/cri-containerd-20efcfea5bc2b8df8345f3ba904e1e684567a04ec3e848fabcecbc6951030ad4.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc6988878_39a9_4996_9f52_59092f8fe697.slice/cri-containerd-0113d05769964a8b62c16134bf8bab93711d679f3dd8872b1f4eaa511c8a5959.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc6988878_39a9_4996_9f52_59092f8fe697.slice/cri-containerd-54df83d9f0844ae68400f31a08dbefbd0a4bfa6c4e178dfce25591d8502a1f21.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6abccfd3_e32a_4347_ac6b_aaa965c17219.slice/cri-containerd-a32065de2f0de67255eb8da8b0ffa68981a2756b5d472d95c1cd60a8f36af585.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6abccfd3_e32a_4347_ac6b_aaa965c17219.slice/cri-containerd-9d2871931835bedc0d3be9e9fe600608a2501e98510e4ae5b600d8032e2a5c7e.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd5265453_804f_4ced_a9c3_78c9ff3e7be4.slice/cri-containerd-da36ea10b319c13b8a7e5dfb46274a6848c6f4dcd630be023ea92c1da561b631.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd5265453_804f_4ced_a9c3_78c9ff3e7be4.slice/cri-containerd-21f7bcc8fb06c8dda48b107d087867d1632f5400b3bc48173b1f57869ced5ac5.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod656e25cb_afe1_4ccc_84cc_2e4766cfaae2.slice/cri-containerd-c37dea696b96d6bf09e084b93a5cb2c41721d91fae92635089b5c440c9aa1376.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod656e25cb_afe1_4ccc_84cc_2e4766cfaae2.slice/cri-containerd-d80b430d2225ef6b6c977e4fdd1a205bbe3315bfe5338a0f03467463a7987e2c.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod656e25cb_afe1_4ccc_84cc_2e4766cfaae2.slice/cri-containerd-79fb0f6f5d213711907ff3dbff05635907a924731d6e6474d94aa856e469bb5c.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod656e25cb_afe1_4ccc_84cc_2e4766cfaae2.slice/cri-containerd-53cdd2d7e86c337670c7454bb220f49acb1e024d729759b9502788eab7d6ec64.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabc92898_dc25_4824_b428_2920b5caa4f1.slice/cri-containerd-d1d5e002ea2896cf4173e552ae65bfd68937f397e21dc1a7fe76496ef7f364bb.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabc92898_dc25_4824_b428_2920b5caa4f1.slice/cri-containerd-d62f94b7f445a7c755f6cc3220e3e85fc30240742018b1b6d79493e2f1c9f10e.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod96487caa_73c0_4f14_a411_5f37bc79ffc0.slice/cri-containerd-287c3937585bc2233a7def24caf5b11bf22729837f2b65668733044cb945f291.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod96487caa_73c0_4f14_a411_5f37bc79ffc0.slice/cri-containerd-5d027870c1136a5d858bd93c27b08422e7908e48c57b188ccf1a7ef5d42ac2cb.scope
    102      cgroup_device   multi                                          
