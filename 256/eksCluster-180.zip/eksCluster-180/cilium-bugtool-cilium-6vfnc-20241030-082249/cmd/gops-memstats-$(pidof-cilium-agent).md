alloc: 138.78MB (145523496 bytes)
total-alloc: 2.29GB (2457039568 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 64225723
frees: 63220868
heap-alloc: 138.78MB (145523496 bytes)
heap-sys: 250.73MB (262914048 bytes)
heap-idle: 61.43MB (64413696 bytes)
heap-in-use: 189.30MB (198500352 bytes)
heap-released: 2.34MB (2449408 bytes)
heap-objects: 1004855
stack-in-use: 61.22MB (64192512 bytes)
stack-sys: 61.22MB (64192512 bytes)
stack-mspan-inuse: 2.94MB (3082880 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.20MB (1259817 bytes)
gc-sys: 6.04MB (6334024 bytes)
next-gc: when heap-alloc >= 213.58MB (223958312 bytes)
last-gc: 2024-10-30 08:23:15.623228844 +0000 UTC
gc-pause-total: 14.005878ms
gc-pause: 73716
gc-pause-end: 1730276595623228844
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005164480878405921
enable-gc: true
debug-gc: false
