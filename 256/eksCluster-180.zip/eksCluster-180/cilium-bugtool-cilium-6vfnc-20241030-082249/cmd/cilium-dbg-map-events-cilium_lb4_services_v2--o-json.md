{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:12.624Z",
  "value": "1 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:12.624Z",
  "value": "2 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:12.624Z",
  "value": "0 2 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.159.45:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:12.624Z",
  "value": "0 0 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:12.624Z",
  "value": "0 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:12.624Z",
  "value": "0 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.159.45:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:15.976Z",
  "value": "3 0 (2) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.159.45:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:15.976Z",
  "value": "0 1 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:20.385Z",
  "value": "0 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:20.386Z",
  "value": "0 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:20.445Z",
  "value": "4 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:20.445Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:20.445Z",
  "value": "5 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:20.446Z",
  "value": "0 1 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:20.464Z",
  "value": "5 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:20.464Z",
  "value": "6 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:20.465Z",
  "value": "0 2 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:20.465Z",
  "value": "4 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:20.465Z",
  "value": "7 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:20.465Z",
  "value": "0 2 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.55.64:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:53.661Z",
  "value": "0 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.55.64:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:01.685Z",
  "value": "0 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.55.64:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:05.775Z",
  "value": "8 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.55.64:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:05.775Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.55.64:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:53.130Z",
  "value": "8 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.55.64:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:53.130Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.55.64:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:02.539Z",
  "value": "8 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.55.64:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:02.539Z",
  "value": "9 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.55.64:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:02.539Z",
  "value": "0 2 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.55.64:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:02.687Z",
  "value": "9 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.55.64:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:02.687Z",
  "value": "8 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.55.64:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:02.688Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.55.64:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:03.080Z",
  "value": "9 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.55.64:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:03.080Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.55.64:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:03.080Z",
  "value": "\u003cnil\u003e"
}

