[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5290eda4_ceea_4fa4_90bf_aafbb6eac70b.slice/cri-containerd-2150836742de6371c78d67b88637a6cf1ad4ff96a2ca4b97b6f11d0d3365b76a.scope"
      }
    ],
    "ips": [
      "10.239.0.39"
    ],
    "name": "coredns-cc6ccd49c-8sr4b",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0863511c_51a1_4a05_bd49_f22d4d3dbaba.slice/cri-containerd-2125d4d22a0057c76f16e8b37346ea4991ed3b54a957ceaa03c666c6acd03244.scope"
      }
    ],
    "ips": [
      "10.239.0.11"
    ],
    "name": "coredns-cc6ccd49c-dxxlt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podffbe6b8c_816d_4b11_bbca_c4a905bffd5e.slice/cri-containerd-e9a81b276b276fb0eec58d6aa7d8255086a524de4ad12c9ba1e7f4e00030e5c4.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podffbe6b8c_816d_4b11_bbca_c4a905bffd5e.slice/cri-containerd-14f6c4545058b69aa5714688bff87d2e474a252f93ce31a0fe43ffadd99b608a.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podffbe6b8c_816d_4b11_bbca_c4a905bffd5e.slice/cri-containerd-ceb8284a3efcc1f02f7555bb748803978a8ceb23b0338c7fbd7e788bbce4a2ca.scope"
      }
    ],
    "ips": [
      "10.239.0.169"
    ],
    "name": "clustermesh-apiserver-77549f6545-42smn",
    "namespace": "kube-system"
  }
]

