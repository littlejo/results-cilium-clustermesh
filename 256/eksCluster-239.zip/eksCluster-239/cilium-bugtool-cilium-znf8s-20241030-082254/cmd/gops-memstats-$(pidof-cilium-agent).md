alloc: 181.86MB (190693840 bytes)
total-alloc: 2.32GB (2488697232 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 64710001
frees: 62819799
heap-alloc: 181.86MB (190693840 bytes)
heap-sys: 247.55MB (259571712 bytes)
heap-idle: 39.91MB (41844736 bytes)
heap-in-use: 207.64MB (217726976 bytes)
heap-released: 5.41MB (5677056 bytes)
heap-objects: 1890202
stack-in-use: 64.41MB (67534848 bytes)
stack-sys: 64.41MB (67534848 bytes)
stack-mspan-inuse: 3.25MB (3408000 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1054969 bytes)
gc-sys: 6.03MB (6325760 bytes)
next-gc: when heap-alloc >= 211.89MB (222182968 bytes)
last-gc: 2024-10-30 08:22:58.477340842 +0000 UTC
gc-pause-total: 30.5155ms
gc-pause: 89626
gc-pause-end: 1730276578477340842
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005777195145557705
enable-gc: true
debug-gc: false
