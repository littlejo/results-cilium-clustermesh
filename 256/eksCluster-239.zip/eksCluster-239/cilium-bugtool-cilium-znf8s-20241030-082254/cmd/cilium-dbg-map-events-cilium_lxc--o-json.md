{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:50.769Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.201.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:50.769Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.247.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:50.769Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:55.387Z",
  "value": "id=1211  sec_id=7864809 flags=0x0000 ifindex=12  mac=C2:2E:4A:10:56:3E nodemac=D2:E2:FA:74:9B:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:55.395Z",
  "value": "id=2730  sec_id=4     flags=0x0000 ifindex=10  mac=46:9E:29:C3:8A:A9 nodemac=4A:CF:E9:A5:BE:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:55.451Z",
  "value": "id=2258  sec_id=7864809 flags=0x0000 ifindex=14  mac=E6:3E:97:F7:76:65 nodemac=3E:B0:B9:C4:F2:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:55.527Z",
  "value": "id=1211  sec_id=7864809 flags=0x0000 ifindex=12  mac=C2:2E:4A:10:56:3E nodemac=D2:E2:FA:74:9B:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:55.584Z",
  "value": "id=2730  sec_id=4     flags=0x0000 ifindex=10  mac=46:9E:29:C3:8A:A9 nodemac=4A:CF:E9:A5:BE:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:51.503Z",
  "value": "id=2730  sec_id=4     flags=0x0000 ifindex=10  mac=46:9E:29:C3:8A:A9 nodemac=4A:CF:E9:A5:BE:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:51.504Z",
  "value": "id=1211  sec_id=7864809 flags=0x0000 ifindex=12  mac=C2:2E:4A:10:56:3E nodemac=D2:E2:FA:74:9B:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:51.504Z",
  "value": "id=2258  sec_id=7864809 flags=0x0000 ifindex=14  mac=E6:3E:97:F7:76:65 nodemac=3E:B0:B9:C4:F2:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:51.534Z",
  "value": "id=831   sec_id=7870091 flags=0x0000 ifindex=16  mac=FA:E4:DA:0B:CF:71 nodemac=66:1A:BC:06:D2:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:52.504Z",
  "value": "id=1211  sec_id=7864809 flags=0x0000 ifindex=12  mac=C2:2E:4A:10:56:3E nodemac=D2:E2:FA:74:9B:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:52.504Z",
  "value": "id=2258  sec_id=7864809 flags=0x0000 ifindex=14  mac=E6:3E:97:F7:76:65 nodemac=3E:B0:B9:C4:F2:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:52.504Z",
  "value": "id=2730  sec_id=4     flags=0x0000 ifindex=10  mac=46:9E:29:C3:8A:A9 nodemac=4A:CF:E9:A5:BE:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:52.504Z",
  "value": "id=831   sec_id=7870091 flags=0x0000 ifindex=16  mac=FA:E4:DA:0B:CF:71 nodemac=66:1A:BC:06:D2:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.330Z",
  "value": "id=285   sec_id=7870091 flags=0x0000 ifindex=18  mac=82:FB:BD:79:44:64 nodemac=26:EE:57:51:29:78"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.239.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.567Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:38.691Z",
  "value": "id=285   sec_id=7870091 flags=0x0000 ifindex=18  mac=82:FB:BD:79:44:64 nodemac=26:EE:57:51:29:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:38.692Z",
  "value": "id=2730  sec_id=4     flags=0x0000 ifindex=10  mac=46:9E:29:C3:8A:A9 nodemac=4A:CF:E9:A5:BE:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:38.692Z",
  "value": "id=1211  sec_id=7864809 flags=0x0000 ifindex=12  mac=C2:2E:4A:10:56:3E nodemac=D2:E2:FA:74:9B:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:38.692Z",
  "value": "id=2258  sec_id=7864809 flags=0x0000 ifindex=14  mac=E6:3E:97:F7:76:65 nodemac=3E:B0:B9:C4:F2:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.690Z",
  "value": "id=2730  sec_id=4     flags=0x0000 ifindex=10  mac=46:9E:29:C3:8A:A9 nodemac=4A:CF:E9:A5:BE:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.691Z",
  "value": "id=1211  sec_id=7864809 flags=0x0000 ifindex=12  mac=C2:2E:4A:10:56:3E nodemac=D2:E2:FA:74:9B:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.691Z",
  "value": "id=285   sec_id=7870091 flags=0x0000 ifindex=18  mac=82:FB:BD:79:44:64 nodemac=26:EE:57:51:29:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.691Z",
  "value": "id=2258  sec_id=7864809 flags=0x0000 ifindex=14  mac=E6:3E:97:F7:76:65 nodemac=3E:B0:B9:C4:F2:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:40.690Z",
  "value": "id=2258  sec_id=7864809 flags=0x0000 ifindex=14  mac=E6:3E:97:F7:76:65 nodemac=3E:B0:B9:C4:F2:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:40.691Z",
  "value": "id=2730  sec_id=4     flags=0x0000 ifindex=10  mac=46:9E:29:C3:8A:A9 nodemac=4A:CF:E9:A5:BE:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:40.691Z",
  "value": "id=1211  sec_id=7864809 flags=0x0000 ifindex=12  mac=C2:2E:4A:10:56:3E nodemac=D2:E2:FA:74:9B:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:40.691Z",
  "value": "id=285   sec_id=7870091 flags=0x0000 ifindex=18  mac=82:FB:BD:79:44:64 nodemac=26:EE:57:51:29:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.691Z",
  "value": "id=2258  sec_id=7864809 flags=0x0000 ifindex=14  mac=E6:3E:97:F7:76:65 nodemac=3E:B0:B9:C4:F2:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.691Z",
  "value": "id=1211  sec_id=7864809 flags=0x0000 ifindex=12  mac=C2:2E:4A:10:56:3E nodemac=D2:E2:FA:74:9B:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.692Z",
  "value": "id=285   sec_id=7870091 flags=0x0000 ifindex=18  mac=82:FB:BD:79:44:64 nodemac=26:EE:57:51:29:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.239.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.692Z",
  "value": "id=2730  sec_id=4     flags=0x0000 ifindex=10  mac=46:9E:29:C3:8A:A9 nodemac=4A:CF:E9:A5:BE:E0"
}

