ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.136.77:443 (active)     
                                         2 => 172.31.242.195:443 (active)    
2    10.100.131.242:443   ClusterIP      1 => 172.31.247.110:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.239.0.39:53 (active)        
                                         2 => 10.239.0.11:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.239.0.39:9153 (active)      
                                         2 => 10.239.0.11:9153 (active)      
5    10.100.89.212:2379   ClusterIP      1 => 10.239.0.169:2379 (active)     
