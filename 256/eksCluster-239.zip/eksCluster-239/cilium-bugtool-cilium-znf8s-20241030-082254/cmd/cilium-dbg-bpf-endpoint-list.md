IP ADDRESS         LOCAL ENDPOINT INFO
10.239.0.47:0      (localhost)                                                                                        
10.239.0.169:0     id=285   sec_id=7870091 flags=0x0000 ifindex=18  mac=82:FB:BD:79:44:64 nodemac=26:EE:57:51:29:78   
172.31.247.110:0   (localhost)                                                                                        
10.239.0.11:0      id=2258  sec_id=7864809 flags=0x0000 ifindex=14  mac=E6:3E:97:F7:76:65 nodemac=3E:B0:B9:C4:F2:2B   
172.31.201.222:0   (localhost)                                                                                        
10.239.0.39:0      id=1211  sec_id=7864809 flags=0x0000 ifindex=12  mac=C2:2E:4A:10:56:3E nodemac=D2:E2:FA:74:9B:79   
10.239.0.190:0     id=2730  sec_id=4     flags=0x0000 ifindex=10  mac=46:9E:29:C3:8A:A9 nodemac=4A:CF:E9:A5:BE:E0     
