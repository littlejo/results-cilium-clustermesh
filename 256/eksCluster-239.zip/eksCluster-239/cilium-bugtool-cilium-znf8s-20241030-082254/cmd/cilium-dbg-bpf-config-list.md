KEY             VALUE
AgentLiveness   1690326203647
UTimeOffset     3379443197265625
