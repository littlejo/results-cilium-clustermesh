Endpoint ID: 285
Path: /sys/fs/bpf/tc/globals/cilium_policy_00285

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11588235   116667    0        
Allow    Ingress     1          ANY          NONE         disabled    10916557   115590    0        
Allow    Egress      0          ANY          NONE         disabled    14517277   141978    0        


Endpoint ID: 395
Path: /sys/fs/bpf/tc/globals/cilium_policy_00395

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1211
Path: /sys/fs/bpf/tc/globals/cilium_policy_01211

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    111384   1280      0        
Allow    Egress      0          ANY          NONE         disabled    17404    188       0        


Endpoint ID: 2258
Path: /sys/fs/bpf/tc/globals/cilium_policy_02258

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    111120   1276      0        
Allow    Egress      0          ANY          NONE         disabled    16838    181       0        


Endpoint ID: 2730
Path: /sys/fs/bpf/tc/globals/cilium_policy_02730

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1656737   20900     0        
Allow    Ingress     1          ANY          NONE         disabled    18384     219       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


