CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5290eda4_ceea_4fa4_90bf_aafbb6eac70b.slice/cri-containerd-828fd1377fc25f5b17d0e217fbea569db16be2b75d8bc87b1dfc1459ef5f3375.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5290eda4_ceea_4fa4_90bf_aafbb6eac70b.slice/cri-containerd-2150836742de6371c78d67b88637a6cf1ad4ff96a2ca4b97b6f11d0d3365b76a.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9ecad38_ad0f_4674_aa81_92b917e2987c.slice/cri-containerd-92dae71620f89ed65abd5341a144897af6a0795b0b9475a21d8166062f41ab90.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9ecad38_ad0f_4674_aa81_92b917e2987c.slice/cri-containerd-646f2c1062e5e5234418178663f20b7e45fc33f7be4058eb14bf5d7bf408ef63.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36db8504_c599_4252_a8e6_87c1c2e729e5.slice/cri-containerd-8919ce57239a9b3cc5227b4e7db332383456b9523afce56e792d6cfba36b6ed1.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36db8504_c599_4252_a8e6_87c1c2e729e5.slice/cri-containerd-0da32fdcf5fb92998c3b65fba81a148f0cb635b47d704401ea8777bd550dedb0.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0863511c_51a1_4a05_bd49_f22d4d3dbaba.slice/cri-containerd-2125d4d22a0057c76f16e8b37346ea4991ed3b54a957ceaa03c666c6acd03244.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0863511c_51a1_4a05_bd49_f22d4d3dbaba.slice/cri-containerd-4024df9fe1f5dfa3b09db0c4a4a854cef07be3edd08307eb98f0dfcc92d3fbeb.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podffbe6b8c_816d_4b11_bbca_c4a905bffd5e.slice/cri-containerd-ace2cd4d104b4ace3a07c75e32e6a5c450e48f78363320313715a5d5acbb5b8c.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podffbe6b8c_816d_4b11_bbca_c4a905bffd5e.slice/cri-containerd-14f6c4545058b69aa5714688bff87d2e474a252f93ce31a0fe43ffadd99b608a.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podffbe6b8c_816d_4b11_bbca_c4a905bffd5e.slice/cri-containerd-ceb8284a3efcc1f02f7555bb748803978a8ceb23b0338c7fbd7e788bbce4a2ca.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podffbe6b8c_816d_4b11_bbca_c4a905bffd5e.slice/cri-containerd-e9a81b276b276fb0eec58d6aa7d8255086a524de4ad12c9ba1e7f4e00030e5c4.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod143c686c_08b4_4cf9_806b_3a38197abeb9.slice/cri-containerd-ae2640bd488e24bdaa2684bb0939c96c8ebd6f6ab2abc032771496f5944c205b.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod143c686c_08b4_4cf9_806b_3a38197abeb9.slice/cri-containerd-e523238db63523cb4a30df0227dd6c77d564e93bb13c219301516ca4415d3b6b.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2867c8bd_366a_4f09_b22a_c3fca26d0e24.slice/cri-containerd-8058b8b4870e927e9e32d8659db27b0b03033361bb46db13264d52b894d2933e.scope
    110      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2867c8bd_366a_4f09_b22a_c3fca26d0e24.slice/cri-containerd-2ecba0b21ed99f10a4258a0009bdfb62ef10bcf81abe8d0cbb129287a1fd3b89.scope
    98       cgroup_device   multi                                          
