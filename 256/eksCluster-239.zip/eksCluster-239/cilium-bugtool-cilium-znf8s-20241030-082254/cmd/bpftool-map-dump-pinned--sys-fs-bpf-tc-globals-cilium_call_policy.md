key: 1d 01 00 00  value: 78 02 00 00
key: bb 04 00 00  value: 0d 02 00 00
key: d2 08 00 00  value: 01 02 00 00
key: aa 0a 00 00  value: 1d 02 00 00
Found 4 elements
