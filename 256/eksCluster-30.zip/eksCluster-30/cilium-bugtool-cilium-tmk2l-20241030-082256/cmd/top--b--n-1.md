top - 08:22:57 up 38 min,  0 users,  load average: 0.58, 0.26, 0.14
Tasks:   5 total,   1 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 25.8 us, 35.5 sy,  0.0 ni, 35.5 id,  0.0 wa,  0.0 hi,  3.2 si,  0.0 st
MiB Mem :   7814.2 total,   4497.3 free,   1170.9 used,   2146.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6458.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 378344  78588 S  40.0   4.7   0:54.07 cilium-+
    601 root      20   0 1240432  16464  11484 S   6.7   0.2   0:00.03 cilium-+
    395 root      20   0 1229488   7292   3052 S   0.0   0.1   0:01.15 cilium-+
    633 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    663 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
