CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb65c230e_aa55_4fda_9a25_fcc700fa889a.slice/cri-containerd-15263f6823f262aefacf7d29cd290e7f878f252c90cee7fbef468a269b0e6a55.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb65c230e_aa55_4fda_9a25_fcc700fa889a.slice/cri-containerd-2989baf5b8fe7bcc1be4f51386845a101e4d74a0c9f5138e73b633938e8c24a7.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf790d32a_c8c6_4bd4_84c1_411a3c459196.slice/cri-containerd-fff01ea1e47fa06eaef31a71200fed707ec555469dd85fc3b9b7dcd8cabfd35a.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf790d32a_c8c6_4bd4_84c1_411a3c459196.slice/cri-containerd-8fb43c24e04bd81abc4282f3ac4c0cdcea819194ca60d18cb86383291d71dba3.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb03367d3_9da3_4672_b21e_6faddc8fbe26.slice/cri-containerd-707345e89aedd4988164398722f278afeb77c0bce1faac998b2f34231bbaa494.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb03367d3_9da3_4672_b21e_6faddc8fbe26.slice/cri-containerd-c2b3fa756e28b62a3fbf649d1f871a63bb31363f1c7b450c42895755bd430687.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod149298ca_3b66_4649_8ba9_9b854a80e82f.slice/cri-containerd-976ea4af9e2eda21bbc942d300422588137434e2d416e9e07f1c1596a387969e.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod149298ca_3b66_4649_8ba9_9b854a80e82f.slice/cri-containerd-19c3c8d897b943628820d6a7ffb757c72936aa71d38b6dc7897eaad754082d69.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a7fc33d_761f_404f_b1be_e8be971bfbbc.slice/cri-containerd-d0161576b9990c84fc3ababb7201efab512f9870ab53eb314b03941a37009ae1.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a7fc33d_761f_404f_b1be_e8be971bfbbc.slice/cri-containerd-607dc8a36bee126143ec04e7ce3c1198c17e28f13f678b9b562ff59cbdb03483.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a7fc33d_761f_404f_b1be_e8be971bfbbc.slice/cri-containerd-68f31acea7cac290e251c463dfb265fe369856bd89960847a7c357c3eb478134.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a7fc33d_761f_404f_b1be_e8be971bfbbc.slice/cri-containerd-4ec5a934166d1f117d3f9f570fb2416c74c7dd7cf177c3812d006405690078f4.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbc28e70b_3477_41dd_821d_8ec7d8e1ce1a.slice/cri-containerd-f6f085dac90a478010c0654e0fe9c582183d57b0aed80f9585ab675e9cabce7c.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbc28e70b_3477_41dd_821d_8ec7d8e1ce1a.slice/cri-containerd-85c8ced31b305b30143067dba2c5d6f407f0c45e5781793a97f4c61bdc6cdd80.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfcf8b2f0_ffc3_4544_b2e5_ec579b2c7915.slice/cri-containerd-9c9f5d048a0ad1adcb33228d398dbcd2c7f37bebc3a615b8627e3c954d4b5d17.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfcf8b2f0_ffc3_4544_b2e5_ec579b2c7915.slice/cri-containerd-54e255ad76f7f89dc474c34624c8f644becb601958cfa12b770cb64a20ef5e74.scope
    94       cgroup_device   multi                                          
