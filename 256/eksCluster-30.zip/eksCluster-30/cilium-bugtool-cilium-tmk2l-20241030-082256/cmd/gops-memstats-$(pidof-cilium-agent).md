alloc: 180.33MB (189093064 bytes)
total-alloc: 2.21GB (2372419712 bytes)
sys: 308.77MB (323768676 bytes)
lookups: 0
mallocs: 62814020
frees: 60744573
heap-alloc: 180.33MB (189093064 bytes)
heap-sys: 231.62MB (242876416 bytes)
heap-idle: 32.70MB (34291712 bytes)
heap-in-use: 198.92MB (208584704 bytes)
heap-released: 2.00MB (2097152 bytes)
heap-objects: 2069447
stack-in-use: 64.38MB (67502080 bytes)
stack-sys: 64.38MB (67502080 bytes)
stack-mspan-inuse: 3.36MB (3522720 bytes)
stack-mspan-sys: 3.77MB (3949440 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.06MB (1107185 bytes)
gc-sys: 5.98MB (6270512 bytes)
next-gc: when heap-alloc >= 211.24MB (221497016 bytes)
last-gc: 2024-10-30 08:22:06.609906354 +0000 UTC
gc-pause-total: 12.208406ms
gc-pause: 94565
gc-pause-end: 1730276526609906354
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.00031250175946023
enable-gc: true
debug-gc: false
