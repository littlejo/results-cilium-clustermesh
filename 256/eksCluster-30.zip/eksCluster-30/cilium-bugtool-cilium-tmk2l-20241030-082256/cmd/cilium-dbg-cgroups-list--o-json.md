[
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a7fc33d_761f_404f_b1be_e8be971bfbbc.slice/cri-containerd-607dc8a36bee126143ec04e7ce3c1198c17e28f13f678b9b562ff59cbdb03483.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a7fc33d_761f_404f_b1be_e8be971bfbbc.slice/cri-containerd-d0161576b9990c84fc3ababb7201efab512f9870ab53eb314b03941a37009ae1.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a7fc33d_761f_404f_b1be_e8be971bfbbc.slice/cri-containerd-68f31acea7cac290e251c463dfb265fe369856bd89960847a7c357c3eb478134.scope"
      }
    ],
    "ips": [
      "10.30.0.244"
    ],
    "name": "clustermesh-apiserver-5789cd5d6c-cc2b6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb03367d3_9da3_4672_b21e_6faddc8fbe26.slice/cri-containerd-707345e89aedd4988164398722f278afeb77c0bce1faac998b2f34231bbaa494.scope"
      }
    ],
    "ips": [
      "10.30.0.247"
    ],
    "name": "coredns-cc6ccd49c-cvvrq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod149298ca_3b66_4649_8ba9_9b854a80e82f.slice/cri-containerd-976ea4af9e2eda21bbc942d300422588137434e2d416e9e07f1c1596a387969e.scope"
      }
    ],
    "ips": [
      "10.30.0.6"
    ],
    "name": "coredns-cc6ccd49c-vrsbw",
    "namespace": "kube-system"
  }
]

