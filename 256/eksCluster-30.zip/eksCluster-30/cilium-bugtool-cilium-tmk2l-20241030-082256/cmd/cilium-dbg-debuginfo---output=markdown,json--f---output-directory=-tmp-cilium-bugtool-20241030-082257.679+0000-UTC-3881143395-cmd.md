markdown output at /tmp/cilium-bugtool-20241030-082257.679+0000-UTC-3881143395/cmd/cilium-debuginfo-20241030-082258.55+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082257.679+0000-UTC-3881143395/cmd/cilium-debuginfo-20241030-082258.55+0000-UTC.json
