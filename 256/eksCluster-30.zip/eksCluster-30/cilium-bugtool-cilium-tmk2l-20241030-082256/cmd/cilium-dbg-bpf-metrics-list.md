REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34548     2731501     677    bpf_overlay.c
Interface                 INGRESS     590846    126005333   1132   bpf_host.c
Success                   EGRESS      15198     1193643     1694   bpf_host.c
Success                   EGRESS      256718    31404096    1308   bpf_lxc.c
Success                   EGRESS      34427     2723022     53     encap.h
Success                   INGRESS     296839    32721111    86     l3.h
Success                   INGRESS     316840    34303015    235    trace.h
Unsupported L3 protocol   EGRESS      46        3452        1492   bpf_lxc.c
