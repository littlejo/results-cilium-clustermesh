ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.171.248:443 (active)    
                                         2 => 172.31.234.194:443 (active)    
2    10.100.229.152:443   ClusterIP      1 => 172.31.183.179:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.30.0.6:53 (active)          
                                         2 => 10.30.0.247:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.30.0.6:9153 (active)        
                                         2 => 10.30.0.247:9153 (active)      
5    10.100.87.237:2379   ClusterIP      1 => 10.30.0.244:2379 (active)      
