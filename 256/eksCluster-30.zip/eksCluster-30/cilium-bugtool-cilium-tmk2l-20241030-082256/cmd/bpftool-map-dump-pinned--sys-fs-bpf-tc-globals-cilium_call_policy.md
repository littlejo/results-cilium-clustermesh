key: 08 00 00 00  value: 65 02 00 00
key: bd 01 00 00  value: 0e 02 00 00
key: c1 01 00 00  value: 20 02 00 00
key: 12 0a 00 00  value: 1f 02 00 00
Found 4 elements
