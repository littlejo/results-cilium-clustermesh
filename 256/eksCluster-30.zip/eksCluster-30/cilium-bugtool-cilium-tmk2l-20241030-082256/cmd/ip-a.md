1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:23:a4:da:8e:23 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.183.179/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3070sec preferred_lft 3070sec
    inet6 fe80::423:a4ff:feda:8e23/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:85:72:73:7b:d1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.179.239/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::485:72ff:fe73:7bd1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:f0:0d:a4:a2:5b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::74f0:dff:fea4:a25b/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:d9:64:0d:06:67 brd ff:ff:ff:ff:ff:ff
    inet 10.30.0.199/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d4d9:64ff:fe0d:667/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 82:2d:f5:8a:60:03 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::802d:f5ff:fe8a:6003/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:6c:f3:b4:ab:aa brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b06c:f3ff:feb4:abaa/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcc8f4a03e0714@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:31:7a:1d:cf:73 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::6031:7aff:fe1d:cf73/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcafc11c7eabfb@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:d3:c8:81:46:2b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::4cd3:c8ff:fe81:462b/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf3daa1d0fa46@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:59:8f:d5:cf:24 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7859:8fff:fed5:cf24/64 scope link 
       valid_lft forever preferred_lft forever
