{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:15.274Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.179.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:15.274Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.183.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:15.275Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:19.845Z",
  "value": "id=445   sec_id=1045717 flags=0x0000 ifindex=12  mac=82:98:D7:14:E6:13 nodemac=62:31:7A:1D:CF:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:19.860Z",
  "value": "id=449   sec_id=4     flags=0x0000 ifindex=10  mac=8E:93:63:D3:6F:34 nodemac=B2:6C:F3:B4:AB:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:19.861Z",
  "value": "id=445   sec_id=1045717 flags=0x0000 ifindex=12  mac=82:98:D7:14:E6:13 nodemac=62:31:7A:1D:CF:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:19.895Z",
  "value": "id=2578  sec_id=1045717 flags=0x0000 ifindex=14  mac=2A:AC:39:1B:E3:1B nodemac=4E:D3:C8:81:46:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:19.932Z",
  "value": "id=449   sec_id=4     flags=0x0000 ifindex=10  mac=8E:93:63:D3:6F:34 nodemac=B2:6C:F3:B4:AB:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:20.249Z",
  "value": "id=445   sec_id=1045717 flags=0x0000 ifindex=12  mac=82:98:D7:14:E6:13 nodemac=62:31:7A:1D:CF:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:20.250Z",
  "value": "id=2578  sec_id=1045717 flags=0x0000 ifindex=14  mac=2A:AC:39:1B:E3:1B nodemac=4E:D3:C8:81:46:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:20.251Z",
  "value": "id=449   sec_id=4     flags=0x0000 ifindex=10  mac=8E:93:63:D3:6F:34 nodemac=B2:6C:F3:B4:AB:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:20.281Z",
  "value": "id=157   sec_id=1039617 flags=0x0000 ifindex=16  mac=5A:3D:C4:D4:43:27 nodemac=F6:29:E4:33:8C:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:21.250Z",
  "value": "id=157   sec_id=1039617 flags=0x0000 ifindex=16  mac=5A:3D:C4:D4:43:27 nodemac=F6:29:E4:33:8C:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:21.251Z",
  "value": "id=449   sec_id=4     flags=0x0000 ifindex=10  mac=8E:93:63:D3:6F:34 nodemac=B2:6C:F3:B4:AB:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:21.251Z",
  "value": "id=445   sec_id=1045717 flags=0x0000 ifindex=12  mac=82:98:D7:14:E6:13 nodemac=62:31:7A:1D:CF:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:21.251Z",
  "value": "id=2578  sec_id=1045717 flags=0x0000 ifindex=14  mac=2A:AC:39:1B:E3:1B nodemac=4E:D3:C8:81:46:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.850Z",
  "value": "id=8     sec_id=1039617 flags=0x0000 ifindex=18  mac=F6:D5:77:51:E8:A1 nodemac=7A:59:8F:D5:CF:24"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.30.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.306Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.768Z",
  "value": "id=449   sec_id=4     flags=0x0000 ifindex=10  mac=8E:93:63:D3:6F:34 nodemac=B2:6C:F3:B4:AB:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.770Z",
  "value": "id=2578  sec_id=1045717 flags=0x0000 ifindex=14  mac=2A:AC:39:1B:E3:1B nodemac=4E:D3:C8:81:46:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.771Z",
  "value": "id=8     sec_id=1039617 flags=0x0000 ifindex=18  mac=F6:D5:77:51:E8:A1 nodemac=7A:59:8F:D5:CF:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.771Z",
  "value": "id=445   sec_id=1045717 flags=0x0000 ifindex=12  mac=82:98:D7:14:E6:13 nodemac=62:31:7A:1D:CF:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:49.774Z",
  "value": "id=449   sec_id=4     flags=0x0000 ifindex=10  mac=8E:93:63:D3:6F:34 nodemac=B2:6C:F3:B4:AB:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:49.774Z",
  "value": "id=445   sec_id=1045717 flags=0x0000 ifindex=12  mac=82:98:D7:14:E6:13 nodemac=62:31:7A:1D:CF:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:49.775Z",
  "value": "id=2578  sec_id=1045717 flags=0x0000 ifindex=14  mac=2A:AC:39:1B:E3:1B nodemac=4E:D3:C8:81:46:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:49.775Z",
  "value": "id=8     sec_id=1039617 flags=0x0000 ifindex=18  mac=F6:D5:77:51:E8:A1 nodemac=7A:59:8F:D5:CF:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.771Z",
  "value": "id=449   sec_id=4     flags=0x0000 ifindex=10  mac=8E:93:63:D3:6F:34 nodemac=B2:6C:F3:B4:AB:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.772Z",
  "value": "id=8     sec_id=1039617 flags=0x0000 ifindex=18  mac=F6:D5:77:51:E8:A1 nodemac=7A:59:8F:D5:CF:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.772Z",
  "value": "id=445   sec_id=1045717 flags=0x0000 ifindex=12  mac=82:98:D7:14:E6:13 nodemac=62:31:7A:1D:CF:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.772Z",
  "value": "id=2578  sec_id=1045717 flags=0x0000 ifindex=14  mac=2A:AC:39:1B:E3:1B nodemac=4E:D3:C8:81:46:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.772Z",
  "value": "id=449   sec_id=4     flags=0x0000 ifindex=10  mac=8E:93:63:D3:6F:34 nodemac=B2:6C:F3:B4:AB:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.772Z",
  "value": "id=8     sec_id=1039617 flags=0x0000 ifindex=18  mac=F6:D5:77:51:E8:A1 nodemac=7A:59:8F:D5:CF:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.773Z",
  "value": "id=445   sec_id=1045717 flags=0x0000 ifindex=12  mac=82:98:D7:14:E6:13 nodemac=62:31:7A:1D:CF:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.30.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.773Z",
  "value": "id=2578  sec_id=1045717 flags=0x0000 ifindex=14  mac=2A:AC:39:1B:E3:1B nodemac=4E:D3:C8:81:46:2B"
}

