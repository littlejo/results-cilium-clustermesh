Endpoint ID: 8
Path: /sys/fs/bpf/tc/globals/cilium_policy_00008

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    10351025   106456    0        
Allow    Ingress     1          ANY          NONE         disabled    9728145    102067    0        
Allow    Egress      0          ANY          NONE         disabled    11752419   119301    0        


Endpoint ID: 445
Path: /sys/fs/bpf/tc/globals/cilium_policy_00445

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    175177   2008      0        
Allow    Egress      0          ANY          NONE         disabled    22477    253       0        


Endpoint ID: 449
Path: /sys/fs/bpf/tc/globals/cilium_policy_00449

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1586650   20064     0        
Allow    Ingress     1          ANY          NONE         disabled    26344     308       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 801
Path: /sys/fs/bpf/tc/globals/cilium_policy_00801

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2578
Path: /sys/fs/bpf/tc/globals/cilium_policy_02578

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174781   2013      0        
Allow    Egress      0          ANY          NONE         disabled    22861    256       0        


