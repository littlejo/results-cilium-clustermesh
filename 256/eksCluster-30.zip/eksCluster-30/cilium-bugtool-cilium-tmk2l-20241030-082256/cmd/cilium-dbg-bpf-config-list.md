KEY             VALUE
AgentLiveness   2340833587460
UTimeOffset     3379441871093750
