xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 503
ens6(5) clsact/ingress cil_from_netdev-ens6 id 509
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 495
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 487
cilium_host(7) clsact/egress cil_from_host-cilium_host id 490
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 548
lxcc8f4a03e0714(12) clsact/ingress cil_from_container-lxcc8f4a03e0714 id 520
lxcafc11c7eabfb(14) clsact/ingress cil_from_container-lxcafc11c7eabfb id 542
lxcf3daa1d0fa46(18) clsact/ingress cil_from_container-lxcf3daa1d0fa46 id 619

flow_dissector:

netfilter:

