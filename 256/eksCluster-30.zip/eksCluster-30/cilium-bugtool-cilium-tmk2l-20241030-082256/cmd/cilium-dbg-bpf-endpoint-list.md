IP ADDRESS         LOCAL ENDPOINT INFO
10.30.0.211:0      id=449   sec_id=4     flags=0x0000 ifindex=10  mac=8E:93:63:D3:6F:34 nodemac=B2:6C:F3:B4:AB:AA     
10.30.0.199:0      (localhost)                                                                                        
10.30.0.6:0        id=2578  sec_id=1045717 flags=0x0000 ifindex=14  mac=2A:AC:39:1B:E3:1B nodemac=4E:D3:C8:81:46:2B   
172.31.179.239:0   (localhost)                                                                                        
10.30.0.244:0      id=8     sec_id=1039617 flags=0x0000 ifindex=18  mac=F6:D5:77:51:E8:A1 nodemac=7A:59:8F:D5:CF:24   
172.31.183.179:0   (localhost)                                                                                        
10.30.0.247:0      id=445   sec_id=1045717 flags=0x0000 ifindex=12  mac=82:98:D7:14:E6:13 nodemac=62:31:7A:1D:CF:73   
