USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         601  0.0  0.2 1240432 16464 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         622  0.0  0.0   6408  1648 ?        R    08:22   0:00  \_ ps auxfw
root         623  0.0  0.0   3852  1292 ?        R    08:22   0:00  \_ bash -c hostname
root           1  2.9  4.7 1606080 378088 ?      Ssl  07:52   0:54 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.0  0.0 1229488 7292 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
