key: 3f 01 00 00  value: 73 02 00 00
key: c3 03 00 00  value: 16 02 00 00
key: 17 05 00 00  value: 02 02 00 00
key: 4c 05 00 00  value: 0a 02 00 00
Found 4 elements
