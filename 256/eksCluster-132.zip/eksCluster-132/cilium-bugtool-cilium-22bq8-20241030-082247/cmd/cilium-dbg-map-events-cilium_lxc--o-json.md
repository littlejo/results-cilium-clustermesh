{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:03.237Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.154.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:03.237Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.179.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:03.237Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:07.642Z",
  "value": "id=1356  sec_id=4359799 flags=0x0000 ifindex=12  mac=7E:EB:68:DC:3C:81 nodemac=CA:63:5C:D0:16:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:07.656Z",
  "value": "id=963   sec_id=4     flags=0x0000 ifindex=10  mac=FA:75:BF:E0:1F:89 nodemac=B6:4C:00:5C:8F:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:07.702Z",
  "value": "id=1303  sec_id=4359799 flags=0x0000 ifindex=14  mac=DE:00:A3:B5:1C:73 nodemac=56:A5:AB:F5:4A:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:07.766Z",
  "value": "id=1356  sec_id=4359799 flags=0x0000 ifindex=12  mac=7E:EB:68:DC:3C:81 nodemac=CA:63:5C:D0:16:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:07.823Z",
  "value": "id=963   sec_id=4     flags=0x0000 ifindex=10  mac=FA:75:BF:E0:1F:89 nodemac=B6:4C:00:5C:8F:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:33.368Z",
  "value": "id=1356  sec_id=4359799 flags=0x0000 ifindex=12  mac=7E:EB:68:DC:3C:81 nodemac=CA:63:5C:D0:16:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:33.368Z",
  "value": "id=1303  sec_id=4359799 flags=0x0000 ifindex=14  mac=DE:00:A3:B5:1C:73 nodemac=56:A5:AB:F5:4A:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:33.368Z",
  "value": "id=963   sec_id=4     flags=0x0000 ifindex=10  mac=FA:75:BF:E0:1F:89 nodemac=B6:4C:00:5C:8F:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:33.399Z",
  "value": "id=2456  sec_id=4359793 flags=0x0000 ifindex=16  mac=B2:90:66:A6:08:D1 nodemac=DA:D9:D6:94:DA:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:34.368Z",
  "value": "id=2456  sec_id=4359793 flags=0x0000 ifindex=16  mac=B2:90:66:A6:08:D1 nodemac=DA:D9:D6:94:DA:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:34.368Z",
  "value": "id=963   sec_id=4     flags=0x0000 ifindex=10  mac=FA:75:BF:E0:1F:89 nodemac=B6:4C:00:5C:8F:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:34.368Z",
  "value": "id=1356  sec_id=4359799 flags=0x0000 ifindex=12  mac=7E:EB:68:DC:3C:81 nodemac=CA:63:5C:D0:16:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:34.368Z",
  "value": "id=1303  sec_id=4359799 flags=0x0000 ifindex=14  mac=DE:00:A3:B5:1C:73 nodemac=56:A5:AB:F5:4A:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.342Z",
  "value": "id=319   sec_id=4359793 flags=0x0000 ifindex=18  mac=02:9B:D9:CD:93:FB nodemac=36:ED:B3:FA:E9:85"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.132.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.631Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:29.891Z",
  "value": "id=963   sec_id=4     flags=0x0000 ifindex=10  mac=FA:75:BF:E0:1F:89 nodemac=B6:4C:00:5C:8F:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:29.891Z",
  "value": "id=1356  sec_id=4359799 flags=0x0000 ifindex=12  mac=7E:EB:68:DC:3C:81 nodemac=CA:63:5C:D0:16:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:29.892Z",
  "value": "id=1303  sec_id=4359799 flags=0x0000 ifindex=14  mac=DE:00:A3:B5:1C:73 nodemac=56:A5:AB:F5:4A:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:29.892Z",
  "value": "id=319   sec_id=4359793 flags=0x0000 ifindex=18  mac=02:9B:D9:CD:93:FB nodemac=36:ED:B3:FA:E9:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.892Z",
  "value": "id=963   sec_id=4     flags=0x0000 ifindex=10  mac=FA:75:BF:E0:1F:89 nodemac=B6:4C:00:5C:8F:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.893Z",
  "value": "id=1356  sec_id=4359799 flags=0x0000 ifindex=12  mac=7E:EB:68:DC:3C:81 nodemac=CA:63:5C:D0:16:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.893Z",
  "value": "id=1303  sec_id=4359799 flags=0x0000 ifindex=14  mac=DE:00:A3:B5:1C:73 nodemac=56:A5:AB:F5:4A:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.894Z",
  "value": "id=319   sec_id=4359793 flags=0x0000 ifindex=18  mac=02:9B:D9:CD:93:FB nodemac=36:ED:B3:FA:E9:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:31.890Z",
  "value": "id=1356  sec_id=4359799 flags=0x0000 ifindex=12  mac=7E:EB:68:DC:3C:81 nodemac=CA:63:5C:D0:16:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:31.890Z",
  "value": "id=319   sec_id=4359793 flags=0x0000 ifindex=18  mac=02:9B:D9:CD:93:FB nodemac=36:ED:B3:FA:E9:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:31.890Z",
  "value": "id=1303  sec_id=4359799 flags=0x0000 ifindex=14  mac=DE:00:A3:B5:1C:73 nodemac=56:A5:AB:F5:4A:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:31.891Z",
  "value": "id=963   sec_id=4     flags=0x0000 ifindex=10  mac=FA:75:BF:E0:1F:89 nodemac=B6:4C:00:5C:8F:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.890Z",
  "value": "id=1356  sec_id=4359799 flags=0x0000 ifindex=12  mac=7E:EB:68:DC:3C:81 nodemac=CA:63:5C:D0:16:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.890Z",
  "value": "id=319   sec_id=4359793 flags=0x0000 ifindex=18  mac=02:9B:D9:CD:93:FB nodemac=36:ED:B3:FA:E9:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.890Z",
  "value": "id=1303  sec_id=4359799 flags=0x0000 ifindex=14  mac=DE:00:A3:B5:1C:73 nodemac=56:A5:AB:F5:4A:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.132.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.891Z",
  "value": "id=963   sec_id=4     flags=0x0000 ifindex=10  mac=FA:75:BF:E0:1F:89 nodemac=B6:4C:00:5C:8F:B2"
}

