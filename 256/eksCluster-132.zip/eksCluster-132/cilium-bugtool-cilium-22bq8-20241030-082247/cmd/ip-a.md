1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:e1:3d:ae:f4:d9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.154.190/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3215sec preferred_lft 3215sec
    inet6 fe80::4e1:3dff:feae:f4d9/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:69:5d:81:c5:9b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.179.254/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::469:5dff:fe81:c59b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:40:a8:1c:c1:ce brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4440:a8ff:fe1c:c1ce/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:6d:09:50:75:27 brd ff:ff:ff:ff:ff:ff
    inet 10.132.0.211/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::ec6d:9ff:fe50:7527/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether da:0a:6c:74:43:3b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d80a:6cff:fe74:433b/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:4c:00:5c:8f:b2 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b44c:ff:fe5c:8fb2/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc9e542532a41f@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:63:5c:d0:16:18 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c863:5cff:fed0:1618/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc054bb8150e9e@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:a5:ab:f5:4a:a6 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::54a5:abff:fef5:4aa6/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc53a71b3a9962@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:ed:b3:fa:e9:85 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::34ed:b3ff:fefa:e985/64 scope link 
       valid_lft forever preferred_lft forever
