alloc: 204.39MB (214320144 bytes)
total-alloc: 2.38GB (2560621008 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 65517429
frees: 63320895
heap-alloc: 204.39MB (214320144 bytes)
heap-sys: 251.14MB (263340032 bytes)
heap-idle: 28.66MB (30056448 bytes)
heap-in-use: 222.48MB (233283584 bytes)
heap-released: 7.44MB (7798784 bytes)
heap-objects: 2196534
stack-in-use: 64.81MB (67960832 bytes)
stack-sys: 64.81MB (67960832 bytes)
stack-mspan-inuse: 3.53MB (3699840 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1000.73KB (1024745 bytes)
gc-sys: 6.01MB (6299040 bytes)
next-gc: when heap-alloc >= 234.94MB (246348536 bytes)
last-gc: 2024-10-30 08:22:49.441660162 +0000 UTC
gc-pause-total: 11.771535ms
gc-pause: 191175
gc-pause-end: 1730276569441660162
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.00038830434200823
enable-gc: true
debug-gc: false
