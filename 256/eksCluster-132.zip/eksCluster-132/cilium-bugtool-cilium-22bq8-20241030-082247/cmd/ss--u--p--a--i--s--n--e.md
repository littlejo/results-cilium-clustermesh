Total: 678
TCP:   1832 (estab 427, closed 1386, orphaned 0, timewait 557)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  446       434       12       
INET	  456       440       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.154.190%ens5:68         0.0.0.0:*    uid:192 ino:66782 sk:3e0 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:31734 sk:3e1 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:14938 sk:3e2 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:33673      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:30653 sk:3e3 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:31733 sk:3e4 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:14939 sk:3e5 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::4e1:3dff:feae:f4d9]%ens5:546           [::]:*    uid:192 ino:15145 sk:3e6 cgroup:unreachable:c4e v6only:1 <->                   
