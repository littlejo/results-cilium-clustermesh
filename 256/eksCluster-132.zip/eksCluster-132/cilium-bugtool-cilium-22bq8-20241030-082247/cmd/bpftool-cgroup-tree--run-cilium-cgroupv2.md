CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4c65f616_3c55_42d8_a8cb_7cce5e4615ff.slice/cri-containerd-075987ce1fd6d51e6baa621a1e0e25f4dcc84fc1922422c999d8b3eaa3463f11.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4c65f616_3c55_42d8_a8cb_7cce5e4615ff.slice/cri-containerd-952414d98928ad1dd11f3a70d3546a2ea3db7f4cbd6bc0888da05f819b4ad658.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9017f87_6180_4acc_986d_cacf484c2738.slice/cri-containerd-d98102f63aedc7bd5f12c1d6f19d32737a4f53949d324400aaf6240cbfc84fbb.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9017f87_6180_4acc_986d_cacf484c2738.slice/cri-containerd-280fbf61f5a5f6030559088ca15b7a0445c4e03475a0d7c86038aa1121c40996.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda710386e_cc62_4b23_a51d_659e4e643bbb.slice/cri-containerd-27c6581c79b90fa219104dd8cf7912a219e2d8a1d2e55eb552061970d622e8fe.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda710386e_cc62_4b23_a51d_659e4e643bbb.slice/cri-containerd-fe6dbd1bbb4604e884fbc32ed6b92b1c6b6dbe1ed05cce17e36515394fe8c876.scope
    537      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod290308b2_4b46_42de_9057_a01ed42c8093.slice/cri-containerd-cadcd79b42200dbbd96b3850af209df61f94974a32d17e1a9825e01a23c0cd86.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod290308b2_4b46_42de_9057_a01ed42c8093.slice/cri-containerd-42f45279c59849396b0109efea1c8aff72dd111ac0659a25df8d399fcb81c1ba.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podccecac08_eccb_4726_8403_aceefa439c33.slice/cri-containerd-1786097b769f81b765d1534c5871d9decc5ef6dcf406c9a063f7d3cd711c004a.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podccecac08_eccb_4726_8403_aceefa439c33.slice/cri-containerd-3fa7462f8a603c5b8c45c301d90c66f9ab9cffb4e372c5c8b6e8d6b50dd6dd9f.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4453efcb_4c9f_4808_a5dd_a6c9fe717e5e.slice/cri-containerd-90ae913bf490148b8702b14f9fe2c4d66fb20084345f0720e72b3a5829131e6f.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4453efcb_4c9f_4808_a5dd_a6c9fe717e5e.slice/cri-containerd-b3627a94e0743ab3f8f264293271339f3ad00d13b72916dd2ba7b3c28934cf9a.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4453efcb_4c9f_4808_a5dd_a6c9fe717e5e.slice/cri-containerd-c4a020fe9783d7f31d4ba881ae879d9b83560566c227d8735e1a7327d28d71d4.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4453efcb_4c9f_4808_a5dd_a6c9fe717e5e.slice/cri-containerd-a4390fb2b8e92237e12e195a2acf107975237e8b45931c8138f6306d178677b3.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod47a6361f_65dd_4341_a3c0_8a67237d401b.slice/cri-containerd-dcd93c039418c48c80e9cedc4cae0471e7eaac4e2c3d9a7004fa847536c57572.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod47a6361f_65dd_4341_a3c0_8a67237d401b.slice/cri-containerd-ae0aa4c05bfb21c04056c5f06624220fc68bb2d01afefeed5e8577c980722497.scope
    98       cgroup_device   multi                                          
