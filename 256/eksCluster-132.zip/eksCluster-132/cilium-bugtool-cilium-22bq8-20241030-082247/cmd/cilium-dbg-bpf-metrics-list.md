REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37733     2990299     677    bpf_overlay.c
Interface                 INGRESS     667750    135777429   1132   bpf_host.c
Success                   EGRESS      17629     1393701     1694   bpf_host.c
Success                   EGRESS      286349    35484775    1308   bpf_lxc.c
Success                   EGRESS      38765     3066892     53     encap.h
Success                   INGRESS     330130    37405465    86     l3.h
Success                   INGRESS     350885    39046109    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
