IP ADDRESS         LOCAL ENDPOINT INFO
10.132.0.211:0     (localhost)                                                                                        
10.132.0.105:0     id=319   sec_id=4359793 flags=0x0000 ifindex=18  mac=02:9B:D9:CD:93:FB nodemac=36:ED:B3:FA:E9:85   
10.132.0.48:0      id=1303  sec_id=4359799 flags=0x0000 ifindex=14  mac=DE:00:A3:B5:1C:73 nodemac=56:A5:AB:F5:4A:A6   
172.31.179.254:0   (localhost)                                                                                        
10.132.0.71:0      id=963   sec_id=4     flags=0x0000 ifindex=10  mac=FA:75:BF:E0:1F:89 nodemac=B6:4C:00:5C:8F:B2     
10.132.0.59:0      id=1356  sec_id=4359799 flags=0x0000 ifindex=12  mac=7E:EB:68:DC:3C:81 nodemac=CA:63:5C:D0:16:18   
172.31.154.190:0   (localhost)                                                                                        
