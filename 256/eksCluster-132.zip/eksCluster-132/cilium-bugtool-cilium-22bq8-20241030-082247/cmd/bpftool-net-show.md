xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 573
ens6(5) clsact/ingress cil_from_netdev-ens6 id 579
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 566
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 556
cilium_host(7) clsact/egress cil_from_host-cilium_host id 561
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 544
lxc9e542532a41f(12) clsact/ingress cil_from_container-lxc9e542532a41f id 524
lxc054bb8150e9e(14) clsact/ingress cil_from_container-lxc054bb8150e9e id 513
lxc53a71b3a9962(18) clsact/ingress cil_from_container-lxc53a71b3a9962 id 626

flow_dissector:

netfilter:

