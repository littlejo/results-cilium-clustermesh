ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.222.251:443 (active)    
                                          2 => 172.31.158.204:443 (active)    
2    10.100.187.69:443     ClusterIP      1 => 172.31.154.190:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.132.0.48:9153 (active)      
                                          2 => 10.132.0.59:9153 (active)      
4    10.100.0.10:53        ClusterIP      1 => 10.132.0.48:53 (active)        
                                          2 => 10.132.0.59:53 (active)        
5    10.100.216.200:2379   ClusterIP      1 => 10.132.0.105:2379 (active)     
