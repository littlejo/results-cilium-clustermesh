Endpoint ID: 319
Path: /sys/fs/bpf/tc/globals/cilium_policy_00319

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11539852   116006    0        
Allow    Ingress     1          ANY          NONE         disabled    10901622   115168    0        
Allow    Egress      0          ANY          NONE         disabled    14464776   141301    0        


Endpoint ID: 484
Path: /sys/fs/bpf/tc/globals/cilium_policy_00484

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 963
Path: /sys/fs/bpf/tc/globals/cilium_policy_00963

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1642466   20780     0        
Allow    Ingress     1          ANY          NONE         disabled    26410     309       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1303
Path: /sys/fs/bpf/tc/globals/cilium_policy_01303

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    172030   1971      0        
Allow    Egress      0          ANY          NONE         disabled    20134    224       0        


Endpoint ID: 1356
Path: /sys/fs/bpf/tc/globals/cilium_policy_01356

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    171832   1968      0        
Allow    Egress      0          ANY          NONE         disabled    20069    223       0        


