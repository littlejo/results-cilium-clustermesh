 08:22:49 up 36 min,  0 users,  load average: 2.13, 0.61, 0.35
