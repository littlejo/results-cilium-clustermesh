KEY             VALUE
AgentLiveness   2226797275336
UTimeOffset     3379442136718750
