[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4453efcb_4c9f_4808_a5dd_a6c9fe717e5e.slice/cri-containerd-90ae913bf490148b8702b14f9fe2c4d66fb20084345f0720e72b3a5829131e6f.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4453efcb_4c9f_4808_a5dd_a6c9fe717e5e.slice/cri-containerd-a4390fb2b8e92237e12e195a2acf107975237e8b45931c8138f6306d178677b3.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4453efcb_4c9f_4808_a5dd_a6c9fe717e5e.slice/cri-containerd-b3627a94e0743ab3f8f264293271339f3ad00d13b72916dd2ba7b3c28934cf9a.scope"
      }
    ],
    "ips": [
      "10.132.0.105"
    ],
    "name": "clustermesh-apiserver-64c7bf4b7f-vrwt9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod290308b2_4b46_42de_9057_a01ed42c8093.slice/cri-containerd-cadcd79b42200dbbd96b3850af209df61f94974a32d17e1a9825e01a23c0cd86.scope"
      }
    ],
    "ips": [
      "10.132.0.59"
    ],
    "name": "coredns-cc6ccd49c-v4d76",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda710386e_cc62_4b23_a51d_659e4e643bbb.slice/cri-containerd-27c6581c79b90fa219104dd8cf7912a219e2d8a1d2e55eb552061970d622e8fe.scope"
      }
    ],
    "ips": [
      "10.132.0.48"
    ],
    "name": "coredns-cc6ccd49c-bhn5s",
    "namespace": "kube-system"
  }
]

