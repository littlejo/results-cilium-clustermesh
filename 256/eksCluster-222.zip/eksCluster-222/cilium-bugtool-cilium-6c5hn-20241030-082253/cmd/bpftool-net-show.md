xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 551
ens6(5) clsact/ingress cil_from_netdev-ens6 id 567
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 543
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 541
cilium_host(7) clsact/egress cil_from_host-cilium_host id 536
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 580
lxc95906ff1c729(12) clsact/ingress cil_from_container-lxc95906ff1c729 id 527
lxc31c711298362(14) clsact/ingress cil_from_container-lxc31c711298362 id 574
lxc6c24001c3dad(18) clsact/ingress cil_from_container-lxc6c24001c3dad id 646

flow_dissector:

netfilter:

