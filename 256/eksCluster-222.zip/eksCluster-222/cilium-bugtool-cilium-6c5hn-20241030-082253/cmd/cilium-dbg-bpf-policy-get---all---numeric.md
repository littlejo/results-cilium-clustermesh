Endpoint ID: 438
Path: /sys/fs/bpf/tc/globals/cilium_policy_00438

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2093
Path: /sys/fs/bpf/tc/globals/cilium_policy_02093

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11327233   111203    0        
Allow    Ingress     1          ANY          NONE         disabled    9135858    95388     0        
Allow    Egress      0          ANY          NONE         disabled    11276154   111973    0        


Endpoint ID: 3202
Path: /sys/fs/bpf/tc/globals/cilium_policy_03202

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113737   1305      0        
Allow    Egress      0          ANY          NONE         disabled    15828    170       0        


Endpoint ID: 3925
Path: /sys/fs/bpf/tc/globals/cilium_policy_03925

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1664140   21015     0        
Allow    Ingress     1          ANY          NONE         disabled    17391     203       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3947
Path: /sys/fs/bpf/tc/globals/cilium_policy_03947

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113341   1299      0        
Allow    Egress      0          ANY          NONE         disabled    15766    169       0        


