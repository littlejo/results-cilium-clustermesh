filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc95906ff1c729 direct-action not_in_hw id 527 tag 53ac3d60282930d3 jited 
