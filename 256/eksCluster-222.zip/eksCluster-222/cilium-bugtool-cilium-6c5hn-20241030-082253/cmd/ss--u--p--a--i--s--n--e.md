Total: 684
TCP:   1866 (estab 436, closed 1411, orphaned 0, timewait 562)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  455       443       12       
INET	  465       449       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                            127.0.0.1:33523      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:35284 sk:1001 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.180.162%ens5:68         0.0.0.0:*    uid:192 ino:15955 sk:1002 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:34676 sk:1003 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15715 sk:1004 cgroup:unreachable:f0c <->                                    
UNCONN 0      0      [fe80::468:daff:fe69:a381]%ens5:546           [::]:*    uid:192 ino:15953 sk:1005 cgroup:unreachable:c4e v6only:1 <->                   
UNCONN 0      0                                 [::]:8472          [::]:*    ino:34675 sk:1006 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15716 sk:1007 cgroup:unreachable:f0c v6only:1 <->                           
