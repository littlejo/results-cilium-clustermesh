USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         619  0.0  0.2 1240432 16040 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         637  0.0  0.0   6408  1648 ?        R    08:22   0:00  \_ ps auxfw
root           1  3.2  4.7 1606336 382748 ?      Ssl  08:03   0:38 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.0  0.1 1229744 8128 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
