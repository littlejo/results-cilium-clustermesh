{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:25.404Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.175.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:25.404Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.180.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:25.404Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.911Z",
  "value": "id=3925  sec_id=4     flags=0x0000 ifindex=10  mac=82:62:3A:14:CF:AA nodemac=02:E4:C3:60:A5:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.915Z",
  "value": "id=3947  sec_id=7310114 flags=0x0000 ifindex=12  mac=AE:26:47:45:7C:79 nodemac=AA:E0:1E:F2:11:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.954Z",
  "value": "id=3202  sec_id=7310114 flags=0x0000 ifindex=14  mac=72:2F:10:8A:FB:6F nodemac=A2:07:5B:D2:46:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.990Z",
  "value": "id=3925  sec_id=4     flags=0x0000 ifindex=10  mac=82:62:3A:14:CF:AA nodemac=02:E4:C3:60:A5:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:10.985Z",
  "value": "id=3925  sec_id=4     flags=0x0000 ifindex=10  mac=82:62:3A:14:CF:AA nodemac=02:E4:C3:60:A5:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:10.985Z",
  "value": "id=3947  sec_id=7310114 flags=0x0000 ifindex=12  mac=AE:26:47:45:7C:79 nodemac=AA:E0:1E:F2:11:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:10.986Z",
  "value": "id=3202  sec_id=7310114 flags=0x0000 ifindex=14  mac=72:2F:10:8A:FB:6F nodemac=A2:07:5B:D2:46:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:11.016Z",
  "value": "id=3926  sec_id=7317089 flags=0x0000 ifindex=16  mac=EE:10:32:1A:F4:E0 nodemac=7A:6D:76:B3:68:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:11.984Z",
  "value": "id=3926  sec_id=7317089 flags=0x0000 ifindex=16  mac=EE:10:32:1A:F4:E0 nodemac=7A:6D:76:B3:68:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:11.985Z",
  "value": "id=3925  sec_id=4     flags=0x0000 ifindex=10  mac=82:62:3A:14:CF:AA nodemac=02:E4:C3:60:A5:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:11.985Z",
  "value": "id=3202  sec_id=7310114 flags=0x0000 ifindex=14  mac=72:2F:10:8A:FB:6F nodemac=A2:07:5B:D2:46:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:11.985Z",
  "value": "id=3947  sec_id=7310114 flags=0x0000 ifindex=12  mac=AE:26:47:45:7C:79 nodemac=AA:E0:1E:F2:11:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.118Z",
  "value": "id=2093  sec_id=7317089 flags=0x0000 ifindex=18  mac=96:9E:EC:D8:92:84 nodemac=56:AC:C2:1A:BC:87"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.222.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.523Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.544Z",
  "value": "id=3202  sec_id=7310114 flags=0x0000 ifindex=14  mac=72:2F:10:8A:FB:6F nodemac=A2:07:5B:D2:46:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.545Z",
  "value": "id=2093  sec_id=7317089 flags=0x0000 ifindex=18  mac=96:9E:EC:D8:92:84 nodemac=56:AC:C2:1A:BC:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.546Z",
  "value": "id=3925  sec_id=4     flags=0x0000 ifindex=10  mac=82:62:3A:14:CF:AA nodemac=02:E4:C3:60:A5:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.546Z",
  "value": "id=3947  sec_id=7310114 flags=0x0000 ifindex=12  mac=AE:26:47:45:7C:79 nodemac=AA:E0:1E:F2:11:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:02.544Z",
  "value": "id=3202  sec_id=7310114 flags=0x0000 ifindex=14  mac=72:2F:10:8A:FB:6F nodemac=A2:07:5B:D2:46:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:02.544Z",
  "value": "id=2093  sec_id=7317089 flags=0x0000 ifindex=18  mac=96:9E:EC:D8:92:84 nodemac=56:AC:C2:1A:BC:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:02.544Z",
  "value": "id=3947  sec_id=7310114 flags=0x0000 ifindex=12  mac=AE:26:47:45:7C:79 nodemac=AA:E0:1E:F2:11:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:02.545Z",
  "value": "id=3925  sec_id=4     flags=0x0000 ifindex=10  mac=82:62:3A:14:CF:AA nodemac=02:E4:C3:60:A5:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:03.543Z",
  "value": "id=3925  sec_id=4     flags=0x0000 ifindex=10  mac=82:62:3A:14:CF:AA nodemac=02:E4:C3:60:A5:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:03.543Z",
  "value": "id=2093  sec_id=7317089 flags=0x0000 ifindex=18  mac=96:9E:EC:D8:92:84 nodemac=56:AC:C2:1A:BC:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:03.544Z",
  "value": "id=3947  sec_id=7310114 flags=0x0000 ifindex=12  mac=AE:26:47:45:7C:79 nodemac=AA:E0:1E:F2:11:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:03.544Z",
  "value": "id=3202  sec_id=7310114 flags=0x0000 ifindex=14  mac=72:2F:10:8A:FB:6F nodemac=A2:07:5B:D2:46:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:04.544Z",
  "value": "id=3202  sec_id=7310114 flags=0x0000 ifindex=14  mac=72:2F:10:8A:FB:6F nodemac=A2:07:5B:D2:46:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:04.544Z",
  "value": "id=2093  sec_id=7317089 flags=0x0000 ifindex=18  mac=96:9E:EC:D8:92:84 nodemac=56:AC:C2:1A:BC:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:04.545Z",
  "value": "id=3925  sec_id=4     flags=0x0000 ifindex=10  mac=82:62:3A:14:CF:AA nodemac=02:E4:C3:60:A5:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.222.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:04.545Z",
  "value": "id=3947  sec_id=7310114 flags=0x0000 ifindex=12  mac=AE:26:47:45:7C:79 nodemac=AA:E0:1E:F2:11:9A"
}

