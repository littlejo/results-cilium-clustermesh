alloc: 180.55MB (189320552 bytes)
total-alloc: 2.05GB (2199707552 bytes)
sys: 317.02MB (332419428 bytes)
lookups: 0
mallocs: 60353756
frees: 58329668
heap-alloc: 180.55MB (189320552 bytes)
heap-sys: 239.70MB (251338752 bytes)
heap-idle: 38.52MB (40386560 bytes)
heap-in-use: 201.18MB (210952192 bytes)
heap-released: 9.28MB (9732096 bytes)
heap-objects: 2024088
stack-in-use: 64.28MB (67403776 bytes)
stack-sys: 64.28MB (67403776 bytes)
stack-mspan-inuse: 3.38MB (3542720 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.18MB (1239609 bytes)
gc-sys: 6.05MB (6342384 bytes)
next-gc: when heap-alloc >= 208.28MB (218400888 bytes)
last-gc: 2024-10-30 08:22:04.778304337 +0000 UTC
gc-pause-total: 21.646309ms
gc-pause: 120694
gc-pause-end: 1730276524778304337
num-gc: 79
num-forced-gc: 0
gc-cpu-fraction: 0.0004375973494221037
enable-gc: true
debug-gc: false
