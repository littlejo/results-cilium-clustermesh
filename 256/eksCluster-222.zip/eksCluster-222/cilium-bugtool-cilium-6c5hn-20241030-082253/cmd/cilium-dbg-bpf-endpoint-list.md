IP ADDRESS         LOCAL ENDPOINT INFO
10.222.0.117:0     id=3925  sec_id=4     flags=0x0000 ifindex=10  mac=82:62:3A:14:CF:AA nodemac=02:E4:C3:60:A5:55     
10.222.0.189:0     id=3947  sec_id=7310114 flags=0x0000 ifindex=12  mac=AE:26:47:45:7C:79 nodemac=AA:E0:1E:F2:11:9A   
172.31.180.162:0   (localhost)                                                                                        
10.222.0.40:0      id=2093  sec_id=7317089 flags=0x0000 ifindex=18  mac=96:9E:EC:D8:92:84 nodemac=56:AC:C2:1A:BC:87   
10.222.0.219:0     id=3202  sec_id=7310114 flags=0x0000 ifindex=14  mac=72:2F:10:8A:FB:6F nodemac=A2:07:5B:D2:46:17   
172.31.175.127:0   (localhost)                                                                                        
10.222.0.136:0     (localhost)                                                                                        
