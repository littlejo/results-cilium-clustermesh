Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal      2     87     91      0     16      8      2      2      1      2    865 
