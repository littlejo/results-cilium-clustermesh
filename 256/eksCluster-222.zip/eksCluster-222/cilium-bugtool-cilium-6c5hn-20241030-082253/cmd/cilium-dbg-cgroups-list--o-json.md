[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbed533ef_402b_4dad_8fee_70fd9a4faf4b.slice/cri-containerd-70924ce0cd67d3daaed0a97c7f7da531870783d166d9e923a85d79ec1bbbec74.scope"
      }
    ],
    "ips": [
      "10.222.0.189"
    ],
    "name": "coredns-cc6ccd49c-7c77j",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod52a31072_a1d6_4962_8516_904810bbe5ed.slice/cri-containerd-6016ca5d1436c57b5a292e32d404ac757b36207ed6b357f33cac9de5653fd0a9.scope"
      }
    ],
    "ips": [
      "10.222.0.219"
    ],
    "name": "coredns-cc6ccd49c-4np2f",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podee8801e5_bdb7_4e82_839a_c6bcbaedd742.slice/cri-containerd-3b16c7f105432371c2773de77a2fbc98dec976233d1f74d1f89fe964f0335a8f.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podee8801e5_bdb7_4e82_839a_c6bcbaedd742.slice/cri-containerd-408cccb6631fd717c15adcfaf011a4a3d4148ebb716db8d3ed654db68b4c05a4.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podee8801e5_bdb7_4e82_839a_c6bcbaedd742.slice/cri-containerd-d4ab12a90dd518e06ce4dac283cf2f95d711c461dfecc96c59464bd8500336f0.scope"
      }
    ],
    "ips": [
      "10.222.0.40"
    ],
    "name": "clustermesh-apiserver-6bbb4d658f-n5qpv",
    "namespace": "kube-system"
  }
]

