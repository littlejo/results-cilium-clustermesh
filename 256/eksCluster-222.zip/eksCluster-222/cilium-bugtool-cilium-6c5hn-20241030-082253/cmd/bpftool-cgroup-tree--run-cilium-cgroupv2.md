CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbed533ef_402b_4dad_8fee_70fd9a4faf4b.slice/cri-containerd-70924ce0cd67d3daaed0a97c7f7da531870783d166d9e923a85d79ec1bbbec74.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbed533ef_402b_4dad_8fee_70fd9a4faf4b.slice/cri-containerd-3177720f4237cbdb48203b8a17190171c50479c9ee1a689704dceb1eb06a3afe.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod52a31072_a1d6_4962_8516_904810bbe5ed.slice/cri-containerd-6016ca5d1436c57b5a292e32d404ac757b36207ed6b357f33cac9de5653fd0a9.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod52a31072_a1d6_4962_8516_904810bbe5ed.slice/cri-containerd-59d6c2e1f935e329aeafb718122ecc8990f09cae520ad01b81395095aa1e45c3.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod13ad3927_a332_4e6e_82db_4195995913b4.slice/cri-containerd-0d21aab228bdf323dafcd48dcf62eee7ed54db1a7cf3ca4e75125d32118b5534.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod13ad3927_a332_4e6e_82db_4195995913b4.slice/cri-containerd-61ed00efd1a4b56c94532a7b7db5842d418c1f50435db70b277b005a0c7cbc9f.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podedd4828d_4d66_4051_aba8_6f2a275ae954.slice/cri-containerd-f01b2a50b26c3b4832487bd24f1e3f3b459451ba3896f45426885739fcdaa4b4.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podedd4828d_4d66_4051_aba8_6f2a275ae954.slice/cri-containerd-abfa1590a45e937c9fb2d750fe910cec946e8553a4df6f86dd8f405db839ecc7.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b3dd132_9106_4345_946d_541b26459c1d.slice/cri-containerd-a5853652ddc946fb008f4b4d31e9c2903aaacb866a54413b1d17784cbcb65464.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b3dd132_9106_4345_946d_541b26459c1d.slice/cri-containerd-ae63bd58f95f78bf45fc62a67141ba7c604f70b019823078c1022f5631d2e2a0.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod96f825b5_fe2e_4353_8b5d_d2957fe523bc.slice/cri-containerd-7d1f4253015b2ad5dfe40069dcab7348349b8e46641d6cef6beee8118d095dc4.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod96f825b5_fe2e_4353_8b5d_d2957fe523bc.slice/cri-containerd-88bca8930a945fa0b6e49db1a32534116cff5a16c58ee18c33f4beb88721b7e2.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podee8801e5_bdb7_4e82_839a_c6bcbaedd742.slice/cri-containerd-3b16c7f105432371c2773de77a2fbc98dec976233d1f74d1f89fe964f0335a8f.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podee8801e5_bdb7_4e82_839a_c6bcbaedd742.slice/cri-containerd-408cccb6631fd717c15adcfaf011a4a3d4148ebb716db8d3ed654db68b4c05a4.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podee8801e5_bdb7_4e82_839a_c6bcbaedd742.slice/cri-containerd-4b0d0c9deb4b81ee14f4cf5b24d94fa4c9bf6a89f6882a1b2b5efa7a8bdeaa30.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podee8801e5_bdb7_4e82_839a_c6bcbaedd742.slice/cri-containerd-d4ab12a90dd518e06ce4dac283cf2f95d711c461dfecc96c59464bd8500336f0.scope
    678      cgroup_device   multi                                          
