top - 08:22:54 up 28 min,  0 users,  load average: 0.05, 0.21, 0.21
Tasks:   9 total,   1 running,   7 sleeping,   0 stopped,   1 zombie
%Cpu(s): 33.3 us, 50.0 sy,  0.0 ni, 13.3 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4480.7 free,   1187.8 used,   2145.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6441.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 384788  79732 S  26.7   4.8   0:38.32 cilium-+
    395 root      20   0 1229744   8128   3836 S   0.0   0.1   0:01.07 cilium-+
    619 root      20   0 1240432  16040  11292 S   0.0   0.2   0:00.02 cilium-+
    648 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    662 root      20   0       0      0      0 Z   0.0   0.0   0:00.00 gops
    680 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    681 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    699 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    716 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
