key: 2d 08 00 00  value: 84 02 00 00
key: 82 0c 00 00  value: 34 02 00 00
key: 55 0f 00 00  value: 42 02 00 00
key: 6b 0f 00 00  value: 08 02 00 00
Found 4 elements
