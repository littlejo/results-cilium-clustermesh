ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.132.197:443 (active)    
                                        2 => 172.31.205.67:443 (active)     
2    10.100.1.230:443    ClusterIP      1 => 172.31.180.162:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.222.0.189:53 (active)       
                                        2 => 10.222.0.219:53 (active)       
4    10.100.0.10:9153    ClusterIP      1 => 10.222.0.189:9153 (active)     
                                        2 => 10.222.0.219:9153 (active)     
5    10.100.7.138:2379   ClusterIP      1 => 10.222.0.40:2379 (active)      
