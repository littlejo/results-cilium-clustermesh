KEY             VALUE
AgentLiveness   1768962092030
UTimeOffset     3379443041015625
