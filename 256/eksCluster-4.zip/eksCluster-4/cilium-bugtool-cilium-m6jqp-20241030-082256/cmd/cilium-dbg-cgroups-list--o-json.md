[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f534ad8_fa48_4b4f_821b_2f9ff52471f6.slice/cri-containerd-04e2881336201b8a5dc797309b28cb8778c9cfc9132d8a43bc93e0389447c38c.scope"
      }
    ],
    "ips": [
      "10.4.0.111"
    ],
    "name": "coredns-cc6ccd49c-67ddj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod81f2a737_6980_4e7b_b480_dd7f73ae6358.slice/cri-containerd-408f68d946589c2e9c77793dec1c614f3e9904eb0def531f0d1476a75848289d.scope"
      }
    ],
    "ips": [
      "10.4.0.201"
    ],
    "name": "coredns-cc6ccd49c-hxcbj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ea02e4a_0bae_4ee7_ae4e_57e658869b1e.slice/cri-containerd-8c0697769bd55db7134d97924cfec8e5556d8cb13af7a86ab923e1ccf56323cb.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ea02e4a_0bae_4ee7_ae4e_57e658869b1e.slice/cri-containerd-d921c1e7dc7ab4bfec952292987963949485b4a76de734aabadaace0a05a0aaa.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ea02e4a_0bae_4ee7_ae4e_57e658869b1e.slice/cri-containerd-588188dfc124016d6804f9d5782a00ae16a4692e4d44640922a9da4ced64b1e4.scope"
      }
    ],
    "ips": [
      "10.4.0.198"
    ],
    "name": "clustermesh-apiserver-f76dc555c-2zdrv",
    "namespace": "kube-system"
  }
]

