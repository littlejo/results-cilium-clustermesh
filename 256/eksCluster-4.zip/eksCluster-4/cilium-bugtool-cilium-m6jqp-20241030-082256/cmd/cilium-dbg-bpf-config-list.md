KEY             VALUE
AgentLiveness   2373175444550
UTimeOffset     3379441865234375
