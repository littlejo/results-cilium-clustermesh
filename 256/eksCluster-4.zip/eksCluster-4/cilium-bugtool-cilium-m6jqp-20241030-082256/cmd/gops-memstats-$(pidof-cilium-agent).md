alloc: 116.45MB (122111152 bytes)
total-alloc: 2.28GB (2443606864 bytes)
sys: 320.83MB (336417124 bytes)
lookups: 0
mallocs: 63655079
frees: 62957729
heap-alloc: 116.45MB (122111152 bytes)
heap-sys: 247.52MB (259538944 bytes)
heap-idle: 71.91MB (75399168 bytes)
heap-in-use: 175.61MB (184139776 bytes)
heap-released: 3.08MB (3227648 bytes)
heap-objects: 697350
stack-in-use: 60.09MB (63012864 bytes)
stack-sys: 60.09MB (63012864 bytes)
stack-mspan-inuse: 2.74MB (2870240 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1008.48KB (1032681 bytes)
gc-sys: 6.42MB (6731144 bytes)
next-gc: when heap-alloc >= 225.81MB (236784008 bytes)
last-gc: 2024-10-30 08:23:27.638615155 +0000 UTC
gc-pause-total: 19.065484ms
gc-pause: 128387
gc-pause-end: 1730276607638615155
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00035873307808080064
enable-gc: true
debug-gc: false
