USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         662  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         656  2.0  0.2 1240432 16456 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         688  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         690  0.0  0.0      0     0 ?        R    08:22   0:00  \_ [hostname]
root         643  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         642  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         623  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  2.3  4.7 1606144 379120 ?      Ssl  07:52   0:43 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.0  0.0 1229744 6960 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
