Endpoint ID: 86
Path: /sys/fs/bpf/tc/globals/cilium_policy_00086

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1658607   20998     0        
Allow    Ingress     1          ANY          NONE         disabled    26676     311       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1062
Path: /sys/fs/bpf/tc/globals/cilium_policy_01062

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    179011   2061      0        
Allow    Egress      0          ANY          NONE         disabled    21192    237       0        


Endpoint ID: 1526
Path: /sys/fs/bpf/tc/globals/cilium_policy_01526

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2792
Path: /sys/fs/bpf/tc/globals/cilium_policy_02792

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    178417   2052      0        
Allow    Egress      0          ANY          NONE         disabled    22904    257       0        


Endpoint ID: 3437
Path: /sys/fs/bpf/tc/globals/cilium_policy_03437

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11418278   112606    0        
Allow    Ingress     1          ANY          NONE         disabled    9727179    102316    0        
Allow    Egress      0          ANY          NONE         disabled    11475822   113888    0        


