1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ba:e6:cf:c5:77 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.188.9/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3067sec preferred_lft 3067sec
    inet6 fe80::4ba:e6ff:fecf:c577/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c1:11:3a:00:63 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.143.61/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4c1:11ff:fe3a:63/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:db:8b:41:41:09 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::fcdb:8bff:fe41:4109/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:64:fc:2b:02:12 brd ff:ff:ff:ff:ff:ff
    inet 10.4.0.170/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::464:fcff:fe2b:212/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 5e:3b:9d:f2:13:22 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5c3b:9dff:fef2:1322/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:84:fb:d9:29:59 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c084:fbff:fed9:2959/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc5f2ac83c47a2@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:7a:cd:e2:20:50 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::fc7a:cdff:fee2:2050/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcd4fde4956bb8@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:4f:13:10:49:57 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::a44f:13ff:fe10:4957/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc06a1edea49e5@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:33:c5:14:7f:fa brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2033:c5ff:fe14:7ffa/64 scope link 
       valid_lft forever preferred_lft forever
