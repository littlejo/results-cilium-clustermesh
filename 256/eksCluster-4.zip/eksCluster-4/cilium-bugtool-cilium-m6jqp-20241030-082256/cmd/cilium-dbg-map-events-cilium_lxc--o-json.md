{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:12.595Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.143.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:12.595Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.188.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:12.595Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:17.016Z",
  "value": "id=86    sec_id=4     flags=0x0000 ifindex=10  mac=F6:F0:73:0D:F3:1B nodemac=C2:84:FB:D9:29:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:17.019Z",
  "value": "id=2792  sec_id=175605 flags=0x0000 ifindex=12  mac=16:02:27:CF:90:05 nodemac=FE:7A:CD:E2:20:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:17.065Z",
  "value": "id=1062  sec_id=175605 flags=0x0000 ifindex=14  mac=D6:FA:19:E1:0E:D9 nodemac=A6:4F:13:10:49:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:17.082Z",
  "value": "id=86    sec_id=4     flags=0x0000 ifindex=10  mac=F6:F0:73:0D:F3:1B nodemac=C2:84:FB:D9:29:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:18.011Z",
  "value": "id=86    sec_id=4     flags=0x0000 ifindex=10  mac=F6:F0:73:0D:F3:1B nodemac=C2:84:FB:D9:29:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:18.012Z",
  "value": "id=2792  sec_id=175605 flags=0x0000 ifindex=12  mac=16:02:27:CF:90:05 nodemac=FE:7A:CD:E2:20:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:18.013Z",
  "value": "id=1062  sec_id=175605 flags=0x0000 ifindex=14  mac=D6:FA:19:E1:0E:D9 nodemac=A6:4F:13:10:49:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:18.047Z",
  "value": "id=403   sec_id=176424 flags=0x0000 ifindex=16  mac=D2:25:E6:6B:AA:59 nodemac=D2:23:2B:E8:D6:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:19.011Z",
  "value": "id=86    sec_id=4     flags=0x0000 ifindex=10  mac=F6:F0:73:0D:F3:1B nodemac=C2:84:FB:D9:29:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:19.011Z",
  "value": "id=403   sec_id=176424 flags=0x0000 ifindex=16  mac=D2:25:E6:6B:AA:59 nodemac=D2:23:2B:E8:D6:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:19.011Z",
  "value": "id=2792  sec_id=175605 flags=0x0000 ifindex=12  mac=16:02:27:CF:90:05 nodemac=FE:7A:CD:E2:20:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:19.011Z",
  "value": "id=1062  sec_id=175605 flags=0x0000 ifindex=14  mac=D6:FA:19:E1:0E:D9 nodemac=A6:4F:13:10:49:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.940Z",
  "value": "id=3437  sec_id=176424 flags=0x0000 ifindex=18  mac=C6:88:55:E9:85:56 nodemac=22:33:C5:14:7F:FA"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.4.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.348Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.761Z",
  "value": "id=3437  sec_id=176424 flags=0x0000 ifindex=18  mac=C6:88:55:E9:85:56 nodemac=22:33:C5:14:7F:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.764Z",
  "value": "id=86    sec_id=4     flags=0x0000 ifindex=10  mac=F6:F0:73:0D:F3:1B nodemac=C2:84:FB:D9:29:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.764Z",
  "value": "id=2792  sec_id=175605 flags=0x0000 ifindex=12  mac=16:02:27:CF:90:05 nodemac=FE:7A:CD:E2:20:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.764Z",
  "value": "id=1062  sec_id=175605 flags=0x0000 ifindex=14  mac=D6:FA:19:E1:0E:D9 nodemac=A6:4F:13:10:49:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.586Z",
  "value": "id=86    sec_id=4     flags=0x0000 ifindex=10  mac=F6:F0:73:0D:F3:1B nodemac=C2:84:FB:D9:29:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.591Z",
  "value": "id=2792  sec_id=175605 flags=0x0000 ifindex=12  mac=16:02:27:CF:90:05 nodemac=FE:7A:CD:E2:20:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.592Z",
  "value": "id=1062  sec_id=175605 flags=0x0000 ifindex=14  mac=D6:FA:19:E1:0E:D9 nodemac=A6:4F:13:10:49:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.592Z",
  "value": "id=3437  sec_id=176424 flags=0x0000 ifindex=18  mac=C6:88:55:E9:85:56 nodemac=22:33:C5:14:7F:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.582Z",
  "value": "id=2792  sec_id=175605 flags=0x0000 ifindex=12  mac=16:02:27:CF:90:05 nodemac=FE:7A:CD:E2:20:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.583Z",
  "value": "id=86    sec_id=4     flags=0x0000 ifindex=10  mac=F6:F0:73:0D:F3:1B nodemac=C2:84:FB:D9:29:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.583Z",
  "value": "id=1062  sec_id=175605 flags=0x0000 ifindex=14  mac=D6:FA:19:E1:0E:D9 nodemac=A6:4F:13:10:49:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.583Z",
  "value": "id=3437  sec_id=176424 flags=0x0000 ifindex=18  mac=C6:88:55:E9:85:56 nodemac=22:33:C5:14:7F:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.583Z",
  "value": "id=3437  sec_id=176424 flags=0x0000 ifindex=18  mac=C6:88:55:E9:85:56 nodemac=22:33:C5:14:7F:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.584Z",
  "value": "id=86    sec_id=4     flags=0x0000 ifindex=10  mac=F6:F0:73:0D:F3:1B nodemac=C2:84:FB:D9:29:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.584Z",
  "value": "id=2792  sec_id=175605 flags=0x0000 ifindex=12  mac=16:02:27:CF:90:05 nodemac=FE:7A:CD:E2:20:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.584Z",
  "value": "id=1062  sec_id=175605 flags=0x0000 ifindex=14  mac=D6:FA:19:E1:0E:D9 nodemac=A6:4F:13:10:49:57"
}

