top - 08:22:57 up 39 min,  0 users,  load average: 0.10, 0.15, 0.10
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 16.7 us, 23.3 sy,  0.0 ni, 60.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4474.8 free,   1193.5 used,   2145.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6435.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606144 379120  77636 S   0.0   4.7   0:43.53 cilium-+
    394 root      20   0 1229744   6960   2924 S   0.0   0.1   0:01.08 cilium-+
    623 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    642 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    643 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    656 root      20   0 1240432  16456  11484 S   0.0   0.2   0:00.02 cilium-+
    662 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    700 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    718 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
    723 root      20   0 1539912   8308   6236 S   0.0   0.1   0:00.00 runc:[2+
