CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod79c48fd0_5600_47cc_a5cb_c3d7c4d00958.slice/cri-containerd-03d57a9907643957454fa247f516fbf24e0dfa417cfc30c14e3be23ebed7f7ab.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod79c48fd0_5600_47cc_a5cb_c3d7c4d00958.slice/cri-containerd-40f7c2fbf816ac37e0b5f076a93eefb706d5611b045360df6c729761933552ee.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod81f2a737_6980_4e7b_b480_dd7f73ae6358.slice/cri-containerd-408f68d946589c2e9c77793dec1c614f3e9904eb0def531f0d1476a75848289d.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod81f2a737_6980_4e7b_b480_dd7f73ae6358.slice/cri-containerd-1e2012b8d7a988a2c0aff1aebb31b8375d5c1fa99b40138311d12b34fc66a308.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f534ad8_fa48_4b4f_821b_2f9ff52471f6.slice/cri-containerd-04e2881336201b8a5dc797309b28cb8778c9cfc9132d8a43bc93e0389447c38c.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f534ad8_fa48_4b4f_821b_2f9ff52471f6.slice/cri-containerd-91d5de98cf3a675dcf7ba8438260b5a1e2e527ef797949d158d566ef24092a7a.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda2a965bd_69eb_4ffe_b13f_499c5f05334a.slice/cri-containerd-865ac2dc1c95f2512d30419aab6d1b066f34c3a797958391591f2b5fd24deafc.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda2a965bd_69eb_4ffe_b13f_499c5f05334a.slice/cri-containerd-abf31016d74c15fa22b88731628fa77102fa9c49ccf4b6d2cb2ebdf9fdcab286.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31a5fbd3_b980_4d4b_97d7_1c4aea666c90.slice/cri-containerd-2b042ab733cae54b31cbbab9849129e564ec72cc6ee4f60b749cdcac036d5d07.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31a5fbd3_b980_4d4b_97d7_1c4aea666c90.slice/cri-containerd-3d26335160c92df49a24dc1e8be60ec55061ef7ee2fd76563721d609b27636af.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda1167ec8_580f_44f9_bcbd_e7e77ee46881.slice/cri-containerd-9ce81b644c966f9092992d52dc634d6864bf4f89397a5a61654b0b006440ae51.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda1167ec8_580f_44f9_bcbd_e7e77ee46881.slice/cri-containerd-789f4a5ad509805b929132f81c6227a9f211e99c496aa9aba51d2312c2387c09.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ea02e4a_0bae_4ee7_ae4e_57e658869b1e.slice/cri-containerd-8c0697769bd55db7134d97924cfec8e5556d8cb13af7a86ab923e1ccf56323cb.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ea02e4a_0bae_4ee7_ae4e_57e658869b1e.slice/cri-containerd-5674330d2dfdac5bea158d0e2fd216fd22b1c2a346acf07c71aa2f2a09704bca.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ea02e4a_0bae_4ee7_ae4e_57e658869b1e.slice/cri-containerd-588188dfc124016d6804f9d5782a00ae16a4692e4d44640922a9da4ced64b1e4.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ea02e4a_0bae_4ee7_ae4e_57e658869b1e.slice/cri-containerd-d921c1e7dc7ab4bfec952292987963949485b4a76de734aabadaace0a05a0aaa.scope
    647      cgroup_device   multi                                          
