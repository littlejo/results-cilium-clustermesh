ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.135.126:443 (active)   
                                          2 => 172.31.222.62:443 (active)    
2    10.100.103.168:443    ClusterIP      1 => 172.31.188.9:4244 (active)    
3    10.100.0.10:53        ClusterIP      1 => 10.4.0.201:53 (active)        
                                          2 => 10.4.0.111:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.4.0.201:9153 (active)      
                                          2 => 10.4.0.111:9153 (active)      
5    10.100.242.153:2379   ClusterIP      1 => 10.4.0.198:2379 (active)      
