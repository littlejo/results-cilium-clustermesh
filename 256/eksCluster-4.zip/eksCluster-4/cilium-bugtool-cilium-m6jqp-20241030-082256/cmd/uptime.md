 08:22:57 up 39 min,  0 users,  load average: 0.10, 0.15, 0.10
