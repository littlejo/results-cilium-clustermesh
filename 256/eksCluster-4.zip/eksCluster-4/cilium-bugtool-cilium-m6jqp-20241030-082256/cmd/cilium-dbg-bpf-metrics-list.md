REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36196     2859829     677    bpf_overlay.c
Interface                 INGRESS     634923    131274322   1132   bpf_host.c
Success                   EGRESS      15883     1247916     1694   bpf_host.c
Success                   EGRESS      264540    33527958    1308   bpf_lxc.c
Success                   EGRESS      35960     2847183     53     encap.h
Success                   INGRESS     308823    34507789    86     l3.h
Success                   INGRESS     329787    36163748    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
