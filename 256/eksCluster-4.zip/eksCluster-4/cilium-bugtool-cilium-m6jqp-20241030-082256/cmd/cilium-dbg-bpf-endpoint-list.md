IP ADDRESS        LOCAL ENDPOINT INFO
172.31.143.61:0   (localhost)                                                                                       
10.4.0.111:0      id=1062  sec_id=175605 flags=0x0000 ifindex=14  mac=D6:FA:19:E1:0E:D9 nodemac=A6:4F:13:10:49:57   
10.4.0.217:0      id=86    sec_id=4     flags=0x0000 ifindex=10  mac=F6:F0:73:0D:F3:1B nodemac=C2:84:FB:D9:29:59    
172.31.188.9:0    (localhost)                                                                                       
10.4.0.198:0      id=3437  sec_id=176424 flags=0x0000 ifindex=18  mac=C6:88:55:E9:85:56 nodemac=22:33:C5:14:7F:FA   
10.4.0.201:0      id=2792  sec_id=175605 flags=0x0000 ifindex=12  mac=16:02:27:CF:90:05 nodemac=FE:7A:CD:E2:20:50   
10.4.0.170:0      (localhost)                                                                                       
