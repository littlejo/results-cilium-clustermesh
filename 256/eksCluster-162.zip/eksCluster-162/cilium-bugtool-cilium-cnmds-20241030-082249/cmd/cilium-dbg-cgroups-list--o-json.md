[
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9efa77a4_f879_4cda_8298_b27008de2cd3.slice/cri-containerd-16569955c7f6945a0043affd06755eeacb2028ae38c76dae5c2f190162ab8813.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9efa77a4_f879_4cda_8298_b27008de2cd3.slice/cri-containerd-6f7a24fa5c9e7ed8f938a78d331c5fe048ce33b6b89298f9c9966e4069e9f181.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9efa77a4_f879_4cda_8298_b27008de2cd3.slice/cri-containerd-5cadf0e051e5086c94a9f4c9ed7881ddb368c6045c2bb5150e56b7f3d2d08640.scope"
      }
    ],
    "ips": [
      "10.162.0.237"
    ],
    "name": "clustermesh-apiserver-6df546b7f4-zmbcz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7398fc44_3b47_497b_8ab3_97b62514341c.slice/cri-containerd-f970e0b6c6cf56af03856a84201b7e800521dc86489fd01c083385d7a8723045.scope"
      }
    ],
    "ips": [
      "10.162.0.141"
    ],
    "name": "coredns-cc6ccd49c-tzx6n",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2d72d95a_4c0b_427e_80cc_93c17b7336d1.slice/cri-containerd-61f1e8dc5be39f66e1820c3945643eced71c221b5e0cc6c1c2dc02abbdda6f01.scope"
      }
    ],
    "ips": [
      "10.162.0.99"
    ],
    "name": "coredns-cc6ccd49c-jvz5l",
    "namespace": "kube-system"
  }
]

