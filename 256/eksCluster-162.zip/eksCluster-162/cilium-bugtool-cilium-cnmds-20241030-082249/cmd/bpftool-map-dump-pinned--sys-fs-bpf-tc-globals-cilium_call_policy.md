key: 0b 01 00 00  value: 83 02 00 00
key: 60 01 00 00  value: 47 02 00 00
key: cd 01 00 00  value: 41 02 00 00
key: 11 03 00 00  value: 05 02 00 00
Found 4 elements
