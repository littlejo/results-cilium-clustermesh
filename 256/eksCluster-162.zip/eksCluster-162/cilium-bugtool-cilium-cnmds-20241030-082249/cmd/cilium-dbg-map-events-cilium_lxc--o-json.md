{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:32.604Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.161.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:32.604Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.164.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:32.604Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:37.266Z",
  "value": "id=785   sec_id=5355553 flags=0x0000 ifindex=12  mac=3E:8D:5B:E6:CF:85 nodemac=D6:A6:04:DB:9B:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:37.273Z",
  "value": "id=352   sec_id=4     flags=0x0000 ifindex=10  mac=16:67:73:92:34:24 nodemac=D6:00:59:74:05:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:37.319Z",
  "value": "id=461   sec_id=5355553 flags=0x0000 ifindex=14  mac=C2:97:49:26:8B:67 nodemac=3A:E9:7E:4E:64:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:37.349Z",
  "value": "id=352   sec_id=4     flags=0x0000 ifindex=10  mac=16:67:73:92:34:24 nodemac=D6:00:59:74:05:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:13.920Z",
  "value": "id=785   sec_id=5355553 flags=0x0000 ifindex=12  mac=3E:8D:5B:E6:CF:85 nodemac=D6:A6:04:DB:9B:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:13.920Z",
  "value": "id=461   sec_id=5355553 flags=0x0000 ifindex=14  mac=C2:97:49:26:8B:67 nodemac=3A:E9:7E:4E:64:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:13.921Z",
  "value": "id=352   sec_id=4     flags=0x0000 ifindex=10  mac=16:67:73:92:34:24 nodemac=D6:00:59:74:05:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:13.951Z",
  "value": "id=306   sec_id=5365729 flags=0x0000 ifindex=16  mac=52:10:0A:C2:AA:BA nodemac=DA:C2:1C:35:DE:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:14.920Z",
  "value": "id=352   sec_id=4     flags=0x0000 ifindex=10  mac=16:67:73:92:34:24 nodemac=D6:00:59:74:05:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:14.920Z",
  "value": "id=461   sec_id=5355553 flags=0x0000 ifindex=14  mac=C2:97:49:26:8B:67 nodemac=3A:E9:7E:4E:64:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:14.920Z",
  "value": "id=306   sec_id=5365729 flags=0x0000 ifindex=16  mac=52:10:0A:C2:AA:BA nodemac=DA:C2:1C:35:DE:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:14.920Z",
  "value": "id=785   sec_id=5355553 flags=0x0000 ifindex=12  mac=3E:8D:5B:E6:CF:85 nodemac=D6:A6:04:DB:9B:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.365Z",
  "value": "id=267   sec_id=5365729 flags=0x0000 ifindex=18  mac=8E:81:16:14:C0:63 nodemac=8A:04:F0:62:15:CD"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.162.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.711Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.665Z",
  "value": "id=352   sec_id=4     flags=0x0000 ifindex=10  mac=16:67:73:92:34:24 nodemac=D6:00:59:74:05:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.665Z",
  "value": "id=785   sec_id=5355553 flags=0x0000 ifindex=12  mac=3E:8D:5B:E6:CF:85 nodemac=D6:A6:04:DB:9B:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.666Z",
  "value": "id=461   sec_id=5355553 flags=0x0000 ifindex=14  mac=C2:97:49:26:8B:67 nodemac=3A:E9:7E:4E:64:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.666Z",
  "value": "id=267   sec_id=5365729 flags=0x0000 ifindex=18  mac=8E:81:16:14:C0:63 nodemac=8A:04:F0:62:15:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.665Z",
  "value": "id=267   sec_id=5365729 flags=0x0000 ifindex=18  mac=8E:81:16:14:C0:63 nodemac=8A:04:F0:62:15:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.666Z",
  "value": "id=352   sec_id=4     flags=0x0000 ifindex=10  mac=16:67:73:92:34:24 nodemac=D6:00:59:74:05:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.666Z",
  "value": "id=785   sec_id=5355553 flags=0x0000 ifindex=12  mac=3E:8D:5B:E6:CF:85 nodemac=D6:A6:04:DB:9B:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.667Z",
  "value": "id=461   sec_id=5355553 flags=0x0000 ifindex=14  mac=C2:97:49:26:8B:67 nodemac=3A:E9:7E:4E:64:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.665Z",
  "value": "id=267   sec_id=5365729 flags=0x0000 ifindex=18  mac=8E:81:16:14:C0:63 nodemac=8A:04:F0:62:15:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.666Z",
  "value": "id=352   sec_id=4     flags=0x0000 ifindex=10  mac=16:67:73:92:34:24 nodemac=D6:00:59:74:05:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.666Z",
  "value": "id=785   sec_id=5355553 flags=0x0000 ifindex=12  mac=3E:8D:5B:E6:CF:85 nodemac=D6:A6:04:DB:9B:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.667Z",
  "value": "id=461   sec_id=5355553 flags=0x0000 ifindex=14  mac=C2:97:49:26:8B:67 nodemac=3A:E9:7E:4E:64:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.666Z",
  "value": "id=461   sec_id=5355553 flags=0x0000 ifindex=14  mac=C2:97:49:26:8B:67 nodemac=3A:E9:7E:4E:64:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.666Z",
  "value": "id=267   sec_id=5365729 flags=0x0000 ifindex=18  mac=8E:81:16:14:C0:63 nodemac=8A:04:F0:62:15:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.666Z",
  "value": "id=352   sec_id=4     flags=0x0000 ifindex=10  mac=16:67:73:92:34:24 nodemac=D6:00:59:74:05:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.162.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.667Z",
  "value": "id=785   sec_id=5355553 flags=0x0000 ifindex=12  mac=3E:8D:5B:E6:CF:85 nodemac=D6:A6:04:DB:9B:C9"
}

