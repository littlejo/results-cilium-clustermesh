Total: 696
TCP:   1876 (estab 445, closed 1412, orphaned 0, timewait 564)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  464       452       12       
INET	  474       458       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                   172.31.164.49%ens5:68         0.0.0.0:*    uid:192 ino:76399 sk:3f9 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:36582 sk:3fa cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15682 sk:3fb cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:37767      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:36469 sk:3fc fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:36581 sk:3fd cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15683 sk:3fe cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::441:25ff:fe79:82ef]%ens5:546           [::]:*    uid:192 ino:15189 sk:3ff cgroup:unreachable:c4e v6only:1 <->                   
