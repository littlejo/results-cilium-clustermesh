 08:22:50 up 31 min,  0 users,  load average: 0.07, 0.16, 0.12
