alloc: 102.19MB (107158392 bytes)
total-alloc: 2.23GB (2390217136 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 63142483
frees: 62465215
heap-alloc: 102.19MB (107158392 bytes)
heap-sys: 247.88MB (259915776 bytes)
heap-idle: 80.97MB (84901888 bytes)
heap-in-use: 166.91MB (175013888 bytes)
heap-released: 0 bytes
heap-objects: 677268
stack-in-use: 60.12MB (63045632 bytes)
stack-sys: 60.12MB (63045632 bytes)
stack-mspan-inuse: 2.80MB (2935680 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.02MB (1068193 bytes)
gc-sys: 5.95MB (6243720 bytes)
next-gc: when heap-alloc >= 226.33MB (237325208 bytes)
last-gc: 2024-10-30 08:23:20.225569065 +0000 UTC
gc-pause-total: 27.834313ms
gc-pause: 159205
gc-pause-end: 1730276600225569065
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0004753647785478042
enable-gc: true
debug-gc: false
