1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:41:25:79:82:ef brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.164.49/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3507sec preferred_lft 3507sec
    inet6 fe80::441:25ff:fe79:82ef/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:e5:78:86:8c:f7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.161.62/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4e5:78ff:fe86:8cf7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:5a:c4:ff:b6:13 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1c5a:c4ff:feff:b613/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:29:f9:c3:d9:6d brd ff:ff:ff:ff:ff:ff
    inet 10.162.0.3/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::ec29:f9ff:fec3:d96d/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 36:d1:c3:c3:5a:3f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::34d1:c3ff:fec3:5a3f/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:00:59:74:05:a1 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d400:59ff:fe74:5a1/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf4cad97f8d9c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:a6:04:db:9b:c9 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d4a6:4ff:fedb:9bc9/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcbce23e491949@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:e9:7e:4e:64:21 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::38e9:7eff:fe4e:6421/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc8b8dea44f8c5@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:04:f0:62:15:cd brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::8804:f0ff:fe62:15cd/64 scope link 
       valid_lft forever preferred_lft forever
