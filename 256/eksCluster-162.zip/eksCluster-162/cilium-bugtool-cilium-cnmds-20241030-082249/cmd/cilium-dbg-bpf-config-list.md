KEY             VALUE
AgentLiveness   1933163221104
UTimeOffset     3379442710937500
