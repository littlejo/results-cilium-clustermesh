xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 556
ens6(5) clsact/ingress cil_from_netdev-ens6 id 569
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 551
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 538
cilium_host(7) clsact/egress cil_from_host-cilium_host id 543
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 579
lxcf4cad97f8d9c(12) clsact/ingress cil_from_container-lxcf4cad97f8d9c id 531
lxcbce23e491949(14) clsact/ingress cil_from_container-lxcbce23e491949 id 570
lxc8b8dea44f8c5(18) clsact/ingress cil_from_container-lxc8b8dea44f8c5 id 652

flow_dissector:

netfilter:

