top - 08:22:50 up 31 min,  0 users,  load average: 0.07, 0.16, 0.12
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 18.8 us, 21.9 sy,  0.0 ni, 59.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4482.5 free,   1186.4 used,   2145.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6442.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 378096  78456 S   6.7   4.7   0:46.25 cilium-+
    657 root      20   0 1240432  16676  11484 S   6.7   0.2   0:00.03 cilium-+
    395 root      20   0 1229744   8104   3840 S   0.0   0.1   0:01.11 cilium-+
    604 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
    627 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    645 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    646 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    647 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    698 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    716 root      20   0 1228744   3716   3040 S   0.0   0.0   0:00.00 gops
