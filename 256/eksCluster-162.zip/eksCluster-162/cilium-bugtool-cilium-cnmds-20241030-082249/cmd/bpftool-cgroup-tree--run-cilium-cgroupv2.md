CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf05e6e7_c30f_4535_aa7f_943d0dd8156b.slice/cri-containerd-1f255f41f4ea880c685b507de5fc9a1d5d99a9c0172b485b94989fb31b3ee719.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf05e6e7_c30f_4535_aa7f_943d0dd8156b.slice/cri-containerd-7a6edaa664692454587230f6b0460675505da70fdbf6036e6bab88d863ea5f62.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf3029c43_b1c8_4423_991d_f00b81736507.slice/cri-containerd-97b90a7240a81e931dbcf7c13b0baa45fc0a141db5ca86ab5355dd7f0b9dd45b.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf3029c43_b1c8_4423_991d_f00b81736507.slice/cri-containerd-13d7292733ec8e7063a97a2a0cdfcb29bc6ca32e02ad2b0310d418b53ac49498.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7398fc44_3b47_497b_8ab3_97b62514341c.slice/cri-containerd-f970e0b6c6cf56af03856a84201b7e800521dc86489fd01c083385d7a8723045.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7398fc44_3b47_497b_8ab3_97b62514341c.slice/cri-containerd-63d8d4527923313480fc3dc70649faa023955ff28ddcac7da8bf6b0e7213f061.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2d72d95a_4c0b_427e_80cc_93c17b7336d1.slice/cri-containerd-61f1e8dc5be39f66e1820c3945643eced71c221b5e0cc6c1c2dc02abbdda6f01.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2d72d95a_4c0b_427e_80cc_93c17b7336d1.slice/cri-containerd-0849d265951762f249c02b81d404c79c6cb8af240ccc1b5752793ddf38febcec.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod554ee6d5_5d42_4611_97d3_e21cca34eedc.slice/cri-containerd-af92be78ef37469f10b4c1cb23adc7adbc884a3d4c6c1b8edf0373533613e77c.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod554ee6d5_5d42_4611_97d3_e21cca34eedc.slice/cri-containerd-6f6dda74b866fb00a2d6fb56add6bb252fd650ace5313ffbdf69db8de5c8643d.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde5d1187_a14e_48d6_bfe6_469b6c6e87ae.slice/cri-containerd-386d725a0aac57595c54cec3f2e9d370d0c9e43b56a09815cb798bc74db680c3.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde5d1187_a14e_48d6_bfe6_469b6c6e87ae.slice/cri-containerd-adffbe486356e670ffe53d4c69312729daebb43bb5ad008049a210ab4c1aa74f.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9efa77a4_f879_4cda_8298_b27008de2cd3.slice/cri-containerd-d8d624584cd23933b566577aa42dcf7c9276ac29b640103a5b8d6620b27f187e.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9efa77a4_f879_4cda_8298_b27008de2cd3.slice/cri-containerd-16569955c7f6945a0043affd06755eeacb2028ae38c76dae5c2f190162ab8813.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9efa77a4_f879_4cda_8298_b27008de2cd3.slice/cri-containerd-5cadf0e051e5086c94a9f4c9ed7881ddb368c6045c2bb5150e56b7f3d2d08640.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9efa77a4_f879_4cda_8298_b27008de2cd3.slice/cri-containerd-6f7a24fa5c9e7ed8f938a78d331c5fe048ce33b6b89298f9c9966e4069e9f181.scope
    673      cgroup_device   multi                                          
