IP ADDRESS        LOCAL ENDPOINT INFO
172.31.164.49:0   (localhost)                                                                                        
10.162.0.3:0      (localhost)                                                                                        
10.162.0.45:0     id=352   sec_id=4     flags=0x0000 ifindex=10  mac=16:67:73:92:34:24 nodemac=D6:00:59:74:05:A1     
10.162.0.99:0     id=461   sec_id=5355553 flags=0x0000 ifindex=14  mac=C2:97:49:26:8B:67 nodemac=3A:E9:7E:4E:64:21   
172.31.161.62:0   (localhost)                                                                                        
10.162.0.141:0    id=785   sec_id=5355553 flags=0x0000 ifindex=12  mac=3E:8D:5B:E6:CF:85 nodemac=D6:A6:04:DB:9B:C9   
10.162.0.237:0    id=267   sec_id=5365729 flags=0x0000 ifindex=18  mac=8E:81:16:14:C0:63 nodemac=8A:04:F0:62:15:CD   
