Endpoint ID: 267
Path: /sys/fs/bpf/tc/globals/cilium_policy_00267

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11516814   115258    0        
Allow    Ingress     1          ANY          NONE         disabled    9764554    102373    0        
Allow    Egress      0          ANY          NONE         disabled    13416561   131788    0        


Endpoint ID: 352
Path: /sys/fs/bpf/tc/globals/cilium_policy_00352

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1643966   20785     0        
Allow    Ingress     1          ANY          NONE         disabled    18566     217       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 461
Path: /sys/fs/bpf/tc/globals/cilium_policy_00461

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    123943   1424      0        
Allow    Egress      0          ANY          NONE         disabled    17186    186       0        


Endpoint ID: 785
Path: /sys/fs/bpf/tc/globals/cilium_policy_00785

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    124330   1426      0        
Allow    Egress      0          ANY          NONE         disabled    16348    176       0        


Endpoint ID: 3522
Path: /sys/fs/bpf/tc/globals/cilium_policy_03522

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


