[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod142157d8_939b_43dc_9d93_801ac0ea6940.slice/cri-containerd-99334ee01a49dfe0c641c1c00b3e0cee3c507676b4493b8a2a0212201d0b46bf.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod142157d8_939b_43dc_9d93_801ac0ea6940.slice/cri-containerd-9eb41d24a428028787a055e8b04be47cfe16047ba0905ce29781dbb97fe6e1fd.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod142157d8_939b_43dc_9d93_801ac0ea6940.slice/cri-containerd-c99a33d8096e0f695ceaa44cfddd287a0593e16ed3ee8e4aabd3eacf68f7b0f0.scope"
      }
    ],
    "ips": [
      "10.148.0.250"
    ],
    "name": "clustermesh-apiserver-787bf96696-vg2jq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod046b3658_9cc6_49a4_a235_eafd1f1f01b1.slice/cri-containerd-3925dba4684a112d8e70646c4e316b737f6f02ed2d7cd7baf743545d86a1346e.scope"
      }
    ],
    "ips": [
      "10.148.0.114"
    ],
    "name": "coredns-cc6ccd49c-kk5xj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1df79f5b_7146_4264_92f0_d32f5f2cd90f.slice/cri-containerd-476cb6c1dc39bf3da1ed26d21907814d233559815d5590dd66446ec576667b54.scope"
      }
    ],
    "ips": [
      "10.148.0.165"
    ],
    "name": "coredns-cc6ccd49c-hjthf",
    "namespace": "kube-system"
  }
]

