KEY             VALUE
AgentLiveness   1929033853352
UTimeOffset     3379442718750000
