1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:56:df:71:28:d7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.175.74/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3513sec preferred_lft 3513sec
    inet6 fe80::456:dfff:fe71:28d7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ab:85:74:0c:cd brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.137.142/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4ab:85ff:fe74:ccd/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:9b:b0:a7:04:1a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::cc9b:b0ff:fea7:41a/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:a6:03:a3:88:b5 brd ff:ff:ff:ff:ff:ff
    inet 10.148.0.241/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::58a6:3ff:fea3:88b5/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 82:84:ab:a3:af:6d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8084:abff:fea3:af6d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:08:88:85:18:8a brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::ec08:88ff:fe85:188a/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc3289917d01f3@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:83:c8:6c:3d:45 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::9083:c8ff:fe6c:3d45/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce31a8d75baa4@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:95:ac:a5:19:8f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::2095:acff:fea5:198f/64 scope link 
       valid_lft forever preferred_lft forever
18: lxca6f60b368e97@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:94:97:31:d6:fd brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7494:97ff:fe31:d6fd/64 scope link 
       valid_lft forever preferred_lft forever
