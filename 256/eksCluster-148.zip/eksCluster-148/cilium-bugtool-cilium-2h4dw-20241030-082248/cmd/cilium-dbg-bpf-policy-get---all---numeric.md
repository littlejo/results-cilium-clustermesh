Endpoint ID: 159
Path: /sys/fs/bpf/tc/globals/cilium_policy_00159

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1644391   20760     0        
Allow    Ingress     1          ANY          NONE         disabled    18880     221       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 709
Path: /sys/fs/bpf/tc/globals/cilium_policy_00709

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11494989   115909    0        
Allow    Ingress     1          ANY          NONE         disabled    10605841   111887    0        
Allow    Egress      0          ANY          NONE         disabled    14594057   142520    0        


Endpoint ID: 2260
Path: /sys/fs/bpf/tc/globals/cilium_policy_02260

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    125188   1439      0        
Allow    Egress      0          ANY          NONE         disabled    17718    193       0        


Endpoint ID: 2551
Path: /sys/fs/bpf/tc/globals/cilium_policy_02551

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    124660   1431      0        
Allow    Egress      0          ANY          NONE         disabled    16833    181       0        


Endpoint ID: 2572
Path: /sys/fs/bpf/tc/globals/cilium_policy_02572

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


