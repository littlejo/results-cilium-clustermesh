CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb3bc758d_73eb_4815_9f31_2def3ea7a1a0.slice/cri-containerd-6fb869bff21ba3862c3f8d8490a7c24728af48721b9e4b38e16f4b15194c7d43.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb3bc758d_73eb_4815_9f31_2def3ea7a1a0.slice/cri-containerd-c331b1f48222e7e7091f304c233c03e754d33e1796a5c9f6e86d9b3f5f2a08dc.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1df79f5b_7146_4264_92f0_d32f5f2cd90f.slice/cri-containerd-476cb6c1dc39bf3da1ed26d21907814d233559815d5590dd66446ec576667b54.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1df79f5b_7146_4264_92f0_d32f5f2cd90f.slice/cri-containerd-028a6f3d30b643f97d2d16880c7d4d38a2192fa1846d95ac9988ddbe9a78b5fe.scope
    543      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda006a757_3275_484a_a7f7_0d9c45a615e5.slice/cri-containerd-5f6fffbdfc8a7aeb40632e5246cf0a3ea76e3a885143b776bbc3868e713ad935.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda006a757_3275_484a_a7f7_0d9c45a615e5.slice/cri-containerd-e710e055a41e2a39b8cec96ba1c04c3cca456faa2dac7b86bdf83de2b88ec666.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod046b3658_9cc6_49a4_a235_eafd1f1f01b1.slice/cri-containerd-3925dba4684a112d8e70646c4e316b737f6f02ed2d7cd7baf743545d86a1346e.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod046b3658_9cc6_49a4_a235_eafd1f1f01b1.slice/cri-containerd-d4da19aed44d5a6c098d335197012589a6afd6263d18cd467636dfc6afc7ae7e.scope
    547      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod326de0a2_e829_4fe7_91b1_2982b87fb6b7.slice/cri-containerd-0c373d4883104de894bbc587cc403e51f86b261486402bf84ed8265364463a47.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod326de0a2_e829_4fe7_91b1_2982b87fb6b7.slice/cri-containerd-51bc7cc5b118022e81b663178f5416fed24c0d0ca03def09b600d7c1b69f6f75.scope
    110      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod142157d8_939b_43dc_9d93_801ac0ea6940.slice/cri-containerd-c99a33d8096e0f695ceaa44cfddd287a0593e16ed3ee8e4aabd3eacf68f7b0f0.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod142157d8_939b_43dc_9d93_801ac0ea6940.slice/cri-containerd-99334ee01a49dfe0c641c1c00b3e0cee3c507676b4493b8a2a0212201d0b46bf.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod142157d8_939b_43dc_9d93_801ac0ea6940.slice/cri-containerd-0ed435754b2b6b53a5f132c876a8708e0278a534279acee2f316badfe170ab57.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod142157d8_939b_43dc_9d93_801ac0ea6940.slice/cri-containerd-9eb41d24a428028787a055e8b04be47cfe16047ba0905ce29781dbb97fe6e1fd.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc2771050_3ce2_4a7d_ab30_af7efd3abb53.slice/cri-containerd-ac4c1be5e4a20bf1774f9b14fdc63aff9c31f0e042394e9572ac49e4545cb2a5.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc2771050_3ce2_4a7d_ab30_af7efd3abb53.slice/cri-containerd-0ffad44dc3a47ccb74a638e297a7065e92db468e2d179b7a376f0f7593678493.scope
    102      cgroup_device   multi                                          
