alloc: 130.42MB (136758880 bytes)
total-alloc: 2.29GB (2462432424 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 64274938
frees: 63340534
heap-alloc: 130.42MB (136758880 bytes)
heap-sys: 243.02MB (254820352 bytes)
heap-idle: 61.92MB (64929792 bytes)
heap-in-use: 181.09MB (189890560 bytes)
heap-released: 1.97MB (2064384 bytes)
heap-objects: 934404
stack-in-use: 64.94MB (68091904 bytes)
stack-sys: 64.94MB (68091904 bytes)
stack-mspan-inuse: 2.79MB (2923680 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1019.30KB (1043761 bytes)
gc-sys: 6.03MB (6327880 bytes)
next-gc: when heap-alloc >= 211.31MB (221570872 bytes)
last-gc: 2024-10-30 08:23:09.949477541 +0000 UTC
gc-pause-total: 15.722802ms
gc-pause: 184890
gc-pause-end: 1730276589949477541
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0004902175247788191
enable-gc: true
debug-gc: false
