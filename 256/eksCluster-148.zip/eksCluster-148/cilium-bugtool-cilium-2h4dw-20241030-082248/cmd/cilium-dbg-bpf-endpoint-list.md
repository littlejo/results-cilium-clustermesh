IP ADDRESS         LOCAL ENDPOINT INFO
10.148.0.114:0     id=2551  sec_id=4891322 flags=0x0000 ifindex=14  mac=66:30:0E:58:87:5B nodemac=22:95:AC:A5:19:8F   
10.148.0.156:0     id=159   sec_id=4     flags=0x0000 ifindex=10  mac=D2:A1:95:5C:89:E3 nodemac=EE:08:88:85:18:8A     
10.148.0.165:0     id=2260  sec_id=4891322 flags=0x0000 ifindex=12  mac=1A:0B:2E:E9:B0:29 nodemac=92:83:C8:6C:3D:45   
10.148.0.241:0     (localhost)                                                                                        
172.31.137.142:0   (localhost)                                                                                        
172.31.175.74:0    (localhost)                                                                                        
10.148.0.250:0     id=709   sec_id=4891986 flags=0x0000 ifindex=18  mac=62:04:98:96:DE:C1 nodemac=76:94:97:31:D6:FD   
