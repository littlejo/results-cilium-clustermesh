 08:22:49 up 31 min,  0 users,  load average: 0.87, 0.52, 0.29
