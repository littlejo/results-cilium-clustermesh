key: 9f 00 00 00  value: 0c 02 00 00
key: c5 02 00 00  value: 70 02 00 00
key: d4 08 00 00  value: 1a 02 00 00
key: f7 09 00 00  value: 04 02 00 00
Found 4 elements
