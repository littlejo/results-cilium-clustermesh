markdown output at /tmp/cilium-bugtool-20241030-082249.386+0000-UTC-753793225/cmd/cilium-debuginfo-20241030-082320.619+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082249.386+0000-UTC-753793225/cmd/cilium-debuginfo-20241030-082320.619+0000-UTC.json
