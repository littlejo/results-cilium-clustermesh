xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 574
ens6(5) clsact/ingress cil_from_netdev-ens6 id 583
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 563
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 556
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 520
lxc3289917d01f3(12) clsact/ingress cil_from_container-lxc3289917d01f3 id 539
lxce31a8d75baa4(14) clsact/ingress cil_from_container-lxce31a8d75baa4 id 515
lxca6f60b368e97(18) clsact/ingress cil_from_container-lxca6f60b368e97 id 633

flow_dissector:

netfilter:

