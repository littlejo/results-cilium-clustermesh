REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36587     2897672     677    bpf_overlay.c
Interface                 INGRESS     660557    134067879   1132   bpf_host.c
Success                   EGRESS      16536     1301884     1694   bpf_host.c
Success                   EGRESS      283467    34960651    1308   bpf_lxc.c
Success                   EGRESS      37003     2924926     53     encap.h
Success                   INGRESS     324635    36882271    86     l3.h
Success                   INGRESS     345337    38522105    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
