top - 08:22:49 up 31 min,  0 users,  load average: 0.87, 0.52, 0.29
Tasks:  12 total,   1 running,  11 sleeping,   0 stopped,   0 zombie
%Cpu(s): 53.3 us, 40.0 sy,  0.0 ni,  6.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4473.8 free,   1195.0 used,   2145.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6434.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    732 root      20   0 1244340  20916  14400 S  26.7   0.3   0:00.04 hubble
      1 root      20   0 1606080 377440  77872 S   6.7   4.7   0:52.78 cilium-+
    402 root      20   0 1229744   6884   2924 S   0.0   0.1   0:01.18 cilium-+
    632 root      20   0 1240432  16684  11484 S   0.0   0.2   0:00.02 cilium-+
    638 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    639 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    649 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    662 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    713 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    717 root      20   0 1228744   3980   3328 S   0.0   0.0   0:00.00 gops
    722 root      20   0    2208    788    712 S   0.0   0.0   0:00.00 timeout
    753 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
