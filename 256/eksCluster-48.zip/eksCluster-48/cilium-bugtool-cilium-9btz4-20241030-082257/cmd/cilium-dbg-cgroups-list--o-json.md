[
  {
    "containers": [
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1d4c502_b86a_444d_9c55_c74f680ec391.slice/cri-containerd-b2db5521da55e18a474d783d8ad6557110a97a313cb3ac077c125558ec49b78a.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1d4c502_b86a_444d_9c55_c74f680ec391.slice/cri-containerd-5963234cdc1ce55f3c7a960da7c3868f4a431e7295accd0e689feb4bc4c334f0.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1d4c502_b86a_444d_9c55_c74f680ec391.slice/cri-containerd-dc7917ea1b69d4ad4264f0d972705ab5ae5332281439ab0b380fb50e8a642dbf.scope"
      }
    ],
    "ips": [
      "10.48.0.64"
    ],
    "name": "clustermesh-apiserver-7dc776c656-q2llj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf92b9274_3d9f_4ce2_845d_95491a6fb5cd.slice/cri-containerd-3a2e22cf79c4058400594959a5cfd211f3f081fc8e68594bea9cae85c0360d35.scope"
      }
    ],
    "ips": [
      "10.48.0.244"
    ],
    "name": "coredns-cc6ccd49c-nrsdh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc89aa9da_fe3c_40cd_bf8d_817fcfab79c0.slice/cri-containerd-26ef986f5539638ab6b2716e5f370407cd37270d8483b23a9da232f3978b1c10.scope"
      }
    ],
    "ips": [
      "10.48.0.136"
    ],
    "name": "coredns-cc6ccd49c-tzhm5",
    "namespace": "kube-system"
  }
]

