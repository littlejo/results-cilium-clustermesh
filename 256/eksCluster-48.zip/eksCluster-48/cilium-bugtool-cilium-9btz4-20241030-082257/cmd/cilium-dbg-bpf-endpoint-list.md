IP ADDRESS         LOCAL ENDPOINT INFO
172.31.163.127:0   (localhost)                                                                                        
10.48.0.126:0      (localhost)                                                                                        
172.31.162.77:0    (localhost)                                                                                        
10.48.0.7:0        id=2497  sec_id=4     flags=0x0000 ifindex=10  mac=E6:B6:13:25:5A:89 nodemac=FE:95:A1:D6:EC:5E     
10.48.0.136:0      id=1469  sec_id=1619012 flags=0x0000 ifindex=12  mac=7E:FC:D9:C1:8F:AA nodemac=DA:72:3A:17:A7:90   
10.48.0.64:0       id=139   sec_id=1631229 flags=0x0000 ifindex=18  mac=E2:61:AB:31:44:88 nodemac=62:2C:E5:52:BE:88   
10.48.0.244:0      id=2902  sec_id=1619012 flags=0x0000 ifindex=14  mac=52:DA:67:91:5B:BF nodemac=4E:AB:CF:BB:42:EF   
