alloc: 194.95MB (204423760 bytes)
total-alloc: 2.17GB (2334902320 bytes)
sys: 324.96MB (340742500 bytes)
lookups: 0
mallocs: 62133765
frees: 60108873
heap-alloc: 194.95MB (204423760 bytes)
heap-sys: 247.61MB (259637248 bytes)
heap-idle: 32.70MB (34283520 bytes)
heap-in-use: 214.91MB (225353728 bytes)
heap-released: 1.95MB (2048000 bytes)
heap-objects: 2024892
stack-in-use: 64.34MB (67469312 bytes)
stack-sys: 64.34MB (67469312 bytes)
stack-mspan-inuse: 3.35MB (3517120 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.00MB (1050889 bytes)
gc-sys: 6.20MB (6503888 bytes)
next-gc: when heap-alloc >= 217.63MB (228201384 bytes)
last-gc: 2024-10-30 08:22:59.381140571 +0000 UTC
gc-pause-total: 8.784568ms
gc-pause: 136324
gc-pause-end: 1730276579381140571
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0003862319286879658
enable-gc: true
debug-gc: false
