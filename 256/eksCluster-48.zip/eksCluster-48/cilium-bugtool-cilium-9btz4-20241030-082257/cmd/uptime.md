 08:22:58 up 34 min,  0 users,  load average: 0.19, 0.30, 0.18
