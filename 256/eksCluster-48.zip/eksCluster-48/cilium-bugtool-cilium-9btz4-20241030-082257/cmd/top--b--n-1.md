top - 08:22:58 up 34 min,  0 users,  load average: 0.19, 0.30, 0.18
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 26.7 us, 26.7 sy,  0.0 ni, 43.3 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4488.7 free,   1179.8 used,   2145.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6449.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606272 378224  77700 S  20.0   4.7   0:49.39 cilium-+
    620 root      20   0 1240432  16272  11292 S  13.3   0.2   0:00.03 cilium-+
    394 root      20   0 1229744   6828   2868 S   0.0   0.1   0:01.18 cilium-+
    630 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    631 root      20   0 1228744   4032   3392 S   0.0   0.1   0:00.00 gops
    633 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    683 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    701 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
    706 root      20   0 1539912   8268   6200 S   0.0   0.1   0:00.00 runc:[2+
