{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:55.705Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.162.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:55.705Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.163.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:55.705Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:01.180Z",
  "value": "id=1469  sec_id=1619012 flags=0x0000 ifindex=12  mac=7E:FC:D9:C1:8F:AA nodemac=DA:72:3A:17:A7:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:01.180Z",
  "value": "id=2497  sec_id=4     flags=0x0000 ifindex=10  mac=E6:B6:13:25:5A:89 nodemac=FE:95:A1:D6:EC:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:01.244Z",
  "value": "id=2497  sec_id=4     flags=0x0000 ifindex=10  mac=E6:B6:13:25:5A:89 nodemac=FE:95:A1:D6:EC:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:01.246Z",
  "value": "id=2902  sec_id=1619012 flags=0x0000 ifindex=14  mac=52:DA:67:91:5B:BF nodemac=4E:AB:CF:BB:42:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:54.691Z",
  "value": "id=2497  sec_id=4     flags=0x0000 ifindex=10  mac=E6:B6:13:25:5A:89 nodemac=FE:95:A1:D6:EC:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:54.692Z",
  "value": "id=1469  sec_id=1619012 flags=0x0000 ifindex=12  mac=7E:FC:D9:C1:8F:AA nodemac=DA:72:3A:17:A7:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:54.692Z",
  "value": "id=2902  sec_id=1619012 flags=0x0000 ifindex=14  mac=52:DA:67:91:5B:BF nodemac=4E:AB:CF:BB:42:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:54.722Z",
  "value": "id=3830  sec_id=1631229 flags=0x0000 ifindex=16  mac=16:C3:0B:2E:FC:02 nodemac=02:39:B4:15:1D:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:55.691Z",
  "value": "id=3830  sec_id=1631229 flags=0x0000 ifindex=16  mac=16:C3:0B:2E:FC:02 nodemac=02:39:B4:15:1D:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:55.692Z",
  "value": "id=2497  sec_id=4     flags=0x0000 ifindex=10  mac=E6:B6:13:25:5A:89 nodemac=FE:95:A1:D6:EC:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:55.693Z",
  "value": "id=1469  sec_id=1619012 flags=0x0000 ifindex=12  mac=7E:FC:D9:C1:8F:AA nodemac=DA:72:3A:17:A7:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:55.693Z",
  "value": "id=2902  sec_id=1619012 flags=0x0000 ifindex=14  mac=52:DA:67:91:5B:BF nodemac=4E:AB:CF:BB:42:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:18.735Z",
  "value": "id=139   sec_id=1631229 flags=0x0000 ifindex=18  mac=E2:61:AB:31:44:88 nodemac=62:2C:E5:52:BE:88"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.48.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.205Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:18.062Z",
  "value": "id=2902  sec_id=1619012 flags=0x0000 ifindex=14  mac=52:DA:67:91:5B:BF nodemac=4E:AB:CF:BB:42:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:18.062Z",
  "value": "id=139   sec_id=1631229 flags=0x0000 ifindex=18  mac=E2:61:AB:31:44:88 nodemac=62:2C:E5:52:BE:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:18.063Z",
  "value": "id=2497  sec_id=4     flags=0x0000 ifindex=10  mac=E6:B6:13:25:5A:89 nodemac=FE:95:A1:D6:EC:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:18.063Z",
  "value": "id=1469  sec_id=1619012 flags=0x0000 ifindex=12  mac=7E:FC:D9:C1:8F:AA nodemac=DA:72:3A:17:A7:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:19.069Z",
  "value": "id=139   sec_id=1631229 flags=0x0000 ifindex=18  mac=E2:61:AB:31:44:88 nodemac=62:2C:E5:52:BE:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:19.074Z",
  "value": "id=2497  sec_id=4     flags=0x0000 ifindex=10  mac=E6:B6:13:25:5A:89 nodemac=FE:95:A1:D6:EC:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:19.074Z",
  "value": "id=1469  sec_id=1619012 flags=0x0000 ifindex=12  mac=7E:FC:D9:C1:8F:AA nodemac=DA:72:3A:17:A7:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:19.075Z",
  "value": "id=2902  sec_id=1619012 flags=0x0000 ifindex=14  mac=52:DA:67:91:5B:BF nodemac=4E:AB:CF:BB:42:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:20.068Z",
  "value": "id=139   sec_id=1631229 flags=0x0000 ifindex=18  mac=E2:61:AB:31:44:88 nodemac=62:2C:E5:52:BE:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:20.068Z",
  "value": "id=2497  sec_id=4     flags=0x0000 ifindex=10  mac=E6:B6:13:25:5A:89 nodemac=FE:95:A1:D6:EC:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:20.069Z",
  "value": "id=1469  sec_id=1619012 flags=0x0000 ifindex=12  mac=7E:FC:D9:C1:8F:AA nodemac=DA:72:3A:17:A7:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:20.069Z",
  "value": "id=2902  sec_id=1619012 flags=0x0000 ifindex=14  mac=52:DA:67:91:5B:BF nodemac=4E:AB:CF:BB:42:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:21.069Z",
  "value": "id=2497  sec_id=4     flags=0x0000 ifindex=10  mac=E6:B6:13:25:5A:89 nodemac=FE:95:A1:D6:EC:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:21.069Z",
  "value": "id=2902  sec_id=1619012 flags=0x0000 ifindex=14  mac=52:DA:67:91:5B:BF nodemac=4E:AB:CF:BB:42:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:21.069Z",
  "value": "id=139   sec_id=1631229 flags=0x0000 ifindex=18  mac=E2:61:AB:31:44:88 nodemac=62:2C:E5:52:BE:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:21.069Z",
  "value": "id=1469  sec_id=1619012 flags=0x0000 ifindex=12  mac=7E:FC:D9:C1:8F:AA nodemac=DA:72:3A:17:A7:90"
}

