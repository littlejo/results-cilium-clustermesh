KEY             VALUE
AgentLiveness   2092265310427
UTimeOffset     3379442416015625
