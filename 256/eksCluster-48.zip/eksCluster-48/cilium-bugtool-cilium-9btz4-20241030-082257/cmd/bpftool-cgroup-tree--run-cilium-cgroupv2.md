CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7abb5db2_a332_407b_a2b8_ac1ff00186a5.slice/cri-containerd-47931c430a639e31bc2b9c6c08b655a5adc0054577c03aca33be7eea9a737ca7.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7abb5db2_a332_407b_a2b8_ac1ff00186a5.slice/cri-containerd-79016c15055a55a271f54f3eecb018c1b78a3d0512cd34288dabfda541f34616.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc89aa9da_fe3c_40cd_bf8d_817fcfab79c0.slice/cri-containerd-3717299d46a9a4d8d02b0132a9812e20c73970b2a0ee4f1e5efbe94c9435ac02.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc89aa9da_fe3c_40cd_bf8d_817fcfab79c0.slice/cri-containerd-26ef986f5539638ab6b2716e5f370407cd37270d8483b23a9da232f3978b1c10.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf92b9274_3d9f_4ce2_845d_95491a6fb5cd.slice/cri-containerd-3a2e22cf79c4058400594959a5cfd211f3f081fc8e68594bea9cae85c0360d35.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf92b9274_3d9f_4ce2_845d_95491a6fb5cd.slice/cri-containerd-eac9270194820e5af0c5e15ef00719210ac19f1e4c253afa70791211970027e8.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5a287e72_e587_464c_b294_20dc11665f45.slice/cri-containerd-49831641e146257fa4c71dfdf5112e6296517f64b41539275ad9663923f60985.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5a287e72_e587_464c_b294_20dc11665f45.slice/cri-containerd-edc0d243685b209642c86a0ec73eb3d617f327b311d56ded6eda1957336d75fb.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1d4c502_b86a_444d_9c55_c74f680ec391.slice/cri-containerd-6a84f38b0940e18d76ec74f640a94e1651c2d82133c76241cfc3ce47de832be9.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1d4c502_b86a_444d_9c55_c74f680ec391.slice/cri-containerd-dc7917ea1b69d4ad4264f0d972705ab5ae5332281439ab0b380fb50e8a642dbf.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1d4c502_b86a_444d_9c55_c74f680ec391.slice/cri-containerd-b2db5521da55e18a474d783d8ad6557110a97a313cb3ac077c125558ec49b78a.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1d4c502_b86a_444d_9c55_c74f680ec391.slice/cri-containerd-5963234cdc1ce55f3c7a960da7c3868f4a431e7295accd0e689feb4bc4c334f0.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d592c36_d1cb_4348_aa40_f1bcae2885d7.slice/cri-containerd-50a38557b200c5fb37f0d60e3a54806add45603b362187141b670a3b419e8740.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d592c36_d1cb_4348_aa40_f1bcae2885d7.slice/cri-containerd-d56762d75a7cc385ca5e7ac4339bbc971cdf50bdcbbde1f607dc9e7827864159.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd09f5e16_87e0_4bb9_a408_304f5e683c01.slice/cri-containerd-5500ed45d8725d3802ddce59e046379c90ab744f003f52e15248c6c7fab44f8f.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd09f5e16_87e0_4bb9_a408_304f5e683c01.slice/cri-containerd-a8b51967db64e6551731d363a04b351b2713641f067bdfc115919be602ab8d28.scope
    106      cgroup_device   multi                                          
