1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:28:75:11:a8:31 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.162.77/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3349sec preferred_lft 3349sec
    inet6 fe80::428:75ff:fe11:a831/64 scope link 
       valid_lft forever preferred_lft forever
4: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:4d:97:99:d5:9f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.163.127/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::44d:97ff:fe99:d59f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:ee:fa:82:ae:8c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::84ee:faff:fe82:ae8c/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:6d:e0:67:09:5e brd ff:ff:ff:ff:ff:ff
    inet 10.48.0.126/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c46d:e0ff:fe67:95e/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether fe:23:77:02:97:81 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::fc23:77ff:fe02:9781/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:95:a1:d6:ec:5e brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::fc95:a1ff:fed6:ec5e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc119b97f957c7@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:72:3a:17:a7:90 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::d872:3aff:fe17:a790/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc56865effb1a8@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:ab:cf:bb:42:ef brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::4cab:cfff:febb:42ef/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc2f0b05db75b4@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:2c:e5:52:be:88 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::602c:e5ff:fe52:be88/64 scope link 
       valid_lft forever preferred_lft forever
