xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 503
ens6(4) clsact/ingress cil_from_netdev-ens6 id 506
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 492
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 490
cilium_host(7) clsact/egress cil_from_host-cilium_host id 486
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 552
lxc119b97f957c7(12) clsact/ingress cil_from_container-lxc119b97f957c7 id 521
lxc56865effb1a8(14) clsact/ingress cil_from_container-lxc56865effb1a8 id 538
lxc2f0b05db75b4(18) clsact/ingress cil_from_container-lxc2f0b05db75b4 id 613

flow_dissector:

netfilter:

