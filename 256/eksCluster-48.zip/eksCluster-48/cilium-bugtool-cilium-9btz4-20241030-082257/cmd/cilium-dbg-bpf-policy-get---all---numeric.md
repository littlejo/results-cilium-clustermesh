Endpoint ID: 139
Path: /sys/fs/bpf/tc/globals/cilium_policy_00139

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11278705   110498    0        
Allow    Ingress     1          ANY          NONE         disabled    8979637    93769     0        
Allow    Egress      0          ANY          NONE         disabled    10966404   109535    0        


Endpoint ID: 1133
Path: /sys/fs/bpf/tc/globals/cilium_policy_01133

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1469
Path: /sys/fs/bpf/tc/globals/cilium_policy_01469

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    150492   1723      0        
Allow    Egress      0          ANY          NONE         disabled    19007    210       0        


Endpoint ID: 2497
Path: /sys/fs/bpf/tc/globals/cilium_policy_02497

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1658080   21028     0        
Allow    Ingress     1          ANY          NONE         disabled    22388     262       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2902
Path: /sys/fs/bpf/tc/globals/cilium_policy_02902

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    151416   1737      0        
Allow    Egress      0          ANY          NONE         disabled    16901    185       0        


