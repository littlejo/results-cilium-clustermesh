ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.144.250:443 (active)   
                                         2 => 172.31.249.91:443 (active)    
2    10.100.9.180:443     ClusterIP      1 => 172.31.162.77:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.48.0.136:53 (active)       
                                         2 => 10.48.0.244:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.48.0.136:9153 (active)     
                                         2 => 10.48.0.244:9153 (active)     
5    10.100.193.27:2379   ClusterIP      1 => 10.48.0.64:2379 (active)      
