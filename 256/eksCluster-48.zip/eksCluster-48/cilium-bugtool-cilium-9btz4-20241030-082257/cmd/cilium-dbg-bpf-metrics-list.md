REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34174     2694909     677    bpf_overlay.c
Interface                 INGRESS     617445    128983643   1132   bpf_host.c
Success                   EGRESS      13831     1083643     1694   bpf_host.c
Success                   EGRESS      257174    32747754    1308   bpf_lxc.c
Success                   EGRESS      32833     2603640     53     encap.h
Success                   INGRESS     297570    33383402    86     l3.h
Success                   INGRESS     318564    35038714    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
