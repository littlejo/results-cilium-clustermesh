key: 8b 00 00 00  value: 66 02 00 00
key: bd 05 00 00  value: 05 02 00 00
key: c1 09 00 00  value: 22 02 00 00
key: 56 0b 00 00  value: 19 02 00 00
Found 4 elements
