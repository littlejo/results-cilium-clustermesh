USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         672  0.0  0.1 1539912 8440 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         666  0.0  0.1 1616008 8436 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         637  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         629  0.0  0.0 1228744 3660 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         623  0.0  0.2 1240432 16484 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         677  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         678  0.0  0.2 1240432 16484 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  2.9  4.7 1606080 377348 ?      Ssl  07:55   0:48 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.1 1229744 8224 ?        Sl   07:55   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
