KEY             VALUE
AgentLiveness   2127195290006
UTimeOffset     3379442330078125
