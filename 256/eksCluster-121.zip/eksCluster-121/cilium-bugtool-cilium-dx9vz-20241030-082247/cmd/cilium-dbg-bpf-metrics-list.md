REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36683     2900646     677    bpf_overlay.c
Interface                 INGRESS     667207    136388865   1132   bpf_host.c
Success                   EGRESS      16616     1306766     1694   bpf_host.c
Success                   EGRESS      290083    35587147    1308   bpf_lxc.c
Success                   EGRESS      37361     2945927     53     encap.h
Success                   INGRESS     332167    37798939    86     l3.h
Success                   INGRESS     352885    39436865    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
