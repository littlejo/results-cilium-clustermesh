markdown output at /tmp/cilium-bugtool-20241030-082248.722+0000-UTC-897667251/cmd/cilium-debuginfo-20241030-082319.982+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082248.722+0000-UTC-897667251/cmd/cilium-debuginfo-20241030-082319.982+0000-UTC.json
