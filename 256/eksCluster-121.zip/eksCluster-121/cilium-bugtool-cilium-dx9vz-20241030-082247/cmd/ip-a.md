1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:1b:1a:c2:0b:2b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.197.64/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3315sec preferred_lft 3315sec
    inet6 fe80::81b:1aff:fec2:b2b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:40:ec:26:39:d7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.224.255/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::840:ecff:fe26:39d7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:a3:7a:c8:b2:f6 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e4a3:7aff:fec8:b2f6/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:07:38:11:aa:60 brd ff:ff:ff:ff:ff:ff
    inet 10.121.0.57/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c07:38ff:fe11:aa60/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 0e:a7:31:4e:0a:c7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ca7:31ff:fe4e:ac7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:2b:13:bb:b5:9e brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::902b:13ff:febb:b59e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcba27b7dc30de@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:6e:a5:d1:94:19 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::bc6e:a5ff:fed1:9419/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcac3eb30737a4@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:70:92:0a:57:77 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c70:92ff:fe0a:5777/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc4245c2bb08bb@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:c4:3d:84:62:6e brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d8c4:3dff:fe84:626e/64 scope link 
       valid_lft forever preferred_lft forever
