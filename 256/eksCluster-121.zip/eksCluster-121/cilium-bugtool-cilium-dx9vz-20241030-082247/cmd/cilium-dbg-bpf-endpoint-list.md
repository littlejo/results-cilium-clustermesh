IP ADDRESS         LOCAL ENDPOINT INFO
172.31.224.255:0   (localhost)                                                                                        
172.31.197.64:0    (localhost)                                                                                        
10.121.0.57:0      (localhost)                                                                                        
10.121.0.17:0      id=916   sec_id=4     flags=0x0000 ifindex=10  mac=06:11:CB:BB:50:43 nodemac=92:2B:13:BB:B5:9E     
10.121.0.166:0     id=1876  sec_id=4012598 flags=0x0000 ifindex=18  mac=92:03:75:87:9A:D8 nodemac=DA:C4:3D:84:62:6E   
10.121.0.218:0     id=3740  sec_id=4008885 flags=0x0000 ifindex=14  mac=72:67:BB:1D:08:42 nodemac=0E:70:92:0A:57:77   
10.121.0.233:0     id=1332  sec_id=4008885 flags=0x0000 ifindex=12  mac=22:50:B7:8B:9A:FD nodemac=BE:6E:A5:D1:94:19   
