{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:29.637Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.197.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:29.637Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.224.255:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:29.637Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:33.776Z",
  "value": "id=1332  sec_id=4008885 flags=0x0000 ifindex=12  mac=22:50:B7:8B:9A:FD nodemac=BE:6E:A5:D1:94:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:33.812Z",
  "value": "id=916   sec_id=4     flags=0x0000 ifindex=10  mac=06:11:CB:BB:50:43 nodemac=92:2B:13:BB:B5:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:33.863Z",
  "value": "id=3740  sec_id=4008885 flags=0x0000 ifindex=14  mac=72:67:BB:1D:08:42 nodemac=0E:70:92:0A:57:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:33.911Z",
  "value": "id=1332  sec_id=4008885 flags=0x0000 ifindex=12  mac=22:50:B7:8B:9A:FD nodemac=BE:6E:A5:D1:94:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:33.970Z",
  "value": "id=916   sec_id=4     flags=0x0000 ifindex=10  mac=06:11:CB:BB:50:43 nodemac=92:2B:13:BB:B5:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:42.700Z",
  "value": "id=916   sec_id=4     flags=0x0000 ifindex=10  mac=06:11:CB:BB:50:43 nodemac=92:2B:13:BB:B5:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:42.700Z",
  "value": "id=1332  sec_id=4008885 flags=0x0000 ifindex=12  mac=22:50:B7:8B:9A:FD nodemac=BE:6E:A5:D1:94:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:42.701Z",
  "value": "id=3740  sec_id=4008885 flags=0x0000 ifindex=14  mac=72:67:BB:1D:08:42 nodemac=0E:70:92:0A:57:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:42.731Z",
  "value": "id=7     sec_id=4012598 flags=0x0000 ifindex=16  mac=66:10:0D:16:49:C8 nodemac=9E:0D:2B:FD:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:42.731Z",
  "value": "id=7     sec_id=4012598 flags=0x0000 ifindex=16  mac=66:10:0D:16:49:C8 nodemac=9E:0D:2B:FD:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:43.701Z",
  "value": "id=916   sec_id=4     flags=0x0000 ifindex=10  mac=06:11:CB:BB:50:43 nodemac=92:2B:13:BB:B5:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:43.701Z",
  "value": "id=3740  sec_id=4008885 flags=0x0000 ifindex=14  mac=72:67:BB:1D:08:42 nodemac=0E:70:92:0A:57:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:43.701Z",
  "value": "id=7     sec_id=4012598 flags=0x0000 ifindex=16  mac=66:10:0D:16:49:C8 nodemac=9E:0D:2B:FD:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:43.701Z",
  "value": "id=1332  sec_id=4008885 flags=0x0000 ifindex=12  mac=22:50:B7:8B:9A:FD nodemac=BE:6E:A5:D1:94:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:30.203Z",
  "value": "id=1876  sec_id=4012598 flags=0x0000 ifindex=18  mac=92:03:75:87:9A:D8 nodemac=DA:C4:3D:84:62:6E"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.121.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.529Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:21.368Z",
  "value": "id=1876  sec_id=4012598 flags=0x0000 ifindex=18  mac=92:03:75:87:9A:D8 nodemac=DA:C4:3D:84:62:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:21.368Z",
  "value": "id=916   sec_id=4     flags=0x0000 ifindex=10  mac=06:11:CB:BB:50:43 nodemac=92:2B:13:BB:B5:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:21.369Z",
  "value": "id=1332  sec_id=4008885 flags=0x0000 ifindex=12  mac=22:50:B7:8B:9A:FD nodemac=BE:6E:A5:D1:94:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:21.369Z",
  "value": "id=3740  sec_id=4008885 flags=0x0000 ifindex=14  mac=72:67:BB:1D:08:42 nodemac=0E:70:92:0A:57:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:22.368Z",
  "value": "id=916   sec_id=4     flags=0x0000 ifindex=10  mac=06:11:CB:BB:50:43 nodemac=92:2B:13:BB:B5:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:22.368Z",
  "value": "id=1332  sec_id=4008885 flags=0x0000 ifindex=12  mac=22:50:B7:8B:9A:FD nodemac=BE:6E:A5:D1:94:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:22.368Z",
  "value": "id=3740  sec_id=4008885 flags=0x0000 ifindex=14  mac=72:67:BB:1D:08:42 nodemac=0E:70:92:0A:57:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:22.370Z",
  "value": "id=1876  sec_id=4012598 flags=0x0000 ifindex=18  mac=92:03:75:87:9A:D8 nodemac=DA:C4:3D:84:62:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.368Z",
  "value": "id=1876  sec_id=4012598 flags=0x0000 ifindex=18  mac=92:03:75:87:9A:D8 nodemac=DA:C4:3D:84:62:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.368Z",
  "value": "id=1332  sec_id=4008885 flags=0x0000 ifindex=12  mac=22:50:B7:8B:9A:FD nodemac=BE:6E:A5:D1:94:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.368Z",
  "value": "id=916   sec_id=4     flags=0x0000 ifindex=10  mac=06:11:CB:BB:50:43 nodemac=92:2B:13:BB:B5:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.369Z",
  "value": "id=3740  sec_id=4008885 flags=0x0000 ifindex=14  mac=72:67:BB:1D:08:42 nodemac=0E:70:92:0A:57:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.368Z",
  "value": "id=1876  sec_id=4012598 flags=0x0000 ifindex=18  mac=92:03:75:87:9A:D8 nodemac=DA:C4:3D:84:62:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.369Z",
  "value": "id=916   sec_id=4     flags=0x0000 ifindex=10  mac=06:11:CB:BB:50:43 nodemac=92:2B:13:BB:B5:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.369Z",
  "value": "id=1332  sec_id=4008885 flags=0x0000 ifindex=12  mac=22:50:B7:8B:9A:FD nodemac=BE:6E:A5:D1:94:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.370Z",
  "value": "id=3740  sec_id=4008885 flags=0x0000 ifindex=14  mac=72:67:BB:1D:08:42 nodemac=0E:70:92:0A:57:77"
}

