xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 571
ens6(5) clsact/ingress cil_from_netdev-ens6 id 576
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 562
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 557
cilium_host(7) clsact/egress cil_from_host-cilium_host id 556
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 534
lxcba27b7dc30de(12) clsact/ingress cil_from_container-lxcba27b7dc30de id 524
lxcac3eb30737a4(14) clsact/ingress cil_from_container-lxcac3eb30737a4 id 508
lxc4245c2bb08bb(18) clsact/ingress cil_from_container-lxc4245c2bb08bb id 621

flow_dissector:

netfilter:

