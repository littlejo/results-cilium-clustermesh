alloc: 187.55MB (196655960 bytes)
total-alloc: 2.37GB (2545672528 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 65409217
frees: 63392087
heap-alloc: 187.55MB (196655960 bytes)
heap-sys: 247.38MB (259399680 bytes)
heap-idle: 35.36MB (37076992 bytes)
heap-in-use: 212.02MB (222322688 bytes)
heap-released: 3.00MB (3145728 bytes)
heap-objects: 2017130
stack-in-use: 64.59MB (67731456 bytes)
stack-sys: 64.59MB (67731456 bytes)
stack-mspan-inuse: 3.40MB (3560480 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 988.76KB (1012489 bytes)
gc-sys: 6.02MB (6315616 bytes)
next-gc: when heap-alloc >= 238.62MB (250205976 bytes)
last-gc: 2024-10-30 08:22:49.284433129 +0000 UTC
gc-pause-total: 8.286248ms
gc-pause: 619218
gc-pause-end: 1730276569284433129
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.00041330659903441073
enable-gc: true
debug-gc: false
