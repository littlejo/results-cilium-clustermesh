CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb43bc7c5_ad0c_4d38_ac62_2bcb231479cc.slice/cri-containerd-479714342350fee023f7bafb8a0ed5b901a3b6bf860f2d0cea9597be9b8714f8.scope
    517      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb43bc7c5_ad0c_4d38_ac62_2bcb231479cc.slice/cri-containerd-0a7d26c1fd697e5f62707e615f520243ce4d8e75bdabe59a5e88ab7dc81e9ae1.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9069e7a_3b8c_4a1d_9bb4_302a7e81a902.slice/cri-containerd-d7d87a0e5e8da0e1f2e871b7736885a5d1486f7fcd1d98cbd3d024f2329f8fa8.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9069e7a_3b8c_4a1d_9bb4_302a7e81a902.slice/cri-containerd-744d3644ac7f77ce16072bf406366f51d0e591cd417878f167168a4af592f132.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddb834ac9_5f15_420c_b229_4b0b1549871a.slice/cri-containerd-5317a9e968ef3ef0fe5f56075caf71989e99d246eef8de287f572317e2111fb5.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddb834ac9_5f15_420c_b229_4b0b1549871a.slice/cri-containerd-b480ab1e4143e13f17abbe68799432e64a4ee0dc811afcde61d059f44314b6af.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc7a2f43_d9e2_49ce_a41f_2e70ec4bafb5.slice/cri-containerd-523743cdef5801525802b4d8397b7327428431f80187eaf8335cd7e71242570f.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc7a2f43_d9e2_49ce_a41f_2e70ec4bafb5.slice/cri-containerd-2f6c37e65e182eea4d4da6562524b3984dd8a321809386f8eef99f850d24bf17.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f551a3a_08b0_4264_a2c2_5ed9bd862dc0.slice/cri-containerd-615b7fce83ca2de0caba09915ea405462f9a511d11150905290d4c8af1197832.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f551a3a_08b0_4264_a2c2_5ed9bd862dc0.slice/cri-containerd-02a6d493cfca5bbbddcfe8b69f48aa8efe6c9e2049461c175aec21169d09d74d.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ce4c905_5467_4bcb_970a_d2c822fcae1a.slice/cri-containerd-b4981158b14f6e749fdf5c85ba28927cd5469441897cdb865f5beb045d93ea5e.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ce4c905_5467_4bcb_970a_d2c822fcae1a.slice/cri-containerd-fb509d349dcb6c7490c33bb34a601ba944fa290b261303d8901b2797580fe555.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ce4c905_5467_4bcb_970a_d2c822fcae1a.slice/cri-containerd-4d057a43301ef45892e1c89b42a508081d2d98bfd36046ba691df1bc1654bb6c.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ce4c905_5467_4bcb_970a_d2c822fcae1a.slice/cri-containerd-d11d96d516a2b1874ed3201faf585666f0678024284bbad9e27d8982b59cd7c0.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod543f4e70_2987_42da_8fb1_c511b2a8962a.slice/cri-containerd-58825e1ea3682ce183c6d95459130cad7881fd4c4ecd71e1bca2992020f76db5.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod543f4e70_2987_42da_8fb1_c511b2a8962a.slice/cri-containerd-69f73a13e886dd191b5aee8028f2dd248e9a120cb81896b17da1cbb02797cb7f.scope
    99       cgroup_device   multi                                          
