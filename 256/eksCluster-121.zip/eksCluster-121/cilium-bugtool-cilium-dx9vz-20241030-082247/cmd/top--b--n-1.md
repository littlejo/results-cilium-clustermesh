top - 08:22:49 up 34 min,  0 users,  load average: 0.21, 0.18, 0.17
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 58.1 us, 19.4 sy,  0.0 ni, 19.4 id,  0.0 wa,  0.0 hi,  3.2 si,  0.0 st
MiB Mem :   7814.2 total,   4478.0 free,   1189.5 used,   2146.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6439.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 383156  77956 S  93.3   4.8   0:48.98 cilium-+
    623 root      20   0 1240432  16692  11548 S   6.7   0.2   0:00.03 cilium-+
    393 root      20   0 1229744   8224   3836 S   0.0   0.1   0:01.08 cilium-+
    629 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    637 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    666 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    672 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
    696 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    715 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
