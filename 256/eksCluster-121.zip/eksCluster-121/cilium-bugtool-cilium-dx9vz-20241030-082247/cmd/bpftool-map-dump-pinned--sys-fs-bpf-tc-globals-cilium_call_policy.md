key: 94 03 00 00  value: 1a 02 00 00
key: 34 05 00 00  value: 11 02 00 00
key: 54 07 00 00  value: 76 02 00 00
key: 9c 0e 00 00  value: fd 01 00 00
Found 4 elements
