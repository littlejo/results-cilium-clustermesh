Endpoint ID: 916
Path: /sys/fs/bpf/tc/globals/cilium_policy_00916

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1640746   20753     0        
Allow    Ingress     1          ANY          NONE         disabled    23690     278       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1332
Path: /sys/fs/bpf/tc/globals/cilium_policy_01332

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    160541   1840      0        
Allow    Egress      0          ANY          NONE         disabled    19943    221       0        


Endpoint ID: 1876
Path: /sys/fs/bpf/tc/globals/cilium_policy_01876

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11448569   115684    0        
Allow    Ingress     1          ANY          NONE         disabled    10995050   116094    0        
Allow    Egress      0          ANY          NONE         disabled    15144627   147642    0        


Endpoint ID: 3071
Path: /sys/fs/bpf/tc/globals/cilium_policy_03071

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3740
Path: /sys/fs/bpf/tc/globals/cilium_policy_03740

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    159961   1833      0        
Allow    Egress      0          ANY          NONE         disabled    20521    229       0        


