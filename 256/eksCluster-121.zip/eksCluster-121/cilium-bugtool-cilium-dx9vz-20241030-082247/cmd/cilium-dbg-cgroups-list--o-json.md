[
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ce4c905_5467_4bcb_970a_d2c822fcae1a.slice/cri-containerd-4d057a43301ef45892e1c89b42a508081d2d98bfd36046ba691df1bc1654bb6c.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ce4c905_5467_4bcb_970a_d2c822fcae1a.slice/cri-containerd-fb509d349dcb6c7490c33bb34a601ba944fa290b261303d8901b2797580fe555.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ce4c905_5467_4bcb_970a_d2c822fcae1a.slice/cri-containerd-b4981158b14f6e749fdf5c85ba28927cd5469441897cdb865f5beb045d93ea5e.scope"
      }
    ],
    "ips": [
      "10.121.0.166"
    ],
    "name": "clustermesh-apiserver-67475dffb-6nlfp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7746,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb43bc7c5_ad0c_4d38_ac62_2bcb231479cc.slice/cri-containerd-0a7d26c1fd697e5f62707e615f520243ce4d8e75bdabe59a5e88ab7dc81e9ae1.scope"
      }
    ],
    "ips": [
      "10.121.0.233"
    ],
    "name": "coredns-cc6ccd49c-5g4df",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7830,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddb834ac9_5f15_420c_b229_4b0b1549871a.slice/cri-containerd-5317a9e968ef3ef0fe5f56075caf71989e99d246eef8de287f572317e2111fb5.scope"
      }
    ],
    "ips": [
      "10.121.0.218"
    ],
    "name": "coredns-cc6ccd49c-gslw8",
    "namespace": "kube-system"
  }
]

