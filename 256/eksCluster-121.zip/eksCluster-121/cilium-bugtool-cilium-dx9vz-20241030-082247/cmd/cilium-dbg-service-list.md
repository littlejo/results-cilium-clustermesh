ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.184.136:443 (active)   
                                         2 => 172.31.198.94:443 (active)    
2    10.100.129.215:443   ClusterIP      1 => 172.31.197.64:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.121.0.233:9153 (active)    
                                         2 => 10.121.0.218:9153 (active)    
4    10.100.0.10:53       ClusterIP      1 => 10.121.0.233:53 (active)      
                                         2 => 10.121.0.218:53 (active)      
5    10.100.14.72:2379    ClusterIP      1 => 10.121.0.166:2379 (active)    
