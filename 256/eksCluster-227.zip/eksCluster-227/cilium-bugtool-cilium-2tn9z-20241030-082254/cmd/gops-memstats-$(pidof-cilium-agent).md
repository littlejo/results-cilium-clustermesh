alloc: 126.64MB (132795264 bytes)
total-alloc: 2.29GB (2461174888 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 63691223
frees: 62856121
heap-alloc: 126.64MB (132795264 bytes)
heap-sys: 249.55MB (261668864 bytes)
heap-idle: 58.90MB (61759488 bytes)
heap-in-use: 190.65MB (199909376 bytes)
heap-released: 480.00KB (491520 bytes)
heap-objects: 835102
stack-in-use: 66.41MB (69632000 bytes)
stack-sys: 66.41MB (69632000 bytes)
stack-mspan-inuse: 3.00MB (3141440 bytes)
stack-mspan-sys: 3.94MB (4128960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.11MB (1168641 bytes)
gc-sys: 6.02MB (6317520 bytes)
next-gc: when heap-alloc >= 217.55MB (228116296 bytes)
last-gc: 2024-10-30 08:23:18.150401611 +0000 UTC
gc-pause-total: 17.347999ms
gc-pause: 168217
gc-pause-end: 1730276598150401611
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0006449472025177032
enable-gc: true
debug-gc: false
