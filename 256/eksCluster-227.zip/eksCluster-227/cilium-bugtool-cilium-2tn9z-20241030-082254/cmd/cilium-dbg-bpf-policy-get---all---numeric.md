Endpoint ID: 143
Path: /sys/fs/bpf/tc/globals/cilium_policy_00143

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11489093   112463    0        
Allow    Ingress     1          ANY          NONE         disabled    10196950   103659    0        
Allow    Egress      0          ANY          NONE         disabled    10610839   105880    0        


Endpoint ID: 1051
Path: /sys/fs/bpf/tc/globals/cilium_policy_01051

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1405
Path: /sys/fs/bpf/tc/globals/cilium_policy_01405

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112945   1293      0        
Allow    Egress      0          ANY          NONE         disabled    16014    174       0        


Endpoint ID: 2580
Path: /sys/fs/bpf/tc/globals/cilium_policy_02580

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    114397   1315      0        
Allow    Egress      0          ANY          NONE         disabled    17111    185       0        


Endpoint ID: 3057
Path: /sys/fs/bpf/tc/globals/cilium_policy_03057

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1662914   20991     0        
Allow    Ingress     1          ANY          NONE         disabled    18014     214       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


