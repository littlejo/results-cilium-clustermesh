{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:35.549Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.228.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:35.549Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.245.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:35.549Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:40.172Z",
  "value": "id=1405  sec_id=7479532 flags=0x0000 ifindex=12  mac=02:D2:35:05:B5:37 nodemac=76:49:0F:09:38:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:40.173Z",
  "value": "id=3057  sec_id=4     flags=0x0000 ifindex=10  mac=52:98:EB:5E:B7:37 nodemac=6E:D7:5E:C5:48:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:40.248Z",
  "value": "id=2580  sec_id=7479532 flags=0x0000 ifindex=14  mac=72:C7:66:91:40:BC nodemac=56:5E:62:BF:20:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:40.273Z",
  "value": "id=3057  sec_id=4     flags=0x0000 ifindex=10  mac=52:98:EB:5E:B7:37 nodemac=6E:D7:5E:C5:48:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:29.270Z",
  "value": "id=3057  sec_id=4     flags=0x0000 ifindex=10  mac=52:98:EB:5E:B7:37 nodemac=6E:D7:5E:C5:48:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:29.272Z",
  "value": "id=1405  sec_id=7479532 flags=0x0000 ifindex=12  mac=02:D2:35:05:B5:37 nodemac=76:49:0F:09:38:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:29.272Z",
  "value": "id=2580  sec_id=7479532 flags=0x0000 ifindex=14  mac=72:C7:66:91:40:BC nodemac=56:5E:62:BF:20:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:29.299Z",
  "value": "id=934   sec_id=7491316 flags=0x0000 ifindex=16  mac=EA:57:3F:10:5B:97 nodemac=6A:67:BF:75:A7:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:29.299Z",
  "value": "id=934   sec_id=7491316 flags=0x0000 ifindex=16  mac=EA:57:3F:10:5B:97 nodemac=6A:67:BF:75:A7:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:30.269Z",
  "value": "id=3057  sec_id=4     flags=0x0000 ifindex=10  mac=52:98:EB:5E:B7:37 nodemac=6E:D7:5E:C5:48:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:30.269Z",
  "value": "id=2580  sec_id=7479532 flags=0x0000 ifindex=14  mac=72:C7:66:91:40:BC nodemac=56:5E:62:BF:20:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:30.269Z",
  "value": "id=934   sec_id=7491316 flags=0x0000 ifindex=16  mac=EA:57:3F:10:5B:97 nodemac=6A:67:BF:75:A7:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:30.269Z",
  "value": "id=1405  sec_id=7479532 flags=0x0000 ifindex=12  mac=02:D2:35:05:B5:37 nodemac=76:49:0F:09:38:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.855Z",
  "value": "id=143   sec_id=7491316 flags=0x0000 ifindex=18  mac=3E:FE:4D:D3:03:E8 nodemac=4A:9C:1E:67:04:94"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.227.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.821Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.796Z",
  "value": "id=3057  sec_id=4     flags=0x0000 ifindex=10  mac=52:98:EB:5E:B7:37 nodemac=6E:D7:5E:C5:48:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.798Z",
  "value": "id=1405  sec_id=7479532 flags=0x0000 ifindex=12  mac=02:D2:35:05:B5:37 nodemac=76:49:0F:09:38:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.798Z",
  "value": "id=2580  sec_id=7479532 flags=0x0000 ifindex=14  mac=72:C7:66:91:40:BC nodemac=56:5E:62:BF:20:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.799Z",
  "value": "id=143   sec_id=7491316 flags=0x0000 ifindex=18  mac=3E:FE:4D:D3:03:E8 nodemac=4A:9C:1E:67:04:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.795Z",
  "value": "id=143   sec_id=7491316 flags=0x0000 ifindex=18  mac=3E:FE:4D:D3:03:E8 nodemac=4A:9C:1E:67:04:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.796Z",
  "value": "id=3057  sec_id=4     flags=0x0000 ifindex=10  mac=52:98:EB:5E:B7:37 nodemac=6E:D7:5E:C5:48:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.797Z",
  "value": "id=1405  sec_id=7479532 flags=0x0000 ifindex=12  mac=02:D2:35:05:B5:37 nodemac=76:49:0F:09:38:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.797Z",
  "value": "id=2580  sec_id=7479532 flags=0x0000 ifindex=14  mac=72:C7:66:91:40:BC nodemac=56:5E:62:BF:20:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.795Z",
  "value": "id=1405  sec_id=7479532 flags=0x0000 ifindex=12  mac=02:D2:35:05:B5:37 nodemac=76:49:0F:09:38:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.795Z",
  "value": "id=2580  sec_id=7479532 flags=0x0000 ifindex=14  mac=72:C7:66:91:40:BC nodemac=56:5E:62:BF:20:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.796Z",
  "value": "id=143   sec_id=7491316 flags=0x0000 ifindex=18  mac=3E:FE:4D:D3:03:E8 nodemac=4A:9C:1E:67:04:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.799Z",
  "value": "id=3057  sec_id=4     flags=0x0000 ifindex=10  mac=52:98:EB:5E:B7:37 nodemac=6E:D7:5E:C5:48:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.795Z",
  "value": "id=143   sec_id=7491316 flags=0x0000 ifindex=18  mac=3E:FE:4D:D3:03:E8 nodemac=4A:9C:1E:67:04:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.795Z",
  "value": "id=1405  sec_id=7479532 flags=0x0000 ifindex=12  mac=02:D2:35:05:B5:37 nodemac=76:49:0F:09:38:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.795Z",
  "value": "id=3057  sec_id=4     flags=0x0000 ifindex=10  mac=52:98:EB:5E:B7:37 nodemac=6E:D7:5E:C5:48:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.796Z",
  "value": "id=2580  sec_id=7479532 flags=0x0000 ifindex=14  mac=72:C7:66:91:40:BC nodemac=56:5E:62:BF:20:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:50.796Z",
  "value": "id=3057  sec_id=4     flags=0x0000 ifindex=10  mac=52:98:EB:5E:B7:37 nodemac=6E:D7:5E:C5:48:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:50.796Z",
  "value": "id=143   sec_id=7491316 flags=0x0000 ifindex=18  mac=3E:FE:4D:D3:03:E8 nodemac=4A:9C:1E:67:04:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:50.796Z",
  "value": "id=1405  sec_id=7479532 flags=0x0000 ifindex=12  mac=02:D2:35:05:B5:37 nodemac=76:49:0F:09:38:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.227.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:50.796Z",
  "value": "id=2580  sec_id=7479532 flags=0x0000 ifindex=14  mac=72:C7:66:91:40:BC nodemac=56:5E:62:BF:20:78"
}

