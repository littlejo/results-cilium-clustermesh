key: 8f 00 00 00  value: 7e 02 00 00
key: 7d 05 00 00  value: 0c 02 00 00
key: 14 0a 00 00  value: 36 02 00 00
key: f1 0b 00 00  value: 40 02 00 00
Found 4 elements
