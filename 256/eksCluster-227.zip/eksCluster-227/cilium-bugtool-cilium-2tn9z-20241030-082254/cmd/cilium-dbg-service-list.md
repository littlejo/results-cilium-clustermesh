ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.188.236:443 (active)    
                                          2 => 172.31.231.121:443 (active)    
2    10.100.251.8:443      ClusterIP      1 => 172.31.245.124:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.227.0.231:9153 (active)     
                                          2 => 10.227.0.175:9153 (active)     
4    10.100.0.10:53        ClusterIP      1 => 10.227.0.231:53 (active)       
                                          2 => 10.227.0.175:53 (active)       
5    10.100.171.144:2379   ClusterIP      1 => 10.227.0.197:2379 (active)     
