top - 08:22:55 up 28 min,  0 users,  load average: 0.44, 0.32, 0.24
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 13.3 us, 30.0 sy,  0.0 ni, 56.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4466.8 free,   1200.3 used,   2147.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6428.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 397212  77948 S   6.7   5.0   0:55.73 cilium-+
    652 root      20   0 1240432  15492  10704 S   6.7   0.2   0:00.03 cilium-+
    393 root      20   0 1229488   8108   3900 S   0.0   0.1   0:01.22 cilium-+
    609 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    625 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    626 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    645 root      20   0 1229000   3776   3104 S   0.0   0.0   0:00.00 gops
    651 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
    690 root      20   0    6576   2416   2092 R   0.0   0.0   0:00.00 top
    709 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
