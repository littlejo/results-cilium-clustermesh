[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf9047e06_800f_48bd_827c_dafd8b21f8a7.slice/cri-containerd-e0cf1243e7bf20dde3a411f6e69eb5162f34941a27204a6a767b5ae13641e3bf.scope"
      }
    ],
    "ips": [
      "10.227.0.175"
    ],
    "name": "coredns-cc6ccd49c-lb6xr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f9775cd_1c8b_4bd5_98ee_7974e952e87f.slice/cri-containerd-7bf783091be12a56429318ad5f424d4c9a9c2220a6f08bdc9abde74874b6d104.scope"
      }
    ],
    "ips": [
      "10.227.0.231"
    ],
    "name": "coredns-cc6ccd49c-dccd8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0892c14_2223_4592_ab11_045709fccd60.slice/cri-containerd-433cf9e258be1757a075197c332355258068fbe7138c82544e694bdbb12fad0e.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0892c14_2223_4592_ab11_045709fccd60.slice/cri-containerd-aee24c9fa6e466e68fbeaa59bc358a643498c41d28d9f4f58c2d6270072c55e6.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0892c14_2223_4592_ab11_045709fccd60.slice/cri-containerd-83dfccfdd97ac48a0b8ca9e3b2f56f2a0c865b78286a6f072540e6472d57a409.scope"
      }
    ],
    "ips": [
      "10.227.0.197"
    ],
    "name": "clustermesh-apiserver-5f56bbb986-jxcmd",
    "namespace": "kube-system"
  }
]

