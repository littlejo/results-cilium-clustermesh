IP ADDRESS         LOCAL ENDPOINT INFO
10.227.0.231:0     id=2580  sec_id=7479532 flags=0x0000 ifindex=14  mac=72:C7:66:91:40:BC nodemac=56:5E:62:BF:20:78   
10.227.0.175:0     id=1405  sec_id=7479532 flags=0x0000 ifindex=12  mac=02:D2:35:05:B5:37 nodemac=76:49:0F:09:38:55   
172.31.228.62:0    (localhost)                                                                                        
10.227.0.57:0      (localhost)                                                                                        
10.227.0.103:0     id=3057  sec_id=4     flags=0x0000 ifindex=10  mac=52:98:EB:5E:B7:37 nodemac=6E:D7:5E:C5:48:FF     
10.227.0.197:0     id=143   sec_id=7491316 flags=0x0000 ifindex=18  mac=3E:FE:4D:D3:03:E8 nodemac=4A:9C:1E:67:04:94   
172.31.245.124:0   (localhost)                                                                                        
