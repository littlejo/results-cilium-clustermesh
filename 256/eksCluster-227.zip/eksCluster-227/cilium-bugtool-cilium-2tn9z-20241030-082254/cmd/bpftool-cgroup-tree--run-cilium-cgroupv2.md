CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod73b4506e_2e7b_4014_a9c8_12facd334620.slice/cri-containerd-c93a61aacbd39984d024702583d3611c4907dccffbfdd4cb78aa5424c7a27270.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod73b4506e_2e7b_4014_a9c8_12facd334620.slice/cri-containerd-b558b1cff61e76666076b16200c716aa0e286b7c8b4610285ea0f7e81cc5bd82.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f9775cd_1c8b_4bd5_98ee_7974e952e87f.slice/cri-containerd-7bf783091be12a56429318ad5f424d4c9a9c2220a6f08bdc9abde74874b6d104.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f9775cd_1c8b_4bd5_98ee_7974e952e87f.slice/cri-containerd-d6c2a23ae73c79fe08a3ee590b492c1ec86d427061a59b22599051101a09f0a7.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf9047e06_800f_48bd_827c_dafd8b21f8a7.slice/cri-containerd-e0cf1243e7bf20dde3a411f6e69eb5162f34941a27204a6a767b5ae13641e3bf.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf9047e06_800f_48bd_827c_dafd8b21f8a7.slice/cri-containerd-415ff7c725097e8db731710744609bffb5fd5c2c0f14bd981db0f1f0e68c9eff.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a66f1c8_de2a_4301_895f_48c21bfa616b.slice/cri-containerd-7265f44f890b0d2fc1f00464aef4f1a84de827e2232f6816ad05ccd2d7cc3c0e.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a66f1c8_de2a_4301_895f_48c21bfa616b.slice/cri-containerd-82651a6049b94e1e24eac52fd362d5648f4b1a25112980a904b9e4fe2f148110.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0892c14_2223_4592_ab11_045709fccd60.slice/cri-containerd-83dfccfdd97ac48a0b8ca9e3b2f56f2a0c865b78286a6f072540e6472d57a409.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0892c14_2223_4592_ab11_045709fccd60.slice/cri-containerd-71147dc7ca9315023599ae0774aea9f3dc9337442e9b91077442571719522dd8.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0892c14_2223_4592_ab11_045709fccd60.slice/cri-containerd-aee24c9fa6e466e68fbeaa59bc358a643498c41d28d9f4f58c2d6270072c55e6.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0892c14_2223_4592_ab11_045709fccd60.slice/cri-containerd-433cf9e258be1757a075197c332355258068fbe7138c82544e694bdbb12fad0e.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod79ff6427_8c72_492e_bc95_bc1a21411003.slice/cri-containerd-a830592729f449fcb128ba7edb62f3c79ca05c04e0f1c4bfd58a7b0b7e176f9c.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod79ff6427_8c72_492e_bc95_bc1a21411003.slice/cri-containerd-48cc10fd7f1b6b9a5bfa25fba5d403593ba2f5ba675884ad0285af5faf58fa26.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfef7811b_9725_4720_acd4_472921fd6930.slice/cri-containerd-4a4e427a2f6732443fa1a1253b39446dc38f9b553e783502f25ee7163db4fdfe.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfef7811b_9725_4720_acd4_472921fd6930.slice/cri-containerd-90af0c89744cbcef7517fb43e2c8f48aee3bf02f1a066639c758c8e44050c497.scope
    103      cgroup_device   multi                                          
