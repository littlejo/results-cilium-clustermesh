KEY             VALUE
AgentLiveness   1717110116652
UTimeOffset     3379443144531250
