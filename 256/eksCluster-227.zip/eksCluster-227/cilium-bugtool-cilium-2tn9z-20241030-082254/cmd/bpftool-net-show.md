xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 555
ens6(5) clsact/ingress cil_from_netdev-ens6 id 560
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 548
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 536
cilium_host(7) clsact/egress cil_from_host-cilium_host id 534
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 478
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 567
lxc4fdd37f84a1a(12) clsact/ingress cil_from_container-lxc4fdd37f84a1a id 513
lxcf3147761aad3(14) clsact/ingress cil_from_container-lxcf3147761aad3 id 544
lxc83288217bea8(18) clsact/ingress cil_from_container-lxc83288217bea8 id 643

flow_dissector:

netfilter:

