1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:20:b9:ce:18:8d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.245.124/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1925sec preferred_lft 1925sec
    inet6 fe80::820:b9ff:fece:188d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:e2:ec:9d:f7:3b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.228.62/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8e2:ecff:fe9d:f73b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:4c:f0:7c:84:8a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c84c:f0ff:fe7c:848a/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:a9:bf:3c:c4:66 brd ff:ff:ff:ff:ff:ff
    inet 10.227.0.57/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a4a9:bfff:fe3c:c466/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether d2:7d:fa:2b:11:ea brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d07d:faff:fe2b:11ea/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:d7:5e:c5:48:ff brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::6cd7:5eff:fec5:48ff/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc4fdd37f84a1a@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:49:0f:09:38:55 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::7449:fff:fe09:3855/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcf3147761aad3@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:5e:62:bf:20:78 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::545e:62ff:febf:2078/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc83288217bea8@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:9c:1e:67:04:94 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::489c:1eff:fe67:494/64 scope link 
       valid_lft forever preferred_lft forever
