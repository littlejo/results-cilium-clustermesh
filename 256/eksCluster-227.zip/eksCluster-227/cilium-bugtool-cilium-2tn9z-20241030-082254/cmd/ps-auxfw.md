USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         652  2.0  0.1 1240432 15492 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         679  0.0  0.0   6408  1648 ?        R    08:22   0:00  \_ ps auxfw
root         680  0.0  0.0   3852  1292 ?        R    08:22   0:00  \_ bash -c hostname
root         651  0.0  0.0 1228744 3776 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         645  0.0  0.0 1229000 3776 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         626  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         625  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         609  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  4.7  4.9 1606336 397212 ?      Ssl  08:03   0:55 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.1  0.1 1229488 8108 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
