KEY             VALUE
AgentLiveness   2175649549472
UTimeOffset     3379442234375000
