 08:22:49 up 35 min,  0 users,  load average: 0.22, 0.23, 0.15
