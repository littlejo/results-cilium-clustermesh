xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 558
ens6(5) clsact/ingress cil_from_netdev-ens6 id 559
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 543
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 538
cilium_host(7) clsact/egress cil_from_host-cilium_host id 537
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 578
lxc37214699a57c(12) clsact/ingress cil_from_container-lxc37214699a57c id 519
lxc6b8c1c85e715(14) clsact/ingress cil_from_container-lxc6b8c1c85e715 id 547
lxcb202f26e291f(18) clsact/ingress cil_from_container-lxcb202f26e291f id 647

flow_dissector:

netfilter:

