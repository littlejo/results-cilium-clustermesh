REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36334     2880559     677    bpf_overlay.c
Interface                 INGRESS     655544    134097209   1132   bpf_host.c
Success                   EGRESS      16433     1294790     1694   bpf_host.c
Success                   EGRESS      277031    34452319    1308   bpf_lxc.c
Success                   EGRESS      36725     2906515     53     encap.h
Success                   INGRESS     321962    36253010    86     l3.h
Success                   INGRESS     342514    37882825    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
