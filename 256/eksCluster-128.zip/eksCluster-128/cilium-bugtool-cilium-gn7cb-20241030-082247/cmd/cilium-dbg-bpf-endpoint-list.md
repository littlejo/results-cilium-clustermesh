IP ADDRESS        LOCAL ENDPOINT INFO
10.128.0.176:0    id=155   sec_id=4235647 flags=0x0000 ifindex=14  mac=42:23:4C:98:99:B2 nodemac=CA:F1:82:10:D4:81   
172.31.162.15:0   (localhost)                                                                                        
10.128.0.101:0    (localhost)                                                                                        
10.128.0.87:0     id=1025  sec_id=4255461 flags=0x0000 ifindex=18  mac=9A:2B:63:53:F9:3C nodemac=5A:76:79:7C:98:8C   
10.128.0.144:0    id=589   sec_id=4235647 flags=0x0000 ifindex=12  mac=7E:A6:D4:8E:43:21 nodemac=46:5F:A4:F5:57:2E   
172.31.189.76:0   (localhost)                                                                                        
10.128.0.245:0    id=624   sec_id=4     flags=0x0000 ifindex=10  mac=86:81:B7:54:58:ED nodemac=3E:8D:94:30:EF:C6     
