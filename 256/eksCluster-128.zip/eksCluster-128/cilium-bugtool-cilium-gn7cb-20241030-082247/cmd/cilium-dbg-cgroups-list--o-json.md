[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod27b2763b_a6ef_4e76_8686_f277d218f1cf.slice/cri-containerd-07e8943484330180256818fcfeaa2538fad5f1a9bd27a632f480faf21e2627e3.scope"
      }
    ],
    "ips": [
      "10.128.0.144"
    ],
    "name": "coredns-cc6ccd49c-xg2mf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod12aa97b2_4fe7_4516_9c28_80bf9fe783a2.slice/cri-containerd-3758f67c7940146650cd3bc9bd37768132dc9591403b7784174790bcbdcdcb09.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod12aa97b2_4fe7_4516_9c28_80bf9fe783a2.slice/cri-containerd-3b4df833ae5de4cc450b330ad962348fb60f1dff0432fce33ae04c9e731c1a7f.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod12aa97b2_4fe7_4516_9c28_80bf9fe783a2.slice/cri-containerd-7794b4a31a9163935ccbe4550590ae170365a1940194c9a89b4b857eeeb6ffbd.scope"
      }
    ],
    "ips": [
      "10.128.0.87"
    ],
    "name": "clustermesh-apiserver-7f69d7b85c-zhdp2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7345c075_86a5_459e_88b7_fbb6126aec72.slice/cri-containerd-6414b74f6f571c4bbc307a932cc79ee2087bd9b09eb15ac049ad7c7775fc01af.scope"
      }
    ],
    "ips": [
      "10.128.0.176"
    ],
    "name": "coredns-cc6ccd49c-96q5l",
    "namespace": "kube-system"
  }
]

