key: 9b 00 00 00  value: 39 02 00 00
key: 4d 02 00 00  value: 06 02 00 00
key: 70 02 00 00  value: 44 02 00 00
key: 01 04 00 00  value: 83 02 00 00
Found 4 elements
