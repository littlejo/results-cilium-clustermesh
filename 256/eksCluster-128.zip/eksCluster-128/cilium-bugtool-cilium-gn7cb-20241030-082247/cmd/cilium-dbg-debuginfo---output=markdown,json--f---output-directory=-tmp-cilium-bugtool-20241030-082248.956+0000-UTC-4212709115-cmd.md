markdown output at /tmp/cilium-bugtool-20241030-082248.956+0000-UTC-4212709115/cmd/cilium-debuginfo-20241030-082319.81+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082248.956+0000-UTC-4212709115/cmd/cilium-debuginfo-20241030-082319.81+0000-UTC.json
