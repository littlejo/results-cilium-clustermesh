1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:4c:75:53:7c:8b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.189.76/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3264sec preferred_lft 3264sec
    inet6 fe80::44c:75ff:fe53:7c8b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:b4:67:98:18:cd brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.162.15/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4b4:67ff:fe98:18cd/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:bc:7f:12:30:e5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4cbc:7fff:fe12:30e5/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:56:29:24:81:b9 brd ff:ff:ff:ff:ff:ff
    inet 10.128.0.101/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::1856:29ff:fe24:81b9/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 06:0d:4f:5e:82:7c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::40d:4fff:fe5e:827c/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:8d:94:30:ef:c6 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::3c8d:94ff:fe30:efc6/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc37214699a57c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:5f:a4:f5:57:2e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::445f:a4ff:fef5:572e/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc6b8c1c85e715@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:f1:82:10:d4:81 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c8f1:82ff:fe10:d481/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb202f26e291f@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:76:79:7c:98:8c brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::5876:79ff:fe7c:988c/64 scope link 
       valid_lft forever preferred_lft forever
