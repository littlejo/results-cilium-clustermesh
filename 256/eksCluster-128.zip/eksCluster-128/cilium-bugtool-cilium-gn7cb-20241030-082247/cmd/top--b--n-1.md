top - 08:22:49 up 35 min,  0 users,  load average: 0.22, 0.23, 0.15
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 51.7 us, 37.9 sy,  0.0 ni,  6.9 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   7814.2 total,   4477.8 free,   1190.3 used,   2146.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6438.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    701 root      20   0 1244596  22752  14332 S  40.0   0.3   0:00.06 hubble
      1 root      20   0 1606080 380148  77372 S   6.7   4.8   0:54.60 cilium-+
    643 root      20   0 1240432  15124  10576 S   6.7   0.2   0:00.03 cilium-+
    393 root      20   0 1229744   8016   3836 S   0.0   0.1   0:01.13 cilium-+
    610 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    622 root      20   0 1229000   3596   2912 S   0.0   0.0   0:00.00 gops
    649 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    668 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    690 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    697 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    724 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
