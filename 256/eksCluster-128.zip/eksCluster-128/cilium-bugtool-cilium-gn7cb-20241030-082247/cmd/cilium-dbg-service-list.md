ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.172.10:443 (active)    
                                         2 => 172.31.217.218:443 (active)   
2    10.100.222.235:443   ClusterIP      1 => 172.31.189.76:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.128.0.176:53 (active)      
                                         2 => 10.128.0.144:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.128.0.176:9153 (active)    
                                         2 => 10.128.0.144:9153 (active)    
5    10.100.119.20:2379   ClusterIP      1 => 10.128.0.87:2379 (active)     
