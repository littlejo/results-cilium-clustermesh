Endpoint ID: 155
Path: /sys/fs/bpf/tc/globals/cilium_policy_00155

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    170845   1962      0        
Allow    Egress      0          ANY          NONE         disabled    18476    206       0        


Endpoint ID: 589
Path: /sys/fs/bpf/tc/globals/cilium_policy_00589

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    171043   1965      0        
Allow    Egress      0          ANY          NONE         disabled    21184    237       0        


Endpoint ID: 624
Path: /sys/fs/bpf/tc/globals/cilium_policy_00624

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1631779   20579     0        
Allow    Ingress     1          ANY          NONE         disabled    24936     289       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1025
Path: /sys/fs/bpf/tc/globals/cilium_policy_01025

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11501710   115029    0        
Allow    Ingress     1          ANY          NONE         disabled    10532157   111218    0        
Allow    Egress      0          ANY          NONE         disabled    13382019   131441    0        


Endpoint ID: 1308
Path: /sys/fs/bpf/tc/globals/cilium_policy_01308

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


