{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:48.068Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.162.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:48.068Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.189.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:48.068Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.650Z",
  "value": "id=624   sec_id=4     flags=0x0000 ifindex=10  mac=86:81:B7:54:58:ED nodemac=3E:8D:94:30:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.662Z",
  "value": "id=589   sec_id=4235647 flags=0x0000 ifindex=12  mac=7E:A6:D4:8E:43:21 nodemac=46:5F:A4:F5:57:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.710Z",
  "value": "id=155   sec_id=4235647 flags=0x0000 ifindex=14  mac=42:23:4C:98:99:B2 nodemac=CA:F1:82:10:D4:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.734Z",
  "value": "id=624   sec_id=4     flags=0x0000 ifindex=10  mac=86:81:B7:54:58:ED nodemac=3E:8D:94:30:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:11.631Z",
  "value": "id=624   sec_id=4     flags=0x0000 ifindex=10  mac=86:81:B7:54:58:ED nodemac=3E:8D:94:30:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:11.632Z",
  "value": "id=589   sec_id=4235647 flags=0x0000 ifindex=12  mac=7E:A6:D4:8E:43:21 nodemac=46:5F:A4:F5:57:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:11.632Z",
  "value": "id=155   sec_id=4235647 flags=0x0000 ifindex=14  mac=42:23:4C:98:99:B2 nodemac=CA:F1:82:10:D4:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:11.661Z",
  "value": "id=1808  sec_id=4255461 flags=0x0000 ifindex=16  mac=1E:0F:1E:19:C4:03 nodemac=96:F5:5D:B7:B6:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:12.631Z",
  "value": "id=1808  sec_id=4255461 flags=0x0000 ifindex=16  mac=1E:0F:1E:19:C4:03 nodemac=96:F5:5D:B7:B6:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:12.631Z",
  "value": "id=589   sec_id=4235647 flags=0x0000 ifindex=12  mac=7E:A6:D4:8E:43:21 nodemac=46:5F:A4:F5:57:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:12.631Z",
  "value": "id=624   sec_id=4     flags=0x0000 ifindex=10  mac=86:81:B7:54:58:ED nodemac=3E:8D:94:30:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:12.631Z",
  "value": "id=155   sec_id=4235647 flags=0x0000 ifindex=14  mac=42:23:4C:98:99:B2 nodemac=CA:F1:82:10:D4:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:36.907Z",
  "value": "id=1025  sec_id=4255461 flags=0x0000 ifindex=18  mac=9A:2B:63:53:F9:3C nodemac=5A:76:79:7C:98:8C"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.128.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:47.221Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.420Z",
  "value": "id=589   sec_id=4235647 flags=0x0000 ifindex=12  mac=7E:A6:D4:8E:43:21 nodemac=46:5F:A4:F5:57:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.420Z",
  "value": "id=155   sec_id=4235647 flags=0x0000 ifindex=14  mac=42:23:4C:98:99:B2 nodemac=CA:F1:82:10:D4:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.421Z",
  "value": "id=1025  sec_id=4255461 flags=0x0000 ifindex=18  mac=9A:2B:63:53:F9:3C nodemac=5A:76:79:7C:98:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.421Z",
  "value": "id=624   sec_id=4     flags=0x0000 ifindex=10  mac=86:81:B7:54:58:ED nodemac=3E:8D:94:30:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.424Z",
  "value": "id=1025  sec_id=4255461 flags=0x0000 ifindex=18  mac=9A:2B:63:53:F9:3C nodemac=5A:76:79:7C:98:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.425Z",
  "value": "id=624   sec_id=4     flags=0x0000 ifindex=10  mac=86:81:B7:54:58:ED nodemac=3E:8D:94:30:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.426Z",
  "value": "id=589   sec_id=4235647 flags=0x0000 ifindex=12  mac=7E:A6:D4:8E:43:21 nodemac=46:5F:A4:F5:57:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.426Z",
  "value": "id=155   sec_id=4235647 flags=0x0000 ifindex=14  mac=42:23:4C:98:99:B2 nodemac=CA:F1:82:10:D4:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.425Z",
  "value": "id=624   sec_id=4     flags=0x0000 ifindex=10  mac=86:81:B7:54:58:ED nodemac=3E:8D:94:30:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.425Z",
  "value": "id=589   sec_id=4235647 flags=0x0000 ifindex=12  mac=7E:A6:D4:8E:43:21 nodemac=46:5F:A4:F5:57:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.426Z",
  "value": "id=155   sec_id=4235647 flags=0x0000 ifindex=14  mac=42:23:4C:98:99:B2 nodemac=CA:F1:82:10:D4:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.426Z",
  "value": "id=1025  sec_id=4255461 flags=0x0000 ifindex=18  mac=9A:2B:63:53:F9:3C nodemac=5A:76:79:7C:98:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.425Z",
  "value": "id=624   sec_id=4     flags=0x0000 ifindex=10  mac=86:81:B7:54:58:ED nodemac=3E:8D:94:30:EF:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.425Z",
  "value": "id=589   sec_id=4235647 flags=0x0000 ifindex=12  mac=7E:A6:D4:8E:43:21 nodemac=46:5F:A4:F5:57:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.426Z",
  "value": "id=155   sec_id=4235647 flags=0x0000 ifindex=14  mac=42:23:4C:98:99:B2 nodemac=CA:F1:82:10:D4:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.128.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.426Z",
  "value": "id=1025  sec_id=4255461 flags=0x0000 ifindex=18  mac=9A:2B:63:53:F9:3C nodemac=5A:76:79:7C:98:8C"
}

