USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         668  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         649  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         643  0.0  0.1 1240432 15124 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         680  0.0  0.0   6408  1640 ?        R    08:22   0:00  \_ ps auxfw
root         622  0.0  0.0 1229000 3596 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         610  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.1  4.7 1606080 380148 ?      Ssl  07:53   0:54 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.1 1229744 8016 ?        Sl   07:53   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
