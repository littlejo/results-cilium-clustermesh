CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7345c075_86a5_459e_88b7_fbb6126aec72.slice/cri-containerd-6414b74f6f571c4bbc307a932cc79ee2087bd9b09eb15ac049ad7c7775fc01af.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7345c075_86a5_459e_88b7_fbb6126aec72.slice/cri-containerd-b84c28c57e88e5b4f2fb75e524bc410ed95ebf984ae64779bfe48ad5f729111d.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod27b2763b_a6ef_4e76_8686_f277d218f1cf.slice/cri-containerd-07e8943484330180256818fcfeaa2538fad5f1a9bd27a632f480faf21e2627e3.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod27b2763b_a6ef_4e76_8686_f277d218f1cf.slice/cri-containerd-e897dcb46adef0d8e249427f3ab3151004e98572d64ea1ca19bfdf902cfc6eaa.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04e9a9a8_f502_4d71_a4cf_1feca7dc9c7a.slice/cri-containerd-8ed73ea2143588a516e66993c08f82781c2b3a5560c03d27810cdebb718d0ddb.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04e9a9a8_f502_4d71_a4cf_1feca7dc9c7a.slice/cri-containerd-0972d29399c364cdc238c85d6aa74351228ba3188514bb21bccca9503ea138b8.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod950ef574_8a3a_4416_bde1_7957c55b4a7f.slice/cri-containerd-9d65079cfdf9b0b92d2a814ec18cb7d3a3319c208334e28838f4387f83dbc09a.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod950ef574_8a3a_4416_bde1_7957c55b4a7f.slice/cri-containerd-66d6c790388abbaebcf6e8418b6f751fe2b87b7f96cbfaa34e8bace0fcb68faa.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e998cc8_63ae_4e4b_a17c_d54da3807732.slice/cri-containerd-56e02dc7aed01e5488de1582a6869fa63e68f84ab2dea8794a28369934af7cee.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e998cc8_63ae_4e4b_a17c_d54da3807732.slice/cri-containerd-a9728a22098213f17a9322a59707bc83ae375ff4acaffa2f9ddfa2dd3fba6bf7.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod045afc07_840e_4c28_895d_1e305b8591d2.slice/cri-containerd-a7c549c1f164104edf5aa49096303f46858ee3d4eca6b091142ed0b26a0c6dbc.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod045afc07_840e_4c28_895d_1e305b8591d2.slice/cri-containerd-11542a37c73dd376d2ed87d4f8d7b134b82c30ae9410068727d5a20b18037434.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod12aa97b2_4fe7_4516_9c28_80bf9fe783a2.slice/cri-containerd-7fcf68acbfd3a5ef658bada5d3e0606117b3da5709690bb493b0502870dc9691.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod12aa97b2_4fe7_4516_9c28_80bf9fe783a2.slice/cri-containerd-3b4df833ae5de4cc450b330ad962348fb60f1dff0432fce33ae04c9e731c1a7f.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod12aa97b2_4fe7_4516_9c28_80bf9fe783a2.slice/cri-containerd-7794b4a31a9163935ccbe4550590ae170365a1940194c9a89b4b857eeeb6ffbd.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod12aa97b2_4fe7_4516_9c28_80bf9fe783a2.slice/cri-containerd-3758f67c7940146650cd3bc9bd37768132dc9591403b7784174790bcbdcdcb09.scope
    671      cgroup_device   multi                                          
