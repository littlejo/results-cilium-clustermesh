alloc: 181.67MB (190497288 bytes)
total-alloc: 2.33GB (2505181248 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 64655204
frees: 62812628
heap-alloc: 181.67MB (190497288 bytes)
heap-sys: 247.48MB (259506176 bytes)
heap-idle: 36.66MB (38436864 bytes)
heap-in-use: 210.83MB (221069312 bytes)
heap-released: 3.59MB (3760128 bytes)
heap-objects: 1842576
stack-in-use: 64.47MB (67600384 bytes)
stack-sys: 64.47MB (67600384 bytes)
stack-mspan-inuse: 3.31MB (3468800 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 957.94KB (980929 bytes)
gc-sys: 6.05MB (6344264 bytes)
next-gc: when heap-alloc >= 218.47MB (229086600 bytes)
last-gc: 2024-10-30 08:22:52.499643095 +0000 UTC
gc-pause-total: 22.796507ms
gc-pause: 79581
gc-pause-end: 1730276572499643095
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0003880650693643789
enable-gc: true
debug-gc: false
