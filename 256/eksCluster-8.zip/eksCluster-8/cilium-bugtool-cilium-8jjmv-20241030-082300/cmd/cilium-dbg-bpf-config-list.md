KEY             VALUE
AgentLiveness   2221912998094
UTimeOffset     3379442169921875
