IP ADDRESS         LOCAL ENDPOINT INFO
10.8.0.201:0       id=854   sec_id=306943 flags=0x0000 ifindex=12  mac=C6:BE:F2:03:51:AF nodemac=BA:67:EB:E3:4B:0F   
10.8.0.22:0        id=53    sec_id=4     flags=0x0000 ifindex=10  mac=5E:B6:1C:C7:11:13 nodemac=1E:E3:7D:65:46:B3    
10.8.0.165:0       id=319   sec_id=306943 flags=0x0000 ifindex=14  mac=66:0E:FB:2A:F7:F2 nodemac=DA:11:EF:C8:BC:31   
10.8.0.241:0       (localhost)                                                                                       
172.31.179.121:0   (localhost)                                                                                       
10.8.0.253:0       id=719   sec_id=317044 flags=0x0000 ifindex=18  mac=36:F8:A1:F2:82:7C nodemac=3E:EA:99:62:CB:8A   
172.31.148.127:0   (localhost)                                                                                       
