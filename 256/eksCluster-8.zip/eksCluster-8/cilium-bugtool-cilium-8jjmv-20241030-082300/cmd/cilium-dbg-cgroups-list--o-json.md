[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca8df2e7_1c0b_466f_8e8b_285bee6b721e.slice/cri-containerd-b7267c86e826f30f47bf380cb51e8ec9ef6d29cc3a05e72e1d9630889fee87c2.scope"
      }
    ],
    "ips": [
      "10.8.0.165"
    ],
    "name": "coredns-cc6ccd49c-l8ttx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfd8b3028_503b_4898_bdca_8a02ec475458.slice/cri-containerd-d79b3f9bfadce170211d534581a9b1743b34af6a2d2b7d60b870681277b2d83e.scope"
      }
    ],
    "ips": [
      "10.8.0.201"
    ],
    "name": "coredns-cc6ccd49c-cqxwq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29f5eaff_86d1_4297_8ffc_c639e0e4d6c8.slice/cri-containerd-f2f9e81a3fe919ca9b7dea56208757abc5add306c2f6c423e9a24ebc92b86826.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29f5eaff_86d1_4297_8ffc_c639e0e4d6c8.slice/cri-containerd-0f27303a0a1f0476a408fb7c3dd168dc9ed7e0dd4480249a47415b777cb4a79d.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29f5eaff_86d1_4297_8ffc_c639e0e4d6c8.slice/cri-containerd-71acf3db9d94c7a6d5375ad4c8e07515c59281983bcec43db6e25a1ae5128be8.scope"
      }
    ],
    "ips": [
      "10.8.0.253"
    ],
    "name": "clustermesh-apiserver-6b9f7d544b-vclkf",
    "namespace": "kube-system"
  }
]

