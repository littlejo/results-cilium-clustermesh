Total: 696
TCP:   1876 (estab 444, closed 1413, orphaned 0, timewait 559)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  463       452       11       
INET	  473       458       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                  Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                           127.0.0.1:43435      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:31991 sk:1 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                 172.31.179.121%ens5:68         0.0.0.0:*    uid:192 ino:72217 sk:2 cgroup:unreachable:c4e <->                            
UNCONN 0      0                             0.0.0.0:8472       0.0.0.0:*    ino:32051 sk:3 cgroup:/ <->                                                  
UNCONN 0      0                           127.0.0.1:323        0.0.0.0:*    ino:15350 sk:4 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                [::]:8472          [::]:*    ino:32050 sk:5 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                               [::1]:323           [::]:*    ino:15351 sk:6 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::439:8ff:fe97:c2b9]%ens5:546           [::]:*    uid:192 ino:15471 sk:7 cgroup:unreachable:c4e v6only:1 <->                   
