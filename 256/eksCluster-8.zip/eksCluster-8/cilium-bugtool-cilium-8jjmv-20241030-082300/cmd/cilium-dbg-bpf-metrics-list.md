REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37045     2924145     677    bpf_overlay.c
Interface                 INGRESS     656354    134554817   1132   bpf_host.c
Success                   EGRESS      12574     1993379     86     l3.h
Success                   EGRESS      16578     1303971     1694   bpf_host.c
Success                   EGRESS      278931    34751189    1308   bpf_lxc.c
Success                   EGRESS      37181     2941312     53     encap.h
Success                   INGRESS     320770    36272875    86     l3.h
Success                   INGRESS     354462    39930474    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
