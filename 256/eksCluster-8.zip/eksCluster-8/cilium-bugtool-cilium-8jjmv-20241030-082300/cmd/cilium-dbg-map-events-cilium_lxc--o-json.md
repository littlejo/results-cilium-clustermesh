{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:08.354Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.148.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:08.354Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.179.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:08.354Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:12.746Z",
  "value": "id=53    sec_id=4     flags=0x0000 ifindex=10  mac=5E:B6:1C:C7:11:13 nodemac=1E:E3:7D:65:46:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:12.747Z",
  "value": "id=854   sec_id=306943 flags=0x0000 ifindex=12  mac=C6:BE:F2:03:51:AF nodemac=BA:67:EB:E3:4B:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:12.792Z",
  "value": "id=319   sec_id=306943 flags=0x0000 ifindex=14  mac=66:0E:FB:2A:F7:F2 nodemac=DA:11:EF:C8:BC:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:12.886Z",
  "value": "id=53    sec_id=4     flags=0x0000 ifindex=10  mac=5E:B6:1C:C7:11:13 nodemac=1E:E3:7D:65:46:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:12.956Z",
  "value": "id=854   sec_id=306943 flags=0x0000 ifindex=12  mac=C6:BE:F2:03:51:AF nodemac=BA:67:EB:E3:4B:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:46.241Z",
  "value": "id=319   sec_id=306943 flags=0x0000 ifindex=14  mac=66:0E:FB:2A:F7:F2 nodemac=DA:11:EF:C8:BC:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:46.241Z",
  "value": "id=53    sec_id=4     flags=0x0000 ifindex=10  mac=5E:B6:1C:C7:11:13 nodemac=1E:E3:7D:65:46:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:46.241Z",
  "value": "id=854   sec_id=306943 flags=0x0000 ifindex=12  mac=C6:BE:F2:03:51:AF nodemac=BA:67:EB:E3:4B:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:46.271Z",
  "value": "id=187   sec_id=317044 flags=0x0000 ifindex=16  mac=5E:E7:E6:45:26:0A nodemac=3A:66:47:93:A0:99"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:47.240Z",
  "value": "id=187   sec_id=317044 flags=0x0000 ifindex=16  mac=5E:E7:E6:45:26:0A nodemac=3A:66:47:93:A0:99"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:47.240Z",
  "value": "id=319   sec_id=306943 flags=0x0000 ifindex=14  mac=66:0E:FB:2A:F7:F2 nodemac=DA:11:EF:C8:BC:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:47.241Z",
  "value": "id=854   sec_id=306943 flags=0x0000 ifindex=12  mac=C6:BE:F2:03:51:AF nodemac=BA:67:EB:E3:4B:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:47.241Z",
  "value": "id=53    sec_id=4     flags=0x0000 ifindex=10  mac=5E:B6:1C:C7:11:13 nodemac=1E:E3:7D:65:46:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.748Z",
  "value": "id=719   sec_id=317044 flags=0x0000 ifindex=18  mac=36:F8:A1:F2:82:7C nodemac=3E:EA:99:62:CB:8A"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.8.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.475Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.088Z",
  "value": "id=319   sec_id=306943 flags=0x0000 ifindex=14  mac=66:0E:FB:2A:F7:F2 nodemac=DA:11:EF:C8:BC:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.090Z",
  "value": "id=719   sec_id=317044 flags=0x0000 ifindex=18  mac=36:F8:A1:F2:82:7C nodemac=3E:EA:99:62:CB:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.094Z",
  "value": "id=53    sec_id=4     flags=0x0000 ifindex=10  mac=5E:B6:1C:C7:11:13 nodemac=1E:E3:7D:65:46:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.095Z",
  "value": "id=854   sec_id=306943 flags=0x0000 ifindex=12  mac=C6:BE:F2:03:51:AF nodemac=BA:67:EB:E3:4B:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.115Z",
  "value": "id=319   sec_id=306943 flags=0x0000 ifindex=14  mac=66:0E:FB:2A:F7:F2 nodemac=DA:11:EF:C8:BC:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.115Z",
  "value": "id=719   sec_id=317044 flags=0x0000 ifindex=18  mac=36:F8:A1:F2:82:7C nodemac=3E:EA:99:62:CB:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.117Z",
  "value": "id=53    sec_id=4     flags=0x0000 ifindex=10  mac=5E:B6:1C:C7:11:13 nodemac=1E:E3:7D:65:46:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.117Z",
  "value": "id=854   sec_id=306943 flags=0x0000 ifindex=12  mac=C6:BE:F2:03:51:AF nodemac=BA:67:EB:E3:4B:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.107Z",
  "value": "id=319   sec_id=306943 flags=0x0000 ifindex=14  mac=66:0E:FB:2A:F7:F2 nodemac=DA:11:EF:C8:BC:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.107Z",
  "value": "id=53    sec_id=4     flags=0x0000 ifindex=10  mac=5E:B6:1C:C7:11:13 nodemac=1E:E3:7D:65:46:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.107Z",
  "value": "id=719   sec_id=317044 flags=0x0000 ifindex=18  mac=36:F8:A1:F2:82:7C nodemac=3E:EA:99:62:CB:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.107Z",
  "value": "id=854   sec_id=306943 flags=0x0000 ifindex=12  mac=C6:BE:F2:03:51:AF nodemac=BA:67:EB:E3:4B:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.107Z",
  "value": "id=854   sec_id=306943 flags=0x0000 ifindex=12  mac=C6:BE:F2:03:51:AF nodemac=BA:67:EB:E3:4B:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.108Z",
  "value": "id=719   sec_id=317044 flags=0x0000 ifindex=18  mac=36:F8:A1:F2:82:7C nodemac=3E:EA:99:62:CB:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.109Z",
  "value": "id=319   sec_id=306943 flags=0x0000 ifindex=14  mac=66:0E:FB:2A:F7:F2 nodemac=DA:11:EF:C8:BC:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.109Z",
  "value": "id=53    sec_id=4     flags=0x0000 ifindex=10  mac=5E:B6:1C:C7:11:13 nodemac=1E:E3:7D:65:46:B3"
}

