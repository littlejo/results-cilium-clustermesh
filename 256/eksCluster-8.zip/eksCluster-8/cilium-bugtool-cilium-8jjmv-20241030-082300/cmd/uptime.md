 08:23:01 up 36 min,  0 users,  load average: 1.70, 0.56, 0.26
