xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 571
ens6(5) clsact/ingress cil_from_netdev-ens6 id 583
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 568
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 557
cilium_host(7) clsact/egress cil_from_host-cilium_host id 556
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 522
lxc642925ff781e(12) clsact/ingress cil_from_container-lxc642925ff781e id 539
lxc271e78b76ab6(14) clsact/ingress cil_from_container-lxc271e78b76ab6 id 517
lxc0e0a74569386(18) clsact/ingress cil_from_container-lxc0e0a74569386 id 627

flow_dissector:

netfilter:

