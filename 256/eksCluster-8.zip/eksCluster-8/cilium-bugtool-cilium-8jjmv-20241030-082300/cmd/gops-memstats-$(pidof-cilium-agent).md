alloc: 206.44MB (216470360 bytes)
total-alloc: 2.37GB (2545354808 bytes)
sys: 341.09MB (357653876 bytes)
lookups: 0
mallocs: 65195225
frees: 63205059
heap-alloc: 206.44MB (216470360 bytes)
heap-sys: 258.55MB (271106048 bytes)
heap-idle: 31.41MB (32940032 bytes)
heap-in-use: 227.13MB (238166016 bytes)
heap-released: 1.96MB (2056192 bytes)
heap-objects: 1990166
stack-in-use: 69.00MB (72351744 bytes)
stack-sys: 69.00MB (72351744 bytes)
stack-mspan-inuse: 3.35MB (3509280 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.26MB (1316201 bytes)
gc-sys: 6.49MB (6810128 bytes)
next-gc: when heap-alloc >= 213.24MB (223595336 bytes)
last-gc: 2024-10-30 08:23:05.412155434 +0000 UTC
gc-pause-total: 8.792627ms
gc-pause: 175550
gc-pause-end: 1730276585412155434
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00034835428053079797
enable-gc: true
debug-gc: false
