1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:39:08:97:c2:b9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.179.121/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3219sec preferred_lft 3219sec
    inet6 fe80::439:8ff:fe97:c2b9/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:4f:67:f1:25:ad brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.148.127/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::44f:67ff:fef1:25ad/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:84:fe:15:b5:1a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1484:feff:fe15:b51a/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:53:ad:b0:70:ca brd ff:ff:ff:ff:ff:ff
    inet 10.8.0.241/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::2c53:adff:feb0:70ca/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 62:19:83:d1:27:25 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6019:83ff:fed1:2725/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:e3:7d:65:46:b3 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::1ce3:7dff:fe65:46b3/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc642925ff781e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:67:eb:e3:4b:0f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b867:ebff:fee3:4b0f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc271e78b76ab6@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:11:ef:c8:bc:31 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d811:efff:fec8:bc31/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc0e0a74569386@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:ea:99:62:cb:8a brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::3cea:99ff:fe62:cb8a/64 scope link 
       valid_lft forever preferred_lft forever
