key: 35 00 00 00  value: 06 02 00 00
key: 3f 01 00 00  value: 00 02 00 00
key: cf 02 00 00  value: 74 02 00 00
key: 56 03 00 00  value: 20 02 00 00
Found 4 elements
