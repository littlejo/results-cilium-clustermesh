CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcc63efbe_40e3_4b27_9243_2447e69c928e.slice/cri-containerd-ae37e58f8a9aebe9c24511ec02fe1c0ed781989c44495be43a2f2a0ea01f102b.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcc63efbe_40e3_4b27_9243_2447e69c928e.slice/cri-containerd-2f087262dd48728cdfc95306d5183acd58e86f99f8cf250573d8235f1a92267a.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04d125e2_a98b_4548_82c5_6f0ed54216bb.slice/cri-containerd-e1a23fcd51084fc8a6e13a9dc5c97f8210bcafb9d0073054250881af8a6e2db3.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04d125e2_a98b_4548_82c5_6f0ed54216bb.slice/cri-containerd-cc9e1bc34a00931864bbe740eafa61d197e46b9faa5639dd124c56546e0f36e8.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca8df2e7_1c0b_466f_8e8b_285bee6b721e.slice/cri-containerd-b7267c86e826f30f47bf380cb51e8ec9ef6d29cc3a05e72e1d9630889fee87c2.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca8df2e7_1c0b_466f_8e8b_285bee6b721e.slice/cri-containerd-a292db2a4a445e3d61facdd97b2de74417864d34ddf750135343ed0959bc28c8.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfd8b3028_503b_4898_bdca_8a02ec475458.slice/cri-containerd-20302f008e0a31ace4c131caa17fa12780639bc5ba82a411e524d77b322be38a.scope
    531      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfd8b3028_503b_4898_bdca_8a02ec475458.slice/cri-containerd-d79b3f9bfadce170211d534581a9b1743b34af6a2d2b7d60b870681277b2d83e.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcde1cdc0_7544_4d71_b028_f0d2ced2c83e.slice/cri-containerd-41ce0e9c932db3093f1d4ab2b1faba520d87f359fcf2fa8ab667d4eabe634a13.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcde1cdc0_7544_4d71_b028_f0d2ced2c83e.slice/cri-containerd-6aca251c1432a5f0cbb9424e092be0c01be71bbd022601c16673f5ec30833d57.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29f5eaff_86d1_4297_8ffc_c639e0e4d6c8.slice/cri-containerd-71acf3db9d94c7a6d5375ad4c8e07515c59281983bcec43db6e25a1ae5128be8.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29f5eaff_86d1_4297_8ffc_c639e0e4d6c8.slice/cri-containerd-0f27303a0a1f0476a408fb7c3dd168dc9ed7e0dd4480249a47415b777cb4a79d.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29f5eaff_86d1_4297_8ffc_c639e0e4d6c8.slice/cri-containerd-27b2c8128c858fdb66b698cb398bf648a0c3d1e83650fadc02becde9bbca1cd9.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29f5eaff_86d1_4297_8ffc_c639e0e4d6c8.slice/cri-containerd-f2f9e81a3fe919ca9b7dea56208757abc5add306c2f6c423e9a24ebc92b86826.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod973e3513_1929_4066_9166_29b3385cb11f.slice/cri-containerd-7d2f8284723a3a15ec92ca2d415cf174f2601c71ae1bfbc97eb102190c1942d8.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod973e3513_1929_4066_9166_29b3385cb11f.slice/cri-containerd-6cfec88c703c2c1d61a41f025e813d102c7716ce43594af8c0036cf0cf974bff.scope
    98       cgroup_device   multi                                          
