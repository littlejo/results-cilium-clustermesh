Endpoint ID: 53
Path: /sys/fs/bpf/tc/globals/cilium_policy_00053

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1671724   21212     0        
Allow    Ingress     1          ANY          NONE         disabled    26116     306       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 319
Path: /sys/fs/bpf/tc/globals/cilium_policy_00319

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    351619   3157      0        
Allow    Ingress     1          ANY          NONE         disabled    174150   2005      0        
Allow    Egress      0          ANY          NONE         disabled    109136   1055      0        


Endpoint ID: 719
Path: /sys/fs/bpf/tc/globals/cilium_policy_00719

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11654736   116357    0        
Allow    Ingress     1          ANY          NONE         disabled    10077925   106119    0        
Allow    Egress      0          ANY          NONE         disabled    13246150   130132    0        


Endpoint ID: 854
Path: /sys/fs/bpf/tc/globals/cilium_policy_00854

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    348907   3130      0        
Allow    Ingress     1          ANY          NONE         disabled    174612   2012      0        
Allow    Egress      0          ANY          NONE         disabled    108430   1046      0        


Endpoint ID: 3583
Path: /sys/fs/bpf/tc/globals/cilium_policy_03583

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


