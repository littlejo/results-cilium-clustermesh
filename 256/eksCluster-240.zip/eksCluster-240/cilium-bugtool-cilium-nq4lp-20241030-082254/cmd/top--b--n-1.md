top - 08:22:55 up 27 min,  0 users,  load average: 0.21, 0.17, 0.15
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 20.7 us, 51.7 sy,  0.0 ni, 20.7 id,  0.0 wa,  0.0 hi,  6.9 si,  0.0 st
MiB Mem :   7814.2 total,   4471.7 free,   1196.6 used,   2145.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6432.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 383260  78144 S  13.3   4.8   0:42.79 cilium-+
    734 root      20   0 1243828  19712  13704 S  13.3   0.2   0:00.02 hubble
    394 root      20   0 1229744   7916   3840 S   0.0   0.1   0:01.06 cilium-+
    624 root      20   0 1228744   3656   2976 S   0.0   0.0   0:00.00 gops
    642 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
    651 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    658 root      20   0 1240432  15952  10960 S   0.0   0.2   0:00.02 cilium-+
    698 root      20   0    6576   2412   2088 R   0.0   0.0   0:00.00 top
    723 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    724 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
