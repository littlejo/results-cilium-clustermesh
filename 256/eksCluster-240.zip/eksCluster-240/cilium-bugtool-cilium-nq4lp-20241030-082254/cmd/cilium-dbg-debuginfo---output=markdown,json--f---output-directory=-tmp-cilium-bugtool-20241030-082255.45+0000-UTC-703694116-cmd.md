markdown output at /tmp/cilium-bugtool-20241030-082255.45+0000-UTC-703694116/cmd/cilium-debuginfo-20241030-082326.482+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082255.45+0000-UTC-703694116/cmd/cilium-debuginfo-20241030-082326.482+0000-UTC.json
