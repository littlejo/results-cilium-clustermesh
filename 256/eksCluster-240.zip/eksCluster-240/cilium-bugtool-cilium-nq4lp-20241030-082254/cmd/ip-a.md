1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:9e:c6:5e:dc:81 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.168.247/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1945sec preferred_lft 1945sec
    inet6 fe80::49e:c6ff:fe5e:dc81/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:06:ae:59:06:fd brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.145.125/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::406:aeff:fe59:6fd/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:6f:ef:4d:dd:54 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d06f:efff:fe4d:dd54/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:e1:00:f1:a5:f0 brd ff:ff:ff:ff:ff:ff
    inet 10.240.0.212/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::2ce1:ff:fef1:a5f0/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3a:92:45:3b:6f:e4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3892:45ff:fe3b:6fe4/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:06:b7:c9:d7:d2 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::fc06:b7ff:fec9:d7d2/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf7c7034b93ae@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:30:ff:06:47:ab brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d030:ffff:fe06:47ab/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc8d32088041bb@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:0b:99:b3:5e:31 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::6c0b:99ff:feb3:5e31/64 scope link 
       valid_lft forever preferred_lft forever
18: lxca2457b8e46c2@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:65:7d:87:94:6a brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9065:7dff:fe87:946a/64 scope link 
       valid_lft forever preferred_lft forever
