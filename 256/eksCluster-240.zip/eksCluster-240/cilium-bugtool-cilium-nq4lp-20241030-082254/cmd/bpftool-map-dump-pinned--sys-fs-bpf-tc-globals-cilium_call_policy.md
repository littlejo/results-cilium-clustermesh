key: 93 00 00 00  value: 35 02 00 00
key: 85 02 00 00  value: 00 02 00 00
key: c2 0a 00 00  value: 74 02 00 00
key: 69 0d 00 00  value: 04 02 00 00
Found 4 elements
