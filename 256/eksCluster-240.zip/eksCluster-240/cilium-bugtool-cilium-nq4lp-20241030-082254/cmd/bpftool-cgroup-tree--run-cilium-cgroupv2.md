CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5f5ccee5_2168_4eb1_832d_4a525df153a1.slice/cri-containerd-4911cc4f69ed09f680d9cfab7cc9bfd08748202d4a2df1ff7b136f21fc48193f.scope
    580      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5f5ccee5_2168_4eb1_832d_4a525df153a1.slice/cri-containerd-444335cf6baa715f93f1ba7a6241d3287130cddda258ce387f8e253e88654dec.scope
    576      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podba2be9b8_fbd3_4f3d_941f_1c88c75e4c58.slice/cri-containerd-981beeac05c8c040e257b092df426cb99500809bd9564df4912d86c5b0907349.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podba2be9b8_fbd3_4f3d_941f_1c88c75e4c58.slice/cri-containerd-0acbef9db84714d96c213f3bf59e9ed642d1d441ce7ef1d261ed28f087a2e7fa.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7e244709_ce10_46a2_aced_3ff37d209a04.slice/cri-containerd-583d62321cef10aefa48e1c1551152b133c46cc1b357a0244c47afb20c395d71.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7e244709_ce10_46a2_aced_3ff37d209a04.slice/cri-containerd-9b058db1b453510a76c34131cabe7f79cf797907cde8a4671e570aa3a9d7f677.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4841a26_851d_4dce_8da1_0af80e2140aa.slice/cri-containerd-9407677556df2a7470f19cfbfa0cc7aa6296c66735375ea4764d6582fcaae722.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4841a26_851d_4dce_8da1_0af80e2140aa.slice/cri-containerd-83408614fb8c272d91d64556802a83b5b7bb0f500033c43efc579f9758f45932.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod90398172_4810_436f_a298_c5df6804b2d6.slice/cri-containerd-9214c701a4a4eda2b1b80629c6718c7b35eda3c3ad0dbecc00c6bc89648b8fa6.scope
    126      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod90398172_4810_436f_a298_c5df6804b2d6.slice/cri-containerd-c7e8067080b7ea36e907e16cc68806c61dac9c9e5ce0f2de8978cd201e4efeb7.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd8fbbc32_e6d8_4b5e_b451_d8abedc2146b.slice/cri-containerd-a3b0ebcd109e876ddb46c828bd40e5bcf2d15b7ff1a11c3af62e1aab41b590be.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd8fbbc32_e6d8_4b5e_b451_d8abedc2146b.slice/cri-containerd-5591c228a51c3ab857c5d624226de8c086c938f88801ce59ae3ae09b3c3b058a.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf007853_84fe_486e_b078_a3dda185fb41.slice/cri-containerd-93bf7900c551a8ca62462a9e89829e1c0cdbbf11713eacf331e3d900fcd93d8d.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf007853_84fe_486e_b078_a3dda185fb41.slice/cri-containerd-25b7f5d61801f4d8b3998ab543061d03eba4c35327c71087cbe2bdd9b76252f9.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf007853_84fe_486e_b078_a3dda185fb41.slice/cri-containerd-0171c2aadb79cde08dd1308fd193b166d32b75623278057dcbd4c6e55536c840.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf007853_84fe_486e_b078_a3dda185fb41.slice/cri-containerd-21552a0efce4410c7d36d6fccde25602f3c55689378ce437c08cf04faa0e4916.scope
    654      cgroup_device   multi                                          
