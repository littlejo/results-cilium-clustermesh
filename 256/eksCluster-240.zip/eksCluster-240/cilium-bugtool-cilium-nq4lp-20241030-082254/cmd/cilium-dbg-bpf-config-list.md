KEY             VALUE
AgentLiveness   1696184901395
UTimeOffset     3379443183593750
