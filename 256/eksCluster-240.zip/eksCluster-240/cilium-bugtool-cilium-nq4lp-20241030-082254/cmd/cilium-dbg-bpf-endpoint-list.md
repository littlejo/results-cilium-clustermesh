IP ADDRESS         LOCAL ENDPOINT INFO
172.31.168.247:0   (localhost)                                                                                        
10.240.0.212:0     (localhost)                                                                                        
172.31.145.125:0   (localhost)                                                                                        
10.240.0.148:0     id=3433  sec_id=7901996 flags=0x0000 ifindex=12  mac=82:99:5B:04:50:56 nodemac=D2:30:FF:06:47:AB   
10.240.0.166:0     id=645   sec_id=4     flags=0x0000 ifindex=10  mac=06:28:4A:C9:56:9D nodemac=FE:06:B7:C9:D7:D2     
10.240.0.163:0     id=147   sec_id=7901996 flags=0x0000 ifindex=14  mac=BA:99:93:F5:49:9D nodemac=6E:0B:99:B3:5E:31   
10.240.0.201:0     id=2754  sec_id=7906970 flags=0x0000 ifindex=18  mac=EA:9A:F0:11:EA:6D nodemac=92:65:7D:87:94:6A   
