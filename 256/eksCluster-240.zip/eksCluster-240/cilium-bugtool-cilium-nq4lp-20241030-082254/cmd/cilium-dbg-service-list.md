ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.168.110:443 (active)    
                                         2 => 172.31.195.126:443 (active)    
2    10.100.15.122:443    ClusterIP      1 => 172.31.168.247:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.240.0.148:53 (active)       
                                         2 => 10.240.0.163:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.240.0.148:9153 (active)     
                                         2 => 10.240.0.163:9153 (active)     
5    10.100.149.98:2379   ClusterIP      1 => 10.240.0.201:2379 (active)     
