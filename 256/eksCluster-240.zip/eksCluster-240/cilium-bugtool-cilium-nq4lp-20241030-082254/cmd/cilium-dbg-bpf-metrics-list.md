REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36745     2910745     677    bpf_overlay.c
Interface                 INGRESS     643319    131770921   1132   bpf_host.c
Success                   EGRESS      16524     1301004     1694   bpf_host.c
Success                   EGRESS      274375    34239379    1308   bpf_lxc.c
Success                   EGRESS      37075     2931825     53     encap.h
Success                   INGRESS     318139    35746373    86     l3.h
Success                   INGRESS     339011    37400160    235    trace.h
Unsupported L3 protocol   EGRESS      42        3168        1492   bpf_lxc.c
