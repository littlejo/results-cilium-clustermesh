[
  {
    "containers": [
      {
        "cgroup-id": 7530,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7e244709_ce10_46a2_aced_3ff37d209a04.slice/cri-containerd-583d62321cef10aefa48e1c1551152b133c46cc1b357a0244c47afb20c395d71.scope"
      }
    ],
    "ips": [
      "10.240.0.148"
    ],
    "name": "coredns-cc6ccd49c-gmd4t",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5f5ccee5_2168_4eb1_832d_4a525df153a1.slice/cri-containerd-4911cc4f69ed09f680d9cfab7cc9bfd08748202d4a2df1ff7b136f21fc48193f.scope"
      }
    ],
    "ips": [
      "10.240.0.163"
    ],
    "name": "coredns-cc6ccd49c-p4d9t",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf007853_84fe_486e_b078_a3dda185fb41.slice/cri-containerd-21552a0efce4410c7d36d6fccde25602f3c55689378ce437c08cf04faa0e4916.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf007853_84fe_486e_b078_a3dda185fb41.slice/cri-containerd-93bf7900c551a8ca62462a9e89829e1c0cdbbf11713eacf331e3d900fcd93d8d.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf007853_84fe_486e_b078_a3dda185fb41.slice/cri-containerd-0171c2aadb79cde08dd1308fd193b166d32b75623278057dcbd4c6e55536c840.scope"
      }
    ],
    "ips": [
      "10.240.0.201"
    ],
    "name": "clustermesh-apiserver-7586fb95ff-gv997",
    "namespace": "kube-system"
  }
]

