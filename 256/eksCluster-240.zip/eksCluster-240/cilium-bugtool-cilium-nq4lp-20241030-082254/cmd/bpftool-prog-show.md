29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:55:13+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:55:13+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:55:14+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:55:14+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:55:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:55:14+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:55:14+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:55:18+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:55:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
123: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
126: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name tail_handle_ipv4  tag c898bc97b1f41f22  gpl
	loaded_at 2024-10-30T08:03:41+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
479: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:03:41+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
480: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:03:41+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 126
481: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:03:41+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
504: sched_cls  name tail_ipv4_ct_ingress  tag 9fc1f0b489b2d8a2  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,107,82,83,106,84
	btf_id 153
505: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,107,82,83,106,84
	btf_id 154
506: sched_cls  name tail_handle_ipv4_cont  tag 8e65ec4769161b1e  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,106,41,101,82,83,39,76,74,77,107,40,37,38,81
	btf_id 155
507: sched_cls  name tail_handle_arp  tag c9db564f7499e2d0  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 156
508: sched_cls  name cil_from_container  tag 356a463ffccccfd4  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 107,76
	btf_id 157
509: sched_cls  name __send_drop_notify  tag ef7a9b021136fac1  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 158
511: sched_cls  name tail_ipv4_to_endpoint  tag 34341c191f2cb50e  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,106,41,82,83,80,101,39,107,40,37,38
	btf_id 160
512: sched_cls  name handle_policy  tag 7e715c163b69dc55  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,107,82,83,106,41,80,101,39,84,75,40,37,38
	btf_id 161
513: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 162
514: sched_cls  name tail_handle_ipv4  tag 705a83da39ac1d00  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 163
515: sched_cls  name tail_ipv4_ct_egress  tag 443b6848033be02b  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,108,84
	btf_id 165
516: sched_cls  name handle_policy  tag f6155d773a449105  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,109,82,83,108,41,80,100,39,84,75,40,37,38
	btf_id 166
517: sched_cls  name tail_handle_arp  tag 5b7cdd0e2c29e81c  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 167
518: sched_cls  name cil_from_container  tag da33b5b445a08deb  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 109,76
	btf_id 168
519: sched_cls  name tail_ipv4_ct_ingress  tag d7b958196bf0e75e  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,108,84
	btf_id 169
520: sched_cls  name __send_drop_notify  tag 60899edce1eb88b7  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 170
522: sched_cls  name tail_handle_ipv4_cont  tag f24888d0c40e962e  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,108,41,100,82,83,39,76,74,77,109,40,37,38,81
	btf_id 172
523: sched_cls  name tail_ipv4_to_endpoint  tag 2e24899d07645018  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,108,41,82,83,80,100,39,109,40,37,38
	btf_id 173
524: sched_cls  name tail_handle_ipv4  tag a025d9a2ff2bc96c  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 174
525: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 175
526: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
529: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
530: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
533: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
534: sched_cls  name tail_handle_ipv4_from_host  tag aeca9397b363b832  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,113
	btf_id 177
535: sched_cls  name __send_drop_notify  tag 48e4b1116fd9360e  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 178
537: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,113
	btf_id 180
538: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,113
	btf_id 181
540: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 183
541: sched_cls  name __send_drop_notify  tag 48e4b1116fd9360e  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 185
543: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,114
	btf_id 187
546: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 190
547: sched_cls  name tail_handle_ipv4_from_host  tag aeca9397b363b832  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,114
	btf_id 191
548: sched_cls  name __send_drop_notify  tag 48e4b1116fd9360e  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 193
549: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,117,75
	btf_id 194
550: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 195
554: sched_cls  name tail_handle_ipv4_from_host  tag aeca9397b363b832  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 199
555: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 201
559: sched_cls  name tail_handle_ipv4_from_host  tag aeca9397b363b832  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 205
560: sched_cls  name __send_drop_notify  tag 48e4b1116fd9360e  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
561: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:03:44+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,119,75
	btf_id 207
562: sched_cls  name cil_from_container  tag 7b4ebab31348e739  gpl
	loaded_at 2024-10-30T08:03:49+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 122,76
	btf_id 209
563: sched_cls  name tail_ipv4_ct_ingress  tag d7bc69f0ba77da42  gpl
	loaded_at 2024-10-30T08:03:49+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,122,82,83,121,84
	btf_id 210
564: sched_cls  name tail_handle_arp  tag 10348a569fc47599  gpl
	loaded_at 2024-10-30T08:03:49+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,122
	btf_id 211
565: sched_cls  name handle_policy  tag ede7e47dbaec6ef9  gpl
	loaded_at 2024-10-30T08:03:49+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,122,82,83,121,41,80,120,39,84,75,40,37,38
	btf_id 212
566: sched_cls  name tail_ipv4_ct_egress  tag 443b6848033be02b  gpl
	loaded_at 2024-10-30T08:03:49+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,122,82,83,121,84
	btf_id 213
567: sched_cls  name tail_handle_ipv4  tag b9db24100b3747a9  gpl
	loaded_at 2024-10-30T08:03:49+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,122
	btf_id 214
568: sched_cls  name __send_drop_notify  tag 01daea15fc32f0af  gpl
	loaded_at 2024-10-30T08:03:49+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 215
569: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:49+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,122
	btf_id 216
570: sched_cls  name tail_ipv4_to_endpoint  tag 72120fe5bfaca685  gpl
	loaded_at 2024-10-30T08:03:49+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,121,41,82,83,80,120,39,122,40,37,38
	btf_id 217
571: sched_cls  name tail_handle_ipv4_cont  tag a98d2ee7301330c7  gpl
	loaded_at 2024-10-30T08:03:49+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,121,41,120,82,83,39,76,74,77,122,40,37,38,81
	btf_id 218
573: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
576: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
577: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
580: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
620: sched_cls  name tail_ipv4_ct_egress  tag 0937c32e9b613d81  gpl
	loaded_at 2024-10-30T08:10:59+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 233
621: sched_cls  name cil_from_container  tag 19133517c4cd5b44  gpl
	loaded_at 2024-10-30T08:10:59+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 234
622: sched_cls  name tail_handle_ipv4  tag b050b51222e2f38b  gpl
	loaded_at 2024-10-30T08:10:59+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 235
623: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:10:59+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 236
624: sched_cls  name tail_ipv4_to_endpoint  tag 18fb39f07256735c  gpl
	loaded_at 2024-10-30T08:10:59+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 237
626: sched_cls  name tail_handle_ipv4_cont  tag 0ac04833cd222253  gpl
	loaded_at 2024-10-30T08:10:59+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 239
627: sched_cls  name __send_drop_notify  tag b820f806e70e35a8  gpl
	loaded_at 2024-10-30T08:10:59+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 240
628: sched_cls  name handle_policy  tag 7f50853d75a93f6f  gpl
	loaded_at 2024-10-30T08:10:59+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 241
629: sched_cls  name tail_handle_arp  tag b6c5f536c37a5f38  gpl
	loaded_at 2024-10-30T08:10:59+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 242
630: sched_cls  name tail_ipv4_ct_ingress  tag 6de1d42f288c3867  gpl
	loaded_at 2024-10-30T08:10:59+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 243
631: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
634: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
647: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
650: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
655: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
658: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
