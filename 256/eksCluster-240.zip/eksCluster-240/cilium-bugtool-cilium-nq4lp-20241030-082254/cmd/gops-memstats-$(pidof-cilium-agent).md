alloc: 112.02MB (117458184 bytes)
total-alloc: 2.26GB (2430502232 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 63766645
frees: 63073775
heap-alloc: 112.02MB (117458184 bytes)
heap-sys: 253.98MB (266313728 bytes)
heap-idle: 73.17MB (76726272 bytes)
heap-in-use: 180.80MB (189587456 bytes)
heap-released: 3.00MB (3145728 bytes)
heap-objects: 692870
stack-in-use: 62.00MB (65011712 bytes)
stack-sys: 62.00MB (65011712 bytes)
stack-mspan-inuse: 2.88MB (3020960 bytes)
stack-mspan-sys: 3.91MB (4096320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 959.74KB (982777 bytes)
gc-sys: 5.98MB (6270344 bytes)
next-gc: when heap-alloc >= 211.37MB (221635000 bytes)
last-gc: 2024-10-30 08:23:24.901586147 +0000 UTC
gc-pause-total: 14.32545ms
gc-pause: 103857
gc-pause-end: 1730276604901586147
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005406539362834016
enable-gc: true
debug-gc: false
