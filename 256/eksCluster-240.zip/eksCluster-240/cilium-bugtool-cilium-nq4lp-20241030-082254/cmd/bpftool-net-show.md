xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 549
ens6(5) clsact/ingress cil_from_netdev-ens6 id 561
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 546
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 540
cilium_host(7) clsact/egress cil_from_host-cilium_host id 538
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 479
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 508
lxcf7c7034b93ae(12) clsact/ingress cil_from_container-lxcf7c7034b93ae id 518
lxc8d32088041bb(14) clsact/ingress cil_from_container-lxc8d32088041bb id 562
lxca2457b8e46c2(18) clsact/ingress cil_from_container-lxca2457b8e46c2 id 621

flow_dissector:

netfilter:

