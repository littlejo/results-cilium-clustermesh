{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:39.615Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.145.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:39.615Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.168.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:39.615Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:43.870Z",
  "value": "id=645   sec_id=4     flags=0x0000 ifindex=10  mac=06:28:4A:C9:56:9D nodemac=FE:06:B7:C9:D7:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:43.871Z",
  "value": "id=3433  sec_id=7901996 flags=0x0000 ifindex=12  mac=82:99:5B:04:50:56 nodemac=D2:30:FF:06:47:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:43.922Z",
  "value": "id=645   sec_id=4     flags=0x0000 ifindex=10  mac=06:28:4A:C9:56:9D nodemac=FE:06:B7:C9:D7:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:43.956Z",
  "value": "id=3433  sec_id=7901996 flags=0x0000 ifindex=12  mac=82:99:5B:04:50:56 nodemac=D2:30:FF:06:47:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:49.459Z",
  "value": "id=147   sec_id=7901996 flags=0x0000 ifindex=14  mac=BA:99:93:F5:49:9D nodemac=6E:0B:99:B3:5E:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:35.021Z",
  "value": "id=645   sec_id=4     flags=0x0000 ifindex=10  mac=06:28:4A:C9:56:9D nodemac=FE:06:B7:C9:D7:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:35.021Z",
  "value": "id=3433  sec_id=7901996 flags=0x0000 ifindex=12  mac=82:99:5B:04:50:56 nodemac=D2:30:FF:06:47:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:35.022Z",
  "value": "id=147   sec_id=7901996 flags=0x0000 ifindex=14  mac=BA:99:93:F5:49:9D nodemac=6E:0B:99:B3:5E:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:35.050Z",
  "value": "id=95    sec_id=7906970 flags=0x0000 ifindex=16  mac=DA:3F:35:D1:A0:1F nodemac=C2:97:A1:07:EB:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:36.022Z",
  "value": "id=3433  sec_id=7901996 flags=0x0000 ifindex=12  mac=82:99:5B:04:50:56 nodemac=D2:30:FF:06:47:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:36.022Z",
  "value": "id=95    sec_id=7906970 flags=0x0000 ifindex=16  mac=DA:3F:35:D1:A0:1F nodemac=C2:97:A1:07:EB:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:36.022Z",
  "value": "id=147   sec_id=7901996 flags=0x0000 ifindex=14  mac=BA:99:93:F5:49:9D nodemac=6E:0B:99:B3:5E:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:36.022Z",
  "value": "id=645   sec_id=4     flags=0x0000 ifindex=10  mac=06:28:4A:C9:56:9D nodemac=FE:06:B7:C9:D7:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.673Z",
  "value": "id=2754  sec_id=7906970 flags=0x0000 ifindex=18  mac=EA:9A:F0:11:EA:6D nodemac=92:65:7D:87:94:6A"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.240.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.507Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.133Z",
  "value": "id=2754  sec_id=7906970 flags=0x0000 ifindex=18  mac=EA:9A:F0:11:EA:6D nodemac=92:65:7D:87:94:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.134Z",
  "value": "id=645   sec_id=4     flags=0x0000 ifindex=10  mac=06:28:4A:C9:56:9D nodemac=FE:06:B7:C9:D7:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.134Z",
  "value": "id=3433  sec_id=7901996 flags=0x0000 ifindex=12  mac=82:99:5B:04:50:56 nodemac=D2:30:FF:06:47:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.134Z",
  "value": "id=147   sec_id=7901996 flags=0x0000 ifindex=14  mac=BA:99:93:F5:49:9D nodemac=6E:0B:99:B3:5E:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.156Z",
  "value": "id=2754  sec_id=7906970 flags=0x0000 ifindex=18  mac=EA:9A:F0:11:EA:6D nodemac=92:65:7D:87:94:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.157Z",
  "value": "id=645   sec_id=4     flags=0x0000 ifindex=10  mac=06:28:4A:C9:56:9D nodemac=FE:06:B7:C9:D7:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.158Z",
  "value": "id=147   sec_id=7901996 flags=0x0000 ifindex=14  mac=BA:99:93:F5:49:9D nodemac=6E:0B:99:B3:5E:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.158Z",
  "value": "id=3433  sec_id=7901996 flags=0x0000 ifindex=12  mac=82:99:5B:04:50:56 nodemac=D2:30:FF:06:47:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.151Z",
  "value": "id=3433  sec_id=7901996 flags=0x0000 ifindex=12  mac=82:99:5B:04:50:56 nodemac=D2:30:FF:06:47:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.151Z",
  "value": "id=2754  sec_id=7906970 flags=0x0000 ifindex=18  mac=EA:9A:F0:11:EA:6D nodemac=92:65:7D:87:94:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.152Z",
  "value": "id=147   sec_id=7901996 flags=0x0000 ifindex=14  mac=BA:99:93:F5:49:9D nodemac=6E:0B:99:B3:5E:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.152Z",
  "value": "id=645   sec_id=4     flags=0x0000 ifindex=10  mac=06:28:4A:C9:56:9D nodemac=FE:06:B7:C9:D7:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:16.152Z",
  "value": "id=147   sec_id=7901996 flags=0x0000 ifindex=14  mac=BA:99:93:F5:49:9D nodemac=6E:0B:99:B3:5E:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:16.152Z",
  "value": "id=2754  sec_id=7906970 flags=0x0000 ifindex=18  mac=EA:9A:F0:11:EA:6D nodemac=92:65:7D:87:94:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:16.153Z",
  "value": "id=645   sec_id=4     flags=0x0000 ifindex=10  mac=06:28:4A:C9:56:9D nodemac=FE:06:B7:C9:D7:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.240.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:16.153Z",
  "value": "id=3433  sec_id=7901996 flags=0x0000 ifindex=12  mac=82:99:5B:04:50:56 nodemac=D2:30:FF:06:47:AB"
}

