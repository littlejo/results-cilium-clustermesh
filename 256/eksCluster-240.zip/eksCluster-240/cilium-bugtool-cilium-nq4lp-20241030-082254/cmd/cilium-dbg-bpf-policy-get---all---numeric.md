Endpoint ID: 147
Path: /sys/fs/bpf/tc/globals/cilium_policy_00147

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    111930   1283      0        
Allow    Egress      0          ANY          NONE         disabled    15852    170       0        


Endpoint ID: 645
Path: /sys/fs/bpf/tc/globals/cilium_policy_00645

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1659057   20936     0        
Allow    Ingress     1          ANY          NONE         disabled    17824     211       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2754
Path: /sys/fs/bpf/tc/globals/cilium_policy_02754

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11600110   115720    0        
Allow    Ingress     1          ANY          NONE         disabled    10439410   110080    0        
Allow    Egress      0          ANY          NONE         disabled    12898847   127102    0        


Endpoint ID: 3076
Path: /sys/fs/bpf/tc/globals/cilium_policy_03076

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3433
Path: /sys/fs/bpf/tc/globals/cilium_policy_03433

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    111792   1279      0        
Allow    Egress      0          ANY          NONE         disabled    17054    185       0        


