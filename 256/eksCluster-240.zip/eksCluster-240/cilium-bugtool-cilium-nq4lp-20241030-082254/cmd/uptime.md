 08:22:55 up 27 min,  0 users,  load average: 0.21, 0.17, 0.15
