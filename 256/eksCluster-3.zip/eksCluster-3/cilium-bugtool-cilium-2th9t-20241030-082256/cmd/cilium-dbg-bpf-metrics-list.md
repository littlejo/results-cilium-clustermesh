REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37000     2924000     677    bpf_overlay.c
Interface                 INGRESS     668568    136142959   1132   bpf_host.c
Success                   EGRESS      16473     1296894     1694   bpf_host.c
Success                   EGRESS      22428     3554646     86     l3.h
Success                   EGRESS      285535    35437111    1308   bpf_lxc.c
Success                   EGRESS      37375     2952735     53     encap.h
Success                   INGRESS     330309    37367573    86     l3.h
Success                   INGRESS     373788    42583973    235    trace.h
Unsupported L3 protocol   EGRESS      41        3022        1492   bpf_lxc.c
