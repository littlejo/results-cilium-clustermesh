Total: 683
TCP:   1873 (estab 433, closed 1421, orphaned 0, timewait 577)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  452       440       12       
INET	  462       446       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                    172.31.226.7%ens5:68         0.0.0.0:*    uid:192 ino:75448 sk:1 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:32514 sk:2 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15254 sk:3 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:43251      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=43)) ino:32438 sk:4 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:32513 sk:5 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15255 sk:6 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::831:2dff:fe45:4cf5]%ens5:546           [::]:*    uid:192 ino:15647 sk:7 cgroup:unreachable:c4e v6only:1 <->                   
