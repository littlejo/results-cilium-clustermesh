{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:33.208Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.203.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:33.208Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.226.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:33.208Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:37.893Z",
  "value": "id=1535  sec_id=4     flags=0x0000 ifindex=10  mac=52:12:B8:DE:A3:A3 nodemac=EA:8D:03:9B:71:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:37.895Z",
  "value": "id=2698  sec_id=133233 flags=0x0000 ifindex=12  mac=0A:A7:5A:FC:DF:DE nodemac=7A:D7:A2:E9:65:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:37.932Z",
  "value": "id=1535  sec_id=4     flags=0x0000 ifindex=10  mac=52:12:B8:DE:A3:A3 nodemac=EA:8D:03:9B:71:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:37.933Z",
  "value": "id=2698  sec_id=133233 flags=0x0000 ifindex=12  mac=0A:A7:5A:FC:DF:DE nodemac=7A:D7:A2:E9:65:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:37.959Z",
  "value": "id=3449  sec_id=133233 flags=0x0000 ifindex=14  mac=46:ED:F6:8A:FA:D4 nodemac=7A:B5:D5:4B:C6:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:51.057Z",
  "value": "id=1535  sec_id=4     flags=0x0000 ifindex=10  mac=52:12:B8:DE:A3:A3 nodemac=EA:8D:03:9B:71:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:51.057Z",
  "value": "id=2698  sec_id=133233 flags=0x0000 ifindex=12  mac=0A:A7:5A:FC:DF:DE nodemac=7A:D7:A2:E9:65:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:51.058Z",
  "value": "id=3449  sec_id=133233 flags=0x0000 ifindex=14  mac=46:ED:F6:8A:FA:D4 nodemac=7A:B5:D5:4B:C6:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:51.088Z",
  "value": "id=2985  sec_id=161722 flags=0x0000 ifindex=16  mac=A2:76:9E:74:91:0A nodemac=FA:91:96:06:39:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:52.057Z",
  "value": "id=3449  sec_id=133233 flags=0x0000 ifindex=14  mac=46:ED:F6:8A:FA:D4 nodemac=7A:B5:D5:4B:C6:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:52.057Z",
  "value": "id=2698  sec_id=133233 flags=0x0000 ifindex=12  mac=0A:A7:5A:FC:DF:DE nodemac=7A:D7:A2:E9:65:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:52.057Z",
  "value": "id=1535  sec_id=4     flags=0x0000 ifindex=10  mac=52:12:B8:DE:A3:A3 nodemac=EA:8D:03:9B:71:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:52.058Z",
  "value": "id=2985  sec_id=161722 flags=0x0000 ifindex=16  mac=A2:76:9E:74:91:0A nodemac=FA:91:96:06:39:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.131Z",
  "value": "id=1335  sec_id=161722 flags=0x0000 ifindex=18  mac=F2:89:18:5E:61:EE nodemac=4E:DA:66:71:3F:E4"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.3.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.698Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.391Z",
  "value": "id=3449  sec_id=133233 flags=0x0000 ifindex=14  mac=46:ED:F6:8A:FA:D4 nodemac=7A:B5:D5:4B:C6:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.391Z",
  "value": "id=1535  sec_id=4     flags=0x0000 ifindex=10  mac=52:12:B8:DE:A3:A3 nodemac=EA:8D:03:9B:71:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.391Z",
  "value": "id=1335  sec_id=161722 flags=0x0000 ifindex=18  mac=F2:89:18:5E:61:EE nodemac=4E:DA:66:71:3F:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.392Z",
  "value": "id=2698  sec_id=133233 flags=0x0000 ifindex=12  mac=0A:A7:5A:FC:DF:DE nodemac=7A:D7:A2:E9:65:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.401Z",
  "value": "id=1535  sec_id=4     flags=0x0000 ifindex=10  mac=52:12:B8:DE:A3:A3 nodemac=EA:8D:03:9B:71:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.408Z",
  "value": "id=2698  sec_id=133233 flags=0x0000 ifindex=12  mac=0A:A7:5A:FC:DF:DE nodemac=7A:D7:A2:E9:65:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.409Z",
  "value": "id=3449  sec_id=133233 flags=0x0000 ifindex=14  mac=46:ED:F6:8A:FA:D4 nodemac=7A:B5:D5:4B:C6:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.409Z",
  "value": "id=1335  sec_id=161722 flags=0x0000 ifindex=18  mac=F2:89:18:5E:61:EE nodemac=4E:DA:66:71:3F:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.392Z",
  "value": "id=1335  sec_id=161722 flags=0x0000 ifindex=18  mac=F2:89:18:5E:61:EE nodemac=4E:DA:66:71:3F:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.393Z",
  "value": "id=2698  sec_id=133233 flags=0x0000 ifindex=12  mac=0A:A7:5A:FC:DF:DE nodemac=7A:D7:A2:E9:65:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.393Z",
  "value": "id=3449  sec_id=133233 flags=0x0000 ifindex=14  mac=46:ED:F6:8A:FA:D4 nodemac=7A:B5:D5:4B:C6:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.393Z",
  "value": "id=1535  sec_id=4     flags=0x0000 ifindex=10  mac=52:12:B8:DE:A3:A3 nodemac=EA:8D:03:9B:71:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.393Z",
  "value": "id=1535  sec_id=4     flags=0x0000 ifindex=10  mac=52:12:B8:DE:A3:A3 nodemac=EA:8D:03:9B:71:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.393Z",
  "value": "id=2698  sec_id=133233 flags=0x0000 ifindex=12  mac=0A:A7:5A:FC:DF:DE nodemac=7A:D7:A2:E9:65:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.393Z",
  "value": "id=3449  sec_id=133233 flags=0x0000 ifindex=14  mac=46:ED:F6:8A:FA:D4 nodemac=7A:B5:D5:4B:C6:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.394Z",
  "value": "id=1335  sec_id=161722 flags=0x0000 ifindex=18  mac=F2:89:18:5E:61:EE nodemac=4E:DA:66:71:3F:E4"
}

