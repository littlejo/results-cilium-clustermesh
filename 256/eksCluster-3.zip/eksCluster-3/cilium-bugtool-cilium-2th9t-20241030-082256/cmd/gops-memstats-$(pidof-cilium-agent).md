alloc: 105.35MB (110468168 bytes)
total-alloc: 2.43GB (2606884128 bytes)
sys: 328.83MB (344805732 bytes)
lookups: 0
mallocs: 66481718
frees: 65649804
heap-alloc: 105.35MB (110468168 bytes)
heap-sys: 251.73MB (263954432 bytes)
heap-idle: 92.81MB (97320960 bytes)
heap-in-use: 158.91MB (166633472 bytes)
heap-released: 368.00KB (376832 bytes)
heap-objects: 831914
stack-in-use: 64.25MB (67371008 bytes)
stack-sys: 64.25MB (67371008 bytes)
stack-mspan-inuse: 2.72MB (2855520 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 996.22KB (1020129 bytes)
gc-sys: 6.05MB (6348192 bytes)
next-gc: when heap-alloc >= 211.48MB (221752296 bytes)
last-gc: 2024-10-30 08:23:22.81639599 +0000 UTC
gc-pause-total: 24.265515ms
gc-pause: 177455
gc-pause-end: 1730276602816395990
num-gc: 88
num-forced-gc: 0
gc-cpu-fraction: 0.000416345744171089
enable-gc: true
debug-gc: false
