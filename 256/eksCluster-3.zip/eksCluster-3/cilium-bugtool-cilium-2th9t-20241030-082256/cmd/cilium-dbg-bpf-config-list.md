KEY             VALUE
AgentLiveness   2301766585236
UTimeOffset     3379442005859375
