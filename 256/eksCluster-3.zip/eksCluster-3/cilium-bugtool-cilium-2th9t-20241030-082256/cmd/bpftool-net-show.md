xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 508
ens6(5) clsact/ingress cil_from_netdev-ens6 id 512
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 495
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 491
cilium_host(7) clsact/egress cil_from_host-cilium_host id 494
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 542
lxc8a3c52a2ce45(12) clsact/ingress cil_from_container-lxc8a3c52a2ce45 id 532
lxcfc8512e1127c(14) clsact/ingress cil_from_container-lxcfc8512e1127c id 556
lxcf57ed18009c3(18) clsact/ingress cil_from_container-lxcf57ed18009c3 id 624

flow_dissector:

netfilter:

