[
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36dc8ec0_cc3f_482a_942d_5c9a3a43405c.slice/cri-containerd-971503028795423284b48e9378e15b97a333f7d52757f36cc86b4db061e13302.scope"
      }
    ],
    "ips": [
      "10.3.0.254"
    ],
    "name": "coredns-cc6ccd49c-vq9cv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc719c502_70c5_40c0_a11c_737852648d58.slice/cri-containerd-bc86bb873bfd4704c83a3ab4e849f96cac3de115652926c3cd8523c6e309e8a0.scope"
      }
    ],
    "ips": [
      "10.3.0.79"
    ],
    "name": "coredns-cc6ccd49c-gdhrd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9316,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod264809ad_f640_4318_82be_a5902ae5e100.slice/cri-containerd-3334ac512d70fcc22cc65d93b453b29bb3e249b368798b6677154e0a65ccc873.scope"
      },
      {
        "cgroup-id": 9232,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod264809ad_f640_4318_82be_a5902ae5e100.slice/cri-containerd-296e0e600354833255991c07a714f333ac894330e69e548b2e7a9db378437ddd.scope"
      },
      {
        "cgroup-id": 9400,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod264809ad_f640_4318_82be_a5902ae5e100.slice/cri-containerd-bb4e1a9efd6c861b8f9901fc743fbbaf9fcd3fbe92ad68f23c39818cabd1cc3b.scope"
      }
    ],
    "ips": [
      "10.3.0.218"
    ],
    "name": "clustermesh-apiserver-f9bb6dcf9-88jhr",
    "namespace": "kube-system"
  }
]

