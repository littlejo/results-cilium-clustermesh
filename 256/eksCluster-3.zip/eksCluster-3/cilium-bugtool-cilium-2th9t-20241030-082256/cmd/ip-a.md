1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:31:2d:45:4c:f5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.226.7/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3140sec preferred_lft 3140sec
    inet6 fe80::831:2dff:fe45:4cf5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:cd:00:1e:af:f3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.203.127/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8cd:ff:fe1e:aff3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:79:f9:51:8c:46 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b079:f9ff:fe51:8c46/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:ae:81:42:40:6a brd ff:ff:ff:ff:ff:ff
    inet 10.3.0.212/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e4ae:81ff:fe42:406a/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether c2:df:8c:4b:24:2c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c0df:8cff:fe4b:242c/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:8d:03:9b:71:37 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::e88d:3ff:fe9b:7137/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc8a3c52a2ce45@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:d7:a2:e9:65:d9 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::78d7:a2ff:fee9:65d9/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcfc8512e1127c@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:b5:d5:4b:c6:55 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::78b5:d5ff:fe4b:c655/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf57ed18009c3@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:da:66:71:3f:e4 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::4cda:66ff:fe71:3fe4/64 scope link 
       valid_lft forever preferred_lft forever
