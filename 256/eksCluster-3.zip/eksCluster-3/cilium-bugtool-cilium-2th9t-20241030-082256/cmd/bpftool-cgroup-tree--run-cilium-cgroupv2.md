CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podef8e2b7b_4abf_42a9_908b_49b63e25cab7.slice/cri-containerd-6a750ac74859f34af35796c01ade0f18ece42f021579844e59d317869a5f5e80.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podef8e2b7b_4abf_42a9_908b_49b63e25cab7.slice/cri-containerd-4ad6200cad273fb2d46cc9ff63c6580dba8f630bc63ccf57646a9593139175ad.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc719c502_70c5_40c0_a11c_737852648d58.slice/cri-containerd-456b644eb62991adee5873f4a97d364f871b2ea4fcdebf22e5dd31dc27802972.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc719c502_70c5_40c0_a11c_737852648d58.slice/cri-containerd-bc86bb873bfd4704c83a3ab4e849f96cac3de115652926c3cd8523c6e309e8a0.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5220bc6e_f834_48a9_b66d_c82620efc522.slice/cri-containerd-33e16fe89f7d7066cb6678c54328afac5b987d43a205663e3aeb8932a400a253.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5220bc6e_f834_48a9_b66d_c82620efc522.slice/cri-containerd-12e3fbf0ea628ceda5e828f77b57b3a37218bc1873d1d618ee87eefa320c6206.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36dc8ec0_cc3f_482a_942d_5c9a3a43405c.slice/cri-containerd-971503028795423284b48e9378e15b97a333f7d52757f36cc86b4db061e13302.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36dc8ec0_cc3f_482a_942d_5c9a3a43405c.slice/cri-containerd-69dcb67d383350ece8431c5ab373943a5c4a9bd4a1519a842fa8066f050f6442.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod11cde510_9447_41fd_8ba3_936a53957799.slice/cri-containerd-30caa817fb8372088edaf5461f3a455006586e25be6e5d69fe77776ff7fa6daf.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod11cde510_9447_41fd_8ba3_936a53957799.slice/cri-containerd-bbe488ac1a68b942a5d91e41fa6c409f5f944fcfa2621e54bd17ac81cfa8bc52.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod264809ad_f640_4318_82be_a5902ae5e100.slice/cri-containerd-e5cdfb03298b3c983d8ebcc1572447d991e3d9359d44215bb896e104a0e544fb.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod264809ad_f640_4318_82be_a5902ae5e100.slice/cri-containerd-3334ac512d70fcc22cc65d93b453b29bb3e249b368798b6677154e0a65ccc873.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod264809ad_f640_4318_82be_a5902ae5e100.slice/cri-containerd-bb4e1a9efd6c861b8f9901fc743fbbaf9fcd3fbe92ad68f23c39818cabd1cc3b.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod264809ad_f640_4318_82be_a5902ae5e100.slice/cri-containerd-296e0e600354833255991c07a714f333ac894330e69e548b2e7a9db378437ddd.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1dc4725a_91d7_4498_8430_827ae411ff05.slice/cri-containerd-524f81b2cef8747f2aa19044ebb4973654fa9c84485714adc07b7f88ff05c60c.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1dc4725a_91d7_4498_8430_827ae411ff05.slice/cri-containerd-a42a7b087189b2a2b5b16374407b42e2c3be8602df4d0d778b1dba3f93a84ae2.scope
    109      cgroup_device   multi                                          
