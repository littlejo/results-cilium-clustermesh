Endpoint ID: 1335
Path: /sys/fs/bpf/tc/globals/cilium_policy_01335

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11673039   117124    0        
Allow    Ingress     1          ANY          NONE         disabled    10720316   113317    0        
Allow    Egress      0          ANY          NONE         disabled    13825839   135369    0        


Endpoint ID: 1535
Path: /sys/fs/bpf/tc/globals/cilium_policy_01535

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1665537   21097     0        
Allow    Ingress     1          ANY          NONE         disabled    26152     306       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2698
Path: /sys/fs/bpf/tc/globals/cilium_policy_02698

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    634095   5685      0        
Allow    Ingress     1          ANY          NONE         disabled    177652   2053      0        
Allow    Egress      0          ANY          NONE         disabled    147537   1395      0        


Endpoint ID: 2718
Path: /sys/fs/bpf/tc/globals/cilium_policy_02718

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3449
Path: /sys/fs/bpf/tc/globals/cilium_policy_03449

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    615057   5529      0        
Allow    Ingress     1          ANY          NONE         disabled    177093   2039      0        
Allow    Egress      0          ANY          NONE         disabled    144799   1376      0        


