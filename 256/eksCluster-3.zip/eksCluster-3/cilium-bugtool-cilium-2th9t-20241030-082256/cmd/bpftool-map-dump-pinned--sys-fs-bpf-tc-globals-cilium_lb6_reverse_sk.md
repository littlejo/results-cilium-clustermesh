Error: bpf obj get (/sys/fs/bpf/tc/globals/cilium_lb6_reverse_sk): No such file or directory
> Error while running 'bpftool map dump pinned /sys/fs/bpf/tc/globals/cilium_lb6_reverse_sk':  exit status 255

