 08:22:58 up 37 min,  0 users,  load average: 0.23, 0.22, 0.21
