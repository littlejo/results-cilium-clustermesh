ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.163.116:443 (active)   
                                         2 => 172.31.254.253:443 (active)   
2    10.100.151.110:443   ClusterIP      1 => 172.31.226.7:4244 (active)    
3    10.100.0.10:53       ClusterIP      1 => 10.3.0.79:53 (active)         
                                         2 => 10.3.0.254:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.3.0.79:9153 (active)       
                                         2 => 10.3.0.254:9153 (active)      
5    10.100.21.177:2379   ClusterIP      1 => 10.3.0.218:2379 (active)      
