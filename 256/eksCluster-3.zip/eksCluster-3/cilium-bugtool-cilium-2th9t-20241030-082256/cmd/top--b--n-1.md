top - 08:22:58 up 37 min,  0 users,  load average: 0.23, 0.22, 0.21
Tasks:   8 total,   3 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 56.2 us, 43.8 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4414.8 free,   1252.0 used,   2147.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6377.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    676 root      20   0 1244340  21972  13944 R  50.0   0.3   0:00.38 hubble
      1 root      20   0 1606144 395672  78528 S   6.2   4.9   0:55.46 cilium-+
    398 root      20   0 1229744   6988   2924 S   0.0   0.1   0:01.16 cilium-+
    646 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    657 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    698 root      20   0 1240432  16664  11420 D   0.0   0.2   0:00.03 cilium-+
    730 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    740 root      20   0 1240432  16664  11420 R   0.0   0.2   0:00.00 cilium-+
