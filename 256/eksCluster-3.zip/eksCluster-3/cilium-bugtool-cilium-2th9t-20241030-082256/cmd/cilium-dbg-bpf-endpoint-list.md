IP ADDRESS         LOCAL ENDPOINT INFO
10.3.0.218:0       id=1335  sec_id=161722 flags=0x0000 ifindex=18  mac=F2:89:18:5E:61:EE nodemac=4E:DA:66:71:3F:E4   
10.3.0.79:0        id=2698  sec_id=133233 flags=0x0000 ifindex=12  mac=0A:A7:5A:FC:DF:DE nodemac=7A:D7:A2:E9:65:D9   
172.31.226.7:0     (localhost)                                                                                       
10.3.0.254:0       id=3449  sec_id=133233 flags=0x0000 ifindex=14  mac=46:ED:F6:8A:FA:D4 nodemac=7A:B5:D5:4B:C6:55   
10.3.0.107:0       id=1535  sec_id=4     flags=0x0000 ifindex=10  mac=52:12:B8:DE:A3:A3 nodemac=EA:8D:03:9B:71:37    
172.31.203.127:0   (localhost)                                                                                       
10.3.0.212:0       (localhost)                                                                                       
