key: 37 05 00 00  value: 67 02 00 00
key: ff 05 00 00  value: 22 02 00 00
key: 8a 0a 00 00  value: 17 02 00 00
key: 79 0d 00 00  value: 21 02 00 00
Found 4 elements
