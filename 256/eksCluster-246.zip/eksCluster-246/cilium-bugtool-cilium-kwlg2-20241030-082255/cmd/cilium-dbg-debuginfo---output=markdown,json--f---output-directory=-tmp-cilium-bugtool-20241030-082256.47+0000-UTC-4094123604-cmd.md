markdown output at /tmp/cilium-bugtool-20241030-082256.47+0000-UTC-4094123604/cmd/cilium-debuginfo-20241030-082327.688+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082256.47+0000-UTC-4094123604/cmd/cilium-debuginfo-20241030-082327.688+0000-UTC.json
