KEY             VALUE
AgentLiveness   1645917044877
UTimeOffset     3379443285156250
