key: 0b 00 00 00  value: 0a f6 00 f3 09 4b 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 97 d7 10 94 00 00  00 00 00 00
key: 09 00 00 00  value: 0a f6 00 63 23 c1 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f a0 57 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a f6 00 2b 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f d2 9e 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a f6 00 63 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a f6 00 2b 23 c1 00 00  00 00 00 00
Found 8 elements
