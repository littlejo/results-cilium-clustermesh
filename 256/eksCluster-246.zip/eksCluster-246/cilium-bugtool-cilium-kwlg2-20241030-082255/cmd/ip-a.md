1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:29:f3:5b:19:c1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.151.215/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1995sec preferred_lft 1995sec
    inet6 fe80::429:f3ff:fe5b:19c1/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:fc:0b:42:ee:1d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.142.236/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4fc:bff:fe42:ee1d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:90:37:63:e2:b8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ac90:37ff:fe63:e2b8/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:ac:1d:64:d1:81 brd ff:ff:ff:ff:ff:ff
    inet 10.246.0.233/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::50ac:1dff:fe64:d181/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3e:e0:de:29:c2:83 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3ce0:deff:fe29:c283/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:91:61:13:2b:f9 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::fc91:61ff:fe13:2bf9/64 scope link 
       valid_lft forever preferred_lft forever
12: lxccdf5d1120b50@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:b1:81:3d:6e:81 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::2cb1:81ff:fe3d:6e81/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc3913b6af2df3@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:d6:ba:22:5f:84 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::fcd6:baff:fe22:5f84/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcd0932fe9a584@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:43:94:ce:f9:bf brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7843:94ff:fece:f9bf/64 scope link 
       valid_lft forever preferred_lft forever
