[
  {
    "containers": [
      {
        "cgroup-id": 7530,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7dae4037_7271_4d40_89fc_85cfff5b6c85.slice/cri-containerd-ddceed16a7a4984edc12eea3462c8b3529f396a7db55f6babf2483da29fb5c06.scope"
      }
    ],
    "ips": [
      "10.246.0.99"
    ],
    "name": "coredns-cc6ccd49c-pccxs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52ad2728_af85_460d_b954_6ce665cb495d.slice/cri-containerd-ae3278cdde9ae65753df3374375d5ffed0d83398e4a7d3644876b40efb310652.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52ad2728_af85_460d_b954_6ce665cb495d.slice/cri-containerd-729a03368a1c4edf85928863a0edfa892c4d2b1deb3c19f9114183a0d720be0e.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52ad2728_af85_460d_b954_6ce665cb495d.slice/cri-containerd-2591c960cf02a15d3d28bee3c90858fe1bc5e3460a75a0bb7ab1ce84eeaa256a.scope"
      }
    ],
    "ips": [
      "10.246.0.243"
    ],
    "name": "clustermesh-apiserver-7db87947cb-prp88",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9ec8e4d_4693_456f_af56_08b068f135ad.slice/cri-containerd-a0fd9b76f5690a446368014ff06d64cb5265cc9e1128f03d11b7a155edd52393.scope"
      }
    ],
    "ips": [
      "10.246.0.43"
    ],
    "name": "coredns-cc6ccd49c-rfn64",
    "namespace": "kube-system"
  }
]

