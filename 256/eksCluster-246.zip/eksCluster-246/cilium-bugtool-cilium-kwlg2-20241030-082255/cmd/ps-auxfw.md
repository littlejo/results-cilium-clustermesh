USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         656  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         649  2.0  0.2 1240432 16556 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         678  0.0  0.0   6408  1640 ?        R    08:22   0:00  \_ ps auxfw
root         679  0.0  0.0   2020   400 ?        R    08:22   0:00  \_ bash -c hostname
root         639  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         621  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.7  4.7 1606080 382672 ?      Rsl  08:03   0:42 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.0 1229744 7040 ?        Sl   08:04   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
