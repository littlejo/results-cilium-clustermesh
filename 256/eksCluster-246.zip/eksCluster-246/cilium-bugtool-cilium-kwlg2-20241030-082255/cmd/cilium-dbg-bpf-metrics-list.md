REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37817     2999400     677    bpf_overlay.c
Interface                 INGRESS     661973    134763857   1132   bpf_host.c
Success                   EGRESS      17655     1395452     1694   bpf_host.c
Success                   EGRESS      284525    35074534    1308   bpf_lxc.c
Success                   EGRESS      38761     3069518     53     encap.h
Success                   INGRESS     327688    37155695    86     l3.h
Success                   INGRESS     348501    38803689    235    trace.h
Unsupported L3 protocol   EGRESS      42        3152        1492   bpf_lxc.c
