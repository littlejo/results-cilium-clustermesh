Endpoint ID: 25
Path: /sys/fs/bpf/tc/globals/cilium_policy_00025

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11600975   116805    0        
Allow    Ingress     1          ANY          NONE         disabled    10775742   114065    0        
Allow    Egress      0          ANY          NONE         disabled    14552108   142320    0        


Endpoint ID: 182
Path: /sys/fs/bpf/tc/globals/cilium_policy_00182

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    110687   1273      0        
Allow    Egress      0          ANY          NONE         disabled    16100    174       0        


Endpoint ID: 574
Path: /sys/fs/bpf/tc/globals/cilium_policy_00574

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    110834   1277      0        
Allow    Egress      0          ANY          NONE         disabled    16309    176       0        


Endpoint ID: 600
Path: /sys/fs/bpf/tc/globals/cilium_policy_00600

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1650050   20840     0        
Allow    Ingress     1          ANY          NONE         disabled    17794     211       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1828
Path: /sys/fs/bpf/tc/globals/cilium_policy_01828

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


