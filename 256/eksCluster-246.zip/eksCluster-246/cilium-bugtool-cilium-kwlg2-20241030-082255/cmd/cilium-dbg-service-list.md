ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.160.87:443 (active)     
                                         2 => 172.31.210.158:443 (active)    
2    10.100.113.244:443   ClusterIP      1 => 172.31.151.215:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.246.0.43:53 (active)        
                                         2 => 10.246.0.99:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.246.0.43:9153 (active)      
                                         2 => 10.246.0.99:9153 (active)      
5    10.100.90.23:2379    ClusterIP      1 => 10.246.0.243:2379 (active)     
