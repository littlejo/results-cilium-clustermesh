key: 19 00 00 00  value: 8b 02 00 00
key: b6 00 00 00  value: 1e 02 00 00
key: 3e 02 00 00  value: 4e 02 00 00
key: 58 02 00 00  value: 38 02 00 00
Found 4 elements
