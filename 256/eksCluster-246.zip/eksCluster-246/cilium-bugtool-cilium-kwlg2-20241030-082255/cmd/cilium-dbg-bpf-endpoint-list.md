IP ADDRESS         LOCAL ENDPOINT INFO
10.246.0.233:0     (localhost)                                                                                        
10.246.0.243:0     id=25    sec_id=8096109 flags=0x0000 ifindex=18  mac=2E:98:66:02:E8:0D nodemac=7A:43:94:CE:F9:BF   
172.31.151.215:0   (localhost)                                                                                        
10.246.0.99:0      id=182   sec_id=8099506 flags=0x0000 ifindex=12  mac=FE:D5:B1:76:8C:A7 nodemac=2E:B1:81:3D:6E:81   
10.246.0.43:0      id=574   sec_id=8099506 flags=0x0000 ifindex=14  mac=DE:83:A5:99:99:AE nodemac=FE:D6:BA:22:5F:84   
10.246.0.37:0      id=600   sec_id=4     flags=0x0000 ifindex=10  mac=6E:16:24:76:96:DA nodemac=FE:91:61:13:2B:F9     
172.31.142.236:0   (localhost)                                                                                        
