qdisc noqueue 0: dev lo root refcnt 2 
qdisc mq 0: dev ens5 root 
qdisc fq_codel 0: dev ens5 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens5 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens5 parent ffff:fff1 
qdisc mq 0: dev ens6 root 
qdisc fq_codel 0: dev ens6 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens6 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens6 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
qdisc noqueue 0: dev lxccdf5d1120b50 root refcnt 2 
qdisc clsact ffff: dev lxccdf5d1120b50 parent ffff:fff1 
qdisc noqueue 0: dev lxc3913b6af2df3 root refcnt 2 
qdisc clsact ffff: dev lxc3913b6af2df3 parent ffff:fff1 
qdisc noqueue 0: dev lxcd0932fe9a584 root refcnt 2 
qdisc clsact ffff: dev lxcd0932fe9a584 parent ffff:fff1 
