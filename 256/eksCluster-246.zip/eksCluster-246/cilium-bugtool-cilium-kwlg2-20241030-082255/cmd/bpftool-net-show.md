xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 556
ens6(5) clsact/ingress cil_from_netdev-ens6 id 562
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 545
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 536
cilium_host(7) clsact/egress cil_from_host-cilium_host id 540
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 549
lxccdf5d1120b50(12) clsact/ingress cil_from_container-lxccdf5d1120b50 id 521
lxc3913b6af2df3(14) clsact/ingress cil_from_container-lxc3913b6af2df3 id 585
lxcd0932fe9a584(18) clsact/ingress cil_from_container-lxcd0932fe9a584 id 648

flow_dissector:

netfilter:

