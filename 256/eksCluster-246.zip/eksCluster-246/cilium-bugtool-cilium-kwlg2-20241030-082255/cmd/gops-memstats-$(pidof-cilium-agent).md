alloc: 193.21MB (202596296 bytes)
total-alloc: 2.30GB (2472655144 bytes)
sys: 332.77MB (348934500 bytes)
lookups: 0
mallocs: 64491029
frees: 62342681
heap-alloc: 193.21MB (202596296 bytes)
heap-sys: 255.45MB (267853824 bytes)
heap-idle: 42.29MB (44343296 bytes)
heap-in-use: 213.16MB (223510528 bytes)
heap-released: 13.78MB (14450688 bytes)
heap-objects: 2148348
stack-in-use: 64.53MB (67665920 bytes)
stack-sys: 64.53MB (67665920 bytes)
stack-mspan-inuse: 3.48MB (3651200 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1018.01KB (1042441 bytes)
gc-sys: 5.98MB (6274464 bytes)
next-gc: when heap-alloc >= 229.92MB (241090504 bytes)
last-gc: 2024-10-30 08:22:57.060188042 +0000 UTC
gc-pause-total: 16.93086ms
gc-pause: 9901220
gc-pause-end: 1730276577060188042
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005052061107334555
enable-gc: true
debug-gc: false
