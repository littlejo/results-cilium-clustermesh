CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ca00afb_18f9_47a1_b069_557ab3e29ece.slice/cri-containerd-e8d1f5e1af4d8b9c8279ad90b652f08c6fe674a0872fa96352a6568837ae508f.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ca00afb_18f9_47a1_b069_557ab3e29ece.slice/cri-containerd-9921a42da27338bcfcebb2b9d26ace20e8c4f2dd07710e94035ded2d5544bb66.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda582808e_aeb1_436f_b594_60b2040338dd.slice/cri-containerd-390e0a632b01e06dbc439027e09f6c310cdfd446eeb135cb5961140ea0608256.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda582808e_aeb1_436f_b594_60b2040338dd.slice/cri-containerd-5a356be0ee0b18b9281fbaf469681b93826b05d9e5fe36fa4afacca2810f0e21.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7dae4037_7271_4d40_89fc_85cfff5b6c85.slice/cri-containerd-ddceed16a7a4984edc12eea3462c8b3529f396a7db55f6babf2483da29fb5c06.scope
    584      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7dae4037_7271_4d40_89fc_85cfff5b6c85.slice/cri-containerd-3ab04e1a2b1f7649f888fb9f6153333eff216863eb1fbf483f4ad5c69701fbd4.scope
    580      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9ec8e4d_4693_456f_af56_08b068f135ad.slice/cri-containerd-8e38cca55988141538e8a610bc0fb0985973fcc9bbf95ea3669297473251d168.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9ec8e4d_4693_456f_af56_08b068f135ad.slice/cri-containerd-a0fd9b76f5690a446368014ff06d64cb5265cc9e1128f03d11b7a155edd52393.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5579941a_2889_440c_8113_c638bd5e4373.slice/cri-containerd-0ae5f8781a25a45d8e7f4e6798b5d1d2e76fcdcde74b5e3dcf73ce36460271e5.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5579941a_2889_440c_8113_c638bd5e4373.slice/cri-containerd-9c731d96acb3945ae2a7b4df329fcdcb0b122d378c343c359275a00263f2e8c5.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52ad2728_af85_460d_b954_6ce665cb495d.slice/cri-containerd-729a03368a1c4edf85928863a0edfa892c4d2b1deb3c19f9114183a0d720be0e.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52ad2728_af85_460d_b954_6ce665cb495d.slice/cri-containerd-2591c960cf02a15d3d28bee3c90858fe1bc5e3460a75a0bb7ab1ce84eeaa256a.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52ad2728_af85_460d_b954_6ce665cb495d.slice/cri-containerd-ae3278cdde9ae65753df3374375d5ffed0d83398e4a7d3644876b40efb310652.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52ad2728_af85_460d_b954_6ce665cb495d.slice/cri-containerd-85bd56c8acd7635e012dcaccbb6b88a9454fb93363e8018e2210217f083df26f.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2af73f25_4d2c_46b1_aa04_5fdb1103941b.slice/cri-containerd-16b2f9a8726e1f1d6834d4b40e4ec1daf2cd8cafe1ff7dcb4e94e6febb5a41e9.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2af73f25_4d2c_46b1_aa04_5fdb1103941b.slice/cri-containerd-c127627b2530947bbfbd66b699285f0acdcb36fe52144c8dacb7caf1fa505b81.scope
    113      cgroup_device   multi                                          
