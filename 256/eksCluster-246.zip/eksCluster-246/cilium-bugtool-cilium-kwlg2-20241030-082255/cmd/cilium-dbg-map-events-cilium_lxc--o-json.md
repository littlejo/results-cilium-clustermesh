{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:06.336Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.142.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:06.336Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.151.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:06.336Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.586Z",
  "value": "id=600   sec_id=4     flags=0x0000 ifindex=10  mac=6E:16:24:76:96:DA nodemac=FE:91:61:13:2B:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.591Z",
  "value": "id=182   sec_id=8099506 flags=0x0000 ifindex=12  mac=FE:D5:B1:76:8C:A7 nodemac=2E:B1:81:3D:6E:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.626Z",
  "value": "id=600   sec_id=4     flags=0x0000 ifindex=10  mac=6E:16:24:76:96:DA nodemac=FE:91:61:13:2B:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:11.382Z",
  "value": "id=574   sec_id=8099506 flags=0x0000 ifindex=14  mac=DE:83:A5:99:99:AE nodemac=FE:D6:BA:22:5F:84"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:08.299Z",
  "value": "id=182   sec_id=8099506 flags=0x0000 ifindex=12  mac=FE:D5:B1:76:8C:A7 nodemac=2E:B1:81:3D:6E:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:08.299Z",
  "value": "id=574   sec_id=8099506 flags=0x0000 ifindex=14  mac=DE:83:A5:99:99:AE nodemac=FE:D6:BA:22:5F:84"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:08.300Z",
  "value": "id=600   sec_id=4     flags=0x0000 ifindex=10  mac=6E:16:24:76:96:DA nodemac=FE:91:61:13:2B:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:08.328Z",
  "value": "id=1221  sec_id=8096109 flags=0x0000 ifindex=16  mac=EE:C9:3C:D9:ED:4C nodemac=82:FE:A6:E8:B5:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:08.328Z",
  "value": "id=1221  sec_id=8096109 flags=0x0000 ifindex=16  mac=EE:C9:3C:D9:ED:4C nodemac=82:FE:A6:E8:B5:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:56.878Z",
  "value": "id=25    sec_id=8096109 flags=0x0000 ifindex=18  mac=2E:98:66:02:E8:0D nodemac=7A:43:94:CE:F9:BF"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.246.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.225Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.282Z",
  "value": "id=182   sec_id=8099506 flags=0x0000 ifindex=12  mac=FE:D5:B1:76:8C:A7 nodemac=2E:B1:81:3D:6E:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.283Z",
  "value": "id=574   sec_id=8099506 flags=0x0000 ifindex=14  mac=DE:83:A5:99:99:AE nodemac=FE:D6:BA:22:5F:84"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.283Z",
  "value": "id=25    sec_id=8096109 flags=0x0000 ifindex=18  mac=2E:98:66:02:E8:0D nodemac=7A:43:94:CE:F9:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.285Z",
  "value": "id=600   sec_id=4     flags=0x0000 ifindex=10  mac=6E:16:24:76:96:DA nodemac=FE:91:61:13:2B:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.287Z",
  "value": "id=600   sec_id=4     flags=0x0000 ifindex=10  mac=6E:16:24:76:96:DA nodemac=FE:91:61:13:2B:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.291Z",
  "value": "id=182   sec_id=8099506 flags=0x0000 ifindex=12  mac=FE:D5:B1:76:8C:A7 nodemac=2E:B1:81:3D:6E:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.291Z",
  "value": "id=574   sec_id=8099506 flags=0x0000 ifindex=14  mac=DE:83:A5:99:99:AE nodemac=FE:D6:BA:22:5F:84"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.292Z",
  "value": "id=25    sec_id=8096109 flags=0x0000 ifindex=18  mac=2E:98:66:02:E8:0D nodemac=7A:43:94:CE:F9:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.286Z",
  "value": "id=182   sec_id=8099506 flags=0x0000 ifindex=12  mac=FE:D5:B1:76:8C:A7 nodemac=2E:B1:81:3D:6E:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.287Z",
  "value": "id=600   sec_id=4     flags=0x0000 ifindex=10  mac=6E:16:24:76:96:DA nodemac=FE:91:61:13:2B:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.287Z",
  "value": "id=574   sec_id=8099506 flags=0x0000 ifindex=14  mac=DE:83:A5:99:99:AE nodemac=FE:D6:BA:22:5F:84"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.287Z",
  "value": "id=25    sec_id=8096109 flags=0x0000 ifindex=18  mac=2E:98:66:02:E8:0D nodemac=7A:43:94:CE:F9:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.287Z",
  "value": "id=574   sec_id=8099506 flags=0x0000 ifindex=14  mac=DE:83:A5:99:99:AE nodemac=FE:D6:BA:22:5F:84"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.287Z",
  "value": "id=25    sec_id=8096109 flags=0x0000 ifindex=18  mac=2E:98:66:02:E8:0D nodemac=7A:43:94:CE:F9:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.288Z",
  "value": "id=182   sec_id=8099506 flags=0x0000 ifindex=12  mac=FE:D5:B1:76:8C:A7 nodemac=2E:B1:81:3D:6E:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.246.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.288Z",
  "value": "id=600   sec_id=4     flags=0x0000 ifindex=10  mac=6E:16:24:76:96:DA nodemac=FE:91:61:13:2B:F9"
}

