filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcd0932fe9a584 direct-action not_in_hw id 648 tag 42b9a36d2455b1bc jited 
