{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:35.585Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.135.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:35.585Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.173.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:35.585Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:40.054Z",
  "value": "id=2200  sec_id=4     flags=0x0000 ifindex=10  mac=E6:9D:68:D9:13:45 nodemac=72:24:14:5A:BB:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:40.063Z",
  "value": "id=2636  sec_id=7077103 flags=0x0000 ifindex=12  mac=42:0E:40:D8:AB:41 nodemac=02:F3:F8:D1:4B:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:40.139Z",
  "value": "id=2795  sec_id=7077103 flags=0x0000 ifindex=14  mac=82:D6:2E:33:32:17 nodemac=EA:05:A2:2C:43:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:40.155Z",
  "value": "id=2200  sec_id=4     flags=0x0000 ifindex=10  mac=E6:9D:68:D9:13:45 nodemac=72:24:14:5A:BB:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:27.232Z",
  "value": "id=2200  sec_id=4     flags=0x0000 ifindex=10  mac=E6:9D:68:D9:13:45 nodemac=72:24:14:5A:BB:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:27.233Z",
  "value": "id=2636  sec_id=7077103 flags=0x0000 ifindex=12  mac=42:0E:40:D8:AB:41 nodemac=02:F3:F8:D1:4B:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:27.233Z",
  "value": "id=2795  sec_id=7077103 flags=0x0000 ifindex=14  mac=82:D6:2E:33:32:17 nodemac=EA:05:A2:2C:43:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:27.265Z",
  "value": "id=2938  sec_id=7057867 flags=0x0000 ifindex=16  mac=FE:F6:64:7C:07:FC nodemac=AE:4F:2F:60:28:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:28.232Z",
  "value": "id=2200  sec_id=4     flags=0x0000 ifindex=10  mac=E6:9D:68:D9:13:45 nodemac=72:24:14:5A:BB:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:28.233Z",
  "value": "id=2636  sec_id=7077103 flags=0x0000 ifindex=12  mac=42:0E:40:D8:AB:41 nodemac=02:F3:F8:D1:4B:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:28.233Z",
  "value": "id=2795  sec_id=7077103 flags=0x0000 ifindex=14  mac=82:D6:2E:33:32:17 nodemac=EA:05:A2:2C:43:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:28.233Z",
  "value": "id=2938  sec_id=7057867 flags=0x0000 ifindex=16  mac=FE:F6:64:7C:07:FC nodemac=AE:4F:2F:60:28:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.400Z",
  "value": "id=1988  sec_id=7057867 flags=0x0000 ifindex=18  mac=66:A0:5F:9C:DC:A5 nodemac=46:81:99:70:B2:31"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.214.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.707Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.014Z",
  "value": "id=1988  sec_id=7057867 flags=0x0000 ifindex=18  mac=66:A0:5F:9C:DC:A5 nodemac=46:81:99:70:B2:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.015Z",
  "value": "id=2200  sec_id=4     flags=0x0000 ifindex=10  mac=E6:9D:68:D9:13:45 nodemac=72:24:14:5A:BB:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.016Z",
  "value": "id=2636  sec_id=7077103 flags=0x0000 ifindex=12  mac=42:0E:40:D8:AB:41 nodemac=02:F3:F8:D1:4B:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.016Z",
  "value": "id=2795  sec_id=7077103 flags=0x0000 ifindex=14  mac=82:D6:2E:33:32:17 nodemac=EA:05:A2:2C:43:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.015Z",
  "value": "id=2200  sec_id=4     flags=0x0000 ifindex=10  mac=E6:9D:68:D9:13:45 nodemac=72:24:14:5A:BB:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.015Z",
  "value": "id=2795  sec_id=7077103 flags=0x0000 ifindex=14  mac=82:D6:2E:33:32:17 nodemac=EA:05:A2:2C:43:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.015Z",
  "value": "id=1988  sec_id=7057867 flags=0x0000 ifindex=18  mac=66:A0:5F:9C:DC:A5 nodemac=46:81:99:70:B2:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.015Z",
  "value": "id=2636  sec_id=7077103 flags=0x0000 ifindex=12  mac=42:0E:40:D8:AB:41 nodemac=02:F3:F8:D1:4B:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.015Z",
  "value": "id=1988  sec_id=7057867 flags=0x0000 ifindex=18  mac=66:A0:5F:9C:DC:A5 nodemac=46:81:99:70:B2:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.015Z",
  "value": "id=2200  sec_id=4     flags=0x0000 ifindex=10  mac=E6:9D:68:D9:13:45 nodemac=72:24:14:5A:BB:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.015Z",
  "value": "id=2636  sec_id=7077103 flags=0x0000 ifindex=12  mac=42:0E:40:D8:AB:41 nodemac=02:F3:F8:D1:4B:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.016Z",
  "value": "id=2795  sec_id=7077103 flags=0x0000 ifindex=14  mac=82:D6:2E:33:32:17 nodemac=EA:05:A2:2C:43:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.015Z",
  "value": "id=2795  sec_id=7077103 flags=0x0000 ifindex=14  mac=82:D6:2E:33:32:17 nodemac=EA:05:A2:2C:43:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.015Z",
  "value": "id=2200  sec_id=4     flags=0x0000 ifindex=10  mac=E6:9D:68:D9:13:45 nodemac=72:24:14:5A:BB:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.016Z",
  "value": "id=1988  sec_id=7057867 flags=0x0000 ifindex=18  mac=66:A0:5F:9C:DC:A5 nodemac=46:81:99:70:B2:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.214.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.016Z",
  "value": "id=2636  sec_id=7077103 flags=0x0000 ifindex=12  mac=42:0E:40:D8:AB:41 nodemac=02:F3:F8:D1:4B:7E"
}

