CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod00d0ac75_653a_44c0_952c_8041262bb866.slice/cri-containerd-039ed416122843c032c2edc69281d60ee704a9c35450ef7f7d8123c3d9770720.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod00d0ac75_653a_44c0_952c_8041262bb866.slice/cri-containerd-1dbf0f1b4bf72f763c196f301ccdb57018e67450e7e001858497d4ce9be117e3.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c6c5181_644f_4533_90b9_5c411a337fda.slice/cri-containerd-e88fc6b2b7242470ab6081f36b6c9701363346def876bf619d612e3caa90242b.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c6c5181_644f_4533_90b9_5c411a337fda.slice/cri-containerd-f441f3d253710cd2e13e99321d4b40006fd6eb576810314109fa26fd0961886e.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc6ee016f_c059_411e_b6b4_f434f47ef3cd.slice/cri-containerd-c554b3cf84321c1c967041cb3dc0ae56a6d78f2da98cd1d19fd5fc044a810758.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc6ee016f_c059_411e_b6b4_f434f47ef3cd.slice/cri-containerd-5d4c7bb9636cada3a4f8d46a421e79474e56ecd7bbbfdf3fce2db86c921b520a.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7f09f401_6b7a_40fc_a127_083d4f093b68.slice/cri-containerd-ec26c0bd9a38cb24b1f7bac9ae6349fc2e919a4f4f41625fb409b6f20780ef02.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7f09f401_6b7a_40fc_a127_083d4f093b68.slice/cri-containerd-9596744a4de66c233b21239a00ff62e1f9faa84dd84056c0da9feaf6c001b463.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7577b9f0_7776_4caa_8fcf_8317a81edb93.slice/cri-containerd-76ec421079441c0f60fc251232a1b40c1fe2c46364bbb7076c4aa09baca5ff26.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7577b9f0_7776_4caa_8fcf_8317a81edb93.slice/cri-containerd-13c01b8331377afdeda7ef537cb60f010bdceb5bb675a79c11b7b0042d29e8bf.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod912c8aa0_7652_4f3a_b5de_cc6b02b362b7.slice/cri-containerd-0d0ea442d882d08214649a75bbcdea5b22428639569284e35679a68b6c1983cb.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod912c8aa0_7652_4f3a_b5de_cc6b02b362b7.slice/cri-containerd-60b23485a87adf676bb002c733d2d6fbf95c3b7fa33a97146f4243789ffcc00f.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod912c8aa0_7652_4f3a_b5de_cc6b02b362b7.slice/cri-containerd-e9054c8b20d8093d0f17a03e19bc982eccb7006b0d469fbd24f8937e9c3f39a0.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod912c8aa0_7652_4f3a_b5de_cc6b02b362b7.slice/cri-containerd-0073070f96860be3ff85f3c52c3a43d54e09fc7d27b9ac676067cf92e5990220.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4394814b_745e_46b5_9535_13d04da07ebb.slice/cri-containerd-e65c8c1012526cd83c14a779411576fb62008000862a88ab9988cca65ef7178f.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4394814b_745e_46b5_9535_13d04da07ebb.slice/cri-containerd-b6a456c0bbfbe5dffd1ec03eab69b185102cdf17dbba90bf07eb58bf88d1fe0b.scope
    103      cgroup_device   multi                                          
