KEY             VALUE
AgentLiveness   1727143279699
UTimeOffset     3379443121093750
