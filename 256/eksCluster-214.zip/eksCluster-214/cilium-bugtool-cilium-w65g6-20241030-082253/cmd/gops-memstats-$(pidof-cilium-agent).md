alloc: 205.00MB (214953728 bytes)
total-alloc: 2.21GB (2367897144 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 62833589
frees: 60627540
heap-alloc: 205.00MB (214953728 bytes)
heap-sys: 247.36MB (259375104 bytes)
heap-idle: 16.66MB (17473536 bytes)
heap-in-use: 230.70MB (241901568 bytes)
heap-released: 2.78MB (2916352 bytes)
heap-objects: 2206049
stack-in-use: 68.22MB (71532544 bytes)
stack-sys: 68.22MB (71532544 bytes)
stack-mspan-inuse: 3.63MB (3801600 bytes)
stack-mspan-sys: 3.89MB (4080000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 953.35KB (976233 bytes)
gc-sys: 6.40MB (6708736 bytes)
next-gc: when heap-alloc >= 211.54MB (221812536 bytes)
last-gc: 2024-10-30 08:22:46.494167638 +0000 UTC
gc-pause-total: 22.861639ms
gc-pause: 108009
gc-pause-end: 1730276566494167638
num-gc: 79
num-forced-gc: 0
gc-cpu-fraction: 0.0004625245264265726
enable-gc: true
debug-gc: false
