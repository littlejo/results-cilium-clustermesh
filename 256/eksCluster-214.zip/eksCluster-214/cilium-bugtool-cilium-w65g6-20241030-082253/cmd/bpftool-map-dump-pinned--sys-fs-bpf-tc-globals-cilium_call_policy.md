key: c4 07 00 00  value: 7d 02 00 00
key: 98 08 00 00  value: 43 02 00 00
key: 4c 0a 00 00  value: 12 02 00 00
key: eb 0a 00 00  value: 42 02 00 00
Found 4 elements
