[
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod912c8aa0_7652_4f3a_b5de_cc6b02b362b7.slice/cri-containerd-0073070f96860be3ff85f3c52c3a43d54e09fc7d27b9ac676067cf92e5990220.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod912c8aa0_7652_4f3a_b5de_cc6b02b362b7.slice/cri-containerd-60b23485a87adf676bb002c733d2d6fbf95c3b7fa33a97146f4243789ffcc00f.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod912c8aa0_7652_4f3a_b5de_cc6b02b362b7.slice/cri-containerd-e9054c8b20d8093d0f17a03e19bc982eccb7006b0d469fbd24f8937e9c3f39a0.scope"
      }
    ],
    "ips": [
      "10.214.0.39"
    ],
    "name": "clustermesh-apiserver-66bf55dffd-njzz5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod00d0ac75_653a_44c0_952c_8041262bb866.slice/cri-containerd-039ed416122843c032c2edc69281d60ee704a9c35450ef7f7d8123c3d9770720.scope"
      }
    ],
    "ips": [
      "10.214.0.222"
    ],
    "name": "coredns-cc6ccd49c-b7df7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c6c5181_644f_4533_90b9_5c411a337fda.slice/cri-containerd-f441f3d253710cd2e13e99321d4b40006fd6eb576810314109fa26fd0961886e.scope"
      }
    ],
    "ips": [
      "10.214.0.202"
    ],
    "name": "coredns-cc6ccd49c-z6c2z",
    "namespace": "kube-system"
  }
]

