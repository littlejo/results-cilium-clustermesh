ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.254.205:443 (active)    
                                         2 => 172.31.165.124:443 (active)    
2    10.100.200.181:443   ClusterIP      1 => 172.31.135.249:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.214.0.202:53 (active)       
                                         2 => 10.214.0.222:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.214.0.202:9153 (active)     
                                         2 => 10.214.0.222:9153 (active)     
5    10.100.48.245:2379   ClusterIP      1 => 10.214.0.39:2379 (active)      
