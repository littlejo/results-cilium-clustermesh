REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35617     2815825     677    bpf_overlay.c
Interface                 INGRESS     635459    130902852   1132   bpf_host.c
Success                   EGRESS      15405     1207252     1694   bpf_host.c
Success                   EGRESS      268549    33774799    1308   bpf_lxc.c
Success                   EGRESS      35207     2783185     53     encap.h
Success                   INGRESS     311481    35111096    86     l3.h
Success                   INGRESS     332344    36763715    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
