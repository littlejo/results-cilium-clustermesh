1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:fd:4a:aa:0b:09 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.135.249/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1913sec preferred_lft 1913sec
    inet6 fe80::4fd:4aff:feaa:b09/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d3:f9:d6:2c:f1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.173.143/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4d3:f9ff:fed6:2cf1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:95:86:8c:26:e2 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4c95:86ff:fe8c:26e2/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:12:26:94:0e:1f brd ff:ff:ff:ff:ff:ff
    inet 10.214.0.94/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::9c12:26ff:fe94:e1f/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether fe:31:75:ed:33:ef brd ff:ff:ff:ff:ff:ff
    inet6 fe80::fc31:75ff:feed:33ef/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:24:14:5a:bb:c4 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::7024:14ff:fe5a:bbc4/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc9c6d415c82ae@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:f3:f8:d1:4b:7e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f3:f8ff:fed1:4b7e/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc5d0b58488a37@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:05:a2:2c:43:93 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e805:a2ff:fe2c:4393/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc842c8a2c8d37@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:81:99:70:b2:31 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::4481:99ff:fe70:b231/64 scope link 
       valid_lft forever preferred_lft forever
