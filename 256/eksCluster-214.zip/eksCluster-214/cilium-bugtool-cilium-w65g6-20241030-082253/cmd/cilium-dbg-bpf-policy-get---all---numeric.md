Endpoint ID: 1306
Path: /sys/fs/bpf/tc/globals/cilium_policy_01306

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1988
Path: /sys/fs/bpf/tc/globals/cilium_policy_01988

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11608506   115453    0        
Allow    Ingress     1          ANY          NONE         disabled    9785565    102891    0        
Allow    Egress      0          ANY          NONE         disabled    12556718   123390    0        


Endpoint ID: 2200
Path: /sys/fs/bpf/tc/globals/cilium_policy_02200

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1656957   20916     0        
Allow    Ingress     1          ANY          NONE         disabled    17816     211       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2636
Path: /sys/fs/bpf/tc/globals/cilium_policy_02636

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112378   1288      0        
Allow    Egress      0          ANY          NONE         disabled    16743    181       0        


Endpoint ID: 2795
Path: /sys/fs/bpf/tc/globals/cilium_policy_02795

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112444   1289      0        
Allow    Egress      0          ANY          NONE         disabled    16577    177       0        


