top - 08:22:54 up 28 min,  0 users,  load average: 0.32, 0.20, 0.14
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 38.7 us, 35.5 sy,  0.0 ni, 12.9 id,  0.0 wa,  0.0 hi, 12.9 si,  0.0 st
MiB Mem :   7814.2 total,   4469.6 free,   1198.7 used,   2145.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6430.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    709 root      20   0 1244596  21848  14004 S  40.0   0.3   0:00.06 hubble
      1 root      20   0 1606080 384428  78712 S  13.3   4.8   0:40.46 cilium-+
    394 root      20   0 1229488   6936   2924 S   0.0   0.1   0:01.05 cilium-+
    639 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    640 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    664 root      20   0 1240432  16496  11292 S   0.0   0.2   0:00.02 cilium-+
    697 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    701 root      20   0    2208    780    700 S   0.0   0.0   0:00.00 timeout
    729 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
