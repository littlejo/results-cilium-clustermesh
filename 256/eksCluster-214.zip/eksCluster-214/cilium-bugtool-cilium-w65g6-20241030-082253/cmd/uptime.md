 08:22:54 up 28 min,  0 users,  load average: 0.32, 0.20, 0.14
