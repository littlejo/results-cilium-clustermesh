filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc842c8a2c8d37 direct-action not_in_hw id 641 tag 2738b64a9f1c9b97 jited 
