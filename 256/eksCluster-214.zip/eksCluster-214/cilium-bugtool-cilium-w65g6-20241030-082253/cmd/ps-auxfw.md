USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         679  0.0  0.1 1615752 8388 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         664  0.0  0.2 1240432 16496 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         684  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         687  0.0  0.0   3728   472 ?        R    08:22   0:00  \_ bash -c hostname
root         640  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         639  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.4  4.8 1606080 384428 ?      Ssl  08:03   0:40 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.0  0.0 1229488 6936 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
