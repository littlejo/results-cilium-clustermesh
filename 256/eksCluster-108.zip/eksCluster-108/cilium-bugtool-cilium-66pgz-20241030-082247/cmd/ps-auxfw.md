USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         715  0.0  0.0 1228488 1756 ?        Rsl  08:22   0:00 /bin/gops pprof-cpu 1
root         693  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         687  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         674  2.0  0.2 1240432 16420 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         721  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         722  0.0  0.2 1240432 16420 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  2.7  4.7 1606080 379412 ?      Ssl  07:54   0:47 cilium-agent --config-dir=/tmp/cilium/config-map
root         400  0.0  0.1 1229744 8200 ?        Sl   07:54   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
