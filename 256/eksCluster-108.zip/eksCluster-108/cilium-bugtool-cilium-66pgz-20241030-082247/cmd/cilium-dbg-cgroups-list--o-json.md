[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9b517ffa_a17c_48e0_abb6_e58909e3c81e.slice/cri-containerd-c6b0bd67f5004bf98fe1c605bc27e32b468dfbbc1bf89d07845f7e2c43a2af03.scope"
      }
    ],
    "ips": [
      "10.108.0.229"
    ],
    "name": "coredns-cc6ccd49c-4h4vv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04a737cd_4bb3_4c47_99da_c87a31fe657d.slice/cri-containerd-01b57721aa866aa954a10a2ba51d2142df4e21be686c85dcc206c269de640374.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04a737cd_4bb3_4c47_99da_c87a31fe657d.slice/cri-containerd-431e97b24e42bf819688d88fbb1639dac17ba58075f1789b2f20427e1cb919f0.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04a737cd_4bb3_4c47_99da_c87a31fe657d.slice/cri-containerd-b521dc2b9f25ae7b1afc56a48f4ff447136c1a6cd8ee0d3e399e4d17dc24617a.scope"
      }
    ],
    "ips": [
      "10.108.0.201"
    ],
    "name": "clustermesh-apiserver-69649d9fd6-plzg2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7614,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda5b7979a_4460_4e00_91a6_407c0429bfd5.slice/cri-containerd-a49334b9c6826c858d240ebbd2872806f80c82323682fb94ad6e0a2d4fbb61a5.scope"
      }
    ],
    "ips": [
      "10.108.0.157"
    ],
    "name": "coredns-cc6ccd49c-rskpj",
    "namespace": "kube-system"
  }
]

