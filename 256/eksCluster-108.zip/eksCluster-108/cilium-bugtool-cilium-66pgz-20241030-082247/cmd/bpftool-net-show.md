xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 589
ens6(5) clsact/ingress cil_from_netdev-ens6 id 592
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 580
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 573
cilium_host(7) clsact/egress cil_from_host-cilium_host id 574
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 505
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 504
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 542
lxca6f2c4101b9d(12) clsact/ingress cil_from_container-lxca6f2c4101b9d id 529
lxc3eb839b1d74a(14) clsact/ingress cil_from_container-lxc3eb839b1d74a id 563
lxcd6d7597196ef(18) clsact/ingress cil_from_container-lxcd6d7597196ef id 643

flow_dissector:

netfilter:

