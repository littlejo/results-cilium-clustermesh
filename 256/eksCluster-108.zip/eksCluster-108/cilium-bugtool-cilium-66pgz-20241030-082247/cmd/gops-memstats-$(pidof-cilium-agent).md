alloc: 151.09MB (158426656 bytes)
total-alloc: 2.33GB (2500350264 bytes)
sys: 332.77MB (348934500 bytes)
lookups: 0
mallocs: 64668487
frees: 63021337
heap-alloc: 151.09MB (158426656 bytes)
heap-sys: 255.32MB (267722752 bytes)
heap-idle: 76.47MB (80183296 bytes)
heap-in-use: 178.85MB (187539456 bytes)
heap-released: 13.59MB (14254080 bytes)
heap-objects: 1647150
stack-in-use: 64.66MB (67796992 bytes)
stack-sys: 64.66MB (67796992 bytes)
stack-mspan-inuse: 3.04MB (3188320 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1004.34KB (1028441 bytes)
gc-sys: 6.02MB (6317664 bytes)
next-gc: when heap-alloc >= 213.91MB (224304024 bytes)
last-gc: 2024-10-30 08:22:53.596262896 +0000 UTC
gc-pause-total: 8.088338ms
gc-pause: 103600
gc-pause-end: 1730276573596262896
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0003459878759068442
enable-gc: true
debug-gc: false
