CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9b517ffa_a17c_48e0_abb6_e58909e3c81e.slice/cri-containerd-c6b0bd67f5004bf98fe1c605bc27e32b468dfbbc1bf89d07845f7e2c43a2af03.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9b517ffa_a17c_48e0_abb6_e58909e3c81e.slice/cri-containerd-3f25f53d936b94cf7b210110ccf2cdac62a00ab3c0fa16d710064faebba93170.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda5b7979a_4460_4e00_91a6_407c0429bfd5.slice/cri-containerd-a49334b9c6826c858d240ebbd2872806f80c82323682fb94ad6e0a2d4fbb61a5.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda5b7979a_4460_4e00_91a6_407c0429bfd5.slice/cri-containerd-de9bb4e4e0beb99da7f215915fc73ab7db6391d36e75db34737a360649db4b0c.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8cf360e7_a4ed_49e5_a433_63d4cc63bfd6.slice/cri-containerd-10fe0e7958409aba09ee7ab53774d5677ae951e7ab5c20d61ba8f458423671b7.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8cf360e7_a4ed_49e5_a433_63d4cc63bfd6.slice/cri-containerd-9a557718e1456ea50c59aaa34e515e56351bf14a3c5a86063a1d19cc32498579.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e80ac9b_86ad_4f09_8e1d_e9217a4cfa3b.slice/cri-containerd-a680d7a9831e6d68505cc34386fd6f1fb5cd81e0a6250985ca5c661d1144edee.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e80ac9b_86ad_4f09_8e1d_e9217a4cfa3b.slice/cri-containerd-e035668a0f215b5d13c689176918eeb5344477b42b20386e654474c780a261ca.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podefa7db05_4544_4368_8532_c9c03102b0fc.slice/cri-containerd-9cf6983627d31d2c8bc5b7044cdbfafe273a649b89f2d2ae454c128e2ed3cb2b.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podefa7db05_4544_4368_8532_c9c03102b0fc.slice/cri-containerd-4a41994385de6f01513ea91d5d4ac6257e638e0ba2571028de98f3a735e73cfa.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04a737cd_4bb3_4c47_99da_c87a31fe657d.slice/cri-containerd-b960db3f9b0d9be2b6ea79d91ad735c9cd859c336037e9b5120c33ab828dea58.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04a737cd_4bb3_4c47_99da_c87a31fe657d.slice/cri-containerd-01b57721aa866aa954a10a2ba51d2142df4e21be686c85dcc206c269de640374.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04a737cd_4bb3_4c47_99da_c87a31fe657d.slice/cri-containerd-431e97b24e42bf819688d88fbb1639dac17ba58075f1789b2f20427e1cb919f0.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04a737cd_4bb3_4c47_99da_c87a31fe657d.slice/cri-containerd-b521dc2b9f25ae7b1afc56a48f4ff447136c1a6cd8ee0d3e399e4d17dc24617a.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3998b9f7_a264_4781_97f1_834819c13f2f.slice/cri-containerd-7a243314dba79fdc6cbe3160c9ac7eca93f712301e72c180a54440da56150428.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3998b9f7_a264_4781_97f1_834819c13f2f.slice/cri-containerd-839e53046cdab910ecbb0e8f109e8fe559fe4c798e2378181b7c2eac9008e31c.scope
    97       cgroup_device   multi                                          
