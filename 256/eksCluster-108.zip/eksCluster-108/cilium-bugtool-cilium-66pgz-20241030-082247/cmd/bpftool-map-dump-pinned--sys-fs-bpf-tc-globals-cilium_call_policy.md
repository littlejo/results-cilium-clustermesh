key: f2 00 00 00  value: 2f 02 00 00
key: 7d 05 00 00  value: 20 02 00 00
key: 49 07 00 00  value: 84 02 00 00
key: 43 0e 00 00  value: 14 02 00 00
Found 4 elements
