REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36701     2905130     677    bpf_overlay.c
Interface                 INGRESS     661557    135057331   1132   bpf_host.c
Success                   EGRESS      16550     1302869     1694   bpf_host.c
Success                   EGRESS      282477    34829399    1308   bpf_lxc.c
Success                   EGRESS      37104     2931686     53     encap.h
Success                   INGRESS     323809    36835836    86     l3.h
Success                   INGRESS     344611    38482143    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
