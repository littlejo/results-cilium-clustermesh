KEY             VALUE
AgentLiveness   2150232055655
UTimeOffset     3379442283203125
