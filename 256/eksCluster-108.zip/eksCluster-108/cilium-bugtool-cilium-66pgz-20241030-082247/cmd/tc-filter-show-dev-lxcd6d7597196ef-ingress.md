filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcd6d7597196ef direct-action not_in_hw id 643 tag 9aea3a163874ee72 jited 
