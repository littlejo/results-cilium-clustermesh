{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:30.673Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.141.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:30.674Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.170.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:30.674Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:33.656Z",
  "value": "id=3651  sec_id=3577125 flags=0x0000 ifindex=12  mac=9A:88:5D:3A:4C:F8 nodemac=2A:8F:20:B3:5F:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:36.631Z",
  "value": "id=1405  sec_id=4     flags=0x0000 ifindex=10  mac=3A:F3:73:AB:42:97 nodemac=22:51:2C:BA:33:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:36.639Z",
  "value": "id=242   sec_id=3577125 flags=0x0000 ifindex=14  mac=CA:28:16:25:F9:46 nodemac=CA:01:C0:42:A5:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:36.673Z",
  "value": "id=3651  sec_id=3577125 flags=0x0000 ifindex=12  mac=9A:88:5D:3A:4C:F8 nodemac=2A:8F:20:B3:5F:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:36.729Z",
  "value": "id=1405  sec_id=4     flags=0x0000 ifindex=10  mac=3A:F3:73:AB:42:97 nodemac=22:51:2C:BA:33:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:36.795Z",
  "value": "id=242   sec_id=3577125 flags=0x0000 ifindex=14  mac=CA:28:16:25:F9:46 nodemac=CA:01:C0:42:A5:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:45.218Z",
  "value": "id=3651  sec_id=3577125 flags=0x0000 ifindex=12  mac=9A:88:5D:3A:4C:F8 nodemac=2A:8F:20:B3:5F:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:45.218Z",
  "value": "id=242   sec_id=3577125 flags=0x0000 ifindex=14  mac=CA:28:16:25:F9:46 nodemac=CA:01:C0:42:A5:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:45.219Z",
  "value": "id=1405  sec_id=4     flags=0x0000 ifindex=10  mac=3A:F3:73:AB:42:97 nodemac=22:51:2C:BA:33:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:45.247Z",
  "value": "id=1326  sec_id=3581616 flags=0x0000 ifindex=16  mac=9A:AE:82:5E:D7:E0 nodemac=62:31:FD:09:B6:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:46.219Z",
  "value": "id=3651  sec_id=3577125 flags=0x0000 ifindex=12  mac=9A:88:5D:3A:4C:F8 nodemac=2A:8F:20:B3:5F:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:46.219Z",
  "value": "id=1326  sec_id=3581616 flags=0x0000 ifindex=16  mac=9A:AE:82:5E:D7:E0 nodemac=62:31:FD:09:B6:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:46.219Z",
  "value": "id=1405  sec_id=4     flags=0x0000 ifindex=10  mac=3A:F3:73:AB:42:97 nodemac=22:51:2C:BA:33:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:46.219Z",
  "value": "id=242   sec_id=3577125 flags=0x0000 ifindex=14  mac=CA:28:16:25:F9:46 nodemac=CA:01:C0:42:A5:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:56.216Z",
  "value": "id=1865  sec_id=3581616 flags=0x0000 ifindex=18  mac=6A:7C:0B:3F:15:4B nodemac=82:48:7F:27:92:0D"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.108.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:06.489Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.158Z",
  "value": "id=3651  sec_id=3577125 flags=0x0000 ifindex=12  mac=9A:88:5D:3A:4C:F8 nodemac=2A:8F:20:B3:5F:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.160Z",
  "value": "id=242   sec_id=3577125 flags=0x0000 ifindex=14  mac=CA:28:16:25:F9:46 nodemac=CA:01:C0:42:A5:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.161Z",
  "value": "id=1405  sec_id=4     flags=0x0000 ifindex=10  mac=3A:F3:73:AB:42:97 nodemac=22:51:2C:BA:33:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.161Z",
  "value": "id=1865  sec_id=3581616 flags=0x0000 ifindex=18  mac=6A:7C:0B:3F:15:4B nodemac=82:48:7F:27:92:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.159Z",
  "value": "id=1865  sec_id=3581616 flags=0x0000 ifindex=18  mac=6A:7C:0B:3F:15:4B nodemac=82:48:7F:27:92:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.161Z",
  "value": "id=3651  sec_id=3577125 flags=0x0000 ifindex=12  mac=9A:88:5D:3A:4C:F8 nodemac=2A:8F:20:B3:5F:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.161Z",
  "value": "id=242   sec_id=3577125 flags=0x0000 ifindex=14  mac=CA:28:16:25:F9:46 nodemac=CA:01:C0:42:A5:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.161Z",
  "value": "id=1405  sec_id=4     flags=0x0000 ifindex=10  mac=3A:F3:73:AB:42:97 nodemac=22:51:2C:BA:33:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.158Z",
  "value": "id=3651  sec_id=3577125 flags=0x0000 ifindex=12  mac=9A:88:5D:3A:4C:F8 nodemac=2A:8F:20:B3:5F:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.158Z",
  "value": "id=242   sec_id=3577125 flags=0x0000 ifindex=14  mac=CA:28:16:25:F9:46 nodemac=CA:01:C0:42:A5:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.158Z",
  "value": "id=1405  sec_id=4     flags=0x0000 ifindex=10  mac=3A:F3:73:AB:42:97 nodemac=22:51:2C:BA:33:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.158Z",
  "value": "id=1865  sec_id=3581616 flags=0x0000 ifindex=18  mac=6A:7C:0B:3F:15:4B nodemac=82:48:7F:27:92:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.158Z",
  "value": "id=3651  sec_id=3577125 flags=0x0000 ifindex=12  mac=9A:88:5D:3A:4C:F8 nodemac=2A:8F:20:B3:5F:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.159Z",
  "value": "id=242   sec_id=3577125 flags=0x0000 ifindex=14  mac=CA:28:16:25:F9:46 nodemac=CA:01:C0:42:A5:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.159Z",
  "value": "id=1405  sec_id=4     flags=0x0000 ifindex=10  mac=3A:F3:73:AB:42:97 nodemac=22:51:2C:BA:33:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.159Z",
  "value": "id=1865  sec_id=3581616 flags=0x0000 ifindex=18  mac=6A:7C:0B:3F:15:4B nodemac=82:48:7F:27:92:0D"
}

