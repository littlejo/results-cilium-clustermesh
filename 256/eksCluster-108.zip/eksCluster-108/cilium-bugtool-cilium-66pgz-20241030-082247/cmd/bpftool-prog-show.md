35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:47:31+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:47:31+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:47:32+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:47:32+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:47:32+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:47:32+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:47:36+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:47:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:47:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:47:47+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
495: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
498: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
499: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
502: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
503: sched_cls  name tail_handle_ipv4  tag f0852398d0262290  gpl
	loaded_at 2024-10-30T07:54:34+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,104
	btf_id 136
504: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:54:34+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 137
505: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:54:34+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,104
	btf_id 138
506: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:54:34+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 139
529: sched_cls  name cil_from_container  tag f3e58ea787a7d0bf  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 165
530: sched_cls  name tail_ipv4_ct_ingress  tag a4117a16a359ceb1  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 166
532: sched_cls  name handle_policy  tag 32fd07656589c405  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,112,41,80,91,39,84,75,40,37,38
	btf_id 168
533: sched_cls  name tail_ipv4_to_endpoint  tag f775512a657b2346  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,91,39,111,40,37,38
	btf_id 169
534: sched_cls  name tail_handle_arp  tag d56dc42f457fb687  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 170
535: sched_cls  name tail_handle_ipv4  tag 0cd124ad7e7ff382  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 171
536: sched_cls  name tail_ipv4_ct_egress  tag 8f53360eca447a2e  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 172
537: sched_cls  name tail_handle_ipv4_cont  tag 4eac4fa2c1a7126b  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,112,41,91,82,83,39,76,74,77,111,40,37,38,81
	btf_id 173
538: sched_cls  name __send_drop_notify  tag 8ffb532b052bf5b0  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 174
539: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 175
540: sched_cls  name tail_ipv4_to_endpoint  tag b491564117378313  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,113,41,82,83,80,106,39,114,40,37,38
	btf_id 177
541: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,114
	btf_id 178
542: sched_cls  name cil_from_container  tag c043af0de5adbb78  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 114,76
	btf_id 179
543: sched_cls  name tail_handle_arp  tag d56ad5c41ed5198e  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,114
	btf_id 180
544: sched_cls  name handle_policy  tag 7389b25cf35f15f1  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,114,82,83,113,41,80,106,39,84,75,40,37,38
	btf_id 181
545: sched_cls  name tail_handle_ipv4_cont  tag a59e7c2548e6f0ed  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,113,41,106,82,83,39,76,74,77,114,40,37,38,81
	btf_id 182
546: sched_cls  name tail_handle_ipv4  tag 1c67201ca85aec4f  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,114
	btf_id 183
548: sched_cls  name tail_ipv4_ct_ingress  tag 66443103f4db5300  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 185
549: sched_cls  name __send_drop_notify  tag 45b265554b4b5716  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 186
550: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 187
552: sched_cls  name tail_ipv4_to_endpoint  tag 0b6279763529e549  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,105,39,115,40,37,38
	btf_id 190
553: sched_cls  name tail_ipv4_ct_egress  tag 8f53360eca447a2e  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 191
554: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
557: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
558: sched_cls  name tail_ipv4_ct_ingress  tag d3e44744413a13ca  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 192
559: sched_cls  name handle_policy  tag e846d7f574b8dc2b  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,105,39,84,75,40,37,38
	btf_id 193
560: sched_cls  name __send_drop_notify  tag 6cc99dc9b288506a  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 194
561: sched_cls  name tail_handle_ipv4  tag 927437f50ea838c8  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 195
562: sched_cls  name tail_handle_arp  tag a1db644d9b0c510b  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 196
563: sched_cls  name cil_from_container  tag 5c6b474db4afd527  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 197
564: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 198
565: sched_cls  name tail_handle_ipv4_cont  tag 802bf7d9986c4cfd  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,116,41,105,82,83,39,76,74,77,115,40,37,38,81
	btf_id 199
566: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
569: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
570: sched_cls  name __send_drop_notify  tag 4a53252c28802443  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
571: sched_cls  name tail_handle_ipv4_from_host  tag d8f896164a9f8473  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 202
573: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 204
574: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,119
	btf_id 205
576: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 207
577: sched_cls  name __send_drop_notify  tag 4a53252c28802443  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 209
578: sched_cls  name tail_handle_ipv4_from_host  tag d8f896164a9f8473  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 210
580: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 212
583: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 215
586: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 219
587: sched_cls  name __send_drop_notify  tag 4a53252c28802443  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 220
588: sched_cls  name tail_handle_ipv4_from_host  tag d8f896164a9f8473  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 221
589: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 222
591: sched_cls  name tail_handle_ipv4_from_host  tag d8f896164a9f8473  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,125
	btf_id 225
592: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,125,75
	btf_id 226
596: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,125
	btf_id 230
597: sched_cls  name __send_drop_notify  tag 4a53252c28802443  gpl
	loaded_at 2024-10-30T07:54:37+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 231
637: sched_cls  name __send_drop_notify  tag 23b130ae184a549a  gpl
	loaded_at 2024-10-30T08:09:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 245
638: sched_cls  name tail_ipv4_ct_ingress  tag fe16f39f606ae5dc  gpl
	loaded_at 2024-10-30T08:09:56+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 246
639: sched_cls  name tail_ipv4_to_endpoint  tag 25f67849f9ece318  gpl
	loaded_at 2024-10-30T08:09:56+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,138,41,82,83,80,137,39,139,40,37,38
	btf_id 247
640: sched_cls  name tail_handle_arp  tag f7cbd5efd86f1289  gpl
	loaded_at 2024-10-30T08:09:56+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,139
	btf_id 248
641: sched_cls  name tail_handle_ipv4  tag db68df95116d2f32  gpl
	loaded_at 2024-10-30T08:09:56+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,139
	btf_id 249
642: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:09:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,139
	btf_id 250
643: sched_cls  name cil_from_container  tag 9aea3a163874ee72  gpl
	loaded_at 2024-10-30T08:09:56+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 139,76
	btf_id 251
644: sched_cls  name handle_policy  tag 4f1e0cd0286afdc9  gpl
	loaded_at 2024-10-30T08:09:56+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,139,82,83,138,41,80,137,39,84,75,40,37,38
	btf_id 252
645: sched_cls  name tail_ipv4_ct_egress  tag 6f4c6b07345b9498  gpl
	loaded_at 2024-10-30T08:09:56+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 253
647: sched_cls  name tail_handle_ipv4_cont  tag 24174fe7193ccc5f  gpl
	loaded_at 2024-10-30T08:09:56+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,138,41,137,82,83,39,76,74,77,139,40,37,38,81
	btf_id 255
648: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
651: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
664: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
667: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
668: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
671: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
