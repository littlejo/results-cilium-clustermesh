markdown output at /tmp/cilium-bugtool-20241030-082248.461+0000-UTC-3556415867/cmd/cilium-debuginfo-20241030-082319.601+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082248.461+0000-UTC-3556415867/cmd/cilium-debuginfo-20241030-082319.601+0000-UTC.json
