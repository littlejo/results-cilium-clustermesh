ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.170.216:443 (active)   
                                          2 => 172.31.235.242:443 (active)   
2    10.100.47.156:443     ClusterIP      1 => 172.31.170.46:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.108.0.157:53 (active)      
                                          2 => 10.108.0.229:53 (active)      
4    10.100.0.10:9153      ClusterIP      1 => 10.108.0.157:9153 (active)    
                                          2 => 10.108.0.229:9153 (active)    
5    10.100.104.238:2379   ClusterIP      1 => 10.108.0.201:2379 (active)    
