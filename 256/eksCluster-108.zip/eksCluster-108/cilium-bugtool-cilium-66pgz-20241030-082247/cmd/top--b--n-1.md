top - 08:22:48 up 35 min,  0 users,  load average: 0.39, 0.25, 0.14
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 58.6 us, 24.1 sy,  0.0 ni, 17.2 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4477.5 free,   1190.2 used,   2146.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6439.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 385220  78528 S  80.0   4.8   0:47.90 cilium-+
    674 root      20   0 1240432  16672  11484 S   6.7   0.2   0:00.03 cilium-+
    400 root      20   0 1229744   8200   3840 S   0.0   0.1   0:01.07 cilium-+
    687 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    693 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    715 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    743 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    766 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
