Endpoint ID: 242
Path: /sys/fs/bpf/tc/globals/cilium_policy_00242

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    165739   1899      0        
Allow    Egress      0          ANY          NONE         disabled    20225    227       0        


Endpoint ID: 1220
Path: /sys/fs/bpf/tc/globals/cilium_policy_01220

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1405
Path: /sys/fs/bpf/tc/globals/cilium_policy_01405

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1648353   20827     0        
Allow    Ingress     1          ANY          NONE         disabled    24762     289       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1865
Path: /sys/fs/bpf/tc/globals/cilium_policy_01865

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11539502   116192    0        
Allow    Ingress     1          ANY          NONE         disabled    10313940   108672    0        
Allow    Egress      0          ANY          NONE         disabled    14487716   141365    0        


Endpoint ID: 3651
Path: /sys/fs/bpf/tc/globals/cilium_policy_03651

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    165013   1888      0        
Allow    Egress      0          ANY          NONE         disabled    21978    247       0        


