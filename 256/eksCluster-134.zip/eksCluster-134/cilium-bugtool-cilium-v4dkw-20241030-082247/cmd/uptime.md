 08:22:49 up 32 min,  0 users,  load average: 0.03, 0.14, 0.14
