IP ADDRESS         LOCAL ENDPOINT INFO
10.134.0.3:0       id=38    sec_id=4426588 flags=0x0000 ifindex=12  mac=92:2F:59:1F:F3:3B nodemac=F6:9F:EF:7B:C1:93   
172.31.159.255:0   (localhost)                                                                                        
10.134.0.225:0     (localhost)                                                                                        
172.31.128.28:0    (localhost)                                                                                        
10.134.0.4:0       id=3775  sec_id=4444336 flags=0x0000 ifindex=18  mac=BE:32:77:24:3A:63 nodemac=F2:67:2E:F2:CC:65   
10.134.0.191:0     id=1997  sec_id=4     flags=0x0000 ifindex=10  mac=22:73:89:89:B6:CE nodemac=8A:5D:29:5C:B4:A8     
10.134.0.25:0      id=2068  sec_id=4426588 flags=0x0000 ifindex=14  mac=C2:C9:3E:D7:5A:BF nodemac=D2:05:F8:37:A8:BC   
