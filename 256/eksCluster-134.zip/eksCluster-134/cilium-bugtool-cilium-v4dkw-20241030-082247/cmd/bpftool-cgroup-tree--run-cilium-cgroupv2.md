CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc631aa68_27b4_4a09_a30d_1556e89e3f11.slice/cri-containerd-14a6cd7cd577b2bb522118251996e79bc49fa733a7e77ccbc432c4203a5d12c5.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc631aa68_27b4_4a09_a30d_1556e89e3f11.slice/cri-containerd-540ad8e747b38949aad60ee8ee1bfc4c70ae6d975ef9522fab2d382f3dc59ba5.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod25170090_25c2_4828_96c6_2c6fd7d17936.slice/cri-containerd-9893c019740b5421664acae14c075ddb2cedbd4e92596c6c892f9b3c19f0478e.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod25170090_25c2_4828_96c6_2c6fd7d17936.slice/cri-containerd-3c7711c6c2b42cd049a809d47c3c04b10b2b439ea6e8e1bf24e82ad7db4bc5ff.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda82fc63_004a_4221_aa42_597f2cd10156.slice/cri-containerd-edc03e3808146ca2774beceed9a5523d9eb84f4e3cab09ab2fef3e914d26319f.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda82fc63_004a_4221_aa42_597f2cd10156.slice/cri-containerd-21fb5613836f965ebc316d2321aade5814629561932934fb4129185f7ed07d38.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf40c0d06_6185_4c47_b9bc_7fe88162d475.slice/cri-containerd-f68f331a84698a7a2359c89b2580423adeb30c16b818b8f14c8f3b53e19b98b8.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf40c0d06_6185_4c47_b9bc_7fe88162d475.slice/cri-containerd-dc19f5ad5cdce7a9b068b0fe97c15373d67e085c91694760a323f06a190180c6.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ebc504b_c37a_4495_8997_838f022e2056.slice/cri-containerd-11da9f2e234892999dbc9604660db600b8f694b93053ae2bf01c6390ddb4e5bb.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ebc504b_c37a_4495_8997_838f022e2056.slice/cri-containerd-fec1bbecb539fa624862ce084732fbc657cb7d0f603da34df4444d58358f32b1.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ebc504b_c37a_4495_8997_838f022e2056.slice/cri-containerd-8da1ac0076097a5df671aaa8bedfc069361e1a60ac901aee37056e7e72e77625.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ebc504b_c37a_4495_8997_838f022e2056.slice/cri-containerd-02865ac2eb06dddd6a6752d394769384a568036877f21e10fb4bb9a871b864bb.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64041844_66e1_4abd_917d_2ee3d9ce7062.slice/cri-containerd-b119b1dfff3a80e0aa4b30745b34bd08dacbb646fd412f03492886022fa23fcd.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64041844_66e1_4abd_917d_2ee3d9ce7062.slice/cri-containerd-6a5431a6ebd333f34adf6b88755e0e8ab79a8f4ae6a3ecb5dff8a3b6897a53cd.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod639e07f3_dd2d_4d2c_9c25_d70b2020b684.slice/cri-containerd-ef45719e006af3116ff5aa1b555aafa8510fed342e12667761d25bd01754fd7e.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod639e07f3_dd2d_4d2c_9c25_d70b2020b684.slice/cri-containerd-fa8d7aead5aa1c17a5dc400c02e2ae71f40ea4f075524767d66021076434f691.scope
    101      cgroup_device   multi                                          
