35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:50:02+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:50:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:50:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:50:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:50:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:50:02+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:50:03+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:50:03+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:50:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:50:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:50:03+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:50:03+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:50:06+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:50:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:50:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:50:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:59:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:59:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:59:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:59:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:59:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:59:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:00:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:00:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:00:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:00:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:00:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:00:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:00:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
485: sched_cls  name tail_handle_ipv4  tag deb9e89450cc4da5  gpl
	loaded_at 2024-10-30T08:00:26+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
486: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:00:26+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
487: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:00:26+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 127
517: sched_cls  name tail_ipv4_ct_ingress  tag 9b3f3cdf67e5e137  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 163
518: sched_cls  name tail_handle_arp  tag 9422fd4d1e7a20d8  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 165
524: sched_cls  name handle_policy  tag 2e3a183eceda18cc  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 167
526: sched_cls  name tail_handle_ipv4_cont  tag 4a32a6ab95688c05  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 172
527: sched_cls  name tail_ipv4_to_endpoint  tag c5911321f8fec1fe  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 174
529: sched_cls  name tail_handle_ipv4  tag 4f473dac6aff48a7  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 175
531: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 177
532: sched_cls  name cil_from_container  tag 4d26b23f4be75d96  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 179
534: sched_cls  name tail_ipv4_ct_egress  tag eccf8b1b4c374706  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 180
535: sched_cls  name __send_drop_notify  tag 79390cb7aa88c31a  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 182
538: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 185
539: sched_cls  name tail_handle_ipv4_from_host  tag 8d551d54c2e8c4e5  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,115
	btf_id 186
540: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,115
	btf_id 187
541: sched_cls  name __send_drop_notify  tag efced0c0d6a4cc37  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 188
543: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,115
	btf_id 190
545: sched_cls  name __send_drop_notify  tag efced0c0d6a4cc37  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 193
549: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 199
550: sched_cls  name tail_handle_ipv4_from_host  tag 8d551d54c2e8c4e5  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 200
551: sched_cls  name tail_handle_ipv4  tag cce0bf1d1979211a  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,119
	btf_id 198
552: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 201
553: sched_cls  name __send_drop_notify  tag efced0c0d6a4cc37  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 204
554: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 205
558: sched_cls  name tail_ipv4_ct_egress  tag eccf8b1b4c374706  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,119,82,83,120,84
	btf_id 202
559: sched_cls  name tail_handle_ipv4_from_host  tag 8d551d54c2e8c4e5  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 209
560: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 210
562: sched_cls  name tail_handle_ipv4_from_host  tag 8d551d54c2e8c4e5  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 214
563: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 215
564: sched_cls  name __send_drop_notify  tag efced0c0d6a4cc37  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 216
565: sched_cls  name tail_handle_ipv4_cont  tag 2ac3fe0f19d826e7  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,120,41,114,82,83,39,76,74,77,119,40,37,38,81
	btf_id 211
566: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 217
568: sched_cls  name __send_drop_notify  tag 16989d175a9ff610  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 220
570: sched_cls  name __send_drop_notify  tag c6ddd72c4007d002  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 223
571: sched_cls  name tail_handle_arp  tag 5479acc98af33e53  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 224
572: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 225
573: sched_cls  name tail_ipv4_to_endpoint  tag 910c6c78c6b4ee2a  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,120,41,82,83,80,114,39,119,40,37,38
	btf_id 221
574: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,119
	btf_id 227
575: sched_cls  name tail_ipv4_ct_ingress  tag fed54e4180855ffb  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,119,82,83,120,84
	btf_id 228
576: sched_cls  name tail_handle_arp  tag 7696abeb653623bc  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,119
	btf_id 229
578: sched_cls  name cil_from_container  tag 3354cff533650e60  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 119,76
	btf_id 231
579: sched_cls  name handle_policy  tag 4335cfe52c07c75b  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,125,82,83,126,41,80,100,39,84,75,40,37,38
	btf_id 226
580: sched_cls  name tail_handle_ipv4_cont  tag 201507767b9d2651  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,126,41,100,82,83,39,76,74,77,125,40,37,38,81
	btf_id 232
581: sched_cls  name tail_ipv4_to_endpoint  tag 92c7055ccf600ce7  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,126,41,82,83,80,100,39,125,40,37,38
	btf_id 233
582: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 235
584: sched_cls  name tail_ipv4_ct_ingress  tag b783f2d7512a8ed9  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 237
585: sched_cls  name handle_policy  tag 02fb5124b9380f64  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,119,82,83,120,41,80,114,39,84,75,40,37,38
	btf_id 234
586: sched_cls  name tail_handle_ipv4  tag c91942bcc72bf3fa  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 238
587: sched_cls  name cil_from_container  tag 468211573cb1af45  gpl
	loaded_at 2024-10-30T08:00:28+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 125,76
	btf_id 239
588: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:00:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
591: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:00:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
592: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:00:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
595: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:00:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
596: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:00:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
599: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:00:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:00:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:00:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
643: sched_cls  name tail_ipv4_ct_ingress  tag 12720df43ccfbc88  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 253
644: sched_cls  name __send_drop_notify  tag 9c67d86c7927aa0f  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 254
645: sched_cls  name tail_ipv4_to_endpoint  tag 7c76a2464e7cced8  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 255
646: sched_cls  name tail_handle_ipv4  tag e1d675e7fce9f4d1  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 256
647: sched_cls  name handle_policy  tag 890e6a8853c94103  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 257
648: sched_cls  name cil_from_container  tag 7aa12e5bf8c2f295  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 258
649: sched_cls  name tail_handle_arp  tag efc4bcf8f3a78625  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 259
650: sched_cls  name tail_ipv4_ct_egress  tag 70185b51bb63214b  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 260
651: sched_cls  name tail_handle_ipv4_cont  tag a9493b48b490995b  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 261
652: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 262
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
670: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
673: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
674: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
677: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
678: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
681: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
