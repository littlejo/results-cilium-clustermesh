ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.183.22:443 (active)    
                                          2 => 172.31.224.77:443 (active)    
2    10.100.175.141:443    ClusterIP      1 => 172.31.128.28:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.134.0.3:53 (active)        
                                          2 => 10.134.0.25:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.134.0.3:9153 (active)      
                                          2 => 10.134.0.25:9153 (active)     
5    10.100.251.105:2379   ClusterIP      1 => 10.134.0.4:2379 (active)      
