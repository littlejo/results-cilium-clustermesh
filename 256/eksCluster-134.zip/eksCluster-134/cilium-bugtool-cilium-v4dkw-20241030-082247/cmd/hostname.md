ip-172-31-128-28.eu-west-3.compute.internal
