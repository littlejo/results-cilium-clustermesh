alloc: 125.01MB (131080072 bytes)
total-alloc: 2.17GB (2326262808 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 62089739
frees: 61258804
heap-alloc: 125.01MB (131080072 bytes)
heap-sys: 254.20MB (266551296 bytes)
heap-idle: 71.44MB (74907648 bytes)
heap-in-use: 182.77MB (191643648 bytes)
heap-released: 648.00KB (663552 bytes)
heap-objects: 830935
stack-in-use: 61.75MB (64749568 bytes)
stack-sys: 61.75MB (64749568 bytes)
stack-mspan-inuse: 2.84MB (2975680 bytes)
stack-mspan-sys: 3.89MB (4080000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 986.21KB (1009881 bytes)
gc-sys: 6.00MB (6286704 bytes)
next-gc: when heap-alloc >= 213.15MB (223504648 bytes)
last-gc: 2024-10-30 08:23:12.918747746 +0000 UTC
gc-pause-total: 13.760464ms
gc-pause: 199059
gc-pause-end: 1730276592918747746
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0004768970026301759
enable-gc: true
debug-gc: false
