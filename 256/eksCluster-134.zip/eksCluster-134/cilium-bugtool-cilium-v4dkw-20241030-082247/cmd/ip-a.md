1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ee:f4:2f:7f:c1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.128.28/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3441sec preferred_lft 3441sec
    inet6 fe80::4ee:f4ff:fe2f:7fc1/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:97:4b:a4:20:fb brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.159.255/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::497:4bff:fea4:20fb/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:44:35:d8:ae:90 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3844:35ff:fed8:ae90/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:f2:d3:a8:c4:85 brd ff:ff:ff:ff:ff:ff
    inet 10.134.0.225/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::74f2:d3ff:fea8:c485/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ca:32:58:a7:ba:1f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c832:58ff:fea7:ba1f/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:5d:29:5c:b4:a8 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::885d:29ff:fe5c:b4a8/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc6a5d953fb3cc@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:9f:ef:7b:c1:93 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f49f:efff:fe7b:c193/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc3ede7e2a5c15@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:05:f8:37:a8:bc brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d005:f8ff:fe37:a8bc/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc2e8bba54a983@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:67:2e:f2:cc:65 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::f067:2eff:fef2:cc65/64 scope link 
       valid_lft forever preferred_lft forever
