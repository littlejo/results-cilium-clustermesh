Endpoint ID: 38
Path: /sys/fs/bpf/tc/globals/cilium_policy_00038

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    131193   1513      0        
Allow    Egress      0          ANY          NONE         disabled    17425    193       0        


Endpoint ID: 922
Path: /sys/fs/bpf/tc/globals/cilium_policy_00922

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1997
Path: /sys/fs/bpf/tc/globals/cilium_policy_01997

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1647734   20806     0        
Allow    Ingress     1          ANY          NONE         disabled    19656     230       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2068
Path: /sys/fs/bpf/tc/globals/cilium_policy_02068

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    130604   1500      0        
Allow    Egress      0          ANY          NONE         disabled    18671    205       0        


Endpoint ID: 3775
Path: /sys/fs/bpf/tc/globals/cilium_policy_03775

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11395844   112338    0        
Allow    Ingress     1          ANY          NONE         disabled    9111325    95222     0        
Allow    Egress      0          ANY          NONE         disabled    11798306   116531    0        


