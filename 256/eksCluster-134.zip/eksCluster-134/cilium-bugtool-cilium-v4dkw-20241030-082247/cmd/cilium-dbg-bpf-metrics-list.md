REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34106     2694761     677    bpf_overlay.c
Interface                 INGRESS     616602    128694378   1132   bpf_host.c
Success                   EGRESS      14002     1095049     1694   bpf_host.c
Success                   EGRESS      259908    32908747    1308   bpf_lxc.c
Success                   EGRESS      33007     2611733     53     encap.h
Success                   INGRESS     299919    33873011    86     l3.h
Success                   INGRESS     320674    35516769    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
