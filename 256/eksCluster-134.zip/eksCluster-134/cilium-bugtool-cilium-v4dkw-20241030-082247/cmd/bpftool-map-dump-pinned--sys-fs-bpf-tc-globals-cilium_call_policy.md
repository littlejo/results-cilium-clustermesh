key: 26 00 00 00  value: 0c 02 00 00
key: cd 07 00 00  value: 43 02 00 00
key: 14 08 00 00  value: 49 02 00 00
key: bf 0e 00 00  value: 87 02 00 00
Found 4 elements
