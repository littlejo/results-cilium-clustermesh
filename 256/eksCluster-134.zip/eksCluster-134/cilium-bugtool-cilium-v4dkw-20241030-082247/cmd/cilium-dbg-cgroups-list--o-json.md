[
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod25170090_25c2_4828_96c6_2c6fd7d17936.slice/cri-containerd-3c7711c6c2b42cd049a809d47c3c04b10b2b439ea6e8e1bf24e82ad7db4bc5ff.scope"
      }
    ],
    "ips": [
      "10.134.0.25"
    ],
    "name": "coredns-cc6ccd49c-v4mlt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9268,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ebc504b_c37a_4495_8997_838f022e2056.slice/cri-containerd-8da1ac0076097a5df671aaa8bedfc069361e1a60ac901aee37056e7e72e77625.scope"
      },
      {
        "cgroup-id": 9184,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ebc504b_c37a_4495_8997_838f022e2056.slice/cri-containerd-11da9f2e234892999dbc9604660db600b8f694b93053ae2bf01c6390ddb4e5bb.scope"
      },
      {
        "cgroup-id": 9352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ebc504b_c37a_4495_8997_838f022e2056.slice/cri-containerd-02865ac2eb06dddd6a6752d394769384a568036877f21e10fb4bb9a871b864bb.scope"
      }
    ],
    "ips": [
      "10.134.0.4"
    ],
    "name": "clustermesh-apiserver-858b56865b-9h4vj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf40c0d06_6185_4c47_b9bc_7fe88162d475.slice/cri-containerd-f68f331a84698a7a2359c89b2580423adeb30c16b818b8f14c8f3b53e19b98b8.scope"
      }
    ],
    "ips": [
      "10.134.0.3"
    ],
    "name": "coredns-cc6ccd49c-dgwrd",
    "namespace": "kube-system"
  }
]

