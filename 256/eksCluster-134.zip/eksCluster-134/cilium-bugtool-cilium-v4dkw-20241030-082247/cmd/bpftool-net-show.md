xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 554
ens6(5) clsact/ingress cil_from_netdev-ens6 id 566
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 549
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 538
cilium_host(7) clsact/egress cil_from_host-cilium_host id 543
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 587
lxc6a5d953fb3cc(12) clsact/ingress cil_from_container-lxc6a5d953fb3cc id 532
lxc3ede7e2a5c15(14) clsact/ingress cil_from_container-lxc3ede7e2a5c15 id 578
lxc2e8bba54a983(18) clsact/ingress cil_from_container-lxc2e8bba54a983 id 648

flow_dissector:

netfilter:

