top - 08:22:50 up 36 min,  0 users,  load average: 0.30, 0.25, 0.19
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 60.0 us, 30.0 sy,  0.0 ni, 10.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4438.4 free,   1228.3 used,   2147.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6401.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 393812  79420 S  80.0   4.9   0:49.89 cilium-+
    617 root      20   0 1229640  25912   4004 S  20.0   0.3   0:00.03 gops
    644 root      20   0 1240432  16572  11356 S  13.3   0.2   0:00.04 cilium-+
    394 root      20   0 1229744   7804   3840 S   0.0   0.1   0:01.08 cilium-+
    650 root      20   0 1228744   4020   3384 S   0.0   0.1   0:00.00 gops
    660 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    697 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    716 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
