[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcccc5a01_1fb6_4c8f_a983_4a0007ebc328.slice/cri-containerd-3c4858e2eb050888c408100118714f458bbf6710632080b272398371481f4981.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcccc5a01_1fb6_4c8f_a983_4a0007ebc328.slice/cri-containerd-80fe01cf0691f0c1593898c4ceb0e49b6515077fbf4d1781c18e657cd4307eef.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcccc5a01_1fb6_4c8f_a983_4a0007ebc328.slice/cri-containerd-16472ee8f8c8c19e9c40f65e97c518c39356ff8c7cb85e7ff2b687dd7a0427c1.scope"
      }
    ],
    "ips": [
      "10.17.0.177"
    ],
    "name": "clustermesh-apiserver-86d76cb6db-dlvs9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d066686_47ff_4253_8ba1_888b23846ddf.slice/cri-containerd-29c7c7ab34bc70649cf2c5e45a72385bff5103ce27a107acaf993ac7db8898ab.scope"
      }
    ],
    "ips": [
      "10.17.0.181"
    ],
    "name": "coredns-cc6ccd49c-kgmf7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeedfb990_49ab_405a_938a_b966e6ec592f.slice/cri-containerd-41213d6d5c464ad9715cbd000a5d3f0302441f810c345b93922f9738b8c3d545.scope"
      }
    ],
    "ips": [
      "10.17.0.199"
    ],
    "name": "coredns-cc6ccd49c-5w6f4",
    "namespace": "kube-system"
  }
]

