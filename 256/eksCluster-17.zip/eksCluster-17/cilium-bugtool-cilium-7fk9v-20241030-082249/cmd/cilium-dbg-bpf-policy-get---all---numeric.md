Endpoint ID: 1229
Path: /sys/fs/bpf/tc/globals/cilium_policy_01229

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    265126   2379      0        
Allow    Ingress     1          ANY          NONE         disabled    172389   1980      0        
Allow    Egress      0          ANY          NONE         disabled    98034    956       0        


Endpoint ID: 1324
Path: /sys/fs/bpf/tc/globals/cilium_policy_01324

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    275093   2463      0        
Allow    Ingress     1          ANY          NONE         disabled    172983   1989      0        
Allow    Egress      0          ANY          NONE         disabled    99869    969       0        


Endpoint ID: 1716
Path: /sys/fs/bpf/tc/globals/cilium_policy_01716

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2022
Path: /sys/fs/bpf/tc/globals/cilium_policy_02022

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1653340   20972     0        
Allow    Ingress     1          ANY          NONE         disabled    27026     319       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3863
Path: /sys/fs/bpf/tc/globals/cilium_policy_03863

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11546704   116401    0        
Allow    Ingress     1          ANY          NONE         disabled    11051836   116846    0        
Allow    Egress      0          ANY          NONE         disabled    14491984   141687    0        


