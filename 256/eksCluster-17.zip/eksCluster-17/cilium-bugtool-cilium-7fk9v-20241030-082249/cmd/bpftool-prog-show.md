29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:46:19+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:46:20+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:46:20+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:46:20+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:46:20+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:46:20+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:46:26+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:46:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:46:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:46:50+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
479: sched_cls  name tail_handle_ipv4  tag 394360ceed2f3a43  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
480: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
481: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 127
510: sched_cls  name tail_ipv4_ct_ingress  tag ae6b96e93dd6fd70  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 163
514: sched_cls  name tail_ipv4_to_endpoint  tag 0bb742f2c1205647  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 164
515: sched_cls  name tail_handle_ipv4_cont  tag 7b2a6583d0855661  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 168
516: sched_cls  name __send_drop_notify  tag b2b613d3c6781e01  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 169
519: sched_cls  name tail_ipv4_ct_egress  tag 7f5209875c884868  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 171
521: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 173
523: sched_cls  name tail_handle_arp  tag 5f9b58bbfdd2e081  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 175
525: sched_cls  name tail_handle_ipv4  tag aac0a51c7d5acb17  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 177
526: sched_cls  name cil_from_container  tag 72770ddcb9d63b71  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 179
531: sched_cls  name handle_policy  tag ddf5c49811f27a05  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 180
532: sched_cls  name tail_handle_ipv4_from_host  tag 36254dbe2a7b3f3d  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,116
	btf_id 185
533: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,116
	btf_id 188
535: sched_cls  name __send_drop_notify  tag a0b3e2b51aa0396c  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 190
537: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,116
	btf_id 192
538: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 193
539: sched_cls  name __send_drop_notify  tag a0b3e2b51aa0396c  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 195
542: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 198
543: sched_cls  name tail_handle_ipv4_from_host  tag 36254dbe2a7b3f3d  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 199
544: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 200
546: sched_cls  name tail_ipv4_to_endpoint  tag 55631769bca4066d  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,117,41,82,83,80,114,39,118,40,37,38
	btf_id 187
548: sched_cls  name __send_drop_notify  tag a0b3e2b51aa0396c  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
549: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 206
552: sched_cls  name tail_handle_ipv4_from_host  tag 36254dbe2a7b3f3d  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 209
553: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 210
555: sched_cls  name tail_handle_ipv4_from_host  tag 36254dbe2a7b3f3d  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 213
556: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 214
558: sched_cls  name __send_drop_notify  tag a0b3e2b51aa0396c  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 216
559: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 217
561: sched_cls  name cil_from_container  tag 8254063d10e2ad0e  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 125,76
	btf_id 220
562: sched_cls  name tail_handle_ipv4_cont  tag dc3d02be6d937547  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,126,41,100,82,83,39,76,74,77,125,40,37,38,81
	btf_id 221
564: sched_cls  name handle_policy  tag 27762f4907c38307  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,118,82,83,117,41,80,114,39,84,75,40,37,38
	btf_id 204
565: sched_cls  name tail_handle_ipv4  tag 0e6d1ee5b2a5e323  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,118
	btf_id 224
566: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,118
	btf_id 225
567: sched_cls  name tail_ipv4_to_endpoint  tag f1349e7b0ec7a7d5  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,126,41,82,83,80,100,39,125,40,37,38
	btf_id 223
568: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 227
569: sched_cls  name tail_handle_arp  tag f467081553cd2879  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 228
570: sched_cls  name tail_handle_ipv4_cont  tag 8d838d1b24ca7bc4  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,117,41,114,82,83,39,76,74,77,118,40,37,38,81
	btf_id 226
571: sched_cls  name __send_drop_notify  tag 3172ae000134d5fd  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 230
572: sched_cls  name cil_from_container  tag 79d74a6ac4bf5de0  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 118,76
	btf_id 231
573: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 229
574: sched_cls  name __send_drop_notify  tag 188fdc395f60cabd  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 233
575: sched_cls  name tail_ipv4_ct_egress  tag 7f5209875c884868  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 232
577: sched_cls  name tail_handle_ipv4  tag 6ac52a7da23eb40c  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 234
578: sched_cls  name tail_handle_arp  tag 39737cd065d09650  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,118
	btf_id 236
579: sched_cls  name tail_ipv4_ct_ingress  tag 82f7a4ccc9e37e5c  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 237
580: sched_cls  name tail_ipv4_ct_ingress  tag 571b8cd3e45f5c66  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 238
581: sched_cls  name handle_policy  tag 3275b5ba3ecb7ff9  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,125,82,83,126,41,80,100,39,84,75,40,37,38
	btf_id 239
582: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
585: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
586: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
589: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
590: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
593: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
594: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
597: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
637: sched_cls  name __send_drop_notify  tag 6f6d49e946858e6a  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 253
639: sched_cls  name tail_handle_arp  tag bfa7eea931fbd880  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 255
640: sched_cls  name tail_handle_ipv4  tag af1677d4553689dd  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 256
641: sched_cls  name cil_from_container  tag f23cade4d342885d  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 257
642: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 258
643: sched_cls  name tail_ipv4_ct_egress  tag 8f0f893d24d80f5c  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 259
644: sched_cls  name tail_ipv4_to_endpoint  tag dd9b510c440c597f  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 260
645: sched_cls  name tail_handle_ipv4_cont  tag 46f528e666d22ab5  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 261
646: sched_cls  name handle_policy  tag c3958dcddc050584  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 262
647: sched_cls  name tail_ipv4_ct_ingress  tag c5beee2c2541e476  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 263
648: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
651: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
664: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
667: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
668: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
671: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
