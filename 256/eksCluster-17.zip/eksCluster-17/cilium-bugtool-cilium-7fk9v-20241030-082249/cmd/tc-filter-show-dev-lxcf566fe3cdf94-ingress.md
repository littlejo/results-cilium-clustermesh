filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf566fe3cdf94 direct-action not_in_hw id 572 tag 79d74a6ac4bf5de0 jited 
