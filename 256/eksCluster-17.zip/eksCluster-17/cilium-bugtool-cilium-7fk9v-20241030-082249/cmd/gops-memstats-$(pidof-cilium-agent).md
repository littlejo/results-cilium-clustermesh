alloc: 207.55MB (217636064 bytes)
total-alloc: 2.42GB (2602101984 bytes)
sys: 332.77MB (348934500 bytes)
lookups: 0
mallocs: 66259156
frees: 64075390
heap-alloc: 207.55MB (217636064 bytes)
heap-sys: 255.39MB (267796480 bytes)
heap-idle: 28.47MB (29851648 bytes)
heap-in-use: 226.92MB (237944832 bytes)
heap-released: 12.72MB (13336576 bytes)
heap-objects: 2183766
stack-in-use: 64.56MB (67698688 bytes)
stack-sys: 64.56MB (67698688 bytes)
stack-mspan-inuse: 3.55MB (3720640 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.00MB (1052473 bytes)
gc-sys: 6.03MB (6321712 bytes)
next-gc: when heap-alloc >= 224.33MB (235225800 bytes)
last-gc: 2024-10-30 08:22:50.183726984 +0000 UTC
gc-pause-total: 7.747185ms
gc-pause: 124612
gc-pause-end: 1730276570183726984
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0003705346410042854
enable-gc: true
debug-gc: false
