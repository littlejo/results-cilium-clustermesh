xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 549
ens6(5) clsact/ingress cil_from_netdev-ens6 id 559
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 542
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 538
cilium_host(7) clsact/egress cil_from_host-cilium_host id 537
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 561
lxcba859e52b8e5(12) clsact/ingress cil_from_container-lxcba859e52b8e5 id 526
lxcf566fe3cdf94(14) clsact/ingress cil_from_container-lxcf566fe3cdf94 id 572
lxc354bccd615fd(18) clsact/ingress cil_from_container-lxc354bccd615fd id 641

flow_dissector:

netfilter:

