CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ae3e057_af7e_4043_9ede_12474368d547.slice/cri-containerd-d615590cde9964552df375be8e19b172df558cfc31c611349f85c3da764d2dfd.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ae3e057_af7e_4043_9ede_12474368d547.slice/cri-containerd-dc77c87338dc8ccce5cf86a98bab20450670cbc503e63be751c8dce0ff637dcf.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08c36216_a9b7_4127_9e80_8bd7db60d05b.slice/cri-containerd-01b2b26f7f35c77a31e7234876417a5386d6437c6a47810c3af78a5ad6e25b3d.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08c36216_a9b7_4127_9e80_8bd7db60d05b.slice/cri-containerd-ca5c4fe9b569de65ef47a0187cdd937872238d0c50d17901e57bc07caf487fdd.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeedfb990_49ab_405a_938a_b966e6ec592f.slice/cri-containerd-41213d6d5c464ad9715cbd000a5d3f0302441f810c345b93922f9738b8c3d545.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeedfb990_49ab_405a_938a_b966e6ec592f.slice/cri-containerd-dc5854f84fa6ca471cb33c49588b584c0099c587de545432bdbe546876621ecf.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d066686_47ff_4253_8ba1_888b23846ddf.slice/cri-containerd-77b64daa73363838adb09770bc44caa4f6e96c087743b908305ca031a90b074a.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d066686_47ff_4253_8ba1_888b23846ddf.slice/cri-containerd-29c7c7ab34bc70649cf2c5e45a72385bff5103ce27a107acaf993ac7db8898ab.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod22b42699_34fc_490e_ac72_768b8435e879.slice/cri-containerd-acce2a8332ef643d8fe18b3d3e0f7eb5686c83f1e97ac93f0c92ec2e34469a61.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod22b42699_34fc_490e_ac72_768b8435e879.slice/cri-containerd-ef64ba2645701e4588ea8ef7a20d4b533cdaa6a07a0c732974d509325dd03318.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf18a5ee9_84b5_4fbb_801a_ad7fc89285c3.slice/cri-containerd-f9963e718c589632a9a3e7875c5b8141faf03c18e875e8ed9ecac25e5cbd16e0.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf18a5ee9_84b5_4fbb_801a_ad7fc89285c3.slice/cri-containerd-49bb6b2dfee6a3069ac7c959f99caa45686f9b5cc1c136aad262efa4c7131a38.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcccc5a01_1fb6_4c8f_a983_4a0007ebc328.slice/cri-containerd-3c4858e2eb050888c408100118714f458bbf6710632080b272398371481f4981.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcccc5a01_1fb6_4c8f_a983_4a0007ebc328.slice/cri-containerd-90c913e1e7f836527c418bc0f71abe5d8607caa6fcdf7f9f19077cb98a8e190d.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcccc5a01_1fb6_4c8f_a983_4a0007ebc328.slice/cri-containerd-16472ee8f8c8c19e9c40f65e97c518c39356ff8c7cb85e7ff2b687dd7a0427c1.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcccc5a01_1fb6_4c8f_a983_4a0007ebc328.slice/cri-containerd-80fe01cf0691f0c1593898c4ceb0e49b6515077fbf4d1781c18e657cd4307eef.scope
    667      cgroup_device   multi                                          
