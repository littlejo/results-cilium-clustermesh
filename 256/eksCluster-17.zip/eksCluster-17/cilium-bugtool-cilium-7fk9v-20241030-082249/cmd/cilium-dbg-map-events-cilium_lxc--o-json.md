{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:11.785Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.194.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:11.785Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.218.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:11.785Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:16.044Z",
  "value": "id=2022  sec_id=4     flags=0x0000 ifindex=10  mac=F6:F3:3F:A5:6D:28 nodemac=82:19:4E:A7:CD:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:16.044Z",
  "value": "id=1324  sec_id=603264 flags=0x0000 ifindex=12  mac=96:39:18:39:71:8D nodemac=A2:1F:FC:C9:85:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:16.093Z",
  "value": "id=1229  sec_id=603264 flags=0x0000 ifindex=14  mac=9E:F3:16:ED:A3:89 nodemac=FA:8F:6C:9C:3A:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:16.113Z",
  "value": "id=2022  sec_id=4     flags=0x0000 ifindex=10  mac=F6:F3:3F:A5:6D:28 nodemac=82:19:4E:A7:CD:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:48.825Z",
  "value": "id=2022  sec_id=4     flags=0x0000 ifindex=10  mac=F6:F3:3F:A5:6D:28 nodemac=82:19:4E:A7:CD:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:48.826Z",
  "value": "id=1324  sec_id=603264 flags=0x0000 ifindex=12  mac=96:39:18:39:71:8D nodemac=A2:1F:FC:C9:85:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:48.827Z",
  "value": "id=1229  sec_id=603264 flags=0x0000 ifindex=14  mac=9E:F3:16:ED:A3:89 nodemac=FA:8F:6C:9C:3A:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:48.856Z",
  "value": "id=1218  sec_id=601471 flags=0x0000 ifindex=16  mac=22:A5:BC:55:16:A0 nodemac=7E:C1:5A:42:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:49.826Z",
  "value": "id=2022  sec_id=4     flags=0x0000 ifindex=10  mac=F6:F3:3F:A5:6D:28 nodemac=82:19:4E:A7:CD:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:49.826Z",
  "value": "id=1218  sec_id=601471 flags=0x0000 ifindex=16  mac=22:A5:BC:55:16:A0 nodemac=7E:C1:5A:42:42:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:49.826Z",
  "value": "id=1324  sec_id=603264 flags=0x0000 ifindex=12  mac=96:39:18:39:71:8D nodemac=A2:1F:FC:C9:85:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:49.827Z",
  "value": "id=1229  sec_id=603264 flags=0x0000 ifindex=14  mac=9E:F3:16:ED:A3:89 nodemac=FA:8F:6C:9C:3A:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.597Z",
  "value": "id=3863  sec_id=601471 flags=0x0000 ifindex=18  mac=1E:17:AF:6F:81:B6 nodemac=2E:B2:27:CC:C4:24"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.17.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.285Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:26.167Z",
  "value": "id=3863  sec_id=601471 flags=0x0000 ifindex=18  mac=1E:17:AF:6F:81:B6 nodemac=2E:B2:27:CC:C4:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:26.170Z",
  "value": "id=2022  sec_id=4     flags=0x0000 ifindex=10  mac=F6:F3:3F:A5:6D:28 nodemac=82:19:4E:A7:CD:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:26.170Z",
  "value": "id=1324  sec_id=603264 flags=0x0000 ifindex=12  mac=96:39:18:39:71:8D nodemac=A2:1F:FC:C9:85:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:26.170Z",
  "value": "id=1229  sec_id=603264 flags=0x0000 ifindex=14  mac=9E:F3:16:ED:A3:89 nodemac=FA:8F:6C:9C:3A:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.166Z",
  "value": "id=3863  sec_id=601471 flags=0x0000 ifindex=18  mac=1E:17:AF:6F:81:B6 nodemac=2E:B2:27:CC:C4:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.167Z",
  "value": "id=1229  sec_id=603264 flags=0x0000 ifindex=14  mac=9E:F3:16:ED:A3:89 nodemac=FA:8F:6C:9C:3A:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.167Z",
  "value": "id=2022  sec_id=4     flags=0x0000 ifindex=10  mac=F6:F3:3F:A5:6D:28 nodemac=82:19:4E:A7:CD:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.167Z",
  "value": "id=1324  sec_id=603264 flags=0x0000 ifindex=12  mac=96:39:18:39:71:8D nodemac=A2:1F:FC:C9:85:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:28.167Z",
  "value": "id=1324  sec_id=603264 flags=0x0000 ifindex=12  mac=96:39:18:39:71:8D nodemac=A2:1F:FC:C9:85:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:28.167Z",
  "value": "id=1229  sec_id=603264 flags=0x0000 ifindex=14  mac=9E:F3:16:ED:A3:89 nodemac=FA:8F:6C:9C:3A:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:28.168Z",
  "value": "id=3863  sec_id=601471 flags=0x0000 ifindex=18  mac=1E:17:AF:6F:81:B6 nodemac=2E:B2:27:CC:C4:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:28.169Z",
  "value": "id=2022  sec_id=4     flags=0x0000 ifindex=10  mac=F6:F3:3F:A5:6D:28 nodemac=82:19:4E:A7:CD:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:29.168Z",
  "value": "id=2022  sec_id=4     flags=0x0000 ifindex=10  mac=F6:F3:3F:A5:6D:28 nodemac=82:19:4E:A7:CD:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:29.168Z",
  "value": "id=3863  sec_id=601471 flags=0x0000 ifindex=18  mac=1E:17:AF:6F:81:B6 nodemac=2E:B2:27:CC:C4:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:29.168Z",
  "value": "id=1324  sec_id=603264 flags=0x0000 ifindex=12  mac=96:39:18:39:71:8D nodemac=A2:1F:FC:C9:85:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:29.168Z",
  "value": "id=1229  sec_id=603264 flags=0x0000 ifindex=14  mac=9E:F3:16:ED:A3:89 nodemac=FA:8F:6C:9C:3A:C1"
}

