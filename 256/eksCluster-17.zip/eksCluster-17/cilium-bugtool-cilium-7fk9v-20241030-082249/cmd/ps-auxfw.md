USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         660  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         651  0.0  0.0 1228744 3584 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         650  0.0  0.0 1228744 4020 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         644  0.0  0.1 1240432 15868 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         685  0.0  0.1 1240432 15868 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         686  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         628  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         617  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  2.7  4.7 1606080 382988 ?      Ssl  07:53   0:49 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.0  0.0 1229744 7804 ?        Sl   07:53   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
