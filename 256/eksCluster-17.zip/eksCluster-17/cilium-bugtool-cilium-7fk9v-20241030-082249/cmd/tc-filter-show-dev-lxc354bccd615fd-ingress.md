filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc354bccd615fd direct-action not_in_hw id 641 tag f23cade4d342885d jited 
