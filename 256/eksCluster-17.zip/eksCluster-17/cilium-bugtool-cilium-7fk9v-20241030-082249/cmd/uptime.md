 08:22:50 up 36 min,  0 users,  load average: 0.30, 0.25, 0.19
