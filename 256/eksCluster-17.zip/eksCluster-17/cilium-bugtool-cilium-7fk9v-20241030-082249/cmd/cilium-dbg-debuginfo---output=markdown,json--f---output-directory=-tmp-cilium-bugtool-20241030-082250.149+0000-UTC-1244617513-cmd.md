markdown output at /tmp/cilium-bugtool-20241030-082250.149+0000-UTC-1244617513/cmd/cilium-debuginfo-20241030-082321.268+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082250.149+0000-UTC-1244617513/cmd/cilium-debuginfo-20241030-082321.268+0000-UTC.json
