REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37914     2999314     677    bpf_overlay.c
Interface                 INGRESS     672483    136393370   1132   bpf_host.c
Success                   EGRESS      17667     1396164     1694   bpf_host.c
Success                   EGRESS      288237    35622764    1308   bpf_lxc.c
Success                   EGRESS      38941     3078549     53     encap.h
Success                   EGRESS      9684      1536704     86     l3.h
Success                   INGRESS     332801    37720279    86     l3.h
Success                   INGRESS     363383    40904179    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
