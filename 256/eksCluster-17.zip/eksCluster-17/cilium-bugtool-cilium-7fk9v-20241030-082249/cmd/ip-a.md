1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:51:b1:e9:03:9d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.194.203/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3219sec preferred_lft 3219sec
    inet6 fe80::851:b1ff:fee9:39d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:fd:3a:ba:57:33 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.218.110/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8fd:3aff:feba:5733/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:fa:49:37:46:f0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::fa:49ff:fe37:46f0/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:b2:b6:59:5f:e7 brd ff:ff:ff:ff:ff:ff
    inet 10.17.0.137/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c0b2:b6ff:fe59:5fe7/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 26:b6:d5:f5:2e:c5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::24b6:d5ff:fef5:2ec5/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:19:4e:a7:cd:2f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::8019:4eff:fea7:cd2f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcba859e52b8e5@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:1f:fc:c9:85:c6 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a01f:fcff:fec9:85c6/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcf566fe3cdf94@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:8f:6c:9c:3a:c1 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f88f:6cff:fe9c:3ac1/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc354bccd615fd@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:b2:27:cc:c4:24 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2cb2:27ff:fecc:c424/64 scope link 
       valid_lft forever preferred_lft forever
