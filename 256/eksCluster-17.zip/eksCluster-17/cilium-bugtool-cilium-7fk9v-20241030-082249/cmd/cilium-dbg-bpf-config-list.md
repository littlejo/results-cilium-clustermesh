KEY             VALUE
AgentLiveness   2225345456776
UTimeOffset     3379442140625000
