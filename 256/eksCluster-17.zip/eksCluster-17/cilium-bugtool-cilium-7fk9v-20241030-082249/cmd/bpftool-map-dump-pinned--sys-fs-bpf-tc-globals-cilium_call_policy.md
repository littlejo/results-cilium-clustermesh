key: cd 04 00 00  value: 34 02 00 00
key: 2c 05 00 00  value: 13 02 00 00
key: e6 07 00 00  value: 45 02 00 00
key: 17 0f 00 00  value: 86 02 00 00
Found 4 elements
