IP ADDRESS         LOCAL ENDPOINT INFO
10.17.0.33:0       id=2022  sec_id=4     flags=0x0000 ifindex=10  mac=F6:F3:3F:A5:6D:28 nodemac=82:19:4E:A7:CD:2F    
10.17.0.137:0      (localhost)                                                                                       
10.17.0.181:0      id=1229  sec_id=603264 flags=0x0000 ifindex=14  mac=9E:F3:16:ED:A3:89 nodemac=FA:8F:6C:9C:3A:C1   
10.17.0.177:0      id=3863  sec_id=601471 flags=0x0000 ifindex=18  mac=1E:17:AF:6F:81:B6 nodemac=2E:B2:27:CC:C4:24   
172.31.218.110:0   (localhost)                                                                                       
10.17.0.199:0      id=1324  sec_id=603264 flags=0x0000 ifindex=12  mac=96:39:18:39:71:8D nodemac=A2:1F:FC:C9:85:C6   
172.31.194.203:0   (localhost)                                                                                       
