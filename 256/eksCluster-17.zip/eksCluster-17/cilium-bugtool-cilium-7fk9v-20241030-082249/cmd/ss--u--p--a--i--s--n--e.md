Total: 700
TCP:   1882 (estab 449, closed 1414, orphaned 0, timewait 562)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  468       456       12       
INET	  478       462       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                  Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                           127.0.0.1:42151      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:31708 sk:1001 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                 172.31.194.203%ens5:68         0.0.0.0:*    uid:192 ino:71310 sk:1002 cgroup:unreachable:c4e <->                            
UNCONN 0      0                             0.0.0.0:8472       0.0.0.0:*    ino:31885 sk:1003 cgroup:/ <->                                                  
UNCONN 0      0                           127.0.0.1:323        0.0.0.0:*    ino:15759 sk:1004 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                [::]:8472          [::]:*    ino:31884 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                               [::1]:323           [::]:*    ino:15760 sk:1006 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::851:b1ff:fee9:39d]%ens5:546           [::]:*    uid:192 ino:15166 sk:1007 cgroup:unreachable:c4e v6only:1 <->                   
