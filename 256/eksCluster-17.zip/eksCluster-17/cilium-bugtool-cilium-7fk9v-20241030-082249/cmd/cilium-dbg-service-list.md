ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.148.177:443 (active)    
                                         2 => 172.31.195.171:443 (active)    
2    10.100.227.138:443   ClusterIP      1 => 172.31.194.203:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.17.0.199:53 (active)        
                                         2 => 10.17.0.181:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.17.0.199:9153 (active)      
                                         2 => 10.17.0.181:9153 (active)      
5    10.100.50.42:2379    ClusterIP      1 => 10.17.0.177:2379 (active)      
