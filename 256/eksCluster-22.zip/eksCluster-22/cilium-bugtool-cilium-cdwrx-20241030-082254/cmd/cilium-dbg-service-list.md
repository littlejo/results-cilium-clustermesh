ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.156.166:443 (active)    
                                          2 => 172.31.248.176:443 (active)    
2    10.100.223.176:443    ClusterIP      1 => 172.31.172.110:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.22.0.81:53 (active)         
                                          2 => 10.22.0.224:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.22.0.81:9153 (active)       
                                          2 => 10.22.0.224:9153 (active)      
5    10.100.148.145:2379   ClusterIP      1 => 10.22.0.26:2379 (active)       
