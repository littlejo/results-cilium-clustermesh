IP ADDRESS         LOCAL ENDPOINT INFO
10.22.0.81:0       id=88    sec_id=756300 flags=0x0000 ifindex=12  mac=72:6F:37:80:77:52 nodemac=A2:7D:A4:D2:93:37   
10.22.0.153:0      (localhost)                                                                                       
10.22.0.224:0      id=509   sec_id=756300 flags=0x0000 ifindex=14  mac=8A:9D:D1:E7:EC:01 nodemac=CE:5A:6C:6F:D4:42   
172.31.172.110:0   (localhost)                                                                                       
10.22.0.26:0       id=1993  sec_id=765733 flags=0x0000 ifindex=18  mac=AE:08:F6:24:98:A9 nodemac=4A:21:05:6D:CF:F3   
172.31.190.95:0    (localhost)                                                                                       
10.22.0.84:0       id=911   sec_id=4     flags=0x0000 ifindex=10  mac=82:76:2B:46:99:77 nodemac=4A:6A:BF:33:5D:A5    
