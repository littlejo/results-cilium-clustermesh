KEY             VALUE
AgentLiveness   2387792876575
UTimeOffset     3379441832031250
