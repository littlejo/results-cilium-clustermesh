[
  {
    "containers": [
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddcea8b09_f310_4161_ab5a_2bb44015b703.slice/cri-containerd-a61418f0b2a6de2d78b048c143c394ea7770f6b5433091db9d523790b3b83c60.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddcea8b09_f310_4161_ab5a_2bb44015b703.slice/cri-containerd-703dfe4dcb8f47dd72881551cbceadc11d6ab8d469e83a368cb65eb4d6af22e9.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddcea8b09_f310_4161_ab5a_2bb44015b703.slice/cri-containerd-a07a35818c837ed04b69697ff315187524147ecaed125784662c43f24bb59d81.scope"
      }
    ],
    "ips": [
      "10.22.0.26"
    ],
    "name": "clustermesh-apiserver-df8787bcf-gsf7l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod751c7419_b1b2_4f24_9add_65c5f7b2304f.slice/cri-containerd-4c2e4a356283b1502dbacf72b0f1238129aea580ee1cd0b2ebf7016baebd2d7a.scope"
      }
    ],
    "ips": [
      "10.22.0.224"
    ],
    "name": "coredns-cc6ccd49c-brf8n",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68f964b7_deb9_45d5_937a_d55ba2d41672.slice/cri-containerd-84a4a0b59cfd9866f60d30d84c3149643e12ebabb6ed77299eb7d15dad435db5.scope"
      }
    ],
    "ips": [
      "10.22.0.81"
    ],
    "name": "coredns-cc6ccd49c-k6wj6",
    "namespace": "kube-system"
  }
]

