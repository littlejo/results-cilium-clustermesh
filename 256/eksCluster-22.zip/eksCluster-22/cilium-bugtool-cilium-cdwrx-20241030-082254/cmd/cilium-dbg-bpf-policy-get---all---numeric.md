Endpoint ID: 88
Path: /sys/fs/bpf/tc/globals/cilium_policy_00088

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    178980   2057      0        
Allow    Egress      0          ANY          NONE         disabled    21426    240       0        


Endpoint ID: 509
Path: /sys/fs/bpf/tc/globals/cilium_policy_00509

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    177107   2023      0        
Allow    Egress      0          ANY          NONE         disabled    22912    257       0        


Endpoint ID: 911
Path: /sys/fs/bpf/tc/globals/cilium_policy_00911

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1639695   20736     0        
Allow    Ingress     1          ANY          NONE         disabled    26388     307       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1993
Path: /sys/fs/bpf/tc/globals/cilium_policy_01993

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11576084   114600    0        
Allow    Ingress     1          ANY          NONE         disabled    10667052   108608    0        
Allow    Egress      0          ANY          NONE         disabled    11933295   118139    0        


Endpoint ID: 2547
Path: /sys/fs/bpf/tc/globals/cilium_policy_02547

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


