 08:22:54 up 39 min,  0 users,  load average: 0.43, 0.48, 0.34
