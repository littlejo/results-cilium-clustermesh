markdown output at /tmp/cilium-bugtool-20241030-082254.909+0000-UTC-3333141914/cmd/cilium-debuginfo-20241030-082325.999+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082254.909+0000-UTC-3333141914/cmd/cilium-debuginfo-20241030-082325.999+0000-UTC.json
