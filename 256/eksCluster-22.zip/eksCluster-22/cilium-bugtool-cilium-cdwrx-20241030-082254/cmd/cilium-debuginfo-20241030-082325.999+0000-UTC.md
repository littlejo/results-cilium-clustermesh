# Cilium debug information

#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.22.0.224": (string) (len=35) "kube-system/coredns-cc6ccd49c-brf8n",
  (string) (len=10) "10.22.0.26": (string) (len=49) "kube-system/clustermesh-apiserver-df8787bcf-gsf7l",
  (string) (len=11) "10.22.0.153": (string) (len=6) "router",
  (string) (len=10) "10.22.0.84": (string) (len=6) "health",
  (string) (len=10) "10.22.0.81": (string) (len=35) "kube-system/coredns-cc6ccd49c-k6wj6"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.172.110": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001c824d0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001d4c5a0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001d4c5a0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40009cbe40)(frontends:[10.100.148.145]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x400003e790)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x400003e840)(frontends:[10.100.223.176]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x400003e9a0)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40009cbd90)(frontends:[]/ports=[kvmesh-metrics etcd-metrics apiserv-metrics]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4000e453d0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-zgk5j": (*k8s.Endpoints)(0x4002a7ba00)(10.22.0.224:53/TCP[eu-west-3a],10.22.0.224:53/UDP[eu-west-3a],10.22.0.224:9153/TCP[eu-west-3a],10.22.0.81:53/TCP[eu-west-3a],10.22.0.81:53/UDP[eu-west-3a],10.22.0.81:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40011bc908)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-8jfzm": (*k8s.Endpoints)(0x400a8bef70)(10.22.0.26:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4000e453c0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002a7a5b0)(172.31.156.166:443/TCP,172.31.248.176:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4000e453c8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-h9rzq": (*k8s.Endpoints)(0x400333f1e0)(172.31.172.110:4244/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001c8e000)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x400097d450)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400f60d848
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4000f79140,
  gcExited: (chan struct {}) 0x4000f791a0,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001bec380)({
     ObserverVec: (*prometheus.HistogramVec)(0x40015b7d38)({
      MetricVec: (*prometheus.MetricVec)(0x4001c03a40)({
       metricMap: (*prometheus.metricMap)(0x4001c03a70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001987620)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001bec400)({
     ObserverVec: (*prometheus.HistogramVec)(0x40015b7d40)({
      MetricVec: (*prometheus.MetricVec)(0x4001c03ad0)({
       metricMap: (*prometheus.metricMap)(0x4001c03b00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001987680)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001bec480)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015b7d48)({
      MetricVec: (*prometheus.MetricVec)(0x4001c03b60)({
       metricMap: (*prometheus.metricMap)(0x4001c03b90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019876e0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001bec500)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015b7d50)({
      MetricVec: (*prometheus.MetricVec)(0x4001c03bf0)({
       metricMap: (*prometheus.metricMap)(0x4001c03c20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001987740)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x400186a000)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001756000)({
      MetricVec: (*prometheus.MetricVec)(0x4001c03c80)({
       metricMap: (*prometheus.metricMap)(0x4001c03cb0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019877a0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x400186a080)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001756008)({
      MetricVec: (*prometheus.MetricVec)(0x400184c030)({
       metricMap: (*prometheus.metricMap)(0x400184c060)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c80000)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x400186a100)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001756010)({
      MetricVec: (*prometheus.MetricVec)(0x400184c0c0)({
       metricMap: (*prometheus.metricMap)(0x400184c0f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c80060)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x400186a180)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001756018)({
      MetricVec: (*prometheus.MetricVec)(0x400184c150)({
       metricMap: (*prometheus.metricMap)(0x400184c180)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c800c0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x400186a200)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001756020)({
      MetricVec: (*prometheus.MetricVec)(0x400184c1e0)({
       metricMap: (*prometheus.metricMap)(0x400184c210)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c80120)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001c8e000)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001c8f180)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001c92f48)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 377ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.22.0.0/24, 
Allocated addresses:
  10.22.0.153 (router)
  10.22.0.224 (kube-system/coredns-cc6ccd49c-brf8n)
  10.22.0.26 (kube-system/clustermesh-apiserver-df8787bcf-gsf7l)
  10.22.0.81 (kube-system/coredns-cc6ccd49c-k6wj6)
  10.22.0.84 (health)
ClusterMesh:   255/255 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh129: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=129, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh130: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=130, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh131: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=131, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh132: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=132, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh133: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=133, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh134: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=134, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh135: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=135, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh136: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=136, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh137: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=137, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh138: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=138, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh139: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=139, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh140: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=140, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh141: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=141, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh142: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=142, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh143: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=143, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh144: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=144, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh145: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=145, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh146: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=146, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh147: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=147, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh148: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=148, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh149: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=149, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh150: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=150, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh151: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=151, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh152: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=152, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh153: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=153, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh154: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=154, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh155: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=155, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh156: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=156, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh157: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=157, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh158: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=158, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh159: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=159, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh160: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=160, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh161: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=161, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh162: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=162, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh163: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=163, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh164: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=164, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh165: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=165, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh166: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=166, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh167: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=167, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh168: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=168, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh169: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=169, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh170: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=170, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh171: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=171, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh172: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=172, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh173: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=173, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh174: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=174, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh175: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=175, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh176: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=176, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh177: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=177, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh178: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=178, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh179: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=179, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh180: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=180, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh181: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=181, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh182: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=182, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh183: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=183, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh184: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=184, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh185: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=185, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh186: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=186, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh187: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=187, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh188: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=188, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh189: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=189, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh190: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=190, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh191: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=191, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh192: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=192, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh193: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=193, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh194: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=194, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh195: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=195, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh196: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=196, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh197: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=197, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh198: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=198, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh199: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=199, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh200: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=200, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh201: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=201, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh202: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=202, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh203: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=203, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh204: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=204, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh205: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=205, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh206: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=206, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh207: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=207, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh208: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=208, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh209: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=209, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh210: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=210, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh211: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=211, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh212: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=212, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh213: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=213, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh214: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=214, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh215: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=215, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh216: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=216, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh217: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=217, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh218: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=218, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh219: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=219, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh220: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=220, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh221: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=221, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh222: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=222, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh223: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=223, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh224: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=224, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh225: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=225, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh226: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=226, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh227: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=227, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh228: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=228, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh229: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=229, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh230: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=230, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh231: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=231, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh232: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=232, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh233: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=233, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh234: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=234, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh235: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=235, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh236: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=236, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh237: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=237, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh238: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=238, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh239: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=239, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh240: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=240, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh241: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=241, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh242: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=242, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh243: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=243, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh244: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=244, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh245: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=245, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh246: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=246, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh247: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=247, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh248: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=248, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh249: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=249, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh250: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=250, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh251: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=251, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh252: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=252, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh253: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=253, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh254: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=254, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh255: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=255, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh256: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=256, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m32s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m34s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 11m33s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8eead1b446590020
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      290/290 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   28s ago        never        0       no error   
  ct-map-pressure                                                    29s ago        never        0       no error   
  daemon-validate-config                                             59s ago        never        0       no error   
  dns-garbage-collector-job                                          32s ago        never        0       no error   
  endpoint-1993-regeneration-recovery                                never          never        0       no error   
  endpoint-2547-regeneration-recovery                                never          never        0       no error   
  endpoint-509-regeneration-recovery                                 never          never        0       no error   
  endpoint-88-regeneration-recovery                                  never          never        0       no error   
  endpoint-911-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                        1m32s ago      never        0       no error   
  ep-bpf-prog-watchdog                                               29s ago        never        0       no error   
  ipcache-inject-labels                                              29s ago        never        0       no error   
  k8s-heartbeat                                                      32s ago        never        0       no error   
  link-cache                                                         14s ago        never        0       no error   
  local-identity-checkpoint                                          31m29s ago     never        0       no error   
  node-neighbor-link-updater                                         9s ago         never        0       no error   
  remote-etcd-cmesh1                                                 11m32s ago     never        0       no error   
  remote-etcd-cmesh10                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh100                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh101                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh102                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh103                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh104                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh105                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh106                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh107                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh108                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh109                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh11                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh110                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh111                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh112                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh113                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh114                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh115                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh116                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh117                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh118                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh119                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh12                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh120                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh121                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh122                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh123                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh124                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh125                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh126                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh127                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh128                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh129                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh13                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh130                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh131                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh132                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh133                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh134                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh135                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh136                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh137                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh138                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh139                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh14                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh140                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh141                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh142                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh143                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh144                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh145                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh146                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh147                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh148                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh149                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh15                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh150                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh151                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh152                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh153                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh154                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh155                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh156                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh157                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh158                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh159                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh16                                                11m32s ago     never        0       no error   
  remote-etcd-cmesh160                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh161                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh162                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh163                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh164                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh165                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh166                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh167                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh168                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh169                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh17                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh170                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh171                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh172                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh173                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh174                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh175                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh176                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh177                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh178                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh179                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh18                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh180                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh181                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh182                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh183                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh184                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh185                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh186                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh187                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh188                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh189                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh19                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh190                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh191                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh192                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh193                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh194                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh195                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh196                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh197                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh198                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh199                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh2                                                 11m31s ago     never        0       no error   
  remote-etcd-cmesh20                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh200                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh201                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh202                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh203                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh204                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh205                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh206                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh207                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh208                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh209                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh21                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh210                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh211                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh212                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh213                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh214                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh215                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh216                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh217                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh218                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh219                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh22                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh220                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh221                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh222                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh223                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh224                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh225                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh226                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh227                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh228                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh229                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh230                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh231                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh232                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh233                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh234                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh235                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh236                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh237                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh238                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh239                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh24                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh240                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh241                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh242                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh243                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh244                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh245                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh246                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh247                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh248                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh249                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh25                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh250                                               11m32s ago     never        0       no error   
  remote-etcd-cmesh251                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh252                                               11m30s ago     never        0       no error   
  remote-etcd-cmesh253                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh254                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh255                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh256                                               11m31s ago     never        0       no error   
  remote-etcd-cmesh26                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh27                                                11m32s ago     never        0       no error   
  remote-etcd-cmesh28                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh29                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh3                                                 11m31s ago     never        0       no error   
  remote-etcd-cmesh30                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh31                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh32                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh33                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh34                                                11m32s ago     never        0       no error   
  remote-etcd-cmesh35                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh36                                                11m32s ago     never        0       no error   
  remote-etcd-cmesh37                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh38                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh39                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh4                                                 11m31s ago     never        0       no error   
  remote-etcd-cmesh40                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh41                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh42                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh43                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh44                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh45                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh46                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh47                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh48                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh49                                                11m32s ago     never        0       no error   
  remote-etcd-cmesh5                                                 11m30s ago     never        0       no error   
  remote-etcd-cmesh50                                                11m32s ago     never        0       no error   
  remote-etcd-cmesh51                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh52                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh53                                                11m32s ago     never        0       no error   
  remote-etcd-cmesh54                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh55                                                11m32s ago     never        0       no error   
  remote-etcd-cmesh56                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh57                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh58                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh59                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh6                                                 11m32s ago     never        0       no error   
  remote-etcd-cmesh60                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh61                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh62                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh63                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh64                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh65                                                11m32s ago     never        0       no error   
  remote-etcd-cmesh66                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh67                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh68                                                11m32s ago     never        0       no error   
  remote-etcd-cmesh69                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh7                                                 11m30s ago     never        0       no error   
  remote-etcd-cmesh70                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh71                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh72                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh73                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh74                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh75                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh76                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh77                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh78                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh79                                                11m32s ago     never        0       no error   
  remote-etcd-cmesh8                                                 11m30s ago     never        0       no error   
  remote-etcd-cmesh80                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh81                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh82                                                11m32s ago     never        0       no error   
  remote-etcd-cmesh83                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh84                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh85                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh86                                                11m32s ago     never        0       no error   
  remote-etcd-cmesh87                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh88                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh89                                                11m30s ago     never        0       no error   
  remote-etcd-cmesh9                                                 11m31s ago     never        0       no error   
  remote-etcd-cmesh90                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh91                                                11m32s ago     never        0       no error   
  remote-etcd-cmesh92                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh93                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh94                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh95                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh96                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh97                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh98                                                11m31s ago     never        0       no error   
  remote-etcd-cmesh99                                                11m30s ago     never        0       no error   
  resolve-identity-1993                                              1m45s ago      never        0       no error   
  resolve-identity-2547                                              1m29s ago      never        0       no error   
  resolve-identity-509                                               1m26s ago      never        0       no error   
  resolve-identity-88                                                1m26s ago      never        0       no error   
  resolve-identity-911                                               1m28s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-df8787bcf-gsf7l   11m45s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-brf8n                 31m26s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-k6wj6                 31m26s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                     31m29s ago     never        0       no error   
  sync-policymap-1993                                                11m45s ago     never        0       no error   
  sync-policymap-2547                                                1m28s ago      never        0       no error   
  sync-policymap-509                                                 1m24s ago      never        0       no error   
  sync-policymap-88                                                  1m25s ago      never        0       no error   
  sync-policymap-911                                                 1m25s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (1993)                                  4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (509)                                   6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (88)                                    6s ago         never        0       no error   
  sync-utime                                                         29s ago        never        0       no error   
  write-cni-file                                                     31m32s ago     never        0       no error   
Proxy Status:            OK, ip 10.22.0.153, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 753664, max 786431
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 110.45   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
88         Disabled           Disabled          756300     k8s:eks.amazonaws.com/component=coredns                                             10.22.0.81    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh23                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
509        Disabled           Disabled          756300     k8s:eks.amazonaws.com/component=coredns                                             10.22.0.224   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh23                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
911        Disabled           Disabled          4          reserved:health                                                                     10.22.0.84    ready   
1993       Disabled           Disabled          765733     k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.22.0.26    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh23                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
2547       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.large                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
```

#### BPF Policy Get 88

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    178980   2057      0        
Allow    Egress      0          ANY          NONE         disabled    21426    240       0        

```


#### BPF CT List 88

```
Invalid argument: unknown type 88
```


#### Endpoint Get 88

```
[
  {
    "id": 88,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-88-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c20a6a76-a339-4d3b-a196-70486735c1a3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-88",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:21:59.115Z",
            "success-count": 7
          },
          "uuid": "f03095cb-b3c7-4239-b480-8299a5610908"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-k6wj6",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T07:51:59.111Z",
            "success-count": 1
          },
          "uuid": "aa61b578-0533-4411-bc31-25c417295821"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-88",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:00.970Z",
            "success-count": 3
          },
          "uuid": "539ed39c-3925-42b7-bdd9-fb73a4910ac3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (88)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:19.265Z",
            "success-count": 190
          },
          "uuid": "1fa07ae2-566c-4690-a9b7-5c3d6b81d1d5"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "70b9a30412c4e0bdbfddc6264b31fab663a84ef47ee852f0bdc43058c9893f36:eth0",
        "container-id": "70b9a30412c4e0bdbfddc6264b31fab663a84ef47ee852f0bdc43058c9893f36",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-k6wj6",
        "pod-name": "kube-system/coredns-cc6ccd49c-k6wj6"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 756300,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh23",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh23",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:11:57Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.22.0.81",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "a2:7d:a4:d2:93:37",
        "interface-index": 12,
        "interface-name": "lxcf0eb6469040b",
        "mac": "72:6f:37:80:77:52"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 756300,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 756300,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 88

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 88

```
Timestamp              Status    State                   Message
2024-10-30T08:11:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:11:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:57Z   OK        regenerating            Regenerating endpoint: 
2024-10-30T08:11:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:11:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:13Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:13Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:13Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:13Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:12Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:12Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:12Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:12Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:52:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:52:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:52:00Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:52:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:51:59Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:51:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:51:59Z   OK        ready                   Set identity for this endpoint
2024-10-30T07:51:59Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:51:59Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 756300

```
ID       LABELS
756300   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh23
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 509

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    177107   2023      0        
Allow    Egress      0          ANY          NONE         disabled    22912    257       0        

```


#### BPF CT List 509

```
Invalid argument: unknown type 509
```


#### Endpoint Get 509

```
[
  {
    "id": 509,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-509-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f76786f8-0b9a-4cfd-8226-e12b1d5678d6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-509",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:21:59.200Z",
            "success-count": 7
          },
          "uuid": "bdfdefb2-46f9-4063-baae-db590ae24b97"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-brf8n",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T07:51:59.198Z",
            "success-count": 1
          },
          "uuid": "30564e76-47ae-493d-89e6-4f11ea6601dd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-509",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:01.036Z",
            "success-count": 3
          },
          "uuid": "d3122195-8226-4b4b-8860-7bf75fc74615"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (509)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:19.344Z",
            "success-count": 190
          },
          "uuid": "6fe3fb8f-22b3-4020-9628-309099532169"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "451309d71e8a31332801b24dc26b0a9409e0808f90d11fea02b97158cf665e85:eth0",
        "container-id": "451309d71e8a31332801b24dc26b0a9409e0808f90d11fea02b97158cf665e85",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-brf8n",
        "pod-name": "kube-system/coredns-cc6ccd49c-brf8n"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 756300,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh23",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh23",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:11:57Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.22.0.224",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ce:5a:6c:6f:d4:42",
        "interface-index": 14,
        "interface-name": "lxc2f4c37355d56",
        "mac": "8a:9d:d1:e7:ec:01"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 756300,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 756300,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 509

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 509

```
Timestamp              Status   State                   Message
2024-10-30T08:11:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:11:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:57Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:11:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:11:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:12Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:52:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:52:00Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:52:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T07:51:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:51:59Z   OK       ready                   Set identity for this endpoint
2024-10-30T07:51:59Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 756300

```
ID       LABELS
756300   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh23
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 911

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1636741   20697     0        
Allow    Ingress     1          ANY          NONE         disabled    26388     307       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        

```


#### BPF CT List 911

```
Invalid argument: unknown type 911
```


#### Endpoint Get 911

```
[
  {
    "id": 911,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-911-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "6490c4d1-7ba5-4889-b677-09c410e75bfd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-911",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:21:57.403Z",
            "success-count": 7
          },
          "uuid": "edbb0a66-9f37-47e6-8e96-9a9b2d557f9c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-911",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:00.986Z",
            "success-count": 3
          },
          "uuid": "4ac0070e-7dd8-41be-8293-c695f1bc50a9"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:11:57Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.22.0.84",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "4a:6a:bf:33:5d:a5",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "82:76:2b:46:99:77"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 911

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 911

```
Timestamp              Status   State                   Message
2024-10-30T08:11:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:11:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:57Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:11:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:11:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:12Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-30T07:52:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:52:00Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-30T07:52:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:52:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-30T07:51:59Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T07:51:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-30T07:51:57Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:51:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:51:57Z   OK       ready                   Set identity for this endpoint
2024-10-30T07:51:56Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 1993

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11574472   114583    0        
Allow    Ingress     1          ANY          NONE         disabled    10667052   108608    0        
Allow    Egress      0          ANY          NONE         disabled    11929649   118098    0        

```


#### BPF CT List 1993

```
Invalid argument: unknown type 1993
```


#### Endpoint Get 1993

```
[
  {
    "id": 1993,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1993-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "eb2ba9fb-ccfe-4413-a71b-aaf9ea674692"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1993",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:21:40.941Z",
            "success-count": 3
          },
          "uuid": "673cbda2-45df-4e86-8314-6a27edeffd0f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-df8787bcf-gsf7l",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:11:40.938Z",
            "success-count": 1
          },
          "uuid": "b220d72b-02fd-4e77-b491-34507a23a1b7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1993",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:11:41.000Z",
            "success-count": 1
          },
          "uuid": "2b8534bd-4b24-4370-a832-7ad060fe8cfc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1993)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:21.007Z",
            "success-count": 72
          },
          "uuid": "74bb66f1-7cc0-43fb-a35b-0f6fb98c2445"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "3bd4199d9f64f2711ed59699c89d9f615ee531ff625766c01fb7be2ed91fbe95:eth0",
        "container-id": "3bd4199d9f64f2711ed59699c89d9f615ee531ff625766c01fb7be2ed91fbe95",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-df8787bcf-gsf7l",
        "pod-name": "kube-system/clustermesh-apiserver-df8787bcf-gsf7l"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 765733,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh23",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=df8787bcf"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh23",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:11:57Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.22.0.26",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "4a:21:05:6d:cf:f3",
        "interface-index": 18,
        "interface-name": "lxc601ce6424173",
        "mac": "ae:08:f6:24:98:a9"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 765733,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 765733,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1993

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1993

```
Timestamp              Status   State                   Message
2024-10-30T08:11:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:11:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:57Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:11:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:11:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T08:11:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:40Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T08:11:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T08:11:40Z   OK       ready                   Set identity for this endpoint
2024-10-30T08:11:40Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 765733

```
ID       LABELS
765733   k8s:app.kubernetes.io/name=clustermesh-apiserver
         k8s:app.kubernetes.io/part-of=cilium
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh23
         k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 2547

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2547

```
Invalid argument: unknown type 2547
```


#### Endpoint Get 2547

```
[
  {
    "id": 2547,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2547-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d6f2225b-2d57-417f-b109-2d0b4ebc179e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2547",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:21:56.344Z",
            "success-count": 7
          },
          "uuid": "1c2e1c52-4acd-41c0-b2cd-24ae332e3382"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2547",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:21:57.408Z",
            "success-count": 3
          },
          "uuid": "65892e8c-d353-44f9-bfb3-141c6e650f36"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:11:57Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "4a:bc:f0:02:62:f7",
        "interface-name": "cilium_host",
        "mac": "4a:bc:f0:02:62:f7"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2547

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2547

```
Timestamp              Status   State                   Message
2024-10-30T08:11:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:11:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:57Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:11:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:11:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:12Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:52:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:52:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:52:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T07:51:59Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-30T07:51:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:51:58Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-30T07:51:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-30T07:51:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:51:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:51:56Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:51:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:51:56Z   OK       ready                   Set identity for this endpoint
2024-10-30T07:51:56Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.156.166:443 (active)    
                                          2 => 172.31.248.176:443 (active)    
2    10.100.223.176:443    ClusterIP      1 => 172.31.172.110:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.22.0.81:53 (active)         
                                          2 => 10.22.0.224:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.22.0.81:9153 (active)       
                                          2 => 10.22.0.224:9153 (active)      
5    10.100.148.145:2379   ClusterIP      1 => 10.22.0.26:2379 (active)       
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 29372006                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 29372006                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 29372006                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-4015000000 rw-p 00000000 00:00 0 
4015000000-4018000000 ---p 00000000 00:00 0 
ffff7251a000-ffff728f3000 rw-p 00000000 00:00 0 
ffff728f7000-ffff729e8000 rw-p 00000000 00:00 0 
ffff729f0000-ffff72ad1000 rw-p 00000000 00:00 0 
ffff72ad1000-ffff72b12000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff72b12000-ffff72b53000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff72b53000-ffff72b93000 rw-p 00000000 00:00 0 
ffff72b93000-ffff72b95000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff72b95000-ffff72b97000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff72b97000-ffff7314e000 rw-p 00000000 00:00 0 
ffff7314e000-ffff7324e000 rw-p 00000000 00:00 0 
ffff7324e000-ffff7325f000 rw-p 00000000 00:00 0 
ffff7325f000-ffff7525f000 rw-p 00000000 00:00 0 
ffff7525f000-ffff752df000 ---p 00000000 00:00 0 
ffff752df000-ffff752e0000 rw-p 00000000 00:00 0 
ffff752e0000-ffff952df000 ---p 00000000 00:00 0 
ffff952df000-ffff952e0000 rw-p 00000000 00:00 0 
ffff952e0000-ffffb526f000 ---p 00000000 00:00 0 
ffffb526f000-ffffb5270000 rw-p 00000000 00:00 0 
ffffb5270000-ffffb9261000 ---p 00000000 00:00 0 
ffffb9261000-ffffb9262000 rw-p 00000000 00:00 0 
ffffb9262000-ffffb9a5f000 ---p 00000000 00:00 0 
ffffb9a5f000-ffffb9a60000 rw-p 00000000 00:00 0 
ffffb9a60000-ffffb9b5f000 ---p 00000000 00:00 0 
ffffb9b5f000-ffffb9bbf000 rw-p 00000000 00:00 0 
ffffb9bbf000-ffffb9bc1000 r--p 00000000 00:00 0                          [vvar]
ffffb9bc1000-ffffb9bc2000 r-xp 00000000 00:00 0                          [vdso]
ffffff5c1000-ffffff5e2000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium environment keys

```
enable-l2-neigh-discovery:true
disable-external-ip-mitigation:false
bpf-lb-service-map-max:0
ipv6-cluster-alloc-cidr:f00d::/64
hubble-disable-tls:false
k8s-heartbeat-timeout:30s
enable-ipv4-masquerade:true
monitor-aggregation:medium
hubble-skip-unknown-cgroup-ids:true
hubble-redact-http-userinfo:true
tofqdns-proxy-port:0
k8s-sync-timeout:3m0s
state-dir:/var/run/cilium
enable-l2-pod-announcements:false
hubble-metrics:
clustermesh-config:/var/lib/cilium/clustermesh/
keep-config:false
cluster-health-port:4240
encrypt-node:false
set-cilium-node-taints:true
srv6-encap-mode:reduced
force-device-detection:false
bpf-filter-priority:1
bgp-announce-lb-ip:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
k8s-service-proxy-name:
envoy-base-id:0
enable-envoy-config:false
custom-cni-conf:false
monitor-aggregation-interval:5s
bpf-ct-timeout-regular-tcp-fin:10s
tunnel-protocol:vxlan
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
enable-external-ips:false
preallocate-bpf-maps:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
max-internal-timer-delay:0s
node-port-range:
wireguard-persistent-keepalive:0s
bpf-lb-map-max:65536
lib-dir:/var/lib/cilium
bpf-lb-rss-ipv6-src-cidr:
bpf-lb-algorithm:random
nodeport-addresses:
enable-hubble-recorder-api:true
bpf-policy-map-full-reconciliation-interval:15m0s
ipv4-service-loopback-address:169.254.42.1
log-driver:
k8s-namespace:kube-system
enable-hubble:true
mesh-auth-enabled:true
hubble-redact-http-urlquery:false
node-port-algorithm:random
hubble-socket-path:/var/run/cilium/hubble.sock
enable-node-port:false
proxy-admin-port:0
operator-api-serve-addr:127.0.0.1:9234
restore:true
enable-ipv6-big-tcp:false
enable-route-mtu-for-cni-chaining:false
gateway-api-secrets-namespace:
enable-pmtu-discovery:false
direct-routing-skip-unreachable:false
endpoint-queue-size:25
version:false
trace-sock:true
enable-bgp-control-plane:false
enable-ipv6-masquerade:true
enable-bpf-clock-probe:false
http-retry-timeout:0
egress-masquerade-interfaces:ens+
bpf-lb-affinity-map-max:0
hubble-export-allowlist:
crd-wait-timeout:5m0s
enable-unreachable-routes:false
cluster-id:23
http-normalize-path:true
enable-xt-socket-fallback:true
monitor-queue-size:0
ipsec-key-file:
routing-mode:tunnel
disable-iptables-feeder-rules:
enable-auto-protect-node-port-range:true
policy-accounting:true
procfs:/host/proc
enable-srv6:false
enable-ipv4-egress-gateway:false
enable-l2-announcements:false
kvstore-lease-ttl:15m0s
tofqdns-max-deferred-connection-deletes:10000
disable-envoy-version-check:false
enable-ipv6:false
socket-path:/var/run/cilium/cilium.sock
cni-log-file:/var/run/cilium/cilium-cni.log
enable-monitor:true
ipv6-native-routing-cidr:
enable-runtime-device-detection:true
enable-ipsec:false
hubble-redact-enabled:false
enable-well-known-identities:false
disable-endpoint-crd:false
pprof:false
hubble-listen-address::4244
api-rate-limit:
encryption-strict-mode-cidr:
hubble-export-denylist:
bpf-ct-timeout-service-tcp:2h13m20s
derive-masq-ip-addr-from-device:
vtep-endpoint:
nodes-gc-interval:5m0s
bpf-ct-timeout-regular-any:1m0s
bpf-lb-acceleration:disabled
k8s-kubeconfig-path:
bpf-root:/sys/fs/bpf
allow-localhost:auto
local-router-ipv4:
enable-gateway-api:false
cni-external-routing:false
local-max-addr-scope:252
l2-announcements-retry-period:2s
policy-queue-size:100
gops-port:9890
http-idle-timeout:0
install-no-conntrack-iptables-rules:false
k8s-client-connection-timeout:30s
envoy-config-timeout:2m0s
enable-session-affinity:false
vtep-mask:
enable-ipv4-fragment-tracking:true
tofqdns-idle-connection-grace-period:0s
enable-k8s-terminating-endpoint:true
ipam-multi-pool-pre-allocation:
ipam-default-ip-pool:default
enable-endpoint-health-checking:true
ipv6-range:auto
http-retry-count:3
ipv4-native-routing-cidr:
hubble-export-fieldmask:
bpf-policy-map-max:16384
bpf-nat-global-max:524288
ipam:cluster-pool
remove-cilium-node-taints:true
fixed-identity-mapping:
hubble-event-buffer-capacity:4095
dnsproxy-concurrency-limit:0
enable-policy:default
prepend-iptables-chains:true
enable-high-scale-ipcache:false
bpf-ct-global-any-max:262144
enable-cilium-api-server-access:
enable-bbr:false
mke-cgroup-mount:
conntrack-gc-interval:0s
enable-mke:false
read-cni-conf:
enable-k8s-api-discovery:false
bpf-lb-maglev-table-size:16381
enable-health-checking:true
dnsproxy-insecure-skip-transparent-mode-check:false
enable-metrics:true
cluster-name:cmesh23
envoy-keep-cap-netbindservice:false
fqdn-regex-compile-lru-size:1024
ip-masq-agent-config-path:/etc/config/ip-masq-agent
auto-direct-node-routes:false
enable-recorder:false
bpf-sock-rev-map-max:262144
enable-sctp:false
direct-routing-device:
enable-k8s-networkpolicy:true
use-cilium-internal-ip-for-ipsec:false
clustermesh-ip-identities-sync-timeout:1m0s
kvstore-opt:
envoy-log:
conntrack-gc-max-interval:0s
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
nat-map-stats-interval:30s
ingress-secrets-namespace:
enable-tracing:false
enable-ipsec-xfrm-state-caching:true
ipv6-service-range:auto
k8s-client-connection-keep-alive:30s
dnsproxy-enable-transparent-mode:true
endpoint-gc-interval:5m0s
enable-ipsec-encrypted-overlay:false
controller-group-metrics:
proxy-prometheus-port:0
k8s-client-burst:20
bpf-lb-mode:snat
enable-wireguard-userspace-fallback:false
proxy-idle-timeout-seconds:60
enable-ipip-termination:false
synchronize-k8s-nodes:true
certificates-directory:/var/run/cilium/certs
monitor-aggregation-flags:all
bpf-fragments-map-max:8192
identity-restore-grace-period:30s
agent-liveness-update-interval:1s
envoy-config-retry-interval:15s
k8s-require-ipv6-pod-cidr:false
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
bpf-lb-rss-ipv4-src-cidr:
enable-local-node-route:true
exclude-node-label-patterns:
pprof-address:localhost
tofqdns-min-ttl:0
bpf-lb-sock-hostns-only:false
kvstore:
http-max-grpc-timeout:0
mesh-auth-mutual-connect-timeout:5s
prometheus-serve-addr:
kube-proxy-replacement:false
label-prefix-file:
max-connected-clusters:511
bpf-events-policy-verdict-enabled:true
proxy-max-requests-per-connection:0
l2-announcements-renew-deadline:5s
log-system-load:false
enable-svc-source-range-check:true
external-envoy-proxy:true
k8s-require-ipv4-pod-cidr:false
bpf-ct-timeout-regular-tcp-syn:1m0s
enable-node-selector-labels:false
enable-ipv4-big-tcp:false
enable-bpf-tproxy:false
egress-gateway-reconciliation-trigger-interval:1s
vtep-mac:
cni-exclusive:true
bpf-events-drop-enabled:true
enable-k8s:true
log-opt:
clustermesh-enable-mcs-api:false
enable-ipsec-key-watcher:true
bpf-lb-service-backend-map-max:0
operator-prometheus-serve-addr::9963
proxy-connect-timeout:2
iptables-random-fully:false
exclude-local-address:
node-port-acceleration:disabled
enable-encryption-strict-mode:false
trace-payloadlen:128
join-cluster:false
proxy-portrange-min:10000
auto-create-cilium-node-resource:true
identity-allocation-mode:crd
l2-pod-announcements-interface:
bpf-neigh-global-max:524288
nat-map-stats-entries:32
cflags:
enable-local-redirect-policy:false
hubble-flowlogs-config-path:
proxy-portrange-max:20000
enable-host-firewall:false
node-port-bind-protection:true
dnsproxy-socket-linger-timeout:10
enable-active-connection-tracking:false
mesh-auth-rotated-identities-queue-size:1024
bpf-lb-maglev-map-max:0
bgp-announce-pod-cidr:false
mesh-auth-mutual-listener-port:0
policy-cidr-match-mode:
vlan-bpf-bypass:
enable-service-topology:false
hubble-redact-http-headers-allow:
bypass-ip-availability-upon-restore:false
service-no-backend-response:reject
bpf-lb-sock:false
kube-proxy-replacement-healthz-bind-address:
tofqdns-pre-cache:
max-controller-interval:0
egress-gateway-policy-map-max:16384
enable-health-check-nodeport:true
proxy-max-connection-duration-seconds:0
multicast-enabled:false
ipv6-mcast-device:
hubble-redact-kafka-apikey:false
enable-nat46x64-gateway:false
enable-endpoint-routes:false
proxy-xff-num-trusted-hops-ingress:0
bgp-config-path:/var/lib/cilium/bgp/config.yaml
cilium-endpoint-gc-interval:5m0s
cmdref:
hubble-drop-events-reasons:auth_required,policy_denied
egress-multi-home-ip-rule-compat:false
agent-labels:
dnsproxy-concurrency-processing-grace-period:0s
bpf-lb-sock-terminate-pod-connections:false
hubble-export-file-path:
enable-ingress-controller:false
enable-cilium-endpoint-slice:false
hubble-drop-events-interval:2m0s
route-metric:0
labels:
k8s-service-cache-size:128
dns-policy-unload-on-shutdown:false
ipv6-node:auto
bpf-map-dynamic-size-ratio:0.0025
mesh-auth-spiffe-trust-domain:spiffe.cilium
ipv4-service-range:auto
agent-health-port:9879
enable-ipv6-ndp:false
hubble-drop-events:false
bpf-node-map-max:16384
enable-masquerade-to-route-source:false
enable-stale-cilium-endpoint-cleanup:true
ipam-cilium-node-update-rate:15s
enable-health-check-loadbalancer-ip:false
enable-custom-calls:false
bpf-lb-source-range-map-max:0
mtu:0
l2-announcements-lease-duration:15s
cgroup-root:/run/cilium/cgroupv2
unmanaged-pod-watcher-interval:15
use-full-tls-context:false
kvstore-max-consecutive-quorum-errors:2
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
bpf-lb-rev-nat-map-max:0
k8s-api-server:
proxy-xff-num-trusted-hops-egress:0
devices:
bpf-lb-external-clusterip:false
debug:false
metrics:
set-cilium-is-up-condition:true
enable-wireguard:false
cluster-pool-ipv4-mask-size:24
mesh-auth-spire-admin-socket:
identity-heartbeat-timeout:30m0s
mesh-auth-queue-size:1024
hubble-recorder-sink-queue-size:1024
enable-cilium-health-api-server-access:
debug-verbose:
ipv4-pod-subnets:
kvstore-periodic-sync:5m0s
iptables-lock-timeout:5s
bpf-ct-timeout-service-any:1m0s
policy-audit-mode:false
config-dir:/tmp/cilium/config-map
tofqdns-dns-reject-response-code:refused
enable-ipv4:true
allocator-list-timeout:3m0s
enable-identity-mark:true
bpf-auth-map-max:524288
node-port-mode:snat
enable-icmp-rules:true
config:
node-labels:
config-sources:config-map:kube-system/cilium-config
cni-chaining-target:
tofqdns-endpoint-max-ip-per-hostname:50
enable-k8s-endpoint-slice:true
http-request-timeout:3600
enable-l7-proxy:true
hubble-metrics-server:
enable-vtep:false
mesh-auth-signal-backoff-duration:1s
mesh-auth-gc-interval:5m0s
ipsec-key-rotation-duration:5m0s
pprof-port:6060
encryption-strict-mode-allow-remote-node-identities:false
bpf-ct-timeout-service-tcp-grace:1m0s
datapath-mode:veth
dnsproxy-lock-count:131
hubble-event-queue-size:0
encrypt-interface:
bpf-map-event-buffers:
static-cnp-path:
tofqdns-proxy-response-max-delay:100ms
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
tunnel-port:0
k8s-client-qps:10
allow-icmp-frag-needed:true
install-iptables-rules:true
tofqdns-enable-dns-compression:true
arping-refresh-period:30s
hubble-export-file-max-size-mb:10
hubble-monitor-events:
hubble-prefer-ipv6:false
enable-ip-masq-agent:false
enable-tcx:true
annotate-k8s-node:false
container-ip-local-reserved-ports:auto
hubble-recorder-storage-path:/var/run/cilium/pcaps
clustermesh-sync-timeout:1m0s
proxy-gid:1337
cluster-pool-ipv4-cidr:10.22.0.0/16
identity-change-grace-period:5s
hubble-export-file-max-backups:5
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bpf-lb-dsr-dispatch:opt
enable-host-port:false
bpf-events-trace-enabled:true
enable-bandwidth-manager:false
bpf-lb-dsr-l4-xlate:frontend
dnsproxy-lock-timeout:500ms
envoy-secrets-namespace:
hubble-export-file-compress:false
enable-bpf-masquerade:false
enable-xdp-prefilter:false
ipv6-pod-subnets:
enable-host-legacy-routing:false
cni-chaining-mode:none
bpf-ct-global-tcp-max:524288
clustermesh-enable-endpoint-sync:false
ipv4-range:auto
policy-trigger-interval:1s
vtep-cidr:
kvstore-connectivity-timeout:2m0s
ipv4-node:auto
local-router-ipv6:
endpoint-bpf-prog-watchdog-interval:30s
identity-gc-interval:15m0s
dns-max-ips-per-restored-rule:1000
hubble-redact-http-headers-deny:
bpf-ct-timeout-regular-tcp:2h13m20s
```


#### Cilium encryption


