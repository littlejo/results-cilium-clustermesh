top - 08:22:55 up 39 min,  0 users,  load average: 0.43, 0.48, 0.34
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s):  7.4 us, 37.0 sy,  0.0 ni, 51.9 id,  0.0 wa,  0.0 hi,  3.7 si,  0.0 st
MiB Mem :   7814.2 total,   4456.4 free,   1210.5 used,   2147.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6418.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 399208  78712 S   6.7   5.0   0:58.77 cilium-+
    397 root      20   0 1229488   8132   3900 S   0.0   0.1   0:01.14 cilium-+
    627 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    640 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    646 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    660 root      20   0 1240432  16760  11484 S   0.0   0.2   0:00.02 cilium-+
    666 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    709 root      20   0    6576   2412   2084 R   0.0   0.0   0:00.00 top
    728 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
