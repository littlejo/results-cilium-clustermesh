alloc: 175.49MB (184017928 bytes)
total-alloc: 2.44GB (2617837240 bytes)
sys: 333.02MB (349196644 bytes)
lookups: 0
mallocs: 65792238
frees: 63975907
heap-alloc: 175.49MB (184017928 bytes)
heap-sys: 252.60MB (264871936 bytes)
heap-idle: 44.13MB (46276608 bytes)
heap-in-use: 208.47MB (218595328 bytes)
heap-released: 2.44MB (2555904 bytes)
heap-objects: 1816331
stack-in-use: 67.38MB (70647808 bytes)
stack-sys: 67.38MB (70647808 bytes)
stack-mspan-inuse: 3.34MB (3503200 bytes)
stack-mspan-sys: 3.98MB (4177920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.00MB (1053185 bytes)
gc-sys: 6.03MB (6328000 bytes)
next-gc: when heap-alloc >= 215.56MB (226032008 bytes)
last-gc: 2024-10-30 08:22:59.41224909 +0000 UTC
gc-pause-total: 16.8477ms
gc-pause: 95917
gc-pause-end: 1730276579412249090
num-gc: 87
num-forced-gc: 0
gc-cpu-fraction: 0.00039284289072572995
enable-gc: true
debug-gc: false
