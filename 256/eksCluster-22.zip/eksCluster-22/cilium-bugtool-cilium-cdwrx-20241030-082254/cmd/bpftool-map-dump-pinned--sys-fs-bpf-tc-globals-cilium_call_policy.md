key: 58 00 00 00  value: 12 02 00 00
key: fd 01 00 00  value: 29 02 00 00
key: 8f 03 00 00  value: 21 02 00 00
key: c9 07 00 00  value: 70 02 00 00
Found 4 elements
