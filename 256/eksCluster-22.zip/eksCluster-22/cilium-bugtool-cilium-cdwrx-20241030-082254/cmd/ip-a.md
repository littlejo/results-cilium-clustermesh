1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:82:15:22:a6:d3 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.172.110/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3053sec preferred_lft 3053sec
    inet6 fe80::482:15ff:fe22:a6d3/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:29:38:bb:4c:15 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.190.95/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::429:38ff:febb:4c15/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:56:ae:10:88:95 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6c56:aeff:fe10:8895/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:bc:f0:02:62:f7 brd ff:ff:ff:ff:ff:ff
    inet 10.22.0.153/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::48bc:f0ff:fe02:62f7/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 2e:e0:d0:74:5c:b1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2ce0:d0ff:fe74:5cb1/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:6a:bf:33:5d:a5 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::486a:bfff:fe33:5da5/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf0eb6469040b@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:7d:a4:d2:93:37 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a07d:a4ff:fed2:9337/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc2f4c37355d56@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:5a:6c:6f:d4:42 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::cc5a:6cff:fe6f:d442/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc601ce6424173@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:21:05:6d:cf:f3 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::4821:5ff:fe6d:cff3/64 scope link 
       valid_lft forever preferred_lft forever
