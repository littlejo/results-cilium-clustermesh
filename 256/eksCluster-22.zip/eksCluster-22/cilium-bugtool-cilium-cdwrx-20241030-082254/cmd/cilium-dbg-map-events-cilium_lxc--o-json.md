{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:51:56.224Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.172.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:51:56.224Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.190.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:51:56.224Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:00.969Z",
  "value": "id=88    sec_id=756300 flags=0x0000 ifindex=12  mac=72:6F:37:80:77:52 nodemac=A2:7D:A4:D2:93:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:00.982Z",
  "value": "id=911   sec_id=4     flags=0x0000 ifindex=10  mac=82:76:2B:46:99:77 nodemac=4A:6A:BF:33:5D:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:00.984Z",
  "value": "id=88    sec_id=756300 flags=0x0000 ifindex=12  mac=72:6F:37:80:77:52 nodemac=A2:7D:A4:D2:93:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:01.031Z",
  "value": "id=911   sec_id=4     flags=0x0000 ifindex=10  mac=82:76:2B:46:99:77 nodemac=4A:6A:BF:33:5D:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:01.034Z",
  "value": "id=509   sec_id=756300 flags=0x0000 ifindex=14  mac=8A:9D:D1:E7:EC:01 nodemac=CE:5A:6C:6F:D4:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:12.685Z",
  "value": "id=509   sec_id=756300 flags=0x0000 ifindex=14  mac=8A:9D:D1:E7:EC:01 nodemac=CE:5A:6C:6F:D4:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:12.686Z",
  "value": "id=911   sec_id=4     flags=0x0000 ifindex=10  mac=82:76:2B:46:99:77 nodemac=4A:6A:BF:33:5D:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:12.686Z",
  "value": "id=88    sec_id=756300 flags=0x0000 ifindex=12  mac=72:6F:37:80:77:52 nodemac=A2:7D:A4:D2:93:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:12.717Z",
  "value": "id=441   sec_id=765733 flags=0x0000 ifindex=16  mac=4A:3B:47:6F:AF:99 nodemac=8E:43:0A:9B:DF:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:13.686Z",
  "value": "id=88    sec_id=756300 flags=0x0000 ifindex=12  mac=72:6F:37:80:77:52 nodemac=A2:7D:A4:D2:93:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:13.686Z",
  "value": "id=911   sec_id=4     flags=0x0000 ifindex=10  mac=82:76:2B:46:99:77 nodemac=4A:6A:BF:33:5D:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:13.686Z",
  "value": "id=441   sec_id=765733 flags=0x0000 ifindex=16  mac=4A:3B:47:6F:AF:99 nodemac=8E:43:0A:9B:DF:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:13.686Z",
  "value": "id=509   sec_id=756300 flags=0x0000 ifindex=14  mac=8A:9D:D1:E7:EC:01 nodemac=CE:5A:6C:6F:D4:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.999Z",
  "value": "id=1993  sec_id=765733 flags=0x0000 ifindex=18  mac=AE:08:F6:24:98:A9 nodemac=4A:21:05:6D:CF:F3"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.22.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.636Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.310Z",
  "value": "id=509   sec_id=756300 flags=0x0000 ifindex=14  mac=8A:9D:D1:E7:EC:01 nodemac=CE:5A:6C:6F:D4:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.310Z",
  "value": "id=88    sec_id=756300 flags=0x0000 ifindex=12  mac=72:6F:37:80:77:52 nodemac=A2:7D:A4:D2:93:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.311Z",
  "value": "id=1993  sec_id=765733 flags=0x0000 ifindex=18  mac=AE:08:F6:24:98:A9 nodemac=4A:21:05:6D:CF:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.312Z",
  "value": "id=911   sec_id=4     flags=0x0000 ifindex=10  mac=82:76:2B:46:99:77 nodemac=4A:6A:BF:33:5D:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.318Z",
  "value": "id=88    sec_id=756300 flags=0x0000 ifindex=12  mac=72:6F:37:80:77:52 nodemac=A2:7D:A4:D2:93:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.319Z",
  "value": "id=509   sec_id=756300 flags=0x0000 ifindex=14  mac=8A:9D:D1:E7:EC:01 nodemac=CE:5A:6C:6F:D4:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.320Z",
  "value": "id=1993  sec_id=765733 flags=0x0000 ifindex=18  mac=AE:08:F6:24:98:A9 nodemac=4A:21:05:6D:CF:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.320Z",
  "value": "id=911   sec_id=4     flags=0x0000 ifindex=10  mac=82:76:2B:46:99:77 nodemac=4A:6A:BF:33:5D:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.324Z",
  "value": "id=911   sec_id=4     flags=0x0000 ifindex=10  mac=82:76:2B:46:99:77 nodemac=4A:6A:BF:33:5D:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.325Z",
  "value": "id=88    sec_id=756300 flags=0x0000 ifindex=12  mac=72:6F:37:80:77:52 nodemac=A2:7D:A4:D2:93:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.326Z",
  "value": "id=509   sec_id=756300 flags=0x0000 ifindex=14  mac=8A:9D:D1:E7:EC:01 nodemac=CE:5A:6C:6F:D4:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.329Z",
  "value": "id=1993  sec_id=765733 flags=0x0000 ifindex=18  mac=AE:08:F6:24:98:A9 nodemac=4A:21:05:6D:CF:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:56.322Z",
  "value": "id=911   sec_id=4     flags=0x0000 ifindex=10  mac=82:76:2B:46:99:77 nodemac=4A:6A:BF:33:5D:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:56.322Z",
  "value": "id=1993  sec_id=765733 flags=0x0000 ifindex=18  mac=AE:08:F6:24:98:A9 nodemac=4A:21:05:6D:CF:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:56.322Z",
  "value": "id=509   sec_id=756300 flags=0x0000 ifindex=14  mac=8A:9D:D1:E7:EC:01 nodemac=CE:5A:6C:6F:D4:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:56.322Z",
  "value": "id=88    sec_id=756300 flags=0x0000 ifindex=12  mac=72:6F:37:80:77:52 nodemac=A2:7D:A4:D2:93:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.322Z",
  "value": "id=911   sec_id=4     flags=0x0000 ifindex=10  mac=82:76:2B:46:99:77 nodemac=4A:6A:BF:33:5D:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.322Z",
  "value": "id=1993  sec_id=765733 flags=0x0000 ifindex=18  mac=AE:08:F6:24:98:A9 nodemac=4A:21:05:6D:CF:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.323Z",
  "value": "id=88    sec_id=756300 flags=0x0000 ifindex=12  mac=72:6F:37:80:77:52 nodemac=A2:7D:A4:D2:93:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.22.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.324Z",
  "value": "id=509   sec_id=756300 flags=0x0000 ifindex=14  mac=8A:9D:D1:E7:EC:01 nodemac=CE:5A:6C:6F:D4:42"
}

