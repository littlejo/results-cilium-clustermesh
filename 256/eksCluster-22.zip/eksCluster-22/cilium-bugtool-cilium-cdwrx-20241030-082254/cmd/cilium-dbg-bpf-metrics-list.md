REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36490     2887904     677    bpf_overlay.c
Interface                 INGRESS     661521    134766626   1132   bpf_host.c
Success                   EGRESS      16446     1295345     1694   bpf_host.c
Success                   EGRESS      287442    36347554    1308   bpf_lxc.c
Success                   EGRESS      36664     2905196     53     encap.h
Success                   INGRESS     328975    37175699    86     l3.h
Success                   INGRESS     349671    38812374    235    trace.h
Unsupported L3 protocol   EGRESS      43        3202        1492   bpf_lxc.c
