CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68f964b7_deb9_45d5_937a_d55ba2d41672.slice/cri-containerd-84a4a0b59cfd9866f60d30d84c3149643e12ebabb6ed77299eb7d15dad435db5.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68f964b7_deb9_45d5_937a_d55ba2d41672.slice/cri-containerd-70b9a30412c4e0bdbfddc6264b31fab663a84ef47ee852f0bdc43058c9893f36.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcfbd937b_b27c_4bfd_81b6_c291bf1a1dd5.slice/cri-containerd-a0f670c7b876f04dcc78b6048e5e5f07fc99fe3a1654db59858ed1bbf42714ee.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcfbd937b_b27c_4bfd_81b6_c291bf1a1dd5.slice/cri-containerd-5f36f321e93dd4529b47fb3c66afad88990e547059616ab54ca2808661eaf3c4.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod751c7419_b1b2_4f24_9add_65c5f7b2304f.slice/cri-containerd-4c2e4a356283b1502dbacf72b0f1238129aea580ee1cd0b2ebf7016baebd2d7a.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod751c7419_b1b2_4f24_9add_65c5f7b2304f.slice/cri-containerd-451309d71e8a31332801b24dc26b0a9409e0808f90d11fea02b97158cf665e85.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd04eeecf_71fb_4a8e_a2ca_7f7044a99fa2.slice/cri-containerd-db36cd817b0bbaf87761d05a34e27077bd25ada82f02acf7715b8f1319cf7a5c.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd04eeecf_71fb_4a8e_a2ca_7f7044a99fa2.slice/cri-containerd-204444b43da3ac30f8c45a84a2734819b7a3c7a52eda8b9c771fa874ac6d2ff8.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ddf2a35_05ff_4f0e_8ef5_3f270372b3ed.slice/cri-containerd-1a487fb3f2e6371e4e131e67ccc2ae1acdd39d6d99eb720be49c595557942950.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ddf2a35_05ff_4f0e_8ef5_3f270372b3ed.slice/cri-containerd-9923e10dd8bf1c7e28e9aec3a4a9aaa50fefc13b0ceaa79f10ae7ae0db500de1.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a854f60_fd5b_4a4a_9e45_41479193c4ab.slice/cri-containerd-488ce87654c041bd22d815ae6d42135079ed707481c52897c6b46f0963252605.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a854f60_fd5b_4a4a_9e45_41479193c4ab.slice/cri-containerd-60c981bce43c5a0bfa4bf9734dafa0c4f5369d3859bba0a90fdda7b458dac928.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddcea8b09_f310_4161_ab5a_2bb44015b703.slice/cri-containerd-a07a35818c837ed04b69697ff315187524147ecaed125784662c43f24bb59d81.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddcea8b09_f310_4161_ab5a_2bb44015b703.slice/cri-containerd-a61418f0b2a6de2d78b048c143c394ea7770f6b5433091db9d523790b3b83c60.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddcea8b09_f310_4161_ab5a_2bb44015b703.slice/cri-containerd-3bd4199d9f64f2711ed59699c89d9f615ee531ff625766c01fb7be2ed91fbe95.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddcea8b09_f310_4161_ab5a_2bb44015b703.slice/cri-containerd-703dfe4dcb8f47dd72881551cbceadc11d6ab8d469e83a368cb65eb4d6af22e9.scope
    653      cgroup_device   multi                                          
