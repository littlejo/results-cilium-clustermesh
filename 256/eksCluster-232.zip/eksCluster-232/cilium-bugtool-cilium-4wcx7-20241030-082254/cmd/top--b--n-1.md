top - 08:22:56 up 28 min,  0 users,  load average: 0.64, 0.30, 0.21
Tasks:  11 total,   2 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 66.7 us, 23.3 sy,  0.0 ni, 10.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4467.3 free,   1200.5 used,   2146.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6428.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 389636  79872 S  93.3   4.9   0:45.52 cilium-+
    682 root      20   0 1240432  16904  11484 S   6.7   0.2   0:00.03 cilium-+
    394 root      20   0 1229744   6988   2864 S   0.0   0.1   0:01.05 cilium-+
    680 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    681 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    696 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    712 root      20   0    2208    788    708 S   0.0   0.0   0:00.00 timeout
    732 root      20   0 1244340  22352  14528 S   0.0   0.3   0:00.09 hubble
    761 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    780 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    786 root      20   0 1692104   9392   6636 R   0.0   0.1   0:00.00 runc:[2+
