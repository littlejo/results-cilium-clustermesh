key: d2 05 00 00  value: 66 02 00 00
key: 58 0b 00 00  value: 1a 02 00 00
key: f9 0c 00 00  value: 1e 02 00 00
key: 34 0e 00 00  value: 03 02 00 00
Found 4 elements
