alloc: 194.83MB (204290552 bytes)
total-alloc: 2.34GB (2512388040 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 65130804
frees: 63100953
heap-alloc: 194.83MB (204290552 bytes)
heap-sys: 251.58MB (263798784 bytes)
heap-idle: 29.43MB (30859264 bytes)
heap-in-use: 222.15MB (232939520 bytes)
heap-released: 2.19MB (2293760 bytes)
heap-objects: 2029851
stack-in-use: 64.38MB (67502080 bytes)
stack-sys: 64.38MB (67502080 bytes)
stack-mspan-inuse: 3.46MB (3628320 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 934.32KB (956745 bytes)
gc-sys: 6.05MB (6346360 bytes)
next-gc: when heap-alloc >= 219.68MB (230354344 bytes)
last-gc: 2024-10-30 08:22:56.292925468 +0000 UTC
gc-pause-total: 23.408345ms
gc-pause: 85166
gc-pause-end: 1730276576292925468
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0006092817592370245
enable-gc: true
debug-gc: false
