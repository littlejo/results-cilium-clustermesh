[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7cf7a930_2352_44cb_83f2_568c4ccc1890.slice/cri-containerd-66a04b237aaf0dfd4d8e389ec57ec15ab159f5f08e0dfbc51b1b9902ae36b617.scope"
      }
    ],
    "ips": [
      "10.232.0.176"
    ],
    "name": "coredns-cc6ccd49c-nrbft",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfe992e68_c14d_42f3_a505_6767aaef0eac.slice/cri-containerd-0ad53dcc2ad6aec69a3f403455abee6a6708a3405b6df04391bbd4dbf1e843e0.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfe992e68_c14d_42f3_a505_6767aaef0eac.slice/cri-containerd-6d15b7d4583864fd04602e6a05e9a14bdfc9f75fcddbb775934c11a7ad57e6ee.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfe992e68_c14d_42f3_a505_6767aaef0eac.slice/cri-containerd-17c0101dc67f005bb4e209f637f4f79fcba993b063635909e1237ef0778f5faa.scope"
      }
    ],
    "ips": [
      "10.232.0.78"
    ],
    "name": "clustermesh-apiserver-c7787c6d-z5rdb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode394f94e_5bed_4c8c_aaba_f80555aaa977.slice/cri-containerd-d9ea6a37cba6ec5fbe6ed722268af585356c0d2ea8bc0fff801d591fc62ef227.scope"
      }
    ],
    "ips": [
      "10.232.0.215"
    ],
    "name": "coredns-cc6ccd49c-hvr89",
    "namespace": "kube-system"
  }
]

