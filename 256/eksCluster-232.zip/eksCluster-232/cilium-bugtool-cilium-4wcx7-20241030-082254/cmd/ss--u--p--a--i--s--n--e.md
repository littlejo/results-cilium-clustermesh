Total: 677
TCP:   1874 (estab 438, closed 1417, orphaned 0, timewait 567)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  457       446       11       
INET	  467       452       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:40157      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:34186 sk:3f8 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.189.68%ens5:68         0.0.0.0:*    uid:192 ino:15715 sk:3f9 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:35182 sk:3fa cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:14161 sk:3fb cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:35181 sk:3fc cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:14162 sk:3fd cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::41b:62ff:fef5:c379]%ens5:546           [::]:*    uid:192 ino:15710 sk:3fe cgroup:unreachable:c4e v6only:1 <->                   
