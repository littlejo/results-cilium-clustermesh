IP ADDRESS        LOCAL ENDPOINT INFO
10.232.0.183:0    (localhost)                                                                                        
10.232.0.176:0    id=3636  sec_id=7667661 flags=0x0000 ifindex=12  mac=02:3D:9D:AA:20:3A nodemac=6A:7B:95:99:AE:D7   
172.31.189.68:0   (localhost)                                                                                        
10.232.0.215:0    id=3321  sec_id=7667661 flags=0x0000 ifindex=14  mac=CA:20:B6:35:AE:32 nodemac=36:E4:DE:5B:40:93   
172.31.182.14:0   (localhost)                                                                                        
10.232.0.78:0     id=1490  sec_id=7643794 flags=0x0000 ifindex=18  mac=C6:7A:2D:5A:25:4C nodemac=1A:E0:C2:A1:26:38   
10.232.0.106:0    id=2904  sec_id=4     flags=0x0000 ifindex=10  mac=16:51:FA:8D:69:68 nodemac=8A:8F:5D:C5:F3:2E     
