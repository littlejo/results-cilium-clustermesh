REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36986     2927550     677    bpf_overlay.c
Interface                 INGRESS     671443    136074064   1132   bpf_host.c
Success                   EGRESS      16706     1312745     1694   bpf_host.c
Success                   EGRESS      293211    35962590    1308   bpf_lxc.c
Success                   EGRESS      37598     2964775     53     encap.h
Success                   INGRESS     335274    38102347    86     l3.h
Success                   INGRESS     356204    39761128    235    trace.h
Unsupported L3 protocol   EGRESS      44        3312        1492   bpf_lxc.c
