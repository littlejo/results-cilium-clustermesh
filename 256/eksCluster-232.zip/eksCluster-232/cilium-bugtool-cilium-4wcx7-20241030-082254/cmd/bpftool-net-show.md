xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 497
ens6(5) clsact/ingress cil_from_netdev-ens6 id 505
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 491
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 484
cilium_host(7) clsact/egress cil_from_host-cilium_host id 485
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 539
lxc72f16fa5bf63(12) clsact/ingress cil_from_container-lxc72f16fa5bf63 id 521
lxc9d00c18f9066(14) clsact/ingress cil_from_container-lxc9d00c18f9066 id 532
lxcc7ee49084e19(18) clsact/ingress cil_from_container-lxcc7ee49084e19 id 618

flow_dissector:

netfilter:

