CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode394f94e_5bed_4c8c_aaba_f80555aaa977.slice/cri-containerd-3fa56cb56655639fb166dba07bb184302d0fe507e4166391b4d0fd834866ef7e.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode394f94e_5bed_4c8c_aaba_f80555aaa977.slice/cri-containerd-d9ea6a37cba6ec5fbe6ed722268af585356c0d2ea8bc0fff801d591fc62ef227.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7cf7a930_2352_44cb_83f2_568c4ccc1890.slice/cri-containerd-dcd92cec9f87193cd50c277367a9bf64598ab36231c1b8f409be7d89b43a8e6d.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7cf7a930_2352_44cb_83f2_568c4ccc1890.slice/cri-containerd-66a04b237aaf0dfd4d8e389ec57ec15ab159f5f08e0dfbc51b1b9902ae36b617.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5f4abc4d_e2d1_4033_be8f_f7aba0adeea0.slice/cri-containerd-ff014305b36a05defc5103ec00e9800dcfdb1beefe0a386b2a991b1163926d8c.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5f4abc4d_e2d1_4033_be8f_f7aba0adeea0.slice/cri-containerd-25258acb52b82fcb8f46c22a43a6dc3b0de1dc05e8cbefecfe687d6e4f1b47ce.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9c1c165a_90f7_4ac0_8ffa_425ce9c084f3.slice/cri-containerd-7421aafd7bee1e8fcc74a4da9a15446975c4b5fe6a56746883b328a2dada5914.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9c1c165a_90f7_4ac0_8ffa_425ce9c084f3.slice/cri-containerd-c8f5bf1f7aaab6088662689cea915e7c2822786218cc2994e2dbf2a1cb0d68dc.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfbcdda02_9844_4c45_9402_295081dbe010.slice/cri-containerd-5bae9974831824f2df20249d7a81bef04c7bc9f1255a90f164c162b571b2dce2.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfbcdda02_9844_4c45_9402_295081dbe010.slice/cri-containerd-f1240d0559a2a2c39c68dcf2c685549e358eef61341e5808c3d1e95db6711b77.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod153322e1_5105_4ecd_b678_2c1a12f75b44.slice/cri-containerd-db3668f1c2c0b0d5b65c0f146100c0f9a7ae3a5f231ca708c6f7ffad2582974c.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod153322e1_5105_4ecd_b678_2c1a12f75b44.slice/cri-containerd-f0d7450e4596056873ad9e507ec62fa30a7338cc2780aadc2cea4c0ad3750e58.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfe992e68_c14d_42f3_a505_6767aaef0eac.slice/cri-containerd-0ad53dcc2ad6aec69a3f403455abee6a6708a3405b6df04391bbd4dbf1e843e0.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfe992e68_c14d_42f3_a505_6767aaef0eac.slice/cri-containerd-38c0da5be4aa5c72fc1f9189e34491182c3d17d2c5720d9bbc15e0fe304d8bc5.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfe992e68_c14d_42f3_a505_6767aaef0eac.slice/cri-containerd-6d15b7d4583864fd04602e6a05e9a14bdfc9f75fcddbb775934c11a7ad57e6ee.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfe992e68_c14d_42f3_a505_6767aaef0eac.slice/cri-containerd-17c0101dc67f005bb4e209f637f4f79fcba993b063635909e1237ef0778f5faa.scope
    647      cgroup_device   multi                                          
