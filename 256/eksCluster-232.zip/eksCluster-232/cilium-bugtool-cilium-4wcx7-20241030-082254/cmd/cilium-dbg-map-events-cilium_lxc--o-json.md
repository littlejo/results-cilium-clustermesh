{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:35.069Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.182.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:35.069Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.189.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:35.069Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:39.629Z",
  "value": "id=2904  sec_id=4     flags=0x0000 ifindex=10  mac=16:51:FA:8D:69:68 nodemac=8A:8F:5D:C5:F3:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:39.629Z",
  "value": "id=3636  sec_id=7667661 flags=0x0000 ifindex=12  mac=02:3D:9D:AA:20:3A nodemac=6A:7B:95:99:AE:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:39.700Z",
  "value": "id=3321  sec_id=7667661 flags=0x0000 ifindex=14  mac=CA:20:B6:35:AE:32 nodemac=36:E4:DE:5B:40:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:39.703Z",
  "value": "id=3636  sec_id=7667661 flags=0x0000 ifindex=12  mac=02:3D:9D:AA:20:3A nodemac=6A:7B:95:99:AE:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:39.704Z",
  "value": "id=2904  sec_id=4     flags=0x0000 ifindex=10  mac=16:51:FA:8D:69:68 nodemac=8A:8F:5D:C5:F3:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:32.277Z",
  "value": "id=2904  sec_id=4     flags=0x0000 ifindex=10  mac=16:51:FA:8D:69:68 nodemac=8A:8F:5D:C5:F3:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:32.277Z",
  "value": "id=3636  sec_id=7667661 flags=0x0000 ifindex=12  mac=02:3D:9D:AA:20:3A nodemac=6A:7B:95:99:AE:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:32.278Z",
  "value": "id=3321  sec_id=7667661 flags=0x0000 ifindex=14  mac=CA:20:B6:35:AE:32 nodemac=36:E4:DE:5B:40:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:32.310Z",
  "value": "id=1588  sec_id=7643794 flags=0x0000 ifindex=16  mac=82:1C:C3:66:AB:7B nodemac=82:0C:A4:2A:50:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:33.277Z",
  "value": "id=2904  sec_id=4     flags=0x0000 ifindex=10  mac=16:51:FA:8D:69:68 nodemac=8A:8F:5D:C5:F3:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:33.278Z",
  "value": "id=3321  sec_id=7667661 flags=0x0000 ifindex=14  mac=CA:20:B6:35:AE:32 nodemac=36:E4:DE:5B:40:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:33.278Z",
  "value": "id=1588  sec_id=7643794 flags=0x0000 ifindex=16  mac=82:1C:C3:66:AB:7B nodemac=82:0C:A4:2A:50:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:33.278Z",
  "value": "id=3636  sec_id=7667661 flags=0x0000 ifindex=12  mac=02:3D:9D:AA:20:3A nodemac=6A:7B:95:99:AE:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:29.955Z",
  "value": "id=1490  sec_id=7643794 flags=0x0000 ifindex=18  mac=C6:7A:2D:5A:25:4C nodemac=1A:E0:C2:A1:26:38"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.232.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.250Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:03.481Z",
  "value": "id=2904  sec_id=4     flags=0x0000 ifindex=10  mac=16:51:FA:8D:69:68 nodemac=8A:8F:5D:C5:F3:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:03.482Z",
  "value": "id=3636  sec_id=7667661 flags=0x0000 ifindex=12  mac=02:3D:9D:AA:20:3A nodemac=6A:7B:95:99:AE:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:03.482Z",
  "value": "id=3321  sec_id=7667661 flags=0x0000 ifindex=14  mac=CA:20:B6:35:AE:32 nodemac=36:E4:DE:5B:40:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:03.482Z",
  "value": "id=1490  sec_id=7643794 flags=0x0000 ifindex=18  mac=C6:7A:2D:5A:25:4C nodemac=1A:E0:C2:A1:26:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:04.512Z",
  "value": "id=2904  sec_id=4     flags=0x0000 ifindex=10  mac=16:51:FA:8D:69:68 nodemac=8A:8F:5D:C5:F3:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:04.512Z",
  "value": "id=3636  sec_id=7667661 flags=0x0000 ifindex=12  mac=02:3D:9D:AA:20:3A nodemac=6A:7B:95:99:AE:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:04.513Z",
  "value": "id=3321  sec_id=7667661 flags=0x0000 ifindex=14  mac=CA:20:B6:35:AE:32 nodemac=36:E4:DE:5B:40:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:04.513Z",
  "value": "id=1490  sec_id=7643794 flags=0x0000 ifindex=18  mac=C6:7A:2D:5A:25:4C nodemac=1A:E0:C2:A1:26:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:05.481Z",
  "value": "id=3636  sec_id=7667661 flags=0x0000 ifindex=12  mac=02:3D:9D:AA:20:3A nodemac=6A:7B:95:99:AE:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:05.482Z",
  "value": "id=2904  sec_id=4     flags=0x0000 ifindex=10  mac=16:51:FA:8D:69:68 nodemac=8A:8F:5D:C5:F3:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:05.482Z",
  "value": "id=3321  sec_id=7667661 flags=0x0000 ifindex=14  mac=CA:20:B6:35:AE:32 nodemac=36:E4:DE:5B:40:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:05.482Z",
  "value": "id=1490  sec_id=7643794 flags=0x0000 ifindex=18  mac=C6:7A:2D:5A:25:4C nodemac=1A:E0:C2:A1:26:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:06.482Z",
  "value": "id=1490  sec_id=7643794 flags=0x0000 ifindex=18  mac=C6:7A:2D:5A:25:4C nodemac=1A:E0:C2:A1:26:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:06.482Z",
  "value": "id=2904  sec_id=4     flags=0x0000 ifindex=10  mac=16:51:FA:8D:69:68 nodemac=8A:8F:5D:C5:F3:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:06.483Z",
  "value": "id=3636  sec_id=7667661 flags=0x0000 ifindex=12  mac=02:3D:9D:AA:20:3A nodemac=6A:7B:95:99:AE:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.232.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:06.483Z",
  "value": "id=3321  sec_id=7667661 flags=0x0000 ifindex=14  mac=CA:20:B6:35:AE:32 nodemac=36:E4:DE:5B:40:93"
}

