Endpoint ID: 1490
Path: /sys/fs/bpf/tc/globals/cilium_policy_01490

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11518317   116320    0        
Allow    Ingress     1          ANY          NONE         disabled    11300657   119507    0        
Allow    Egress      0          ANY          NONE         disabled    15213076   148318    0        


Endpoint ID: 2904
Path: /sys/fs/bpf/tc/globals/cilium_policy_02904

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1664080   20996     0        
Allow    Ingress     1          ANY          NONE         disabled    17853     213       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3321
Path: /sys/fs/bpf/tc/globals/cilium_policy_03321

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    114199   1312      0        
Allow    Egress      0          ANY          NONE         disabled    16018    173       0        


Endpoint ID: 3636
Path: /sys/fs/bpf/tc/globals/cilium_policy_03636

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113935   1308      0        
Allow    Egress      0          ANY          NONE         disabled    16290    176       0        


Endpoint ID: 3654
Path: /sys/fs/bpf/tc/globals/cilium_policy_03654

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


