IP ADDRESS         LOCAL ENDPOINT INFO
10.101.0.51:0      id=3869  sec_id=3359178 flags=0x0000 ifindex=12  mac=D2:33:E2:AC:7E:BE nodemac=22:5C:CC:B9:06:D7   
172.31.231.222:0   (localhost)                                                                                        
10.101.0.100:0     id=3831  sec_id=3368954 flags=0x0000 ifindex=18  mac=4A:FC:20:44:F3:BD nodemac=82:50:FF:9F:47:2B   
10.101.0.190:0     id=1749  sec_id=3359178 flags=0x0000 ifindex=14  mac=F2:99:39:A9:5B:D7 nodemac=FE:32:72:47:46:00   
172.31.255.237:0   (localhost)                                                                                        
10.101.0.103:0     (localhost)                                                                                        
10.101.0.72:0      id=541   sec_id=4     flags=0x0000 ifindex=10  mac=7A:FD:60:A1:72:DC nodemac=9E:FD:17:F3:13:AC     
