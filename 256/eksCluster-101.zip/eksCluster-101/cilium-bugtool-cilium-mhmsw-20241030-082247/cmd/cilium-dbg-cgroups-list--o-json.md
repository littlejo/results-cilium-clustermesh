[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf7d0e00_21a1_4499_8122_739d183cd7be.slice/cri-containerd-cddd6b4cf92a4cf323681e5d23828dd25b3a245cc68763ba7d2320258d139053.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf7d0e00_21a1_4499_8122_739d183cd7be.slice/cri-containerd-1ac66ef947db4ac5c40060b7778a2b23e77808ab291c20d43ccb32ca00f20acc.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf7d0e00_21a1_4499_8122_739d183cd7be.slice/cri-containerd-c4318a978c25057d8786fb666064c76ea790a5f3da69d1e2e6f00363ee49d11f.scope"
      }
    ],
    "ips": [
      "10.101.0.100"
    ],
    "name": "clustermesh-apiserver-685c744477-8vc9f",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod924f36dc_171e_4d99_975e_f768aa7cd57a.slice/cri-containerd-1698728a5611df8bde25b8d29d994291051378d164384b8756da2011ef550af5.scope"
      }
    ],
    "ips": [
      "10.101.0.190"
    ],
    "name": "coredns-cc6ccd49c-64g97",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5ac85987_fe69_45e3_b9fd_96e9afb44e57.slice/cri-containerd-63385f7f5dd4009702de7d72dcfc7e17fcd6c9abac55d8a8cb470a043f4ccf00.scope"
      }
    ],
    "ips": [
      "10.101.0.51"
    ],
    "name": "coredns-cc6ccd49c-qp5q4",
    "namespace": "kube-system"
  }
]

