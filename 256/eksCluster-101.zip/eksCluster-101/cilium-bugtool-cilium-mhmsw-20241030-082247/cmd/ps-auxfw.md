USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         685  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         671  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         665  0.0  0.2 1240432 16044 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         703  0.0  0.0   6408  1632 ?        R    08:22   0:00  \_ ps auxfw
root         705  0.0  0.2 1240432 16044 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  3.3  4.8 1606080 387628 ?      Ssl  07:53   0:58 cilium-agent --config-dir=/tmp/cilium/config-map
root         413  0.0  0.0 1229744 6936 ?        Sl   07:53   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
