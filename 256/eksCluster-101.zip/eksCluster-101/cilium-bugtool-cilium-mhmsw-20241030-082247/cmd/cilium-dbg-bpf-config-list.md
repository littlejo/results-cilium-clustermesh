KEY             VALUE
AgentLiveness   2161161193495
UTimeOffset     3379442263671875
