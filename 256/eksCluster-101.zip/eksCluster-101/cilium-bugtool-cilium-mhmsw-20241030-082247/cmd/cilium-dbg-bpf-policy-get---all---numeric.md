Endpoint ID: 541
Path: /sys/fs/bpf/tc/globals/cilium_policy_00541

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1630356   20595     0        
Allow    Ingress     1          ANY          NONE         disabled    25900     304       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 876
Path: /sys/fs/bpf/tc/globals/cilium_policy_00876

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1749
Path: /sys/fs/bpf/tc/globals/cilium_policy_01749

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    169090   1939      0        
Allow    Egress      0          ANY          NONE         disabled    21330    239       0        


Endpoint ID: 3831
Path: /sys/fs/bpf/tc/globals/cilium_policy_03831

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11536040   114537    0        
Allow    Ingress     1          ANY          NONE         disabled    10252142   107936    0        
Allow    Egress      0          ANY          NONE         disabled    12454528   122623    0        


Endpoint ID: 3869
Path: /sys/fs/bpf/tc/globals/cilium_policy_03869

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    168743   1939      0        
Allow    Egress      0          ANY          NONE         disabled    20541    230       0        


