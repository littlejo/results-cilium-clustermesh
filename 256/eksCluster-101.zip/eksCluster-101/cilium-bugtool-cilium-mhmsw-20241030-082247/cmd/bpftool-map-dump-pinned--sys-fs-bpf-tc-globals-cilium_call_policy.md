key: 1d 02 00 00  value: 21 02 00 00
key: d5 06 00 00  value: 2d 02 00 00
key: f7 0e 00 00  value: 71 02 00 00
key: 1d 0f 00 00  value: 08 02 00 00
Found 4 elements
