alloc: 179.13MB (187830280 bytes)
total-alloc: 2.32GB (2488817880 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 64151433
frees: 62328065
heap-alloc: 179.13MB (187830280 bytes)
heap-sys: 251.29MB (263495680 bytes)
heap-idle: 44.34MB (46497792 bytes)
heap-in-use: 206.95MB (216997888 bytes)
heap-released: 1.22MB (1277952 bytes)
heap-objects: 1823368
stack-in-use: 64.69MB (67829760 bytes)
stack-sys: 64.69MB (67829760 bytes)
stack-mspan-inuse: 3.29MB (3454400 bytes)
stack-mspan-sys: 3.92MB (4112640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 911.57KB (933449 bytes)
gc-sys: 6.00MB (6286800 bytes)
next-gc: when heap-alloc >= 215.78MB (226259144 bytes)
last-gc: 2024-10-30 08:22:55.115065727 +0000 UTC
gc-pause-total: 12.012874ms
gc-pause: 102516
gc-pause-end: 1730276575115065727
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.00038660315038685646
enable-gc: true
debug-gc: false
