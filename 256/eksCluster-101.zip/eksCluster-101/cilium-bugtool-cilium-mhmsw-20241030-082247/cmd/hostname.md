ip-172-31-255-237.eu-west-3.compute.internal
