top - 08:22:49 up 35 min,  0 users,  load average: 0.06, 0.13, 0.12
Tasks:  10 total,   2 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 63.3 us, 30.0 sy,  0.0 ni,  3.3 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4470.1 free,   1197.6 used,   2146.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6431.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 389476  80344 S  80.0   4.9   0:58.88 cilium-+
    729 root      20   0 1243508  18096  12992 S   6.7   0.2   0:00.01 hubble
    413 root      20   0 1229744   6936   2864 S   0.0   0.1   0:01.15 cilium-+
    665 root      20   0 1240432  16044  10832 S   0.0   0.2   0:00.03 cilium-+
    671 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    685 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    714 root      20   0    6576   2416   2092 R   0.0   0.0   0:00.00 top
    717 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    743 root      20   0 1616264   9204   6460 D   0.0   0.1   0:00.00 runc:[2+
    751 root      20   0 1240432  16044  10832 R   0.0   0.2   0:00.00 cilium-+
