{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:54.602Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.231.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:54.602Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.255.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:54.602Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:59.447Z",
  "value": "id=541   sec_id=4     flags=0x0000 ifindex=10  mac=7A:FD:60:A1:72:DC nodemac=9E:FD:17:F3:13:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:59.450Z",
  "value": "id=3869  sec_id=3359178 flags=0x0000 ifindex=12  mac=D2:33:E2:AC:7E:BE nodemac=22:5C:CC:B9:06:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:59.493Z",
  "value": "id=541   sec_id=4     flags=0x0000 ifindex=10  mac=7A:FD:60:A1:72:DC nodemac=9E:FD:17:F3:13:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:59.508Z",
  "value": "id=1749  sec_id=3359178 flags=0x0000 ifindex=14  mac=F2:99:39:A9:5B:D7 nodemac=FE:32:72:47:46:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:29.914Z",
  "value": "id=1749  sec_id=3359178 flags=0x0000 ifindex=14  mac=F2:99:39:A9:5B:D7 nodemac=FE:32:72:47:46:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:29.915Z",
  "value": "id=541   sec_id=4     flags=0x0000 ifindex=10  mac=7A:FD:60:A1:72:DC nodemac=9E:FD:17:F3:13:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:29.915Z",
  "value": "id=3869  sec_id=3359178 flags=0x0000 ifindex=12  mac=D2:33:E2:AC:7E:BE nodemac=22:5C:CC:B9:06:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:29.949Z",
  "value": "id=1118  sec_id=3368954 flags=0x0000 ifindex=16  mac=A2:7C:A0:FB:05:7F nodemac=E6:A1:90:24:EF:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:29.950Z",
  "value": "id=1118  sec_id=3368954 flags=0x0000 ifindex=16  mac=A2:7C:A0:FB:05:7F nodemac=E6:A1:90:24:EF:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:30.913Z",
  "value": "id=1118  sec_id=3368954 flags=0x0000 ifindex=16  mac=A2:7C:A0:FB:05:7F nodemac=E6:A1:90:24:EF:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:30.913Z",
  "value": "id=541   sec_id=4     flags=0x0000 ifindex=10  mac=7A:FD:60:A1:72:DC nodemac=9E:FD:17:F3:13:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:30.914Z",
  "value": "id=3869  sec_id=3359178 flags=0x0000 ifindex=12  mac=D2:33:E2:AC:7E:BE nodemac=22:5C:CC:B9:06:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:30.914Z",
  "value": "id=1749  sec_id=3359178 flags=0x0000 ifindex=14  mac=F2:99:39:A9:5B:D7 nodemac=FE:32:72:47:46:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.822Z",
  "value": "id=3831  sec_id=3368954 flags=0x0000 ifindex=18  mac=4A:FC:20:44:F3:BD nodemac=82:50:FF:9F:47:2B"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.101.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:26.385Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.829Z",
  "value": "id=1749  sec_id=3359178 flags=0x0000 ifindex=14  mac=F2:99:39:A9:5B:D7 nodemac=FE:32:72:47:46:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.829Z",
  "value": "id=3831  sec_id=3368954 flags=0x0000 ifindex=18  mac=4A:FC:20:44:F3:BD nodemac=82:50:FF:9F:47:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.830Z",
  "value": "id=3869  sec_id=3359178 flags=0x0000 ifindex=12  mac=D2:33:E2:AC:7E:BE nodemac=22:5C:CC:B9:06:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.830Z",
  "value": "id=541   sec_id=4     flags=0x0000 ifindex=10  mac=7A:FD:60:A1:72:DC nodemac=9E:FD:17:F3:13:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.830Z",
  "value": "id=541   sec_id=4     flags=0x0000 ifindex=10  mac=7A:FD:60:A1:72:DC nodemac=9E:FD:17:F3:13:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.830Z",
  "value": "id=3869  sec_id=3359178 flags=0x0000 ifindex=12  mac=D2:33:E2:AC:7E:BE nodemac=22:5C:CC:B9:06:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.831Z",
  "value": "id=1749  sec_id=3359178 flags=0x0000 ifindex=14  mac=F2:99:39:A9:5B:D7 nodemac=FE:32:72:47:46:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.831Z",
  "value": "id=3831  sec_id=3368954 flags=0x0000 ifindex=18  mac=4A:FC:20:44:F3:BD nodemac=82:50:FF:9F:47:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:33.829Z",
  "value": "id=3869  sec_id=3359178 flags=0x0000 ifindex=12  mac=D2:33:E2:AC:7E:BE nodemac=22:5C:CC:B9:06:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:33.830Z",
  "value": "id=1749  sec_id=3359178 flags=0x0000 ifindex=14  mac=F2:99:39:A9:5B:D7 nodemac=FE:32:72:47:46:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:33.830Z",
  "value": "id=541   sec_id=4     flags=0x0000 ifindex=10  mac=7A:FD:60:A1:72:DC nodemac=9E:FD:17:F3:13:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:33.830Z",
  "value": "id=3831  sec_id=3368954 flags=0x0000 ifindex=18  mac=4A:FC:20:44:F3:BD nodemac=82:50:FF:9F:47:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:34.830Z",
  "value": "id=3831  sec_id=3368954 flags=0x0000 ifindex=18  mac=4A:FC:20:44:F3:BD nodemac=82:50:FF:9F:47:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:34.831Z",
  "value": "id=1749  sec_id=3359178 flags=0x0000 ifindex=14  mac=F2:99:39:A9:5B:D7 nodemac=FE:32:72:47:46:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:34.831Z",
  "value": "id=541   sec_id=4     flags=0x0000 ifindex=10  mac=7A:FD:60:A1:72:DC nodemac=9E:FD:17:F3:13:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:34.831Z",
  "value": "id=3869  sec_id=3359178 flags=0x0000 ifindex=12  mac=D2:33:E2:AC:7E:BE nodemac=22:5C:CC:B9:06:D7"
}

