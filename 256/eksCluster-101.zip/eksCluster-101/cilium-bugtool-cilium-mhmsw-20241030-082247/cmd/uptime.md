 08:22:48 up 35 min,  0 users,  load average: 0.06, 0.13, 0.12
