CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd72bd2ff_30ff_48a3_b3bb_6030f57e1502.slice/cri-containerd-af005447e6124adec3b34d1c4a431722d95b8eb64609ff1dd28043d14ff16ff4.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd72bd2ff_30ff_48a3_b3bb_6030f57e1502.slice/cri-containerd-4ecf88a57aa6729971b21b70128594c4b4c4012f99f6e0e946c073312ff249e9.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5ac85987_fe69_45e3_b9fd_96e9afb44e57.slice/cri-containerd-db3755774e3b9e159003ce4138873be2074f26d4e4e72ebae4359971eb7b00a5.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5ac85987_fe69_45e3_b9fd_96e9afb44e57.slice/cri-containerd-63385f7f5dd4009702de7d72dcfc7e17fcd6c9abac55d8a8cb470a043f4ccf00.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2d5fa880_afa3_447d_a7d6_0840cd329c71.slice/cri-containerd-b0af8d903e1ce9c0a0751f3ccf778b601b4a558278f86dabb9bdd999f44673ca.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2d5fa880_afa3_447d_a7d6_0840cd329c71.slice/cri-containerd-f62e682d8593693d99bb85baed165ecb54bbf4d0d0a8d9ec68f95e37e0821d9c.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod924f36dc_171e_4d99_975e_f768aa7cd57a.slice/cri-containerd-2f0d093199136ddf082f30e97901ff6789a8208ec284257a0f136c224a97192f.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod924f36dc_171e_4d99_975e_f768aa7cd57a.slice/cri-containerd-1698728a5611df8bde25b8d29d994291051378d164384b8756da2011ef550af5.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf7d0e00_21a1_4499_8122_739d183cd7be.slice/cri-containerd-c4318a978c25057d8786fb666064c76ea790a5f3da69d1e2e6f00363ee49d11f.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf7d0e00_21a1_4499_8122_739d183cd7be.slice/cri-containerd-cddd6b4cf92a4cf323681e5d23828dd25b3a245cc68763ba7d2320258d139053.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf7d0e00_21a1_4499_8122_739d183cd7be.slice/cri-containerd-1ac66ef947db4ac5c40060b7778a2b23e77808ab291c20d43ccb32ca00f20acc.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf7d0e00_21a1_4499_8122_739d183cd7be.slice/cri-containerd-b1707d117d71a3b2efee3c76037adea7075300ac8453f14053b5a830ee3ee6df.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3f0ea9e_b92c_4ae0_9fac_35584cd0fc80.slice/cri-containerd-56a9cc837ed9aa3420b33f1326c049158b7a98c6cee62f8adb40148271f3dc55.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3f0ea9e_b92c_4ae0_9fac_35584cd0fc80.slice/cri-containerd-ee5db509f783b268e10a9b9f96a3963be20e789870a5870abefe2f00fcbd4ebb.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9b2e54ca_353a_4229_94a2_f05b67885f95.slice/cri-containerd-059c49662e0a090d928a2059f5600a52d82c65bba9ea8524d5f2b7c2f487ec85.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9b2e54ca_353a_4229_94a2_f05b67885f95.slice/cri-containerd-655dc19e78c5eba188bdfad9bad6a708b71729ac96f059773391a1dbf3eaf315.scope
    105      cgroup_device   multi                                          
