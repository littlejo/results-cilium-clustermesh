IP ADDRESS         LOCAL ENDPOINT INFO
172.31.154.145:0   (localhost)                                                                                       
10.6.0.119:0       id=94    sec_id=233940 flags=0x0000 ifindex=14  mac=CE:55:70:2B:15:0D nodemac=FE:B4:9B:2B:CA:EB   
10.6.0.10:0        id=2986  sec_id=231641 flags=0x0000 ifindex=18  mac=1A:3C:BF:10:63:22 nodemac=C6:06:C6:8B:FD:34   
10.6.0.254:0       id=282   sec_id=233940 flags=0x0000 ifindex=12  mac=32:E5:B4:13:A8:86 nodemac=96:93:38:D8:DA:44   
172.31.132.223:0   (localhost)                                                                                       
10.6.0.26:0        id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=5A:0D:1A:07:4A:BB nodemac=3E:51:1C:6B:61:54    
10.6.0.84:0        (localhost)                                                                                       
