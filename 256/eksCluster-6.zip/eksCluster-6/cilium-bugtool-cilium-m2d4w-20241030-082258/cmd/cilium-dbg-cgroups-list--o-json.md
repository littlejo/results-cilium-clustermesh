[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1b966e50_d30f_4ef3_a6a4_58c1aa15a892.slice/cri-containerd-2e37cfc74ad0cdf6852bcd97e14a83de64c4c4dd9ad6290b24481d481a628ad8.scope"
      }
    ],
    "ips": [
      "10.6.0.254"
    ],
    "name": "coredns-cc6ccd49c-6r2wr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aacc8f8_0056_4916_8d72_2bfb8ecb4cda.slice/cri-containerd-351cc689d32c1dda4294ec1056fd99198f7241381ba5564e16020708adbd0303.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aacc8f8_0056_4916_8d72_2bfb8ecb4cda.slice/cri-containerd-0e96ef99ee79279ab0bc9149b41b3f42aee58b3f6b55d3134ce8c35a70ebf768.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aacc8f8_0056_4916_8d72_2bfb8ecb4cda.slice/cri-containerd-a99b5396657ade9ff9a3e1f5549bca85755a93c57793b4ce0565d3b0c69a0a42.scope"
      }
    ],
    "ips": [
      "10.6.0.10"
    ],
    "name": "clustermesh-apiserver-857475cbcc-n4hxl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod32e9aed1_f214_4646_beb4_a138bf89431a.slice/cri-containerd-84dd1fb9ee47d2a771579c0177ebda89c21a2c3dfa76a1eed351b08a6ad774d1.scope"
      }
    ],
    "ips": [
      "10.6.0.119"
    ],
    "name": "coredns-cc6ccd49c-r5jr7",
    "namespace": "kube-system"
  }
]

