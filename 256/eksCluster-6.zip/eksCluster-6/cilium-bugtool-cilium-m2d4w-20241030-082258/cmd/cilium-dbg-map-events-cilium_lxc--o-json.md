{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:16.296Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.132.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:16.296Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.154.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:16.296Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:20.782Z",
  "value": "id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=5A:0D:1A:07:4A:BB nodemac=3E:51:1C:6B:61:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:20.785Z",
  "value": "id=282   sec_id=233940 flags=0x0000 ifindex=12  mac=32:E5:B4:13:A8:86 nodemac=96:93:38:D8:DA:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:20.836Z",
  "value": "id=94    sec_id=233940 flags=0x0000 ifindex=14  mac=CE:55:70:2B:15:0D nodemac=FE:B4:9B:2B:CA:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:20.838Z",
  "value": "id=282   sec_id=233940 flags=0x0000 ifindex=12  mac=32:E5:B4:13:A8:86 nodemac=96:93:38:D8:DA:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:20.856Z",
  "value": "id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=5A:0D:1A:07:4A:BB nodemac=3E:51:1C:6B:61:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:26.727Z",
  "value": "id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=5A:0D:1A:07:4A:BB nodemac=3E:51:1C:6B:61:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:26.729Z",
  "value": "id=282   sec_id=233940 flags=0x0000 ifindex=12  mac=32:E5:B4:13:A8:86 nodemac=96:93:38:D8:DA:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:26.729Z",
  "value": "id=94    sec_id=233940 flags=0x0000 ifindex=14  mac=CE:55:70:2B:15:0D nodemac=FE:B4:9B:2B:CA:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:26.759Z",
  "value": "id=499   sec_id=231641 flags=0x0000 ifindex=16  mac=9A:DC:06:57:03:45 nodemac=82:F7:F0:E0:04:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.728Z",
  "value": "id=499   sec_id=231641 flags=0x0000 ifindex=16  mac=9A:DC:06:57:03:45 nodemac=82:F7:F0:E0:04:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.728Z",
  "value": "id=94    sec_id=233940 flags=0x0000 ifindex=14  mac=CE:55:70:2B:15:0D nodemac=FE:B4:9B:2B:CA:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.728Z",
  "value": "id=282   sec_id=233940 flags=0x0000 ifindex=12  mac=32:E5:B4:13:A8:86 nodemac=96:93:38:D8:DA:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.729Z",
  "value": "id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=5A:0D:1A:07:4A:BB nodemac=3E:51:1C:6B:61:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:17.418Z",
  "value": "id=2986  sec_id=231641 flags=0x0000 ifindex=18  mac=1A:3C:BF:10:63:22 nodemac=C6:06:C6:8B:FD:34"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.6.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.737Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.715Z",
  "value": "id=2986  sec_id=231641 flags=0x0000 ifindex=18  mac=1A:3C:BF:10:63:22 nodemac=C6:06:C6:8B:FD:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.717Z",
  "value": "id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=5A:0D:1A:07:4A:BB nodemac=3E:51:1C:6B:61:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.717Z",
  "value": "id=282   sec_id=233940 flags=0x0000 ifindex=12  mac=32:E5:B4:13:A8:86 nodemac=96:93:38:D8:DA:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.718Z",
  "value": "id=94    sec_id=233940 flags=0x0000 ifindex=14  mac=CE:55:70:2B:15:0D nodemac=FE:B4:9B:2B:CA:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.725Z",
  "value": "id=2986  sec_id=231641 flags=0x0000 ifindex=18  mac=1A:3C:BF:10:63:22 nodemac=C6:06:C6:8B:FD:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.731Z",
  "value": "id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=5A:0D:1A:07:4A:BB nodemac=3E:51:1C:6B:61:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.731Z",
  "value": "id=282   sec_id=233940 flags=0x0000 ifindex=12  mac=32:E5:B4:13:A8:86 nodemac=96:93:38:D8:DA:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.732Z",
  "value": "id=94    sec_id=233940 flags=0x0000 ifindex=14  mac=CE:55:70:2B:15:0D nodemac=FE:B4:9B:2B:CA:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:26.715Z",
  "value": "id=94    sec_id=233940 flags=0x0000 ifindex=14  mac=CE:55:70:2B:15:0D nodemac=FE:B4:9B:2B:CA:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:26.715Z",
  "value": "id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=5A:0D:1A:07:4A:BB nodemac=3E:51:1C:6B:61:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:26.716Z",
  "value": "id=2986  sec_id=231641 flags=0x0000 ifindex=18  mac=1A:3C:BF:10:63:22 nodemac=C6:06:C6:8B:FD:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:26.716Z",
  "value": "id=282   sec_id=233940 flags=0x0000 ifindex=12  mac=32:E5:B4:13:A8:86 nodemac=96:93:38:D8:DA:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:27.717Z",
  "value": "id=2986  sec_id=231641 flags=0x0000 ifindex=18  mac=1A:3C:BF:10:63:22 nodemac=C6:06:C6:8B:FD:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:27.717Z",
  "value": "id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=5A:0D:1A:07:4A:BB nodemac=3E:51:1C:6B:61:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:27.717Z",
  "value": "id=282   sec_id=233940 flags=0x0000 ifindex=12  mac=32:E5:B4:13:A8:86 nodemac=96:93:38:D8:DA:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:27.717Z",
  "value": "id=94    sec_id=233940 flags=0x0000 ifindex=14  mac=CE:55:70:2B:15:0D nodemac=FE:B4:9B:2B:CA:EB"
}

