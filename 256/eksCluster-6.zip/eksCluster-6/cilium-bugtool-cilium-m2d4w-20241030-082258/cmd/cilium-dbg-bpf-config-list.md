KEY             VALUE
AgentLiveness   2366855914047
UTimeOffset     3379441882812500
