CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod32e9aed1_f214_4646_beb4_a138bf89431a.slice/cri-containerd-84dd1fb9ee47d2a771579c0177ebda89c21a2c3dfa76a1eed351b08a6ad774d1.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod32e9aed1_f214_4646_beb4_a138bf89431a.slice/cri-containerd-29945bab8fa51842525c6258c45fa93b2d3d88eae914413630b7f17b5b4d58c5.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1b966e50_d30f_4ef3_a6a4_58c1aa15a892.slice/cri-containerd-58164435d6f624917eefd2e5fd52e76c66ff6f3685289884200b1e350964aa36.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1b966e50_d30f_4ef3_a6a4_58c1aa15a892.slice/cri-containerd-2e37cfc74ad0cdf6852bcd97e14a83de64c4c4dd9ad6290b24481d481a628ad8.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1ad2fe89_1f13_48c9_a668_3a54c0965977.slice/cri-containerd-8e0c6d1819c6564ff627da4001194d2204b07fa8b7db6913a5d0b3bef4bc9885.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1ad2fe89_1f13_48c9_a668_3a54c0965977.slice/cri-containerd-c8a098a8bb93e8cef4515e18fa5617e724bbdb0d843624d41173308e8813afbe.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb909177b_311a_4dc0_9ff7_4a9c958daa93.slice/cri-containerd-c27c6b5264b63b66c42bab556ee3bc6bfa8deb4f3ec9f835a6dc11353f61f5ec.scope
    51       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb909177b_311a_4dc0_9ff7_4a9c958daa93.slice/cri-containerd-bb1f1c3723969462b8e2b6a2854bb4752021576a5030d59ad50bf99455e8f0fc.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aacc8f8_0056_4916_8d72_2bfb8ecb4cda.slice/cri-containerd-351cc689d32c1dda4294ec1056fd99198f7241381ba5564e16020708adbd0303.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aacc8f8_0056_4916_8d72_2bfb8ecb4cda.slice/cri-containerd-0979ce318c4f4a3e972778e975ac8dec80ea5b135ccf15efa2dcd6df94d43034.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aacc8f8_0056_4916_8d72_2bfb8ecb4cda.slice/cri-containerd-a99b5396657ade9ff9a3e1f5549bca85755a93c57793b4ce0565d3b0c69a0a42.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aacc8f8_0056_4916_8d72_2bfb8ecb4cda.slice/cri-containerd-0e96ef99ee79279ab0bc9149b41b3f42aee58b3f6b55d3134ce8c35a70ebf768.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ea53eb_46e5_460c_aa52_facbf3eadba3.slice/cri-containerd-94cf15eb63b6711c1b8a8fe047860a6a8d5ba2ef11817a8d45ed2da7b6ee531b.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ea53eb_46e5_460c_aa52_facbf3eadba3.slice/cri-containerd-77b2afa6bdf5a5d056a2193085f69b85d8da51fc498688142c2b1eacba211199.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7feedfe0_3ca6_4a5b_b1ac_287104de99ce.slice/cri-containerd-915a93e69f6ae71bc8506eb6e322ccecabf1e4a2f8ae95767f5649cb3ee3306b.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7feedfe0_3ca6_4a5b_b1ac_287104de99ce.slice/cri-containerd-47c10ffedd8c45277e0a5e4244cd66f48bd340a7efbf118881dee2e439bfcead.scope
    95       cgroup_device   multi                                          
