Endpoint ID: 94
Path: /sys/fs/bpf/tc/globals/cilium_policy_00094

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176569   2024      0        
Allow    Egress      0          ANY          NONE         disabled    21195    238       0        


Endpoint ID: 282
Path: /sys/fs/bpf/tc/globals/cilium_policy_00282

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    178351   2051      0        
Allow    Egress      0          ANY          NONE         disabled    21209    238       0        


Endpoint ID: 1209
Path: /sys/fs/bpf/tc/globals/cilium_policy_01209

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2034
Path: /sys/fs/bpf/tc/globals/cilium_policy_02034

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1670828   21214     0        
Allow    Ingress     1          ANY          NONE         disabled    26828     314       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2986
Path: /sys/fs/bpf/tc/globals/cilium_policy_02986

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11634316   116945    0        
Allow    Ingress     1          ANY          NONE         disabled    10322429   108817    0        
Allow    Egress      0          ANY          NONE         disabled    14026338   137659    0        


