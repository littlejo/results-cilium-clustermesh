 08:22:59 up 38 min,  0 users,  load average: 0.11, 0.15, 0.15
