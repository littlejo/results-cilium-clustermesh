USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         605  0.0  0.2 1240432 16108 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         669  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         671  0.0  0.0   3852  1292 ?        R    08:22   0:00  \_ bash -c hostname
root           1  2.9  4.8 1606080 384156 ?      Ssl  07:52   0:55 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.0  0.0 1229744 7192 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
