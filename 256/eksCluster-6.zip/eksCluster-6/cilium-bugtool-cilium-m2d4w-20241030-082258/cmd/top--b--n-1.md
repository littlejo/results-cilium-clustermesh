top - 08:23:00 up 38 min,  0 users,  load average: 0.11, 0.15, 0.15
Tasks:  10 total,   4 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 48.3 us, 31.0 sy,  0.0 ni, 10.3 id,  0.0 wa,  0.0 hi, 10.3 si,  0.0 st
MiB Mem :   7814.2 total,   4470.4 free,   1198.0 used,   2145.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6431.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 384156  77488 S   6.7   4.8   0:55.02 cilium-+
    702 root      20   0 1243508  19472  14016 S   6.7   0.2   0:00.01 hubble
    394 root      20   0 1229744   7192   3056 S   0.0   0.1   0:01.16 cilium-+
    605 root      20   0 1240432  16360  11164 S   0.0   0.2   0:00.02 cilium-+
    681 root      20   0    6576   2412   2088 R   0.0   0.0   0:00.00 top
    685 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    695 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    712 root      20   0       4      4      0 R   0.0   0.0   0:00.00 runc:[2+
    719 root      20   0    3852   1272   1116 R   0.0   0.0   0:00.00 bash
    722 root      20   0   13060   1228     60 R   0.0   0.0   0:00.00 runc:[2+
