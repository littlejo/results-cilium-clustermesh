alloc: 116.86MB (122535784 bytes)
total-alloc: 2.36GB (2533835032 bytes)
sys: 336.84MB (353197428 bytes)
lookups: 0
mallocs: 64892630
frees: 64216754
heap-alloc: 116.86MB (122535784 bytes)
heap-sys: 263.84MB (276660224 bytes)
heap-idle: 80.77MB (84697088 bytes)
heap-in-use: 183.07MB (191963136 bytes)
heap-released: 2.23MB (2342912 bytes)
heap-objects: 675876
stack-in-use: 60.16MB (63078400 bytes)
stack-sys: 60.16MB (63078400 bytes)
stack-mspan-inuse: 2.81MB (2945920 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 983.27KB (1006865 bytes)
gc-sys: 6.06MB (6353472 bytes)
next-gc: when heap-alloc >= 224.74MB (235655400 bytes)
last-gc: 2024-10-30 08:23:30.553125889 +0000 UTC
gc-pause-total: 29.032666ms
gc-pause: 12069928
gc-pause-end: 1730276610553125889
num-gc: 87
num-forced-gc: 0
gc-cpu-fraction: 0.00041017293071726513
enable-gc: true
debug-gc: false
