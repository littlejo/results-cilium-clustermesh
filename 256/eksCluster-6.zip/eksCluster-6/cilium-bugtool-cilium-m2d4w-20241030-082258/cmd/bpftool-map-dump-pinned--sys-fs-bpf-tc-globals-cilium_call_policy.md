key: 5e 00 00 00  value: 22 02 00 00
key: 1a 01 00 00  value: 0f 02 00 00
key: f2 07 00 00  value: 1a 02 00 00
key: aa 0b 00 00  value: 69 02 00 00
Found 4 elements
