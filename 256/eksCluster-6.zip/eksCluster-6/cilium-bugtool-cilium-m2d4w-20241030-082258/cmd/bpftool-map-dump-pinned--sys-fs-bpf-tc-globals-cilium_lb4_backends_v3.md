key: 0b 00 00 00  value: 0a 06 00 0a 09 4b 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f 9b b2 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 06 00 fe 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 06 00 fe 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f dc 3b 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 06 00 77 23 c1 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 06 00 77 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 9a 91 10 94 00 00  00 00 00 00
Found 8 elements
