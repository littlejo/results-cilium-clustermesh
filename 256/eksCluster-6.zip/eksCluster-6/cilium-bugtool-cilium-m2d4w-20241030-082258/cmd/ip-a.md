1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ac:97:50:0f:fd brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.154.145/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3076sec preferred_lft 3076sec
    inet6 fe80::4ac:97ff:fe50:ffd/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:60:9b:e5:d8:b1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.132.223/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::460:9bff:fee5:d8b1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:48:53:a7:ce:85 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ac48:53ff:fea7:ce85/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:73:3b:a9:3a:62 brd ff:ff:ff:ff:ff:ff
    inet 10.6.0.84/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::8473:3bff:fea9:3a62/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 9a:8e:e2:11:78:95 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::988e:e2ff:fe11:7895/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:51:1c:6b:61:54 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::3c51:1cff:fe6b:6154/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc0ee60516c790@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:93:38:d8:da:44 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::9493:38ff:fed8:da44/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce24d6f4f1070@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:b4:9b:2b:ca:eb brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::fcb4:9bff:fe2b:caeb/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcd1aec3f30022@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:06:c6:8b:fd:34 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c406:c6ff:fe8b:fd34/64 scope link 
       valid_lft forever preferred_lft forever
