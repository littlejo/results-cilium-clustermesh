REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37185     2933133     677    bpf_overlay.c
Interface                 INGRESS     659517    135015711   1132   bpf_host.c
Success                   EGRESS      16655     1309025     1694   bpf_host.c
Success                   EGRESS      280986    34714184    1308   bpf_lxc.c
Success                   EGRESS      37358     2952433     53     encap.h
Success                   INGRESS     322924    36519142    86     l3.h
Success                   INGRESS     344106    38187366    235    trace.h
Unsupported L3 protocol   EGRESS      45        3362        1492   bpf_lxc.c
