xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 579
ens6(5) clsact/ingress cil_from_netdev-ens6 id 583
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 566
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 564
cilium_host(7) clsact/egress cil_from_host-cilium_host id 563
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 518
lxc06965147b064(12) clsact/ingress cil_from_container-lxc06965147b064 id 542
lxcbb02681b7e5f(14) clsact/ingress cil_from_container-lxcbb02681b7e5f id 525
lxc77ed851bb96a(18) clsact/ingress cil_from_container-lxc77ed851bb96a id 631

flow_dissector:

netfilter:

