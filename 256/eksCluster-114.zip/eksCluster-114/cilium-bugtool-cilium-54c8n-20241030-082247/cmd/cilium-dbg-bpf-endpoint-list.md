IP ADDRESS         LOCAL ENDPOINT INFO
10.114.0.7:0       id=3436  sec_id=3785811 flags=0x0000 ifindex=14  mac=FA:A6:3B:08:57:8A nodemac=AE:28:B3:63:2D:A2   
10.114.0.24:0      id=3702  sec_id=3785811 flags=0x0000 ifindex=12  mac=EE:03:1B:C8:8A:E8 nodemac=DE:85:40:90:54:A2   
172.31.171.126:0   (localhost)                                                                                        
10.114.0.106:0     (localhost)                                                                                        
10.114.0.65:0      id=732   sec_id=3779621 flags=0x0000 ifindex=18  mac=C6:72:D6:54:50:5F nodemac=3E:36:B6:E8:CB:53   
172.31.187.38:0    (localhost)                                                                                        
10.114.0.218:0     id=1511  sec_id=4     flags=0x0000 ifindex=10  mac=12:CD:CE:16:1A:9D nodemac=36:E7:B3:D6:EF:A9     
