ip-172-31-187-38.eu-west-3.compute.internal
