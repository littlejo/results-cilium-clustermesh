REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36638     2900442     677    bpf_overlay.c
Interface                 INGRESS     657520    133427560   1132   bpf_host.c
Success                   EGRESS      16493     1298441     1694   bpf_host.c
Success                   EGRESS      282910    35655988    1308   bpf_lxc.c
Success                   EGRESS      36869     2916942     53     encap.h
Success                   INGRESS     325052    36785396    86     l3.h
Success                   INGRESS     345848    38431443    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
