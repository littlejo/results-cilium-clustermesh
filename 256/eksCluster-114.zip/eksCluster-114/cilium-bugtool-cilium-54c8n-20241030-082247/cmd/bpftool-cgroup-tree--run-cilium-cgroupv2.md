CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda20e8592_69d2_4afa_afbf_cb92d9a23a06.slice/cri-containerd-6d7c62050528bf7e08ac987981e80cbb02abeffd4c2ee967aeb16331e4cbe38a.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda20e8592_69d2_4afa_afbf_cb92d9a23a06.slice/cri-containerd-20205cc5aab774ec29fcee109e904ccde2a62b900fe20cf7ffe80e1042b95b00.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf8f4c812_402c_4081_b166_782eb351dde3.slice/cri-containerd-d0f63d178fdf11f05236d3aba6cff56b6994955ff61ee5b9200bad8ed8b223d4.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf8f4c812_402c_4081_b166_782eb351dde3.slice/cri-containerd-6a62fc4546cc17334add65af0975058277eb680cddf608e3006686e16acad2cf.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod707cad7d_7906_4c0e_8101_82c9d382467b.slice/cri-containerd-8db59ef5da88130ccdb0e1c4b70c609ed3d1e01bca6753ebeaffed686e4edbb6.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod707cad7d_7906_4c0e_8101_82c9d382467b.slice/cri-containerd-e891b5a805d4b834a27c640d9b11b5c647024da98cefa7863e00e57f173eeb19.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5fdf5788_354e_4891_a153_9c0c77d019eb.slice/cri-containerd-bed2701e6347214fc1eba1da2552547664b2d292ef8aed1b967a18e0a6f5a3e0.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5fdf5788_354e_4891_a153_9c0c77d019eb.slice/cri-containerd-f630a0780c095a92a2e6cc0edd5ec449cf2c88643fe056d0fc2ff1ab1d50b7b7.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda4b6bc46_baf5_4159_b117_27f9dd50dfb8.slice/cri-containerd-11cbea65f1a068cbe41b70787b74d38d1aa244245f3bc39ce1d118448c00a0d8.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda4b6bc46_baf5_4159_b117_27f9dd50dfb8.slice/cri-containerd-de6b009bf09e0dd6f9f0f98572939b91963d1ad4768d45a287fdd3555fecc7c5.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod234c8bb3_0e3e_4b5b_9d0b_993f99c541a6.slice/cri-containerd-8a5fe1683563649dd56c413910372a5c0d2564be95966380c79f78f9f57bf610.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod234c8bb3_0e3e_4b5b_9d0b_993f99c541a6.slice/cri-containerd-48b4aef5751b4428cf7e488c6df50b3b04f6fff68aaa551a40a629640f24f4f7.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9786f90_5193_4011_906c_740729e0f873.slice/cri-containerd-17ea46b7a4db067338bf2416c3ee3a73d1dfb731af71d34876f344fe71967bb5.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9786f90_5193_4011_906c_740729e0f873.slice/cri-containerd-5761eca3f867b1bfa0323bc4bcf55cda7f910c9944e420e8628122fb0ef64445.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9786f90_5193_4011_906c_740729e0f873.slice/cri-containerd-7c134380156bd760d8a47160689a43f05ebf8c0485b7359780383803d4f01858.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9786f90_5193_4011_906c_740729e0f873.slice/cri-containerd-f987b144a40400da6bbc00c733b553629930baa79ad093ac456e1b344acb8cb3.scope
    660      cgroup_device   multi                                          
