1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:96:b2:79:fa:df brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.187.38/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3333sec preferred_lft 3333sec
    inet6 fe80::496:b2ff:fe79:fadf/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:92:0b:35:58:b3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.171.126/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::492:bff:fe35:58b3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:6d:c6:1c:a3:11 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c6d:c6ff:fe1c:a311/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:90:11:92:37:f8 brd ff:ff:ff:ff:ff:ff
    inet 10.114.0.106/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d490:11ff:fe92:37f8/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 9e:e1:85:1d:b6:a7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9ce1:85ff:fe1d:b6a7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:e7:b3:d6:ef:a9 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::34e7:b3ff:fed6:efa9/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc06965147b064@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:85:40:90:54:a2 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::dc85:40ff:fe90:54a2/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcbb02681b7e5f@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:28:b3:63:2d:a2 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ac28:b3ff:fe63:2da2/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc77ed851bb96a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:36:b6:e8:cb:53 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::3c36:b6ff:fee8:cb53/64 scope link 
       valid_lft forever preferred_lft forever
