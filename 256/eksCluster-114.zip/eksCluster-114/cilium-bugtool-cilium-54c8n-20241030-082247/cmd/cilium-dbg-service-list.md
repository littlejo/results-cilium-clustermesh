ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.175.188:443 (active)   
                                          2 => 172.31.237.166:443 (active)   
2    10.100.115.64:443     ClusterIP      1 => 172.31.187.38:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.114.0.24:53 (active)       
                                          2 => 10.114.0.7:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.114.0.24:9153 (active)     
                                          2 => 10.114.0.7:9153 (active)      
5    10.100.123.225:2379   ClusterIP      1 => 10.114.0.65:2379 (active)     
