filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcbb02681b7e5f direct-action not_in_hw id 525 tag 1d70594ea255c904 jited 
