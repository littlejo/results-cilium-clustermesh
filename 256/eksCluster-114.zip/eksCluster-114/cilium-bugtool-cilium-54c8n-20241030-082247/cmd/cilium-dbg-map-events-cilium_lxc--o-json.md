{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:06.854Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.171.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:06.854Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.187.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:06.854Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:11.549Z",
  "value": "id=3702  sec_id=3785811 flags=0x0000 ifindex=12  mac=EE:03:1B:C8:8A:E8 nodemac=DE:85:40:90:54:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:11.552Z",
  "value": "id=3436  sec_id=3785811 flags=0x0000 ifindex=14  mac=FA:A6:3B:08:57:8A nodemac=AE:28:B3:63:2D:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:11.615Z",
  "value": "id=1511  sec_id=4     flags=0x0000 ifindex=10  mac=12:CD:CE:16:1A:9D nodemac=36:E7:B3:D6:EF:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:11.656Z",
  "value": "id=3436  sec_id=3785811 flags=0x0000 ifindex=14  mac=FA:A6:3B:08:57:8A nodemac=AE:28:B3:63:2D:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:11.708Z",
  "value": "id=3702  sec_id=3785811 flags=0x0000 ifindex=12  mac=EE:03:1B:C8:8A:E8 nodemac=DE:85:40:90:54:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:55.670Z",
  "value": "id=3702  sec_id=3785811 flags=0x0000 ifindex=12  mac=EE:03:1B:C8:8A:E8 nodemac=DE:85:40:90:54:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:55.670Z",
  "value": "id=3436  sec_id=3785811 flags=0x0000 ifindex=14  mac=FA:A6:3B:08:57:8A nodemac=AE:28:B3:63:2D:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:55.672Z",
  "value": "id=1511  sec_id=4     flags=0x0000 ifindex=10  mac=12:CD:CE:16:1A:9D nodemac=36:E7:B3:D6:EF:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:55.703Z",
  "value": "id=680   sec_id=3779621 flags=0x0000 ifindex=16  mac=12:B9:D3:D5:9A:86 nodemac=72:90:66:48:C0:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:55.703Z",
  "value": "id=680   sec_id=3779621 flags=0x0000 ifindex=16  mac=12:B9:D3:D5:9A:86 nodemac=72:90:66:48:C0:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.345Z",
  "value": "id=732   sec_id=3779621 flags=0x0000 ifindex=18  mac=C6:72:D6:54:50:5F nodemac=3E:36:B6:E8:CB:53"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.114.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.475Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.820Z",
  "value": "id=1511  sec_id=4     flags=0x0000 ifindex=10  mac=12:CD:CE:16:1A:9D nodemac=36:E7:B3:D6:EF:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.820Z",
  "value": "id=732   sec_id=3779621 flags=0x0000 ifindex=18  mac=C6:72:D6:54:50:5F nodemac=3E:36:B6:E8:CB:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.821Z",
  "value": "id=3702  sec_id=3785811 flags=0x0000 ifindex=12  mac=EE:03:1B:C8:8A:E8 nodemac=DE:85:40:90:54:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.821Z",
  "value": "id=3436  sec_id=3785811 flags=0x0000 ifindex=14  mac=FA:A6:3B:08:57:8A nodemac=AE:28:B3:63:2D:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.837Z",
  "value": "id=1511  sec_id=4     flags=0x0000 ifindex=10  mac=12:CD:CE:16:1A:9D nodemac=36:E7:B3:D6:EF:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.837Z",
  "value": "id=3702  sec_id=3785811 flags=0x0000 ifindex=12  mac=EE:03:1B:C8:8A:E8 nodemac=DE:85:40:90:54:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.838Z",
  "value": "id=3436  sec_id=3785811 flags=0x0000 ifindex=14  mac=FA:A6:3B:08:57:8A nodemac=AE:28:B3:63:2D:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.839Z",
  "value": "id=732   sec_id=3779621 flags=0x0000 ifindex=18  mac=C6:72:D6:54:50:5F nodemac=3E:36:B6:E8:CB:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.824Z",
  "value": "id=1511  sec_id=4     flags=0x0000 ifindex=10  mac=12:CD:CE:16:1A:9D nodemac=36:E7:B3:D6:EF:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.825Z",
  "value": "id=732   sec_id=3779621 flags=0x0000 ifindex=18  mac=C6:72:D6:54:50:5F nodemac=3E:36:B6:E8:CB:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.826Z",
  "value": "id=3702  sec_id=3785811 flags=0x0000 ifindex=12  mac=EE:03:1B:C8:8A:E8 nodemac=DE:85:40:90:54:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.826Z",
  "value": "id=3436  sec_id=3785811 flags=0x0000 ifindex=14  mac=FA:A6:3B:08:57:8A nodemac=AE:28:B3:63:2D:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.824Z",
  "value": "id=732   sec_id=3779621 flags=0x0000 ifindex=18  mac=C6:72:D6:54:50:5F nodemac=3E:36:B6:E8:CB:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.825Z",
  "value": "id=1511  sec_id=4     flags=0x0000 ifindex=10  mac=12:CD:CE:16:1A:9D nodemac=36:E7:B3:D6:EF:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.825Z",
  "value": "id=3702  sec_id=3785811 flags=0x0000 ifindex=12  mac=EE:03:1B:C8:8A:E8 nodemac=DE:85:40:90:54:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.825Z",
  "value": "id=3436  sec_id=3785811 flags=0x0000 ifindex=14  mac=FA:A6:3B:08:57:8A nodemac=AE:28:B3:63:2D:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.824Z",
  "value": "id=732   sec_id=3779621 flags=0x0000 ifindex=18  mac=C6:72:D6:54:50:5F nodemac=3E:36:B6:E8:CB:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.824Z",
  "value": "id=3702  sec_id=3785811 flags=0x0000 ifindex=12  mac=EE:03:1B:C8:8A:E8 nodemac=DE:85:40:90:54:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.825Z",
  "value": "id=3436  sec_id=3785811 flags=0x0000 ifindex=14  mac=FA:A6:3B:08:57:8A nodemac=AE:28:B3:63:2D:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.825Z",
  "value": "id=1511  sec_id=4     flags=0x0000 ifindex=10  mac=12:CD:CE:16:1A:9D nodemac=36:E7:B3:D6:EF:A9"
}

