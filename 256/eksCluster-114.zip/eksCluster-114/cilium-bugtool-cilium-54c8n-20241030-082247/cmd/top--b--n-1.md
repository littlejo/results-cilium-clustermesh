top - 08:22:49 up 34 min,  0 users,  load average: 0.10, 0.16, 0.16
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 58.1 us, 35.5 sy,  0.0 ni,  3.2 id,  0.0 wa,  0.0 hi,  3.2 si,  0.0 st
MiB Mem :   7814.2 total,   4462.0 free,   1205.0 used,   2147.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6424.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 399588  79740 S  73.3   5.0   0:54.08 cilium-+
    660 root      20   0 1240432  16260  10768 S   6.7   0.2   0:00.03 cilium-+
    414 root      20   0 1229488   7124   2864 S   0.0   0.1   0:01.14 cilium-+
    670 root      20   0 1228744   3656   2976 S   0.0   0.0   0:00.00 gops
    680 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    681 root      20   0    2208    792    716 S   0.0   0.0   0:00.00 timeout
    698 root      20   0 1244084  19840  13824 S   0.0   0.2   0:00.03 hubble
    727 root      20   0    6576   2412   2088 R   0.0   0.0   0:00.00 top
    759 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
