[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5fdf5788_354e_4891_a153_9c0c77d019eb.slice/cri-containerd-f630a0780c095a92a2e6cc0edd5ec449cf2c88643fe056d0fc2ff1ab1d50b7b7.scope"
      }
    ],
    "ips": [
      "10.114.0.24"
    ],
    "name": "coredns-cc6ccd49c-lpb57",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod707cad7d_7906_4c0e_8101_82c9d382467b.slice/cri-containerd-8db59ef5da88130ccdb0e1c4b70c609ed3d1e01bca6753ebeaffed686e4edbb6.scope"
      }
    ],
    "ips": [
      "10.114.0.7"
    ],
    "name": "coredns-cc6ccd49c-6l5m6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9786f90_5193_4011_906c_740729e0f873.slice/cri-containerd-7c134380156bd760d8a47160689a43f05ebf8c0485b7359780383803d4f01858.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9786f90_5193_4011_906c_740729e0f873.slice/cri-containerd-5761eca3f867b1bfa0323bc4bcf55cda7f910c9944e420e8628122fb0ef64445.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9786f90_5193_4011_906c_740729e0f873.slice/cri-containerd-f987b144a40400da6bbc00c733b553629930baa79ad093ac456e1b344acb8cb3.scope"
      }
    ],
    "ips": [
      "10.114.0.65"
    ],
    "name": "clustermesh-apiserver-65f7645b56-4kzcv",
    "namespace": "kube-system"
  }
]

