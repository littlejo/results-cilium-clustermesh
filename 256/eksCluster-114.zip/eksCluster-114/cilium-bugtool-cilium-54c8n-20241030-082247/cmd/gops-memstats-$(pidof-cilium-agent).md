alloc: 105.24MB (110350328 bytes)
total-alloc: 2.41GB (2586980160 bytes)
sys: 345.09MB (361848180 bytes)
lookups: 0
mallocs: 65419230
frees: 64594019
heap-alloc: 105.24MB (110350328 bytes)
heap-sys: 263.54MB (276340736 bytes)
heap-idle: 93.27MB (97804288 bytes)
heap-in-use: 170.27MB (178536448 bytes)
heap-released: 31.89MB (33439744 bytes)
heap-objects: 825211
stack-in-use: 68.44MB (71761920 bytes)
stack-sys: 68.44MB (71761920 bytes)
stack-mspan-inuse: 2.96MB (3098880 bytes)
stack-mspan-sys: 3.97MB (4161600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.09MB (1141785 bytes)
gc-sys: 6.05MB (6347232 bytes)
next-gc: when heap-alloc >= 212.08MB (222384632 bytes)
last-gc: 2024-10-30 08:23:13.542765499 +0000 UTC
gc-pause-total: 26.61306ms
gc-pause: 74714
gc-pause-end: 1730276593542765499
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0005549230088574749
enable-gc: true
debug-gc: false
