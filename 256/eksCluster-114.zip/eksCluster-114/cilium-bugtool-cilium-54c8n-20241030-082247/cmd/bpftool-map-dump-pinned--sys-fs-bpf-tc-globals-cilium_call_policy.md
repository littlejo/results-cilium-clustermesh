key: dc 02 00 00  value: 76 02 00 00
key: e7 05 00 00  value: 04 02 00 00
key: 6c 0d 00 00  value: 12 02 00 00
key: 76 0e 00 00  value: 19 02 00 00
Found 4 elements
