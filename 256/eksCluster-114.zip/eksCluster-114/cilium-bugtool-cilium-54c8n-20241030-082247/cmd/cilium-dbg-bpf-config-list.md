KEY             VALUE
AgentLiveness   2107412828037
UTimeOffset     3379442369140625
