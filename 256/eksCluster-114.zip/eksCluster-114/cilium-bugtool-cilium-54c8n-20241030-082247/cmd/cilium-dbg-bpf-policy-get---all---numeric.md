Endpoint ID: 732
Path: /sys/fs/bpf/tc/globals/cilium_policy_00732

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11446900   113578    0        
Allow    Ingress     1          ANY          NONE         disabled    10646834   108793    0        
Allow    Egress      0          ANY          NONE         disabled    12020426   118781    0        


Endpoint ID: 1148
Path: /sys/fs/bpf/tc/globals/cilium_policy_01148

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1511
Path: /sys/fs/bpf/tc/globals/cilium_policy_01511

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1648893   20833     0        
Allow    Ingress     1          ANY          NONE         disabled    23698     276       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3436
Path: /sys/fs/bpf/tc/globals/cilium_policy_03436

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    155731   1793      0        
Allow    Egress      0          ANY          NONE         disabled    18683    207       0        


Endpoint ID: 3702
Path: /sys/fs/bpf/tc/globals/cilium_policy_03702

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    155656   1787      0        
Allow    Egress      0          ANY          NONE         disabled    20474    228       0        


