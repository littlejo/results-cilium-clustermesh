xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 573
ens6(5) clsact/ingress cil_from_netdev-ens6 id 577
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 567
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 562
cilium_host(7) clsact/egress cil_from_host-cilium_host id 556
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 514
lxc02e3eb759d5e(12) clsact/ingress cil_from_container-lxc02e3eb759d5e id 518
lxcbc9f261762d7(14) clsact/ingress cil_from_container-lxcbc9f261762d7 id 541
lxc7352c28232ca(18) clsact/ingress cil_from_container-lxc7352c28232ca id 632

flow_dissector:

netfilter:

