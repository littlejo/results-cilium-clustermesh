KEY             VALUE
AgentLiveness   1946375316975
UTimeOffset     3379442687500000
