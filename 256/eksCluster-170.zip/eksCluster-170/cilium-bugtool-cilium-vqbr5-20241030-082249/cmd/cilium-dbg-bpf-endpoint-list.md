IP ADDRESS         LOCAL ENDPOINT INFO
10.170.0.83:0      (localhost)                                                                                        
172.31.186.20:0    (localhost)                                                                                        
10.170.0.200:0     id=555   sec_id=4     flags=0x0000 ifindex=10  mac=9E:1D:53:0E:79:C2 nodemac=EA:74:E2:30:3C:5A     
10.170.0.14:0      id=5     sec_id=5611342 flags=0x0000 ifindex=12  mac=A6:1B:A0:81:16:52 nodemac=E2:8E:C8:92:43:E4   
10.170.0.86:0      id=3218  sec_id=5611342 flags=0x0000 ifindex=14  mac=7E:25:8B:FF:C1:0E nodemac=3E:5E:FC:DF:AE:1C   
10.170.0.11:0      id=998   sec_id=5610337 flags=0x0000 ifindex=18  mac=BE:B4:C6:3A:02:6F nodemac=FE:E9:16:8F:0A:34   
172.31.160.142:0   (localhost)                                                                                        
