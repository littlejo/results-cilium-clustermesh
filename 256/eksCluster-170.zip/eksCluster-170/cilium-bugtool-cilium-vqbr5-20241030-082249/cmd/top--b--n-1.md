top - 08:22:50 up 31 min,  0 users,  load average: 0.31, 0.15, 0.10
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 25.0 us, 46.4 sy,  0.0 ni, 25.0 id,  0.0 wa,  0.0 hi,  3.6 si,  0.0 st
MiB Mem :   7814.2 total,   4480.3 free,   1188.6 used,   2145.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6440.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 382328  79360 S   6.7   4.8   0:47.43 cilium-+
    636 root      20   0 1240432  15444  10576 S   6.7   0.2   0:00.03 cilium-+
    416 root      20   0 1229744   8252   3900 S   0.0   0.1   0:01.10 cilium-+
    689 root      20   0    6576   2408   2084 R   0.0   0.0   0:00.00 top
    700 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    712 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    729 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
