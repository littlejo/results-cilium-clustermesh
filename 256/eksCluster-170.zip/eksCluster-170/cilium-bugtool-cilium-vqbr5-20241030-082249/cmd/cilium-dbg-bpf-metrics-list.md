REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36666     2904117     677    bpf_overlay.c
Interface                 INGRESS     656617    133269411   1132   bpf_host.c
Success                   EGRESS      16471     1297794     1694   bpf_host.c
Success                   EGRESS      277590    34495367    1308   bpf_lxc.c
Success                   EGRESS      37067     2930109     53     encap.h
Success                   INGRESS     320230    36268203    86     l3.h
Success                   INGRESS     341076    37918572    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
