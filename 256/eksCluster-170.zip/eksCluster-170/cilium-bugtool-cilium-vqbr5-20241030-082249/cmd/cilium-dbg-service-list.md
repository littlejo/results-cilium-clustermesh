ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.246.8:443 (active)     
                                        2 => 172.31.161.104:443 (active)   
2    10.100.50.149:443   ClusterIP      1 => 172.31.186.20:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.170.0.14:53 (active)       
                                        2 => 10.170.0.86:53 (active)       
4    10.100.0.10:9153    ClusterIP      1 => 10.170.0.14:9153 (active)     
                                        2 => 10.170.0.86:9153 (active)     
5    10.100.11.19:2379   ClusterIP      1 => 10.170.0.11:2379 (active)     
