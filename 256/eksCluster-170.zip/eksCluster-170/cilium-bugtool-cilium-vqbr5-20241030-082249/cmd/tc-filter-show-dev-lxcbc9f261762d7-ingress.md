filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcbc9f261762d7 direct-action not_in_hw id 541 tag f6a72915d7d25fcf jited 
