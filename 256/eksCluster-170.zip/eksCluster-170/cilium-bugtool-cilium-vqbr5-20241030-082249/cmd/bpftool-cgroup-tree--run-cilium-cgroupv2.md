CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9d1ce92_d19c_4778_9b17_54607fdc5931.slice/cri-containerd-503520c0beadf39628be32f72e53f9c89b6ac359cda1cb26eba812f3f30adb8b.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9d1ce92_d19c_4778_9b17_54607fdc5931.slice/cri-containerd-70a852365dc7ed2da0b34c634433b613b06d92fd70914011ef6aa9ad85f683da.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcaed6c22_5b06_4b1f_83b5_1766ed09f56a.slice/cri-containerd-01e6a5e6beb4add7aeaf47fccad9c096dd2c3f80568bb9a38c8cf6893cd02567.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcaed6c22_5b06_4b1f_83b5_1766ed09f56a.slice/cri-containerd-9b938cafc2945605f552be478d28dd8fee166b1687084440355673bf24c8525b.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod88f43656_7df1_4c31_a93c_de8f2d2964ef.slice/cri-containerd-78026a65747a9613ebee713a689377401d4039d36306d4d7a5590e5749584c96.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod88f43656_7df1_4c31_a93c_de8f2d2964ef.slice/cri-containerd-12418d567ddbb9f4085bac14c19e15a194b1d4c76a136d8ecd4e32ee39d2e661.scope
    523      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1e668033_c11e_45e9_befe_c769b9ca00fe.slice/cri-containerd-db79eb30dead7ae3fefad9e67f931930d8c243fb9ec7be8a35e6e7dbf84c31f6.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1e668033_c11e_45e9_befe_c769b9ca00fe.slice/cri-containerd-449938a171fcad2ea3542c5ba58cab353366e114dd248f92c85683ba4c3596fc.scope
    527      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod21aba9f4_36cc_454c_9744_d067ac5fe8f0.slice/cri-containerd-a9e74ff01dda57c74887838ed09829081098b842097fd62003fc5a91735f2023.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod21aba9f4_36cc_454c_9744_d067ac5fe8f0.slice/cri-containerd-34d67c950b6921906eb3443bbf917b7bdec8f60f668e23838391c13c81ee65f4.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95a1b082_fe60_4a2b_a5db_192cbbc703bd.slice/cri-containerd-e798883a34899259ad107cc2417516b082f8019f0304f4101374a51ac99a454d.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95a1b082_fe60_4a2b_a5db_192cbbc703bd.slice/cri-containerd-e8cfdd10b1de53d558c6dd4ca4e39d2dce9a08da98af196440f775a66df7d109.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95a1b082_fe60_4a2b_a5db_192cbbc703bd.slice/cri-containerd-ad5c791077b9c0aab755ed7f0189304f760548a24efa46c1e25c125729a53664.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95a1b082_fe60_4a2b_a5db_192cbbc703bd.slice/cri-containerd-69bdb98349fde3be1d4ac771529342107f2eaa99f905912de8a93422c70583e5.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a2a7e41_40aa_4048_931e_e4bc066f8b3d.slice/cri-containerd-4c15ffddf7a2955a540417530496b9759c04b358e1fd6606783f562b49be6664.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a2a7e41_40aa_4048_931e_e4bc066f8b3d.slice/cri-containerd-0602fd943af67cb9b11477d80f59cc7664fee9999a45ea03d37df94e55ac877e.scope
    106      cgroup_device   multi                                          
