filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc7352c28232ca direct-action not_in_hw id 632 tag 8ca030e3128517ba jited 
