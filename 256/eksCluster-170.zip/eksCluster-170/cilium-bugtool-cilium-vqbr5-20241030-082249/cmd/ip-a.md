1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:05:2d:ea:86:b5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.186.20/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3496sec preferred_lft 3496sec
    inet6 fe80::405:2dff:feea:86b5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d6:ed:7e:9a:fd brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.160.142/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4d6:edff:fe7e:9afd/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:2b:aa:0a:0f:bb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c42b:aaff:fe0a:fbb/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:8b:2e:c7:4b:de brd ff:ff:ff:ff:ff:ff
    inet 10.170.0.83/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::248b:2eff:fec7:4bde/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether da:54:5b:8b:59:7c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d854:5bff:fe8b:597c/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:74:e2:30:3c:5a brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::e874:e2ff:fe30:3c5a/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc02e3eb759d5e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:8e:c8:92:43:e4 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::e08e:c8ff:fe92:43e4/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcbc9f261762d7@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:5e:fc:df:ae:1c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::3c5e:fcff:fedf:ae1c/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc7352c28232ca@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:e9:16:8f:0a:34 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::fce9:16ff:fe8f:a34/64 scope link 
       valid_lft forever preferred_lft forever
