key: 05 00 00 00  value: 10 02 00 00
key: 2b 02 00 00  value: 04 02 00 00
key: e6 03 00 00  value: 77 02 00 00
key: 92 0c 00 00  value: 1b 02 00 00
Found 4 elements
