Endpoint ID: 5
Path: /sys/fs/bpf/tc/globals/cilium_policy_00005

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    125997   1448      0        
Allow    Egress      0          ANY          NONE         disabled    17426    189       0        


Endpoint ID: 555
Path: /sys/fs/bpf/tc/globals/cilium_policy_00555

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1654564   20899     0        
Allow    Ingress     1          ANY          NONE         disabled    19136     225       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 998
Path: /sys/fs/bpf/tc/globals/cilium_policy_00998

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11555698   115767    0        
Allow    Ingress     1          ANY          NONE         disabled    10352262   109025    0        
Allow    Egress      0          ANY          NONE         disabled    13817558   135407    0        


Endpoint ID: 3218
Path: /sys/fs/bpf/tc/globals/cilium_policy_03218

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    125271   1437      0        
Allow    Egress      0          ANY          NONE         disabled    17190    185       0        


Endpoint ID: 3385
Path: /sys/fs/bpf/tc/globals/cilium_policy_03385

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


