alloc: 117.91MB (123634168 bytes)
total-alloc: 2.18GB (2342571896 bytes)
sys: 316.77MB (332157284 bytes)
lookups: 0
mallocs: 62589233
frees: 61517828
heap-alloc: 117.91MB (123634168 bytes)
heap-sys: 239.53MB (251166720 bytes)
heap-idle: 75.38MB (79044608 bytes)
heap-in-use: 164.15MB (172122112 bytes)
heap-released: 8.53MB (8945664 bytes)
heap-objects: 1071405
stack-in-use: 64.47MB (67600384 bytes)
stack-sys: 64.47MB (67600384 bytes)
stack-mspan-inuse: 2.83MB (2964960 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1006.81KB (1030977 bytes)
gc-sys: 5.96MB (6245768 bytes)
next-gc: when heap-alloc >= 212.27MB (222581944 bytes)
last-gc: 2024-10-30 08:22:34.285058346 +0000 UTC
gc-pause-total: 14.856597ms
gc-pause: 100933
gc-pause-end: 1730276554285058346
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0004960418050349779
enable-gc: true
debug-gc: false
