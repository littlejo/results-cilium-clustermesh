[
  {
    "containers": [
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95a1b082_fe60_4a2b_a5db_192cbbc703bd.slice/cri-containerd-e798883a34899259ad107cc2417516b082f8019f0304f4101374a51ac99a454d.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95a1b082_fe60_4a2b_a5db_192cbbc703bd.slice/cri-containerd-e8cfdd10b1de53d558c6dd4ca4e39d2dce9a08da98af196440f775a66df7d109.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95a1b082_fe60_4a2b_a5db_192cbbc703bd.slice/cri-containerd-ad5c791077b9c0aab755ed7f0189304f760548a24efa46c1e25c125729a53664.scope"
      }
    ],
    "ips": [
      "10.170.0.11"
    ],
    "name": "clustermesh-apiserver-7d565fd4cd-nhtrc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod88f43656_7df1_4c31_a93c_de8f2d2964ef.slice/cri-containerd-78026a65747a9613ebee713a689377401d4039d36306d4d7a5590e5749584c96.scope"
      }
    ],
    "ips": [
      "10.170.0.14"
    ],
    "name": "coredns-cc6ccd49c-hwlls",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1e668033_c11e_45e9_befe_c769b9ca00fe.slice/cri-containerd-db79eb30dead7ae3fefad9e67f931930d8c243fb9ec7be8a35e6e7dbf84c31f6.scope"
      }
    ],
    "ips": [
      "10.170.0.86"
    ],
    "name": "coredns-cc6ccd49c-cvrs6",
    "namespace": "kube-system"
  }
]

