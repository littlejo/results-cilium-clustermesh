Error: bpf obj get (/sys/fs/bpf/tc/globals/cilium_lb6_source_range): No such file or directory
> Error while running 'bpftool map dump pinned /sys/fs/bpf/tc/globals/cilium_lb6_source_range':  exit status 255

