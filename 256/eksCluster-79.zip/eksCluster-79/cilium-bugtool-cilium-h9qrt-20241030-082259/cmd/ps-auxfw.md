USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         632  0.0  0.2 1240176 16012 ?       Ssl  08:23   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         655  0.0  0.0   6408  1648 ?        R    08:23   0:00  \_ ps auxfw
root           1  3.6  4.7 1606080 380012 ?      Ssl  07:56   0:58 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.0 1229744 6952 ?        Sl   07:56   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
