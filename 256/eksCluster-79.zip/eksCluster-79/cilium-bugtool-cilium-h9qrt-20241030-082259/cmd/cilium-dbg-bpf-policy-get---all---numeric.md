Endpoint ID: 48
Path: /sys/fs/bpf/tc/globals/cilium_policy_00048

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    154508   1778      0        
Allow    Egress      0          ANY          NONE         disabled    18864    208       0        


Endpoint ID: 591
Path: /sys/fs/bpf/tc/globals/cilium_policy_00591

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    153441   1757      0        
Allow    Egress      0          ANY          NONE         disabled    20356    225       0        


Endpoint ID: 1077
Path: /sys/fs/bpf/tc/globals/cilium_policy_01077

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1675365   21218     0        
Allow    Ingress     1          ANY          NONE         disabled    24076     283       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1127
Path: /sys/fs/bpf/tc/globals/cilium_policy_01127

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2518
Path: /sys/fs/bpf/tc/globals/cilium_policy_02518

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11567688   114303    0        
Allow    Ingress     1          ANY          NONE         disabled    9870726    103897    0        
Allow    Egress      0          ANY          NONE         disabled    12015276   119169    0        


