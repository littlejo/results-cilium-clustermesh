alloc: 123.77MB (129778840 bytes)
total-alloc: 2.25GB (2420661600 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63469760
frees: 62323255
heap-alloc: 123.77MB (129778840 bytes)
heap-sys: 247.48MB (259497984 bytes)
heap-idle: 81.59MB (85557248 bytes)
heap-in-use: 165.88MB (173940736 bytes)
heap-released: 3.38MB (3538944 bytes)
heap-objects: 1146505
stack-in-use: 64.50MB (67633152 bytes)
stack-sys: 64.50MB (67633152 bytes)
stack-mspan-inuse: 2.83MB (2963520 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1060617 bytes)
gc-sys: 5.98MB (6274416 bytes)
next-gc: when heap-alloc >= 214.00MB (224395496 bytes)
last-gc: 2024-10-30 08:23:12.763887745 +0000 UTC
gc-pause-total: 16.218909ms
gc-pause: 68331
gc-pause-end: 1730276592763887745
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.0003762042651761798
enable-gc: true
debug-gc: false
