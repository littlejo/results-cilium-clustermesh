{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:31.266Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.192.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:31.266Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.240.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:31.266Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:36.097Z",
  "value": "id=1077  sec_id=4     flags=0x0000 ifindex=10  mac=1E:E5:32:49:D8:3F nodemac=82:57:B7:A9:12:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:36.101Z",
  "value": "id=48    sec_id=2634818 flags=0x0000 ifindex=12  mac=F2:0D:E4:8A:77:55 nodemac=A6:31:00:D2:4A:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:36.152Z",
  "value": "id=591   sec_id=2634818 flags=0x0000 ifindex=14  mac=16:7A:C1:C4:B4:0A nodemac=9E:D7:6F:48:E1:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:36.153Z",
  "value": "id=48    sec_id=2634818 flags=0x0000 ifindex=12  mac=F2:0D:E4:8A:77:55 nodemac=A6:31:00:D2:4A:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:36.156Z",
  "value": "id=1077  sec_id=4     flags=0x0000 ifindex=10  mac=1E:E5:32:49:D8:3F nodemac=82:57:B7:A9:12:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:23.796Z",
  "value": "id=48    sec_id=2634818 flags=0x0000 ifindex=12  mac=F2:0D:E4:8A:77:55 nodemac=A6:31:00:D2:4A:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:23.796Z",
  "value": "id=1077  sec_id=4     flags=0x0000 ifindex=10  mac=1E:E5:32:49:D8:3F nodemac=82:57:B7:A9:12:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:23.797Z",
  "value": "id=591   sec_id=2634818 flags=0x0000 ifindex=14  mac=16:7A:C1:C4:B4:0A nodemac=9E:D7:6F:48:E1:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:23.833Z",
  "value": "id=1134  sec_id=2633462 flags=0x0000 ifindex=16  mac=62:6D:D9:29:B9:30 nodemac=5A:92:16:A7:74:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:24.797Z",
  "value": "id=1077  sec_id=4     flags=0x0000 ifindex=10  mac=1E:E5:32:49:D8:3F nodemac=82:57:B7:A9:12:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:24.797Z",
  "value": "id=1134  sec_id=2633462 flags=0x0000 ifindex=16  mac=62:6D:D9:29:B9:30 nodemac=5A:92:16:A7:74:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:24.798Z",
  "value": "id=48    sec_id=2634818 flags=0x0000 ifindex=12  mac=F2:0D:E4:8A:77:55 nodemac=A6:31:00:D2:4A:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:24.798Z",
  "value": "id=591   sec_id=2634818 flags=0x0000 ifindex=14  mac=16:7A:C1:C4:B4:0A nodemac=9E:D7:6F:48:E1:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.336Z",
  "value": "id=2518  sec_id=2633462 flags=0x0000 ifindex=18  mac=76:93:6A:F7:DA:66 nodemac=26:71:7F:DC:78:D5"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.79.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.857Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.495Z",
  "value": "id=591   sec_id=2634818 flags=0x0000 ifindex=14  mac=16:7A:C1:C4:B4:0A nodemac=9E:D7:6F:48:E1:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.495Z",
  "value": "id=2518  sec_id=2633462 flags=0x0000 ifindex=18  mac=76:93:6A:F7:DA:66 nodemac=26:71:7F:DC:78:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.496Z",
  "value": "id=1077  sec_id=4     flags=0x0000 ifindex=10  mac=1E:E5:32:49:D8:3F nodemac=82:57:B7:A9:12:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.497Z",
  "value": "id=48    sec_id=2634818 flags=0x0000 ifindex=12  mac=F2:0D:E4:8A:77:55 nodemac=A6:31:00:D2:4A:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.495Z",
  "value": "id=2518  sec_id=2633462 flags=0x0000 ifindex=18  mac=76:93:6A:F7:DA:66 nodemac=26:71:7F:DC:78:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.495Z",
  "value": "id=1077  sec_id=4     flags=0x0000 ifindex=10  mac=1E:E5:32:49:D8:3F nodemac=82:57:B7:A9:12:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.496Z",
  "value": "id=48    sec_id=2634818 flags=0x0000 ifindex=12  mac=F2:0D:E4:8A:77:55 nodemac=A6:31:00:D2:4A:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.496Z",
  "value": "id=591   sec_id=2634818 flags=0x0000 ifindex=14  mac=16:7A:C1:C4:B4:0A nodemac=9E:D7:6F:48:E1:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.495Z",
  "value": "id=48    sec_id=2634818 flags=0x0000 ifindex=12  mac=F2:0D:E4:8A:77:55 nodemac=A6:31:00:D2:4A:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.495Z",
  "value": "id=591   sec_id=2634818 flags=0x0000 ifindex=14  mac=16:7A:C1:C4:B4:0A nodemac=9E:D7:6F:48:E1:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.495Z",
  "value": "id=1077  sec_id=4     flags=0x0000 ifindex=10  mac=1E:E5:32:49:D8:3F nodemac=82:57:B7:A9:12:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.495Z",
  "value": "id=2518  sec_id=2633462 flags=0x0000 ifindex=18  mac=76:93:6A:F7:DA:66 nodemac=26:71:7F:DC:78:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.495Z",
  "value": "id=591   sec_id=2634818 flags=0x0000 ifindex=14  mac=16:7A:C1:C4:B4:0A nodemac=9E:D7:6F:48:E1:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.495Z",
  "value": "id=48    sec_id=2634818 flags=0x0000 ifindex=12  mac=F2:0D:E4:8A:77:55 nodemac=A6:31:00:D2:4A:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.496Z",
  "value": "id=1077  sec_id=4     flags=0x0000 ifindex=10  mac=1E:E5:32:49:D8:3F nodemac=82:57:B7:A9:12:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.496Z",
  "value": "id=2518  sec_id=2633462 flags=0x0000 ifindex=18  mac=76:93:6A:F7:DA:66 nodemac=26:71:7F:DC:78:D5"
}

