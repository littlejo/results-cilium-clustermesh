markdown output at /tmp/cilium-bugtool-20241030-082300.857+0000-UTC-3239689976/cmd/cilium-debuginfo-20241030-082332.268+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082300.857+0000-UTC-3239689976/cmd/cilium-debuginfo-20241030-082332.268+0000-UTC.json
