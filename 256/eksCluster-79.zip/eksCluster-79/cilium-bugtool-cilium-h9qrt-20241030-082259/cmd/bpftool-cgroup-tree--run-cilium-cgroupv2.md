CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod79e2a214_11d7_40fd_b668_56f8987640f8.slice/cri-containerd-def2244716b06ef5cf72703b1401e461cd709e01442a9a4f45cbc16564e7b310.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod79e2a214_11d7_40fd_b668_56f8987640f8.slice/cri-containerd-7d1e59cfa940b6ecd3af09fff06fbdd5a679cf5d4179cef43d5b69905f899421.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b5bebde_b11f_4a22_b85c_7906c038f8cf.slice/cri-containerd-6df86d40752f6fab082eebef386cc54fb2669de3ffe756843b0901eb11266a8f.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b5bebde_b11f_4a22_b85c_7906c038f8cf.slice/cri-containerd-6df0f0ed7541d78465fcabc4f51823c4561cd386a5ac0be99438ccbe0bdb42a9.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podddedc7c8_54cc_49d8_a989_05cdecaf2418.slice/cri-containerd-3604e5fada4acf60c4bb52a50bb9970257728669778383120908b5b87947d0fa.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podddedc7c8_54cc_49d8_a989_05cdecaf2418.slice/cri-containerd-a5830c02cc09d70d1d65bf45f167b2c65ff4f8f64a73bcf0a056be229e63c215.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda90e4fc_952e_4c26_b55c_1927154d0a24.slice/cri-containerd-35e305d987d6787a7f8d9563b3c98a86c48dc720b7b358a7bfe792e536479f00.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda90e4fc_952e_4c26_b55c_1927154d0a24.slice/cri-containerd-1598612f4db39c50943cd014cf108dbf65c591d3a52729acde152738efe8eec6.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podee67eee9_df45_4673_bcbe_b8f118f0ae36.slice/cri-containerd-c458773f4f2f9ac159f51a92f92569950ebbd6441590175c23cd1413642d9fce.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podee67eee9_df45_4673_bcbe_b8f118f0ae36.slice/cri-containerd-589d40e672f491b3734b905f53b0adb10c7fd0d177471858258a4236dbc267cc.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca4be7c5_938e_43e6_a0f2_ef9bd56b3137.slice/cri-containerd-be08afe5dd5fd0d0bc8bfdb765aeafd54609bf380a097ef68d8e5039d9e8e083.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca4be7c5_938e_43e6_a0f2_ef9bd56b3137.slice/cri-containerd-c9e31486e8c86d71747608446574cf438df5dcdf344121feb6ac2c65ee5f0302.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca4be7c5_938e_43e6_a0f2_ef9bd56b3137.slice/cri-containerd-1582874fda8fb0453d4ed91be52caf9b4037ac603d2b69197630a76efafdff07.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca4be7c5_938e_43e6_a0f2_ef9bd56b3137.slice/cri-containerd-34e42c7d85182714e73430a0baa32d184b3abc6afa44614283cf3bd2337f665d.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6dd89c0f_ba82_4f52_a3fd_cc7e844f3fe6.slice/cri-containerd-5a7fef595f97b80fe57397554483e9915863a8ea545e293fcc1185a41665c215.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6dd89c0f_ba82_4f52_a3fd_cc7e844f3fe6.slice/cri-containerd-b9762b2d4f59df81aaaa5df719e162ae74f060420d43f41e2f78329b3948577c.scope
    91       cgroup_device   multi                                          
