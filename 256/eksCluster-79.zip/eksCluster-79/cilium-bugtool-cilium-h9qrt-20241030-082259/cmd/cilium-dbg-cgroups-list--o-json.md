[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca4be7c5_938e_43e6_a0f2_ef9bd56b3137.slice/cri-containerd-34e42c7d85182714e73430a0baa32d184b3abc6afa44614283cf3bd2337f665d.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca4be7c5_938e_43e6_a0f2_ef9bd56b3137.slice/cri-containerd-1582874fda8fb0453d4ed91be52caf9b4037ac603d2b69197630a76efafdff07.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca4be7c5_938e_43e6_a0f2_ef9bd56b3137.slice/cri-containerd-be08afe5dd5fd0d0bc8bfdb765aeafd54609bf380a097ef68d8e5039d9e8e083.scope"
      }
    ],
    "ips": [
      "10.79.0.219"
    ],
    "name": "clustermesh-apiserver-6b5dbd9f99-grkj6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podddedc7c8_54cc_49d8_a989_05cdecaf2418.slice/cri-containerd-a5830c02cc09d70d1d65bf45f167b2c65ff4f8f64a73bcf0a056be229e63c215.scope"
      }
    ],
    "ips": [
      "10.79.0.33"
    ],
    "name": "coredns-cc6ccd49c-5f57c",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda90e4fc_952e_4c26_b55c_1927154d0a24.slice/cri-containerd-35e305d987d6787a7f8d9563b3c98a86c48dc720b7b358a7bfe792e536479f00.scope"
      }
    ],
    "ips": [
      "10.79.0.198"
    ],
    "name": "coredns-cc6ccd49c-cf42b",
    "namespace": "kube-system"
  }
]

