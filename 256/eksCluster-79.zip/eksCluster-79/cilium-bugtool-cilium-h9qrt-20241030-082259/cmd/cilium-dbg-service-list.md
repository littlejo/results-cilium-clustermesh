ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.212.8:443 (active)      
                                         2 => 172.31.189.164:443 (active)    
2    10.100.5.201:443     ClusterIP      1 => 172.31.192.135:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.79.0.198:9153 (active)      
                                         2 => 10.79.0.33:9153 (active)       
4    10.100.0.10:53       ClusterIP      1 => 10.79.0.198:53 (active)        
                                         2 => 10.79.0.33:53 (active)         
5    10.100.97.140:2379   ClusterIP      1 => 10.79.0.219:2379 (active)      
