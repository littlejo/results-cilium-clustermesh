1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:f1:62:be:bc:55 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.192.135/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3326sec preferred_lft 3326sec
    inet6 fe80::8f1:62ff:febe:bc55/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:20:c8:4b:8a:09 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.240.62/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::820:c8ff:fe4b:8a09/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:c0:68:7a:c5:f5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::bcc0:68ff:fe7a:c5f5/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:64:7d:bf:88:d0 brd ff:ff:ff:ff:ff:ff
    inet 10.79.0.13/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::f464:7dff:febf:88d0/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f6:18:ed:af:06:9c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f418:edff:feaf:69c/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:57:b7:a9:12:76 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8057:b7ff:fea9:1276/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc19769b559eca@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:31:00:d2:4a:d9 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a431:ff:fed2:4ad9/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcae71cb356a7e@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:d7:6f:48:e1:54 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::9cd7:6fff:fe48:e154/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc53771b8e9151@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:71:7f:dc:78:d5 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2471:7fff:fedc:78d5/64 scope link 
       valid_lft forever preferred_lft forever
