29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:18+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:48:19+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:48:20+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:48:20+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:48:20+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:20+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:48:24+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:48:35+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:56:33+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
479: sched_cls  name tail_handle_ipv4  tag e609a4efd9354ea7  gpl
	loaded_at 2024-10-30T07:56:33+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
480: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:56:33+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 126
481: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:56:33+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
482: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 129
483: sched_cls  name __send_drop_notify  tag 27f5af91fbe41502  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 130
486: sched_cls  name tail_handle_ipv4_from_host  tag db478ef437a42f8c  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,101
	btf_id 133
487: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,101
	btf_id 134
488: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,101
	btf_id 135
491: sched_cls  name tail_handle_ipv4_from_host  tag db478ef437a42f8c  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,103
	btf_id 139
492: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,103
	btf_id 140
494: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 142
495: sched_cls  name __send_drop_notify  tag 27f5af91fbe41502  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 143
496: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,106,75
	btf_id 145
498: sched_cls  name tail_handle_ipv4_from_host  tag db478ef437a42f8c  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,106
	btf_id 147
499: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,106
	btf_id 148
502: sched_cls  name __send_drop_notify  tag 27f5af91fbe41502  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 151
503: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,107,75
	btf_id 153
505: sched_cls  name tail_handle_ipv4_from_host  tag db478ef437a42f8c  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,107
	btf_id 155
506: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,107
	btf_id 156
509: sched_cls  name __send_drop_notify  tag 27f5af91fbe41502  gpl
	loaded_at 2024-10-30T07:56:34+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 159
511: sched_cls  name tail_handle_ipv4  tag b4c2d9dc5ac534bf  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 162
512: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 164
513: sched_cls  name tail_ipv4_ct_egress  tag a86e0c232d82d5bf  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 166
514: sched_cls  name cil_from_container  tag c74dedb562e5ad28  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 167
518: sched_cls  name handle_policy  tag b6dacacfb7767b50  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 168
519: sched_cls  name tail_handle_arp  tag 8df8cb626f50469e  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 172
523: sched_cls  name tail_ipv4_ct_ingress  tag 2d7fe908b8e1d9fd  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 174
528: sched_cls  name tail_ipv4_to_endpoint  tag 5268c9c260ef363b  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,111,40,37,38
	btf_id 178
530: sched_cls  name tail_handle_ipv4_cont  tag 7a7ae5ce63240a82  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,111,40,37,38,81
	btf_id 182
531: sched_cls  name __send_drop_notify  tag 6fcdfe1aae6c123b  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 185
532: sched_cls  name tail_ipv4_ct_ingress  tag 33cbd10b7e6c6c6e  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 184
533: sched_cls  name tail_handle_arp  tag 5a2a34139bbe0906  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 186
534: sched_cls  name tail_ipv4_ct_egress  tag a86e0c232d82d5bf  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 188
535: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 189
537: sched_cls  name __send_drop_notify  tag f24571f30c376c7d  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 191
539: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,118
	btf_id 193
540: sched_cls  name cil_from_container  tag 296601acf12bea55  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 118,76
	btf_id 195
541: sched_cls  name tail_handle_ipv4  tag 09268d62517e6dac  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 194
542: sched_cls  name handle_policy  tag 83bc238fdcfba3c8  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,118,82,83,117,41,80,100,39,84,75,40,37,38
	btf_id 196
543: sched_cls  name tail_handle_ipv4  tag 5a80303ca2e8d20f  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,118
	btf_id 198
544: sched_cls  name __send_drop_notify  tag af158ea2b7a31a8a  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
545: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 200
546: sched_cls  name handle_policy  tag 1d00afb369ed5de0  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 197
547: sched_cls  name tail_handle_ipv4_cont  tag 1f49138f036572ee  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 202
548: sched_cls  name tail_ipv4_ct_ingress  tag 24406236be649154  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 201
549: sched_cls  name cil_from_container  tag fcd09d310e4718d1  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 203
550: sched_cls  name tail_handle_ipv4_cont  tag ae03821028d359af  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,117,41,100,82,83,39,76,74,77,118,40,37,38,81
	btf_id 205
551: sched_cls  name tail_ipv4_to_endpoint  tag 2c9569a89b3579da  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 204
552: sched_cls  name tail_ipv4_to_endpoint  tag 7fe9fb41c6b807bb  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,117,41,82,83,80,100,39,118,40,37,38
	btf_id 206
553: sched_cls  name tail_handle_arp  tag 1e11528a6e9052d3  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,118
	btf_id 207
554: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
557: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
558: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
561: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
562: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
565: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
566: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
569: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
609: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,135
	btf_id 221
610: sched_cls  name cil_from_container  tag f1c7ff77a0f45011  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 135,76
	btf_id 222
611: sched_cls  name tail_handle_ipv4  tag 5020e977fed2311c  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,135
	btf_id 223
612: sched_cls  name handle_policy  tag c5c1bee7315e9f73  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,135,82,83,134,41,80,133,39,84,75,40,37,38
	btf_id 224
613: sched_cls  name tail_handle_ipv4_cont  tag a06a66956a48c15a  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,134,41,133,82,83,39,76,74,77,135,40,37,38,81
	btf_id 225
614: sched_cls  name tail_ipv4_to_endpoint  tag 544dce5a5f6067a2  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,134,41,82,83,80,133,39,135,40,37,38
	btf_id 226
615: sched_cls  name tail_handle_arp  tag b8685eadf6371fe0  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,135
	btf_id 227
616: sched_cls  name tail_ipv4_ct_ingress  tag 74e3778027e77b5a  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 228
617: sched_cls  name __send_drop_notify  tag 1f93c64d397ffaf5  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 229
618: sched_cls  name tail_ipv4_ct_egress  tag 9b233bfb44576d20  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 230
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
636: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
639: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
643: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
644: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
647: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
