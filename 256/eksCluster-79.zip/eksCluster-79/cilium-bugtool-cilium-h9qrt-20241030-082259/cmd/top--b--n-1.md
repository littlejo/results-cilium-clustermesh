top - 08:23:01 up 34 min,  0 users,  load average: 1.27, 0.42, 0.25
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 44.8 us, 41.4 sy,  0.0 ni, 10.3 id,  0.0 wa,  0.0 hi,  0.0 si,  3.4 st
MiB Mem :   7814.2 total,   4471.6 free,   1196.1 used,   2146.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6433.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 380720  77884 S  66.7   4.8   0:58.70 cilium-+
    632 root      20   0 1240176  16012  11356 S   6.7   0.2   0:00.03 cilium-+
    393 root      20   0 1229744   6952   2864 S   0.0   0.1   0:01.21 cilium-+
    667 root      20   0    6576   2432   2104 R   0.0   0.0   0:00.00 top
    668 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    693 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    701 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    708 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
