key: 30 00 00 00  value: 06 02 00 00
key: 4f 02 00 00  value: 22 02 00 00
key: 35 04 00 00  value: 1e 02 00 00
key: d6 09 00 00  value: 64 02 00 00
Found 4 elements
