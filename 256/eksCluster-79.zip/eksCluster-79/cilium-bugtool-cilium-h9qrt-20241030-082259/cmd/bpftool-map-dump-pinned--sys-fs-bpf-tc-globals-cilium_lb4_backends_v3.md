key: 09 00 00 00  value: 0a 4f 00 21 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 4f 00 c6 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f c0 87 10 94 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 4f 00 db 09 4b 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 4f 00 21 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f d4 08 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 4f 00 c6 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f bd a4 01 bb 00 00  00 00 00 00
Found 8 elements
