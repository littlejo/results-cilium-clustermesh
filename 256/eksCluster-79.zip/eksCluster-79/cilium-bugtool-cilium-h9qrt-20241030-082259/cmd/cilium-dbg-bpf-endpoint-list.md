IP ADDRESS         LOCAL ENDPOINT INFO
10.79.0.77:0       id=1077  sec_id=4     flags=0x0000 ifindex=10  mac=1E:E5:32:49:D8:3F nodemac=82:57:B7:A9:12:76     
10.79.0.219:0      id=2518  sec_id=2633462 flags=0x0000 ifindex=18  mac=76:93:6A:F7:DA:66 nodemac=26:71:7F:DC:78:D5   
10.79.0.33:0       id=48    sec_id=2634818 flags=0x0000 ifindex=12  mac=F2:0D:E4:8A:77:55 nodemac=A6:31:00:D2:4A:D9   
10.79.0.198:0      id=591   sec_id=2634818 flags=0x0000 ifindex=14  mac=16:7A:C1:C4:B4:0A nodemac=9E:D7:6F:48:E1:54   
10.79.0.13:0       (localhost)                                                                                        
172.31.192.135:0   (localhost)                                                                                        
172.31.240.62:0    (localhost)                                                                                        
