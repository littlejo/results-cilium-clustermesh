REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35815     2826779     677    bpf_overlay.c
Interface                 INGRESS     641591    131791280   1132   bpf_host.c
Success                   EGRESS      15340     1202954     1694   bpf_host.c
Success                   EGRESS      269591    33991426    1308   bpf_lxc.c
Success                   EGRESS      35348     2794927     53     encap.h
Success                   INGRESS     312759    35059654    86     l3.h
Success                   INGRESS     333885    36727525    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
