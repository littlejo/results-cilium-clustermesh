REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36599     2898461     677    bpf_overlay.c
Interface                 INGRESS     649028    133103747   1132   bpf_host.c
Success                   EGRESS      16577     1304643     1694   bpf_host.c
Success                   EGRESS      275697    34411527    1308   bpf_lxc.c
Success                   EGRESS      36997     2924913     53     encap.h
Success                   INGRESS     317095    35767414    86     l3.h
Success                   INGRESS     337768    37405278    235    trace.h
Unsupported L3 protocol   EGRESS      42        3132        1492   bpf_lxc.c
