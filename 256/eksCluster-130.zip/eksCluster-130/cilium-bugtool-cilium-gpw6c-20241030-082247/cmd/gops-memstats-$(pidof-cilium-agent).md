alloc: 196.57MB (206114128 bytes)
total-alloc: 2.29GB (2454581920 bytes)
sys: 320.52MB (336089444 bytes)
lookups: 0
mallocs: 64013441
frees: 61968573
heap-alloc: 196.57MB (206114128 bytes)
heap-sys: 243.70MB (255541248 bytes)
heap-idle: 25.64MB (26886144 bytes)
heap-in-use: 218.06MB (228655104 bytes)
heap-released: 2.59MB (2719744 bytes)
heap-objects: 2044868
stack-in-use: 64.25MB (67371008 bytes)
stack-sys: 64.25MB (67371008 bytes)
stack-mspan-inuse: 3.39MB (3556000 bytes)
stack-mspan-sys: 3.78MB (3965760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 820.74KB (840441 bytes)
gc-sys: 6.00MB (6294872 bytes)
next-gc: when heap-alloc >= 211.12MB (221375544 bytes)
last-gc: 2024-10-30 08:22:48.579899191 +0000 UTC
gc-pause-total: 18.624864ms
gc-pause: 106036
gc-pause-end: 1730276568579899191
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0004053209024504833
enable-gc: true
debug-gc: false
