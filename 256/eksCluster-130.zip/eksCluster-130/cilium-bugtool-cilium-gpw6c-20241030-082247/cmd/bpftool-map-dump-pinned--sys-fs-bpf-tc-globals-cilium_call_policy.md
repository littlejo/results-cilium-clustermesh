key: c5 02 00 00  value: 68 02 00 00
key: 33 05 00 00  value: 1a 02 00 00
key: 95 0b 00 00  value: 0a 02 00 00
key: 9b 0b 00 00  value: 24 02 00 00
Found 4 elements
