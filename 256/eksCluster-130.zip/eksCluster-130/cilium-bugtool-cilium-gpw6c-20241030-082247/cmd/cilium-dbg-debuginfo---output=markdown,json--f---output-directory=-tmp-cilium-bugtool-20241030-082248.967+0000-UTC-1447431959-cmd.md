markdown output at /tmp/cilium-bugtool-20241030-082248.967+0000-UTC-1447431959/cmd/cilium-debuginfo-20241030-082320.206+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082248.967+0000-UTC-1447431959/cmd/cilium-debuginfo-20241030-082320.206+0000-UTC.json
