CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode5fa6bdc_bc2a_451f_a27d_d16d37adbe46.slice/cri-containerd-8b0398f097d02dbc072d4c888c93cc957fb57d957c0d5a31f127657c46c8c137.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode5fa6bdc_bc2a_451f_a27d_d16d37adbe46.slice/cri-containerd-17450cb6b1c73f5ec87daa90f2fc8411b1fc5548b979a973295e0c2c8652c9ab.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3ce2b135_3693_4fd5_b349_dc70d3a0beee.slice/cri-containerd-359c595e5d15fcdfa57c59048a1acbece84502633c3468d3b2126ed8e5cbfc11.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3ce2b135_3693_4fd5_b349_dc70d3a0beee.slice/cri-containerd-bd9cc148768ab8eccdea57c2554fed6c88e850ffd7ba97d1e36b5f83a6d8a41d.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod002e6ea2_f938_45cb_b31d_de97cc48c31b.slice/cri-containerd-7764e6f13c85b4fe6615b9f1e1775ea9051a05c56fcd76fd6fdb562d246ce7a6.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod002e6ea2_f938_45cb_b31d_de97cc48c31b.slice/cri-containerd-44325fc22b8982832988a04c7fabc991aa91de2a87c62ce3d4a0e3b6d62d67b7.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf6d21a8c_8a87_425a_9372_a3848c310348.slice/cri-containerd-23f47c1ed9f04c782e2b1151ac87c42b41281d4540e15c0b67ee0e969c0a89c7.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf6d21a8c_8a87_425a_9372_a3848c310348.slice/cri-containerd-5e6fa0ab2f9120af65430dd3c523aef39fd5d0157a1b2702945509c17e564570.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod49e94db4_b222_485d_8c3f_7c32bf05a417.slice/cri-containerd-2c2022fd249715198a42de6cee2a2447d9ed9956fd252e82e30b2d90a0dcac16.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod49e94db4_b222_485d_8c3f_7c32bf05a417.slice/cri-containerd-23319725fe3d5dee9521d0324bdb355d0880af92d2af9410e3c99d5291e5cdca.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod49e94db4_b222_485d_8c3f_7c32bf05a417.slice/cri-containerd-714c20fc1c96bacaff20774336772fc3735b1f5ec8c8e67f371f39d5be265683.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod49e94db4_b222_485d_8c3f_7c32bf05a417.slice/cri-containerd-d8fd121d82bb1c0304dd5c84115193f40b488ccc301b585118c9d72a8ed8178b.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6dfe188a_9a5e_4236_a368_fde714c66f5f.slice/cri-containerd-aa7d9f04b9138e21c12dea70535110f9c9ce5b009297b4b0638f3f17e76248c2.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6dfe188a_9a5e_4236_a368_fde714c66f5f.slice/cri-containerd-37b28ebeb8d8fa6fca9210a6038d8bc987f7e5a9b5e996aa883d9c1416ab6f46.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9de559c3_8975_4333_b520_39382f59393d.slice/cri-containerd-f1a7b287ab0e42f1626b002b3d820ae911965d5c2ff57d81f31fe5a8990940e0.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9de559c3_8975_4333_b520_39382f59393d.slice/cri-containerd-2401a2949df19e2815f7871a7119d4b9b16fba82cea176d6b91998687818c9d2.scope
    94       cgroup_device   multi                                          
