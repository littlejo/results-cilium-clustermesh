{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:31.255Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.130.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:31.255Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.150.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:31.255Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:35.739Z",
  "value": "id=1331  sec_id=4     flags=0x0000 ifindex=10  mac=12:6D:53:08:C9:AF nodemac=86:6A:3A:F2:58:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:35.748Z",
  "value": "id=2965  sec_id=4297291 flags=0x0000 ifindex=12  mac=32:F8:69:B8:99:48 nodemac=C6:C9:06:47:4E:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:35.794Z",
  "value": "id=2971  sec_id=4297291 flags=0x0000 ifindex=14  mac=7A:CD:48:57:E7:00 nodemac=A6:93:07:6F:D3:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:35.795Z",
  "value": "id=2965  sec_id=4297291 flags=0x0000 ifindex=12  mac=32:F8:69:B8:99:48 nodemac=C6:C9:06:47:4E:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:35.805Z",
  "value": "id=1331  sec_id=4     flags=0x0000 ifindex=10  mac=12:6D:53:08:C9:AF nodemac=86:6A:3A:F2:58:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:19.018Z",
  "value": "id=1331  sec_id=4     flags=0x0000 ifindex=10  mac=12:6D:53:08:C9:AF nodemac=86:6A:3A:F2:58:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:19.018Z",
  "value": "id=2965  sec_id=4297291 flags=0x0000 ifindex=12  mac=32:F8:69:B8:99:48 nodemac=C6:C9:06:47:4E:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:19.018Z",
  "value": "id=2971  sec_id=4297291 flags=0x0000 ifindex=14  mac=7A:CD:48:57:E7:00 nodemac=A6:93:07:6F:D3:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:19.048Z",
  "value": "id=1835  sec_id=4310679 flags=0x0000 ifindex=16  mac=02:61:A5:76:F6:13 nodemac=92:39:09:B7:EB:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:19.048Z",
  "value": "id=1835  sec_id=4310679 flags=0x0000 ifindex=16  mac=02:61:A5:76:F6:13 nodemac=92:39:09:B7:EB:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:20.017Z",
  "value": "id=1331  sec_id=4     flags=0x0000 ifindex=10  mac=12:6D:53:08:C9:AF nodemac=86:6A:3A:F2:58:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:20.017Z",
  "value": "id=1835  sec_id=4310679 flags=0x0000 ifindex=16  mac=02:61:A5:76:F6:13 nodemac=92:39:09:B7:EB:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:20.018Z",
  "value": "id=2965  sec_id=4297291 flags=0x0000 ifindex=12  mac=32:F8:69:B8:99:48 nodemac=C6:C9:06:47:4E:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:20.018Z",
  "value": "id=2971  sec_id=4297291 flags=0x0000 ifindex=14  mac=7A:CD:48:57:E7:00 nodemac=A6:93:07:6F:D3:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.821Z",
  "value": "id=709   sec_id=4310679 flags=0x0000 ifindex=18  mac=02:EB:40:22:10:5A nodemac=DE:97:44:C0:64:E1"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.130.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.698Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:27.666Z",
  "value": "id=1331  sec_id=4     flags=0x0000 ifindex=10  mac=12:6D:53:08:C9:AF nodemac=86:6A:3A:F2:58:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:27.666Z",
  "value": "id=2965  sec_id=4297291 flags=0x0000 ifindex=12  mac=32:F8:69:B8:99:48 nodemac=C6:C9:06:47:4E:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:27.667Z",
  "value": "id=2971  sec_id=4297291 flags=0x0000 ifindex=14  mac=7A:CD:48:57:E7:00 nodemac=A6:93:07:6F:D3:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:27.667Z",
  "value": "id=709   sec_id=4310679 flags=0x0000 ifindex=18  mac=02:EB:40:22:10:5A nodemac=DE:97:44:C0:64:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.665Z",
  "value": "id=709   sec_id=4310679 flags=0x0000 ifindex=18  mac=02:EB:40:22:10:5A nodemac=DE:97:44:C0:64:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.665Z",
  "value": "id=1331  sec_id=4     flags=0x0000 ifindex=10  mac=12:6D:53:08:C9:AF nodemac=86:6A:3A:F2:58:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.666Z",
  "value": "id=2965  sec_id=4297291 flags=0x0000 ifindex=12  mac=32:F8:69:B8:99:48 nodemac=C6:C9:06:47:4E:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.666Z",
  "value": "id=2971  sec_id=4297291 flags=0x0000 ifindex=14  mac=7A:CD:48:57:E7:00 nodemac=A6:93:07:6F:D3:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.666Z",
  "value": "id=2971  sec_id=4297291 flags=0x0000 ifindex=14  mac=7A:CD:48:57:E7:00 nodemac=A6:93:07:6F:D3:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.666Z",
  "value": "id=1331  sec_id=4     flags=0x0000 ifindex=10  mac=12:6D:53:08:C9:AF nodemac=86:6A:3A:F2:58:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.667Z",
  "value": "id=709   sec_id=4310679 flags=0x0000 ifindex=18  mac=02:EB:40:22:10:5A nodemac=DE:97:44:C0:64:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.667Z",
  "value": "id=2965  sec_id=4297291 flags=0x0000 ifindex=12  mac=32:F8:69:B8:99:48 nodemac=C6:C9:06:47:4E:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.666Z",
  "value": "id=2965  sec_id=4297291 flags=0x0000 ifindex=12  mac=32:F8:69:B8:99:48 nodemac=C6:C9:06:47:4E:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.666Z",
  "value": "id=709   sec_id=4310679 flags=0x0000 ifindex=18  mac=02:EB:40:22:10:5A nodemac=DE:97:44:C0:64:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.667Z",
  "value": "id=2971  sec_id=4297291 flags=0x0000 ifindex=14  mac=7A:CD:48:57:E7:00 nodemac=A6:93:07:6F:D3:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.130.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.667Z",
  "value": "id=1331  sec_id=4     flags=0x0000 ifindex=10  mac=12:6D:53:08:C9:AF nodemac=86:6A:3A:F2:58:58"
}

