Total: 664
TCP:   1847 (estab 426, closed 1402, orphaned 0, timewait 566)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  445       434       11       
INET	  455       440       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                  Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                           127.0.0.1:34445      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:32345 sk:3e9 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                 172.31.130.213%ens5:68         0.0.0.0:*    uid:192 ino:72193 sk:3ea cgroup:unreachable:c4e <->                            
UNCONN 0      0                             0.0.0.0:8472       0.0.0.0:*    ino:32391 sk:3eb cgroup:/ <->                                                  
UNCONN 0      0                           127.0.0.1:323        0.0.0.0:*    ino:15186 sk:3ec cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                [::]:8472          [::]:*    ino:32390 sk:3ed cgroup:/ v6only:1 <->                                         
UNCONN 0      0                               [::1]:323           [::]:*    ino:15187 sk:3ee cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::42f:9ff:fea9:9453]%ens5:546           [::]:*    uid:192 ino:15668 sk:3ef cgroup:unreachable:c4e v6only:1 <->                   
