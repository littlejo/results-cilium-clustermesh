KEY             VALUE
AgentLiveness   2056814129309
UTimeOffset     3379442466796875
