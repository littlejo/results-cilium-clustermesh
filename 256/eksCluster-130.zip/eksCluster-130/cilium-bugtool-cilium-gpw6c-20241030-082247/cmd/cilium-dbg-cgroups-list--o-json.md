[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod49e94db4_b222_485d_8c3f_7c32bf05a417.slice/cri-containerd-714c20fc1c96bacaff20774336772fc3735b1f5ec8c8e67f371f39d5be265683.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod49e94db4_b222_485d_8c3f_7c32bf05a417.slice/cri-containerd-2c2022fd249715198a42de6cee2a2447d9ed9956fd252e82e30b2d90a0dcac16.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod49e94db4_b222_485d_8c3f_7c32bf05a417.slice/cri-containerd-d8fd121d82bb1c0304dd5c84115193f40b488ccc301b585118c9d72a8ed8178b.scope"
      }
    ],
    "ips": [
      "10.130.0.225"
    ],
    "name": "clustermesh-apiserver-76d884c89-47mpp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode5fa6bdc_bc2a_451f_a27d_d16d37adbe46.slice/cri-containerd-17450cb6b1c73f5ec87daa90f2fc8411b1fc5548b979a973295e0c2c8652c9ab.scope"
      }
    ],
    "ips": [
      "10.130.0.203"
    ],
    "name": "coredns-cc6ccd49c-dmntr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod002e6ea2_f938_45cb_b31d_de97cc48c31b.slice/cri-containerd-44325fc22b8982832988a04c7fabc991aa91de2a87c62ce3d4a0e3b6d62d67b7.scope"
      }
    ],
    "ips": [
      "10.130.0.237"
    ],
    "name": "coredns-cc6ccd49c-lg99c",
    "namespace": "kube-system"
  }
]

