IP ADDRESS         LOCAL ENDPOINT INFO
10.130.0.225:0     id=709   sec_id=4310679 flags=0x0000 ifindex=18  mac=02:EB:40:22:10:5A nodemac=DE:97:44:C0:64:E1   
10.130.0.203:0     id=2971  sec_id=4297291 flags=0x0000 ifindex=14  mac=7A:CD:48:57:E7:00 nodemac=A6:93:07:6F:D3:D1   
172.31.150.28:0    (localhost)                                                                                        
172.31.130.213:0   (localhost)                                                                                        
10.130.0.14:0      (localhost)                                                                                        
10.130.0.237:0     id=2965  sec_id=4297291 flags=0x0000 ifindex=12  mac=32:F8:69:B8:99:48 nodemac=C6:C9:06:47:4E:9D   
10.130.0.195:0     id=1331  sec_id=4     flags=0x0000 ifindex=10  mac=12:6D:53:08:C9:AF nodemac=86:6A:3A:F2:58:58     
