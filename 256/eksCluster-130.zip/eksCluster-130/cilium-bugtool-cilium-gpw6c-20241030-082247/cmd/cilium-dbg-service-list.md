ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.194.83:443 (active)     
                                         2 => 172.31.169.77:443 (active)     
2    10.100.226.225:443   ClusterIP      1 => 172.31.130.213:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.130.0.237:53 (active)       
                                         2 => 10.130.0.203:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.130.0.237:9153 (active)     
                                         2 => 10.130.0.203:9153 (active)     
5    10.100.99.243:2379   ClusterIP      1 => 10.130.0.225:2379 (active)     
