1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:2f:09:a9:94:53 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.130.213/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3384sec preferred_lft 3384sec
    inet6 fe80::42f:9ff:fea9:9453/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:7f:59:39:77:fb brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.150.28/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::47f:59ff:fe39:77fb/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:b3:40:75:88:fe brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ccb3:40ff:fe75:88fe/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:ee:74:85:45:f4 brd ff:ff:ff:ff:ff:ff
    inet 10.130.0.14/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::78ee:74ff:fe85:45f4/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 66:3b:c1:84:4f:3f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::643b:c1ff:fe84:4f3f/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:6a:3a:f2:58:58 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::846a:3aff:fef2:5858/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc11180b24e7d6@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:c9:06:47:4e:9d brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c4c9:6ff:fe47:4e9d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcecaa9317f8b2@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:93:07:6f:d3:d1 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a493:7ff:fe6f:d3d1/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcba15830b31f9@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:97:44:c0:64:e1 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::dc97:44ff:fec0:64e1/64 scope link 
       valid_lft forever preferred_lft forever
