 08:22:49 up 33 min,  0 users,  load average: 0.55, 0.22, 0.13
