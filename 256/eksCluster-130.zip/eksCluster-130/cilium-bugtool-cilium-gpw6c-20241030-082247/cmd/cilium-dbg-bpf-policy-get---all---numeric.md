Endpoint ID: 709
Path: /sys/fs/bpf/tc/globals/cilium_policy_00709

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11546995   115232    0        
Allow    Ingress     1          ANY          NONE         disabled    10195130   107304    0        
Allow    Egress      0          ANY          NONE         disabled    13119249   128781    0        


Endpoint ID: 1331
Path: /sys/fs/bpf/tc/globals/cilium_policy_01331

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1640240   20703     0        
Allow    Ingress     1          ANY          NONE         disabled    21541     251       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1509
Path: /sys/fs/bpf/tc/globals/cilium_policy_01509

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2965
Path: /sys/fs/bpf/tc/globals/cilium_policy_02965

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    145330   1658      0        
Allow    Egress      0          ANY          NONE         disabled    18700    205       0        


Endpoint ID: 2971
Path: /sys/fs/bpf/tc/globals/cilium_policy_02971

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    145528   1661      0        
Allow    Egress      0          ANY          NONE         disabled    19738    218       0        


