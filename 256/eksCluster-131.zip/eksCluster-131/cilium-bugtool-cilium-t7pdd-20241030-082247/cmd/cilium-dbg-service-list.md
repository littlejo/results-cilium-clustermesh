ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.221.252:443 (active)    
                                        2 => 172.31.157.243:443 (active)    
2    10.100.93.247:443   ClusterIP      1 => 172.31.208.241:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.131.0.68:53 (active)        
                                        2 => 10.131.0.189:53 (active)       
4    10.100.0.10:9153    ClusterIP      1 => 10.131.0.68:9153 (active)      
                                        2 => 10.131.0.189:9153 (active)     
5    10.100.83.16:2379   ClusterIP      1 => 10.131.0.33:2379 (active)      
