Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal     57     23     57     60     32     32     11     10     10      2    864 
