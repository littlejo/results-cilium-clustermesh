top - 08:22:49 up 35 min,  0 users,  load average: 0.24, 0.21, 0.18
Tasks:   8 total,   2 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 27.6 us, 62.1 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi, 10.3 si,  0.0 st
MiB Mem :   7814.2 total,   4444.9 free,   1223.5 used,   2145.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6405.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    737 root      20   0 1244340  22780  14332 S  53.3   0.3   0:00.11 hubble
      1 root      20   0 1606080 397508  78520 S   6.7   5.0   0:54.91 cilium-+
    396 root      20   0 1229744   7100   2924 S   0.0   0.1   0:01.18 cilium-+
    673 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
    698 root      20   0 1240432  16720  11484 D   0.0   0.2   0:00.02 cilium-+
    722 root      20   0    2208    788    708 S   0.0   0.0   0:00.00 timeout
    745 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    763 root      20   0 1240432  16720  11484 R   0.0   0.2   0:00.00 cilium-+
