alloc: 114.24MB (119789672 bytes)
total-alloc: 2.20GB (2358537744 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 62428148
frees: 61459870
heap-alloc: 114.24MB (119789672 bytes)
heap-sys: 247.29MB (259301376 bytes)
heap-idle: 83.87MB (87941120 bytes)
heap-in-use: 163.42MB (171360256 bytes)
heap-released: 928.00KB (950272 bytes)
heap-objects: 968278
stack-in-use: 64.69MB (67829760 bytes)
stack-sys: 64.69MB (67829760 bytes)
stack-mspan-inuse: 2.79MB (2930560 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 974.14KB (997521 bytes)
gc-sys: 5.98MB (6266272 bytes)
next-gc: when heap-alloc >= 213.27MB (223626136 bytes)
last-gc: 2024-10-30 08:23:07.958234627 +0000 UTC
gc-pause-total: 7.140807ms
gc-pause: 124998
gc-pause-end: 1730276587958234627
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.00032958861300660437
enable-gc: true
debug-gc: false
