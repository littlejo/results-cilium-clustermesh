CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod57f220ae_6d70_4eab_b174_4d4c85a3b17a.slice/cri-containerd-ad47518dd04c8c4859c9f199d610895f0a3f6616ae5f44d2524d61cb92b818a8.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod57f220ae_6d70_4eab_b174_4d4c85a3b17a.slice/cri-containerd-549eb4af1c6a2ed8e945bdad74fe8e1750bdd0c58593235b517f5cc36aebd067.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10f52940_710c_4447_92ad_b57ee009b5b2.slice/cri-containerd-936275c7848e9108b394561451c569f2836de559bb20cb3afe068bf105901567.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10f52940_710c_4447_92ad_b57ee009b5b2.slice/cri-containerd-d0a8cda859f2ccf62104a40b6b26da6f6d0974d98c38e6df827fb9d408fa9918.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0bcce2f1_70b3_44b5_9325_1345b283f1b9.slice/cri-containerd-12604172f97ae03a0d82e862fe985f030bc040a46edc98d1c3a594f6394d58fe.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0bcce2f1_70b3_44b5_9325_1345b283f1b9.slice/cri-containerd-e0ac433ffd32743a92b77b26cd989ac55429ce2a9c820ef9c1cf6cd9db72b5e5.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaae5b31d_e40a_42a7_a48f_e82d406bb726.slice/cri-containerd-1f879af534fe6bd6979491242ce2117926acc46ead62fcba68e437aa84969b65.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaae5b31d_e40a_42a7_a48f_e82d406bb726.slice/cri-containerd-f88b53163e8d4b537b4252a0d558315934f42953764aa936a5ff5f73d3d1fbd9.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94b42c38_ba4d_488e_8e0e_936198ae8965.slice/cri-containerd-4003a50866bd0a661ae4a832ab62e0684e3319aa3178ee535890cca3dc799460.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94b42c38_ba4d_488e_8e0e_936198ae8965.slice/cri-containerd-b09a83a88570368815ca305e6010aa77c85f61916a2da2429ea60d50b6282c66.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94b42c38_ba4d_488e_8e0e_936198ae8965.slice/cri-containerd-624692f5e5f35e13000732435621adf6d82ec27337591d82b668431f97e1ebcd.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94b42c38_ba4d_488e_8e0e_936198ae8965.slice/cri-containerd-15386f59c65fcca0f21054eef5acbce4df4966a5568f2a4a4332de8e307c33b8.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9b62c559_bf68_4eac_a3ec_c08166b39de5.slice/cri-containerd-d60fbeeea3d49588a9e3574fa6cfc21d6a296d3b131e95c29e03591d93ef2219.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9b62c559_bf68_4eac_a3ec_c08166b39de5.slice/cri-containerd-927337885f05d1d44b66ee29083d00981335f47276a17e1bec96d9df5cc0f5c1.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8fef0bd5_fad7_463a_8f4d_b2c669b3100f.slice/cri-containerd-4bee438a44fd0a5c1dc7e5ac8c38cbebf6e10febf8eafe6507509cde7989f941.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8fef0bd5_fad7_463a_8f4d_b2c669b3100f.slice/cri-containerd-16f7615630a6902c8eb4a91ab82b89e1388d33d67de9062d5726b1497cabfde0.scope
    99       cgroup_device   multi                                          
