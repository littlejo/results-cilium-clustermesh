Total: 668
TCP:   2381 (estab 431, closed 1931, orphaned 0, timewait 1083)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  450       440       10       
INET	  460       446       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                  172.31.208.241%ens5:68         0.0.0.0:*    uid:192 ino:67286 sk:13d2 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:32999 sk:13d3 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15694 sk:13d4 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:33597      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=40)) ino:31791 sk:13d5 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:32998 sk:13d6 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15695 sk:13d7 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::821:92ff:fe7e:4981]%ens5:546           [::]:*    uid:192 ino:15983 sk:13d8 cgroup:unreachable:c4e v6only:1 <->                   
