xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 500
ens6(5) clsact/ingress cil_from_netdev-ens6 id 503
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 490
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 483
cilium_host(7) clsact/egress cil_from_host-cilium_host id 488
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 479
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 478
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 536
lxcd9f33ad04c13(12) clsact/ingress cil_from_container-lxcd9f33ad04c13 id 523
lxcacae092939ed(14) clsact/ingress cil_from_container-lxcacae092939ed id 535
lxc626151ece18e(18) clsact/ingress cil_from_container-lxc626151ece18e id 609

flow_dissector:

netfilter:

