key: 5a 00 00 00  value: 6b 02 00 00
key: cf 00 00 00  value: 1d 02 00 00
key: 35 02 00 00  value: 1a 02 00 00
key: f5 04 00 00  value: 13 02 00 00
Found 4 elements
