REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34078     2689663     677    bpf_overlay.c
Interface                 INGRESS     616217    129433530   1132   bpf_host.c
Success                   EGRESS      13972     1093037     1694   bpf_host.c
Success                   EGRESS      259303    32941466    1308   bpf_lxc.c
Success                   EGRESS      32992     2610391     53     encap.h
Success                   INGRESS     300399    33769464    86     l3.h
Success                   INGRESS     321156    35410136    235    trace.h
Unsupported L3 protocol   EGRESS      41        3026        1492   bpf_lxc.c
