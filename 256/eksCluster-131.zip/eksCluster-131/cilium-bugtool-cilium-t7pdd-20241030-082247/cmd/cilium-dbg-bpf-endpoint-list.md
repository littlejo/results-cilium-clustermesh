IP ADDRESS         LOCAL ENDPOINT INFO
10.131.0.33:0      id=90    sec_id=4328742 flags=0x0000 ifindex=18  mac=5E:67:CE:C5:B5:75 nodemac=42:A9:33:6A:1F:19   
10.131.0.68:0      id=565   sec_id=4347946 flags=0x0000 ifindex=14  mac=72:F2:89:4D:F5:2B nodemac=EE:C6:7F:DF:D2:AB   
172.31.208.241:0   (localhost)                                                                                        
10.131.0.189:0     id=1269  sec_id=4347946 flags=0x0000 ifindex=12  mac=3E:CC:AE:0A:79:A9 nodemac=CA:6D:6F:9C:20:4F   
10.131.0.24:0      (localhost)                                                                                        
172.31.213.174:0   (localhost)                                                                                        
10.131.0.23:0      id=207   sec_id=4     flags=0x0000 ifindex=10  mac=DE:7A:B8:60:B5:E8 nodemac=FA:85:3C:3E:98:D6     
