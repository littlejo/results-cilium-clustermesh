Endpoint ID: 90
Path: /sys/fs/bpf/tc/globals/cilium_policy_00090

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11282095   110594    0        
Allow    Ingress     1          ANY          NONE         disabled    9142601    95421     0        
Allow    Egress      0          ANY          NONE         disabled    11160373   110791    0        


Endpoint ID: 207
Path: /sys/fs/bpf/tc/globals/cilium_policy_00207

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1643338   20793     0        
Allow    Ingress     1          ANY          NONE         disabled    24088     280       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 565
Path: /sys/fs/bpf/tc/globals/cilium_policy_00565

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    164862   1898      0        
Allow    Egress      0          ANY          NONE         disabled    20886    235       0        


Endpoint ID: 1269
Path: /sys/fs/bpf/tc/globals/cilium_policy_01269

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    163747   1876      0        
Allow    Egress      0          ANY          NONE         disabled    22387    251       0        


Endpoint ID: 1806
Path: /sys/fs/bpf/tc/globals/cilium_policy_01806

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


