 08:22:49 up 35 min,  0 users,  load average: 0.24, 0.21, 0.18
