KEY             VALUE
AgentLiveness   2142409382467
UTimeOffset     3379442300781250
