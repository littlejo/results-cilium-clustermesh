{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:43.849Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.208.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:43.849Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.213.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:43.849Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:48.536Z",
  "value": "id=207   sec_id=4     flags=0x0000 ifindex=10  mac=DE:7A:B8:60:B5:E8 nodemac=FA:85:3C:3E:98:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:48.546Z",
  "value": "id=1269  sec_id=4347946 flags=0x0000 ifindex=12  mac=3E:CC:AE:0A:79:A9 nodemac=CA:6D:6F:9C:20:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:48.582Z",
  "value": "id=565   sec_id=4347946 flags=0x0000 ifindex=14  mac=72:F2:89:4D:F5:2B nodemac=EE:C6:7F:DF:D2:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:48.583Z",
  "value": "id=1269  sec_id=4347946 flags=0x0000 ifindex=12  mac=3E:CC:AE:0A:79:A9 nodemac=CA:6D:6F:9C:20:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:48.605Z",
  "value": "id=207   sec_id=4     flags=0x0000 ifindex=10  mac=DE:7A:B8:60:B5:E8 nodemac=FA:85:3C:3E:98:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:52.710Z",
  "value": "id=207   sec_id=4     flags=0x0000 ifindex=10  mac=DE:7A:B8:60:B5:E8 nodemac=FA:85:3C:3E:98:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:52.710Z",
  "value": "id=565   sec_id=4347946 flags=0x0000 ifindex=14  mac=72:F2:89:4D:F5:2B nodemac=EE:C6:7F:DF:D2:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:52.711Z",
  "value": "id=1269  sec_id=4347946 flags=0x0000 ifindex=12  mac=3E:CC:AE:0A:79:A9 nodemac=CA:6D:6F:9C:20:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:52.740Z",
  "value": "id=523   sec_id=4328742 flags=0x0000 ifindex=16  mac=BA:35:B8:1B:96:27 nodemac=8A:DB:85:DB:2A:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:08.169Z",
  "value": "id=90    sec_id=4328742 flags=0x0000 ifindex=18  mac=5E:67:CE:C5:B5:75 nodemac=42:A9:33:6A:1F:19"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.131.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:18.581Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.836Z",
  "value": "id=565   sec_id=4347946 flags=0x0000 ifindex=14  mac=72:F2:89:4D:F5:2B nodemac=EE:C6:7F:DF:D2:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.837Z",
  "value": "id=207   sec_id=4     flags=0x0000 ifindex=10  mac=DE:7A:B8:60:B5:E8 nodemac=FA:85:3C:3E:98:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.837Z",
  "value": "id=1269  sec_id=4347946 flags=0x0000 ifindex=12  mac=3E:CC:AE:0A:79:A9 nodemac=CA:6D:6F:9C:20:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.838Z",
  "value": "id=90    sec_id=4328742 flags=0x0000 ifindex=18  mac=5E:67:CE:C5:B5:75 nodemac=42:A9:33:6A:1F:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.849Z",
  "value": "id=207   sec_id=4     flags=0x0000 ifindex=10  mac=DE:7A:B8:60:B5:E8 nodemac=FA:85:3C:3E:98:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.850Z",
  "value": "id=1269  sec_id=4347946 flags=0x0000 ifindex=12  mac=3E:CC:AE:0A:79:A9 nodemac=CA:6D:6F:9C:20:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.850Z",
  "value": "id=565   sec_id=4347946 flags=0x0000 ifindex=14  mac=72:F2:89:4D:F5:2B nodemac=EE:C6:7F:DF:D2:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.850Z",
  "value": "id=90    sec_id=4328742 flags=0x0000 ifindex=18  mac=5E:67:CE:C5:B5:75 nodemac=42:A9:33:6A:1F:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.836Z",
  "value": "id=207   sec_id=4     flags=0x0000 ifindex=10  mac=DE:7A:B8:60:B5:E8 nodemac=FA:85:3C:3E:98:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.836Z",
  "value": "id=565   sec_id=4347946 flags=0x0000 ifindex=14  mac=72:F2:89:4D:F5:2B nodemac=EE:C6:7F:DF:D2:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.837Z",
  "value": "id=90    sec_id=4328742 flags=0x0000 ifindex=18  mac=5E:67:CE:C5:B5:75 nodemac=42:A9:33:6A:1F:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.837Z",
  "value": "id=1269  sec_id=4347946 flags=0x0000 ifindex=12  mac=3E:CC:AE:0A:79:A9 nodemac=CA:6D:6F:9C:20:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.836Z",
  "value": "id=90    sec_id=4328742 flags=0x0000 ifindex=18  mac=5E:67:CE:C5:B5:75 nodemac=42:A9:33:6A:1F:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.837Z",
  "value": "id=207   sec_id=4     flags=0x0000 ifindex=10  mac=DE:7A:B8:60:B5:E8 nodemac=FA:85:3C:3E:98:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.837Z",
  "value": "id=1269  sec_id=4347946 flags=0x0000 ifindex=12  mac=3E:CC:AE:0A:79:A9 nodemac=CA:6D:6F:9C:20:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.131.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.837Z",
  "value": "id=565   sec_id=4347946 flags=0x0000 ifindex=14  mac=72:F2:89:4D:F5:2B nodemac=EE:C6:7F:DF:D2:AB"
}

