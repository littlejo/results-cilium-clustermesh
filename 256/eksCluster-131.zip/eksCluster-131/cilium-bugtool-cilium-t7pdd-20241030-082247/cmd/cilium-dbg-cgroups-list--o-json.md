[
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94b42c38_ba4d_488e_8e0e_936198ae8965.slice/cri-containerd-624692f5e5f35e13000732435621adf6d82ec27337591d82b668431f97e1ebcd.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94b42c38_ba4d_488e_8e0e_936198ae8965.slice/cri-containerd-b09a83a88570368815ca305e6010aa77c85f61916a2da2429ea60d50b6282c66.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod94b42c38_ba4d_488e_8e0e_936198ae8965.slice/cri-containerd-4003a50866bd0a661ae4a832ab62e0684e3319aa3178ee535890cca3dc799460.scope"
      }
    ],
    "ips": [
      "10.131.0.33"
    ],
    "name": "clustermesh-apiserver-59c88b4f9-gc2f2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaae5b31d_e40a_42a7_a48f_e82d406bb726.slice/cri-containerd-f88b53163e8d4b537b4252a0d558315934f42953764aa936a5ff5f73d3d1fbd9.scope"
      }
    ],
    "ips": [
      "10.131.0.68"
    ],
    "name": "coredns-cc6ccd49c-wz6xh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10f52940_710c_4447_92ad_b57ee009b5b2.slice/cri-containerd-d0a8cda859f2ccf62104a40b6b26da6f6d0974d98c38e6df827fb9d408fa9918.scope"
      }
    ],
    "ips": [
      "10.131.0.189"
    ],
    "name": "coredns-cc6ccd49c-4wgch",
    "namespace": "kube-system"
  }
]

