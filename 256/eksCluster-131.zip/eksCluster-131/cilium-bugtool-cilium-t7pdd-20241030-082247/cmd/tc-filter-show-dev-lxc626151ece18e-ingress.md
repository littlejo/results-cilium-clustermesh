filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc626151ece18e direct-action not_in_hw id 609 tag 0f5888024419680d jited 
