USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         621  0.0  0.2 1240432 16844 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         666  0.0  0.0   6408  1632 ?        R    08:22   0:00  \_ ps auxfw
root         667  0.0  0.0   3720  1292 ?        R    08:22   0:00  \_ bash -c hostname
root           1  3.2  4.7 1606080 380472 ?      Ssl  07:55   0:53 cilium-agent --config-dir=/tmp/cilium/config-map
root         414  0.0  0.1 1229488 8552 ?        Sl   07:55   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
