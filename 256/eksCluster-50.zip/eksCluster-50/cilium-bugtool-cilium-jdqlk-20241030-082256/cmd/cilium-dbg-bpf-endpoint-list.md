IP ADDRESS         LOCAL ENDPOINT INFO
172.31.174.255:0   (localhost)                                                                                        
172.31.186.245:0   (localhost)                                                                                        
10.50.0.234:0      (localhost)                                                                                        
10.50.0.137:0      id=3732  sec_id=1673753 flags=0x0000 ifindex=14  mac=8E:D1:A5:BC:45:A7 nodemac=36:09:A1:4F:65:56   
10.50.0.55:0       id=2191  sec_id=1675267 flags=0x0000 ifindex=18  mac=52:87:94:D9:76:CE nodemac=06:9F:E6:E7:23:71   
10.50.0.218:0      id=1321  sec_id=4     flags=0x0000 ifindex=10  mac=8E:23:A2:01:A8:87 nodemac=8E:3F:B9:0C:05:A6     
10.50.0.222:0      id=881   sec_id=1673753 flags=0x0000 ifindex=12  mac=B6:EC:7C:75:49:19 nodemac=12:4A:E8:E0:BF:37   
