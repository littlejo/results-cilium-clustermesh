REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36485     2882054     677    bpf_overlay.c
Interface                 INGRESS     653761    134182451   1132   bpf_host.c
Success                   EGRESS      16105     1262068     1694   bpf_host.c
Success                   EGRESS      279501    34626968    1308   bpf_lxc.c
Success                   EGRESS      36340     2871934     53     encap.h
Success                   INGRESS     320174    36260377    86     l3.h
Success                   INGRESS     341205    37924409    235    trace.h
Unsupported L3 protocol   EGRESS      44        3292        1492   bpf_lxc.c
