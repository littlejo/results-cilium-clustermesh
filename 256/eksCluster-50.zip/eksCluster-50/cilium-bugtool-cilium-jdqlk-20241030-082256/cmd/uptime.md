 08:22:57 up 34 min,  0 users,  load average: 0.35, 0.22, 0.13
