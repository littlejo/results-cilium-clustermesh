[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc011bbb_3fa7_4d54_b306_92c00ccd1fe9.slice/cri-containerd-49b2f006117c50a3bfffb2c03f2cca1d14d45e6d77c5b2057621bca49257ad36.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc011bbb_3fa7_4d54_b306_92c00ccd1fe9.slice/cri-containerd-f76ddf21ca254b225f298ddcf01055d607c5cbe9d654a43d7841d5e0e1bfa5d0.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc011bbb_3fa7_4d54_b306_92c00ccd1fe9.slice/cri-containerd-1b28619d6424aabe4f3dcb8c37f42572e4564a5bf9d07bcf577a9187829179a7.scope"
      }
    ],
    "ips": [
      "10.50.0.55"
    ],
    "name": "clustermesh-apiserver-55dbc77b78-v9pjh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod145f45a9_9c3d_4d2a_9a0c_c8ad4fdcfbab.slice/cri-containerd-c349fce8f3542b49f195866be3ffa642d598b940158be7778ffc9af7c27ef8b8.scope"
      }
    ],
    "ips": [
      "10.50.0.222"
    ],
    "name": "coredns-cc6ccd49c-zr288",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33f1b0d1_5ede_44e3_b093_ee228e80fed2.slice/cri-containerd-20df2b1e7beb2ee2497e383b39373229687f355e79e69a0f167cc37304b1ad1c.scope"
      }
    ],
    "ips": [
      "10.50.0.137"
    ],
    "name": "coredns-cc6ccd49c-xvjkw",
    "namespace": "kube-system"
  }
]

