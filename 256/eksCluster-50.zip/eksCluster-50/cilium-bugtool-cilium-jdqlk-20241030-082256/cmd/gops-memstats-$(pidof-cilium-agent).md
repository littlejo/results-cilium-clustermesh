alloc: 207.90MB (218003072 bytes)
total-alloc: 2.31GB (2476764632 bytes)
sys: 336.84MB (353197428 bytes)
lookups: 0
mallocs: 64118666
frees: 62111092
heap-alloc: 207.90MB (218003072 bytes)
heap-sys: 259.61MB (272220160 bytes)
heap-idle: 26.31MB (27590656 bytes)
heap-in-use: 233.30MB (244629504 bytes)
heap-released: 88.00KB (90112 bytes)
heap-objects: 2007574
stack-in-use: 64.34MB (67469312 bytes)
stack-sys: 64.34MB (67469312 bytes)
stack-mspan-inuse: 3.41MB (3572000 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1007.12KB (1031289 bytes)
gc-sys: 6.07MB (6369664 bytes)
next-gc: when heap-alloc >= 225.00MB (235925128 bytes)
last-gc: 2024-10-30 08:22:58.396366061 +0000 UTC
gc-pause-total: 8.987685ms
gc-pause: 143946
gc-pause-end: 1730276578396366061
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.00040155312365162325
enable-gc: true
debug-gc: false
