key: 71 03 00 00  value: 11 02 00 00
key: 29 05 00 00  value: 2d 02 00 00
key: 8f 08 00 00  value: 6b 02 00 00
key: 94 0e 00 00  value: 28 02 00 00
Found 4 elements
