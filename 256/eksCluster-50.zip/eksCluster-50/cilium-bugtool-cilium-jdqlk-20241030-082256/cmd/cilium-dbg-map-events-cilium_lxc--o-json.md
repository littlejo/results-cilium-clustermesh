{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:27.030Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.174.255:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:27.030Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.186.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:27.030Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:31.672Z",
  "value": "id=1321  sec_id=4     flags=0x0000 ifindex=10  mac=8E:23:A2:01:A8:87 nodemac=8E:3F:B9:0C:05:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:31.674Z",
  "value": "id=881   sec_id=1673753 flags=0x0000 ifindex=12  mac=B6:EC:7C:75:49:19 nodemac=12:4A:E8:E0:BF:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:31.715Z",
  "value": "id=3732  sec_id=1673753 flags=0x0000 ifindex=14  mac=8E:D1:A5:BC:45:A7 nodemac=36:09:A1:4F:65:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:31.716Z",
  "value": "id=881   sec_id=1673753 flags=0x0000 ifindex=12  mac=B6:EC:7C:75:49:19 nodemac=12:4A:E8:E0:BF:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:31.742Z",
  "value": "id=1321  sec_id=4     flags=0x0000 ifindex=10  mac=8E:23:A2:01:A8:87 nodemac=8E:3F:B9:0C:05:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:28.404Z",
  "value": "id=881   sec_id=1673753 flags=0x0000 ifindex=12  mac=B6:EC:7C:75:49:19 nodemac=12:4A:E8:E0:BF:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:28.404Z",
  "value": "id=3732  sec_id=1673753 flags=0x0000 ifindex=14  mac=8E:D1:A5:BC:45:A7 nodemac=36:09:A1:4F:65:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:28.404Z",
  "value": "id=1321  sec_id=4     flags=0x0000 ifindex=10  mac=8E:23:A2:01:A8:87 nodemac=8E:3F:B9:0C:05:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:28.434Z",
  "value": "id=2050  sec_id=1675267 flags=0x0000 ifindex=16  mac=92:0C:59:05:53:69 nodemac=D6:77:BB:65:02:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:29.404Z",
  "value": "id=881   sec_id=1673753 flags=0x0000 ifindex=12  mac=B6:EC:7C:75:49:19 nodemac=12:4A:E8:E0:BF:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:29.405Z",
  "value": "id=3732  sec_id=1673753 flags=0x0000 ifindex=14  mac=8E:D1:A5:BC:45:A7 nodemac=36:09:A1:4F:65:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:29.405Z",
  "value": "id=1321  sec_id=4     flags=0x0000 ifindex=10  mac=8E:23:A2:01:A8:87 nodemac=8E:3F:B9:0C:05:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:29.405Z",
  "value": "id=2050  sec_id=1675267 flags=0x0000 ifindex=16  mac=92:0C:59:05:53:69 nodemac=D6:77:BB:65:02:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.207Z",
  "value": "id=2191  sec_id=1675267 flags=0x0000 ifindex=18  mac=52:87:94:D9:76:CE nodemac=06:9F:E6:E7:23:71"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.50.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.604Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.516Z",
  "value": "id=1321  sec_id=4     flags=0x0000 ifindex=10  mac=8E:23:A2:01:A8:87 nodemac=8E:3F:B9:0C:05:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.516Z",
  "value": "id=881   sec_id=1673753 flags=0x0000 ifindex=12  mac=B6:EC:7C:75:49:19 nodemac=12:4A:E8:E0:BF:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.517Z",
  "value": "id=3732  sec_id=1673753 flags=0x0000 ifindex=14  mac=8E:D1:A5:BC:45:A7 nodemac=36:09:A1:4F:65:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.517Z",
  "value": "id=2191  sec_id=1675267 flags=0x0000 ifindex=18  mac=52:87:94:D9:76:CE nodemac=06:9F:E6:E7:23:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.515Z",
  "value": "id=1321  sec_id=4     flags=0x0000 ifindex=10  mac=8E:23:A2:01:A8:87 nodemac=8E:3F:B9:0C:05:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.515Z",
  "value": "id=881   sec_id=1673753 flags=0x0000 ifindex=12  mac=B6:EC:7C:75:49:19 nodemac=12:4A:E8:E0:BF:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.515Z",
  "value": "id=3732  sec_id=1673753 flags=0x0000 ifindex=14  mac=8E:D1:A5:BC:45:A7 nodemac=36:09:A1:4F:65:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.516Z",
  "value": "id=2191  sec_id=1675267 flags=0x0000 ifindex=18  mac=52:87:94:D9:76:CE nodemac=06:9F:E6:E7:23:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.515Z",
  "value": "id=881   sec_id=1673753 flags=0x0000 ifindex=12  mac=B6:EC:7C:75:49:19 nodemac=12:4A:E8:E0:BF:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.515Z",
  "value": "id=1321  sec_id=4     flags=0x0000 ifindex=10  mac=8E:23:A2:01:A8:87 nodemac=8E:3F:B9:0C:05:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.515Z",
  "value": "id=3732  sec_id=1673753 flags=0x0000 ifindex=14  mac=8E:D1:A5:BC:45:A7 nodemac=36:09:A1:4F:65:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.516Z",
  "value": "id=2191  sec_id=1675267 flags=0x0000 ifindex=18  mac=52:87:94:D9:76:CE nodemac=06:9F:E6:E7:23:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.515Z",
  "value": "id=881   sec_id=1673753 flags=0x0000 ifindex=12  mac=B6:EC:7C:75:49:19 nodemac=12:4A:E8:E0:BF:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.515Z",
  "value": "id=3732  sec_id=1673753 flags=0x0000 ifindex=14  mac=8E:D1:A5:BC:45:A7 nodemac=36:09:A1:4F:65:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.516Z",
  "value": "id=2191  sec_id=1675267 flags=0x0000 ifindex=18  mac=52:87:94:D9:76:CE nodemac=06:9F:E6:E7:23:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.516Z",
  "value": "id=1321  sec_id=4     flags=0x0000 ifindex=10  mac=8E:23:A2:01:A8:87 nodemac=8E:3F:B9:0C:05:A6"
}

