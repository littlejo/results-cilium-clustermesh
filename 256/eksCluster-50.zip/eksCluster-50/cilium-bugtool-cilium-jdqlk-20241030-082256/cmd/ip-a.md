1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:8c:44:27:fd:bb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.186.245/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3312sec preferred_lft 3312sec
    inet6 fe80::48c:44ff:fe27:fdbb/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:b9:e2:db:25:75 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.174.255/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4b9:e2ff:fedb:2575/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:78:cf:d8:e1:4b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9c78:cfff:fed8:e14b/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:23:4f:19:e2:9b brd ff:ff:ff:ff:ff:ff
    inet 10.50.0.234/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a423:4fff:fe19:e29b/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 36:79:10:49:86:6b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3479:10ff:fe49:866b/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:3f:b9:0c:05:a6 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8c3f:b9ff:fe0c:5a6/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc70d80966f061@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:4a:e8:e0:bf:37 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::104a:e8ff:fee0:bf37/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcba0ccabe8651@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:09:a1:4f:65:56 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::3409:a1ff:fe4f:6556/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc72d7b54309d0@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:9f:e6:e7:23:71 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::49f:e6ff:fee7:2371/64 scope link 
       valid_lft forever preferred_lft forever
