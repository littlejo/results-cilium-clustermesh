35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:02+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:48:02+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:48:03+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:48:03+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:48:03+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:03+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:48:07+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:48:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:48:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:48:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
110: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
113: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
485: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 125
486: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
487: sched_cls  name tail_handle_ipv4  tag 99a700976bc69b79  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
490: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,101
	btf_id 131
491: sched_cls  name __send_drop_notify  tag 3c4afb8da6a4c9a9  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 132
492: sched_cls  name tail_handle_ipv4_from_host  tag f24b188141480cf2  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,101
	btf_id 133
493: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,101
	btf_id 134
494: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 135
495: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,103
	btf_id 137
496: sched_cls  name __send_drop_notify  tag 3c4afb8da6a4c9a9  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 138
497: sched_cls  name tail_handle_ipv4_from_host  tag f24b188141480cf2  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,103
	btf_id 139
499: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 141
502: sched_cls  name tail_handle_ipv4_from_host  tag f24b188141480cf2  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,106
	btf_id 145
506: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,106,75
	btf_id 149
507: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,106
	btf_id 150
508: sched_cls  name __send_drop_notify  tag 3c4afb8da6a4c9a9  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 151
509: sched_cls  name tail_handle_ipv4_from_host  tag f24b188141480cf2  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,108
	btf_id 153
513: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,108,75
	btf_id 157
514: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,108
	btf_id 158
515: sched_cls  name __send_drop_notify  tag 3c4afb8da6a4c9a9  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 159
519: sched_cls  name tail_ipv4_ct_ingress  tag d360dba76b56af22  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 163
522: sched_cls  name tail_handle_arp  tag b3cbc21fcb8138c7  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 168
523: sched_cls  name tail_handle_ipv4  tag 085abac55f98c924  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 170
529: sched_cls  name handle_policy  tag fc9a94f3ac44bebc  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 171
530: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 177
532: sched_cls  name tail_ipv4_to_endpoint  tag e43ec79497129207  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 178
533: sched_cls  name cil_from_container  tag 55078a5b69b6b323  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 180
534: sched_cls  name tail_ipv4_ct_egress  tag 9f5c3e0281d67d29  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 181
536: sched_cls  name __send_drop_notify  tag 5a1113edea0c545b  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 182
537: sched_cls  name tail_handle_ipv4_cont  tag 55aedae2b916db15  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 183
539: sched_cls  name tail_handle_arp  tag 1b9bff09429e1f1b  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 188
540: sched_cls  name __send_drop_notify  tag cb467bc4e20c0206  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 189
541: sched_cls  name tail_ipv4_to_endpoint  tag 85c71d679dcf980a  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 186
542: sched_cls  name cil_from_container  tag e61d7055ffae114a  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 117,76
	btf_id 190
543: sched_cls  name cil_from_container  tag 70b9ff292ae14dc9  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 191
544: sched_cls  name tail_handle_ipv4  tag c5d4aedadf2cf66d  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 192
545: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 194
546: sched_cls  name tail_handle_ipv4_cont  tag d904cb477a0837ca  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,118,41,100,82,83,39,76,74,77,117,40,37,38,81
	btf_id 193
547: sched_cls  name tail_ipv4_ct_ingress  tag 3e709254ae0de9c4  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 196
548: sched_cls  name tail_ipv4_ct_egress  tag 9f5c3e0281d67d29  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 195
549: sched_cls  name tail_handle_ipv4_cont  tag d1c6456537603fae  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 198
550: sched_cls  name tail_ipv4_ct_ingress  tag 7643c8040db4cd26  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 199
551: sched_cls  name tail_handle_ipv4  tag a92dbaa3dd37e37a  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 197
552: sched_cls  name handle_policy  tag c921e8fe6f464c58  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 200
553: sched_cls  name tail_handle_arp  tag 726291336ba9e233  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 202
554: sched_cls  name __send_drop_notify  tag 44724efbe4c9a501  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
555: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 201
556: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 204
557: sched_cls  name handle_policy  tag aed26aa73ba2a932  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,117,82,83,118,41,80,100,39,84,75,40,37,38
	btf_id 205
558: sched_cls  name tail_ipv4_to_endpoint  tag e0b5fa99097d5706  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,118,41,82,83,80,100,39,117,40,37,38
	btf_id 206
560: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
563: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
564: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
567: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
568: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
571: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
572: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
575: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
615: sched_cls  name tail_handle_ipv4_cont  tag 738e583e46dce397  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,135,41,133,82,83,39,76,74,77,134,40,37,38,81
	btf_id 221
616: sched_cls  name tail_handle_ipv4  tag c6a2efe92fe6d8b6  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,134
	btf_id 222
617: sched_cls  name cil_from_container  tag 175dc8903b36c286  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 134,76
	btf_id 223
619: sched_cls  name handle_policy  tag 33526e2c64beb7c3  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,134,82,83,135,41,80,133,39,84,75,40,37,38
	btf_id 225
620: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,134
	btf_id 226
621: sched_cls  name tail_ipv4_to_endpoint  tag 41927b99d316e135  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,135,41,82,83,80,133,39,134,40,37,38
	btf_id 227
622: sched_cls  name __send_drop_notify  tag 6676f23fa42b88b5  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 228
623: sched_cls  name tail_ipv4_ct_egress  tag dccea74cf19680cb  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 229
624: sched_cls  name tail_handle_arp  tag bb500ca1062ba708  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,134
	btf_id 230
625: sched_cls  name tail_ipv4_ct_ingress  tag 9726dea2eb269c54  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 231
626: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
629: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
642: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
645: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
646: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
649: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
