top - 08:22:58 up 34 min,  0 users,  load average: 0.35, 0.22, 0.13
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 44.8 us, 41.4 sy,  0.0 ni, 13.8 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4475.0 free,   1193.1 used,   2146.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6436.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 380812  78532 S  60.0   4.8   0:53.67 cilium-+
    621 root      20   0 1240432  16844  11548 S   6.7   0.2   0:00.03 cilium-+
    414 root      20   0 1229488   8552   4156 S   0.0   0.1   0:01.18 cilium-+
    676 root      20   0 1229000   4040   3392 S   0.0   0.1   0:00.00 gops
    683 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    685 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    693 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    699 root      20   0 1228744   4032   3392 S   0.0   0.1   0:00.00 gops
