CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33f1b0d1_5ede_44e3_b093_ee228e80fed2.slice/cri-containerd-20df2b1e7beb2ee2497e383b39373229687f355e79e69a0f167cc37304b1ad1c.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33f1b0d1_5ede_44e3_b093_ee228e80fed2.slice/cri-containerd-7e348473dd74911b9240834539a447442ffc4003ae395e62eaeaf0973e34c898.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14719a1f_4b92_496f_ad7e_e925d81e52ea.slice/cri-containerd-43a9d7c42516617d7e0114c55405585e50746e48309bf252e909653939a0b882.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14719a1f_4b92_496f_ad7e_e925d81e52ea.slice/cri-containerd-64a945a7c3a3af75a3abfcc26895eb3f95bfe1c714b23613b81f65843849561b.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod145f45a9_9c3d_4d2a_9a0c_c8ad4fdcfbab.slice/cri-containerd-333e201b8c7dfef982c02a6c3e6682c4a14702a6be23c765d4b98b92dd8ac0c4.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod145f45a9_9c3d_4d2a_9a0c_c8ad4fdcfbab.slice/cri-containerd-c349fce8f3542b49f195866be3ffa642d598b940158be7778ffc9af7c27ef8b8.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod757a6546_49f9_46e1_a954_7568a8ea550b.slice/cri-containerd-5d347c43ca8fa148b817cdacdad3464a8dc536629a3cbe4cc8f4d8318bd36b34.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod757a6546_49f9_46e1_a954_7568a8ea550b.slice/cri-containerd-5392687281ce47a4f2c0a1a11f20aaa0b012990fe29e6b0bc86730baa78d9dd5.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd2f2f293_f7d3_4cec_ae15_8a56d3dc0412.slice/cri-containerd-a898f6b99d605c8d5c88421f6e8f943e5e9dfa4feda6db919719f493f9428232.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd2f2f293_f7d3_4cec_ae15_8a56d3dc0412.slice/cri-containerd-837137a1fb58c174e3d642d527a0452e53a8e7752a617b8fb1e4fcf88311fa9f.scope
    113      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaef17328_679d_4f16_9031_b333c6357896.slice/cri-containerd-041edfb9c5196d9eeabf472e2fd79d1410d2e0bba739296721d2bc925f77bb07.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaef17328_679d_4f16_9031_b333c6357896.slice/cri-containerd-d638212193886fa4e5e2f962f65666b6e9714341e75ff84765ca2d68702a12a7.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc011bbb_3fa7_4d54_b306_92c00ccd1fe9.slice/cri-containerd-49b2f006117c50a3bfffb2c03f2cca1d14d45e6d77c5b2057621bca49257ad36.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc011bbb_3fa7_4d54_b306_92c00ccd1fe9.slice/cri-containerd-1b28619d6424aabe4f3dcb8c37f42572e4564a5bf9d07bcf577a9187829179a7.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc011bbb_3fa7_4d54_b306_92c00ccd1fe9.slice/cri-containerd-f76ddf21ca254b225f298ddcf01055d607c5cbe9d654a43d7841d5e0e1bfa5d0.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc011bbb_3fa7_4d54_b306_92c00ccd1fe9.slice/cri-containerd-07b024ae53913a764953d094909bf3feca25dbe84d0617b0808142e566de654c.scope
    629      cgroup_device   multi                                          
