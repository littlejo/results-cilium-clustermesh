ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.189.128:443 (active)    
                                         2 => 172.31.246.231:443 (active)    
2    10.100.14.230:443    ClusterIP      1 => 172.31.186.245:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.50.0.137:53 (active)        
                                         2 => 10.50.0.222:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.50.0.137:9153 (active)      
                                         2 => 10.50.0.222:9153 (active)      
5    10.100.154.54:2379   ClusterIP      1 => 10.50.0.55:2379 (active)       
