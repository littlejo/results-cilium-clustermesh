Endpoint ID: 707
Path: /sys/fs/bpf/tc/globals/cilium_policy_00707

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 881
Path: /sys/fs/bpf/tc/globals/cilium_policy_00881

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    159669   1830      0        
Allow    Egress      0          ANY          NONE         disabled    20753    231       0        


Endpoint ID: 1321
Path: /sys/fs/bpf/tc/globals/cilium_policy_01321

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1665388   21050     0        
Allow    Ingress     1          ANY          NONE         disabled    24640     288       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2191
Path: /sys/fs/bpf/tc/globals/cilium_policy_02191

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11669380   117038    0        
Allow    Ingress     1          ANY          NONE         disabled    10142806   106884    0        
Allow    Egress      0          ANY          NONE         disabled    13909379   136535    0        


Endpoint ID: 3732
Path: /sys/fs/bpf/tc/globals/cilium_policy_03732

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    160725   1846      0        
Allow    Egress      0          ANY          NONE         disabled    20176    224       0        


