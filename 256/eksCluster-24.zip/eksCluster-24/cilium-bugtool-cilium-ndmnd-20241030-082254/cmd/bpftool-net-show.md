xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 553
ens6(5) clsact/ingress cil_from_netdev-ens6 id 559
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 542
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 537
cilium_host(7) clsact/egress cil_from_host-cilium_host id 536
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 574
lxcf6a5ce076bce(12) clsact/ingress cil_from_container-lxcf6a5ce076bce id 532
lxc179a9cd02868(14) clsact/ingress cil_from_container-lxc179a9cd02868 id 563
lxce6cd25553044(18) clsact/ingress cil_from_container-lxce6cd25553044 id 644

flow_dissector:

netfilter:

