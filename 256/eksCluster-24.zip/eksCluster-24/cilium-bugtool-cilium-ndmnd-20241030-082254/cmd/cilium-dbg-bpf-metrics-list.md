REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36767     2904141     677    bpf_overlay.c
Interface                 INGRESS     666469    136413033   1132   bpf_host.c
Success                   EGRESS      16566     1303619     1694   bpf_host.c
Success                   EGRESS      289528    35405244    1308   bpf_lxc.c
Success                   EGRESS      37087     2932746     53     encap.h
Success                   INGRESS     329219    37536658    86     l3.h
Success                   INGRESS     350071    39181226    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
