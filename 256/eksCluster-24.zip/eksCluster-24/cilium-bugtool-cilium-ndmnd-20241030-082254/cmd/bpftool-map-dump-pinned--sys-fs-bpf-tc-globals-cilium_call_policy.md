key: 39 00 00 00  value: 86 02 00 00
key: f6 04 00 00  value: 11 02 00 00
key: 10 06 00 00  value: 38 02 00 00
key: d2 07 00 00  value: 39 02 00 00
Found 4 elements
