[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04455c9c_3263_4b0d_b59b_7ca072cdab63.slice/cri-containerd-f36c54cf38968a26f93793b0a63da9808816a456a6c0c79dd37b3adf1aa83fe1.scope"
      }
    ],
    "ips": [
      "10.24.0.81"
    ],
    "name": "coredns-cc6ccd49c-b46z5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode31ac476_6f9f_4b94_a4ee_e5f348e70071.slice/cri-containerd-6fbfb2899f252166d820852a566498ee5ddbfbd783193222e167cf6ee6235fbc.scope"
      }
    ],
    "ips": [
      "10.24.0.169"
    ],
    "name": "coredns-cc6ccd49c-jcfwk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod605a1239_700d_414e_8754_85f275a2eb66.slice/cri-containerd-aa7ee137401fd9c310a3a4ed8d5e8b62f52104c03703e331483aed9c7297c465.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod605a1239_700d_414e_8754_85f275a2eb66.slice/cri-containerd-61ffbd784813dcaea9e843e30e897653a189145173703a50275f1faee50ef0d8.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod605a1239_700d_414e_8754_85f275a2eb66.slice/cri-containerd-0802100d94c52dbd9d19ceb13caa5b2a0ff5cb63432aee6b6fa8988aa5350dea.scope"
      }
    ],
    "ips": [
      "10.24.0.17"
    ],
    "name": "clustermesh-apiserver-6985544b8d-jvt6l",
    "namespace": "kube-system"
  }
]

