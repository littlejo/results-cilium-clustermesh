ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.162.71:443 (active)     
                                         2 => 172.31.222.109:443 (active)    
2    10.100.89.43:443     ClusterIP      1 => 172.31.171.219:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.24.0.169:53 (active)        
                                         2 => 10.24.0.81:53 (active)         
4    10.100.0.10:9153     ClusterIP      1 => 10.24.0.169:9153 (active)      
                                         2 => 10.24.0.81:9153 (active)       
5    10.100.215.37:2379   ClusterIP      1 => 10.24.0.17:2379 (active)       
