Endpoint ID: 57
Path: /sys/fs/bpf/tc/globals/cilium_policy_00057

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11491298   116064    0        
Allow    Ingress     1          ANY          NONE         disabled    10636845   112301    0        
Allow    Egress      0          ANY          NONE         disabled    15222531   148529    0        


Endpoint ID: 1270
Path: /sys/fs/bpf/tc/globals/cilium_policy_01270

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174546   2002      0        
Allow    Egress      0          ANY          NONE         disabled    20205    225       0        


Endpoint ID: 1552
Path: /sys/fs/bpf/tc/globals/cilium_policy_01552

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174185   2002      0        
Allow    Egress      0          ANY          NONE         disabled    20914    236       0        


Endpoint ID: 2002
Path: /sys/fs/bpf/tc/globals/cilium_policy_02002

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1649668   20914     0        
Allow    Ingress     1          ANY          NONE         disabled    26166     307       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3322
Path: /sys/fs/bpf/tc/globals/cilium_policy_03322

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


