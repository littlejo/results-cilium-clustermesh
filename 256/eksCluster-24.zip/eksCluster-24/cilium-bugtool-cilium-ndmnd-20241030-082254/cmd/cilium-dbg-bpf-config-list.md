KEY             VALUE
AgentLiveness   2272513963703
UTimeOffset     3379442058593750
