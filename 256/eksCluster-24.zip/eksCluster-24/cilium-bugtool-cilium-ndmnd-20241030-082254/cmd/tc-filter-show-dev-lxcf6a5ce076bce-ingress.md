filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf6a5ce076bce direct-action not_in_hw id 532 tag 48c2977d90fa614d jited 
