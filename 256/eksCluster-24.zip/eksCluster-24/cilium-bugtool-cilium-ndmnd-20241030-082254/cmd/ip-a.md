1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ff:63:a3:4d:7f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.171.219/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3173sec preferred_lft 3173sec
    inet6 fe80::4ff:63ff:fea3:4d7f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:1b:81:01:6f:f9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.144.191/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::41b:81ff:fe01:6ff9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:27:ec:ed:8b:ec brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2427:ecff:feed:8bec/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:06:38:1c:6c:58 brd ff:ff:ff:ff:ff:ff
    inet 10.24.0.197/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::7406:38ff:fe1c:6c58/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 4a:ff:6d:35:75:35 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::48ff:6dff:fe35:7535/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:88:5a:23:d9:0c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::2088:5aff:fe23:d90c/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf6a5ce076bce@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:ee:77:dd:8d:28 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::ee:77ff:fedd:8d28/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc179a9cd02868@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:64:ee:ec:a1:65 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::fc64:eeff:feec:a165/64 scope link 
       valid_lft forever preferred_lft forever
18: lxce6cd25553044@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:23:45:c0:7b:0d brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::3823:45ff:fec0:7b0d/64 scope link 
       valid_lft forever preferred_lft forever
