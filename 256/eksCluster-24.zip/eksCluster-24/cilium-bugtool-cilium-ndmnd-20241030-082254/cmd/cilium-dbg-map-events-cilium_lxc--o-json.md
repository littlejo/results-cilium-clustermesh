{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:47.955Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.144.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:47.955Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.171.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:47.955Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:52.751Z",
  "value": "id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=EA:07:BE:AB:7B:41 nodemac=22:88:5A:23:D9:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:52.757Z",
  "value": "id=1270  sec_id=834966 flags=0x0000 ifindex=12  mac=BA:9F:5A:AC:E2:F9 nodemac=02:EE:77:DD:8D:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:52.822Z",
  "value": "id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=EA:07:BE:AB:7B:41 nodemac=22:88:5A:23:D9:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:52.822Z",
  "value": "id=1552  sec_id=834966 flags=0x0000 ifindex=14  mac=4A:00:8E:38:6B:01 nodemac=FE:64:EE:EC:A1:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:07.846Z",
  "value": "id=1270  sec_id=834966 flags=0x0000 ifindex=12  mac=BA:9F:5A:AC:E2:F9 nodemac=02:EE:77:DD:8D:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:07.847Z",
  "value": "id=1552  sec_id=834966 flags=0x0000 ifindex=14  mac=4A:00:8E:38:6B:01 nodemac=FE:64:EE:EC:A1:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:07.848Z",
  "value": "id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=EA:07:BE:AB:7B:41 nodemac=22:88:5A:23:D9:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:07.877Z",
  "value": "id=1401  sec_id=829207 flags=0x0000 ifindex=16  mac=E6:F9:8B:13:07:D4 nodemac=7A:CD:13:BF:79:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:08.846Z",
  "value": "id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=EA:07:BE:AB:7B:41 nodemac=22:88:5A:23:D9:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:08.846Z",
  "value": "id=1401  sec_id=829207 flags=0x0000 ifindex=16  mac=E6:F9:8B:13:07:D4 nodemac=7A:CD:13:BF:79:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:08.846Z",
  "value": "id=1270  sec_id=834966 flags=0x0000 ifindex=12  mac=BA:9F:5A:AC:E2:F9 nodemac=02:EE:77:DD:8D:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:08.846Z",
  "value": "id=1552  sec_id=834966 flags=0x0000 ifindex=14  mac=4A:00:8E:38:6B:01 nodemac=FE:64:EE:EC:A1:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:30.098Z",
  "value": "id=57    sec_id=829207 flags=0x0000 ifindex=18  mac=F6:CF:48:D8:07:2B nodemac=3A:23:45:C0:7B:0D"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.24.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.433Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.338Z",
  "value": "id=57    sec_id=829207 flags=0x0000 ifindex=18  mac=F6:CF:48:D8:07:2B nodemac=3A:23:45:C0:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.339Z",
  "value": "id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=EA:07:BE:AB:7B:41 nodemac=22:88:5A:23:D9:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.339Z",
  "value": "id=1270  sec_id=834966 flags=0x0000 ifindex=12  mac=BA:9F:5A:AC:E2:F9 nodemac=02:EE:77:DD:8D:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.339Z",
  "value": "id=1552  sec_id=834966 flags=0x0000 ifindex=14  mac=4A:00:8E:38:6B:01 nodemac=FE:64:EE:EC:A1:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.345Z",
  "value": "id=1552  sec_id=834966 flags=0x0000 ifindex=14  mac=4A:00:8E:38:6B:01 nodemac=FE:64:EE:EC:A1:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.348Z",
  "value": "id=57    sec_id=829207 flags=0x0000 ifindex=18  mac=F6:CF:48:D8:07:2B nodemac=3A:23:45:C0:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.348Z",
  "value": "id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=EA:07:BE:AB:7B:41 nodemac=22:88:5A:23:D9:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.349Z",
  "value": "id=1270  sec_id=834966 flags=0x0000 ifindex=12  mac=BA:9F:5A:AC:E2:F9 nodemac=02:EE:77:DD:8D:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.338Z",
  "value": "id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=EA:07:BE:AB:7B:41 nodemac=22:88:5A:23:D9:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.338Z",
  "value": "id=1270  sec_id=834966 flags=0x0000 ifindex=12  mac=BA:9F:5A:AC:E2:F9 nodemac=02:EE:77:DD:8D:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.339Z",
  "value": "id=1552  sec_id=834966 flags=0x0000 ifindex=14  mac=4A:00:8E:38:6B:01 nodemac=FE:64:EE:EC:A1:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.339Z",
  "value": "id=57    sec_id=829207 flags=0x0000 ifindex=18  mac=F6:CF:48:D8:07:2B nodemac=3A:23:45:C0:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.339Z",
  "value": "id=57    sec_id=829207 flags=0x0000 ifindex=18  mac=F6:CF:48:D8:07:2B nodemac=3A:23:45:C0:7B:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.339Z",
  "value": "id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=EA:07:BE:AB:7B:41 nodemac=22:88:5A:23:D9:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.340Z",
  "value": "id=1270  sec_id=834966 flags=0x0000 ifindex=12  mac=BA:9F:5A:AC:E2:F9 nodemac=02:EE:77:DD:8D:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.340Z",
  "value": "id=1552  sec_id=834966 flags=0x0000 ifindex=14  mac=4A:00:8E:38:6B:01 nodemac=FE:64:EE:EC:A1:65"
}

