alloc: 119.62MB (125426136 bytes)
total-alloc: 2.37GB (2542430088 bytes)
sys: 316.77MB (332157284 bytes)
lookups: 0
mallocs: 65299190
frees: 64332568
heap-alloc: 119.62MB (125426136 bytes)
heap-sys: 239.64MB (251281408 bytes)
heap-idle: 75.12MB (78774272 bytes)
heap-in-use: 164.52MB (172507136 bytes)
heap-released: 1.27MB (1327104 bytes)
heap-objects: 966622
stack-in-use: 64.31MB (67436544 bytes)
stack-sys: 64.31MB (67436544 bytes)
stack-mspan-inuse: 2.73MB (2863680 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 999.17KB (1023145 bytes)
gc-sys: 6.02MB (6317520 bytes)
next-gc: when heap-alloc >= 212.55MB (222873496 bytes)
last-gc: 2024-10-30 08:23:14.620189191 +0000 UTC
gc-pause-total: 10.41956ms
gc-pause: 107949
gc-pause-end: 1730276594620189191
num-gc: 87
num-forced-gc: 0
gc-cpu-fraction: 0.0003900681445061763
enable-gc: true
debug-gc: false
