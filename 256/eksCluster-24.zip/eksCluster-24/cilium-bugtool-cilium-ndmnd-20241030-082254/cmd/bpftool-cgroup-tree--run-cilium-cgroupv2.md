CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1fd0b19b_c573_41c4_9283_53c2d3860485.slice/cri-containerd-36fa7c7d29df2d153fecc622f5a9f45719a8251ad43a4f43a7ce721f221187a2.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1fd0b19b_c573_41c4_9283_53c2d3860485.slice/cri-containerd-226b605941a1a1fb99ef3e1788dfd7ff6872ed1b9355ada5ba9510bb590cb0e4.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod42096dcd_50b5_4896_bad2_e64df008ae9e.slice/cri-containerd-0099d0c14766c346949cecc70fcd27ec0fb877f68abdb9e094e755f2df297c60.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod42096dcd_50b5_4896_bad2_e64df008ae9e.slice/cri-containerd-e5e7b91516ad444ccc856762ca58476947e39b770a76d1068be1c14399545ea7.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04455c9c_3263_4b0d_b59b_7ca072cdab63.slice/cri-containerd-f36c54cf38968a26f93793b0a63da9808816a456a6c0c79dd37b3adf1aa83fe1.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04455c9c_3263_4b0d_b59b_7ca072cdab63.slice/cri-containerd-56d3004c51c2b3651fa878159ee1d3bee7d449915e866d073408924d5942d350.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode31ac476_6f9f_4b94_a4ee_e5f348e70071.slice/cri-containerd-6fbfb2899f252166d820852a566498ee5ddbfbd783193222e167cf6ee6235fbc.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode31ac476_6f9f_4b94_a4ee_e5f348e70071.slice/cri-containerd-01fe284b7c6411f154844af2a76f1e4aad2c06e1341a77a9f9508a72fce3df1f.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7ed9f7af_6631_4fd6_8fc1_089ed4f8e30c.slice/cri-containerd-8f149d07881d4cfe39696fddf9cdd92fa65e77a9ab36aee97bcea6c36c05164e.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7ed9f7af_6631_4fd6_8fc1_089ed4f8e30c.slice/cri-containerd-f808e8731d4b8cc9d6900088040d648e27f9b6eac3c7d7b4396c6f85cee72d09.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod605a1239_700d_414e_8754_85f275a2eb66.slice/cri-containerd-3c6b1074fcf7371228ee0578ed7e49b706af4d2e54172f0d8a2736fcd52373d9.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod605a1239_700d_414e_8754_85f275a2eb66.slice/cri-containerd-61ffbd784813dcaea9e843e30e897653a189145173703a50275f1faee50ef0d8.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod605a1239_700d_414e_8754_85f275a2eb66.slice/cri-containerd-aa7ee137401fd9c310a3a4ed8d5e8b62f52104c03703e331483aed9c7297c465.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod605a1239_700d_414e_8754_85f275a2eb66.slice/cri-containerd-0802100d94c52dbd9d19ceb13caa5b2a0ff5cb63432aee6b6fa8988aa5350dea.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8f45cbe5_3fea_4568_9c91_409d191d52b5.slice/cri-containerd-1cdd16263d3e06f9fd447c59b99a1d3687440815c695cd41885842875a9ed496.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8f45cbe5_3fea_4568_9c91_409d191d52b5.slice/cri-containerd-6aa363ae2c06ea0b32e080b616f8c3944c08870dab340bee8d4b2c103489b948.scope
    103      cgroup_device   multi                                          
