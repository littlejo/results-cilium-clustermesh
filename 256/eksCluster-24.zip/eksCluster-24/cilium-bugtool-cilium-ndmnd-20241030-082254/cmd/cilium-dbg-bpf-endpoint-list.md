IP ADDRESS         LOCAL ENDPOINT INFO
10.24.0.197:0      (localhost)                                                                                       
172.31.144.191:0   (localhost)                                                                                       
10.24.0.1:0        id=2002  sec_id=4     flags=0x0000 ifindex=10  mac=EA:07:BE:AB:7B:41 nodemac=22:88:5A:23:D9:0C    
10.24.0.17:0       id=57    sec_id=829207 flags=0x0000 ifindex=18  mac=F6:CF:48:D8:07:2B nodemac=3A:23:45:C0:7B:0D   
172.31.171.219:0   (localhost)                                                                                       
10.24.0.81:0       id=1552  sec_id=834966 flags=0x0000 ifindex=14  mac=4A:00:8E:38:6B:01 nodemac=FE:64:EE:EC:A1:65   
10.24.0.169:0      id=1270  sec_id=834966 flags=0x0000 ifindex=12  mac=BA:9F:5A:AC:E2:F9 nodemac=02:EE:77:DD:8D:28   
