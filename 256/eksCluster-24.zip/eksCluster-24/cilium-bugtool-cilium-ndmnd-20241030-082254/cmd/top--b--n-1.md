top - 08:22:56 up 37 min,  0 users,  load average: 0.33, 0.31, 0.24
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 33.3 us, 40.0 sy,  0.0 ni, 20.0 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   7814.2 total,   4503.9 free,   1194.1 used,   2116.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6435.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    717 root      20   0 1244340  21596  13952 S  26.7   0.3   0:00.04 hubble
      1 root      20   0 1606080 387364  78404 S  13.3   4.8   1:00.40 cilium-+
    396 root      20   0 1229488   6860   2868 S   0.0   0.1   0:01.17 cilium-+
    630 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    637 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    654 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    667 root      20   0 1240432  15644  10896 S   0.0   0.2   0:00.03 cilium-+
    694 root      20   0    6576   2408   2084 R   0.0   0.0   0:00.00 top
    701 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    721 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
