REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38069     3016265     677    bpf_overlay.c
Interface                 INGRESS     670067    135896833   1132   bpf_host.c
Success                   EGRESS      17791     1404111     1694   bpf_host.c
Success                   EGRESS      283497    35188635    1308   bpf_lxc.c
Success                   EGRESS      38967     3083474     53     encap.h
Success                   INGRESS     329423    37116093    86     l3.h
Success                   INGRESS     350352    38772293    235    trace.h
Unsupported L3 protocol   EGRESS      42        3112        1492   bpf_lxc.c
