alloc: 191.96MB (201285960 bytes)
total-alloc: 2.39GB (2564586832 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 65565773
frees: 63358025
heap-alloc: 191.96MB (201285960 bytes)
heap-sys: 246.92MB (258916352 bytes)
heap-idle: 32.02MB (33570816 bytes)
heap-in-use: 214.91MB (225345536 bytes)
heap-released: 3.82MB (4005888 bytes)
heap-objects: 2207748
stack-in-use: 65.03MB (68190208 bytes)
stack-sys: 65.03MB (68190208 bytes)
stack-mspan-inuse: 3.63MB (3805920 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.20MB (1263465 bytes)
gc-sys: 6.04MB (6331976 bytes)
next-gc: when heap-alloc >= 223.51MB (234366232 bytes)
last-gc: 2024-10-30 08:22:57.500411473 +0000 UTC
gc-pause-total: 25.246741ms
gc-pause: 12659921
gc-pause-end: 1730276577500411473
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00042446289584726255
enable-gc: true
debug-gc: false
