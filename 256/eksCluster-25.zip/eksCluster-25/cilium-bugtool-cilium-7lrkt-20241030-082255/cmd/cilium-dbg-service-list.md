ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.178.249:443 (active)   
                                        2 => 172.31.239.37:443 (active)    
2    10.100.87.184:443   ClusterIP      1 => 172.31.210.57:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.25.0.182:53 (active)       
                                        2 => 10.25.0.160:53 (active)       
4    10.100.0.10:9153    ClusterIP      1 => 10.25.0.182:9153 (active)     
                                        2 => 10.25.0.160:9153 (active)     
5    10.100.70.77:2379   ClusterIP      1 => 10.25.0.33:2379 (active)      
