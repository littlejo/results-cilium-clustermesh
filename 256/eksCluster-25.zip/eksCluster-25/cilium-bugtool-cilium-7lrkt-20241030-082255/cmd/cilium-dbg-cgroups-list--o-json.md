[
  {
    "containers": [
      {
        "cgroup-id": 7751,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3ac793e_8708_4d3b_8d99_06f257f0e398.slice/cri-containerd-33e808166b34b0ee779ca80d28ef4eccb2362e973dc5c9f4e4c1682eefd71cc8.scope"
      }
    ],
    "ips": [
      "10.25.0.160"
    ],
    "name": "coredns-cc6ccd49c-fshgb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7835,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1d82f2d8_a654_40ca_804f_334ec6ba708a.slice/cri-containerd-f853a2ab0008ce68a26b9af24def6d03ffcd565ca3cae36800e04f269a3575c9.scope"
      }
    ],
    "ips": [
      "10.25.0.182"
    ],
    "name": "coredns-cc6ccd49c-qsdnf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8131c39_38f7_420a_89d8_8b46495e9b46.slice/cri-containerd-247c95058e597f529a17d7d6de923cea6e9ccdbdf09b8dd39e2c4ca91e10606c.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8131c39_38f7_420a_89d8_8b46495e9b46.slice/cri-containerd-d1a5729da43da3997496c26e5af2da72e7bda1b6396bfdb6dcf6e66ff5308555.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8131c39_38f7_420a_89d8_8b46495e9b46.slice/cri-containerd-49d6b895a36eab2f30353caf40ab46668386fb8127e0941863ee51ee760ba866.scope"
      }
    ],
    "ips": [
      "10.25.0.33"
    ],
    "name": "clustermesh-apiserver-64b469d48c-4x2rn",
    "namespace": "kube-system"
  }
]

