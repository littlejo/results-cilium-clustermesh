CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8bc08d26_70c4_4b1f_9e7e_689782382d22.slice/cri-containerd-d2870bbc251733ccb958c1e3c18235bcaeaccac5f28bc82fc29471d5b69a7001.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8bc08d26_70c4_4b1f_9e7e_689782382d22.slice/cri-containerd-fde8957a341a071efff877cf2d7d995cadf0c7ea5ae37726e9d6d7ca11c58e16.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1d82f2d8_a654_40ca_804f_334ec6ba708a.slice/cri-containerd-90776004c74fc08a183db4a8a2d52d70052337580fa367d4e3fce099feccc177.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1d82f2d8_a654_40ca_804f_334ec6ba708a.slice/cri-containerd-f853a2ab0008ce68a26b9af24def6d03ffcd565ca3cae36800e04f269a3575c9.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5a80fbc0_8c75_4a31_9364_9fce7998260f.slice/cri-containerd-6f8b4faf6f5f48cf8b87569974b36b378c5f43e59b0f6e5c623e828e68f3dd16.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5a80fbc0_8c75_4a31_9364_9fce7998260f.slice/cri-containerd-de2667f63c825f1fc69d60940b661f5a69c46e9c61120d4f0e8ab935385f88d7.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3ac793e_8708_4d3b_8d99_06f257f0e398.slice/cri-containerd-33e808166b34b0ee779ca80d28ef4eccb2362e973dc5c9f4e4c1682eefd71cc8.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3ac793e_8708_4d3b_8d99_06f257f0e398.slice/cri-containerd-b19e608a76aa04bd3de425770b44b08531824ceec09859117f9a645229183ee8.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a1d8ca9_2651_442a_983a_6f66f5b9baac.slice/cri-containerd-655b4a30b679310e755db79f3da07257fc6ef7f9f3d6d416e0555f3cfc92a285.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a1d8ca9_2651_442a_983a_6f66f5b9baac.slice/cri-containerd-f4a68bdf9cee46b0587fe96168753569c32eeecda9bb05b0aa3d91855da35702.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8131c39_38f7_420a_89d8_8b46495e9b46.slice/cri-containerd-49d6b895a36eab2f30353caf40ab46668386fb8127e0941863ee51ee760ba866.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8131c39_38f7_420a_89d8_8b46495e9b46.slice/cri-containerd-ce43aa3a57460cc418614a4db690470d884479fe22983dd0fb6617b5f2bddd24.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8131c39_38f7_420a_89d8_8b46495e9b46.slice/cri-containerd-d1a5729da43da3997496c26e5af2da72e7bda1b6396bfdb6dcf6e66ff5308555.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8131c39_38f7_420a_89d8_8b46495e9b46.slice/cri-containerd-247c95058e597f529a17d7d6de923cea6e9ccdbdf09b8dd39e2c4ca91e10606c.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1550b806_869a_4d7e_8617_d3781f502bd6.slice/cri-containerd-4ebfd520904e4a37d79e118b1c37cb0664fb17b8329bb2a65c6d1dc4bf162f55.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1550b806_869a_4d7e_8617_d3781f502bd6.slice/cri-containerd-b76609ca7d402373dfb441d7849386e5e17c93bfce01d99213a1bf8da44ba5b9.scope
    103      cgroup_device   multi                                          
