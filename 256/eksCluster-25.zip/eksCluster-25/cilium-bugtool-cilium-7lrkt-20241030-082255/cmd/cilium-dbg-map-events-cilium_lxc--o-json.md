{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:19.038Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.210.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:19.038Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.234.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:19.038Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:23.757Z",
  "value": "id=126   sec_id=4     flags=0x0000 ifindex=10  mac=3A:2F:17:AD:DD:48 nodemac=86:EF:A9:97:03:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:23.769Z",
  "value": "id=654   sec_id=856932 flags=0x0000 ifindex=12  mac=EA:B8:97:8D:6E:92 nodemac=C2:3D:FB:EA:1C:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:23.805Z",
  "value": "id=12    sec_id=856932 flags=0x0000 ifindex=14  mac=7A:10:2B:12:C8:8F nodemac=4E:57:BF:84:27:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:23.806Z",
  "value": "id=654   sec_id=856932 flags=0x0000 ifindex=12  mac=EA:B8:97:8D:6E:92 nodemac=C2:3D:FB:EA:1C:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:23.825Z",
  "value": "id=126   sec_id=4     flags=0x0000 ifindex=10  mac=3A:2F:17:AD:DD:48 nodemac=86:EF:A9:97:03:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.284Z",
  "value": "id=126   sec_id=4     flags=0x0000 ifindex=10  mac=3A:2F:17:AD:DD:48 nodemac=86:EF:A9:97:03:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.284Z",
  "value": "id=654   sec_id=856932 flags=0x0000 ifindex=12  mac=EA:B8:97:8D:6E:92 nodemac=C2:3D:FB:EA:1C:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.285Z",
  "value": "id=12    sec_id=856932 flags=0x0000 ifindex=14  mac=7A:10:2B:12:C8:8F nodemac=4E:57:BF:84:27:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.314Z",
  "value": "id=4056  sec_id=875309 flags=0x0000 ifindex=16  mac=5E:42:6A:37:6D:86 nodemac=3E:D6:B6:EB:15:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:28.284Z",
  "value": "id=654   sec_id=856932 flags=0x0000 ifindex=12  mac=EA:B8:97:8D:6E:92 nodemac=C2:3D:FB:EA:1C:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:28.284Z",
  "value": "id=4056  sec_id=875309 flags=0x0000 ifindex=16  mac=5E:42:6A:37:6D:86 nodemac=3E:D6:B6:EB:15:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:28.284Z",
  "value": "id=12    sec_id=856932 flags=0x0000 ifindex=14  mac=7A:10:2B:12:C8:8F nodemac=4E:57:BF:84:27:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:28.285Z",
  "value": "id=126   sec_id=4     flags=0x0000 ifindex=10  mac=3A:2F:17:AD:DD:48 nodemac=86:EF:A9:97:03:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:22.839Z",
  "value": "id=354   sec_id=875309 flags=0x0000 ifindex=18  mac=5E:6D:DE:A0:58:75 nodemac=76:E1:7E:CB:3F:52"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.25.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.239Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.903Z",
  "value": "id=654   sec_id=856932 flags=0x0000 ifindex=12  mac=EA:B8:97:8D:6E:92 nodemac=C2:3D:FB:EA:1C:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.903Z",
  "value": "id=12    sec_id=856932 flags=0x0000 ifindex=14  mac=7A:10:2B:12:C8:8F nodemac=4E:57:BF:84:27:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.903Z",
  "value": "id=354   sec_id=875309 flags=0x0000 ifindex=18  mac=5E:6D:DE:A0:58:75 nodemac=76:E1:7E:CB:3F:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.904Z",
  "value": "id=126   sec_id=4     flags=0x0000 ifindex=10  mac=3A:2F:17:AD:DD:48 nodemac=86:EF:A9:97:03:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:40.905Z",
  "value": "id=12    sec_id=856932 flags=0x0000 ifindex=14  mac=7A:10:2B:12:C8:8F nodemac=4E:57:BF:84:27:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:40.906Z",
  "value": "id=354   sec_id=875309 flags=0x0000 ifindex=18  mac=5E:6D:DE:A0:58:75 nodemac=76:E1:7E:CB:3F:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:40.906Z",
  "value": "id=126   sec_id=4     flags=0x0000 ifindex=10  mac=3A:2F:17:AD:DD:48 nodemac=86:EF:A9:97:03:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:40.907Z",
  "value": "id=654   sec_id=856932 flags=0x0000 ifindex=12  mac=EA:B8:97:8D:6E:92 nodemac=C2:3D:FB:EA:1C:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.906Z",
  "value": "id=354   sec_id=875309 flags=0x0000 ifindex=18  mac=5E:6D:DE:A0:58:75 nodemac=76:E1:7E:CB:3F:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.906Z",
  "value": "id=126   sec_id=4     flags=0x0000 ifindex=10  mac=3A:2F:17:AD:DD:48 nodemac=86:EF:A9:97:03:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.906Z",
  "value": "id=654   sec_id=856932 flags=0x0000 ifindex=12  mac=EA:B8:97:8D:6E:92 nodemac=C2:3D:FB:EA:1C:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.907Z",
  "value": "id=12    sec_id=856932 flags=0x0000 ifindex=14  mac=7A:10:2B:12:C8:8F nodemac=4E:57:BF:84:27:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.907Z",
  "value": "id=12    sec_id=856932 flags=0x0000 ifindex=14  mac=7A:10:2B:12:C8:8F nodemac=4E:57:BF:84:27:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.907Z",
  "value": "id=354   sec_id=875309 flags=0x0000 ifindex=18  mac=5E:6D:DE:A0:58:75 nodemac=76:E1:7E:CB:3F:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.907Z",
  "value": "id=126   sec_id=4     flags=0x0000 ifindex=10  mac=3A:2F:17:AD:DD:48 nodemac=86:EF:A9:97:03:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.907Z",
  "value": "id=654   sec_id=856932 flags=0x0000 ifindex=12  mac=EA:B8:97:8D:6E:92 nodemac=C2:3D:FB:EA:1C:15"
}

