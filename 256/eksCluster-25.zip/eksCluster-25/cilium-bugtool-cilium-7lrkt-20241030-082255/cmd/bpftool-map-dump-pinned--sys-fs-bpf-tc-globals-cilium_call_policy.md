key: 0c 00 00 00  value: 13 02 00 00
key: 7e 00 00 00  value: 27 02 00 00
key: 62 01 00 00  value: 62 02 00 00
key: 8e 02 00 00  value: 11 02 00 00
Found 4 elements
