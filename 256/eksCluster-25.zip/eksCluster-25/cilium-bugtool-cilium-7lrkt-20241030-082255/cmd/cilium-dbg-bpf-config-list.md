KEY             VALUE
AgentLiveness   2347606020474
UTimeOffset     3379441916015625
