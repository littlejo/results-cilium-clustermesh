IP ADDRESS        LOCAL ENDPOINT INFO
10.25.0.33:0      id=354   sec_id=875309 flags=0x0000 ifindex=18  mac=5E:6D:DE:A0:58:75 nodemac=76:E1:7E:CB:3F:52   
10.25.0.58:0      (localhost)                                                                                       
172.31.234.61:0   (localhost)                                                                                       
10.25.0.160:0     id=654   sec_id=856932 flags=0x0000 ifindex=12  mac=EA:B8:97:8D:6E:92 nodemac=C2:3D:FB:EA:1C:15   
172.31.210.57:0   (localhost)                                                                                       
10.25.0.182:0     id=12    sec_id=856932 flags=0x0000 ifindex=14  mac=7A:10:2B:12:C8:8F nodemac=4E:57:BF:84:27:DA   
10.25.0.151:0     id=126   sec_id=4     flags=0x0000 ifindex=10  mac=3A:2F:17:AD:DD:48 nodemac=86:EF:A9:97:03:5B    
