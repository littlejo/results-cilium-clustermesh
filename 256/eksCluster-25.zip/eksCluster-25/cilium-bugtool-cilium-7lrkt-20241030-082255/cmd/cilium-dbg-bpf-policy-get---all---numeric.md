Endpoint ID: 12
Path: /sys/fs/bpf/tc/globals/cilium_policy_00012

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    177627   2038      0        
Allow    Egress      0          ANY          NONE         disabled    22009    248       0        


Endpoint ID: 126
Path: /sys/fs/bpf/tc/globals/cilium_policy_00126

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1659746   20975     0        
Allow    Ingress     1          ANY          NONE         disabled    27662     325       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 306
Path: /sys/fs/bpf/tc/globals/cilium_policy_00306

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 354
Path: /sys/fs/bpf/tc/globals/cilium_policy_00354

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11666040   117122    0        
Allow    Ingress     1          ANY          NONE         disabled    10874056   114893    0        
Allow    Egress      0          ANY          NONE         disabled    13873999   135969    0        


Endpoint ID: 654
Path: /sys/fs/bpf/tc/globals/cilium_policy_00654

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    179277   2063      0        
Allow    Egress      0          ANY          NONE         disabled    21543    242       0        


