alloc: 201.08MB (210842888 bytes)
total-alloc: 2.30GB (2471052144 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 64400778
frees: 62200075
heap-alloc: 201.08MB (210842888 bytes)
heap-sys: 251.41MB (263626752 bytes)
heap-idle: 31.31MB (32833536 bytes)
heap-in-use: 220.10MB (230793216 bytes)
heap-released: 9.38MB (9830400 bytes)
heap-objects: 2200703
stack-in-use: 64.56MB (67698688 bytes)
stack-sys: 64.56MB (67698688 bytes)
stack-mspan-inuse: 3.52MB (3692800 bytes)
stack-mspan-sys: 3.77MB (3949440 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.07MB (1122713 bytes)
gc-sys: 5.99MB (6278608 bytes)
next-gc: when heap-alloc >= 233.11MB (244434728 bytes)
last-gc: 2024-10-30 08:22:55.689766085 +0000 UTC
gc-pause-total: 16.483385ms
gc-pause: 2710829
gc-pause-end: 1730276575689766085
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0005276161209496638
enable-gc: true
debug-gc: false
