Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal      2     47     61     52     28     13      9      6     27     12    854 
