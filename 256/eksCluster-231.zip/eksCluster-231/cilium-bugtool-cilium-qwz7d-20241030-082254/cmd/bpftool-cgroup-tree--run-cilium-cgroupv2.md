CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode51db382_1a27_4af6_b5bc_48f3c8641210.slice/cri-containerd-23fea81d5ff1f4a4dbbfb1a6493f58281261b92573e6989ed3a555e2398bd196.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode51db382_1a27_4af6_b5bc_48f3c8641210.slice/cri-containerd-3185fe2a23501abcb0f58e2abadf191a28dfc63bd04c8bdc92abb18b231b4894.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod378634a3_0516_4a11_aae5_ed871874e7e6.slice/cri-containerd-253cde24e45b934acb97b715fd7677b061ea92b75e553602c787bd9036204fec.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod378634a3_0516_4a11_aae5_ed871874e7e6.slice/cri-containerd-4a9e35ee149cb863e1124b478ab362ed2e074a2c1d854dc8e352d0e6a3f75bcc.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod407076ea_397f_480e_9270_c9c75637328e.slice/cri-containerd-33d8ffd0e1baefb83d496d6f126560755001a53d2a34ffa33884de8aa8b2be24.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod407076ea_397f_480e_9270_c9c75637328e.slice/cri-containerd-442f9a6411b2741543b2af65949bb92c5c15f6cf509c26a7448c296385e26f94.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc8db200_3181_4dea_a6ba_ec5c2931781e.slice/cri-containerd-1d61670a38a7c6456f385a97cf412429975760dbb24194c1f08d35b205441067.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc8db200_3181_4dea_a6ba_ec5c2931781e.slice/cri-containerd-cedabbd9f8497fd5273640601a703de32cfaba9e4e441f6373ba67fb04f2fa64.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod588ec2ee_e88f_4e1e_a135_6a0839525eab.slice/cri-containerd-75a78692aef4981b1c85c0579cf8f7aba12725866d637f7f69d1f3f6142e1383.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod588ec2ee_e88f_4e1e_a135_6a0839525eab.slice/cri-containerd-ef7b3afe959ac7436f614e1464680f555946f8829ee50f3b1b91661e757c0ad9.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc572101a_785b_4e33_a4d0_7fcf72518615.slice/cri-containerd-45d4e7b3aa3dd9c8abeac4270dbcad0131ce02c6b7392c43961fc7b9bd2aa8c7.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc572101a_785b_4e33_a4d0_7fcf72518615.slice/cri-containerd-68dfcb5f3e163f6d5f7efe29dc0236030b9008b92e582fd7f45b9ff47a10e434.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8de60aff_a78c_41d0_a45c_2b80a7064176.slice/cri-containerd-a973e7e96b8dcd768e544a178523a17d4696e1830ccc7bdb06634cf957c4f147.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8de60aff_a78c_41d0_a45c_2b80a7064176.slice/cri-containerd-8d5412c5906c3567c3ad1444560bf0adfafe94cafefaa5d066d480f68dea797f.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8de60aff_a78c_41d0_a45c_2b80a7064176.slice/cri-containerd-044c56535181e708f0d27d4e42de7de77730167b23382223df5e215991e6cae7.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8de60aff_a78c_41d0_a45c_2b80a7064176.slice/cri-containerd-789767a0ff62d73da8481cd107d4475a6b82eb9f4fe7da119a04cf0f3eb5e756.scope
    654      cgroup_device   multi                                          
