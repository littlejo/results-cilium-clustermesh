key: 01 00 00 00  value: ac 1f 83 21 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: 0a e7 00 5a 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a e7 00 31 09 4b 00 00  00 00 00 00
key: 07 00 00 00  value: 0a e7 00 c9 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f c7 5d 01 bb 00 00  00 00 00 00
key: 04 00 00 00  value: 0a e7 00 5a 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a e7 00 c9 00 35 00 00  00 00 00 00
key: 03 00 00 00  value: ac 1f db 2f 10 94 00 00  00 00 00 00
Found 8 elements
