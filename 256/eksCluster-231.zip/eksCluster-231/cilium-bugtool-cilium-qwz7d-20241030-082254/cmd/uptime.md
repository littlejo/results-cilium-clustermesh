 08:22:55 up 30 min,  0 users,  load average: 0.10, 0.17, 0.17
