[
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8de60aff_a78c_41d0_a45c_2b80a7064176.slice/cri-containerd-8d5412c5906c3567c3ad1444560bf0adfafe94cafefaa5d066d480f68dea797f.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8de60aff_a78c_41d0_a45c_2b80a7064176.slice/cri-containerd-044c56535181e708f0d27d4e42de7de77730167b23382223df5e215991e6cae7.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8de60aff_a78c_41d0_a45c_2b80a7064176.slice/cri-containerd-a973e7e96b8dcd768e544a178523a17d4696e1830ccc7bdb06634cf957c4f147.scope"
      }
    ],
    "ips": [
      "10.231.0.49"
    ],
    "name": "clustermesh-apiserver-698f48fc6b-qgqmb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod407076ea_397f_480e_9270_c9c75637328e.slice/cri-containerd-442f9a6411b2741543b2af65949bb92c5c15f6cf509c26a7448c296385e26f94.scope"
      }
    ],
    "ips": [
      "10.231.0.201"
    ],
    "name": "coredns-cc6ccd49c-ww8qx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode51db382_1a27_4af6_b5bc_48f3c8641210.slice/cri-containerd-23fea81d5ff1f4a4dbbfb1a6493f58281261b92573e6989ed3a555e2398bd196.scope"
      }
    ],
    "ips": [
      "10.231.0.90"
    ],
    "name": "coredns-cc6ccd49c-4njzz",
    "namespace": "kube-system"
  }
]

