32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:52:54+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:53:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:03:04+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
482: sched_cls  name tail_handle_ipv4  tag 886d593acbb704c8  gpl
	loaded_at 2024-10-30T08:03:04+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
483: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:03:04+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
484: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:03:04+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 127
519: sched_cls  name tail_ipv4_to_endpoint  tag 7f467bd964180c22  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 168
520: sched_cls  name tail_ipv4_ct_egress  tag f7b252413ac9a65e  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 170
521: sched_cls  name tail_handle_arp  tag f0867b8231a1d09a  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 171
526: sched_cls  name tail_handle_ipv4  tag 2d3a8faeee942c38  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 173
528: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 177
529: sched_cls  name cil_from_container  tag 2d2fc49e42fc3e5c  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 179
530: sched_cls  name __send_drop_notify  tag 37772c32cf669ac0  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 180
532: sched_cls  name tail_handle_ipv4  tag de69bb772ab6b585  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 183
533: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 184
534: sched_cls  name cil_from_container  tag fe412f272d9a127c  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 185
535: sched_cls  name handle_policy  tag 1963799e5f9c9454  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 181
536: sched_cls  name tail_ipv4_ct_egress  tag f7b252413ac9a65e  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 186
537: sched_cls  name tail_handle_arp  tag 6f1ae2b7a6ce4c50  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 188
538: sched_cls  name tail_handle_ipv4_cont  tag b611dea56363c330  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 187
539: sched_cls  name tail_ipv4_ct_ingress  tag 7a9dc3c93548aca9  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 190
540: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,117
	btf_id 192
542: sched_cls  name tail_ipv4_to_endpoint  tag 91283bdfa17b8711  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 189
543: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 194
544: sched_cls  name tail_handle_ipv4_from_host  tag 9c09753060425983  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 195
545: sched_cls  name __send_drop_notify  tag 3bfa220e10928d65  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 196
546: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 197
550: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 203
551: sched_cls  name handle_policy  tag 62975d393cbf2c78  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 198
552: sched_cls  name tail_handle_ipv4_from_host  tag 9c09753060425983  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 204
554: sched_cls  name __send_drop_notify  tag 3bfa220e10928d65  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
555: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 207
557: sched_cls  name tail_ipv4_ct_ingress  tag a608b3de7209a88d  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 209
558: sched_cls  name __send_drop_notify  tag c7fd07998f387bc6  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 210
559: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 212
563: sched_cls  name tail_handle_ipv4_from_host  tag 9c09753060425983  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 217
564: sched_cls  name __send_drop_notify  tag 3bfa220e10928d65  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 218
565: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 219
566: sched_cls  name tail_handle_ipv4_cont  tag 2860b86b63abe3d6  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 213
567: sched_cls  name tail_ipv4_to_endpoint  tag b8c8b56d9d84f2d4  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,124,41,82,83,80,100,39,123,40,37,38
	btf_id 221
568: sched_cls  name __send_drop_notify  tag 3bfa220e10928d65  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 224
569: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,126
	btf_id 225
570: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,126,75
	btf_id 226
574: sched_cls  name tail_handle_ipv4_from_host  tag 9c09753060425983  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,126
	btf_id 230
575: sched_cls  name handle_policy  tag be0a4b14af709257  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,123,82,83,124,41,80,100,39,84,75,40,37,38
	btf_id 222
576: sched_cls  name tail_handle_arp  tag bfbffffda9f5d834  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,123
	btf_id 231
577: sched_cls  name __send_drop_notify  tag 36ccfbda272af2b7  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 232
578: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,123
	btf_id 233
579: sched_cls  name cil_from_container  tag eaebe2e2135532f6  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 123,76
	btf_id 234
581: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,123,82,83,124,84
	btf_id 236
582: sched_cls  name tail_handle_ipv4_cont  tag f85f2727f1123a34  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,124,41,100,82,83,39,76,74,77,123,40,37,38,81
	btf_id 237
583: sched_cls  name tail_handle_ipv4  tag 71b06185d98421af  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,123
	btf_id 238
584: sched_cls  name tail_ipv4_ct_ingress  tag 61cc601cfe41e5e5  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,123,82,83,124,84
	btf_id 239
585: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
588: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
589: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
592: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: sched_cls  name tail_ipv4_ct_ingress  tag c69f89f9d8b1f63f  gpl
	loaded_at 2024-10-30T08:10:14+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 253
641: sched_cls  name cil_from_container  tag dab84bbd68784606  gpl
	loaded_at 2024-10-30T08:10:14+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 254
642: sched_cls  name handle_policy  tag f57c831fae65c053  gpl
	loaded_at 2024-10-30T08:10:14+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 255
643: sched_cls  name tail_handle_ipv4_cont  tag 6f67f98f60628c8e  gpl
	loaded_at 2024-10-30T08:10:14+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 256
644: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:10:14+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 257
645: sched_cls  name tail_handle_arp  tag 8a13c49ae2aa2b2c  gpl
	loaded_at 2024-10-30T08:10:14+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 258
646: sched_cls  name __send_drop_notify  tag 9ea7f633fe07a792  gpl
	loaded_at 2024-10-30T08:10:14+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 259
648: sched_cls  name tail_ipv4_to_endpoint  tag faab4c4e491e167d  gpl
	loaded_at 2024-10-30T08:10:14+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 261
649: sched_cls  name tail_ipv4_ct_egress  tag 797f3a8eec9d53a7  gpl
	loaded_at 2024-10-30T08:10:14+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 262
650: sched_cls  name tail_handle_ipv4  tag e6163d8c86913624  gpl
	loaded_at 2024-10-30T08:10:14+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 263
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
667: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
670: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
671: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
674: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
