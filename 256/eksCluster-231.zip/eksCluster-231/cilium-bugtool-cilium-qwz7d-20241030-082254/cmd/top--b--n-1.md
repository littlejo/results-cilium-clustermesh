top - 08:22:55 up 30 min,  0 users,  load average: 0.10, 0.17, 0.17
Tasks:  10 total,   2 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 56.2 us, 43.8 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4471.6 free,   1195.7 used,   2146.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6433.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 384180  78404 S  81.2   4.8   0:50.44 cilium-+
    634 root      20   0 1240432  16556  11356 S   6.2   0.2   0:00.03 cilium-+
    394 root      20   0 1229744   8048   3900 S   0.0   0.1   0:01.14 cilium-+
    628 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    658 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    668 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    694 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    720 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    726 root      20   0 1616264   8740   6236 S   0.0   0.1   0:00.00 runc:[2+
    732 root      20   0 1485192   8740   6236 R   0.0   0.1   0:00.00 runc:[2+
