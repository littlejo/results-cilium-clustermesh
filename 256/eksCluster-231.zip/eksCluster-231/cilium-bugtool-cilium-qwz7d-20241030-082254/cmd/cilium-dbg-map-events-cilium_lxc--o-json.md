{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:02.679Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.196.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:02.679Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.219.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:02.679Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:07.148Z",
  "value": "id=1868  sec_id=4     flags=0x0000 ifindex=10  mac=22:E2:39:0D:AB:8D nodemac=D2:40:FA:FB:44:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:07.164Z",
  "value": "id=1530  sec_id=7605658 flags=0x0000 ifindex=12  mac=72:9E:35:37:6F:37 nodemac=6A:B9:6B:CC:39:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:07.189Z",
  "value": "id=1753  sec_id=7605658 flags=0x0000 ifindex=14  mac=F2:A1:DF:4C:02:2C nodemac=CA:9F:97:A8:30:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:07.238Z",
  "value": "id=1868  sec_id=4     flags=0x0000 ifindex=10  mac=22:E2:39:0D:AB:8D nodemac=D2:40:FA:FB:44:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:34.828Z",
  "value": "id=1530  sec_id=7605658 flags=0x0000 ifindex=12  mac=72:9E:35:37:6F:37 nodemac=6A:B9:6B:CC:39:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:34.829Z",
  "value": "id=1753  sec_id=7605658 flags=0x0000 ifindex=14  mac=F2:A1:DF:4C:02:2C nodemac=CA:9F:97:A8:30:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:34.829Z",
  "value": "id=1868  sec_id=4     flags=0x0000 ifindex=10  mac=22:E2:39:0D:AB:8D nodemac=D2:40:FA:FB:44:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:34.858Z",
  "value": "id=292   sec_id=7602426 flags=0x0000 ifindex=16  mac=52:BA:B1:5C:0E:D6 nodemac=2E:F8:C2:80:B8:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:34.859Z",
  "value": "id=292   sec_id=7602426 flags=0x0000 ifindex=16  mac=52:BA:B1:5C:0E:D6 nodemac=2E:F8:C2:80:B8:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:35.828Z",
  "value": "id=1868  sec_id=4     flags=0x0000 ifindex=10  mac=22:E2:39:0D:AB:8D nodemac=D2:40:FA:FB:44:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:35.828Z",
  "value": "id=292   sec_id=7602426 flags=0x0000 ifindex=16  mac=52:BA:B1:5C:0E:D6 nodemac=2E:F8:C2:80:B8:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:35.828Z",
  "value": "id=1530  sec_id=7605658 flags=0x0000 ifindex=12  mac=72:9E:35:37:6F:37 nodemac=6A:B9:6B:CC:39:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:35.828Z",
  "value": "id=1753  sec_id=7605658 flags=0x0000 ifindex=14  mac=F2:A1:DF:4C:02:2C nodemac=CA:9F:97:A8:30:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:14.047Z",
  "value": "id=1793  sec_id=7602426 flags=0x0000 ifindex=18  mac=CE:AE:4F:B2:A9:A3 nodemac=D2:FE:72:F4:1A:27"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.231.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.440Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.527Z",
  "value": "id=1753  sec_id=7605658 flags=0x0000 ifindex=14  mac=F2:A1:DF:4C:02:2C nodemac=CA:9F:97:A8:30:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.527Z",
  "value": "id=1868  sec_id=4     flags=0x0000 ifindex=10  mac=22:E2:39:0D:AB:8D nodemac=D2:40:FA:FB:44:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.527Z",
  "value": "id=1793  sec_id=7602426 flags=0x0000 ifindex=18  mac=CE:AE:4F:B2:A9:A3 nodemac=D2:FE:72:F4:1A:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.528Z",
  "value": "id=1530  sec_id=7605658 flags=0x0000 ifindex=12  mac=72:9E:35:37:6F:37 nodemac=6A:B9:6B:CC:39:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.530Z",
  "value": "id=1530  sec_id=7605658 flags=0x0000 ifindex=12  mac=72:9E:35:37:6F:37 nodemac=6A:B9:6B:CC:39:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.530Z",
  "value": "id=1753  sec_id=7605658 flags=0x0000 ifindex=14  mac=F2:A1:DF:4C:02:2C nodemac=CA:9F:97:A8:30:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.531Z",
  "value": "id=1793  sec_id=7602426 flags=0x0000 ifindex=18  mac=CE:AE:4F:B2:A9:A3 nodemac=D2:FE:72:F4:1A:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.531Z",
  "value": "id=1868  sec_id=4     flags=0x0000 ifindex=10  mac=22:E2:39:0D:AB:8D nodemac=D2:40:FA:FB:44:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.527Z",
  "value": "id=1530  sec_id=7605658 flags=0x0000 ifindex=12  mac=72:9E:35:37:6F:37 nodemac=6A:B9:6B:CC:39:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.527Z",
  "value": "id=1753  sec_id=7605658 flags=0x0000 ifindex=14  mac=F2:A1:DF:4C:02:2C nodemac=CA:9F:97:A8:30:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.527Z",
  "value": "id=1793  sec_id=7602426 flags=0x0000 ifindex=18  mac=CE:AE:4F:B2:A9:A3 nodemac=D2:FE:72:F4:1A:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.527Z",
  "value": "id=1868  sec_id=4     flags=0x0000 ifindex=10  mac=22:E2:39:0D:AB:8D nodemac=D2:40:FA:FB:44:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.528Z",
  "value": "id=1530  sec_id=7605658 flags=0x0000 ifindex=12  mac=72:9E:35:37:6F:37 nodemac=6A:B9:6B:CC:39:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.528Z",
  "value": "id=1753  sec_id=7605658 flags=0x0000 ifindex=14  mac=F2:A1:DF:4C:02:2C nodemac=CA:9F:97:A8:30:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.528Z",
  "value": "id=1793  sec_id=7602426 flags=0x0000 ifindex=18  mac=CE:AE:4F:B2:A9:A3 nodemac=D2:FE:72:F4:1A:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.231.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.528Z",
  "value": "id=1868  sec_id=4     flags=0x0000 ifindex=10  mac=22:E2:39:0D:AB:8D nodemac=D2:40:FA:FB:44:F9"
}

