Endpoint ID: 1530
Path: /sys/fs/bpf/tc/globals/cilium_policy_01530

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    115067   1318      0        
Allow    Egress      0          ANY          NONE         disabled    16772    180       0        


Endpoint ID: 1753
Path: /sys/fs/bpf/tc/globals/cilium_policy_01753

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    117088   1345      0        
Allow    Egress      0          ANY          NONE         disabled    16353    176       0        


Endpoint ID: 1793
Path: /sys/fs/bpf/tc/globals/cilium_policy_01793

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11603687   116662    0        
Allow    Ingress     1          ANY          NONE         disabled    10687442   112962    0        
Allow    Egress      0          ANY          NONE         disabled    14028005   137452    0        


Endpoint ID: 1868
Path: /sys/fs/bpf/tc/globals/cilium_policy_01868

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1655286   20921     0        
Allow    Ingress     1          ANY          NONE         disabled    18394     217       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2588
Path: /sys/fs/bpf/tc/globals/cilium_policy_02588

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


