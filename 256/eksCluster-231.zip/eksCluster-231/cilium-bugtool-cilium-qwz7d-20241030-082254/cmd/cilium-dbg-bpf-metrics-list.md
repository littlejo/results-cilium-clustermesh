REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37864     3001558     677    bpf_overlay.c
Interface                 INGRESS     660407    133699033   1132   bpf_host.c
Success                   EGRESS      17659     1395644     1694   bpf_host.c
Success                   EGRESS      280701    34679197    1308   bpf_lxc.c
Success                   EGRESS      38809     3071968     53     encap.h
Success                   INGRESS     324347    36639959    86     l3.h
Success                   INGRESS     345203    38289919    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
