IP ADDRESS         LOCAL ENDPOINT INFO
10.231.0.201:0     id=1753  sec_id=7605658 flags=0x0000 ifindex=14  mac=F2:A1:DF:4C:02:2C nodemac=CA:9F:97:A8:30:B6   
10.231.0.21:0      id=1868  sec_id=4     flags=0x0000 ifindex=10  mac=22:E2:39:0D:AB:8D nodemac=D2:40:FA:FB:44:F9     
172.31.196.237:0   (localhost)                                                                                        
172.31.219.47:0    (localhost)                                                                                        
10.231.0.9:0       (localhost)                                                                                        
10.231.0.49:0      id=1793  sec_id=7602426 flags=0x0000 ifindex=18  mac=CE:AE:4F:B2:A9:A3 nodemac=D2:FE:72:F4:1A:27   
10.231.0.90:0      id=1530  sec_id=7605658 flags=0x0000 ifindex=12  mac=72:9E:35:37:6F:37 nodemac=6A:B9:6B:CC:39:D4   
