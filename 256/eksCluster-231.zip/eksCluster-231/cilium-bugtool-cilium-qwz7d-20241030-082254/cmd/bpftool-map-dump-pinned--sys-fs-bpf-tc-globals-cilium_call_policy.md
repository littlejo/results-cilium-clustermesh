key: fa 05 00 00  value: 17 02 00 00
key: d9 06 00 00  value: 27 02 00 00
key: 01 07 00 00  value: 82 02 00 00
key: 4c 07 00 00  value: 3f 02 00 00
Found 4 elements
