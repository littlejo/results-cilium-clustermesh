ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.131.33:443 (active)    
                                         2 => 172.31.199.93:443 (active)    
2    10.100.85.128:443    ClusterIP      1 => 172.31.219.47:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.231.0.90:53 (active)       
                                         2 => 10.231.0.201:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.231.0.90:9153 (active)     
                                         2 => 10.231.0.201:9153 (active)    
5    10.100.162.62:2379   ClusterIP      1 => 10.231.0.49:2379 (active)     
