alloc: 155.92MB (163492400 bytes)
total-alloc: 2.47GB (2656834816 bytes)
sys: 329.21MB (345198948 bytes)
lookups: 0
mallocs: 66733107
frees: 65096184
heap-alloc: 155.92MB (163492400 bytes)
heap-sys: 248.36MB (260423680 bytes)
heap-idle: 55.03MB (57704448 bytes)
heap-in-use: 193.33MB (202719232 bytes)
heap-released: 72.00KB (73728 bytes)
heap-objects: 1636923
stack-in-use: 67.59MB (70877184 bytes)
stack-sys: 67.59MB (70877184 bytes)
stack-mspan-inuse: 3.27MB (3427360 bytes)
stack-mspan-sys: 4.00MB (4194240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.30MB (1360417 bytes)
gc-sys: 5.94MB (6227312 bytes)
next-gc: when heap-alloc >= 217.00MB (227539560 bytes)
last-gc: 2024-10-30 08:22:59.966167168 +0000 UTC
gc-pause-total: 21.601425ms
gc-pause: 122778
gc-pause-end: 1730276579966167168
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0006924655043593611
enable-gc: true
debug-gc: false
