markdown output at /tmp/cilium-bugtool-20241030-082253.866+0000-UTC-814600307/cmd/cilium-debuginfo-20241030-082325.131+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082253.866+0000-UTC-814600307/cmd/cilium-debuginfo-20241030-082325.131+0000-UTC.json
