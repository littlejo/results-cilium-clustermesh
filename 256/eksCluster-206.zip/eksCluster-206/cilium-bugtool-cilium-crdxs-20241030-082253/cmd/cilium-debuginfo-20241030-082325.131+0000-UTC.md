# Cilium debug information

#### Cilium encryption



#### Cilium environment keys

```
endpoint-gc-interval:5m0s
conntrack-gc-max-interval:0s
enable-service-topology:false
bgp-announce-pod-cidr:false
enable-k8s-networkpolicy:true
bpf-ct-timeout-service-tcp-grace:1m0s
direct-routing-skip-unreachable:false
http-retry-timeout:0
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
enable-gateway-api:false
proxy-idle-timeout-seconds:60
k8s-require-ipv6-pod-cidr:false
bpf-lb-affinity-map-max:0
bpf-ct-timeout-service-any:1m0s
k8s-require-ipv4-pod-cidr:false
bpf-lb-map-max:65536
enable-ipv6-ndp:false
ipv6-pod-subnets:
enable-hubble:true
hubble-redact-http-urlquery:false
clustermesh-sync-timeout:1m0s
remove-cilium-node-taints:true
enable-node-port:false
operator-prometheus-serve-addr::9963
bpf-lb-sock-hostns-only:false
http-retry-count:3
hubble-drop-events-interval:2m0s
prepend-iptables-chains:true
hubble-monitor-events:
custom-cni-conf:false
bpf-auth-map-max:524288
enable-local-node-route:true
set-cilium-is-up-condition:true
enable-hubble-recorder-api:true
socket-path:/var/run/cilium/cilium.sock
max-connected-clusters:511
kvstore:
annotate-k8s-node:false
enable-ipv6-masquerade:true
hubble-export-file-compress:false
enable-unreachable-routes:false
max-controller-interval:0
ipam:cluster-pool
ipsec-key-file:
force-device-detection:false
encrypt-interface:
clustermesh-ip-identities-sync-timeout:1m0s
iptables-random-fully:false
vtep-mask:
bpf-lb-rss-ipv4-src-cidr:
static-cnp-path:
log-driver:
enable-policy:default
enable-bpf-masquerade:false
dnsproxy-lock-timeout:500ms
ipv6-cluster-alloc-cidr:f00d::/64
disable-envoy-version-check:false
mesh-auth-queue-size:1024
procfs:/host/proc
bpf-lb-rev-nat-map-max:0
dns-max-ips-per-restored-rule:1000
hubble-redact-kafka-apikey:false
log-system-load:false
enable-masquerade-to-route-source:false
dnsproxy-lock-count:131
encrypt-node:false
container-ip-local-reserved-ports:auto
ipam-default-ip-pool:default
local-router-ipv4:
clustermesh-enable-mcs-api:false
bpf-events-trace-enabled:true
join-cluster:false
install-iptables-rules:true
cluster-id:207
enable-svc-source-range-check:true
local-max-addr-scope:252
bpf-lb-mode:snat
enable-l2-neigh-discovery:true
enable-stale-cilium-endpoint-cleanup:true
enable-tcx:true
mesh-auth-enabled:true
ingress-secrets-namespace:
dnsproxy-concurrency-processing-grace-period:0s
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
bpf-lb-maglev-table-size:16381
ipam-cilium-node-update-rate:15s
enable-sctp:false
config:
k8s-namespace:kube-system
enable-ipv4-egress-gateway:false
trace-payloadlen:128
enable-health-check-nodeport:true
cni-external-routing:false
log-opt:
cflags:
preallocate-bpf-maps:false
kvstore-periodic-sync:5m0s
controller-group-metrics:
k8s-client-connection-keep-alive:30s
api-rate-limit:
bpf-lb-service-map-max:0
nodes-gc-interval:5m0s
enable-l2-pod-announcements:false
bpf-ct-global-tcp-max:524288
hubble-redact-http-userinfo:true
policy-cidr-match-mode:
restore:true
kvstore-max-consecutive-quorum-errors:2
agent-labels:
enable-bandwidth-manager:false
mesh-auth-spire-admin-socket:
bgp-announce-lb-ip:false
hubble-redact-enabled:false
identity-change-grace-period:5s
enable-host-firewall:false
read-cni-conf:
enable-mke:false
envoy-config-timeout:2m0s
cluster-pool-ipv4-cidr:10.206.0.0/16
ipv6-node:auto
bpf-ct-timeout-regular-any:1m0s
enable-ipv4-big-tcp:false
ipsec-key-rotation-duration:5m0s
hubble-skip-unknown-cgroup-ids:true
policy-trigger-interval:1s
bpf-policy-map-full-reconciliation-interval:15m0s
node-labels:
enable-ipsec-encrypted-overlay:false
use-full-tls-context:false
proxy-prometheus-port:0
pprof-port:6060
identity-restore-grace-period:30s
ipv6-range:auto
mesh-auth-mutual-connect-timeout:5s
hubble-recorder-sink-queue-size:1024
k8s-api-server:
enable-host-legacy-routing:false
hubble-listen-address::4244
enable-icmp-rules:true
version:false
enable-ip-masq-agent:false
mesh-auth-rotated-identities-queue-size:1024
hubble-export-fieldmask:
hubble-redact-http-headers-deny:
bpf-lb-acceleration:disabled
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
envoy-log:
ipv4-pod-subnets:
k8s-kubeconfig-path:
ipv4-service-range:auto
bpf-lb-dsr-dispatch:opt
enable-tracing:false
hubble-export-file-path:
enable-cilium-health-api-server-access:
l2-announcements-renew-deadline:5s
bpf-ct-timeout-regular-tcp-syn:1m0s
bpf-lb-external-clusterip:false
wireguard-persistent-keepalive:0s
vtep-cidr:
set-cilium-node-taints:true
bpf-policy-map-max:16384
k8s-client-connection-timeout:30s
mesh-auth-gc-interval:5m0s
tofqdns-min-ttl:0
enable-xt-socket-fallback:true
auto-create-cilium-node-resource:true
bpf-lb-sock:false
dns-policy-unload-on-shutdown:false
tunnel-port:0
tofqdns-endpoint-max-ip-per-hostname:50
allocator-list-timeout:3m0s
state-dir:/var/run/cilium
hubble-socket-path:/var/run/cilium/hubble.sock
devices:
cni-chaining-mode:none
identity-heartbeat-timeout:30m0s
enable-local-redirect-policy:false
enable-health-checking:true
enable-ipv4-masquerade:true
http-request-timeout:3600
bpf-lb-sock-terminate-pod-connections:false
endpoint-bpf-prog-watchdog-interval:30s
bpf-filter-priority:1
enable-custom-calls:false
bgp-config-path:/var/lib/cilium/bgp/config.yaml
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
nat-map-stats-entries:32
bpf-events-policy-verdict-enabled:true
kvstore-connectivity-timeout:2m0s
enable-ipv6-big-tcp:false
enable-active-connection-tracking:false
k8s-service-cache-size:128
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-encryption-strict-mode:false
hubble-drop-events:false
enable-srv6:false
l2-pod-announcements-interface:
enable-auto-protect-node-port-range:true
ipv6-service-range:auto
bpf-lb-maglev-map-max:0
direct-routing-device:
identity-gc-interval:15m0s
bpf-lb-rss-ipv6-src-cidr:
fqdn-regex-compile-lru-size:1024
enable-l7-proxy:true
iptables-lock-timeout:5s
enable-nat46x64-gateway:false
agent-liveness-update-interval:1s
enable-identity-mark:true
http-normalize-path:true
k8s-client-burst:20
enable-k8s-terminating-endpoint:true
agent-health-port:9879
enable-endpoint-routes:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
ipv4-node:auto
node-port-mode:snat
proxy-xff-num-trusted-hops-egress:0
enable-session-affinity:false
synchronize-k8s-nodes:true
proxy-portrange-max:20000
cgroup-root:/run/cilium/cgroupv2
policy-queue-size:100
enable-vtep:false
enable-ipip-termination:false
dnsproxy-insecure-skip-transparent-mode-check:false
cni-chaining-target:
tofqdns-proxy-response-max-delay:100ms
bpf-ct-timeout-regular-tcp:2h13m20s
bypass-ip-availability-upon-restore:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
enable-bpf-clock-probe:false
endpoint-queue-size:25
enable-high-scale-ipcache:false
monitor-aggregation:medium
allow-localhost:auto
tofqdns-enable-dns-compression:true
node-port-range:
hubble-event-buffer-capacity:4095
tofqdns-dns-reject-response-code:refused
enable-ipv6:false
exclude-node-label-patterns:
dnsproxy-socket-linger-timeout:10
bpf-events-drop-enabled:true
ipam-multi-pool-pre-allocation:
hubble-export-denylist:
tofqdns-idle-connection-grace-period:0s
unmanaged-pod-watcher-interval:15
hubble-metrics-server:
proxy-max-connection-duration-seconds:0
external-envoy-proxy:true
enable-l2-announcements:false
proxy-gid:1337
bpf-map-dynamic-size-ratio:0.0025
debug-verbose:
proxy-portrange-min:10000
disable-iptables-feeder-rules:
dnsproxy-enable-transparent-mode:true
hubble-redact-http-headers-allow:
enable-external-ips:false
disable-endpoint-crd:false
enable-metrics:true
egress-multi-home-ip-rule-compat:false
enable-host-port:false
enable-bpf-tproxy:false
route-metric:0
hubble-event-queue-size:0
enable-route-mtu-for-cni-chaining:false
cluster-name:cmesh207
mesh-auth-spiffe-trust-domain:spiffe.cilium
kvstore-lease-ttl:15m0s
kube-proxy-replacement:false
enable-cilium-api-server-access:
envoy-keep-cap-netbindservice:false
operator-api-serve-addr:127.0.0.1:9234
vtep-mac:
gops-port:9890
k8s-heartbeat-timeout:30s
ipv6-mcast-device:
envoy-config-retry-interval:15s
bpf-nat-global-max:524288
monitor-queue-size:0
k8s-client-qps:10
bpf-lb-algorithm:random
hubble-export-file-max-backups:5
identity-allocation-mode:crd
mesh-auth-mutual-listener-port:0
hubble-disable-tls:false
enable-k8s-endpoint-slice:true
crd-wait-timeout:5m0s
routing-mode:tunnel
encryption-strict-mode-cidr:
node-port-algorithm:random
enable-wireguard-userspace-fallback:false
bpf-neigh-global-max:524288
l2-announcements-lease-duration:15s
bpf-map-event-buffers:
egress-gateway-reconciliation-trigger-interval:1s
proxy-admin-port:0
l2-announcements-retry-period:2s
http-idle-timeout:0
cni-exclusive:true
enable-health-check-loadbalancer-ip:false
install-no-conntrack-iptables-rules:false
allow-icmp-frag-needed:true
local-router-ipv6:
certificates-directory:/var/run/cilium/certs
derive-masq-ip-addr-from-device:
enable-k8s:true
bpf-fragments-map-max:8192
enable-recorder:false
enable-ipv4-fragment-tracking:true
tofqdns-pre-cache:
proxy-connect-timeout:2
hubble-metrics:
hubble-export-file-max-size-mb:10
bpf-root:/sys/fs/bpf
enable-k8s-api-discovery:false
enable-ipsec-key-watcher:true
k8s-sync-timeout:3m0s
mtu:0
conntrack-gc-interval:0s
srv6-encap-mode:reduced
proxy-max-requests-per-connection:0
bpf-node-map-max:16384
bpf-lb-dsr-l4-xlate:frontend
exclude-local-address:
enable-monitor:true
enable-envoy-config:false
use-cilium-internal-ip-for-ipsec:false
arping-refresh-period:30s
config-dir:/tmp/cilium/config-map
prometheus-serve-addr:
config-sources:config-map:kube-system/cilium-config
egress-gateway-policy-map-max:16384
policy-audit-mode:false
bpf-ct-timeout-regular-tcp-fin:10s
enable-runtime-device-detection:true
enable-wireguard:false
hubble-export-allowlist:
enable-ipsec-xfrm-state-caching:true
policy-accounting:true
hubble-prefer-ipv6:false
ipv6-native-routing-cidr:
ipv4-native-routing-cidr:
pprof-address:localhost
hubble-flowlogs-config-path:
trace-sock:true
cluster-health-port:4240
enable-bgp-control-plane:false
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-endpoint-health-checking:true
enable-pmtu-discovery:false
kvstore-opt:
cmdref:
enable-bbr:false
tunnel-protocol:vxlan
tofqdns-proxy-port:0
multicast-enabled:false
envoy-base-id:0
monitor-aggregation-interval:5s
mke-cgroup-mount:
bpf-ct-global-any-max:262144
bpf-lb-source-range-map-max:0
lib-dir:/var/lib/cilium
bpf-lb-service-backend-map-max:0
node-port-bind-protection:true
gateway-api-secrets-namespace:
label-prefix-file:
node-port-acceleration:disabled
keep-config:false
service-no-backend-response:reject
encryption-strict-mode-allow-remote-node-identities:false
proxy-xff-num-trusted-hops-ingress:0
egress-masquerade-interfaces:ens+
hubble-drop-events-reasons:auth_required,policy_denied
cni-log-file:/var/run/cilium/cilium-cni.log
nodeport-addresses:
nat-map-stats-interval:30s
debug:false
http-max-grpc-timeout:0
fixed-identity-mapping:
cilium-endpoint-gc-interval:5m0s
envoy-secrets-namespace:
enable-ingress-controller:false
tofqdns-max-deferred-connection-deletes:10000
auto-direct-node-routes:false
enable-ipv4:true
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
enable-xdp-prefilter:false
disable-external-ip-mitigation:false
metrics:
enable-well-known-identities:false
ipv4-range:auto
vlan-bpf-bypass:
enable-cilium-endpoint-slice:false
dnsproxy-concurrency-limit:0
kube-proxy-replacement-healthz-bind-address:
bpf-sock-rev-map-max:262144
k8s-service-proxy-name:
max-internal-timer-delay:0s
clustermesh-config:/var/lib/cilium/clustermesh/
monitor-aggregation-flags:all
enable-ipsec:false
vtep-endpoint:
labels:
mesh-auth-signal-backoff-duration:1s
datapath-mode:veth
hubble-recorder-storage-path:/var/run/cilium/pcaps
clustermesh-enable-endpoint-sync:false
pprof:false
cluster-pool-ipv4-mask-size:24
enable-node-selector-labels:false
ipv4-service-loopback-address:169.254.42.1
bpf-ct-timeout-service-tcp:2h13m20s
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4           STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                     
94         Disabled           Disabled          6784476    k8s:eks.amazonaws.com/component=coredns                                             10.206.0.148   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh207                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
467        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.large                                                     ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                      
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                                
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                 
                                                           reserved:host                                                                                              
675        Disabled           Disabled          6784476    k8s:eks.amazonaws.com/component=coredns                                             10.206.0.124   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh207                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
681        Disabled           Disabled          6796457    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.206.0.156   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh207                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=clustermesh-apiserver                                                                          
739        Disabled           Disabled          4          reserved:health                                                                     10.206.0.19    ready   
```

#### BPF Policy Get 94

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    111046   1275      0        
Allow    Egress      0          ANY          NONE         disabled    16867    182       0        

```


#### BPF CT List 94

```
Invalid argument: unknown type 94
```


#### Endpoint Get 94

```
[
  {
    "id": 94,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-94-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "803cf25d-07ea-472b-aaa3-3276db1830b7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-94",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:18:57.029Z",
            "success-count": 4
          },
          "uuid": "fcd883b6-1d7b-4e20-8379-83604da9099b"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-pj6q4",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:03:57.027Z",
            "success-count": 1
          },
          "uuid": "5fe08684-cc2a-458f-8273-eb55c41b2135"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-94",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:18:59.118Z",
            "success-count": 2
          },
          "uuid": "b3c2ccbe-7311-4fdb-bfef-3774ac82f2c0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (94)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:17.128Z",
            "success-count": 118
          },
          "uuid": "c644ea58-7b70-4971-a901-8e46daea73fa"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b0d26a9b8503c3d5f6bace6cadb6831fbbe690b4ea50f52affd15cccb97c31c7:eth0",
        "container-id": "b0d26a9b8503c3d5f6bace6cadb6831fbbe690b4ea50f52affd15cccb97c31c7",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-pj6q4",
        "pod-name": "kube-system/coredns-cc6ccd49c-pj6q4"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6784476,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh207",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh207",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:10:12Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.206.0.148",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "26:c8:2a:5e:76:b2",
        "interface-index": 14,
        "interface-name": "lxce0b90f4dec25",
        "mac": "c2:17:70:18:e0:24"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6784476,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6784476,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 94

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 94

```
Timestamp              Status    State                   Message
2024-10-30T08:10:12Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:10:12Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:12Z   OK        regenerating            Regenerating endpoint: 
2024-10-30T08:10:12Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:10:11Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:11Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:11Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:11Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:10Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:10Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:10Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:10Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:07:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:07:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:07:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:07:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:07:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:07:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:07:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:07:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:04:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:04:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:04:02Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:04:00Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-30T08:03:59Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T08:03:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:57Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-30T08:03:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T08:03:57Z   OK        ready                   Set identity for this endpoint
2024-10-30T08:03:57Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:57Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 6784476

```
ID        LABELS
6784476   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh207
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 467

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 467

```
Invalid argument: unknown type 467
```


#### Endpoint Get 467

```
[
  {
    "id": 467,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-467-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "20ecaab1-4fb4-4a18-add7-edb37a8e64d9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-467",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:18:56.350Z",
            "success-count": 4
          },
          "uuid": "12a7142a-7dd7-4b99-a3f5-1e0804785e04"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-467",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:18:57.437Z",
            "success-count": 2
          },
          "uuid": "a806b468-f908-48d6-9c39-2d2bc466914e"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:10:12Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "d2:0c:42:28:a9:7e",
        "interface-name": "cilium_host",
        "mac": "d2:0c:42:28:a9:7e"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 467

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 467

```
Timestamp              Status   State                   Message
2024-10-30T08:10:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:10:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:12Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:10:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:10:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:07:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:07:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:07:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:07:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:07:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:07:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:07:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:07:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:04:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:04:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:04:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:04:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-30T08:03:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T08:03:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T08:03:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:56Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T08:03:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T08:03:56Z   OK       ready                   Set identity for this endpoint
2024-10-30T08:03:56Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 675

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    111376   1280      0        
Allow    Egress      0          ANY          NONE         disabled    16521    178       0        

```


#### BPF CT List 675

```
Invalid argument: unknown type 675
```


#### Endpoint Get 675

```
[
  {
    "id": 675,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-675-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "795bb08b-280e-4b9b-847a-96365d550d45"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-675",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:18:57.100Z",
            "success-count": 4
          },
          "uuid": "7086b88d-9170-44aa-8acf-6e5afd990f00"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-npmkb",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:03:57.098Z",
            "success-count": 1
          },
          "uuid": "3094681a-de91-41ad-90d3-20744ff85d8b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-675",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:19:02.083Z",
            "success-count": 2
          },
          "uuid": "dace6337-4ce3-4cd0-a9c4-25630f1f4363"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (675)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:17.186Z",
            "success-count": 118
          },
          "uuid": "155202d2-831f-4283-9abb-9b30e6df8040"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "556c49543ce4e543e4bf21c21fe7d762f5e4b7060da8536644cf71585ae36d93:eth0",
        "container-id": "556c49543ce4e543e4bf21c21fe7d762f5e4b7060da8536644cf71585ae36d93",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-npmkb",
        "pod-name": "kube-system/coredns-cc6ccd49c-npmkb"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6784476,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh207",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh207",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:10:12Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.206.0.124",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "5e:11:78:15:98:7a",
        "interface-index": 12,
        "interface-name": "lxc87a4ece51894",
        "mac": "6a:d9:b5:ad:9c:44"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6784476,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6784476,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 675

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 675

```
Timestamp              Status   State                   Message
2024-10-30T08:10:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:10:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:12Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:10:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:10:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:07:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:07:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:07:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:07:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:07:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:07:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:07:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:07:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:04:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:04:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:04:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:04:02Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T08:04:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-30T08:03:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:57Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T08:03:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T08:03:57Z   OK       ready                   Set identity for this endpoint
2024-10-30T08:03:57Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 6784476

```
ID        LABELS
6784476   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh207
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 681

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11634344   117202    0        
Allow    Ingress     1          ANY          NONE         disabled    11924447   122977    0        
Allow    Egress      0          ANY          NONE         disabled    14473678   141303    0        

```


#### BPF CT List 681

```
Invalid argument: unknown type 681
```


#### Endpoint Get 681

```
[
  {
    "id": 681,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-681-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7107f1c8-e809-4e08-8a53-37408716a4c0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-681",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:19:57.440Z",
            "success-count": 3
          },
          "uuid": "3b548ccc-cfce-4bf5-97cb-43e8897030b8"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-969b5b85c-vvl6b",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:09:57.438Z",
            "success-count": 1
          },
          "uuid": "85b3c815-b206-4fa6-a560-dda086526b16"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-681",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:09:57.476Z",
            "success-count": 1
          },
          "uuid": "e1a4064d-b9d0-4f51-b742-cfc209cc48e9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (681)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:17.513Z",
            "success-count": 82
          },
          "uuid": "ec2d919c-9231-4619-933d-fde1cc6274ba"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "ad9cb06c640309c9fbe67b113733a3b06b42d656da3e2e49ab71dd616adc5b9f:eth0",
        "container-id": "ad9cb06c640309c9fbe67b113733a3b06b42d656da3e2e49ab71dd616adc5b9f",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-969b5b85c-vvl6b",
        "pod-name": "kube-system/clustermesh-apiserver-969b5b85c-vvl6b"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6796457,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh207",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=969b5b85c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh207",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:10:12Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.206.0.156",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "5e:0b:59:c6:ef:d0",
        "interface-index": 18,
        "interface-name": "lxca03e41ad471c",
        "mac": "de:dd:52:19:53:85"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6796457,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6796457,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 681

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 681

```
Timestamp              Status   State                   Message
2024-10-30T08:10:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:10:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:12Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:10:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:10:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:09:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T08:09:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:09:57Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T08:09:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T08:09:57Z   OK       ready                   Set identity for this endpoint
2024-10-30T08:09:57Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 6796457

```
ID        LABELS
6796457   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh207
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 739

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1649716   20856     0        
Allow    Ingress     1          ANY          NONE         disabled    17604     208       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        

```


#### BPF CT List 739

```
Invalid argument: unknown type 739
```


#### Endpoint Get 739

```
[
  {
    "id": 739,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-739-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ea49f4c9-2e6f-4bdb-a515-e17541bd6ae5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-739",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:18:57.413Z",
            "success-count": 4
          },
          "uuid": "4df08b99-095d-4a38-ac16-d25f7debe228"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-739",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:19:02.081Z",
            "success-count": 2
          },
          "uuid": "f853461f-feb8-4b4d-8bcf-c1fd344ec7cc"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:10:12Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.206.0.19",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "7e:b2:31:ab:68:f1",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "9a:5a:21:a3:1f:46"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 739

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 739

```
Timestamp              Status   State                   Message
2024-10-30T08:10:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:10:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:12Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:10:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:10:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:07:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:07:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:07:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:07:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:07:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:07:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:07:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:07:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:04:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-30T08:04:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:04:02Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-30T08:04:02Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T08:04:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-30T08:03:59Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T08:03:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T08:03:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T08:03:57Z   OK       ready                   Set identity for this endpoint
2024-10-30T08:03:56Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.145.7:443 (active)      
                                          2 => 172.31.253.52:443 (active)     
2    10.100.182.165:443    ClusterIP      1 => 172.31.164.108:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.206.0.148:53 (active)       
                                          2 => 10.206.0.124:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.206.0.148:9153 (active)     
                                          2 => 10.206.0.124:9153 (active)     
5    10.100.209.201:2379   ClusterIP      1 => 10.206.0.156:2379 (active)     
```

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 41962885                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 41962885                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 41962885                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-4014400000 rw-p 00000000 00:00 0 
4014400000-4018000000 ---p 00000000 00:00 0 
ffff3c639000-ffff3c9f2000 rw-p 00000000 00:00 0 
ffff3c9f6000-ffff3cb27000 rw-p 00000000 00:00 0 
ffff3cb2f000-ffff3cc10000 rw-p 00000000 00:00 0 
ffff3cc10000-ffff3cc51000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff3cc51000-ffff3cc92000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff3cc92000-ffff3ccd2000 rw-p 00000000 00:00 0 
ffff3ccd2000-ffff3ccd4000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff3ccd4000-ffff3ccd6000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff3ccd6000-ffff3d29d000 rw-p 00000000 00:00 0 
ffff3d29d000-ffff3d39d000 rw-p 00000000 00:00 0 
ffff3d39d000-ffff3d3ae000 rw-p 00000000 00:00 0 
ffff3d3ae000-ffff3f3ae000 rw-p 00000000 00:00 0 
ffff3f3ae000-ffff3f42e000 ---p 00000000 00:00 0 
ffff3f42e000-ffff3f42f000 rw-p 00000000 00:00 0 
ffff3f42f000-ffff5f42e000 ---p 00000000 00:00 0 
ffff5f42e000-ffff5f42f000 rw-p 00000000 00:00 0 
ffff5f42f000-ffff7f3be000 ---p 00000000 00:00 0 
ffff7f3be000-ffff7f3bf000 rw-p 00000000 00:00 0 
ffff7f3bf000-ffff833b0000 ---p 00000000 00:00 0 
ffff833b0000-ffff833b1000 rw-p 00000000 00:00 0 
ffff833b1000-ffff83bae000 ---p 00000000 00:00 0 
ffff83bae000-ffff83baf000 rw-p 00000000 00:00 0 
ffff83baf000-ffff83cae000 ---p 00000000 00:00 0 
ffff83cae000-ffff83d0e000 rw-p 00000000 00:00 0 
ffff83d0e000-ffff83d10000 r--p 00000000 00:00 0                          [vvar]
ffff83d10000-ffff83d11000 r-xp 00000000 00:00 0                          [vdso]
fffff54a7000-fffff54c8000 rw-p 00000000 00:00 0                          [stack]

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=12) "10.206.0.215": (string) (len=6) "router",
  (string) (len=11) "10.206.0.19": (string) (len=6) "health",
  (string) (len=12) "10.206.0.148": (string) (len=35) "kube-system/coredns-cc6ccd49c-pj6q4",
  (string) (len=12) "10.206.0.124": (string) (len=35) "kube-system/coredns-cc6ccd49c-npmkb",
  (string) (len=12) "10.206.0.156": (string) (len=49) "kube-system/clustermesh-apiserver-969b5b85c-vvl6b"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.164.108": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40019ca0b0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001acc8a0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001acc8a0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4000a2dd90)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4000a2de40)(frontends:[10.100.209.201]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001cd4b00)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001cd4bb0)(frontends:[10.100.182.165]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4001cd4c60)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4000225500)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40011ae410)(172.31.145.7:443/TCP,172.31.253.52:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4000225508)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-486cf": (*k8s.Endpoints)(0x40034fa270)(172.31.164.108:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4000225510)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-5ssm7": (*k8s.Endpoints)(0x40038fd450)(10.206.0.124:53/TCP[eu-west-3a],10.206.0.124:53/UDP[eu-west-3a],10.206.0.124:9153/TCP[eu-west-3a],10.206.0.148:53/TCP[eu-west-3a],10.206.0.148:53/UDP[eu-west-3a],10.206.0.148:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40015c0f08)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-pvv9w": (*k8s.Endpoints)(0x400a2d44e0)(10.206.0.156:2379/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001bc8e00)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40022599a0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400eddd920
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4002264f60,
  gcExited: (chan struct {}) 0x4002264fc0,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001dbee00)({
     ObserverVec: (*prometheus.HistogramVec)(0x40013342a0)({
      MetricVec: (*prometheus.MetricVec)(0x4002444d80)({
       metricMap: (*prometheus.metricMap)(0x4002444db0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c80ae0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001dbee80)({
     ObserverVec: (*prometheus.HistogramVec)(0x40013342a8)({
      MetricVec: (*prometheus.MetricVec)(0x4002444e10)({
       metricMap: (*prometheus.metricMap)(0x4002444e40)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c80b40)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001dbef00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40013342b0)({
      MetricVec: (*prometheus.MetricVec)(0x4002444ea0)({
       metricMap: (*prometheus.metricMap)(0x4002444ed0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c80ba0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001dbef80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40013342b8)({
      MetricVec: (*prometheus.MetricVec)(0x4002444f30)({
       metricMap: (*prometheus.metricMap)(0x4002444f60)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c80c00)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001dbf000)({
     GaugeVec: (*prometheus.GaugeVec)(0x40013342c0)({
      MetricVec: (*prometheus.MetricVec)(0x4002444fc0)({
       metricMap: (*prometheus.metricMap)(0x4002444ff0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c80c60)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001dbf080)({
     GaugeVec: (*prometheus.GaugeVec)(0x40013342c8)({
      MetricVec: (*prometheus.MetricVec)(0x4002445050)({
       metricMap: (*prometheus.metricMap)(0x4002445080)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c80cc0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001dbf100)({
     GaugeVec: (*prometheus.GaugeVec)(0x40013342d0)({
      MetricVec: (*prometheus.MetricVec)(0x40024450e0)({
       metricMap: (*prometheus.metricMap)(0x4002445110)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c80d20)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001dbf180)({
     GaugeVec: (*prometheus.GaugeVec)(0x40013342d8)({
      MetricVec: (*prometheus.MetricVec)(0x4002445170)({
       metricMap: (*prometheus.metricMap)(0x40024451a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c80d80)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001dbf200)({
     ObserverVec: (*prometheus.HistogramVec)(0x40013342e0)({
      MetricVec: (*prometheus.MetricVec)(0x4002445200)({
       metricMap: (*prometheus.metricMap)(0x4002445230)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c80de0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001bc8e00)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40003c82a0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4000e85230)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 255ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1
  }
 })
})

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.206.0.0/24, 
Allocated addresses:
  10.206.0.124 (kube-system/coredns-cc6ccd49c-npmkb)
  10.206.0.148 (kube-system/coredns-cc6ccd49c-pj6q4)
  10.206.0.156 (kube-system/clustermesh-apiserver-969b5b85c-vvl6b)
  10.206.0.19 (health)
  10.206.0.215 (router)
ClusterMesh:   255/255 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh129: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=129, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh130: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=130, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh131: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=131, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh132: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=132, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh133: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=133, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh134: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=134, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh135: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=135, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh136: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=136, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh137: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=137, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh138: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=138, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh139: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=139, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh140: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=140, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh141: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=141, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh142: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=142, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh143: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=143, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh144: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=144, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh145: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=145, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh146: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=146, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh147: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=147, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh148: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=148, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh149: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=149, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh150: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=150, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh151: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=151, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh152: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=152, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh153: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=153, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh154: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=154, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh155: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=155, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh156: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=156, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh157: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=157, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh158: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=158, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh159: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=159, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh160: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=160, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh161: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=161, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh162: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=162, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh163: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=163, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh164: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=164, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh165: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=165, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh166: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=166, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh167: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=167, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh168: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=168, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh169: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=169, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh170: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=170, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh171: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=171, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh172: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=172, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh173: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=173, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh174: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=174, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh175: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=175, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh176: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=176, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh177: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=177, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh178: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=178, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh179: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=179, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh180: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=180, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh181: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=181, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh182: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=182, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh183: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=183, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh184: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=184, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh185: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=185, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh186: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=186, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh187: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=187, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh188: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=188, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh189: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=189, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh190: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=190, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh191: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=191, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh192: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=192, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh193: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=193, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh194: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=194, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh195: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=195, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh196: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=196, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh197: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=197, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh198: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=198, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh199: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=199, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh200: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=200, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh201: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=201, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh202: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=202, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh203: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=203, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh204: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=204, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh205: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=205, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh206: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=206, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh208: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=208, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh209: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=209, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh210: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=210, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh211: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=211, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh212: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=212, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh213: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=213, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh214: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=214, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh215: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=215, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh216: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=216, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh217: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=217, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh218: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=218, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh219: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=219, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh220: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=220, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh221: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=221, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh222: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=222, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh223: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=223, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh224: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=224, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh225: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=225, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh226: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=226, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh227: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=227, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh228: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=228, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh229: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=229, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh230: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=230, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh231: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=231, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh232: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=232, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh233: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=233, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh234: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=234, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh235: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=235, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh236: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=236, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh237: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=237, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh238: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=238, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh239: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=239, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh240: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=240, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh241: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=241, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh242: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=242, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh243: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=243, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh244: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=244, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh245: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=245, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh246: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=246, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh247: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=247, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh248: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=248, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh249: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=249, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh250: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=250, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh251: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=251, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh252: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=252, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh253: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=253, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh254: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=254, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh255: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=255, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh256: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=256, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m19s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m18s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 13m17s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1babe8463afeef8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      290/290 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   29s ago        never        0       no error   
  ct-map-pressure                                                    30s ago        never        0       no error   
  daemon-validate-config                                             11s ago        never        0       no error   
  dns-garbage-collector-job                                          32s ago        never        0       no error   
  endpoint-467-regeneration-recovery                                 never          never        0       no error   
  endpoint-675-regeneration-recovery                                 never          never        0       no error   
  endpoint-681-regeneration-recovery                                 never          never        0       no error   
  endpoint-739-regeneration-recovery                                 never          never        0       no error   
  endpoint-94-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                        4m32s ago      never        0       no error   
  ep-bpf-prog-watchdog                                               30s ago        never        0       no error   
  ipcache-inject-labels                                              30s ago        never        0       no error   
  k8s-heartbeat                                                      33s ago        never        0       no error   
  link-cache                                                         15s ago        never        0       no error   
  local-identity-checkpoint                                          19m30s ago     never        0       no error   
  node-neighbor-link-updater                                         10s ago        never        0       no error   
  remote-etcd-cmesh1                                                 13m16s ago     never        0       no error   
  remote-etcd-cmesh10                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh100                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh101                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh102                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh103                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh104                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh105                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh106                                               13m17s ago     never        0       no error   
  remote-etcd-cmesh107                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh108                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh109                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh11                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh110                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh111                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh112                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh113                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh114                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh115                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh116                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh117                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh118                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh119                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh12                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh120                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh121                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh122                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh123                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh124                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh125                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh126                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh127                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh128                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh129                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh13                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh130                                               13m17s ago     never        0       no error   
  remote-etcd-cmesh131                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh132                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh133                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh134                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh135                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh136                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh137                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh138                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh139                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh14                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh140                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh141                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh142                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh143                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh144                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh145                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh146                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh147                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh148                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh149                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh15                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh150                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh151                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh152                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh153                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh154                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh155                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh156                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh157                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh158                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh159                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh16                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh160                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh161                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh162                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh163                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh164                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh165                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh166                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh167                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh168                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh169                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh17                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh170                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh171                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh172                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh173                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh174                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh175                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh176                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh177                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh178                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh179                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh18                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh180                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh181                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh182                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh183                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh184                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh185                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh186                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh187                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh188                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh189                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh19                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh190                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh191                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh192                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh193                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh194                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh195                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh196                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh197                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh198                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh199                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh2                                                 13m16s ago     never        0       no error   
  remote-etcd-cmesh20                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh200                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh201                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh202                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh203                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh204                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh205                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh206                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh208                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh209                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh21                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh210                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh211                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh212                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh213                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh214                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh215                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh216                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh217                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh218                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh219                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh22                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh220                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh221                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh222                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh223                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh224                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh225                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh226                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh227                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh228                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh229                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh23                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh230                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh231                                               13m15s ago     never        0       no error   
  remote-etcd-cmesh232                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh233                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh234                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh235                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh236                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh237                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh238                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh239                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh24                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh240                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh241                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh242                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh243                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh244                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh245                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh246                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh247                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh248                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh249                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh25                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh250                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh251                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh252                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh253                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh254                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh255                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh256                                               13m16s ago     never        0       no error   
  remote-etcd-cmesh26                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh27                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh28                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh29                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh3                                                 13m16s ago     never        0       no error   
  remote-etcd-cmesh30                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh31                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh32                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh33                                                13m15s ago     never        0       no error   
  remote-etcd-cmesh34                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh35                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh36                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh37                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh38                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh39                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh4                                                 13m16s ago     never        0       no error   
  remote-etcd-cmesh40                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh41                                                13m17s ago     never        0       no error   
  remote-etcd-cmesh42                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh43                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh44                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh45                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh46                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh47                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh48                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh49                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh5                                                 13m16s ago     never        0       no error   
  remote-etcd-cmesh50                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh51                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh52                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh53                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh54                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh55                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh56                                                13m17s ago     never        0       no error   
  remote-etcd-cmesh57                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh58                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh59                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh6                                                 13m16s ago     never        0       no error   
  remote-etcd-cmesh60                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh61                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh62                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh63                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh64                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh65                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh66                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh67                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh68                                                13m17s ago     never        0       no error   
  remote-etcd-cmesh69                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh7                                                 13m16s ago     never        0       no error   
  remote-etcd-cmesh70                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh71                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh72                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh73                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh74                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh75                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh76                                                13m17s ago     never        0       no error   
  remote-etcd-cmesh77                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh78                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh79                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh8                                                 13m16s ago     never        0       no error   
  remote-etcd-cmesh80                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh81                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh82                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh83                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh84                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh85                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh86                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh87                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh88                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh89                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh9                                                 13m16s ago     never        0       no error   
  remote-etcd-cmesh90                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh91                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh92                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh93                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh94                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh95                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh96                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh97                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh98                                                13m16s ago     never        0       no error   
  remote-etcd-cmesh99                                                13m16s ago     never        0       no error   
  resolve-identity-467                                               4m30s ago      never        0       no error   
  resolve-identity-675                                               4m29s ago      never        0       no error   
  resolve-identity-681                                               3m29s ago      never        0       no error   
  resolve-identity-739                                               4m29s ago      never        0       no error   
  resolve-identity-94                                                4m29s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-969b5b85c-vvl6b   13m29s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-npmkb                 19m29s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-pj6q4                 19m29s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                     19m30s ago     never        0       no error   
  sync-policymap-467                                                 4m29s ago      never        0       no error   
  sync-policymap-675                                                 4m24s ago      never        0       no error   
  sync-policymap-681                                                 13m29s ago     never        0       no error   
  sync-policymap-739                                                 4m24s ago      never        0       no error   
  sync-policymap-94                                                  4m27s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (675)                                   9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (681)                                   9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (94)                                    9s ago         never        0       no error   
  sync-utime                                                         30s ago        never        0       no error   
  write-cni-file                                                     19m33s ago     never        0       no error   
Proxy Status:            OK, ip 10.206.0.215, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 6782976, max 6815743
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 188.62   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Policy get

```
:
 []
Revision: 1

```

