[
  {
    "containers": [
      {
        "cgroup-id": 7619,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4f305eaa_21eb_4ab7_a312_a2123bf67c1d.slice/cri-containerd-fa9f5011d4a7a1485087ac7b1407d6773fc9cd40ebb8af0af080d57405ed133a.scope"
      }
    ],
    "ips": [
      "10.206.0.148"
    ],
    "name": "coredns-cc6ccd49c-pj6q4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3619e4c3_c1a2_4f97_a26c_bf71dc55ce73.slice/cri-containerd-67dfee514f2e20381824834b4a8647eae416f2046b3822c510cf5df0e9323965.scope"
      }
    ],
    "ips": [
      "10.206.0.124"
    ],
    "name": "coredns-cc6ccd49c-npmkb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc00cf542_ddcb_44eb_8c13_1c3786182594.slice/cri-containerd-40f0952483453d8d12da55e2331874a3325772f3a324d3618c7a2015b616bc09.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc00cf542_ddcb_44eb_8c13_1c3786182594.slice/cri-containerd-cc852652075a5b3eb9b663f3db5eea19e57374834f98760375db766260ca32ff.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc00cf542_ddcb_44eb_8c13_1c3786182594.slice/cri-containerd-44b5d516d0148952f01beba99b5295d693cdfa5b157519c93f7ee0351e4df54c.scope"
      }
    ],
    "ips": [
      "10.206.0.156"
    ],
    "name": "clustermesh-apiserver-969b5b85c-vvl6b",
    "namespace": "kube-system"
  }
]

