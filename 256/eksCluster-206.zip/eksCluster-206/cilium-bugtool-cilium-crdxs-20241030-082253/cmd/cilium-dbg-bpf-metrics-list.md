REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37854     3000523     677    bpf_overlay.c
Interface                 INGRESS     685436    137112145   1132   bpf_host.c
Success                   EGRESS      17543     1387265     1694   bpf_host.c
Success                   EGRESS      302063    37570238    1308   bpf_lxc.c
Success                   EGRESS      38909     3077758     53     encap.h
Success                   INGRESS     346838    39564367    86     l3.h
Success                   INGRESS     367673    41212273    235    trace.h
Unsupported L3 protocol   EGRESS      39        2902        1492   bpf_lxc.c
