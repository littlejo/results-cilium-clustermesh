top - 08:22:54 up 27 min,  0 users,  load average: 0.14, 0.17, 0.16
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 60.0 us, 33.3 sy,  0.0 ni,  6.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4459.4 free,   1207.6 used,   2147.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6421.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606528 397464  77796 S  66.7   5.0   0:47.14 cilium-+
    643 root      20   0 1240432  16628  11420 S   6.7   0.2   0:00.03 cilium-+
    396 root      20   0 1229744   6976   2864 S   0.0   0.1   0:01.06 cilium-+
    657 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    685 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    689 root      20   0 1228744   3656   2976 S   0.0   0.0   0:00.00 gops
    690 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    701 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    706 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    739 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
