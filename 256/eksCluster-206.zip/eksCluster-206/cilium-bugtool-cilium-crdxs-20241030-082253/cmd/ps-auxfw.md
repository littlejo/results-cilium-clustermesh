USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         657  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         643  0.0  0.2 1240432 16628 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         673  0.0  0.0   6408  1636 ?        R    08:22   0:00  \_ ps auxfw
root         674  0.0  0.2 1240432 16628 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  4.1  4.9 1606528 397464 ?      Ssl  08:03   0:47 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.0 1229744 6976 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
