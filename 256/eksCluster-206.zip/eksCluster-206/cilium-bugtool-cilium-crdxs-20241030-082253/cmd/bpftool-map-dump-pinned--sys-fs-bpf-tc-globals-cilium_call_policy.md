key: 5e 00 00 00  value: 1b 02 00 00
key: a3 02 00 00  value: 2f 02 00 00
key: a9 02 00 00  value: 82 02 00 00
key: e3 02 00 00  value: 1c 02 00 00
Found 4 elements
