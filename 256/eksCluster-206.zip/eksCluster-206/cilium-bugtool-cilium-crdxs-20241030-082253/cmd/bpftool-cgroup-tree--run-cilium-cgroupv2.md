CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod481cde00_f297_4d80_9408_d87416d88e73.slice/cri-containerd-c69373a7f4e61ecf4a5970c172127f745785c022a4a509e6f509b150e7da3598.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod481cde00_f297_4d80_9408_d87416d88e73.slice/cri-containerd-968534359c108cd8fdf05795699a4edfeb5e5f7dc26b85bc301a76bde04352f3.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4f305eaa_21eb_4ab7_a312_a2123bf67c1d.slice/cri-containerd-fa9f5011d4a7a1485087ac7b1407d6773fc9cd40ebb8af0af080d57405ed133a.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4f305eaa_21eb_4ab7_a312_a2123bf67c1d.slice/cri-containerd-b0d26a9b8503c3d5f6bace6cadb6831fbbe690b4ea50f52affd15cccb97c31c7.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0afba13e_2e6d_496f_8b8c_18231a03dc74.slice/cri-containerd-30c527ac79a31e4fe07c122218715e2015b1a08b47dfba9c3c426ee5c6ed3920.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0afba13e_2e6d_496f_8b8c_18231a03dc74.slice/cri-containerd-8f9b01190ed983844f83f8daf8b1b3889139dc785ce6eeba61324f3a8bb3f117.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3619e4c3_c1a2_4f97_a26c_bf71dc55ce73.slice/cri-containerd-556c49543ce4e543e4bf21c21fe7d762f5e4b7060da8536644cf71585ae36d93.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3619e4c3_c1a2_4f97_a26c_bf71dc55ce73.slice/cri-containerd-67dfee514f2e20381824834b4a8647eae416f2046b3822c510cf5df0e9323965.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbb13f07a_7ef1_493d_8b29_15389c887152.slice/cri-containerd-532c9a2eacb9aa001a34c0c60e2cc0d9601c3b054917bd1e866972eb2cc0eace.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbb13f07a_7ef1_493d_8b29_15389c887152.slice/cri-containerd-6f9a89d2e5450630a1e29ae4b0089fa483371ffdf179e42dfd01b3252873c338.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podae7cee5d_15dd_4190_aed8_c7f088dbb061.slice/cri-containerd-7c1ce49dead50e8d6e60a68758ff4ab06fcddf15f05d35675790d00875dc8fd6.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podae7cee5d_15dd_4190_aed8_c7f088dbb061.slice/cri-containerd-d26d230faf9c4bad9e93cdea7dd286afd09b2275b347af7f66acc560a5e3fd63.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc00cf542_ddcb_44eb_8c13_1c3786182594.slice/cri-containerd-44b5d516d0148952f01beba99b5295d693cdfa5b157519c93f7ee0351e4df54c.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc00cf542_ddcb_44eb_8c13_1c3786182594.slice/cri-containerd-40f0952483453d8d12da55e2331874a3325772f3a324d3618c7a2015b616bc09.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc00cf542_ddcb_44eb_8c13_1c3786182594.slice/cri-containerd-cc852652075a5b3eb9b663f3db5eea19e57374834f98760375db766260ca32ff.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc00cf542_ddcb_44eb_8c13_1c3786182594.slice/cri-containerd-ad9cb06c640309c9fbe67b113733a3b06b42d656da3e2e49ab71dd616adc5b9f.scope
    651      cgroup_device   multi                                          
