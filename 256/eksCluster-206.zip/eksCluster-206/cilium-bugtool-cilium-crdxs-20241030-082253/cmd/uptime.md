 08:22:54 up 27 min,  0 users,  load average: 0.14, 0.17, 0.16
