KEY             VALUE
AgentLiveness   1667761747894
UTimeOffset     3379443236328125
