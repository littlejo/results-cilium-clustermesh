filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc87a4ece51894 direct-action not_in_hw id 562 tag 07a0cf40b064dbe3 jited 
