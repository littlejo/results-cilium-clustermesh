xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 588
ens6(5) clsact/ingress cil_from_netdev-ens6 id 594
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 582
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 572
cilium_host(7) clsact/egress cil_from_host-cilium_host id 576
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 506
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 503
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 541
lxc87a4ece51894(12) clsact/ingress cil_from_container-lxc87a4ece51894 id 562
lxce0b90f4dec25(14) clsact/ingress cil_from_container-lxce0b90f4dec25 id 529
lxca03e41ad471c(18) clsact/ingress cil_from_container-lxca03e41ad471c id 647

flow_dissector:

netfilter:

