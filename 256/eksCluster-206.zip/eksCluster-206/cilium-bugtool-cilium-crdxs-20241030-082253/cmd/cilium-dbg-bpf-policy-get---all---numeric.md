Endpoint ID: 94
Path: /sys/fs/bpf/tc/globals/cilium_policy_00094

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    111046   1275      0        
Allow    Egress      0          ANY          NONE         disabled    16867    182       0        


Endpoint ID: 467
Path: /sys/fs/bpf/tc/globals/cilium_policy_00467

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 675
Path: /sys/fs/bpf/tc/globals/cilium_policy_00675

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    111376   1280      0        
Allow    Egress      0          ANY          NONE         disabled    16521    178       0        


Endpoint ID: 681
Path: /sys/fs/bpf/tc/globals/cilium_policy_00681

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11637602   117238    0        
Allow    Ingress     1          ANY          NONE         disabled    11924447   122977    0        
Allow    Egress      0          ANY          NONE         disabled    14479898   141374    0        


Endpoint ID: 739
Path: /sys/fs/bpf/tc/globals/cilium_policy_00739

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1651930   20883     0        
Allow    Ingress     1          ANY          NONE         disabled    17604     208       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


