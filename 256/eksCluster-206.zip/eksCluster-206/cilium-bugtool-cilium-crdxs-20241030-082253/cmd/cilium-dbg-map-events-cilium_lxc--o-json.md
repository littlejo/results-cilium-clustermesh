{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:56.204Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.164.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:56.204Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.167.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:56.204Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:59.117Z",
  "value": "id=94    sec_id=6784476 flags=0x0000 ifindex=14  mac=C2:17:70:18:E0:24 nodemac=26:C8:2A:5E:76:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:02.080Z",
  "value": "id=739   sec_id=4     flags=0x0000 ifindex=10  mac=9A:5A:21:A3:1F:46 nodemac=7E:B2:31:AB:68:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:02.081Z",
  "value": "id=675   sec_id=6784476 flags=0x0000 ifindex=12  mac=6A:D9:B5:AD:9C:44 nodemac=5E:11:78:15:98:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:02.141Z",
  "value": "id=94    sec_id=6784476 flags=0x0000 ifindex=14  mac=C2:17:70:18:E0:24 nodemac=26:C8:2A:5E:76:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:02.201Z",
  "value": "id=739   sec_id=4     flags=0x0000 ifindex=10  mac=9A:5A:21:A3:1F:46 nodemac=7E:B2:31:AB:68:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:02.236Z",
  "value": "id=675   sec_id=6784476 flags=0x0000 ifindex=12  mac=6A:D9:B5:AD:9C:44 nodemac=5E:11:78:15:98:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:00.646Z",
  "value": "id=94    sec_id=6784476 flags=0x0000 ifindex=14  mac=C2:17:70:18:E0:24 nodemac=26:C8:2A:5E:76:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:00.646Z",
  "value": "id=675   sec_id=6784476 flags=0x0000 ifindex=12  mac=6A:D9:B5:AD:9C:44 nodemac=5E:11:78:15:98:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:00.646Z",
  "value": "id=739   sec_id=4     flags=0x0000 ifindex=10  mac=9A:5A:21:A3:1F:46 nodemac=7E:B2:31:AB:68:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:00.679Z",
  "value": "id=3339  sec_id=6796457 flags=0x0000 ifindex=16  mac=76:37:58:AD:04:B4 nodemac=7A:09:7B:1B:2D:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:01.646Z",
  "value": "id=675   sec_id=6784476 flags=0x0000 ifindex=12  mac=6A:D9:B5:AD:9C:44 nodemac=5E:11:78:15:98:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:01.646Z",
  "value": "id=94    sec_id=6784476 flags=0x0000 ifindex=14  mac=C2:17:70:18:E0:24 nodemac=26:C8:2A:5E:76:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:01.646Z",
  "value": "id=739   sec_id=4     flags=0x0000 ifindex=10  mac=9A:5A:21:A3:1F:46 nodemac=7E:B2:31:AB:68:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:01.647Z",
  "value": "id=3339  sec_id=6796457 flags=0x0000 ifindex=16  mac=76:37:58:AD:04:B4 nodemac=7A:09:7B:1B:2D:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.475Z",
  "value": "id=681   sec_id=6796457 flags=0x0000 ifindex=18  mac=DE:DD:52:19:53:85 nodemac=5E:0B:59:C6:EF:D0"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.206.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.030Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.760Z",
  "value": "id=681   sec_id=6796457 flags=0x0000 ifindex=18  mac=DE:DD:52:19:53:85 nodemac=5E:0B:59:C6:EF:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.761Z",
  "value": "id=94    sec_id=6784476 flags=0x0000 ifindex=14  mac=C2:17:70:18:E0:24 nodemac=26:C8:2A:5E:76:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.761Z",
  "value": "id=675   sec_id=6784476 flags=0x0000 ifindex=12  mac=6A:D9:B5:AD:9C:44 nodemac=5E:11:78:15:98:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.761Z",
  "value": "id=739   sec_id=4     flags=0x0000 ifindex=10  mac=9A:5A:21:A3:1F:46 nodemac=7E:B2:31:AB:68:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.841Z",
  "value": "id=739   sec_id=4     flags=0x0000 ifindex=10  mac=9A:5A:21:A3:1F:46 nodemac=7E:B2:31:AB:68:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.844Z",
  "value": "id=681   sec_id=6796457 flags=0x0000 ifindex=18  mac=DE:DD:52:19:53:85 nodemac=5E:0B:59:C6:EF:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.845Z",
  "value": "id=94    sec_id=6784476 flags=0x0000 ifindex=14  mac=C2:17:70:18:E0:24 nodemac=26:C8:2A:5E:76:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.850Z",
  "value": "id=675   sec_id=6784476 flags=0x0000 ifindex=12  mac=6A:D9:B5:AD:9C:44 nodemac=5E:11:78:15:98:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.820Z",
  "value": "id=675   sec_id=6784476 flags=0x0000 ifindex=12  mac=6A:D9:B5:AD:9C:44 nodemac=5E:11:78:15:98:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.820Z",
  "value": "id=94    sec_id=6784476 flags=0x0000 ifindex=14  mac=C2:17:70:18:E0:24 nodemac=26:C8:2A:5E:76:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.820Z",
  "value": "id=739   sec_id=4     flags=0x0000 ifindex=10  mac=9A:5A:21:A3:1F:46 nodemac=7E:B2:31:AB:68:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.821Z",
  "value": "id=681   sec_id=6796457 flags=0x0000 ifindex=18  mac=DE:DD:52:19:53:85 nodemac=5E:0B:59:C6:EF:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.820Z",
  "value": "id=739   sec_id=4     flags=0x0000 ifindex=10  mac=9A:5A:21:A3:1F:46 nodemac=7E:B2:31:AB:68:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.821Z",
  "value": "id=94    sec_id=6784476 flags=0x0000 ifindex=14  mac=C2:17:70:18:E0:24 nodemac=26:C8:2A:5E:76:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.821Z",
  "value": "id=681   sec_id=6796457 flags=0x0000 ifindex=18  mac=DE:DD:52:19:53:85 nodemac=5E:0B:59:C6:EF:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.206.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.821Z",
  "value": "id=675   sec_id=6784476 flags=0x0000 ifindex=12  mac=6A:D9:B5:AD:9C:44 nodemac=5E:11:78:15:98:7A"
}

