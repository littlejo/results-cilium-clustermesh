IP ADDRESS         LOCAL ENDPOINT INFO
172.31.167.109:0   (localhost)                                                                                        
172.31.164.108:0   (localhost)                                                                                        
10.206.0.19:0      id=739   sec_id=4     flags=0x0000 ifindex=10  mac=9A:5A:21:A3:1F:46 nodemac=7E:B2:31:AB:68:F1     
10.206.0.148:0     id=94    sec_id=6784476 flags=0x0000 ifindex=14  mac=C2:17:70:18:E0:24 nodemac=26:C8:2A:5E:76:B2   
10.206.0.124:0     id=675   sec_id=6784476 flags=0x0000 ifindex=12  mac=6A:D9:B5:AD:9C:44 nodemac=5E:11:78:15:98:7A   
10.206.0.215:0     (localhost)                                                                                        
10.206.0.156:0     id=681   sec_id=6796457 flags=0x0000 ifindex=18  mac=DE:DD:52:19:53:85 nodemac=5E:0B:59:C6:EF:D0   
