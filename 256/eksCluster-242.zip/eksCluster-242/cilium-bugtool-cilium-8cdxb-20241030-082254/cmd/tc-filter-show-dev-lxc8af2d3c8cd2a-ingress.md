filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc8af2d3c8cd2a direct-action not_in_hw id 574 tag b5cd39a5a3a78b7e jited 
