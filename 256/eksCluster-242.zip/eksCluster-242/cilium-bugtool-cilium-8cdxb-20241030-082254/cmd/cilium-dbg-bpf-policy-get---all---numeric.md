Endpoint ID: 625
Path: /sys/fs/bpf/tc/globals/cilium_policy_00625

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    109433   1254      0        
Allow    Egress      0          ANY          NONE         disabled    16877    182       0        


Endpoint ID: 815
Path: /sys/fs/bpf/tc/globals/cilium_policy_00815

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1593654   20127     0        
Allow    Ingress     1          ANY          NONE         disabled    16448     191       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 966
Path: /sys/fs/bpf/tc/globals/cilium_policy_00966

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    108971   1247      0        
Allow    Egress      0          ANY          NONE         disabled    15871    171       0        


Endpoint ID: 1984
Path: /sys/fs/bpf/tc/globals/cilium_policy_01984

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2809
Path: /sys/fs/bpf/tc/globals/cilium_policy_02809

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    10091728   101428    0        
Allow    Ingress     1          ANY          NONE         disabled    8314296    86181     0        
Allow    Egress      0          ANY          NONE         disabled    9412595    97725     0        


