key: 71 02 00 00  value: 40 02 00 00
key: 2f 03 00 00  value: 44 02 00 00
key: c6 03 00 00  value: 06 02 00 00
key: f9 0a 00 00  value: 7f 02 00 00
Found 4 elements
