KEY             VALUE
AgentLiveness   1697194525062
UTimeOffset     3379443128906250
