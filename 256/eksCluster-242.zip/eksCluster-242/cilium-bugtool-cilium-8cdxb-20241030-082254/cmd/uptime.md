 08:22:54 up 28 min,  0 users,  load average: 0.20, 0.19, 0.12
