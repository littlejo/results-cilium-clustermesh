{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:33.635Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.167.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:33.635Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.167.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:33.635Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:38.075Z",
  "value": "id=966   sec_id=7983024 flags=0x0000 ifindex=12  mac=62:04:03:E0:BA:6D nodemac=0E:34:6D:BC:30:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:38.075Z",
  "value": "id=815   sec_id=4     flags=0x0000 ifindex=10  mac=16:C5:0C:71:62:A2 nodemac=72:9C:09:A4:51:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:38.136Z",
  "value": "id=625   sec_id=7983024 flags=0x0000 ifindex=14  mac=6A:0D:1A:08:7D:49 nodemac=E6:69:17:64:A1:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:38.159Z",
  "value": "id=815   sec_id=4     flags=0x0000 ifindex=10  mac=16:C5:0C:71:62:A2 nodemac=72:9C:09:A4:51:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:20.846Z",
  "value": "id=815   sec_id=4     flags=0x0000 ifindex=10  mac=16:C5:0C:71:62:A2 nodemac=72:9C:09:A4:51:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:20.847Z",
  "value": "id=625   sec_id=7983024 flags=0x0000 ifindex=14  mac=6A:0D:1A:08:7D:49 nodemac=E6:69:17:64:A1:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:20.847Z",
  "value": "id=966   sec_id=7983024 flags=0x0000 ifindex=12  mac=62:04:03:E0:BA:6D nodemac=0E:34:6D:BC:30:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:20.874Z",
  "value": "id=828   sec_id=7989567 flags=0x0000 ifindex=16  mac=02:FF:E0:1E:46:ED nodemac=06:79:44:F7:3A:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:21.847Z",
  "value": "id=815   sec_id=4     flags=0x0000 ifindex=10  mac=16:C5:0C:71:62:A2 nodemac=72:9C:09:A4:51:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:21.847Z",
  "value": "id=828   sec_id=7989567 flags=0x0000 ifindex=16  mac=02:FF:E0:1E:46:ED nodemac=06:79:44:F7:3A:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:21.847Z",
  "value": "id=625   sec_id=7983024 flags=0x0000 ifindex=14  mac=6A:0D:1A:08:7D:49 nodemac=E6:69:17:64:A1:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:21.847Z",
  "value": "id=966   sec_id=7983024 flags=0x0000 ifindex=12  mac=62:04:03:E0:BA:6D nodemac=0E:34:6D:BC:30:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:22.129Z",
  "value": "id=2809  sec_id=7989567 flags=0x0000 ifindex=18  mac=2A:9F:B4:67:6A:3C nodemac=56:8B:0D:4F:EE:A8"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.242.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.529Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:38.352Z",
  "value": "id=2809  sec_id=7989567 flags=0x0000 ifindex=18  mac=2A:9F:B4:67:6A:3C nodemac=56:8B:0D:4F:EE:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:38.354Z",
  "value": "id=815   sec_id=4     flags=0x0000 ifindex=10  mac=16:C5:0C:71:62:A2 nodemac=72:9C:09:A4:51:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:38.354Z",
  "value": "id=966   sec_id=7983024 flags=0x0000 ifindex=12  mac=62:04:03:E0:BA:6D nodemac=0E:34:6D:BC:30:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:38.355Z",
  "value": "id=625   sec_id=7983024 flags=0x0000 ifindex=14  mac=6A:0D:1A:08:7D:49 nodemac=E6:69:17:64:A1:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:39.404Z",
  "value": "id=815   sec_id=4     flags=0x0000 ifindex=10  mac=16:C5:0C:71:62:A2 nodemac=72:9C:09:A4:51:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:39.405Z",
  "value": "id=966   sec_id=7983024 flags=0x0000 ifindex=12  mac=62:04:03:E0:BA:6D nodemac=0E:34:6D:BC:30:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:39.405Z",
  "value": "id=625   sec_id=7983024 flags=0x0000 ifindex=14  mac=6A:0D:1A:08:7D:49 nodemac=E6:69:17:64:A1:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:39.405Z",
  "value": "id=2809  sec_id=7989567 flags=0x0000 ifindex=18  mac=2A:9F:B4:67:6A:3C nodemac=56:8B:0D:4F:EE:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:40.308Z",
  "value": "id=815   sec_id=4     flags=0x0000 ifindex=10  mac=16:C5:0C:71:62:A2 nodemac=72:9C:09:A4:51:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:40.309Z",
  "value": "id=966   sec_id=7983024 flags=0x0000 ifindex=12  mac=62:04:03:E0:BA:6D nodemac=0E:34:6D:BC:30:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:40.309Z",
  "value": "id=2809  sec_id=7989567 flags=0x0000 ifindex=18  mac=2A:9F:B4:67:6A:3C nodemac=56:8B:0D:4F:EE:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:40.309Z",
  "value": "id=625   sec_id=7983024 flags=0x0000 ifindex=14  mac=6A:0D:1A:08:7D:49 nodemac=E6:69:17:64:A1:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:41.309Z",
  "value": "id=2809  sec_id=7989567 flags=0x0000 ifindex=18  mac=2A:9F:B4:67:6A:3C nodemac=56:8B:0D:4F:EE:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:41.309Z",
  "value": "id=966   sec_id=7983024 flags=0x0000 ifindex=12  mac=62:04:03:E0:BA:6D nodemac=0E:34:6D:BC:30:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:41.309Z",
  "value": "id=815   sec_id=4     flags=0x0000 ifindex=10  mac=16:C5:0C:71:62:A2 nodemac=72:9C:09:A4:51:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.242.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:41.309Z",
  "value": "id=625   sec_id=7983024 flags=0x0000 ifindex=14  mac=6A:0D:1A:08:7D:49 nodemac=E6:69:17:64:A1:A5"
}

