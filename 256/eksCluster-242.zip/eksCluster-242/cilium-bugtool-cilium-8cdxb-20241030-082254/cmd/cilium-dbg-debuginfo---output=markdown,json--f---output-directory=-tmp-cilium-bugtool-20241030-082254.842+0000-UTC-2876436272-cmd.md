markdown output at /tmp/cilium-bugtool-20241030-082254.842+0000-UTC-2876436272/cmd/cilium-debuginfo-20241030-082257.48+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082254.842+0000-UTC-2876436272/cmd/cilium-debuginfo-20241030-082257.48+0000-UTC.json
