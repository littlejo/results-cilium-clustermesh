[
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7317393b_ee66_44c6_a615_a64f8aa085d0.slice/cri-containerd-3fe0ccb83799a6282a71c99242bce0a77b50863485517be916b4598313fbf2bb.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7317393b_ee66_44c6_a615_a64f8aa085d0.slice/cri-containerd-57d2bd93c00997b92cb623b0722b628c6c184eb3aa49bbf8faacba584ceea18f.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7317393b_ee66_44c6_a615_a64f8aa085d0.slice/cri-containerd-07642cb0bccb4c2b83d73a5fe8c7c98365abf9a8fc84468a96a07706d70b3394.scope"
      }
    ],
    "ips": [
      "10.242.0.220"
    ],
    "name": "clustermesh-apiserver-779754b69f-258jm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7746,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a64787d_df7f_4131_aaa1_1d3d6e4f62f0.slice/cri-containerd-c0b1ba7b4e74eea6b41f89551eadffced0d5594344c83d6564be8183643f96d7.scope"
      }
    ],
    "ips": [
      "10.242.0.95"
    ],
    "name": "coredns-cc6ccd49c-vxxzn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7830,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d497a2e_bf4a_45d9_9ec8_54151ace5f3e.slice/cri-containerd-108768713bdfd7828b0ab62225dade13f26c85290f88df8cd89d2be5175643b2.scope"
      }
    ],
    "ips": [
      "10.242.0.37"
    ],
    "name": "coredns-cc6ccd49c-nfq5v",
    "namespace": "kube-system"
  }
]

