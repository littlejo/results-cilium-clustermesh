USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         606  0.0  0.2 1240432 16196 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         621  0.0  0.0   6408  1648 ?        R    08:22   0:00  \_ ps auxfw
root         622  0.0  0.2 1240432 16196 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  3.1  4.7 1606336 381268 ?      Ssl  08:03   0:36 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.1 1229488 8236 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
