ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.179.61:443 (active)     
                                         2 => 172.31.239.188:443 (active)    
2    10.100.162.166:443   ClusterIP      1 => 172.31.167.121:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.242.0.95:53 (active)        
                                         2 => 10.242.0.37:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.242.0.95:9153 (active)      
                                         2 => 10.242.0.37:9153 (active)      
5    10.100.231.7:2379    ClusterIP      1 => 10.242.0.220:2379 (active)     
