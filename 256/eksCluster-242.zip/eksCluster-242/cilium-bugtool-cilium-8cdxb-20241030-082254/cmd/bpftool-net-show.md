xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 550
ens6(5) clsact/ingress cil_from_netdev-ens6 id 556
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 543
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 532
cilium_host(7) clsact/egress cil_from_host-cilium_host id 535
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 572
lxc97daa8dcf9be(12) clsact/ingress cil_from_container-lxc97daa8dcf9be id 530
lxc8af2d3c8cd2a(14) clsact/ingress cil_from_container-lxc8af2d3c8cd2a id 574
lxcd96fa5fd0c72(18) clsact/ingress cil_from_container-lxcd96fa5fd0c72 id 647

flow_dissector:

netfilter:

