REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     31798     2513740     677    bpf_overlay.c
Interface                 INGRESS     552697    120212011   1132   bpf_host.c
Success                   EGRESS      12373     968334      1694   bpf_host.c
Success                   EGRESS      235190    29433495    1308   bpf_lxc.c
Success                   EGRESS      30064     2385408     53     encap.h
Success                   INGRESS     271837    29835294    86     l3.h
Success                   INGRESS     291912    31424676    235    trace.h
Unsupported L3 protocol   EGRESS      40        2992        1492   bpf_lxc.c
