CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod72484815_d4cb_4a07_977e_53de59006283.slice/cri-containerd-a2525e2c83c8396ae5633a2fb212b67129de648f43839585b44680aea09e7735.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod72484815_d4cb_4a07_977e_53de59006283.slice/cri-containerd-308926fd69abb0705ec3f17bb371d70ab7b33ee6e36583661fa7b0cd14cc5ce3.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d497a2e_bf4a_45d9_9ec8_54151ace5f3e.slice/cri-containerd-108768713bdfd7828b0ab62225dade13f26c85290f88df8cd89d2be5175643b2.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d497a2e_bf4a_45d9_9ec8_54151ace5f3e.slice/cri-containerd-20842aa4ab52f16327957728bf224439f818de8015fc1d5989132349518490de.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a64787d_df7f_4131_aaa1_1d3d6e4f62f0.slice/cri-containerd-cafcee817aa8a0ef26972fbe196981965b66785754b6b6e68fde67e66de44f88.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a64787d_df7f_4131_aaa1_1d3d6e4f62f0.slice/cri-containerd-c0b1ba7b4e74eea6b41f89551eadffced0d5594344c83d6564be8183643f96d7.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ac58511_ed52_451a_9bf8_94d1d4cad7ac.slice/cri-containerd-bec92815ead44819d060cb9d2249778a2450e7ee9e54c41b6ac770c7c813d175.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ac58511_ed52_451a_9bf8_94d1d4cad7ac.slice/cri-containerd-e6118935e8bc1590defceca2d36112836346de7ffd7d1f5e76281a685a156791.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7317393b_ee66_44c6_a615_a64f8aa085d0.slice/cri-containerd-3fe0ccb83799a6282a71c99242bce0a77b50863485517be916b4598313fbf2bb.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7317393b_ee66_44c6_a615_a64f8aa085d0.slice/cri-containerd-07642cb0bccb4c2b83d73a5fe8c7c98365abf9a8fc84468a96a07706d70b3394.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7317393b_ee66_44c6_a615_a64f8aa085d0.slice/cri-containerd-57d2bd93c00997b92cb623b0722b628c6c184eb3aa49bbf8faacba584ceea18f.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7317393b_ee66_44c6_a615_a64f8aa085d0.slice/cri-containerd-45b59da3c7911c6d1579797ef07c6ac51487b371ecf6353c3ff305204e296915.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf7c9ea75_8225_4d1f_8a07_8680f1052c2a.slice/cri-containerd-480296812aacffae1b55234d87d821e97eedacb1c4a0e3de932a5c567811682a.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf7c9ea75_8225_4d1f_8a07_8680f1052c2a.slice/cri-containerd-a4edf2a1755e90e3584c505b9fc1e4c0e41cf3936db78c0fe29e2f8fcd4e406e.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc6355c56_3c97_4a20_95c5_bfeb8f82aa72.slice/cri-containerd-251f147ef97fd052f312565320b8064d5f6d87c8baad97a2650025e29ab45f9b.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc6355c56_3c97_4a20_95c5_bfeb8f82aa72.slice/cri-containerd-6f43344ec023a5025cf41a227cb10578b66b17636dafc9e00c287d3e0c33a8b4.scope
    99       cgroup_device   multi                                          
