IP ADDRESS         LOCAL ENDPOINT INFO
10.242.0.37:0      id=625   sec_id=7983024 flags=0x0000 ifindex=14  mac=6A:0D:1A:08:7D:49 nodemac=E6:69:17:64:A1:A5   
172.31.167.121:0   (localhost)                                                                                        
10.242.0.95:0      id=966   sec_id=7983024 flags=0x0000 ifindex=12  mac=62:04:03:E0:BA:6D nodemac=0E:34:6D:BC:30:B8   
10.242.0.232:0     (localhost)                                                                                        
10.242.0.160:0     id=815   sec_id=4     flags=0x0000 ifindex=10  mac=16:C5:0C:71:62:A2 nodemac=72:9C:09:A4:51:9F     
10.242.0.220:0     id=2809  sec_id=7989567 flags=0x0000 ifindex=18  mac=2A:9F:B4:67:6A:3C nodemac=56:8B:0D:4F:EE:A8   
172.31.167.221:0   (localhost)                                                                                        
