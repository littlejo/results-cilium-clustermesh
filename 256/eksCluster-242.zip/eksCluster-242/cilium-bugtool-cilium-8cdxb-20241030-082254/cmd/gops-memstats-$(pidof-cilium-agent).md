alloc: 208.11MB (218222064 bytes)
total-alloc: 2.02GB (2165169272 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 59644667
frees: 57350487
heap-alloc: 208.11MB (218222064 bytes)
heap-sys: 243.34MB (255164416 bytes)
heap-idle: 13.62MB (14278656 bytes)
heap-in-use: 229.73MB (240885760 bytes)
heap-released: 960.00KB (983040 bytes)
heap-objects: 2294180
stack-in-use: 68.25MB (71565312 bytes)
stack-sys: 68.25MB (71565312 bytes)
stack-mspan-inuse: 3.67MB (3845120 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.22MB (1282449 bytes)
gc-sys: 6.36MB (6673896 bytes)
next-gc: when heap-alloc >= 210.36MB (220579288 bytes)
last-gc: 2024-10-30 08:21:54.228474765 +0000 UTC
gc-pause-total: 20.795058ms
gc-pause: 140131
gc-pause-end: 1730276514228474765
num-gc: 79
num-forced-gc: 0
gc-cpu-fraction: 0.00046312023988320127
enable-gc: true
debug-gc: false
