CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e27fba0_a3de_4a29_8b22_e5276cd67a58.slice/cri-containerd-ccc50cb493fd79dc3ff2ffc54967bbe391a120213818fa96c7edfdc8c0ec2226.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e27fba0_a3de_4a29_8b22_e5276cd67a58.slice/cri-containerd-8a0508ff010553ea1a4629b31cd97f51566c4378b408e0403f0d25d7c52a89a9.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod261b258c_3682_4cad_bf6e_7f595bac2e29.slice/cri-containerd-7802ea9fefc64f1fa51af2379621a20c92542737a22dc91d9278dc20920a8d8f.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod261b258c_3682_4cad_bf6e_7f595bac2e29.slice/cri-containerd-c5d2c25a974cbce3dfadd36f43798f8ee58d96941a8c4ab180bcf609e8426841.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd5c01347_7011_40ba_8e5e_6148d6ff18cb.slice/cri-containerd-f421c795b0befa7ee2368d50976cca29edc16025303717b25ccc4d5629d33f1b.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd5c01347_7011_40ba_8e5e_6148d6ff18cb.slice/cri-containerd-618ce03f0e33a356302864c97b2893b4e1ceda0bf2640174add3a6dad2c668fd.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode13d74bd_ee7a_4d2b_8ff7_aad8493e6190.slice/cri-containerd-937a3f0fa4f4bc4226f289e8a36b94be82f27e5528eddb944cde935bea2d74ea.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode13d74bd_ee7a_4d2b_8ff7_aad8493e6190.slice/cri-containerd-ea4caef5d0617901c0f639b0a134ba859e20cc86d80da677724efa54a8070b7a.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod98d29b6c_7a9f_4101_8470_6c8b098efc73.slice/cri-containerd-add1c9da6a6d03189f1f80feaa0bc7590b90fd1a29e649582d7eb3a322943a73.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod98d29b6c_7a9f_4101_8470_6c8b098efc73.slice/cri-containerd-3eb0066f6d44757f4860b9b41886f823bb2cb00560f4472a8e1ab514512ce737.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod98d29b6c_7a9f_4101_8470_6c8b098efc73.slice/cri-containerd-ac1251b1b3e5e2eba5cae96a3217f912200a02ee621c06c02bf755409add847c.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod98d29b6c_7a9f_4101_8470_6c8b098efc73.slice/cri-containerd-8545023c4837f20f84e9a0b7ee15ba2309b66dfc62db01bf51d60ee7cfa34edb.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod455bb20b_7c1a_47b4_8ab8_c1fb59398f7d.slice/cri-containerd-40f58d88fc339b7e61a0209194cf1b3a536d8ab1d54b320f53e279a19ba69137.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod455bb20b_7c1a_47b4_8ab8_c1fb59398f7d.slice/cri-containerd-4d8ed6faa77570cac890b726ba4d9a31570abc8d37be8bd9b54421de3079efe0.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod344e38cb_0e84_4450_bb99_03792f503e17.slice/cri-containerd-7baa83fb4e0e01b4560b4c03ad9d309ba5b09c473df732f9e89ab690c339e532.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod344e38cb_0e84_4450_bb99_03792f503e17.slice/cri-containerd-ee58ec8ac806255f13bf493303de5d6bfa294bb860c9bb93a84a0911321b3994.scope
    109      cgroup_device   multi                                          
