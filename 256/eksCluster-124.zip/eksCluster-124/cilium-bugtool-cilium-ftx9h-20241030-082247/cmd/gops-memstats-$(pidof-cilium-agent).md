alloc: 135.78MB (142380088 bytes)
total-alloc: 2.24GB (2403571952 bytes)
sys: 328.96MB (344936804 bytes)
lookups: 0
mallocs: 63158657
frees: 61872133
heap-alloc: 135.78MB (142380088 bytes)
heap-sys: 251.38MB (263593984 bytes)
heap-idle: 80.54MB (84451328 bytes)
heap-in-use: 170.84MB (179142656 bytes)
heap-released: 6.18MB (6479872 bytes)
heap-objects: 1286524
stack-in-use: 64.59MB (67731456 bytes)
stack-sys: 64.59MB (67731456 bytes)
stack-mspan-inuse: 2.90MB (3044960 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 978.03KB (1001505 bytes)
gc-sys: 6.19MB (6491648 bytes)
next-gc: when heap-alloc >= 216.61MB (227134040 bytes)
last-gc: 2024-10-30 08:23:03.841873113 +0000 UTC
gc-pause-total: 16.889743ms
gc-pause: 293366
gc-pause-end: 1730276583841873113
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0004071253806434965
enable-gc: true
debug-gc: false
