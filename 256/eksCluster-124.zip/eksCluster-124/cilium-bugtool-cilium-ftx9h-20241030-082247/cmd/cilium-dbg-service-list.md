ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.155.175:443 (active)   
                                         2 => 172.31.245.249:443 (active)   
2    10.100.137.60:443    ClusterIP      1 => 172.31.149.67:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.124.0.31:53 (active)       
                                         2 => 10.124.0.125:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.124.0.31:9153 (active)     
                                         2 => 10.124.0.125:9153 (active)    
5    10.100.17.207:2379   ClusterIP      1 => 10.124.0.21:2379 (active)     
