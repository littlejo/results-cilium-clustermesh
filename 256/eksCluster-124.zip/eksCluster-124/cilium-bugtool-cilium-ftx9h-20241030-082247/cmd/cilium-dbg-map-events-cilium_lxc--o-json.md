{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:07.366Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.149.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:07.366Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.154.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:07.366Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:12.435Z",
  "value": "id=1729  sec_id=4     flags=0x0000 ifindex=10  mac=96:11:3F:2C:63:AA nodemac=CA:C6:D3:40:9A:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:12.436Z",
  "value": "id=851   sec_id=4101041 flags=0x0000 ifindex=12  mac=72:94:92:56:1E:97 nodemac=E6:90:09:9A:2C:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:12.511Z",
  "value": "id=1729  sec_id=4     flags=0x0000 ifindex=10  mac=96:11:3F:2C:63:AA nodemac=CA:C6:D3:40:9A:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:12.512Z",
  "value": "id=851   sec_id=4101041 flags=0x0000 ifindex=12  mac=72:94:92:56:1E:97 nodemac=E6:90:09:9A:2C:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:12.518Z",
  "value": "id=111   sec_id=4101041 flags=0x0000 ifindex=14  mac=66:85:2A:C1:81:5A nodemac=B2:FC:F1:4C:72:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:57.670Z",
  "value": "id=1729  sec_id=4     flags=0x0000 ifindex=10  mac=96:11:3F:2C:63:AA nodemac=CA:C6:D3:40:9A:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:57.670Z",
  "value": "id=851   sec_id=4101041 flags=0x0000 ifindex=12  mac=72:94:92:56:1E:97 nodemac=E6:90:09:9A:2C:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:57.671Z",
  "value": "id=111   sec_id=4101041 flags=0x0000 ifindex=14  mac=66:85:2A:C1:81:5A nodemac=B2:FC:F1:4C:72:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:57.702Z",
  "value": "id=2762  sec_id=4116823 flags=0x0000 ifindex=16  mac=CA:F7:1D:BF:68:FA nodemac=7A:66:AA:E9:1F:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:58.671Z",
  "value": "id=2762  sec_id=4116823 flags=0x0000 ifindex=16  mac=CA:F7:1D:BF:68:FA nodemac=7A:66:AA:E9:1F:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:58.671Z",
  "value": "id=851   sec_id=4101041 flags=0x0000 ifindex=12  mac=72:94:92:56:1E:97 nodemac=E6:90:09:9A:2C:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:58.671Z",
  "value": "id=111   sec_id=4101041 flags=0x0000 ifindex=14  mac=66:85:2A:C1:81:5A nodemac=B2:FC:F1:4C:72:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:58.671Z",
  "value": "id=1729  sec_id=4     flags=0x0000 ifindex=10  mac=96:11:3F:2C:63:AA nodemac=CA:C6:D3:40:9A:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.979Z",
  "value": "id=83    sec_id=4116823 flags=0x0000 ifindex=18  mac=5E:FB:4D:BE:70:8C nodemac=56:96:A7:F6:B4:37"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.124.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:36.282Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.915Z",
  "value": "id=83    sec_id=4116823 flags=0x0000 ifindex=18  mac=5E:FB:4D:BE:70:8C nodemac=56:96:A7:F6:B4:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.917Z",
  "value": "id=1729  sec_id=4     flags=0x0000 ifindex=10  mac=96:11:3F:2C:63:AA nodemac=CA:C6:D3:40:9A:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.917Z",
  "value": "id=851   sec_id=4101041 flags=0x0000 ifindex=12  mac=72:94:92:56:1E:97 nodemac=E6:90:09:9A:2C:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.932Z",
  "value": "id=111   sec_id=4101041 flags=0x0000 ifindex=14  mac=66:85:2A:C1:81:5A nodemac=B2:FC:F1:4C:72:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.917Z",
  "value": "id=851   sec_id=4101041 flags=0x0000 ifindex=12  mac=72:94:92:56:1E:97 nodemac=E6:90:09:9A:2C:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.918Z",
  "value": "id=111   sec_id=4101041 flags=0x0000 ifindex=14  mac=66:85:2A:C1:81:5A nodemac=B2:FC:F1:4C:72:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.919Z",
  "value": "id=83    sec_id=4116823 flags=0x0000 ifindex=18  mac=5E:FB:4D:BE:70:8C nodemac=56:96:A7:F6:B4:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.919Z",
  "value": "id=1729  sec_id=4     flags=0x0000 ifindex=10  mac=96:11:3F:2C:63:AA nodemac=CA:C6:D3:40:9A:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.915Z",
  "value": "id=1729  sec_id=4     flags=0x0000 ifindex=10  mac=96:11:3F:2C:63:AA nodemac=CA:C6:D3:40:9A:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.915Z",
  "value": "id=83    sec_id=4116823 flags=0x0000 ifindex=18  mac=5E:FB:4D:BE:70:8C nodemac=56:96:A7:F6:B4:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.916Z",
  "value": "id=851   sec_id=4101041 flags=0x0000 ifindex=12  mac=72:94:92:56:1E:97 nodemac=E6:90:09:9A:2C:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.916Z",
  "value": "id=111   sec_id=4101041 flags=0x0000 ifindex=14  mac=66:85:2A:C1:81:5A nodemac=B2:FC:F1:4C:72:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.916Z",
  "value": "id=1729  sec_id=4     flags=0x0000 ifindex=10  mac=96:11:3F:2C:63:AA nodemac=CA:C6:D3:40:9A:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.916Z",
  "value": "id=83    sec_id=4116823 flags=0x0000 ifindex=18  mac=5E:FB:4D:BE:70:8C nodemac=56:96:A7:F6:B4:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.917Z",
  "value": "id=111   sec_id=4101041 flags=0x0000 ifindex=14  mac=66:85:2A:C1:81:5A nodemac=B2:FC:F1:4C:72:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.917Z",
  "value": "id=851   sec_id=4101041 flags=0x0000 ifindex=12  mac=72:94:92:56:1E:97 nodemac=E6:90:09:9A:2C:1F"
}

