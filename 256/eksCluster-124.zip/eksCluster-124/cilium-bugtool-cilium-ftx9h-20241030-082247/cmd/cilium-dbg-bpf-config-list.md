KEY             VALUE
AgentLiveness   2107933601271
UTimeOffset     3379442367187500
