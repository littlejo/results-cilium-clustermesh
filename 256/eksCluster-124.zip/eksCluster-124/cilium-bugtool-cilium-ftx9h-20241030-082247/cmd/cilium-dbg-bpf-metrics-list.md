REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35293     2791930     677    bpf_overlay.c
Interface                 INGRESS     631876    131192678   1132   bpf_host.c
Success                   EGRESS      15250     1196566     1694   bpf_host.c
Success                   EGRESS      266160    33472532    1308   bpf_lxc.c
Success                   EGRESS      34845     2757854     53     encap.h
Success                   INGRESS     307284    34618297    86     l3.h
Success                   INGRESS     327978    36257707    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
