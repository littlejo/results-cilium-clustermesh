Endpoint ID: 83
Path: /sys/fs/bpf/tc/globals/cilium_policy_00083

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11399157   112866    0        
Allow    Ingress     1          ANY          NONE         disabled    9594782    100606    0        
Allow    Egress      0          ANY          NONE         disabled    12193421   120406    0        


Endpoint ID: 111
Path: /sys/fs/bpf/tc/globals/cilium_policy_00111

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    155326   1782      0        
Allow    Egress      0          ANY          NONE         disabled    19889    221       0        


Endpoint ID: 851
Path: /sys/fs/bpf/tc/globals/cilium_policy_00851

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    155713   1783      0        
Allow    Egress      0          ANY          NONE         disabled    19236    214       0        


Endpoint ID: 877
Path: /sys/fs/bpf/tc/globals/cilium_policy_00877

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1729
Path: /sys/fs/bpf/tc/globals/cilium_policy_01729

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1641749   20725     0        
Allow    Ingress     1          ANY          NONE         disabled    22272     255       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


