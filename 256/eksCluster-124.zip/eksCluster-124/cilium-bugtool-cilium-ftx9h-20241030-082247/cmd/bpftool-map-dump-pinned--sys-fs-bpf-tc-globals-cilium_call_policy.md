key: 53 00 00 00  value: 6a 02 00 00
key: 6f 00 00 00  value: 1c 02 00 00
key: 53 03 00 00  value: 07 02 00 00
key: c1 06 00 00  value: 29 02 00 00
Found 4 elements
