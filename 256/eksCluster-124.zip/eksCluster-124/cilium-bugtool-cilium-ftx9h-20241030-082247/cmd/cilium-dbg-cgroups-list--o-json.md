[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd5c01347_7011_40ba_8e5e_6148d6ff18cb.slice/cri-containerd-f421c795b0befa7ee2368d50976cca29edc16025303717b25ccc4d5629d33f1b.scope"
      }
    ],
    "ips": [
      "10.124.0.125"
    ],
    "name": "coredns-cc6ccd49c-5sfw7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod261b258c_3682_4cad_bf6e_7f595bac2e29.slice/cri-containerd-7802ea9fefc64f1fa51af2379621a20c92542737a22dc91d9278dc20920a8d8f.scope"
      }
    ],
    "ips": [
      "10.124.0.31"
    ],
    "name": "coredns-cc6ccd49c-nhpbs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod98d29b6c_7a9f_4101_8470_6c8b098efc73.slice/cri-containerd-add1c9da6a6d03189f1f80feaa0bc7590b90fd1a29e649582d7eb3a322943a73.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod98d29b6c_7a9f_4101_8470_6c8b098efc73.slice/cri-containerd-ac1251b1b3e5e2eba5cae96a3217f912200a02ee621c06c02bf755409add847c.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod98d29b6c_7a9f_4101_8470_6c8b098efc73.slice/cri-containerd-3eb0066f6d44757f4860b9b41886f823bb2cb00560f4472a8e1ab514512ce737.scope"
      }
    ],
    "ips": [
      "10.124.0.21"
    ],
    "name": "clustermesh-apiserver-f65f76d7-tjp9q",
    "namespace": "kube-system"
  }
]

