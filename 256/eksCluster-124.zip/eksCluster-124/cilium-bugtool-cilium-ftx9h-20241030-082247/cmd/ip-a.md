1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:3e:ef:c5:e2:5b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.149.67/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3334sec preferred_lft 3334sec
    inet6 fe80::43e:efff:fec5:e25b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a4:95:e9:d2:d9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.154.46/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4a4:95ff:fee9:d2d9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:c0:00:57:4b:8d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6cc0:ff:fe57:4b8d/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:77:25:9e:ee:41 brd ff:ff:ff:ff:ff:ff
    inet 10.124.0.127/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::f477:25ff:fe9e:ee41/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6a:a2:bb:f8:98:19 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::68a2:bbff:fef8:9819/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:c6:d3:40:9a:d5 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c8c6:d3ff:fe40:9ad5/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca1e824070494@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:90:09:9a:2c:1f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::e490:9ff:fe9a:2c1f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcb9df8243eda4@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:fc:f1:4c:72:16 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b0fc:f1ff:fe4c:7216/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc40c8b4b58a54@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:96:a7:f6:b4:37 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::5496:a7ff:fef6:b437/64 scope link 
       valid_lft forever preferred_lft forever
