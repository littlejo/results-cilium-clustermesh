IP ADDRESS        LOCAL ENDPOINT INFO
172.31.149.67:0   (localhost)                                                                                        
10.124.0.127:0    (localhost)                                                                                        
10.124.0.125:0    id=851   sec_id=4101041 flags=0x0000 ifindex=12  mac=72:94:92:56:1E:97 nodemac=E6:90:09:9A:2C:1F   
172.31.154.46:0   (localhost)                                                                                        
10.124.0.207:0    id=1729  sec_id=4     flags=0x0000 ifindex=10  mac=96:11:3F:2C:63:AA nodemac=CA:C6:D3:40:9A:D5     
10.124.0.21:0     id=83    sec_id=4116823 flags=0x0000 ifindex=18  mac=5E:FB:4D:BE:70:8C nodemac=56:96:A7:F6:B4:37   
10.124.0.31:0     id=111   sec_id=4101041 flags=0x0000 ifindex=14  mac=66:85:2A:C1:81:5A nodemac=B2:FC:F1:4C:72:16   
