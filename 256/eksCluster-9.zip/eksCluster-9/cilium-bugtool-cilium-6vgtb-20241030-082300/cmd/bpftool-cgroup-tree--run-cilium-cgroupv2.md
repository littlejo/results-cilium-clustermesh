CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b31a046_91e1_4bba_bb2d_f9117f8d7e8e.slice/cri-containerd-f0703aa564fe77224d6d85a57c008f10e0d2880c9bc18c53b8e62099e5ed19ce.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b31a046_91e1_4bba_bb2d_f9117f8d7e8e.slice/cri-containerd-660fbc10d37d07eed85ca33297589d42b78099445b031500d2dc7ccfda472c88.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod620be4cd_36ef_4f65_be54_306277527aaf.slice/cri-containerd-790c20a77540fe49be6a5747b3aec853201370301b0ba8fe16b614509d542867.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod620be4cd_36ef_4f65_be54_306277527aaf.slice/cri-containerd-07e9e5c92fccf97ed7829ab8b248c9157897e40c9cbcdca66c1dcd4c823ed250.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod60e11fe5_d029_455d_9948_6cf8833ef29a.slice/cri-containerd-da4718f16e53b7423b2c529f942eba7c1f3f28785cd04787db99ccd9ac5e8ca6.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod60e11fe5_d029_455d_9948_6cf8833ef29a.slice/cri-containerd-dfb558f845670f777efea5c82a2bd64ff4e62aad7e6f9df5e1ac791f22e20ac4.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod81047a27_fd66_4f98_95a5_8f8e1e6821b6.slice/cri-containerd-76e5d9f53cb668e879f5fe09a6100893f0c4317cdb87656967e9026c8f0715c5.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod81047a27_fd66_4f98_95a5_8f8e1e6821b6.slice/cri-containerd-b2611524379b04406dadea3c0ef517733a09fd68545329003decf5a9e8db0550.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod057f3b5c_ec2a_4604_ba60_a4323dc08ac6.slice/cri-containerd-49d9cbc490e17dbf7bad58357b9db5e3d022e6456afb06a70d067224f6820a32.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod057f3b5c_ec2a_4604_ba60_a4323dc08ac6.slice/cri-containerd-b97d65964aead91107ab383283efd0d53625093d9c3bf2360649a6989846ca1d.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb2249921_936f_4b47_bd3b_b61f738073f0.slice/cri-containerd-ba6575ea9992218ae13ea515ba20864d27dc915923c750c8926e0a821f203985.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb2249921_936f_4b47_bd3b_b61f738073f0.slice/cri-containerd-5be5aa99d686ddbdf32d873d9af384e892475e6d0c85dcc574efd14c4d869c1d.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb2249921_936f_4b47_bd3b_b61f738073f0.slice/cri-containerd-0270531dc1afbc0debadc793aff477bb9c79c2267d7a99afeec543a9df6a6c49.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb2249921_936f_4b47_bd3b_b61f738073f0.slice/cri-containerd-c775b94f10dc5a4d909396cf01687c69b28de5b543329f3291a430b43ff7fa67.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8b8f91df_ce27_479b_be7a_a06044be636e.slice/cri-containerd-c1efaabb2d02ad7cd270098b18944ab333a38bd3ccd2fde4d1143b91009e4c5f.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8b8f91df_ce27_479b_be7a_a06044be636e.slice/cri-containerd-e3a95b07420a0547daa0b5a0ed203cb075a3a92055593054ab34ab7dd2eb9227.scope
    101      cgroup_device   multi                                          
