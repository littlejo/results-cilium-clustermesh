top - 08:23:01 up 38 min,  0 users,  load average: 0.05, 0.08, 0.08
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 63.3 us, 20.0 sy,  0.0 ni, 13.3 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4469.4 free,   1198.8 used,   2146.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6430.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 387140  78268 S  93.3   4.8   0:55.20 cilium-+
    394 root      20   0 1229488   7912   3836 S   0.0   0.1   0:01.13 cilium-+
    629 root      20   0 1240432  16832  11548 S   0.0   0.2   0:00.02 cilium-+
    630 root      20   0 1228744   3656   2976 S   0.0   0.0   0:00.00 gops
    639 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    640 root      20   0 1228744   3656   2976 S   0.0   0.0   0:00.00 gops
    651 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    713 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    732 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
