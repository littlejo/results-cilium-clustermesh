KEY             VALUE
AgentLiveness   2330594657543
UTimeOffset     3379441957031250
