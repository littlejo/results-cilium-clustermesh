1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:09:28:bb:74:b3 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.238.115/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3110sec preferred_lft 3110sec
    inet6 fe80::809:28ff:febb:74b3/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:1f:dd:86:5b:f9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.207.223/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::81f:ddff:fe86:5bf9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:b0:97:7c:ea:ca brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c8b0:97ff:fe7c:eaca/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:d3:51:ab:08:ae brd ff:ff:ff:ff:ff:ff
    inet 10.9.0.110/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::7cd3:51ff:feab:8ae/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 5e:8e:be:94:db:f3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5c8e:beff:fe94:dbf3/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:a7:2b:c3:06:9f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b0a7:2bff:fec3:69f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc3ef1360264b9@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:b1:a3:01:65:0c brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::58b1:a3ff:fe01:650c/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcfbc357e24e75@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:97:87:d6:b4:ec brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::3497:87ff:fed6:b4ec/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc10d3c205df57@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:76:3b:67:76:af brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::876:3bff:fe67:76af/64 scope link 
       valid_lft forever preferred_lft forever
