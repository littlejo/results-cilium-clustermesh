key: 07 03 00 00  value: 1a 02 00 00
key: 9a 08 00 00  value: 2b 02 00 00
key: ae 09 00 00  value: 69 02 00 00
key: 43 0b 00 00  value: 20 02 00 00
Found 4 elements
