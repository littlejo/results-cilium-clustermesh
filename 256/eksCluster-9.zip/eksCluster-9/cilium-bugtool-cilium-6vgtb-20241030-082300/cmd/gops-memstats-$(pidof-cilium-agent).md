alloc: 182.46MB (191323560 bytes)
total-alloc: 2.38GB (2552040240 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 65373866
frees: 63459188
heap-alloc: 182.46MB (191323560 bytes)
heap-sys: 250.85MB (263036928 bytes)
heap-idle: 45.44MB (47644672 bytes)
heap-in-use: 205.41MB (215392256 bytes)
heap-released: 4.66MB (4882432 bytes)
heap-objects: 1914678
stack-in-use: 65.12MB (68288512 bytes)
stack-sys: 65.12MB (68288512 bytes)
stack-mspan-inuse: 3.32MB (3486240 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 989.46KB (1013209 bytes)
gc-sys: 6.01MB (6301256 bytes)
next-gc: when heap-alloc >= 229.75MB (240914360 bytes)
last-gc: 2024-10-30 08:23:02.144003179 +0000 UTC
gc-pause-total: 9.724263ms
gc-pause: 176075
gc-pause-end: 1730276582144003179
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00038729555696331825
enable-gc: true
debug-gc: false
