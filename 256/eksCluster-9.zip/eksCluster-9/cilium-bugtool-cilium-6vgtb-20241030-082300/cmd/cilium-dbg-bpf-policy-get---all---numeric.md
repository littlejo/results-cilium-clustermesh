Endpoint ID: 173
Path: /sys/fs/bpf/tc/globals/cilium_policy_00173

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 775
Path: /sys/fs/bpf/tc/globals/cilium_policy_00775

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176827   2037      0        
Allow    Egress      0          ANY          NONE         disabled    20432    228       0        


Endpoint ID: 2202
Path: /sys/fs/bpf/tc/globals/cilium_policy_02202

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    178184   2052      0        
Allow    Egress      0          ANY          NONE         disabled    22004    248       0        


Endpoint ID: 2478
Path: /sys/fs/bpf/tc/globals/cilium_policy_02478

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11682725   117071    0        
Allow    Ingress     1          ANY          NONE         disabled    10782283   113853    0        
Allow    Egress      0          ANY          NONE         disabled    13574187   133723    0        


Endpoint ID: 2883
Path: /sys/fs/bpf/tc/globals/cilium_policy_02883

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1667402   21139     0        
Allow    Ingress     1          ANY          NONE         disabled    26952     316       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


