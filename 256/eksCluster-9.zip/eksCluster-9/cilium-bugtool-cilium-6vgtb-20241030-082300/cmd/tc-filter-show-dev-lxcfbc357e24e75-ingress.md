filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcfbc357e24e75 direct-action not_in_hw id 557 tag 24492585c540a31f jited 
