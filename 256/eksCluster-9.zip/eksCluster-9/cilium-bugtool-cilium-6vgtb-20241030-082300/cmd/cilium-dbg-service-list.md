ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.138.63:443 (active)     
                                         2 => 172.31.196.173:443 (active)    
2    10.100.159.83:443    ClusterIP      1 => 172.31.238.115:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.9.0.98:53 (active)          
                                         2 => 10.9.0.194:53 (active)         
4    10.100.0.10:9153     ClusterIP      1 => 10.9.0.98:9153 (active)        
                                         2 => 10.9.0.194:9153 (active)       
5    10.100.45.145:2379   ClusterIP      1 => 10.9.0.6:2379 (active)         
