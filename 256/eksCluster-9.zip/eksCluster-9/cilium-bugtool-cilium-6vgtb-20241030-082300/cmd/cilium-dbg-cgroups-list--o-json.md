[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod620be4cd_36ef_4f65_be54_306277527aaf.slice/cri-containerd-790c20a77540fe49be6a5747b3aec853201370301b0ba8fe16b614509d542867.scope"
      }
    ],
    "ips": [
      "10.9.0.194"
    ],
    "name": "coredns-cc6ccd49c-zq4xl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod81047a27_fd66_4f98_95a5_8f8e1e6821b6.slice/cri-containerd-b2611524379b04406dadea3c0ef517733a09fd68545329003decf5a9e8db0550.scope"
      }
    ],
    "ips": [
      "10.9.0.98"
    ],
    "name": "coredns-cc6ccd49c-shrkl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb2249921_936f_4b47_bd3b_b61f738073f0.slice/cri-containerd-0270531dc1afbc0debadc793aff477bb9c79c2267d7a99afeec543a9df6a6c49.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb2249921_936f_4b47_bd3b_b61f738073f0.slice/cri-containerd-ba6575ea9992218ae13ea515ba20864d27dc915923c750c8926e0a821f203985.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb2249921_936f_4b47_bd3b_b61f738073f0.slice/cri-containerd-5be5aa99d686ddbdf32d873d9af384e892475e6d0c85dcc574efd14c4d869c1d.scope"
      }
    ],
    "ips": [
      "10.9.0.6"
    ],
    "name": "clustermesh-apiserver-5dc6864b5c-psvk7",
    "namespace": "kube-system"
  }
]

