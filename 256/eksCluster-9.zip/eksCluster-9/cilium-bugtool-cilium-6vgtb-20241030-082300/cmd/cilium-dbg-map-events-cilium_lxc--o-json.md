{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:23.035Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.207.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:23.035Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.238.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:23.035Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:27.651Z",
  "value": "id=2883  sec_id=4     flags=0x0000 ifindex=10  mac=BE:0F:D1:BE:20:F6 nodemac=B2:A7:2B:C3:06:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:27.657Z",
  "value": "id=775   sec_id=332223 flags=0x0000 ifindex=12  mac=6E:AB:59:07:A2:48 nodemac=5A:B1:A3:01:65:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:27.696Z",
  "value": "id=2202  sec_id=332223 flags=0x0000 ifindex=14  mac=EE:8C:69:A7:26:9E nodemac=36:97:87:D6:B4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:27.697Z",
  "value": "id=775   sec_id=332223 flags=0x0000 ifindex=12  mac=6E:AB:59:07:A2:48 nodemac=5A:B1:A3:01:65:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:27.705Z",
  "value": "id=2883  sec_id=4     flags=0x0000 ifindex=10  mac=BE:0F:D1:BE:20:F6 nodemac=B2:A7:2B:C3:06:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:36.802Z",
  "value": "id=2883  sec_id=4     flags=0x0000 ifindex=10  mac=BE:0F:D1:BE:20:F6 nodemac=B2:A7:2B:C3:06:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:36.802Z",
  "value": "id=775   sec_id=332223 flags=0x0000 ifindex=12  mac=6E:AB:59:07:A2:48 nodemac=5A:B1:A3:01:65:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:36.803Z",
  "value": "id=2202  sec_id=332223 flags=0x0000 ifindex=14  mac=EE:8C:69:A7:26:9E nodemac=36:97:87:D6:B4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:36.836Z",
  "value": "id=129   sec_id=334404 flags=0x0000 ifindex=16  mac=56:FA:00:7E:F3:F6 nodemac=AA:AE:1D:B8:3D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:37.803Z",
  "value": "id=2202  sec_id=332223 flags=0x0000 ifindex=14  mac=EE:8C:69:A7:26:9E nodemac=36:97:87:D6:B4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:37.803Z",
  "value": "id=775   sec_id=332223 flags=0x0000 ifindex=12  mac=6E:AB:59:07:A2:48 nodemac=5A:B1:A3:01:65:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:37.803Z",
  "value": "id=2883  sec_id=4     flags=0x0000 ifindex=10  mac=BE:0F:D1:BE:20:F6 nodemac=B2:A7:2B:C3:06:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:37.804Z",
  "value": "id=129   sec_id=334404 flags=0x0000 ifindex=16  mac=56:FA:00:7E:F3:F6 nodemac=AA:AE:1D:B8:3D:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:36.538Z",
  "value": "id=2478  sec_id=334404 flags=0x0000 ifindex=18  mac=F6:5F:95:8D:9F:C1 nodemac=0A:76:3B:67:76:AF"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.9.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.973Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.605Z",
  "value": "id=775   sec_id=332223 flags=0x0000 ifindex=12  mac=6E:AB:59:07:A2:48 nodemac=5A:B1:A3:01:65:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.606Z",
  "value": "id=2202  sec_id=332223 flags=0x0000 ifindex=14  mac=EE:8C:69:A7:26:9E nodemac=36:97:87:D6:B4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.606Z",
  "value": "id=2478  sec_id=334404 flags=0x0000 ifindex=18  mac=F6:5F:95:8D:9F:C1 nodemac=0A:76:3B:67:76:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.607Z",
  "value": "id=2883  sec_id=4     flags=0x0000 ifindex=10  mac=BE:0F:D1:BE:20:F6 nodemac=B2:A7:2B:C3:06:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.615Z",
  "value": "id=2202  sec_id=332223 flags=0x0000 ifindex=14  mac=EE:8C:69:A7:26:9E nodemac=36:97:87:D6:B4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.615Z",
  "value": "id=2478  sec_id=334404 flags=0x0000 ifindex=18  mac=F6:5F:95:8D:9F:C1 nodemac=0A:76:3B:67:76:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.616Z",
  "value": "id=2883  sec_id=4     flags=0x0000 ifindex=10  mac=BE:0F:D1:BE:20:F6 nodemac=B2:A7:2B:C3:06:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.616Z",
  "value": "id=775   sec_id=332223 flags=0x0000 ifindex=12  mac=6E:AB:59:07:A2:48 nodemac=5A:B1:A3:01:65:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.615Z",
  "value": "id=2478  sec_id=334404 flags=0x0000 ifindex=18  mac=F6:5F:95:8D:9F:C1 nodemac=0A:76:3B:67:76:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.615Z",
  "value": "id=2883  sec_id=4     flags=0x0000 ifindex=10  mac=BE:0F:D1:BE:20:F6 nodemac=B2:A7:2B:C3:06:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.615Z",
  "value": "id=775   sec_id=332223 flags=0x0000 ifindex=12  mac=6E:AB:59:07:A2:48 nodemac=5A:B1:A3:01:65:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.616Z",
  "value": "id=2202  sec_id=332223 flags=0x0000 ifindex=14  mac=EE:8C:69:A7:26:9E nodemac=36:97:87:D6:B4:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.616Z",
  "value": "id=2883  sec_id=4     flags=0x0000 ifindex=10  mac=BE:0F:D1:BE:20:F6 nodemac=B2:A7:2B:C3:06:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.617Z",
  "value": "id=775   sec_id=332223 flags=0x0000 ifindex=12  mac=6E:AB:59:07:A2:48 nodemac=5A:B1:A3:01:65:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.617Z",
  "value": "id=2478  sec_id=334404 flags=0x0000 ifindex=18  mac=F6:5F:95:8D:9F:C1 nodemac=0A:76:3B:67:76:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.617Z",
  "value": "id=2202  sec_id=332223 flags=0x0000 ifindex=14  mac=EE:8C:69:A7:26:9E nodemac=36:97:87:D6:B4:EC"
}

