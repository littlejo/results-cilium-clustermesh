IP ADDRESS         LOCAL ENDPOINT INFO
172.31.207.223:0   (localhost)                                                                                       
10.9.0.6:0         id=2478  sec_id=334404 flags=0x0000 ifindex=18  mac=F6:5F:95:8D:9F:C1 nodemac=0A:76:3B:67:76:AF   
10.9.0.30:0        id=2883  sec_id=4     flags=0x0000 ifindex=10  mac=BE:0F:D1:BE:20:F6 nodemac=B2:A7:2B:C3:06:9F    
10.9.0.194:0       id=2202  sec_id=332223 flags=0x0000 ifindex=14  mac=EE:8C:69:A7:26:9E nodemac=36:97:87:D6:B4:EC   
10.9.0.98:0        id=775   sec_id=332223 flags=0x0000 ifindex=12  mac=6E:AB:59:07:A2:48 nodemac=5A:B1:A3:01:65:0C   
172.31.238.115:0   (localhost)                                                                                       
10.9.0.110:0       (localhost)                                                                                       
