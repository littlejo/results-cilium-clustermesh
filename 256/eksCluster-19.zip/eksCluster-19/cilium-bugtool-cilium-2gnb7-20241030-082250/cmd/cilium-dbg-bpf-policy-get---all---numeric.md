Endpoint ID: 129
Path: /sys/fs/bpf/tc/globals/cilium_policy_00129

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174678   2013      0        
Allow    Egress      0          ANY          NONE         disabled    22179    248       0        


Endpoint ID: 598
Path: /sys/fs/bpf/tc/globals/cilium_policy_00598

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2120
Path: /sys/fs/bpf/tc/globals/cilium_policy_02120

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1642404   20754     0        
Allow    Ingress     1          ANY          NONE         disabled    26072     304       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3085
Path: /sys/fs/bpf/tc/globals/cilium_policy_03085

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174839   2010      0        
Allow    Egress      0          ANY          NONE         disabled    21192    239       0        


Endpoint ID: 3840
Path: /sys/fs/bpf/tc/globals/cilium_policy_03840

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11674408   116611    0        
Allow    Ingress     1          ANY          NONE         disabled    11339771   116233    0        
Allow    Egress      0          ANY          NONE         disabled    13168206   129543    0        


