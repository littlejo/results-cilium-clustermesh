{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:55.011Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.241.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:55.011Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.245.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:55.011Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:00.293Z",
  "value": "id=3085  sec_id=676390 flags=0x0000 ifindex=12  mac=CE:41:81:41:B7:58 nodemac=1A:20:F8:99:CC:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:00.295Z",
  "value": "id=129   sec_id=676390 flags=0x0000 ifindex=14  mac=82:47:A1:5E:4A:3C nodemac=02:12:DD:F2:5A:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:00.360Z",
  "value": "id=2120  sec_id=4     flags=0x0000 ifindex=10  mac=DA:C1:28:30:1A:17 nodemac=2E:72:0B:D6:23:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:00.429Z",
  "value": "id=3085  sec_id=676390 flags=0x0000 ifindex=12  mac=CE:41:81:41:B7:58 nodemac=1A:20:F8:99:CC:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:00.496Z",
  "value": "id=129   sec_id=676390 flags=0x0000 ifindex=14  mac=82:47:A1:5E:4A:3C nodemac=02:12:DD:F2:5A:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:12.992Z",
  "value": "id=129   sec_id=676390 flags=0x0000 ifindex=14  mac=82:47:A1:5E:4A:3C nodemac=02:12:DD:F2:5A:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:12.992Z",
  "value": "id=3085  sec_id=676390 flags=0x0000 ifindex=12  mac=CE:41:81:41:B7:58 nodemac=1A:20:F8:99:CC:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:12.993Z",
  "value": "id=2120  sec_id=4     flags=0x0000 ifindex=10  mac=DA:C1:28:30:1A:17 nodemac=2E:72:0B:D6:23:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:13.026Z",
  "value": "id=1097  sec_id=663764 flags=0x0000 ifindex=16  mac=16:DF:89:36:10:F2 nodemac=3E:A5:9D:A4:4A:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:13.993Z",
  "value": "id=3085  sec_id=676390 flags=0x0000 ifindex=12  mac=CE:41:81:41:B7:58 nodemac=1A:20:F8:99:CC:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:13.993Z",
  "value": "id=1097  sec_id=663764 flags=0x0000 ifindex=16  mac=16:DF:89:36:10:F2 nodemac=3E:A5:9D:A4:4A:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:13.993Z",
  "value": "id=129   sec_id=676390 flags=0x0000 ifindex=14  mac=82:47:A1:5E:4A:3C nodemac=02:12:DD:F2:5A:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:13.993Z",
  "value": "id=2120  sec_id=4     flags=0x0000 ifindex=10  mac=DA:C1:28:30:1A:17 nodemac=2E:72:0B:D6:23:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.506Z",
  "value": "id=3840  sec_id=663764 flags=0x0000 ifindex=18  mac=FE:E1:0F:64:93:3F nodemac=72:13:FE:89:75:96"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.19.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.524Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.444Z",
  "value": "id=3085  sec_id=676390 flags=0x0000 ifindex=12  mac=CE:41:81:41:B7:58 nodemac=1A:20:F8:99:CC:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.445Z",
  "value": "id=2120  sec_id=4     flags=0x0000 ifindex=10  mac=DA:C1:28:30:1A:17 nodemac=2E:72:0B:D6:23:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.445Z",
  "value": "id=3840  sec_id=663764 flags=0x0000 ifindex=18  mac=FE:E1:0F:64:93:3F nodemac=72:13:FE:89:75:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.446Z",
  "value": "id=129   sec_id=676390 flags=0x0000 ifindex=14  mac=82:47:A1:5E:4A:3C nodemac=02:12:DD:F2:5A:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.445Z",
  "value": "id=3085  sec_id=676390 flags=0x0000 ifindex=12  mac=CE:41:81:41:B7:58 nodemac=1A:20:F8:99:CC:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.446Z",
  "value": "id=129   sec_id=676390 flags=0x0000 ifindex=14  mac=82:47:A1:5E:4A:3C nodemac=02:12:DD:F2:5A:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.446Z",
  "value": "id=2120  sec_id=4     flags=0x0000 ifindex=10  mac=DA:C1:28:30:1A:17 nodemac=2E:72:0B:D6:23:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.447Z",
  "value": "id=3840  sec_id=663764 flags=0x0000 ifindex=18  mac=FE:E1:0F:64:93:3F nodemac=72:13:FE:89:75:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.445Z",
  "value": "id=3085  sec_id=676390 flags=0x0000 ifindex=12  mac=CE:41:81:41:B7:58 nodemac=1A:20:F8:99:CC:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.445Z",
  "value": "id=129   sec_id=676390 flags=0x0000 ifindex=14  mac=82:47:A1:5E:4A:3C nodemac=02:12:DD:F2:5A:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.446Z",
  "value": "id=2120  sec_id=4     flags=0x0000 ifindex=10  mac=DA:C1:28:30:1A:17 nodemac=2E:72:0B:D6:23:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.446Z",
  "value": "id=3840  sec_id=663764 flags=0x0000 ifindex=18  mac=FE:E1:0F:64:93:3F nodemac=72:13:FE:89:75:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.445Z",
  "value": "id=3085  sec_id=676390 flags=0x0000 ifindex=12  mac=CE:41:81:41:B7:58 nodemac=1A:20:F8:99:CC:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.446Z",
  "value": "id=3840  sec_id=663764 flags=0x0000 ifindex=18  mac=FE:E1:0F:64:93:3F nodemac=72:13:FE:89:75:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.446Z",
  "value": "id=129   sec_id=676390 flags=0x0000 ifindex=14  mac=82:47:A1:5E:4A:3C nodemac=02:12:DD:F2:5A:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.19.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.446Z",
  "value": "id=2120  sec_id=4     flags=0x0000 ifindex=10  mac=DA:C1:28:30:1A:17 nodemac=2E:72:0B:D6:23:C4"
}

