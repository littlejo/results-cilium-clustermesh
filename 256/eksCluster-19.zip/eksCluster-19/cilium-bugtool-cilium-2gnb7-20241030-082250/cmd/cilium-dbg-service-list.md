ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.157.254:443 (active)   
                                         2 => 172.31.230.130:443 (active)   
2    10.100.170.76:443    ClusterIP      1 => 172.31.241.81:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.19.0.119:53 (active)       
                                         2 => 10.19.0.59:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.19.0.119:9153 (active)     
                                         2 => 10.19.0.59:9153 (active)      
5    10.100.238.51:2379   ClusterIP      1 => 10.19.0.43:2379 (active)      
