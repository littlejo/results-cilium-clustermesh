 08:22:51 up 37 min,  0 users,  load average: 0.70, 0.64, 0.38
