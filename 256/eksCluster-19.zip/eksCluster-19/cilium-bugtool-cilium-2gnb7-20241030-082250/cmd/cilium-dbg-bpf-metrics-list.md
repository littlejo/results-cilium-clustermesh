REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36544     2892864     677    bpf_overlay.c
Interface                 INGRESS     676981    136022271   1132   bpf_host.c
Success                   EGRESS      16484     1297964     1694   bpf_host.c
Success                   EGRESS      295887    36932273    1308   bpf_lxc.c
Success                   EGRESS      36875     2917417     53     encap.h
Success                   INGRESS     339436    38484057    86     l3.h
Success                   INGRESS     360147    40123003    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
