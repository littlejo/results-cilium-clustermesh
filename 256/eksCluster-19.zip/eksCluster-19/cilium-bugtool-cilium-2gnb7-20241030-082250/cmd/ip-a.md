1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:9e:a6:e6:17:91 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.241.81/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3177sec preferred_lft 3177sec
    inet6 fe80::89e:a6ff:fee6:1791/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:d2:32:51:d1:f3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.245.207/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8d2:32ff:fe51:d1f3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:81:55:64:be:8d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7c81:55ff:fe64:be8d/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:29:a8:22:83:84 brd ff:ff:ff:ff:ff:ff
    inet 10.19.0.189/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b429:a8ff:fe22:8384/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 02:d4:b0:c5:12:82 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d4:b0ff:fec5:1282/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:72:0b:d6:23:c4 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::2c72:bff:fed6:23c4/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcffbaf245a5e2@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:20:f8:99:cc:ae brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::1820:f8ff:fe99:ccae/64 scope link 
       valid_lft forever preferred_lft forever
14: lxca48c0f4add96@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:12:dd:f2:5a:e7 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::12:ddff:fef2:5ae7/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc14da18621fae@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:13:fe:89:75:96 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7013:feff:fe89:7596/64 scope link 
       valid_lft forever preferred_lft forever
