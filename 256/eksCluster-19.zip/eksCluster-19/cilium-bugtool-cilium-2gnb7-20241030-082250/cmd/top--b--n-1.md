top - 08:22:51 up 37 min,  0 users,  load average: 0.70, 0.64, 0.38
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 63.3 us, 16.7 sy,  0.0 ni, 20.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4463.3 free,   1203.9 used,   2147.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6425.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 403204  78296 S 100.0   5.0   1:05.23 cilium-+
    636 root      20   0 1240432  16240  11356 S   6.7   0.2   0:00.02 cilium-+
    404 root      20   0 1229744   7824   3836 S   0.0   0.1   0:01.18 cilium-+
    630 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    645 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    646 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    647 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    651 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    708 root      20   0    6576   2432   2104 R   0.0   0.0   0:00.00 top
    727 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
