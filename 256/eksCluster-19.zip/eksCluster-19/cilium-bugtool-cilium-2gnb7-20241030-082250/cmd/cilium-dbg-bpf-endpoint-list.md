IP ADDRESS         LOCAL ENDPOINT INFO
172.31.241.81:0    (localhost)                                                                                       
10.19.0.59:0       id=129   sec_id=676390 flags=0x0000 ifindex=14  mac=82:47:A1:5E:4A:3C nodemac=02:12:DD:F2:5A:E7   
10.19.0.254:0      id=2120  sec_id=4     flags=0x0000 ifindex=10  mac=DA:C1:28:30:1A:17 nodemac=2E:72:0B:D6:23:C4    
10.19.0.43:0       id=3840  sec_id=663764 flags=0x0000 ifindex=18  mac=FE:E1:0F:64:93:3F nodemac=72:13:FE:89:75:96   
10.19.0.119:0      id=3085  sec_id=676390 flags=0x0000 ifindex=12  mac=CE:41:81:41:B7:58 nodemac=1A:20:F8:99:CC:AE   
172.31.245.207:0   (localhost)                                                                                       
10.19.0.189:0      (localhost)                                                                                       
