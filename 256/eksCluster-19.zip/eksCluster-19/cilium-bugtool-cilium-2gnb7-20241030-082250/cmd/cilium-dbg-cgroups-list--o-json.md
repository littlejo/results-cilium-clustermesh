[
  {
    "containers": [
      {
        "cgroup-id": 9268,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5334490c_e38c_4e2c_9f2a_28db85907871.slice/cri-containerd-978edd5e1cb97dba6c52b4c89baa6f69bb44ee53ba7a58fd061d74530860f3f6.scope"
      },
      {
        "cgroup-id": 9184,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5334490c_e38c_4e2c_9f2a_28db85907871.slice/cri-containerd-9a8f9a47d95b7a65556fbe6944b304fa372331b7c81d9f598cd6c238f0ad157a.scope"
      },
      {
        "cgroup-id": 9352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5334490c_e38c_4e2c_9f2a_28db85907871.slice/cri-containerd-8f648e35fc675990e8eb898f09200c4bf3baad1416a2cec394b6665205ca2e41.scope"
      }
    ],
    "ips": [
      "10.19.0.43"
    ],
    "name": "clustermesh-apiserver-65454d44f6-k9b6h",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod13ae86cb_cb2f_43b0_aa36_98ae3c1abcc4.slice/cri-containerd-15f2bfcd04be77cf696b1a23137718bbf2dc2865acfbdba37ea5bb2a3ed0a7de.scope"
      }
    ],
    "ips": [
      "10.19.0.59"
    ],
    "name": "coredns-cc6ccd49c-6zw5p",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod88913bc9_063a_4724_8d97_5b9662c6f175.slice/cri-containerd-e51a97bd415e9bbab379ddd0477224fb3a0271f7533330abff6bb6d53cc34550.scope"
      }
    ],
    "ips": [
      "10.19.0.119"
    ],
    "name": "coredns-cc6ccd49c-tcvn5",
    "namespace": "kube-system"
  }
]

