alloc: 177.34MB (185952840 bytes)
total-alloc: 2.48GB (2665700216 bytes)
sys: 333.02MB (349196644 bytes)
lookups: 0
mallocs: 66567279
frees: 64561131
heap-alloc: 177.34MB (185952840 bytes)
heap-sys: 250.95MB (263135232 bytes)
heap-idle: 48.61MB (50970624 bytes)
heap-in-use: 202.34MB (212164608 bytes)
heap-released: 3.02MB (3170304 bytes)
heap-objects: 2006148
stack-in-use: 69.03MB (72384512 bytes)
stack-sys: 69.03MB (72384512 bytes)
stack-mspan-inuse: 3.47MB (3643200 bytes)
stack-mspan-sys: 3.89MB (4080000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.13MB (1180513 bytes)
gc-sys: 6.01MB (6301160 bytes)
next-gc: when heap-alloc >= 214.81MB (225239864 bytes)
last-gc: 2024-10-30 08:22:57.249353658 +0000 UTC
gc-pause-total: 20.389476ms
gc-pause: 87309
gc-pause-end: 1730276577249353658
num-gc: 88
num-forced-gc: 0
gc-cpu-fraction: 0.00047796973457580266
enable-gc: true
debug-gc: false
