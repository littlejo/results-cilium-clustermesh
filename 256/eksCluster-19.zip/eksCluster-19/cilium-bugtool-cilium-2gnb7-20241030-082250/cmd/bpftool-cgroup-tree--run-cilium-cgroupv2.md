CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod13ae86cb_cb2f_43b0_aa36_98ae3c1abcc4.slice/cri-containerd-15f2bfcd04be77cf696b1a23137718bbf2dc2865acfbdba37ea5bb2a3ed0a7de.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod13ae86cb_cb2f_43b0_aa36_98ae3c1abcc4.slice/cri-containerd-b146f38f34ba2002f86056029f36c63b2d12d1480c833cd1a190390464f3cd4f.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaec899fc_a5ce_454d_b045_5654e01553fc.slice/cri-containerd-4ce467075dc02e3eb8b2382b53152625995ae67b55c99245956b94d3066772d5.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaec899fc_a5ce_454d_b045_5654e01553fc.slice/cri-containerd-61cb90f189c64d87cc3bab5087210e89bb6223f77e111063ecb820a79ecce2db.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd7de29a7_5305_45ca_ac5a_1d256f0adabe.slice/cri-containerd-7f57da1199b7456b572bda7f2d24c6cad470b0dd2da9f8d7d1716f2e5a503f97.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd7de29a7_5305_45ca_ac5a_1d256f0adabe.slice/cri-containerd-a6fd224ac3c90ac02bca45f0f7c5b651ee89638984ef8ef29458a0f7a22b732c.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod88913bc9_063a_4724_8d97_5b9662c6f175.slice/cri-containerd-ced3e69968e73fb149ee0288502a4cd4c11eed073e7e17ddcc33b28b30cb8d25.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod88913bc9_063a_4724_8d97_5b9662c6f175.slice/cri-containerd-e51a97bd415e9bbab379ddd0477224fb3a0271f7533330abff6bb6d53cc34550.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcdc1aea7_6f8b_4bea_9d5f_5ef12db71cc5.slice/cri-containerd-e3f733d23d8b694e138d7403227656892385d345b1508c3dbe5e7610dcb8d2e4.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcdc1aea7_6f8b_4bea_9d5f_5ef12db71cc5.slice/cri-containerd-aee30c58a4c967eae4cd21408c5a1b0b990dce758f158e1b62ed1ec1e0785368.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5334490c_e38c_4e2c_9f2a_28db85907871.slice/cri-containerd-c7d8482b84ecb041fdaeefc7f638a0fc7924d8e9b0c7fe5196b65f4544112614.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5334490c_e38c_4e2c_9f2a_28db85907871.slice/cri-containerd-978edd5e1cb97dba6c52b4c89baa6f69bb44ee53ba7a58fd061d74530860f3f6.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5334490c_e38c_4e2c_9f2a_28db85907871.slice/cri-containerd-9a8f9a47d95b7a65556fbe6944b304fa372331b7c81d9f598cd6c238f0ad157a.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5334490c_e38c_4e2c_9f2a_28db85907871.slice/cri-containerd-8f648e35fc675990e8eb898f09200c4bf3baad1416a2cec394b6665205ca2e41.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4362cda1_279d_4b17_98aa_7ae385c4b93c.slice/cri-containerd-93ccaa8bbd59a154ac942e4cda843d60d542584ec607bba4a724d5ea1b0d508c.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4362cda1_279d_4b17_98aa_7ae385c4b93c.slice/cri-containerd-187f2fb0593ace28f79e71df238ecb61d4b771e0e322f9caf27d13cac63721ef.scope
    93       cgroup_device   multi                                          
