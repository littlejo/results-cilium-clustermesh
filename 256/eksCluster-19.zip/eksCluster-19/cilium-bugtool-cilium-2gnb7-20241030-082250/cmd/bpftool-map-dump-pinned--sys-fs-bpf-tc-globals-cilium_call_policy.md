key: 81 00 00 00  value: 1c 02 00 00
key: 48 08 00 00  value: 00 02 00 00
key: 0d 0c 00 00  value: 11 02 00 00
key: 00 0f 00 00  value: 72 02 00 00
Found 4 elements
