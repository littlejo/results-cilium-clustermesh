Total: 700
TCP:   1883 (estab 449, closed 1415, orphaned 0, timewait 564)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  468       456       12       
INET	  478       462       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:33129 sk:3fd cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15790 sk:3fe cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:33101      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=26)) ino:32399 sk:3ff fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.241.81%ens5:68         0.0.0.0:*    uid:192 ino:66401 sk:400 cgroup:unreachable:c4e <->                            
UNCONN 0      0                                 [::]:8472          [::]:*    ino:33128 sk:401 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15791 sk:402 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::89e:a6ff:fee6:1791]%ens5:546           [::]:*    uid:192 ino:15126 sk:403 cgroup:unreachable:c4e v6only:1 <->                   
