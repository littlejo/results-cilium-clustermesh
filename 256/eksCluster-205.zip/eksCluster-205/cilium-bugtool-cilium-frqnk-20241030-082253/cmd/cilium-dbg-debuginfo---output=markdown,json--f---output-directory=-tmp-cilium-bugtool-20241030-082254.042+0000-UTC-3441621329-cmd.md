markdown output at /tmp/cilium-bugtool-20241030-082254.042+0000-UTC-3441621329/cmd/cilium-debuginfo-20241030-082325.205+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082254.042+0000-UTC-3441621329/cmd/cilium-debuginfo-20241030-082325.205+0000-UTC.json
