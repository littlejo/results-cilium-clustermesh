CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67537a43_afa5_4742_be51_d27113097416.slice/cri-containerd-16df737ab095dfb618cad4befd3ebca865179df3d160f471d3df33d991dee670.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67537a43_afa5_4742_be51_d27113097416.slice/cri-containerd-3d4754b0d4f707f0db1a6fab0653dd45538f1b190efaf8fc74b7d91b4bf1223f.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4f6434de_c627_40e4_a86c_86750e0b8879.slice/cri-containerd-efdee2e6da8e23444ca4c24ee4e1e5789303886ac269df5c9542b5189ad5deca.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4f6434de_c627_40e4_a86c_86750e0b8879.slice/cri-containerd-4157730ef497ee291bc06a1d834e5abdf4045a7d2064262f68d2edfd5594ff9a.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd3d2547e_4d20_4f35_9f5c_2e89b241c774.slice/cri-containerd-4a9fe5c85d2930c6a847136739a28f05f41cc3ca9bf76903e487f19f06fcf89e.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd3d2547e_4d20_4f35_9f5c_2e89b241c774.slice/cri-containerd-1c8f4fd727f9fd797ce161865a288fc38c348948be1e0beb0ea2dfdd2e643b90.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod885cb3c6_b2f5_4b99_a12c_ee6bdb521e9d.slice/cri-containerd-24b4f6f73ec9705e82a1ce01a28a0bd2d1d109a77792d48c4773693b223eae97.scope
    531      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod885cb3c6_b2f5_4b99_a12c_ee6bdb521e9d.slice/cri-containerd-f34a684760be353c932eefeda0e240271013635f05d22c21855d0a43fa32ca47.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb0cdea29_fd4e_43f1_9820_ac45a83feca0.slice/cri-containerd-8aff8ae08809b42a92eaf7164ccacdadc209bbcb46cc613b9c0bad54e37d65f7.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb0cdea29_fd4e_43f1_9820_ac45a83feca0.slice/cri-containerd-14c59e6683b1893ed8713a8231ee28800c890ea769b6cf2a94dabef64ad6e329.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod35fd5703_40a3_4670_aa1c_22a81ce107d5.slice/cri-containerd-28ea111cab99a46a0f46a718b9fdd9195b124338ecd25954acef11dd46c776f6.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod35fd5703_40a3_4670_aa1c_22a81ce107d5.slice/cri-containerd-d995c70e5875de453d7b2c783db05da2a4fa1b45f5ab29d74dec6787ffab7395.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9624a37_e12b_47af_9176_37a1f11ee51e.slice/cri-containerd-691bb8e76ff27047ab844768df504b80eb9e04c20bc59393bdaa8a47b3e8d0a8.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9624a37_e12b_47af_9176_37a1f11ee51e.slice/cri-containerd-6f4fb411f1a3ee08e9fed9212dffbddd0ac0548c1f497d2210341cca5036437e.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9624a37_e12b_47af_9176_37a1f11ee51e.slice/cri-containerd-14a551b1cb81e1d3bc3b595cbdebdabbab6e2fb449b32329c3666c19b3df6f68.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9624a37_e12b_47af_9176_37a1f11ee51e.slice/cri-containerd-7ad9cce47c269e32350a95537322bdd129d61b87a4b8b689baeb835aaf3d3b3c.scope
    634      cgroup_device   multi                                          
