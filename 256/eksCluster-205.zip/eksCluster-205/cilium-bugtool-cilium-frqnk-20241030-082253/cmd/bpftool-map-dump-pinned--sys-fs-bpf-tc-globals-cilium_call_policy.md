key: cd 01 00 00  value: 03 02 00 00
key: 44 02 00 00  value: 00 02 00 00
key: 97 06 00 00  value: 1b 02 00 00
key: 37 0f 00 00  value: 73 02 00 00
Found 4 elements
