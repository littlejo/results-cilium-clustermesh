 08:22:54 up 29 min,  0 users,  load average: 0.11, 0.13, 0.10
