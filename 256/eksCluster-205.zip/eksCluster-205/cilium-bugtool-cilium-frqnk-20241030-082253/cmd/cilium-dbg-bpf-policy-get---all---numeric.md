Endpoint ID: 461
Path: /sys/fs/bpf/tc/globals/cilium_policy_00461

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1651630   20915     0        
Allow    Ingress     1          ANY          NONE         disabled    18140     214       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 580
Path: /sys/fs/bpf/tc/globals/cilium_policy_00580

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    570089   5124      0        
Allow    Ingress     1          ANY          NONE         disabled    114972   1320      0        
Allow    Egress      0          ANY          NONE         disabled    120858   1154      0        


Endpoint ID: 1687
Path: /sys/fs/bpf/tc/globals/cilium_policy_01687

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    568649   5100      0        
Allow    Ingress     1          ANY          NONE         disabled    113683   1297      0        
Allow    Egress      0          ANY          NONE         disabled    119080   1139      0        


Endpoint ID: 3769
Path: /sys/fs/bpf/tc/globals/cilium_policy_03769

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3895
Path: /sys/fs/bpf/tc/globals/cilium_policy_03895

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11590252   116728    0        
Allow    Ingress     1          ANY          NONE         disabled    10631459   111998    0        
Allow    Egress      0          ANY          NONE         disabled    14542762   142231    0        


