1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:58:c6:dc:6e:d3 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.195.50/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1847sec preferred_lft 1847sec
    inet6 fe80::858:c6ff:fedc:6ed3/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:e0:c2:e0:2e:87 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.194.239/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8e0:c2ff:fee0:2e87/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:9b:d7:0c:1f:63 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d49b:d7ff:fe0c:1f63/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:db:5e:51:b1:82 brd ff:ff:ff:ff:ff:ff
    inet 10.205.0.241/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c4db:5eff:fe51:b182/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6e:a2:ab:31:f0:2c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6ca2:abff:fe31:f02c/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:6e:b7:ea:59:26 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::dc6e:b7ff:feea:5926/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc3ac355178ef9@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:03:77:b4:d9:2d brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::6c03:77ff:feb4:d92d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcd48eda6cd65a@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:65:df:20:d0:96 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::fc65:dfff:fe20:d096/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcbde5c36bae18@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:27:27:ef:a8:ca brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7027:27ff:feef:a8ca/64 scope link 
       valid_lft forever preferred_lft forever
