key: 07 00 00 00  value: 0a cd 00 dd 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a cd 00 dd 00 35 00 00  00 00 00 00
key: 08 00 00 00  value: 0a cd 00 48 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f b7 ad 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f c3 32 10 94 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f de fa 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a cd 00 48 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a cd 00 5f 09 4b 00 00  00 00 00 00
Found 8 elements
