{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:11.664Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.194.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:11.664Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.195.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:11.664Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:15.817Z",
  "value": "id=461   sec_id=4     flags=0x0000 ifindex=10  mac=CA:B9:A9:57:CE:E6 nodemac=DE:6E:B7:EA:59:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:15.822Z",
  "value": "id=1687  sec_id=6756692 flags=0x0000 ifindex=12  mac=1A:E3:42:BD:43:74 nodemac=6E:03:77:B4:D9:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:15.899Z",
  "value": "id=580   sec_id=6756692 flags=0x0000 ifindex=14  mac=BA:E2:BD:9C:C8:2C nodemac=FE:65:DF:20:D0:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:15.946Z",
  "value": "id=461   sec_id=4     flags=0x0000 ifindex=10  mac=CA:B9:A9:57:CE:E6 nodemac=DE:6E:B7:EA:59:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:16.007Z",
  "value": "id=1687  sec_id=6756692 flags=0x0000 ifindex=12  mac=1A:E3:42:BD:43:74 nodemac=6E:03:77:B4:D9:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:47.982Z",
  "value": "id=461   sec_id=4     flags=0x0000 ifindex=10  mac=CA:B9:A9:57:CE:E6 nodemac=DE:6E:B7:EA:59:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:47.983Z",
  "value": "id=1687  sec_id=6756692 flags=0x0000 ifindex=12  mac=1A:E3:42:BD:43:74 nodemac=6E:03:77:B4:D9:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:47.983Z",
  "value": "id=580   sec_id=6756692 flags=0x0000 ifindex=14  mac=BA:E2:BD:9C:C8:2C nodemac=FE:65:DF:20:D0:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:48.010Z",
  "value": "id=134   sec_id=6771215 flags=0x0000 ifindex=16  mac=5E:3C:CD:01:34:EF nodemac=16:E9:81:E6:0B:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:48.011Z",
  "value": "id=134   sec_id=6771215 flags=0x0000 ifindex=16  mac=5E:3C:CD:01:34:EF nodemac=16:E9:81:E6:0B:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:48.983Z",
  "value": "id=461   sec_id=4     flags=0x0000 ifindex=10  mac=CA:B9:A9:57:CE:E6 nodemac=DE:6E:B7:EA:59:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:48.983Z",
  "value": "id=134   sec_id=6771215 flags=0x0000 ifindex=16  mac=5E:3C:CD:01:34:EF nodemac=16:E9:81:E6:0B:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:48.983Z",
  "value": "id=1687  sec_id=6756692 flags=0x0000 ifindex=12  mac=1A:E3:42:BD:43:74 nodemac=6E:03:77:B4:D9:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:48.983Z",
  "value": "id=580   sec_id=6756692 flags=0x0000 ifindex=14  mac=BA:E2:BD:9C:C8:2C nodemac=FE:65:DF:20:D0:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:56.606Z",
  "value": "id=3895  sec_id=6771215 flags=0x0000 ifindex=18  mac=EA:B0:84:D7:04:08 nodemac=72:27:27:EF:A8:CA"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.205.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.021Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.127Z",
  "value": "id=3895  sec_id=6771215 flags=0x0000 ifindex=18  mac=EA:B0:84:D7:04:08 nodemac=72:27:27:EF:A8:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.127Z",
  "value": "id=580   sec_id=6756692 flags=0x0000 ifindex=14  mac=BA:E2:BD:9C:C8:2C nodemac=FE:65:DF:20:D0:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.128Z",
  "value": "id=1687  sec_id=6756692 flags=0x0000 ifindex=12  mac=1A:E3:42:BD:43:74 nodemac=6E:03:77:B4:D9:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.129Z",
  "value": "id=461   sec_id=4     flags=0x0000 ifindex=10  mac=CA:B9:A9:57:CE:E6 nodemac=DE:6E:B7:EA:59:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.178Z",
  "value": "id=1687  sec_id=6756692 flags=0x0000 ifindex=12  mac=1A:E3:42:BD:43:74 nodemac=6E:03:77:B4:D9:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.196Z",
  "value": "id=580   sec_id=6756692 flags=0x0000 ifindex=14  mac=BA:E2:BD:9C:C8:2C nodemac=FE:65:DF:20:D0:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.197Z",
  "value": "id=3895  sec_id=6771215 flags=0x0000 ifindex=18  mac=EA:B0:84:D7:04:08 nodemac=72:27:27:EF:A8:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.197Z",
  "value": "id=461   sec_id=4     flags=0x0000 ifindex=10  mac=CA:B9:A9:57:CE:E6 nodemac=DE:6E:B7:EA:59:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.128Z",
  "value": "id=461   sec_id=4     flags=0x0000 ifindex=10  mac=CA:B9:A9:57:CE:E6 nodemac=DE:6E:B7:EA:59:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.128Z",
  "value": "id=3895  sec_id=6771215 flags=0x0000 ifindex=18  mac=EA:B0:84:D7:04:08 nodemac=72:27:27:EF:A8:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.128Z",
  "value": "id=1687  sec_id=6756692 flags=0x0000 ifindex=12  mac=1A:E3:42:BD:43:74 nodemac=6E:03:77:B4:D9:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.128Z",
  "value": "id=580   sec_id=6756692 flags=0x0000 ifindex=14  mac=BA:E2:BD:9C:C8:2C nodemac=FE:65:DF:20:D0:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.129Z",
  "value": "id=461   sec_id=4     flags=0x0000 ifindex=10  mac=CA:B9:A9:57:CE:E6 nodemac=DE:6E:B7:EA:59:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.129Z",
  "value": "id=3895  sec_id=6771215 flags=0x0000 ifindex=18  mac=EA:B0:84:D7:04:08 nodemac=72:27:27:EF:A8:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.129Z",
  "value": "id=1687  sec_id=6756692 flags=0x0000 ifindex=12  mac=1A:E3:42:BD:43:74 nodemac=6E:03:77:B4:D9:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.205.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.129Z",
  "value": "id=580   sec_id=6756692 flags=0x0000 ifindex=14  mac=BA:E2:BD:9C:C8:2C nodemac=FE:65:DF:20:D0:96"
}

