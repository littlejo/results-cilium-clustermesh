REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37969     3005520     677    bpf_overlay.c
Interface                 INGRESS     670159    135345899   1132   bpf_host.c
Success                   EGRESS      17762     1402437     1694   bpf_host.c
Success                   EGRESS      20448     3240572     86     l3.h
Success                   EGRESS      287077    35498983    1308   bpf_lxc.c
Success                   EGRESS      38912     3078816     53     encap.h
Success                   INGRESS     328035    37371097    86     l3.h
Success                   INGRESS     369341    42258798    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
