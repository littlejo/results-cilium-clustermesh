xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 568
ens6(5) clsact/ingress cil_from_netdev-ens6 id 580
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 560
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 555
cilium_host(7) clsact/egress cil_from_host-cilium_host id 553
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 516
lxc3ac355178ef9(12) clsact/ingress cil_from_container-lxc3ac355178ef9 id 540
lxcd48eda6cd65a(14) clsact/ingress cil_from_container-lxcd48eda6cd65a id 504
lxcbde5c36bae18(18) clsact/ingress cil_from_container-lxcbde5c36bae18 id 629

flow_dissector:

netfilter:

