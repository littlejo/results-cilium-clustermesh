IP ADDRESS         LOCAL ENDPOINT INFO
10.205.0.95:0      id=3895  sec_id=6771215 flags=0x0000 ifindex=18  mac=EA:B0:84:D7:04:08 nodemac=72:27:27:EF:A8:CA   
172.31.195.50:0    (localhost)                                                                                        
10.205.0.221:0     id=1687  sec_id=6756692 flags=0x0000 ifindex=12  mac=1A:E3:42:BD:43:74 nodemac=6E:03:77:B4:D9:2D   
172.31.194.239:0   (localhost)                                                                                        
10.205.0.8:0       id=461   sec_id=4     flags=0x0000 ifindex=10  mac=CA:B9:A9:57:CE:E6 nodemac=DE:6E:B7:EA:59:26     
10.205.0.72:0      id=580   sec_id=6756692 flags=0x0000 ifindex=14  mac=BA:E2:BD:9C:C8:2C nodemac=FE:65:DF:20:D0:96   
10.205.0.241:0     (localhost)                                                                                        
