alloc: 124.79MB (130847712 bytes)
total-alloc: 2.36GB (2538917896 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 65701146
frees: 64577723
heap-alloc: 124.79MB (130847712 bytes)
heap-sys: 247.29MB (259301376 bytes)
heap-idle: 78.31MB (82116608 bytes)
heap-in-use: 168.98MB (177184768 bytes)
heap-released: 3.88MB (4063232 bytes)
heap-objects: 1123423
stack-in-use: 64.69MB (67829760 bytes)
stack-sys: 64.69MB (67829760 bytes)
stack-mspan-inuse: 2.91MB (3056320 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 964.31KB (987457 bytes)
gc-sys: 6.01MB (6305352 bytes)
next-gc: when heap-alloc >= 212.77MB (223105880 bytes)
last-gc: 2024-10-30 08:23:13.095011453 +0000 UTC
gc-pause-total: 12.066016ms
gc-pause: 1540522
gc-pause-end: 1730276593095011453
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.00046408564612753406
enable-gc: true
debug-gc: false
