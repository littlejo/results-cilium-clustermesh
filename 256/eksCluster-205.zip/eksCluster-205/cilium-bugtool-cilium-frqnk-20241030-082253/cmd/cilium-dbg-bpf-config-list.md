KEY             VALUE
AgentLiveness   1796224489075
UTimeOffset     3379442986328125
