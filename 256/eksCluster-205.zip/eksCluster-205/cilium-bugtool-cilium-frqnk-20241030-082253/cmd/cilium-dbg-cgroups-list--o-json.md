[
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9624a37_e12b_47af_9176_37a1f11ee51e.slice/cri-containerd-6f4fb411f1a3ee08e9fed9212dffbddd0ac0548c1f497d2210341cca5036437e.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9624a37_e12b_47af_9176_37a1f11ee51e.slice/cri-containerd-691bb8e76ff27047ab844768df504b80eb9e04c20bc59393bdaa8a47b3e8d0a8.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9624a37_e12b_47af_9176_37a1f11ee51e.slice/cri-containerd-14a551b1cb81e1d3bc3b595cbdebdabbab6e2fb449b32329c3666c19b3df6f68.scope"
      }
    ],
    "ips": [
      "10.205.0.95"
    ],
    "name": "clustermesh-apiserver-54b96479f4-24zq5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod885cb3c6_b2f5_4b99_a12c_ee6bdb521e9d.slice/cri-containerd-f34a684760be353c932eefeda0e240271013635f05d22c21855d0a43fa32ca47.scope"
      }
    ],
    "ips": [
      "10.205.0.221"
    ],
    "name": "coredns-cc6ccd49c-h2ncc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4f6434de_c627_40e4_a86c_86750e0b8879.slice/cri-containerd-4157730ef497ee291bc06a1d834e5abdf4045a7d2064262f68d2edfd5594ff9a.scope"
      }
    ],
    "ips": [
      "10.205.0.72"
    ],
    "name": "coredns-cc6ccd49c-5jdcx",
    "namespace": "kube-system"
  }
]

