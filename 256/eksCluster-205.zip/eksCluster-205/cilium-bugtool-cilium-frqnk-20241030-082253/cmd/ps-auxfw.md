USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         705  0.0  0.1 1616264 8848 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         678  0.0  0.2 1240432 16020 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         712  0.0  0.0   6408  1636 ?        R    08:22   0:00  \_ ps auxfw
root         713  0.0  0.2 1240432 16020 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         667  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         666  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         654  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.5  4.7 1606080 382732 ?      Ssl  08:03   0:42 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.0  0.1 1229488 8004 ?        Sl   08:03   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
