key: 4b 01 00 00  value: 0a 02 00 00
key: 5f 08 00 00  value: 76 02 00 00
key: 8b 08 00 00  value: fd 01 00 00
key: d8 0a 00 00  value: 13 02 00 00
Found 4 elements
