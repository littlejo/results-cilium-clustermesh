key: 02 00 00 00  value: ac 1f 90 24 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a a3 00 9f 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a a3 00 fb 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f ff 6d 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f ea 52 10 94 00 00  00 00 00 00
key: 08 00 00 00  value: 0a a3 00 fb 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a a3 00 d7 09 4b 00 00  00 00 00 00
key: 07 00 00 00  value: 0a a3 00 9f 23 c1 00 00  00 00 00 00
Found 8 elements
