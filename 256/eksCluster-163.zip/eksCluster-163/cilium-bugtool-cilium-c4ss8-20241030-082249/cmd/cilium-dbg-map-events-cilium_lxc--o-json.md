{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:57.118Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.195.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:57.118Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.234.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:57.118Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:01.792Z",
  "value": "id=331   sec_id=5384893 flags=0x0000 ifindex=12  mac=12:DF:54:77:BB:83 nodemac=66:61:CA:E4:62:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:01.806Z",
  "value": "id=2776  sec_id=4     flags=0x0000 ifindex=10  mac=6E:2D:6F:0B:E7:94 nodemac=F6:CB:58:22:94:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:01.881Z",
  "value": "id=2187  sec_id=5384893 flags=0x0000 ifindex=14  mac=AA:AA:DE:E3:F3:06 nodemac=76:74:65:44:85:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:01.962Z",
  "value": "id=331   sec_id=5384893 flags=0x0000 ifindex=12  mac=12:DF:54:77:BB:83 nodemac=66:61:CA:E4:62:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:02.108Z",
  "value": "id=2776  sec_id=4     flags=0x0000 ifindex=10  mac=6E:2D:6F:0B:E7:94 nodemac=F6:CB:58:22:94:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:56.545Z",
  "value": "id=2776  sec_id=4     flags=0x0000 ifindex=10  mac=6E:2D:6F:0B:E7:94 nodemac=F6:CB:58:22:94:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:56.546Z",
  "value": "id=331   sec_id=5384893 flags=0x0000 ifindex=12  mac=12:DF:54:77:BB:83 nodemac=66:61:CA:E4:62:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:56.546Z",
  "value": "id=2187  sec_id=5384893 flags=0x0000 ifindex=14  mac=AA:AA:DE:E3:F3:06 nodemac=76:74:65:44:85:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:56.577Z",
  "value": "id=1527  sec_id=5388859 flags=0x0000 ifindex=16  mac=BE:03:01:D5:BF:DF nodemac=6A:6E:0B:02:FB:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:56.577Z",
  "value": "id=1527  sec_id=5388859 flags=0x0000 ifindex=16  mac=BE:03:01:D5:BF:DF nodemac=6A:6E:0B:02:FB:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:22.839Z",
  "value": "id=2143  sec_id=5388859 flags=0x0000 ifindex=18  mac=DA:32:BE:57:9B:2A nodemac=D6:59:A4:6D:30:96"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.163.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.186Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.647Z",
  "value": "id=2143  sec_id=5388859 flags=0x0000 ifindex=18  mac=DA:32:BE:57:9B:2A nodemac=D6:59:A4:6D:30:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.649Z",
  "value": "id=2776  sec_id=4     flags=0x0000 ifindex=10  mac=6E:2D:6F:0B:E7:94 nodemac=F6:CB:58:22:94:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.650Z",
  "value": "id=331   sec_id=5384893 flags=0x0000 ifindex=12  mac=12:DF:54:77:BB:83 nodemac=66:61:CA:E4:62:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.651Z",
  "value": "id=2187  sec_id=5384893 flags=0x0000 ifindex=14  mac=AA:AA:DE:E3:F3:06 nodemac=76:74:65:44:85:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.644Z",
  "value": "id=331   sec_id=5384893 flags=0x0000 ifindex=12  mac=12:DF:54:77:BB:83 nodemac=66:61:CA:E4:62:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.645Z",
  "value": "id=2776  sec_id=4     flags=0x0000 ifindex=10  mac=6E:2D:6F:0B:E7:94 nodemac=F6:CB:58:22:94:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.645Z",
  "value": "id=2187  sec_id=5384893 flags=0x0000 ifindex=14  mac=AA:AA:DE:E3:F3:06 nodemac=76:74:65:44:85:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.645Z",
  "value": "id=2143  sec_id=5388859 flags=0x0000 ifindex=18  mac=DA:32:BE:57:9B:2A nodemac=D6:59:A4:6D:30:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.644Z",
  "value": "id=2776  sec_id=4     flags=0x0000 ifindex=10  mac=6E:2D:6F:0B:E7:94 nodemac=F6:CB:58:22:94:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.644Z",
  "value": "id=331   sec_id=5384893 flags=0x0000 ifindex=12  mac=12:DF:54:77:BB:83 nodemac=66:61:CA:E4:62:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.645Z",
  "value": "id=2187  sec_id=5384893 flags=0x0000 ifindex=14  mac=AA:AA:DE:E3:F3:06 nodemac=76:74:65:44:85:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.163.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.645Z",
  "value": "id=2143  sec_id=5388859 flags=0x0000 ifindex=18  mac=DA:32:BE:57:9B:2A nodemac=D6:59:A4:6D:30:96"
}

