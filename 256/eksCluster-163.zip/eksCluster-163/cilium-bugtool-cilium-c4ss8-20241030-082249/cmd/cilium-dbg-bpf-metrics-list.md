REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37634     2983580     677    bpf_overlay.c
Interface                 INGRESS     658769    133959112   1132   bpf_host.c
Success                   EGRESS      17592     1391486     1694   bpf_host.c
Success                   EGRESS      279491    34727348    1308   bpf_lxc.c
Success                   EGRESS      38699     3062390     53     encap.h
Success                   INGRESS     324572    36632461    86     l3.h
Success                   INGRESS     345265    38268601    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
