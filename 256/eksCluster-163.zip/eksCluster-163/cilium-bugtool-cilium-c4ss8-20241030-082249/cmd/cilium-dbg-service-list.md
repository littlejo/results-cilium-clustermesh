ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.255.109:443 (active)   
                                         2 => 172.31.144.36:443 (active)    
2    10.100.8.4:443       ClusterIP      1 => 172.31.234.82:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.163.0.159:53 (active)      
                                         2 => 10.163.0.251:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.163.0.159:9153 (active)    
                                         2 => 10.163.0.251:9153 (active)    
5    10.100.12.228:2379   ClusterIP      1 => 10.163.0.215:2379 (active)    
