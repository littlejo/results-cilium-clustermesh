Endpoint ID: 255
Path: /sys/fs/bpf/tc/globals/cilium_policy_00255

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 331
Path: /sys/fs/bpf/tc/globals/cilium_policy_00331

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    128182   1470      0        
Allow    Egress      0          ANY          NONE         disabled    15776    170       0        


Endpoint ID: 2143
Path: /sys/fs/bpf/tc/globals/cilium_policy_02143

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11534150   115656    0        
Allow    Ingress     1          ANY          NONE         disabled    10760039   113905    0        
Allow    Egress      0          ANY          NONE         disabled    13839528   135621    0        


Endpoint ID: 2187
Path: /sys/fs/bpf/tc/globals/cilium_policy_02187

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    129158   1483      0        
Allow    Egress      0          ANY          NONE         disabled    16511    179       0        


Endpoint ID: 2776
Path: /sys/fs/bpf/tc/globals/cilium_policy_02776

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1642568   20771     0        
Allow    Ingress     1          ANY          NONE         disabled    19974     235       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


