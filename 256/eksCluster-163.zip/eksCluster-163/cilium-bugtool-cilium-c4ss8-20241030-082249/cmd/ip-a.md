1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:65:ea:53:39:13 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.234.82/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3465sec preferred_lft 3465sec
    inet6 fe80::865:eaff:fe53:3913/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:bc:7e:ed:58:85 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.195.79/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8bc:7eff:feed:5885/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:ca:2d:8c:b6:33 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a0ca:2dff:fe8c:b633/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:59:a0:14:3f:78 brd ff:ff:ff:ff:ff:ff
    inet 10.163.0.24/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::9059:a0ff:fe14:3f78/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ea:e4:0f:c6:8c:de brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e8e4:fff:fec6:8cde/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:cb:58:22:94:2d brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f4cb:58ff:fe22:942d/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc264cc2669359@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:61:ca:e4:62:54 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::6461:caff:fee4:6254/64 scope link 
       valid_lft forever preferred_lft forever
14: lxca14abff9c382@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:74:65:44:85:a9 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::7474:65ff:fe44:85a9/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc7b77c7a82f2d@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:59:a4:6d:30:96 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d459:a4ff:fe6d:3096/64 scope link 
       valid_lft forever preferred_lft forever
