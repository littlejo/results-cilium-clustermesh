 08:22:49 up 32 min,  0 users,  load average: 0.07, 0.17, 0.15
