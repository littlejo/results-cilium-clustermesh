CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod853ee7b5_b143_4717_bf2d_c2f7b5ab8d5b.slice/cri-containerd-4d2bafe18d8e7d3e03f7f839fbe7cc97752f186bb51b990462b851cf89ddcf70.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod853ee7b5_b143_4717_bf2d_c2f7b5ab8d5b.slice/cri-containerd-f28faf71cbfd6149ca9b2160d8f12e302c357e49885b765c5bdbbfd61e4547b6.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod12830373_14e1_4db9_9569_e24d274e5a43.slice/cri-containerd-8f797ca4be9b67dc591a11a05e7f3a6bf3741b364656293a39217535f6a4de6c.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod12830373_14e1_4db9_9569_e24d274e5a43.slice/cri-containerd-1a62ffe8fe96c26fc1443331e56183ed0433347c5e10f263d7b9f7a54042962f.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9da4b19b_3a3c_4561_919f_e2e995d210a0.slice/cri-containerd-7d1fa26b6df8588eda447511e016450de55bd837d47947fbbde7f2c00a9a43c4.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9da4b19b_3a3c_4561_919f_e2e995d210a0.slice/cri-containerd-a8d4e27bac5a2d61d77363998e7c18306e46afe366530c53620a10039bf34688.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod543a830e_78ec_4c04_a261_39a39688f06a.slice/cri-containerd-a93596032508678607fbf0754937e5ec0f7bbee6d85b483ec88b6d8d1c92356d.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod543a830e_78ec_4c04_a261_39a39688f06a.slice/cri-containerd-b6a2dea3f679ad066dde481c481ec98f9e787e1d726acfcec8feacf097d35e68.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55021f34_1bb3_4b6f_b667_cc6cea76c0ac.slice/cri-containerd-e3081cc973ede4ed40f8b8b6c98df6f644568d8c14cef68a9d8df12fc051d3f6.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55021f34_1bb3_4b6f_b667_cc6cea76c0ac.slice/cri-containerd-f7ca6d4ac2e4136951520f881a989ca113380149366eea7cdec9e53ec3f4e85e.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3b0e2db_407b_4eb5_ac37_7627b872726f.slice/cri-containerd-58b1a8fae2c9f7b7af6c2b0e0f6b1a2d03db6e30fa0d25dbf32726fff0ba0c7f.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3b0e2db_407b_4eb5_ac37_7627b872726f.slice/cri-containerd-0ccb8da4ac1a255cd4c69928d944f0d623a40ba81557ee4bb94d634f9f0b5a0a.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3b0e2db_407b_4eb5_ac37_7627b872726f.slice/cri-containerd-ea5a9d8c92ad904f63353e57657c8dbdd4f33e8f6e6eccb8a3bdec4cf267fd2e.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3b0e2db_407b_4eb5_ac37_7627b872726f.slice/cri-containerd-c5ca8d37cc241199dbebcaffaa0a4f56dc0c5ed3e063691b6ddc3c0dc5c126e6.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7be308c6_fec8_4f0c_891b_b0ec1c07b63a.slice/cri-containerd-d199b97a78849349b34e7d8d4ce6cd02ae60110572a0821f1bd1a7ad0225bb7c.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7be308c6_fec8_4f0c_891b_b0ec1c07b63a.slice/cri-containerd-38b34c14640ad5cd232021ed3937d1cc763b4d360f4bd6609db758e0dd285061.scope
    95       cgroup_device   multi                                          
