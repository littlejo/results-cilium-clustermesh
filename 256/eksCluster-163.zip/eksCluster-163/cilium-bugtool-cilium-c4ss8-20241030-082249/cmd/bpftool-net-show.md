xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 569
ens6(5) clsact/ingress cil_from_netdev-ens6 id 578
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 563
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 556
cilium_host(7) clsact/egress cil_from_host-cilium_host id 557
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 532
lxc264cc2669359(12) clsact/ingress cil_from_container-lxc264cc2669359 id 515
lxca14abff9c382(14) clsact/ingress cil_from_container-lxca14abff9c382 id 512
lxc7b77c7a82f2d(18) clsact/ingress cil_from_container-lxc7b77c7a82f2d id 623

flow_dissector:

netfilter:

