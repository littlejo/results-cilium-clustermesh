top - 08:22:50 up 32 min,  0 users,  load average: 0.07, 0.17, 0.15
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 12.9 us, 25.8 sy,  0.0 ni, 61.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4481.7 free,   1185.3 used,   2147.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6443.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 378020  77948 S   6.7   4.7   0:52.24 cilium-+
    643 root      20   0 1240432  16884  11484 S   6.7   0.2   0:00.03 cilium-+
    411 root      20   0 1229744   8240   3904 S   0.0   0.1   0:01.14 cilium-+
    667 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    678 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    684 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    694 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    719 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    737 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
