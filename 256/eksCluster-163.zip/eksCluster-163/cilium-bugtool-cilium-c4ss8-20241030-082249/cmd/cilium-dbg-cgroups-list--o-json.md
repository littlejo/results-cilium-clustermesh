[
  {
    "containers": [
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3b0e2db_407b_4eb5_ac37_7627b872726f.slice/cri-containerd-ea5a9d8c92ad904f63353e57657c8dbdd4f33e8f6e6eccb8a3bdec4cf267fd2e.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3b0e2db_407b_4eb5_ac37_7627b872726f.slice/cri-containerd-58b1a8fae2c9f7b7af6c2b0e0f6b1a2d03db6e30fa0d25dbf32726fff0ba0c7f.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3b0e2db_407b_4eb5_ac37_7627b872726f.slice/cri-containerd-c5ca8d37cc241199dbebcaffaa0a4f56dc0c5ed3e063691b6ddc3c0dc5c126e6.scope"
      }
    ],
    "ips": [
      "10.163.0.215"
    ],
    "name": "clustermesh-apiserver-7bbb858c74-6psf4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod543a830e_78ec_4c04_a261_39a39688f06a.slice/cri-containerd-a93596032508678607fbf0754937e5ec0f7bbee6d85b483ec88b6d8d1c92356d.scope"
      }
    ],
    "ips": [
      "10.163.0.251"
    ],
    "name": "coredns-cc6ccd49c-gqmb9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9da4b19b_3a3c_4561_919f_e2e995d210a0.slice/cri-containerd-a8d4e27bac5a2d61d77363998e7c18306e46afe366530c53620a10039bf34688.scope"
      }
    ],
    "ips": [
      "10.163.0.159"
    ],
    "name": "coredns-cc6ccd49c-zb45g",
    "namespace": "kube-system"
  }
]

