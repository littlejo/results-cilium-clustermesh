alloc: 138.39MB (145114896 bytes)
total-alloc: 2.31GB (2484914024 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 64521247
frees: 63473080
heap-alloc: 138.39MB (145114896 bytes)
heap-sys: 247.17MB (259178496 bytes)
heap-idle: 59.52MB (62414848 bytes)
heap-in-use: 187.65MB (196763648 bytes)
heap-released: 1.67MB (1753088 bytes)
heap-objects: 1048167
stack-in-use: 64.78MB (67928064 bytes)
stack-sys: 64.78MB (67928064 bytes)
stack-mspan-inuse: 2.89MB (3033760 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1015.17KB (1039529 bytes)
gc-sys: 6.02MB (6307304 bytes)
next-gc: when heap-alloc >= 213.24MB (223599256 bytes)
last-gc: 2024-10-30 08:23:06.475217936 +0000 UTC
gc-pause-total: 18.639823ms
gc-pause: 140416
gc-pause-end: 1730276586475217936
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0005400319859489912
enable-gc: true
debug-gc: false
