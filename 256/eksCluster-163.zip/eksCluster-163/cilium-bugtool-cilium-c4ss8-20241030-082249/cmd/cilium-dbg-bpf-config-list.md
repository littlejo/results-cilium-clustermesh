KEY             VALUE
AgentLiveness   1978679004465
UTimeOffset     3379442623046875
