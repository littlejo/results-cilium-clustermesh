IP ADDRESS        LOCAL ENDPOINT INFO
10.163.0.251:0    id=2187  sec_id=5384893 flags=0x0000 ifindex=14  mac=AA:AA:DE:E3:F3:06 nodemac=76:74:65:44:85:A9   
10.163.0.215:0    id=2143  sec_id=5388859 flags=0x0000 ifindex=18  mac=DA:32:BE:57:9B:2A nodemac=D6:59:A4:6D:30:96   
172.31.234.82:0   (localhost)                                                                                        
10.163.0.24:0     (localhost)                                                                                        
172.31.195.79:0   (localhost)                                                                                        
10.163.0.159:0    id=331   sec_id=5384893 flags=0x0000 ifindex=12  mac=12:DF:54:77:BB:83 nodemac=66:61:CA:E4:62:54   
10.163.0.68:0     id=2776  sec_id=4     flags=0x0000 ifindex=10  mac=6E:2D:6F:0B:E7:94 nodemac=F6:CB:58:22:94:2D     
