1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:ad:fa:87:c9:8b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.229.17/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3518sec preferred_lft 3518sec
    inet6 fe80::8ad:faff:fe87:c98b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:0d:ba:3d:09:e7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.216.175/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::80d:baff:fe3d:9e7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:a1:a4:48:45:bb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7ca1:a4ff:fe48:45bb/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:21:b8:81:31:fb brd ff:ff:ff:ff:ff:ff
    inet 10.91.0.52/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::4821:b8ff:fe81:31fb/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 5a:77:08:e8:4e:fb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5877:8ff:fee8:4efb/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:a5:74:09:18:59 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::5ca5:74ff:fe09:1859/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc0c38783dcf19@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:f9:69:de:15:f9 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::40f9:69ff:fede:15f9/64 scope link 
       valid_lft forever preferred_lft forever
14: lxca83444af2b56@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:a3:af:53:d9:71 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::68a3:afff:fe53:d971/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcc328831aae73@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:d7:57:e1:bc:2d brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::34d7:57ff:fee1:bc2d/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc32f36d987707@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:67:49:db:87:71 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::6467:49ff:fedb:8771/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcfb87c7d66b5a@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:9e:9c:9f:42:f7 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::a09e:9cff:fe9f:42f7/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc9bddaf415783@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:e9:b1:d5:dc:50 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::44e9:b1ff:fed5:dc50/64 scope link 
       valid_lft forever preferred_lft forever
