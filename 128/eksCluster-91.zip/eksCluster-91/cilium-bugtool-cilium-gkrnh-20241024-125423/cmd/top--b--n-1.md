top - 12:54:25 up 31 min,  0 users,  load average: 0.21, 0.35, 0.27
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 16.1 us, 19.4 sy,  0.0 ni, 64.5 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    320.7 free,   1047.5 used,   2468.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2607.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3192 root      20   0 1240432  15748  10768 S  12.5   0.4   0:00.03 cilium-+
      1 root      20   0 1539060 287848  78724 S   0.0   7.3   1:06.75 cilium-+
    396 root      20   0 1229488   9096   2928 S   0.0   0.2   0:04.49 cilium-+
   3143 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3150 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3180 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3186 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3199 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3237 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3255 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
