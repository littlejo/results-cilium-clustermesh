35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:48+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:49+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:54+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:23:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:23:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:31:24+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
485: sched_cls  name tail_handle_ipv4  tag c3f9a26cecaa0d75  gpl
	loaded_at 2024-10-24T12:31:24+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
486: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:31:24+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
487: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:31:24+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
488: sched_cls  name __send_drop_notify  tag 144ff126550e1274  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 129
489: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 130
490: sched_cls  name tail_handle_ipv4_from_host  tag 0efe634bcadc25f5  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,102
	btf_id 131
491: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,102
	btf_id 132
493: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,102
	btf_id 134
495: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 137
496: sched_cls  name tail_handle_ipv4_from_host  tag 0efe634bcadc25f5  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,104
	btf_id 138
497: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,104
	btf_id 139
501: sched_cls  name __send_drop_notify  tag 144ff126550e1274  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 143
502: sched_cls  name __send_drop_notify  tag 144ff126550e1274  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 145
504: sched_cls  name tail_handle_ipv4_from_host  tag 0efe634bcadc25f5  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,105
	btf_id 147
505: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,105
	btf_id 148
506: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,105,75
	btf_id 149
510: sched_cls  name tail_handle_ipv4_from_host  tag 0efe634bcadc25f5  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,107
	btf_id 154
511: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,107
	btf_id 155
512: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,107,75
	btf_id 156
515: sched_cls  name __send_drop_notify  tag 144ff126550e1274  gpl
	loaded_at 2024-10-24T12:31:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 159
523: sched_cls  name handle_policy  tag 29685fac992dc7dd  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 163
524: sched_cls  name __send_drop_notify  tag 260185bc4aa5f6b9  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 171
525: sched_cls  name tail_handle_arp  tag d30f253f0dd2b41f  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 172
527: sched_cls  name tail_handle_ipv4_cont  tag 7b1ec815c079b4ac  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 174
530: sched_cls  name tail_ipv4_to_endpoint  tag 6912e359e1c3bde3  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 175
531: sched_cls  name tail_ipv4_ct_ingress  tag 4c2e35d6fc909852  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 178
532: sched_cls  name tail_ipv4_ct_egress  tag a90921aa9d17fe33  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 179
533: sched_cls  name cil_from_container  tag 6ac7b20cd2966091  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 180
535: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 181
537: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 185
539: sched_cls  name tail_handle_ipv4  tag 3d52b81ba4147c02  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 183
540: sched_cls  name tail_ipv4_ct_ingress  tag 6f82e5a8bc97cc3f  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 189
541: sched_cls  name tail_handle_ipv4_cont  tag a504254525b6b050  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,118,41,100,82,83,39,76,74,77,117,40,37,38,81
	btf_id 190
542: sched_cls  name __send_drop_notify  tag 46afb1c4485dc74b  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 191
543: sched_cls  name handle_policy  tag 83de15f204e7db69  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 187
544: sched_cls  name tail_handle_arp  tag 23e5f6a06baa6bd4  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 193
545: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 194
547: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 196
548: sched_cls  name tail_handle_ipv4  tag b2ed3475993ad1fa  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 192
549: sched_cls  name tail_ipv4_ct_ingress  tag 1f854813873aad1e  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 198
550: sched_cls  name handle_policy  tag 01f019be9ab2b32f  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,117,82,83,118,41,80,100,39,84,75,40,37,38
	btf_id 197
551: sched_cls  name cil_from_container  tag 7d90fbb8f046cf0b  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 117,76
	btf_id 200
552: sched_cls  name tail_ipv4_to_endpoint  tag fbbf84eb83dfc586  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 199
553: sched_cls  name cil_from_container  tag 7d9b9f8f923a2f17  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 202
554: sched_cls  name __send_drop_notify  tag 87868007aa103937  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
555: sched_cls  name tail_handle_arp  tag d423a03adc13c1aa  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 204
556: sched_cls  name tail_ipv4_ct_egress  tag a90921aa9d17fe33  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 205
557: sched_cls  name tail_ipv4_to_endpoint  tag 8060e6b8ce79ea26  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,118,41,82,83,80,100,39,117,40,37,38
	btf_id 201
558: sched_cls  name tail_handle_ipv4_cont  tag 58c00f654d153e85  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 206
559: sched_cls  name tail_handle_ipv4  tag 4cc52e38b059400d  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 207
560: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
563: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
564: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
567: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
568: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
571: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
572: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
575: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
615: sched_cls  name tail_handle_ipv4  tag 8b75943813564a0b  gpl
	loaded_at 2024-10-24T12:41:56+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,135
	btf_id 221
616: sched_cls  name __send_drop_notify  tag e3d88d2707f9e396  gpl
	loaded_at 2024-10-24T12:41:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 222
617: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,135
	btf_id 223
618: sched_cls  name cil_from_container  tag 60ee99b258e9e1d6  gpl
	loaded_at 2024-10-24T12:41:56+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 135,76
	btf_id 224
619: sched_cls  name tail_ipv4_to_endpoint  tag f232259b97ccce32  gpl
	loaded_at 2024-10-24T12:41:56+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,134,41,82,83,80,133,39,135,40,37,38
	btf_id 225
620: sched_cls  name handle_policy  tag 840967ff8afb4eec  gpl
	loaded_at 2024-10-24T12:41:56+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,135,82,83,134,41,80,133,39,84,75,40,37,38
	btf_id 226
621: sched_cls  name tail_handle_arp  tag bcd5b54f3a68830b  gpl
	loaded_at 2024-10-24T12:41:56+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,135
	btf_id 227
622: sched_cls  name tail_ipv4_ct_ingress  tag 7a683fc24422d089  gpl
	loaded_at 2024-10-24T12:41:56+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 228
624: sched_cls  name tail_ipv4_ct_egress  tag 8700fb0f572906d9  gpl
	loaded_at 2024-10-24T12:41:56+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 230
625: sched_cls  name tail_handle_ipv4_cont  tag a4b3ec5b1a3c5bb4  gpl
	loaded_at 2024-10-24T12:41:56+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,134,41,133,82,83,39,76,74,77,135,40,37,38,81
	btf_id 231
626: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
629: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
642: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
645: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
646: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
649: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
687: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
690: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
691: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
694: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
695: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
698: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
699: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
702: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
703: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
706: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
707: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
710: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
711: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
714: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3256: sched_cls  name tail_ipv4_ct_egress  tag 3131b08e063c6f7b  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,621,82,83,622,84
	btf_id 3041
3257: sched_cls  name tail_ipv4_ct_ingress  tag 51d2c2f7d7e5f264  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,621,82,83,622,84
	btf_id 3042
3258: sched_cls  name tail_handle_ipv4_cont  tag a7fd5fde99135af1  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,622,41,146,82,83,39,76,74,77,621,40,37,38,81
	btf_id 3043
3259: sched_cls  name tail_handle_ipv4  tag 104aa84488147775  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,621
	btf_id 3044
3260: sched_cls  name cil_from_container  tag 4601ccbadc5b9232  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 621,76
	btf_id 3045
3261: sched_cls  name tail_handle_arp  tag 2a8e07c3e3e55021  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,621
	btf_id 3046
3262: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,621
	btf_id 3047
3265: sched_cls  name tail_ipv4_to_endpoint  tag 6a928b8758312512  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,622,41,82,83,80,146,39,621,40,37,38
	btf_id 3050
3266: sched_cls  name __send_drop_notify  tag 269836f370d43ec2  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3053
3269: sched_cls  name handle_policy  tag 5432bb509d4a4dc7  gpl
	loaded_at 2024-10-24T12:51:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,621,82,83,622,41,80,146,39,84,75,40,37,38
	btf_id 3055
3313: sched_cls  name tail_handle_ipv4_cont  tag a3217a8a257d0c57  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,634,41,143,82,83,39,76,74,77,633,40,37,38,81
	btf_id 3104
3314: sched_cls  name tail_handle_arp  tag bc464d50b5f8bfc6  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,633
	btf_id 3106
3315: sched_cls  name tail_ipv4_ct_egress  tag 4f00d0917409dd3f  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,631,82,83,632,84
	btf_id 3105
3316: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,633
	btf_id 3107
3317: sched_cls  name tail_ipv4_ct_egress  tag f55ac4f19f350907  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3109
3318: sched_cls  name tail_handle_ipv4_cont  tag 5212c2edbc855198  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,632,41,149,82,83,39,76,74,77,631,40,37,38,81
	btf_id 3108
3319: sched_cls  name tail_ipv4_to_endpoint  tag 1a7892edbc9db800  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,634,41,82,83,80,143,39,633,40,37,38
	btf_id 3110
3320: sched_cls  name tail_ipv4_ct_ingress  tag e2050bccfe25c495  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3112
3321: sched_cls  name handle_policy  tag e84bdc49e2f37dad  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,631,82,83,632,41,80,149,39,84,75,40,37,38
	btf_id 3111
3322: sched_cls  name tail_ipv4_ct_ingress  tag d929f81bba5f1fb2  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,631,82,83,632,84
	btf_id 3114
3323: sched_cls  name __send_drop_notify  tag a2de796817815326  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3115
3324: sched_cls  name handle_policy  tag ab2ba2438e26fd09  gpl
	loaded_at 2024-10-24T12:51:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,633,82,83,634,41,80,143,39,84,75,40,37,38
	btf_id 3113
3325: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,631
	btf_id 3117
3326: sched_cls  name tail_handle_ipv4  tag 971671a9716ad9eb  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,633
	btf_id 3116
3327: sched_cls  name __send_drop_notify  tag af010cf50d04a7a8  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3119
3328: sched_cls  name cil_from_container  tag fcdde6979d692603  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 633,76
	btf_id 3120
3329: sched_cls  name tail_ipv4_to_endpoint  tag 8b3b36ddaeb44062  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,632,41,82,83,80,149,39,631,40,37,38
	btf_id 3118
3330: sched_cls  name cil_from_container  tag 059ce8c5f8090f32  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 631,76
	btf_id 3121
3331: sched_cls  name tail_handle_ipv4  tag 11b29ab6df205833  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,631
	btf_id 3122
3332: sched_cls  name tail_handle_arp  tag 08c342aa4e361e15  gpl
	loaded_at 2024-10-24T12:51:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,631
	btf_id 3123
