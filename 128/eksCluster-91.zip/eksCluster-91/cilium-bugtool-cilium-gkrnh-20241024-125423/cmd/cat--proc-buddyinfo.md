Node 0, zone      DMA      1    132     40     38     17      9      6      1      2      3     49 
Node 0, zone   Normal    423     63     21     35     21     10      1      1      5      3      6 
