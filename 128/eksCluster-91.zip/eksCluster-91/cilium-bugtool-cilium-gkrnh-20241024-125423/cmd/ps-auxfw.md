USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3199  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root        3192  0.0  0.4 1240176 15748 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3226  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3228  0.0  0.0      4     4 ?        R    12:54   0:00  \_ [bash]
root        3186  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3180  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3150  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3143  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops stats 1
root           1  4.7  7.3 1539060 287848 ?      Ssl  12:31   1:06 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.3  0.2 1229488 9096 ?        Sl   12:31   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
