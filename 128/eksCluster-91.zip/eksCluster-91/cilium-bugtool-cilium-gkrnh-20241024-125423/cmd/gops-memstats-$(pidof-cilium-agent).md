alloc: 86.69MB (90903128 bytes)
total-alloc: 3.06GB (3288877120 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 74795183
frees: 74207612
heap-alloc: 86.69MB (90903128 bytes)
heap-sys: 174.92MB (183418880 bytes)
heap-idle: 42.11MB (44154880 bytes)
heap-in-use: 132.81MB (139264000 bytes)
heap-released: 3.01MB (3153920 bytes)
heap-objects: 587571
stack-in-use: 33.03MB (34635776 bytes)
stack-sys: 33.03MB (34635776 bytes)
stack-mspan-inuse: 2.06MB (2154880 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 999.74KB (1023737 bytes)
gc-sys: 5.53MB (5799032 bytes)
next-gc: when heap-alloc >= 149.42MB (156680808 bytes)
last-gc: 2024-10-24 12:54:47.877034933 +0000 UTC
gc-pause-total: 12.344421ms
gc-pause: 86417
gc-pause-end: 1729774487877034933
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0005789561833079925
enable-gc: true
debug-gc: false
