markdown output at /tmp/cilium-bugtool-20241024-125425.653+0000-UTC-2635311794/cmd/cilium-debuginfo-20241024-125455.83+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125425.653+0000-UTC-2635311794/cmd/cilium-debuginfo-20241024-125455.83+0000-UTC.json
