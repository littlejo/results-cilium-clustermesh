filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc9bddaf415783 direct-action not_in_hw id 3330 tag 059ce8c5f8090f32 jited 
