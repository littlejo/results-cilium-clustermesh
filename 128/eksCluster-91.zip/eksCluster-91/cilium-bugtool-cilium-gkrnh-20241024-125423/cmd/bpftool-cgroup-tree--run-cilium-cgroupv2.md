CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68362b35_3d48_46fa_bf92_59d841dcfbd8.slice/cri-containerd-d671e98c1e843d60a2bde0c96afc022605ef082c591cbffe0b43273ae587742c.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68362b35_3d48_46fa_bf92_59d841dcfbd8.slice/cri-containerd-29921be48e0982c90328dda96e080a3caea3d10283bf9c22b012d9f9d970dfbe.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67ed85a6_de70_4391_8dff_65bbf527ba03.slice/cri-containerd-a9b61b7e7ed08a1d7828efb1d5c9b23990141f40675ed3eb65141a89b9dad84b.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67ed85a6_de70_4391_8dff_65bbf527ba03.slice/cri-containerd-d474a6879582dbd9a36e03fabde8ea2541b527fc7c12495ddda831aa515b4886.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod57e4370c_dd98_4cb0_b5d3_31c52c0057f5.slice/cri-containerd-ef31200bdbd5f527500d00818e50a98bd0872884e3c0dfeabae4d4daf4e74895.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod57e4370c_dd98_4cb0_b5d3_31c52c0057f5.slice/cri-containerd-0068be858a78b11d971abe156b350729453c0f68ab46a3d188212fce3bf356fe.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8f626bf9_27ab_4cb2_bf32_fdfa8b56c4bf.slice/cri-containerd-21dbbcd588870ae7510da1c8f1cb8d78ae89a30d59ab5442236ab4f7f25c6d7f.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8f626bf9_27ab_4cb2_bf32_fdfa8b56c4bf.slice/cri-containerd-b7a3c04e0de8a69b6e5abf6cc6df61e078cecc66b844abfa1d8e8e56bb0d28f1.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17311a9d_123a_43d5_8b2f_e0b1fd590a76.slice/cri-containerd-30577522a421ada22842f68f4a807d6d2e66dd15d7f1ee7875c94362a73e2818.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17311a9d_123a_43d5_8b2f_e0b1fd590a76.slice/cri-containerd-d3f2ea3a052b9dd4b3ac86b8fdbdd64c38f6a215731eb4afa0dbe14e0f14aeb4.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod833bbec8_f207_4933_85fc_33b2e7c67735.slice/cri-containerd-5dac8f3f98965b9a1218d9a178f1af16fc8f2e40bd5e70418b9f58c2647bc2ce.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod833bbec8_f207_4933_85fc_33b2e7c67735.slice/cri-containerd-ba0c24d194cb5c04f1c7c510d2c8722cc42db0e14edbc25342a309c478bbde6f.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod833bbec8_f207_4933_85fc_33b2e7c67735.slice/cri-containerd-b2160963860860ee93f76f314f601b75e42b7921e41c249b2da82e3e35acf161.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod833bbec8_f207_4933_85fc_33b2e7c67735.slice/cri-containerd-ccc5cb07147e71aa273118ea9fe7ba431d5de3abd91fa2bb311796302df021b4.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod049d2fc5_15a0_4093_8a40_58df58fc60df.slice/cri-containerd-259c1c5478f87a7c41a1405be5c5c1a24dc9fa7d6fe26b6043625eb7b4e5c1f6.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod049d2fc5_15a0_4093_8a40_58df58fc60df.slice/cri-containerd-c487ca41f6661cbbf72032ac58d71d4eea072b95a00acfd1a5ab7d7f21982636.scope
    694      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod049d2fc5_15a0_4093_8a40_58df58fc60df.slice/cri-containerd-ad0c30f4a44afd8a87ce41e144726878455a57aedf7e816c553cb6f29804a78e.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33fd83dc_4570_4fed_93d8_6b5c96d576dc.slice/cri-containerd-f81a3bca3853ed1348d6d5635f71fe7a6a0b731f96cfc793d47f9f9ad0f9acc7.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33fd83dc_4570_4fed_93d8_6b5c96d576dc.slice/cri-containerd-0ada5966427cefe5b1ebeb53baaecc92eb38d14a6c286967f15bcd859d1b1dc1.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33b3f3d0_394f_4529_8433_ca95b763f5ed.slice/cri-containerd-b3e10784608baf697b87db90a9b65134f03895cd8a39545bacdc8b625ca5a395.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33b3f3d0_394f_4529_8433_ca95b763f5ed.slice/cri-containerd-7b43ea896a9aba25dd2dd4ecfc7be7845d11ca949fefdd9914cd805a9f3c909a.scope
    690      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1df15a41_49bb_458d_a846_9e8e4291d25f.slice/cri-containerd-197dda84174540b33eb7faba77a16543b0735d4255c4acd15a982a9c1ca0a620.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1df15a41_49bb_458d_a846_9e8e4291d25f.slice/cri-containerd-2d3ee4c8631a7f096fe85ced12fce30bd398f9bcdb5dc2e12b6625d8981097d0.scope
    698      cgroup_device   multi                                          
