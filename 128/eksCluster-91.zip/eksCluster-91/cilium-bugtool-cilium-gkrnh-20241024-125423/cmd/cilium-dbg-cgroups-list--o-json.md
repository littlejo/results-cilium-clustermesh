[
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1df15a41_49bb_458d_a846_9e8e4291d25f.slice/cri-containerd-197dda84174540b33eb7faba77a16543b0735d4255c4acd15a982a9c1ca0a620.scope"
      }
    ],
    "ips": [
      "10.91.0.96"
    ],
    "name": "client2-57cf4468f-2xq7c",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33b3f3d0_394f_4529_8433_ca95b763f5ed.slice/cri-containerd-b3e10784608baf697b87db90a9b65134f03895cd8a39545bacdc8b625ca5a395.scope"
      }
    ],
    "ips": [
      "10.91.0.148"
    ],
    "name": "client-974f6c69d-jqw95",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod833bbec8_f207_4933_85fc_33b2e7c67735.slice/cri-containerd-b2160963860860ee93f76f314f601b75e42b7921e41c249b2da82e3e35acf161.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod833bbec8_f207_4933_85fc_33b2e7c67735.slice/cri-containerd-5dac8f3f98965b9a1218d9a178f1af16fc8f2e40bd5e70418b9f58c2647bc2ce.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod833bbec8_f207_4933_85fc_33b2e7c67735.slice/cri-containerd-ba0c24d194cb5c04f1c7c510d2c8722cc42db0e14edbc25342a309c478bbde6f.scope"
      }
    ],
    "ips": [
      "10.91.0.235"
    ],
    "name": "clustermesh-apiserver-64bc8c4b59-9c44n",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod57e4370c_dd98_4cb0_b5d3_31c52c0057f5.slice/cri-containerd-ef31200bdbd5f527500d00818e50a98bd0872884e3c0dfeabae4d4daf4e74895.scope"
      }
    ],
    "ips": [
      "10.91.0.133"
    ],
    "name": "coredns-cc6ccd49c-5g9nk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68362b35_3d48_46fa_bf92_59d841dcfbd8.slice/cri-containerd-d671e98c1e843d60a2bde0c96afc022605ef082c591cbffe0b43273ae587742c.scope"
      }
    ],
    "ips": [
      "10.91.0.11"
    ],
    "name": "coredns-cc6ccd49c-bhdbr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod049d2fc5_15a0_4093_8a40_58df58fc60df.slice/cri-containerd-ad0c30f4a44afd8a87ce41e144726878455a57aedf7e816c553cb6f29804a78e.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod049d2fc5_15a0_4093_8a40_58df58fc60df.slice/cri-containerd-259c1c5478f87a7c41a1405be5c5c1a24dc9fa7d6fe26b6043625eb7b4e5c1f6.scope"
      }
    ],
    "ips": [
      "10.91.0.93"
    ],
    "name": "echo-same-node-86d9cc975c-ngqnz",
    "namespace": "cilium-test-1"
  }
]

