IP ADDRESS         LOCAL ENDPOINT INFO
10.91.0.96:0       id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50   
172.31.216.175:0   (localhost)                                                                                        
10.91.0.235:0      id=1368  sec_id=6058993 flags=0x0000 ifindex=18  mac=AE:31:00:1D:56:AF nodemac=36:D7:57:E1:BC:2D   
10.91.0.52:0       (localhost)                                                                                        
10.91.0.133:0      id=248   sec_id=6066233 flags=0x0000 ifindex=14  mac=26:10:32:43:E2:4F nodemac=6A:A3:AF:53:D9:71   
10.91.0.92:0       id=2697  sec_id=4     flags=0x0000 ifindex=10  mac=52:35:AD:11:B9:78 nodemac=5E:A5:74:09:18:59     
172.31.229.17:0    (localhost)                                                                                        
10.91.0.148:0      id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71   
10.91.0.11:0       id=3683  sec_id=6066233 flags=0x0000 ifindex=12  mac=BE:88:40:FF:BD:95 nodemac=42:F9:69:DE:15:F9   
10.91.0.93:0       id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7   
