{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.981Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.990Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.043Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.054Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.091Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.599Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.619Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.668Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.700Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.713Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.925Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.943Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.001Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.009Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.053Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.649Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.691Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.697Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.745Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.747Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.032Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.063Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.126Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.165Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.180Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.673Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.701Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.721Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.763Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.767Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.797Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.030Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.057Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.102Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.125Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.159Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.762Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.769Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.807Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.815Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.864Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.874Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.901Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.147Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.164Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.239Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.312Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.313Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.719Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.727Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.768Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.784Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.808Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.054Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.067Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.120Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.137Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.160Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.617Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.635Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.702Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.708Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.745Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.947Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.947Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.014Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.017Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.051Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.516Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.531Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.625Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.634Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.667Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.897Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.910Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.963Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.971Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.014Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.442Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.450Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.485Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.527Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.539Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.843Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.846Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.896Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.927Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.950Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.304Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.342Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.345Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.400Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.401Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.434Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.741Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.764Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.804Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.815Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.818Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.063Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.095Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.120Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.153Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.172Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.201Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.433Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.440Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.492Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.514Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.531Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.815Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.844Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.859Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.899Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.905Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.192Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.194Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.209Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.250Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.967Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.970Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.997Z",
  "value": "id=2489  sec_id=6088568 flags=0x0000 ifindex=22  mac=92:20:C3:B8:4C:77 nodemac=A2:9E:9C:9F:42:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.039Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.052Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.326Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.337Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.022Z",
  "value": "id=1180  sec_id=6049267 flags=0x0000 ifindex=20  mac=BE:1A:69:41:88:6B nodemac=66:67:49:DB:87:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.032Z",
  "value": "id=2226  sec_id=6072151 flags=0x0000 ifindex=24  mac=86:72:C2:2C:11:26 nodemac=46:E9:B1:D5:DC:50"
}

