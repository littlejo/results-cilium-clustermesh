Endpoint ID: 145
Path: /sys/fs/bpf/tc/globals/cilium_policy_00145

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 248
Path: /sys/fs/bpf/tc/globals/cilium_policy_00248

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1926     22        0        
Allow    Ingress     1          ANY          NONE         disabled    134778   1549      0        
Allow    Egress      0          ANY          NONE         disabled    18694    207       0        


Endpoint ID: 1180
Path: /sys/fs/bpf/tc/globals/cilium_policy_01180

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1368
Path: /sys/fs/bpf/tc/globals/cilium_policy_01368

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6110133   61141     0        
Allow    Ingress     1          ANY          NONE         disabled    5504189   58182     0        
Allow    Egress      0          ANY          NONE         disabled    6744486   66665     0        


Endpoint ID: 2226
Path: /sys/fs/bpf/tc/globals/cilium_policy_02226

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2489
Path: /sys/fs/bpf/tc/globals/cilium_policy_02489

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    381998   4462      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2697
Path: /sys/fs/bpf/tc/globals/cilium_policy_02697

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6237386   77256     0        
Allow    Ingress     1          ANY          NONE         disabled    59858     725       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3683
Path: /sys/fs/bpf/tc/globals/cilium_policy_03683

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3970     38        0        
Allow    Ingress     1          ANY          NONE         disabled    134303   1546      0        
Allow    Egress      0          ANY          NONE         disabled    19482    216       0        


