MountID:          1067
ParentID:         1046
Mounted State:    true
MountPoint:       /sys/fs/bpf
MountOptions:     rw,nosuid,nodev,noexec,relatime
OptionFields:     [master:7]
FilesystemType:   bpf
MountSource:      bpf
SuperOptions:     rw,mode=700
