filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcfb87c7d66b5a direct-action not_in_hw id 3260 tag 4601ccbadc5b9232 jited 
