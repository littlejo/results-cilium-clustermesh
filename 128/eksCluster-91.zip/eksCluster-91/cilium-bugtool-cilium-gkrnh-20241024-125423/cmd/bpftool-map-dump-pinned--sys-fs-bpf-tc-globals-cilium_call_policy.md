key: f8 00 00 00  value: 1f 02 00 00
key: 9c 04 00 00  value: fc 0c 00 00
key: 58 05 00 00  value: 6c 02 00 00
key: b2 08 00 00  value: f9 0c 00 00
key: b9 09 00 00  value: c5 0c 00 00
key: 89 0a 00 00  value: 26 02 00 00
key: 63 0e 00 00  value: 0b 02 00 00
Found 7 elements
