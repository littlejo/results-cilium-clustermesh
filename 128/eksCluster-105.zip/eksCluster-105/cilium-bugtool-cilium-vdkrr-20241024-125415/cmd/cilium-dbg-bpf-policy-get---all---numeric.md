Endpoint ID: 128
Path: /sys/fs/bpf/tc/globals/cilium_policy_00128

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 674
Path: /sys/fs/bpf/tc/globals/cilium_policy_00674

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 845
Path: /sys/fs/bpf/tc/globals/cilium_policy_00845

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6252762   77178     0        
Allow    Ingress     1          ANY          NONE         disabled    61967     746       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1207
Path: /sys/fs/bpf/tc/globals/cilium_policy_01207

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2782     30        0        
Allow    Ingress     1          ANY          NONE         disabled    129775   1491      0        
Allow    Egress      0          ANY          NONE         disabled    17598    193       0        


Endpoint ID: 1283
Path: /sys/fs/bpf/tc/globals/cilium_policy_01283

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2148
Path: /sys/fs/bpf/tc/globals/cilium_policy_02148

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6100344   61469     0        
Allow    Ingress     1          ANY          NONE         disabled    5471994   57827     0        
Allow    Egress      0          ANY          NONE         disabled    6924461   68240     0        


Endpoint ID: 2555
Path: /sys/fs/bpf/tc/globals/cilium_policy_02555

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3114     30        0        
Allow    Ingress     1          ANY          NONE         disabled    129712   1486      0        
Allow    Egress      0          ANY          NONE         disabled    18800    208       0        


Endpoint ID: 2690
Path: /sys/fs/bpf/tc/globals/cilium_policy_02690

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379679   4421      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


