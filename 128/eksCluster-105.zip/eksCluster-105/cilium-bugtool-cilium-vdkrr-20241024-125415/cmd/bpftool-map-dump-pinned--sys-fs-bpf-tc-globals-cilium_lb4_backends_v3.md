key: 06 00 00 00  value: 0a 69 00 18 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 69 00 18 23 c1 00 00  00 00 00 00
key: 0c 00 00 00  value: 0a 69 00 a5 1f 90 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 69 00 6b 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f fe 69 10 94 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f ac 13 01 bb 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f f8 80 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 69 00 d7 09 4b 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 69 00 6b 23 c1 00 00  00 00 00 00
Found 9 elements
