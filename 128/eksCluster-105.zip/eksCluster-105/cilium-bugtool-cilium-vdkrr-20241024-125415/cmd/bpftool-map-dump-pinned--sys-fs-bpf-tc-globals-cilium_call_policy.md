key: 80 00 00 00  value: 2b 0d 00 00
key: a2 02 00 00  value: 30 0d 00 00
key: 4d 03 00 00  value: 41 02 00 00
key: b7 04 00 00  value: 07 02 00 00
key: 64 08 00 00  value: 81 02 00 00
key: fb 09 00 00  value: 1e 02 00 00
key: 82 0a 00 00  value: ed 0c 00 00
Found 7 elements
