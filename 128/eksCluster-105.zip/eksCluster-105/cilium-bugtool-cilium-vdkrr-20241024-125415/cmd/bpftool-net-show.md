xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 565
ens6(5) clsact/ingress cil_from_netdev-ens6 id 569
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 552
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 540
cilium_host(7) clsact/egress cil_from_host-cilium_host id 539
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 578
lxc88120ae68375(12) clsact/ingress cil_from_container-lxc88120ae68375 id 536
lxc2edb7608bd49(14) clsact/ingress cil_from_container-lxc2edb7608bd49 id 534
lxcd96d99bd7294(18) clsact/ingress cil_from_container-lxcd96d99bd7294 id 646
lxc4cb4e72203d5(20) clsact/ingress cil_from_container-lxc4cb4e72203d5 id 3364
lxc3089027feb7b(22) clsact/ingress cil_from_container-lxc3089027feb7b id 3304
lxccf28daf43a0b(24) clsact/ingress cil_from_container-lxccf28daf43a0b id 3374

flow_dissector:

netfilter:

