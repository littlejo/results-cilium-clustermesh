{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.318Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.368Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.375Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.405Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.663Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.669Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.728Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.773Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.803Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.385Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.427Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.447Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.474Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.507Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.737Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.744Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.801Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.812Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.858Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.395Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.403Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.436Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.446Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.487Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.500Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.530Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.754Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.779Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.844Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.858Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.915Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.461Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.465Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.498Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.539Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.547Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.581Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.590Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.839Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.840Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.917Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.957Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.982Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.372Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.375Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.418Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.450Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.460Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.708Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.717Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.768Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.784Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.823Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.194Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.240Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.240Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.295Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.296Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.335Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.566Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.566Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.616Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.641Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.674Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.060Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.151Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.158Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.232Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.232Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.233Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.471Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.476Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.526Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.537Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.569Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.960Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.022Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.038Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.073Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.115Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.116Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.337Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.342Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.399Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.409Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.440Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.824Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.866Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.872Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.922Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.924Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.959Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.176Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.200Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.257Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.304Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.364Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.633Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.672Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.675Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.720Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.748Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.763Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.020Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.039Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.079Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.098Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.140Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.438Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.486Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.512Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.555Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.589Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.611Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.803Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.818Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.825Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.833Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.857Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.569Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.572Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.605Z",
  "value": "id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.630Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.643Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.932Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.940Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.569Z",
  "value": "id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.572Z",
  "value": "id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6"
}

