1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:bd:82:ce:57:e5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.254.105/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3538sec preferred_lft 3538sec
    inet6 fe80::8bd:82ff:fece:57e5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:2e:ca:d3:40:2f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.192.78/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::82e:caff:fed3:402f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:3e:4d:4c:4d:fc brd ff:ff:ff:ff:ff:ff
    inet6 fe80::883e:4dff:fe4c:4dfc/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:ef:1e:85:1d:3f brd ff:ff:ff:ff:ff:ff
    inet 10.105.0.155/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d8ef:1eff:fe85:1d3f/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 4a:92:38:c4:e6:27 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4892:38ff:fec4:e627/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:61:91:8a:fd:e6 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c861:91ff:fe8a:fde6/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc88120ae68375@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:de:09:02:af:7e brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::28de:9ff:fe02:af7e/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc2edb7608bd49@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:2b:aa:f5:e5:f7 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::42b:aaff:fef5:e5f7/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcd96d99bd7294@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:e2:c5:a7:ae:fc brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c4e2:c5ff:fea7:aefc/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc4cb4e72203d5@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:45:cf:1b:2c:db brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::9045:cfff:fe1b:2cdb/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc3089027feb7b@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:ce:23:06:2a:66 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::d8ce:23ff:fe06:2a66/64 scope link 
       valid_lft forever preferred_lft forever
24: lxccf28daf43a0b@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:ec:60:18:d2:a6 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::54ec:60ff:fe18:d2a6/64 scope link 
       valid_lft forever preferred_lft forever
