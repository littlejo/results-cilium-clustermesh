[
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56603f76_7feb_47e9_ac69_ccf7dbdc979e.slice/cri-containerd-fba56dc1ea0a6b249b25735d2e46d0d7034276db3597539145393d1ab07f1ea6.scope"
      }
    ],
    "ips": [
      "10.105.0.24"
    ],
    "name": "coredns-cc6ccd49c-j65pr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0d20bef7_b301_4846_91e6_f57d3d852409.slice/cri-containerd-063c5b8eea5dab31adb7229da79697b1e6572a007c4c3d2b84915fbf28245106.scope"
      }
    ],
    "ips": [
      "10.105.0.35"
    ],
    "name": "client-974f6c69d-ttg2v",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode12f1d5a_8abc_4424_87de_d5a0876fa77f.slice/cri-containerd-0de242ac53ac9dab849d70ef789aa616fad34dd254a937bff1137dc4448dc16e.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode12f1d5a_8abc_4424_87de_d5a0876fa77f.slice/cri-containerd-0481de5fe53531ff117e0adece15ef3e36a7aa8a62de45a59ceebc246c144fec.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode12f1d5a_8abc_4424_87de_d5a0876fa77f.slice/cri-containerd-51463a1cc86d9d0c8b52b10d522bf5c54f50ff59eb00c429e32932cc05b63acb.scope"
      }
    ],
    "ips": [
      "10.105.0.215"
    ],
    "name": "clustermesh-apiserver-59cbf8bbd9-ckml4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaaf82f48_faad_49f7_b09b_4991a42a99fa.slice/cri-containerd-b716f83b710a3d3ccc2be3e67379c0ab6f579db206b7f477ea6e67244d195eaa.scope"
      }
    ],
    "ips": [
      "10.105.0.123"
    ],
    "name": "client2-57cf4468f-m4g4w",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0c7cd50_c864_4168_a170_4bc080d47ca2.slice/cri-containerd-4edd2058bed81ec7edc56e37f41121df44115c119045daed4af461fd41ab0b15.scope"
      },
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0c7cd50_c864_4168_a170_4bc080d47ca2.slice/cri-containerd-477369c92cecd24774dbf557f3d9ab388cf79373f010d99d9e9fc591b32f228d.scope"
      }
    ],
    "ips": [
      "10.105.0.165"
    ],
    "name": "echo-same-node-86d9cc975c-lqzv6",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaede810d_e714_45a7_93e7_3117c5c672ff.slice/cri-containerd-03adc9065bf40d836afd219d5b395f840602e6896d9e156248aeb2951b157300.scope"
      }
    ],
    "ips": [
      "10.105.0.107"
    ],
    "name": "coredns-cc6ccd49c-9mn56",
    "namespace": "kube-system"
  }
]

