Total: 582
TCP:   3963 (estab 304, closed 3640, orphaned 0, timewait 3176)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  323       313       10       
INET	  333       319       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                            127.0.0.1:46641      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=38)) ino:34920 sk:1001 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.254.105%ens5:68         0.0.0.0:*    uid:192 ino:147230 sk:1002 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:34391 sk:1003 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15195 sk:1004 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:34390 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15196 sk:1006 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::8bd:82ff:fece:57e5]%ens5:546           [::]:*    uid:192 ino:16403 sk:1007 cgroup:unreachable:bd0 v6only:1 <->                   
