KEY             VALUE
AgentLiveness   1903643461091
UTimeOffset     3378462078125000
