CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56603f76_7feb_47e9_ac69_ccf7dbdc979e.slice/cri-containerd-fba56dc1ea0a6b249b25735d2e46d0d7034276db3597539145393d1ab07f1ea6.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56603f76_7feb_47e9_ac69_ccf7dbdc979e.slice/cri-containerd-9b78608b9a22b0a2d96a554d24c1115937fd61726876ba22d39b8ca6c91f0266.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod21eaa205_f9f2_425f_9def_a315005c8929.slice/cri-containerd-a718def9dff67364632379376c933aa6102c6c07957633d39a324fbd40119793.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod21eaa205_f9f2_425f_9def_a315005c8929.slice/cri-containerd-5cc73b1fe6b86990457ac66977d0dfce1d799762dda7b7b9338626ef0049f939.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod59cb2ee2_636f_4e1a_8e25_b55a55fe77d2.slice/cri-containerd-4ef8202023efdbba44532c8ac1421405e94cde09a2e3e89a7df3c5ccbfc5fe60.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod59cb2ee2_636f_4e1a_8e25_b55a55fe77d2.slice/cri-containerd-fc68467b94dd978f3bb178683c475e7e0a614db4f1c4e6b507cb89d9aa73db00.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaede810d_e714_45a7_93e7_3117c5c672ff.slice/cri-containerd-9f4a6f1dd1d458b7a493c2ad108123cf12744c166489769422506926a4407ea3.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaede810d_e714_45a7_93e7_3117c5c672ff.slice/cri-containerd-03adc9065bf40d836afd219d5b395f840602e6896d9e156248aeb2951b157300.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f7daf44_97f4_48c9_bcd3_543ec90c5134.slice/cri-containerd-0ff213dd8560804b495d48767ed2738f156f25db365680400b649c6767be1cfa.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f7daf44_97f4_48c9_bcd3_543ec90c5134.slice/cri-containerd-9c8b22f23c07c2bf1a48e1fb2fc533453c4b303c098c293103e23c0861503817.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaaf82f48_faad_49f7_b09b_4991a42a99fa.slice/cri-containerd-5f4277087522eb7cb6b6b8deffcf4b6a6f881666cb6a62edaf34cb84c6c79b76.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaaf82f48_faad_49f7_b09b_4991a42a99fa.slice/cri-containerd-b716f83b710a3d3ccc2be3e67379c0ab6f579db206b7f477ea6e67244d195eaa.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0d20bef7_b301_4846_91e6_f57d3d852409.slice/cri-containerd-287798305ffeeae4703998f54c4332b3a2826d0845e9a5b38670a578c993dec9.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0d20bef7_b301_4846_91e6_f57d3d852409.slice/cri-containerd-063c5b8eea5dab31adb7229da79697b1e6572a007c4c3d2b84915fbf28245106.scope
    727      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode12f1d5a_8abc_4424_87de_d5a0876fa77f.slice/cri-containerd-e1fecb980ef07f40f634609d2ab3118bb7b37ee05da08e25f7333d90fc4e0442.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode12f1d5a_8abc_4424_87de_d5a0876fa77f.slice/cri-containerd-51463a1cc86d9d0c8b52b10d522bf5c54f50ff59eb00c429e32932cc05b63acb.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode12f1d5a_8abc_4424_87de_d5a0876fa77f.slice/cri-containerd-0481de5fe53531ff117e0adece15ef3e36a7aa8a62de45a59ceebc246c144fec.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode12f1d5a_8abc_4424_87de_d5a0876fa77f.slice/cri-containerd-0de242ac53ac9dab849d70ef789aa616fad34dd254a937bff1137dc4448dc16e.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5a6a9647_834d_4db6_b416_9db03a4fc570.slice/cri-containerd-a79eeb6afd9d81a2cccc2d0ee12aac9858a439197fca25fa652b5cfdefeca358.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5a6a9647_834d_4db6_b416_9db03a4fc570.slice/cri-containerd-dbb4f6f88332fc17dd7d716746d5f8282244d0b60df7882f96b70fb2f1722f18.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0c7cd50_c864_4168_a170_4bc080d47ca2.slice/cri-containerd-8d70bff87dd626c027b18d8f5854de9590562bf9e380a2735491e4a5507045cf.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0c7cd50_c864_4168_a170_4bc080d47ca2.slice/cri-containerd-477369c92cecd24774dbf557f3d9ab388cf79373f010d99d9e9fc591b32f228d.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf0c7cd50_c864_4168_a170_4bc080d47ca2.slice/cri-containerd-4edd2058bed81ec7edc56e37f41121df44115c119045daed4af461fd41ab0b15.scope
    735      cgroup_device   multi                                          
