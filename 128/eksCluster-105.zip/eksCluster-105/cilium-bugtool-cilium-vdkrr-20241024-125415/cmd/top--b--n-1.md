top - 12:54:16 up 31 min,  0 users,  load average: 0.76, 0.62, 0.35
Tasks:   9 total,   3 running,   5 sleeping,   0 stopped,   1 zombie
%Cpu(s): 46.7 us, 50.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   3836.2 total,    280.4 free,   1058.8 used,   2496.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2596.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 296692  79100 S  66.7   7.6   1:08.53 cilium-+
    406 root      20   0 1229744  10056   3836 S   0.0   0.3   0:04.52 cilium-+
   3255 root      20   0 1240432  16028  11100 S   0.0   0.4   0:00.02 cilium-+
   3268 root      20   0       0      0      0 Z   0.0   0.0   0:00.00 gops
   3269 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3313 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3324 root      20   0    2208    792    716 S   0.0   0.0   0:00.00 timeout
   3332 root      20   0 1242676  14160  11128 R   0.0   0.4   0:00.00 hubble
   3339 root      20   0    4220    828    720 R   0.0   0.0   0:00.00 ip
