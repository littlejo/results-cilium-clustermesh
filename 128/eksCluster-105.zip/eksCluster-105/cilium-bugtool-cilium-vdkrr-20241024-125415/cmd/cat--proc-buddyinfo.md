Node 0, zone      DMA     15     41      5     11     16      8     12      4      1      2     41 
Node 0, zone   Normal    143     17     29      2     11      5      4      3      1      2      8 
