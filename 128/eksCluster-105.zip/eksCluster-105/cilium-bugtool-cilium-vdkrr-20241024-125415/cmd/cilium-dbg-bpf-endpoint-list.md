IP ADDRESS         LOCAL ENDPOINT INFO
10.105.0.215:0     id=2148  sec_id=6949865 flags=0x0000 ifindex=18  mac=0A:93:C1:22:9F:23 nodemac=C6:E2:C5:A7:AE:FC   
172.31.192.78:0    (localhost)                                                                                        
10.105.0.107:0     id=2555  sec_id=6981028 flags=0x0000 ifindex=12  mac=62:3B:D2:DA:19:96 nodemac=2A:DE:09:02:AF:7E   
172.31.254.105:0   (localhost)                                                                                        
10.105.0.123:0     id=128   sec_id=7004635 flags=0x0000 ifindex=24  mac=C2:63:3F:2B:F8:ED nodemac=56:EC:60:18:D2:A6   
10.105.0.155:0     (localhost)                                                                                        
10.105.0.104:0     id=845   sec_id=4     flags=0x0000 ifindex=10  mac=C2:D6:E9:37:2C:57 nodemac=CA:61:91:8A:FD:E6     
10.105.0.35:0      id=674   sec_id=6948267 flags=0x0000 ifindex=20  mac=6A:AE:B3:B4:D7:38 nodemac=92:45:CF:1B:2C:DB   
10.105.0.165:0     id=2690  sec_id=6952262 flags=0x0000 ifindex=22  mac=D2:84:85:3B:12:2C nodemac=DA:CE:23:06:2A:66   
10.105.0.24:0      id=1207  sec_id=6981028 flags=0x0000 ifindex=14  mac=0E:E6:89:47:F3:C5 nodemac=06:2B:AA:F5:E5:F7   
