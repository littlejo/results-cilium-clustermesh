alloc: 140.23MB (147045008 bytes)
total-alloc: 3.11GB (3336093576 bytes)
sys: 231.32MB (242558292 bytes)
lookups: 0
mallocs: 75398665
frees: 74031060
heap-alloc: 140.23MB (147045008 bytes)
heap-sys: 184.64MB (193609728 bytes)
heap-idle: 23.80MB (24961024 bytes)
heap-in-use: 160.84MB (168648704 bytes)
heap-released: 8.73MB (9150464 bytes)
heap-objects: 1367605
stack-in-use: 35.31MB (37027840 bytes)
stack-sys: 35.31MB (37027840 bytes)
stack-mspan-inuse: 2.40MB (2521600 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 999.63KB (1023625 bytes)
gc-sys: 5.52MB (5786672 bytes)
next-gc: when heap-alloc >= 146.56MB (153682584 bytes)
last-gc: 2024-10-24 12:54:09.735412483 +0000 UTC
gc-pause-total: 20.859239ms
gc-pause: 92620
gc-pause-end: 1729774449735412483
num-gc: 97
num-forced-gc: 0
gc-cpu-fraction: 0.0006716145496925005
enable-gc: true
debug-gc: false
