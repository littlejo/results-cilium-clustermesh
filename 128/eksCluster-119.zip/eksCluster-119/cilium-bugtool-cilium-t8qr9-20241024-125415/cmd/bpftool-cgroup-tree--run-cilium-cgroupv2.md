CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod991c49a3_8625_491d_af37_884a19d6ac41.slice/cri-containerd-c7018fec46221f1f51314fabe017fa10a5fdc1139e321de382c0c832bcc6afa4.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod991c49a3_8625_491d_af37_884a19d6ac41.slice/cri-containerd-392a5a4d9133a53ba9dd4228adb3d89c8c5a917b8bd0cb33c88aec6a39581553.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8aa355a0_bc04_4127_9746_d6050c746e5f.slice/cri-containerd-c4a8d9e1865f59eb66b621981f661df489dbfbbbc37cac3b35b99a2f4e9d8b1f.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8aa355a0_bc04_4127_9746_d6050c746e5f.slice/cri-containerd-6b1c3ff9ad02792d9d695183d6ef1c8a5869f1e6e2f1784f8f42bc7541e6c99d.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04462e80_15a0_414c_90d1_b992f82c8164.slice/cri-containerd-bee3c230b9a4b55a4835f9d626a2c849e3b8476e23962a68fefcc759a1e864ce.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04462e80_15a0_414c_90d1_b992f82c8164.slice/cri-containerd-93cec1bc4df91d22e0e344a83e749ee091797c83777026bd17c4b74a2f5473f1.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45fd6558_f633_4269_9d7e_f12d1266219c.slice/cri-containerd-bcc73962da1ec5a32977bd75e5585a8813add1dfea1b47c8cc0af8e839f9062e.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45fd6558_f633_4269_9d7e_f12d1266219c.slice/cri-containerd-dc08ad18e3cd0f8f4102ff0022f8037d72f3ed06d681e6d80479649ee8f3edda.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode9ed67ea_db42_44ad_8c17_155ddb8401d6.slice/cri-containerd-97902501b9006595feab6dbe15708e23f51bb671476583cdd6028a12c785685b.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode9ed67ea_db42_44ad_8c17_155ddb8401d6.slice/cri-containerd-08f603cb8230076b82f8f474e4e18acd036429d2d6800ed29fff28390e3bbb26.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode9ed67ea_db42_44ad_8c17_155ddb8401d6.slice/cri-containerd-ee1384b8dae128208f4dda563d3c76ec617d4573f088f53cc48350619db68bcb.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode9ed67ea_db42_44ad_8c17_155ddb8401d6.slice/cri-containerd-fdbd0ed7f23977a599627c8fbbbbb49638c63af19ea9bab223080270fd57c252.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4141bd95_f92e_4ad1_909b_b3b5ea4c3be0.slice/cri-containerd-014e84d6eb04371b80cd6725961f8fc287830ddfd0cf11119f282e3554f9d6f5.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4141bd95_f92e_4ad1_909b_b3b5ea4c3be0.slice/cri-containerd-96961130c593814c6d45ea770f274301c594df7ff115a73a0c02d05701e00a0e.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda30ac357_ea78_4e7e_bf9d_f6ff4eefcc1c.slice/cri-containerd-fbb3a0eaea533b745c190efeabd59baa838a8fdd660219d601ef8435e9e14611.scope
    694      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda30ac357_ea78_4e7e_bf9d_f6ff4eefcc1c.slice/cri-containerd-40dbe2af3cd1f44784cc5683adb3fca3f54b4608f846a5ac9935d4be9ca08b8a.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9894d9b6_4e65_45eb_991b_5097d50d8c9e.slice/cri-containerd-2e2929ca1b1ff6a10336f1cbdedd478908e467b4c3a1a6f83fef8067a08f5332.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9894d9b6_4e65_45eb_991b_5097d50d8c9e.slice/cri-containerd-293e6a26c31de8efc0464c8db3a8cd3e27d26af6bd3518fdd30b143effe98d07.scope
    698      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e449fe8_55ea_4d12_8f13_9ef24a79db6a.slice/cri-containerd-5854bb923a7057edd4b50cd70369f7c0d893ce049f4d1922cac2a6d42b9c6924.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e449fe8_55ea_4d12_8f13_9ef24a79db6a.slice/cri-containerd-d5a9aba4b672ed776acd69d6b948dcc77c22ef182f6e48f92b100b8e6e3fc469.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40c7a6d5_a6a7_42dc_8f1f_1afe6b93e11b.slice/cri-containerd-381e205f067abe730a97e2aa8a0ee82efd31988881e55f86c4cc1bacc3629b2e.scope
    690      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40c7a6d5_a6a7_42dc_8f1f_1afe6b93e11b.slice/cri-containerd-4f0aef812b4a7ea569881de9f453031b77476ab7e13dfdca4e1e9a26d9336a9a.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40c7a6d5_a6a7_42dc_8f1f_1afe6b93e11b.slice/cri-containerd-e4138c9895723414db092dc3b06a491d5402aba6ab8ceb8e450347775f9d4001.scope
    714      cgroup_device   multi                                          
