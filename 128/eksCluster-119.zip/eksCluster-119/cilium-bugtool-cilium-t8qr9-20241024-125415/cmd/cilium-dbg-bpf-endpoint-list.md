IP ADDRESS        LOCAL ENDPOINT INFO
10.119.0.60:0     id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E   
10.119.0.204:0    (localhost)                                                                                        
10.119.0.40:0     id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0   
10.119.0.234:0    id=970   sec_id=7868923 flags=0x0000 ifindex=18  mac=BA:23:11:23:AA:49 nodemac=E2:3D:9F:BF:18:5A   
172.31.233.58:0   (localhost)                                                                                        
172.31.228.77:0   (localhost)                                                                                        
10.119.0.18:0     id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C   
10.119.0.66:0     id=559   sec_id=7873047 flags=0x0000 ifindex=14  mac=EE:E4:3B:63:67:9F nodemac=A6:7B:D3:91:76:7D   
10.119.0.181:0    id=1969  sec_id=4     flags=0x0000 ifindex=10  mac=02:8A:8E:F2:68:F3 nodemac=C2:3A:F6:F2:7F:8A     
10.119.0.49:0     id=1393  sec_id=7873047 flags=0x0000 ifindex=12  mac=E2:89:A3:BA:30:8B nodemac=1A:7D:44:4C:8B:A0   
