Node 0, zone      DMA     26     23     19     22     16      1      7      3      4      3     35 
Node 0, zone   Normal    122     31     17     13      3      6      4      3      1      4      7 
