filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc534009a5a3d5 direct-action not_in_hw id 3304 tag 4d5c892aee6a4731 jited 
