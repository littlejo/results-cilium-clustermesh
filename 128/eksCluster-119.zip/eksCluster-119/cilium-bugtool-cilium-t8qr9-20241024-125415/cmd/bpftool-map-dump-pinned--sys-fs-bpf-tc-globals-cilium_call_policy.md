key: f1 00 00 00  value: ed 0c 00 00
key: 2f 02 00 00  value: 24 02 00 00
key: ca 03 00 00  value: 68 02 00 00
key: 71 05 00 00  value: 17 02 00 00
key: 1d 06 00 00  value: b4 0c 00 00
key: b1 07 00 00  value: 23 02 00 00
key: 35 09 00 00  value: f0 0c 00 00
Found 7 elements
