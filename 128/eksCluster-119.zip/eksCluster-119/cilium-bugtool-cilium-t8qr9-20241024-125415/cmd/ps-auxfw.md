USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3245  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3236  0.0  0.4 1240432 16168 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3269  0.0  0.0   6408  1640 ?        R    12:54   0:00  \_ ps auxfw
root        3271  0.0  0.0   2068   240 ?        R    12:54   0:00  \_ hostname
root        3235  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  5.6  7.5 1539388 298216 ?      Ssl  12:33   1:11 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.3  0.2 1229744 9004 ?        Sl   12:33   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
