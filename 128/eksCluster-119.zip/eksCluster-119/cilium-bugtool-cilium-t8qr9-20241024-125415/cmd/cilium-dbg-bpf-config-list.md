KEY             VALUE
AgentLiveness   1880936797250
UTimeOffset     3378462121093750
