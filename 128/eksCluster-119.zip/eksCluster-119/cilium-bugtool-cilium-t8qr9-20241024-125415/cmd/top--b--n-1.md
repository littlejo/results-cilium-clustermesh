top - 12:54:16 up 30 min,  0 users,  load average: 0.57, 0.56, 0.35
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 21.4 us, 50.0 sy,  0.0 ni, 28.6 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    281.6 free,   1057.5 used,   2497.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2597.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3236 root      20   0 1240432  16480  11164 S   6.7   0.4   0:00.04 cilium-+
      1 root      20   0 1539388 298216  77564 S   0.0   7.6   1:11.50 cilium-+
    395 root      20   0 1229744   9004   2864 S   0.0   0.2   0:04.48 cilium-+
   3235 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3245 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3280 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3286 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
   3300 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3324 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
