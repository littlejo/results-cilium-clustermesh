REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     136370    11064837    677    bpf_overlay.c
Interface                   INGRESS     698985    250337420   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      138209    11193529    53     encap.h
Success                     EGRESS      161664    21301683    1308   bpf_lxc.c
Success                     EGRESS      596       156299      86     l3.h
Success                     EGRESS      59925     4862311     1694   bpf_host.c
Success                     INGRESS     186530    21564053    86     l3.h
Success                     INGRESS     264202    27965348    235    trace.h
Unsupported L3 protocol     EGRESS      69        5194        1492   bpf_lxc.c
