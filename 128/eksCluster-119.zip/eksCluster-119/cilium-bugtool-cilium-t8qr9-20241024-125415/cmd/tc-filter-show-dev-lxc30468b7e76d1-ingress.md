filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc30468b7e76d1 direct-action not_in_hw id 3313 tag f1119a0e0285bcc7 jited 
