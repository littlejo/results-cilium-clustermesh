xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 502
ens6(5) clsact/ingress cil_from_netdev-ens6 id 513
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 495
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 494
cilium_host(7) clsact/egress cil_from_host-cilium_host id 491
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 552
lxc78d223e70aef(12) clsact/ingress cil_from_container-lxc78d223e70aef id 532
lxca7654b30f51b(14) clsact/ingress cil_from_container-lxca7654b30f51b id 542
lxc6811ff3cf772(18) clsact/ingress cil_from_container-lxc6811ff3cf772 id 620
lxced7b7df991c7(20) clsact/ingress cil_from_container-lxced7b7df991c7 id 3249
lxc30468b7e76d1(22) clsact/ingress cil_from_container-lxc30468b7e76d1 id 3313
lxc534009a5a3d5(24) clsact/ingress cil_from_container-lxc534009a5a3d5 id 3304

flow_dissector:

netfilter:

