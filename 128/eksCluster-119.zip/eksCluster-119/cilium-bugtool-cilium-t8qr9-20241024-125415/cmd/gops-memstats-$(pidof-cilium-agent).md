alloc: 83.26MB (87304392 bytes)
total-alloc: 3.21GB (3444585824 bytes)
sys: 227.64MB (238699860 bytes)
lookups: 0
mallocs: 76980613
frees: 76477055
heap-alloc: 83.26MB (87304392 bytes)
heap-sys: 181.04MB (189833216 bytes)
heap-idle: 38.67MB (40550400 bytes)
heap-in-use: 142.37MB (149282816 bytes)
heap-released: 3.14MB (3293184 bytes)
heap-objects: 503558
stack-in-use: 34.75MB (36438016 bytes)
stack-sys: 34.75MB (36438016 bytes)
stack-mspan-inuse: 2.31MB (2420960 bytes)
stack-mspan-sys: 2.93MB (3068160 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.14MB (1197353 bytes)
gc-sys: 5.68MB (5952560 bytes)
next-gc: when heap-alloc >= 170.31MB (178583912 bytes)
last-gc: 2024-10-24 12:54:46.557651751 +0000 UTC
gc-pause-total: 9.996701ms
gc-pause: 75381
gc-pause-end: 1729774486557651751
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0007871580369163251
enable-gc: true
debug-gc: false
