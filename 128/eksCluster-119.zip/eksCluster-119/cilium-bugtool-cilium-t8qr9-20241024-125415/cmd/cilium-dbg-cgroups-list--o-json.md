[
  {
    "containers": [
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode9ed67ea_db42_44ad_8c17_155ddb8401d6.slice/cri-containerd-97902501b9006595feab6dbe15708e23f51bb671476583cdd6028a12c785685b.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode9ed67ea_db42_44ad_8c17_155ddb8401d6.slice/cri-containerd-fdbd0ed7f23977a599627c8fbbbbb49638c63af19ea9bab223080270fd57c252.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode9ed67ea_db42_44ad_8c17_155ddb8401d6.slice/cri-containerd-ee1384b8dae128208f4dda563d3c76ec617d4573f088f53cc48350619db68bcb.scope"
      }
    ],
    "ips": [
      "10.119.0.234"
    ],
    "name": "clustermesh-apiserver-85794b76b5-5scnx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45fd6558_f633_4269_9d7e_f12d1266219c.slice/cri-containerd-bcc73962da1ec5a32977bd75e5585a8813add1dfea1b47c8cc0af8e839f9062e.scope"
      }
    ],
    "ips": [
      "10.119.0.66"
    ],
    "name": "coredns-cc6ccd49c-k48nz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40c7a6d5_a6a7_42dc_8f1f_1afe6b93e11b.slice/cri-containerd-e4138c9895723414db092dc3b06a491d5402aba6ab8ceb8e450347775f9d4001.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40c7a6d5_a6a7_42dc_8f1f_1afe6b93e11b.slice/cri-containerd-4f0aef812b4a7ea569881de9f453031b77476ab7e13dfdca4e1e9a26d9336a9a.scope"
      }
    ],
    "ips": [
      "10.119.0.60"
    ],
    "name": "echo-same-node-86d9cc975c-db4zt",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod991c49a3_8625_491d_af37_884a19d6ac41.slice/cri-containerd-c7018fec46221f1f51314fabe017fa10a5fdc1139e321de382c0c832bcc6afa4.scope"
      }
    ],
    "ips": [
      "10.119.0.49"
    ],
    "name": "coredns-cc6ccd49c-tzjkh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9894d9b6_4e65_45eb_991b_5097d50d8c9e.slice/cri-containerd-2e2929ca1b1ff6a10336f1cbdedd478908e467b4c3a1a6f83fef8067a08f5332.scope"
      }
    ],
    "ips": [
      "10.119.0.18"
    ],
    "name": "client2-57cf4468f-6zc4d",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda30ac357_ea78_4e7e_bf9d_f6ff4eefcc1c.slice/cri-containerd-40dbe2af3cd1f44784cc5683adb3fca3f54b4608f846a5ac9935d4be9ca08b8a.scope"
      }
    ],
    "ips": [
      "10.119.0.40"
    ],
    "name": "client-974f6c69d-t8khh",
    "namespace": "cilium-test-1"
  }
]

