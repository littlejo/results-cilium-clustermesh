1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:5b:14:34:8f:ef brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.233.58/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3560sec preferred_lft 3560sec
    inet6 fe80::85b:14ff:fe34:8fef/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:87:20:99:d5:bd brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.228.77/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::887:20ff:fe99:d5bd/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:92:44:2c:86:ed brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f092:44ff:fe2c:86ed/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:d6:3c:a7:30:01 brd ff:ff:ff:ff:ff:ff
    inet 10.119.0.204/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::acd6:3cff:fea7:3001/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether fe:9f:14:d9:e9:8b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::fc9f:14ff:fed9:e98b/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:3a:f6:f2:7f:8a brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c03a:f6ff:fef2:7f8a/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc78d223e70aef@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:7d:44:4c:8b:a0 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::187d:44ff:fe4c:8ba0/64 scope link 
       valid_lft forever preferred_lft forever
14: lxca7654b30f51b@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:7b:d3:91:76:7d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a47b:d3ff:fe91:767d/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc6811ff3cf772@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:3d:9f:bf:18:5a brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e03d:9fff:febf:185a/64 scope link 
       valid_lft forever preferred_lft forever
20: lxced7b7df991c7@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:f2:e6:33:e7:6e brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::20f2:e6ff:fe33:e76e/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc30468b7e76d1@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:fa:1e:20:b2:4c brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::a8fa:1eff:fe20:b24c/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc534009a5a3d5@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:f8:94:36:c8:b0 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::44f8:94ff:fe36:c8b0/64 scope link 
       valid_lft forever preferred_lft forever
