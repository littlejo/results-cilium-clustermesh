{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.919Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.938Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.992Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.029Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.031Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.233Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.236Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.290Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.314Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.348Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.829Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.830Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.890Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.898Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.935Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.950Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.970Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.179Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.189Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.250Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.263Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.301Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.814Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.822Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.856Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.889Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.918Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.987Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.000Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.236Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.240Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.288Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.328Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.356Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.911Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.915Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.957Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.962Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.021Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.025Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.062Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.300Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.317Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.373Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.386Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.429Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.799Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.857Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.876Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.919Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.942Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.966Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.227Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.295Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.305Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.318Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.353Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.703Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.733Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.749Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.791Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.793Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.825Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.057Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.063Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.115Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.130Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.164Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.567Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.594Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.621Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.648Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.666Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.925Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.929Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.980Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.985Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.028Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.486Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.496Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.538Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.554Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.577Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.795Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.826Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.856Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.873Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.908Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.308Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.342Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.355Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.401Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.403Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.436Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.680Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.691Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.737Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.744Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.788Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.066Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.094Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.122Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.146Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.167Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.186Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.434Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.442Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.502Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.504Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.547Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.807Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.838Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.857Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.898Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.903Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.170Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.179Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.187Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.228Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.902Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.907Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.996Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.997Z",
  "value": "id=1565  sec_id=7910529 flags=0x0000 ifindex=20  mac=2E:D7:56:E7:B3:6F nodemac=22:F2:E6:33:E7:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.056Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.289Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.309Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.930Z",
  "value": "id=241   sec_id=7889830 flags=0x0000 ifindex=22  mac=56:F1:39:FC:2C:F8 nodemac=AA:FA:1E:20:B2:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.936Z",
  "value": "id=2357  sec_id=7884696 flags=0x0000 ifindex=24  mac=EA:F2:8F:72:5B:2B nodemac=46:F8:94:36:C8:B0"
}

