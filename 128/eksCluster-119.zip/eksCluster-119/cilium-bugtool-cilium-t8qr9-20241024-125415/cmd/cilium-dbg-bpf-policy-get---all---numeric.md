Endpoint ID: 241
Path: /sys/fs/bpf/tc/globals/cilium_policy_00241

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 559
Path: /sys/fs/bpf/tc/globals/cilium_policy_00559

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3048     31        0        
Allow    Ingress     1          ANY          NONE         disabled    119938   1374      0        
Allow    Egress      0          ANY          NONE         disabled    17137    187       0        


Endpoint ID: 970
Path: /sys/fs/bpf/tc/globals/cilium_policy_00970

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6075961   61486     0        
Allow    Ingress     1          ANY          NONE         disabled    6116314   63220     0        
Allow    Egress      0          ANY          NONE         disabled    7355352   72101     0        


Endpoint ID: 1393
Path: /sys/fs/bpf/tc/globals/cilium_policy_01393

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2848     29        0        
Allow    Ingress     1          ANY          NONE         disabled    120202   1378      0        
Allow    Egress      0          ANY          NONE         disabled    17491    192       0        


Endpoint ID: 1565
Path: /sys/fs/bpf/tc/globals/cilium_policy_01565

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377602   4408      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1969
Path: /sys/fs/bpf/tc/globals/cilium_policy_01969

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6247607   77110     0        
Allow    Ingress     1          ANY          NONE         disabled    62775     758       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2357
Path: /sys/fs/bpf/tc/globals/cilium_policy_02357

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3353
Path: /sys/fs/bpf/tc/globals/cilium_policy_03353

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


