xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 579
ens6(5) clsact/ingress cil_from_netdev-ens6 id 584
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 568
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 563
cilium_host(7) clsact/egress cil_from_host-cilium_host id 560
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 524
lxc4cfb8c5020a9(12) clsact/ingress cil_from_container-lxc4cfb8c5020a9 id 546
lxc4e6cc5796427(14) clsact/ingress cil_from_container-lxc4e6cc5796427 id 519
lxc15ad1b741377(18) clsact/ingress cil_from_container-lxc15ad1b741377 id 626
lxc5daa16654fb6(20) clsact/ingress cil_from_container-lxc5daa16654fb6 id 3349
lxc85a81b084335(22) clsact/ingress cil_from_container-lxc85a81b084335 id 3347
lxc7f8aa4124996(24) clsact/ingress cil_from_container-lxc7f8aa4124996 id 3289

flow_dissector:

netfilter:

