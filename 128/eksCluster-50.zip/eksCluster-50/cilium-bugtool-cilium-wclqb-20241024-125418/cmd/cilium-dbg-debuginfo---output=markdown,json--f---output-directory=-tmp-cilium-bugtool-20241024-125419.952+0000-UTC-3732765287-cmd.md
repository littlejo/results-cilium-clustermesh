markdown output at /tmp/cilium-bugtool-20241024-125419.952+0000-UTC-3732765287/cmd/cilium-debuginfo-20241024-125450.693+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125419.952+0000-UTC-3732765287/cmd/cilium-debuginfo-20241024-125450.693+0000-UTC.json
