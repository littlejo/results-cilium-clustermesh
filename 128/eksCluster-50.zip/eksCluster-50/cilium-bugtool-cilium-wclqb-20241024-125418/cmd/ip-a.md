1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:41:74:6e:51:fd brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.162.244/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3451sec preferred_lft 3451sec
    inet6 fe80::441:74ff:fe6e:51fd/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:2e:d8:4b:57:89 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.166.253/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::42e:d8ff:fe4b:5789/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:fb:6c:17:6b:5a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::58fb:6cff:fe17:6b5a/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:92:65:24:60:8c brd ff:ff:ff:ff:ff:ff
    inet 10.50.0.234/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a892:65ff:fe24:608c/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 8a:3c:2f:ed:a8:9b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::883c:2fff:feed:a89b/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:0e:41:dc:71:e8 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c80e:41ff:fedc:71e8/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc4cfb8c5020a9@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:02:ee:b6:8b:90 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d002:eeff:feb6:8b90/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc4e6cc5796427@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:05:4c:09:24:d9 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::7405:4cff:fe09:24d9/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc15ad1b741377@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:f0:a6:48:a6:50 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::80f0:a6ff:fe48:a650/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc5daa16654fb6@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:f4:e3:99:e2:b8 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::38f4:e3ff:fe99:e2b8/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc85a81b084335@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:4d:aa:01:2e:70 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::bc4d:aaff:fe01:2e70/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc7f8aa4124996@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:cf:f4:d2:27:c6 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::94cf:f4ff:fed2:27c6/64 scope link 
       valid_lft forever preferred_lft forever
