filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc7f8aa4124996 direct-action not_in_hw id 3289 tag 2ccf0a16570bb1af jited 
