REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     135438    10980867    677    bpf_overlay.c
Interface                   INGRESS     666947    246564491   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      136608    11075835    53     encap.h
Success                     EGRESS      142354    19247747    1308   bpf_lxc.c
Success                     EGRESS      59122     4797807     1694   bpf_host.c
Success                     EGRESS      596       156299      86     l3.h
Success                     INGRESS     165225    18798819    86     l3.h
Success                     INGRESS     242768    25180648    235    trace.h
Unsupported L3 protocol     EGRESS      73        5510        1492   bpf_lxc.c
