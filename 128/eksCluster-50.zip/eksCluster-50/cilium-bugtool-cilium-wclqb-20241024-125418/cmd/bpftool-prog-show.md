35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:43+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:21:43+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:21:44+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:21:44+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:44+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:44+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:21:44+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:44+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:21:49+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:21:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:21:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:04+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:28:06+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
485: sched_cls  name tail_handle_ipv4  tag 997c86b89ae8d6d1  gpl
	loaded_at 2024-10-24T12:28:06+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
486: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:28:06+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
487: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:28:06+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
510: sched_cls  name tail_handle_arp  tag 7aca014d3be1ba41  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 153
511: sched_cls  name tail_ipv4_ct_ingress  tag 5e292004289ddc9d  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 154
512: sched_cls  name handle_policy  tag a96f0a7198ffd5fc  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 155
513: sched_cls  name __send_drop_notify  tag a3592248c3fbc84d  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 156
514: sched_cls  name tail_handle_ipv4  tag b4ee1aaac8aa6765  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 157
515: sched_cls  name tail_ipv4_to_endpoint  tag ac7b613bc24a8993  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 158
516: sched_cls  name tail_ipv4_ct_egress  tag 15a0440dea9697eb  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 159
517: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 160
518: sched_cls  name tail_handle_ipv4_cont  tag 64cfcbec7785b000  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 161
519: sched_cls  name cil_from_container  tag d9fe9433c01ecdfd  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,76
	btf_id 162
521: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 165
522: sched_cls  name tail_handle_ipv4_cont  tag 6fbf334b31c79ecc  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,110,41,100,82,83,39,76,74,77,109,40,37,38,81
	btf_id 166
523: sched_cls  name tail_handle_arp  tag d270c2cb900dab94  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 167
524: sched_cls  name cil_from_container  tag 1122a5a2e22def61  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 109,76
	btf_id 168
525: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
528: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
529: sched_cls  name tail_ipv4_to_endpoint  tag eca5ebc8aaa6055d  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,110,41,82,83,80,100,39,109,40,37,38
	btf_id 169
530: sched_cls  name __send_drop_notify  tag 1ae942254fd7c3f3  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 170
531: sched_cls  name tail_handle_ipv4  tag 518428c9eb9010f4  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 171
533: sched_cls  name tail_ipv4_ct_ingress  tag 23bf973bd52524d1  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 173
534: sched_cls  name handle_policy  tag 6a2d7e4f5df39be6  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,109,82,83,110,41,80,100,39,84,75,40,37,38
	btf_id 174
535: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 175
536: sched_cls  name tail_ipv4_ct_egress  tag 15a0440dea9697eb  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 177
537: sched_cls  name handle_policy  tag b51dd7ca535a8a0d  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,101,39,84,75,40,37,38
	btf_id 178
538: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 179
539: sched_cls  name tail_ipv4_to_endpoint  tag fc8af8ec118b9190  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,101,39,112,40,37,38
	btf_id 180
540: sched_cls  name __send_drop_notify  tag cbd3726c73ac9497  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 181
541: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
544: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
545: sched_cls  name tail_ipv4_ct_ingress  tag 806a13aacf3550f4  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 182
546: sched_cls  name cil_from_container  tag bed8d92680be5e83  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 183
548: sched_cls  name tail_handle_ipv4  tag 6ea8b7f2fe5ab418  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 185
549: sched_cls  name tail_handle_ipv4_cont  tag f9958c6656ca7510  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,101,82,83,39,76,74,77,112,40,37,38,81
	btf_id 186
550: sched_cls  name tail_handle_arp  tag da8621ee27e8cad1  gpl
	loaded_at 2024-10-24T12:28:08+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 187
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
560: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 190
561: sched_cls  name tail_handle_ipv4_from_host  tag 46bd8bbc87d24bd6  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 191
563: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 193
564: sched_cls  name __send_drop_notify  tag 9409c4c4e2844c6e  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 194
565: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 195
566: sched_cls  name tail_handle_ipv4_from_host  tag 46bd8bbc87d24bd6  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 197
568: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 199
569: sched_cls  name __send_drop_notify  tag 9409c4c4e2844c6e  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 200
570: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 201
574: sched_cls  name tail_handle_ipv4_from_host  tag 46bd8bbc87d24bd6  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 206
577: sched_cls  name __send_drop_notify  tag 9409c4c4e2844c6e  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 209
578: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 210
579: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 211
582: sched_cls  name __send_drop_notify  tag 9409c4c4e2844c6e  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 215
583: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 216
584: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 217
586: sched_cls  name tail_handle_ipv4_from_host  tag 46bd8bbc87d24bd6  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 219
626: sched_cls  name cil_from_container  tag bcaf9ce58eff25c1  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 137,76
	btf_id 233
627: sched_cls  name tail_handle_ipv4  tag 0254a3033da2eb11  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,137
	btf_id 234
628: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,137
	btf_id 235
629: sched_cls  name handle_policy  tag d53b310c7b5f6506  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,137,82,83,136,41,80,135,39,84,75,40,37,38
	btf_id 236
630: sched_cls  name tail_handle_ipv4_cont  tag b41bd67a20f5ae10  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,136,41,135,82,83,39,76,74,77,137,40,37,38,81
	btf_id 237
631: sched_cls  name __send_drop_notify  tag d3231817fa300d2a  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 238
633: sched_cls  name tail_handle_arp  tag 3edb53cd460f59e7  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,137
	btf_id 240
634: sched_cls  name tail_ipv4_ct_ingress  tag bd0f5471ed2a61cd  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 241
635: sched_cls  name tail_ipv4_to_endpoint  tag ede1b30d921729a6  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,136,41,82,83,80,135,39,137,40,37,38
	btf_id 242
636: sched_cls  name tail_ipv4_ct_egress  tag 5c53d81fc8b11c73  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 243
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
676: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
679: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
702: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
705: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
706: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
709: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
710: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
713: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
714: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
717: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
718: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
721: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
722: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
725: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3289: sched_cls  name cil_from_container  tag 2ccf0a16570bb1af  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 628,76
	btf_id 3077
3290: sched_cls  name tail_ipv4_ct_ingress  tag e067fae70ed5407c  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,628,82,83,627,84
	btf_id 3078
3291: sched_cls  name tail_handle_arp  tag f432b1813e7a4932  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,628
	btf_id 3079
3292: sched_cls  name handle_policy  tag ecbe9034b22ef90c  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,628,82,83,627,41,80,152,39,84,75,40,37,38
	btf_id 3080
3294: sched_cls  name tail_handle_ipv4  tag 2fff44881cc5f19f  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,628
	btf_id 3083
3296: sched_cls  name tail_handle_ipv4_cont  tag ea2a0a089f4bdcf4  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,627,41,152,82,83,39,76,74,77,628,40,37,38,81
	btf_id 3086
3298: sched_cls  name tail_ipv4_to_endpoint  tag 8361f68719a2d964  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,627,41,82,83,80,152,39,628,40,37,38
	btf_id 3087
3299: sched_cls  name __send_drop_notify  tag 69332ab2556afa0f  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3089
3300: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,628
	btf_id 3090
3301: sched_cls  name tail_ipv4_ct_egress  tag 8886ea5695697068  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,628,82,83,627,84
	btf_id 3091
3345: sched_cls  name tail_handle_ipv4  tag 6ef71bd879d55dae  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,637
	btf_id 3139
3346: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,637
	btf_id 3141
3347: sched_cls  name cil_from_container  tag bb3a90f1d8e473fc  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 637,76
	btf_id 3142
3348: sched_cls  name handle_policy  tag b8c30b93755eff04  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,640,82,83,639,41,80,145,39,84,75,40,37,38
	btf_id 3140
3349: sched_cls  name cil_from_container  tag 96f6469e161161a9  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 640,76
	btf_id 3144
3350: sched_cls  name __send_drop_notify  tag c531449f371cf412  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3145
3351: sched_cls  name tail_ipv4_to_endpoint  tag ee6d5c96e6a865c8  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,638,41,82,83,80,149,39,637,40,37,38
	btf_id 3143
3352: sched_cls  name tail_ipv4_ct_ingress  tag 300ce9da1eb58e82  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3147
3353: sched_cls  name tail_ipv4_ct_ingress  tag 17868210f53d1150  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3146
3355: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,640
	btf_id 3150
3356: sched_cls  name tail_ipv4_ct_egress  tag da50087d349d4ef2  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3151
3357: sched_cls  name tail_handle_ipv4  tag 2a6b1b7311d7710b  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,640
	btf_id 3152
3358: sched_cls  name handle_policy  tag 87a002555bcb01ec  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,637,82,83,638,41,80,149,39,84,75,40,37,38
	btf_id 3149
3359: sched_cls  name tail_handle_ipv4_cont  tag 662dbf521d98969e  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,639,41,145,82,83,39,76,74,77,640,40,37,38,81
	btf_id 3153
3360: sched_cls  name tail_handle_ipv4_cont  tag e736ff018562b6e5  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,638,41,149,82,83,39,76,74,77,637,40,37,38,81
	btf_id 3154
3361: sched_cls  name __send_drop_notify  tag 02a45017060ada37  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3156
3362: sched_cls  name tail_handle_arp  tag 5b9f6fa2928f3ec3  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,637
	btf_id 3157
3363: sched_cls  name tail_ipv4_ct_egress  tag 1f07184ec0ddd739  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3158
3364: sched_cls  name tail_ipv4_to_endpoint  tag 5ac511b7bd09f40c  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,639,41,82,83,80,145,39,640,40,37,38
	btf_id 3155
3365: sched_cls  name tail_handle_arp  tag f9698726f26ae332  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,640
	btf_id 3159
