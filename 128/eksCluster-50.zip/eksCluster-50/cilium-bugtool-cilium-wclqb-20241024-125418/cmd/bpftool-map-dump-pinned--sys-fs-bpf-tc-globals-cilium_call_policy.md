key: a4 00 00 00  value: 00 02 00 00
key: 44 05 00 00  value: 14 0d 00 00
key: cb 05 00 00  value: dc 0c 00 00
key: 92 09 00 00  value: 1e 0d 00 00
key: 06 0a 00 00  value: 16 02 00 00
key: 92 0a 00 00  value: 75 02 00 00
key: 42 0c 00 00  value: 19 02 00 00
Found 7 elements
