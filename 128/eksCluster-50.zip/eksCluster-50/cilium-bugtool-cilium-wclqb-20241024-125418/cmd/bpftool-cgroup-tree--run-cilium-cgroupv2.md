CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ee4df12_3266_497c_bf81_453f3610999c.slice/cri-containerd-1896c91a0b041f27fd5b830f7a8c2536c13419c27f24619f250b2fb4ee703ccb.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ee4df12_3266_497c_bf81_453f3610999c.slice/cri-containerd-4eb8029a4c48709ed16708a3ad78ba73eb014b4e454205a94c44b3800d1bfc79.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfaa335e7_c0aa_4195_8d8e_408e9fd5cde7.slice/cri-containerd-293c41f0a9b9f91860211c80ed593ec07a346f9a058e52388e5b9f8eadbdb3fa.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfaa335e7_c0aa_4195_8d8e_408e9fd5cde7.slice/cri-containerd-c1f0203c7834a50c6fbc3240ed6835337c86d712516ea18d5eff8f59271af0c9.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod11d9d349_16d5_4bc5_8c6b_c105c67812cf.slice/cri-containerd-36861898cc9b46c37b69a4dd206c8c79a7cd67743e2163be0b1c83ecbb262cfc.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod11d9d349_16d5_4bc5_8c6b_c105c67812cf.slice/cri-containerd-06542e96f1b8b06e0f375bc02b6517e98c4147e0083e97001964e4a3a3a12ff8.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c2ecfdc_66d5_47be_8dc5_9b15cfb9877a.slice/cri-containerd-cb589d6a9be0f1daaf8aee0e8bb9d697ca115d232bc9511d7f679181a6f1b8ad.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c2ecfdc_66d5_47be_8dc5_9b15cfb9877a.slice/cri-containerd-0559e7d59b734bf7cfe7e5bc4770c1a743893c7f1ff5219aa2c25074d4f952df.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod48da2422_c4b7_4d43_8203_c82ecfa561cc.slice/cri-containerd-5144b1ddc17c56baa03084413773eb64bda6bfa07e70d2302bcae4fb6343d030.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod48da2422_c4b7_4d43_8203_c82ecfa561cc.slice/cri-containerd-e2f8024427ec23452d35e12fb9ddf30afbf2046b4b4dc05822fbad2ee796b81e.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod48da2422_c4b7_4d43_8203_c82ecfa561cc.slice/cri-containerd-a20d1f271ec3776df317397795dd49bcdd8bb197924fdf1704f9c4c5472bb8d6.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod48da2422_c4b7_4d43_8203_c82ecfa561cc.slice/cri-containerd-82eede54a1ec225bf71498ba556d9125e13c716e128db7d75dd2ee49ec1e867d.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda108ef61_0c64_4f8e_aa8e_f472bd741836.slice/cri-containerd-7d0b08c203669e400f548ef47f555de5f6d5829702cc618902f89ac861569dd1.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda108ef61_0c64_4f8e_aa8e_f472bd741836.slice/cri-containerd-88ea078e57dc75bd926fc62f8665a1ff53b26da7c9a998c5382fc6c2748f2917.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e4e6558_900b_40b3_91c3_3d5b5cb11c63.slice/cri-containerd-ecc6fff9177f751171370b2e7d1727cb93662d6305d9de931cd86acfff264161.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e4e6558_900b_40b3_91c3_3d5b5cb11c63.slice/cri-containerd-2f98692d9b20bab7ebc0999a9bacc1379d03be09cad54e439b9afb44b97a9140.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ff76c69_867f_40d6_8517_ae4fc4c1fd97.slice/cri-containerd-3bb910967371e826fd37af284a0d6dba8dac9a6e87e4895807e5ea306bfce649.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ff76c69_867f_40d6_8517_ae4fc4c1fd97.slice/cri-containerd-8e4fd08e3813ce514431cb760e44f10aa3c3c9f6a1e2aa648f62065248b077c6.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ff76c69_867f_40d6_8517_ae4fc4c1fd97.slice/cri-containerd-471e0ebad548c94cebc523eeab216ac90230aa4273ca94b8278085b787337846.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod735212a2_8a5e_4ece_96f3_6725d5d7c569.slice/cri-containerd-836e2b881bae1075c549d63eba21515e2d896a3d4f1277eb475022b98fb15a97.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod735212a2_8a5e_4ece_96f3_6725d5d7c569.slice/cri-containerd-de63018025d2ad60bd8951b96f099af454d5b76ea5a55401ce9eb32c0c761b5e.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf3fffefb_b160_43a8_98a7_5e68335cfb38.slice/cri-containerd-cc5c4b4aef44f08a9e1b8a2fd53313692a3e91d694134621a15bcdd98641d735.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf3fffefb_b160_43a8_98a7_5e68335cfb38.slice/cri-containerd-9de2ec08033cab6409253f977c5d054218d7badd7d7324af525c27fd32a98042.scope
    679      cgroup_device   multi                                          
