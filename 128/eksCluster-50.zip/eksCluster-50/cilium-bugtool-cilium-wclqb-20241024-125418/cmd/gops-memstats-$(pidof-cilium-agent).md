alloc: 94.28MB (98857080 bytes)
total-alloc: 3.11GB (3338390672 bytes)
sys: 223.07MB (233907540 bytes)
lookups: 0
mallocs: 75381669
frees: 74542917
heap-alloc: 94.28MB (98857080 bytes)
heap-sys: 176.58MB (185155584 bytes)
heap-idle: 47.89MB (50216960 bytes)
heap-in-use: 128.69MB (134938624 bytes)
heap-released: 10.07MB (10559488 bytes)
heap-objects: 838752
stack-in-use: 35.38MB (37093376 bytes)
stack-sys: 35.38MB (37093376 bytes)
stack-mspan-inuse: 2.10MB (2202880 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 736.52KB (754193 bytes)
gc-sys: 5.52MB (5788744 bytes)
next-gc: when heap-alloc >= 149.92MB (157199320 bytes)
last-gc: 2024-10-24 12:54:29.592431545 +0000 UTC
gc-pause-total: 14.69583ms
gc-pause: 69852
gc-pause-end: 1729774469592431545
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0005178075950535016
enable-gc: true
debug-gc: false
