{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.740Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.777Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.779Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.811Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.009Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.017Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.074Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.079Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.128Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.648Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.656Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.684Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.715Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.730Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.755Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.769Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.019Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.030Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.079Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.089Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.128Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.768Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.795Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.844Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.852Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.877Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.021Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.033Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.075Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.095Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.129Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.692Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.697Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.739Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.741Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.779Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.800Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.818Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.055Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.065Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.113Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.113Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.160Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.556Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.610Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.620Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.661Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.664Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.694Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.951Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.007Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.065Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.125Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.130Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.442Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.479Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.482Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.533Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.535Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.582Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.820Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.839Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.895Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.906Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.932Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.378Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.386Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.435Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.436Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.471Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.690Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.692Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.734Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.755Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.768Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.774Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.214Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.279Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.287Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.327Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.343Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.365Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.596Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.599Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.648Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.680Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.699Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.122Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.155Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.165Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.206Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.208Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.239Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.460Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.477Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.507Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.561Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.579Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.851Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.902Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.905Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.946Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.954Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.983Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.201Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.205Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.256Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.278Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.325Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.640Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.681Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.690Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.717Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.733Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.969Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.973Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.001Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.007Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.024Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.706Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.709Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.744Z",
  "value": "id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.772Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.785Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.052Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.053Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.741Z",
  "value": "id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.750Z",
  "value": "id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8"
}

