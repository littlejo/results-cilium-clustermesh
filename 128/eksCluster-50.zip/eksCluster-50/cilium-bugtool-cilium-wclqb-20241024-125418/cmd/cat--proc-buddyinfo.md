Node 0, zone      DMA    308    132     25     30     18     13      9      5      3      2     45 
Node 0, zone   Normal      6      1      1      2      0      3      2      2      2      3      8 
