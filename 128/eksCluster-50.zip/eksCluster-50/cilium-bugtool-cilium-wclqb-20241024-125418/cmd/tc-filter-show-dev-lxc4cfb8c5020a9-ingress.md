filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc4cfb8c5020a9 direct-action not_in_hw id 546 tag bed8d92680be5e83 jited 
