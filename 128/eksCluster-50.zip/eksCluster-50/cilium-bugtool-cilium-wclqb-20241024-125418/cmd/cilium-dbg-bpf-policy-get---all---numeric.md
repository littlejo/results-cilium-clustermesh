Endpoint ID: 164
Path: /sys/fs/bpf/tc/globals/cilium_policy_00164

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1704     19        0        
Allow    Ingress     1          ANY          NONE         disabled    151255   1731      0        
Allow    Egress      0          ANY          NONE         disabled    19752    219       0        


Endpoint ID: 1348
Path: /sys/fs/bpf/tc/globals/cilium_policy_01348

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1483
Path: /sys/fs/bpf/tc/globals/cilium_policy_01483

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379823   4426      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2101
Path: /sys/fs/bpf/tc/globals/cilium_policy_02101

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2450
Path: /sys/fs/bpf/tc/globals/cilium_policy_02450

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2566
Path: /sys/fs/bpf/tc/globals/cilium_policy_02566

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6228140   76981     0        
Allow    Ingress     1          ANY          NONE         disabled    67036     807       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2706
Path: /sys/fs/bpf/tc/globals/cilium_policy_02706

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6057191   59753     0        
Allow    Ingress     1          ANY          NONE         disabled    4902948   51447     0        
Allow    Egress      0          ANY          NONE         disabled    5721104   57674     0        


Endpoint ID: 3138
Path: /sys/fs/bpf/tc/globals/cilium_policy_03138

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4192     41        0        
Allow    Ingress     1          ANY          NONE         disabled    150082   1718      0        
Allow    Egress      0          ANY          NONE         disabled    20062    222       0        


