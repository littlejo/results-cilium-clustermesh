IP ADDRESS         LOCAL ENDPOINT INFO
10.50.0.95:0       id=3138  sec_id=3350625 flags=0x0000 ifindex=12  mac=16:7C:84:AD:B8:D1 nodemac=D2:02:EE:B6:8B:90   
10.50.0.234:0      (localhost)                                                                                        
10.50.0.129:0      id=2450  sec_id=3359695 flags=0x0000 ifindex=22  mac=8E:D6:EA:59:5D:23 nodemac=BE:4D:AA:01:2E:70   
10.50.0.113:0      id=1483  sec_id=3380492 flags=0x0000 ifindex=24  mac=FE:F9:35:03:EB:48 nodemac=96:CF:F4:D2:27:C6   
10.50.0.93:0       id=1348  sec_id=3346369 flags=0x0000 ifindex=20  mac=BE:81:11:E1:67:E7 nodemac=3A:F4:E3:99:E2:B8   
10.50.0.200:0      id=2706  sec_id=3342636 flags=0x0000 ifindex=18  mac=0A:B4:F3:49:44:3E nodemac=82:F0:A6:48:A6:50   
172.31.162.244:0   (localhost)                                                                                        
10.50.0.237:0      id=2566  sec_id=4     flags=0x0000 ifindex=10  mac=06:D9:04:45:4B:93 nodemac=CA:0E:41:DC:71:E8     
172.31.166.253:0   (localhost)                                                                                        
10.50.0.143:0      id=164   sec_id=3350625 flags=0x0000 ifindex=14  mac=9E:22:A2:26:64:26 nodemac=76:05:4C:09:24:D9   
