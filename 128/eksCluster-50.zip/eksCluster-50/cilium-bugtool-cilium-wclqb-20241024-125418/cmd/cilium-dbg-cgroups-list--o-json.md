[
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c2ecfdc_66d5_47be_8dc5_9b15cfb9877a.slice/cri-containerd-0559e7d59b734bf7cfe7e5bc4770c1a743893c7f1ff5219aa2c25074d4f952df.scope"
      }
    ],
    "ips": [
      "10.50.0.143"
    ],
    "name": "coredns-cc6ccd49c-hxv69",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ff76c69_867f_40d6_8517_ae4fc4c1fd97.slice/cri-containerd-471e0ebad548c94cebc523eeab216ac90230aa4273ca94b8278085b787337846.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ff76c69_867f_40d6_8517_ae4fc4c1fd97.slice/cri-containerd-3bb910967371e826fd37af284a0d6dba8dac9a6e87e4895807e5ea306bfce649.scope"
      }
    ],
    "ips": [
      "10.50.0.113"
    ],
    "name": "echo-same-node-86d9cc975c-8mjkj",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod48da2422_c4b7_4d43_8203_c82ecfa561cc.slice/cri-containerd-a20d1f271ec3776df317397795dd49bcdd8bb197924fdf1704f9c4c5472bb8d6.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod48da2422_c4b7_4d43_8203_c82ecfa561cc.slice/cri-containerd-82eede54a1ec225bf71498ba556d9125e13c716e128db7d75dd2ee49ec1e867d.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod48da2422_c4b7_4d43_8203_c82ecfa561cc.slice/cri-containerd-e2f8024427ec23452d35e12fb9ddf30afbf2046b4b4dc05822fbad2ee796b81e.scope"
      }
    ],
    "ips": [
      "10.50.0.200"
    ],
    "name": "clustermesh-apiserver-6fdb8c49db-n7r22",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod11d9d349_16d5_4bc5_8c6b_c105c67812cf.slice/cri-containerd-36861898cc9b46c37b69a4dd206c8c79a7cd67743e2163be0b1c83ecbb262cfc.scope"
      }
    ],
    "ips": [
      "10.50.0.95"
    ],
    "name": "coredns-cc6ccd49c-2jbf4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf3fffefb_b160_43a8_98a7_5e68335cfb38.slice/cri-containerd-cc5c4b4aef44f08a9e1b8a2fd53313692a3e91d694134621a15bcdd98641d735.scope"
      }
    ],
    "ips": [
      "10.50.0.93"
    ],
    "name": "client-974f6c69d-rn6x9",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda108ef61_0c64_4f8e_aa8e_f472bd741836.slice/cri-containerd-7d0b08c203669e400f548ef47f555de5f6d5829702cc618902f89ac861569dd1.scope"
      }
    ],
    "ips": [
      "10.50.0.129"
    ],
    "name": "client2-57cf4468f-65lzm",
    "namespace": "cilium-test-1"
  }
]

