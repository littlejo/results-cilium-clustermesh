key: 06 00 00 00  value: 0a 41 00 53 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f c9 fa 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 41 00 d3 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 41 00 d3 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 41 00 53 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f e3 9c 10 94 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f 87 d3 01 bb 00 00  00 00 00 00
key: 0c 00 00 00  value: 0a 41 00 c5 1f 90 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 41 00 15 09 4b 00 00  00 00 00 00
Found 9 elements
