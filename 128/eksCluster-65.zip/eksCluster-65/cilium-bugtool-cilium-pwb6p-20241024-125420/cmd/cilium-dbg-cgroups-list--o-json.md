[
  {
    "containers": [
      {
        "cgroup-id": 7704,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c56293b_6df9_48bd_a3ce_21b97a949177.slice/cri-containerd-894136781728521451a8a91bf9d6f1a5ec3367acdbdea2716187ef40746f0ae2.scope"
      }
    ],
    "ips": [
      "10.65.0.83"
    ],
    "name": "coredns-cc6ccd49c-rhfzw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7620,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9d14462e_c3d8_4d8c_bec6_a923fb273eab.slice/cri-containerd-f39af19e878a5b2569523fca643c1eba20c751358fad550a7a47eabbcebc17bd.scope"
      }
    ],
    "ips": [
      "10.65.0.211"
    ],
    "name": "coredns-cc6ccd49c-76rjq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf98f14ae_4928_4451_a6b7_5b974f0a0293.slice/cri-containerd-7bc9bc6bee818bd0142870b84e6b6d511f93074326a80861c3e11dd20a3a0740.scope"
      }
    ],
    "ips": [
      "10.65.0.62"
    ],
    "name": "client-974f6c69d-87hxs",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda8cb8efd_faf7_4431_a20d_6053dde68928.slice/cri-containerd-154f116db6c0591a53d9fc34af72536ce4dbbb3cb0c418eaf8e869c734442731.scope"
      }
    ],
    "ips": [
      "10.65.0.190"
    ],
    "name": "client2-57cf4468f-r88lf",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9180,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bc7965_1fd7_47ba_bb70_df7f25c57293.slice/cri-containerd-74dc66822abfacc5cb1202c5efbcabf2116d2e1d1bcacc411f7831723e16c075.scope"
      },
      {
        "cgroup-id": 9096,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bc7965_1fd7_47ba_bb70_df7f25c57293.slice/cri-containerd-f0912f40b031e6543b989753c0bb427a48ee23442f604e39f269a964a7017d50.scope"
      },
      {
        "cgroup-id": 9264,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bc7965_1fd7_47ba_bb70_df7f25c57293.slice/cri-containerd-2b4c1abbd3cc800288d32db4a4104d334a2abbbbe76fe2c8ce6a8034e60c2310.scope"
      }
    ],
    "ips": [
      "10.65.0.21"
    ],
    "name": "clustermesh-apiserver-56c6cd494-q4js8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33d8bdbf_a1b4_48df_bcb3_00d9f8f61268.slice/cri-containerd-1a9bfe975202267a2dbdf9959ac7158a864588c788b231615f7f05d8d3f723f3.scope"
      },
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33d8bdbf_a1b4_48df_bcb3_00d9f8f61268.slice/cri-containerd-220e7d6a495d92fd0e7c645f591a0d92074a83353eaa7ca6be18b5c68fe1a0b1.scope"
      }
    ],
    "ips": [
      "10.65.0.197"
    ],
    "name": "echo-same-node-86d9cc975c-97c8m",
    "namespace": "cilium-test-1"
  }
]

