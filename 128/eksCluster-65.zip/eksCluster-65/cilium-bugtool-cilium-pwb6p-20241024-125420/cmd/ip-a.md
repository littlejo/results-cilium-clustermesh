1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:90:45:59:23:dd brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.227.156/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3465sec preferred_lft 3465sec
    inet6 fe80::890:45ff:fe59:23dd/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:04:81:e9:65:bb brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.228.190/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::804:81ff:fee9:65bb/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:2b:d8:23:f9:1f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2c2b:d8ff:fe23:f91f/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:61:bc:11:f7:cd brd ff:ff:ff:ff:ff:ff
    inet 10.65.0.209/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::5861:bcff:fe11:f7cd/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f6:37:4d:89:bb:3d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f437:4dff:fe89:bb3d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:31:74:ea:cf:55 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::3831:74ff:feea:cf55/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc724589a35ffd@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:9b:28:2a:b1:28 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::349b:28ff:fe2a:b128/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc326b646026da@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:69:41:83:68:12 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::4069:41ff:fe83:6812/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcfa7ed21a7731@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:5a:6c:81:06:fe brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::5a:6cff:fe81:6fe/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc83e819399742@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:b2:fe:26:e7:b4 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c4b2:feff:fe26:e7b4/64 scope link 
       valid_lft forever preferred_lft forever
22: lxca0f2dcb27bab@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:ca:0c:58:11:8a brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::b8ca:cff:fe58:118a/64 scope link 
       valid_lft forever preferred_lft forever
24: lxccaed6114a1aa@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:53:5c:dd:06:c9 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::d053:5cff:fedd:6c9/64 scope link 
       valid_lft forever preferred_lft forever
