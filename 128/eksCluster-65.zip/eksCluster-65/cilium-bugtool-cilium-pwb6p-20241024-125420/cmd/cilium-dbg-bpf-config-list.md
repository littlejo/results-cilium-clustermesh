KEY             VALUE
AgentLiveness   1948082447710
UTimeOffset     3378461945312500
