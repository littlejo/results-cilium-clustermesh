alloc: 75.91MB (79597656 bytes)
total-alloc: 3.06GB (3281163488 bytes)
sys: 211.32MB (221586772 bytes)
lookups: 0
mallocs: 74714147
frees: 74140282
heap-alloc: 75.91MB (79597656 bytes)
heap-sys: 166.82MB (174923776 bytes)
heap-idle: 43.88MB (46014464 bytes)
heap-in-use: 122.94MB (128909312 bytes)
heap-released: 3.49MB (3661824 bytes)
heap-objects: 573865
stack-in-use: 33.16MB (34766848 bytes)
stack-sys: 33.16MB (34766848 bytes)
stack-mspan-inuse: 2.06MB (2157280 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 978.61KB (1002097 bytes)
gc-sys: 5.50MB (5770312 bytes)
next-gc: when heap-alloc >= 146.72MB (153846392 bytes)
last-gc: 2024-10-24 12:54:16.711978749 +0000 UTC
gc-pause-total: 10.775537ms
gc-pause: 65945
gc-pause-end: 1729774456711978749
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0005174799505854151
enable-gc: true
debug-gc: false
