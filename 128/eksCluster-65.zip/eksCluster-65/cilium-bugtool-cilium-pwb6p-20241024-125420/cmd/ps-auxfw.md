USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3286  0.0  0.4 1240432 16152 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3319  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3320  0.0  0.0   3852  1284 ?        R    12:54   0:00  \_ bash -c hostname
root           1  3.7  7.3 1539060 287088 ?      Ssl  12:28   0:57 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.2  0.2 1229488 9020 ?        Sl   12:29   0:03 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
