Endpoint ID: 74
Path: /sys/fs/bpf/tc/globals/cilium_policy_00074

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    352027   4102      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 156
Path: /sys/fs/bpf/tc/globals/cilium_policy_00156

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6189418   76478     0        
Allow    Ingress     1          ANY          NONE         disabled    66894     809       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 702
Path: /sys/fs/bpf/tc/globals/cilium_policy_00702

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2968     32        0        
Allow    Ingress     1          ANY          NONE         disabled    145877   1678      0        
Allow    Egress      0          ANY          NONE         disabled    19340    215       0        


Endpoint ID: 1326
Path: /sys/fs/bpf/tc/globals/cilium_policy_01326

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2928     28        0        
Allow    Ingress     1          ANY          NONE         disabled    144984   1669      0        
Allow    Egress      0          ANY          NONE         disabled    20769    233       0        


Endpoint ID: 3103
Path: /sys/fs/bpf/tc/globals/cilium_policy_03103

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3135
Path: /sys/fs/bpf/tc/globals/cilium_policy_03135

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3202
Path: /sys/fs/bpf/tc/globals/cilium_policy_03202

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5426486   55856     0        
Allow    Ingress     1          ANY          NONE         disabled    4964488   52103     0        
Allow    Egress      0          ANY          NONE         disabled    5526330   57042     0        


Endpoint ID: 3836
Path: /sys/fs/bpf/tc/globals/cilium_policy_03836

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


