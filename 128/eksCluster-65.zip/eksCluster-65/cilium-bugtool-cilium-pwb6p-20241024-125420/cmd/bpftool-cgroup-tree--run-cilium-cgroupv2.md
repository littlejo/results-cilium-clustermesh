CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9d14462e_c3d8_4d8c_bec6_a923fb273eab.slice/cri-containerd-ec2438139e4c5ad2c799e752069b75d4997e48c19cf56678864e763e9b250a7c.scope
    530      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9d14462e_c3d8_4d8c_bec6_a923fb273eab.slice/cri-containerd-f39af19e878a5b2569523fca643c1eba20c751358fad550a7a47eabbcebc17bd.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8658c84f_2176_476f_88fe_1c400e34e1b6.slice/cri-containerd-5289c3244652a2b5f0edb12c2695d4e67c77771fd71cd0f61abb747809a19b96.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8658c84f_2176_476f_88fe_1c400e34e1b6.slice/cri-containerd-67a097fdefab826ad1209cce43ee8efec595ba94fed459e9c384de27dc1c7e5b.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod129eadb7_9433_4426_87a0_e80875c5a942.slice/cri-containerd-56cc024ecaa6cbe70070b16e50425ece31fa05c245106ea1d892a89df1746f32.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod129eadb7_9433_4426_87a0_e80875c5a942.slice/cri-containerd-69478cbb2a2cad89c16d5e38378e228afae4a1a6feb630a65410c28f2b19d7d4.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c56293b_6df9_48bd_a3ce_21b97a949177.slice/cri-containerd-894136781728521451a8a91bf9d6f1a5ec3367acdbdea2716187ef40746f0ae2.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c56293b_6df9_48bd_a3ce_21b97a949177.slice/cri-containerd-c3f8f9e8b3c4e8f80790c9d5bfda9ea5bddfec75de1e81da6099e62f8f2d51ed.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf98f14ae_4928_4451_a6b7_5b974f0a0293.slice/cri-containerd-7bc9bc6bee818bd0142870b84e6b6d511f93074326a80861c3e11dd20a3a0740.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf98f14ae_4928_4451_a6b7_5b974f0a0293.slice/cri-containerd-70a283b3b8aea6d95492f47c5422786df8161f34bdda67d7cee2f45223d4b26e.scope
    688      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bc7965_1fd7_47ba_bb70_df7f25c57293.slice/cri-containerd-14de9548b7ea5b16c83d6d9bf999f2c728b2e91f57a0ca9f39ce527ba11236af.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bc7965_1fd7_47ba_bb70_df7f25c57293.slice/cri-containerd-f0912f40b031e6543b989753c0bb427a48ee23442f604e39f269a964a7017d50.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bc7965_1fd7_47ba_bb70_df7f25c57293.slice/cri-containerd-2b4c1abbd3cc800288d32db4a4104d334a2abbbbe76fe2c8ce6a8034e60c2310.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3bc7965_1fd7_47ba_bb70_df7f25c57293.slice/cri-containerd-74dc66822abfacc5cb1202c5efbcabf2116d2e1d1bcacc411f7831723e16c075.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda8cb8efd_faf7_4431_a20d_6053dde68928.slice/cri-containerd-ac510ffeb879e15c792954a360f448ebcc3c4b76ba1dfd63a373f10a53d96586.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda8cb8efd_faf7_4431_a20d_6053dde68928.slice/cri-containerd-154f116db6c0591a53d9fc34af72536ce4dbbb3cb0c418eaf8e869c734442731.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod80b1ba85_b447_4a01_84c8_2959c2e47de1.slice/cri-containerd-46aef281f8f9f7469a1eec25652ba4d21d6e95dde6ddf92f8cca15f30ba0d3a8.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod80b1ba85_b447_4a01_84c8_2959c2e47de1.slice/cri-containerd-fb39443b96652fc2f9bb7102e4323989799bfd690f16816f4e1fb262df40ead4.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0c7c1b5c_f1c9_4bcc_844e_e62250ed5d7f.slice/cri-containerd-240276afb40519088ebad35be7de04e16cbce0f4464b96262f6c7ddca14201ca.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0c7c1b5c_f1c9_4bcc_844e_e62250ed5d7f.slice/cri-containerd-e01343ab234647b33cdec24f50fb88db61ef6521e518434427c243d928f4a111.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33d8bdbf_a1b4_48df_bcb3_00d9f8f61268.slice/cri-containerd-1a9bfe975202267a2dbdf9959ac7158a864588c788b231615f7f05d8d3f723f3.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33d8bdbf_a1b4_48df_bcb3_00d9f8f61268.slice/cri-containerd-0ac182d2eb5006f271467e2b2ed71ac52640baa36d4ad08fc75fe561f4c44e98.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33d8bdbf_a1b4_48df_bcb3_00d9f8f61268.slice/cri-containerd-220e7d6a495d92fd0e7c645f591a0d92074a83353eaa7ca6be18b5c68fe1a0b1.scope
    719      cgroup_device   multi                                          
