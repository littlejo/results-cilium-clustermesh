xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 569
ens6(5) clsact/ingress cil_from_netdev-ens6 id 574
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 561
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 553
cilium_host(7) clsact/egress cil_from_host-cilium_host id 556
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 515
lxc724589a35ffd(12) clsact/ingress cil_from_container-lxc724589a35ffd id 544
lxc326b646026da(14) clsact/ingress cil_from_container-lxc326b646026da id 507
lxcfa7ed21a7731(18) clsact/ingress cil_from_container-lxcfa7ed21a7731 id 628
lxc83e819399742(20) clsact/ingress cil_from_container-lxc83e819399742 id 3276
lxca0f2dcb27bab(22) clsact/ingress cil_from_container-lxca0f2dcb27bab id 3328
lxccaed6114a1aa(24) clsact/ingress cil_from_container-lxccaed6114a1aa id 3348

flow_dissector:

netfilter:

