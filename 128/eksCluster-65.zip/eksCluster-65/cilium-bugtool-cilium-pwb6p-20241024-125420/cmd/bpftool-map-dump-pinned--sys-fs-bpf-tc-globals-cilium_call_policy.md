key: 4a 00 00 00  value: d5 0c 00 00
key: 9c 00 00 00  value: 08 02 00 00
key: be 02 00 00  value: 18 02 00 00
key: 2e 05 00 00  value: 02 02 00 00
key: 1f 0c 00 00  value: 02 0d 00 00
key: 82 0c 00 00  value: 70 02 00 00
key: fc 0e 00 00  value: 0d 0d 00 00
Found 7 elements
