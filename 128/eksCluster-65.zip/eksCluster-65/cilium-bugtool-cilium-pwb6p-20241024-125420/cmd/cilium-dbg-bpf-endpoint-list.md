IP ADDRESS         LOCAL ENDPOINT INFO
172.31.228.190:0   (localhost)                                                                                        
172.31.227.156:0   (localhost)                                                                                        
10.65.0.62:0       id=3836  sec_id=4331945 flags=0x0000 ifindex=22  mac=8E:84:CB:1D:EF:68 nodemac=BA:CA:0C:58:11:8A   
10.65.0.197:0      id=74    sec_id=4346596 flags=0x0000 ifindex=20  mac=FE:6E:68:2A:20:FB nodemac=C6:B2:FE:26:E7:B4   
10.65.0.21:0       id=3202  sec_id=4335060 flags=0x0000 ifindex=18  mac=46:8B:F8:24:26:BA nodemac=02:5A:6C:81:06:FE   
10.65.0.209:0      (localhost)                                                                                        
10.65.0.223:0      id=156   sec_id=4     flags=0x0000 ifindex=10  mac=E6:AB:86:CC:FB:34 nodemac=3A:31:74:EA:CF:55     
10.65.0.211:0      id=702   sec_id=4374996 flags=0x0000 ifindex=12  mac=26:1E:07:AF:3F:76 nodemac=36:9B:28:2A:B1:28   
10.65.0.190:0      id=3103  sec_id=4373777 flags=0x0000 ifindex=24  mac=4E:6C:D7:43:33:65 nodemac=D2:53:5C:DD:06:C9   
10.65.0.83:0       id=1326  sec_id=4374996 flags=0x0000 ifindex=14  mac=C6:5A:71:FC:C2:14 nodemac=42:69:41:83:68:12   
