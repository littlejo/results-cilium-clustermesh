filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxca0f2dcb27bab direct-action not_in_hw id 3328 tag 9372e04a52240bfd jited 
