Node 0, zone      DMA      0      0      2      1      2      2      1      3      1      4     32 
Node 0, zone   Normal    340     65     26      6     17      6      9      7      4      4      5 
