top - 12:54:22 up 32 min,  0 users,  load average: 0.27, 0.32, 0.19
Tasks:   5 total,   1 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 37.5 us, 25.0 sy,  0.0 ni, 34.4 id,  0.0 wa,  0.0 hi,  3.1 si,  0.0 st
MiB Mem :   3836.2 total,    292.1 free,   1049.0 used,   2495.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2606.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 289992  78268 S  40.0   7.4   0:57.82 cilium-+
    394 root      20   0 1229488   9020   2924 S   0.0   0.2   0:03.57 cilium-+
   3286 root      20   0 1240432  16152  11292 S   0.0   0.4   0:00.01 cilium-+
   3330 root      20   0    6576   2408   2084 R   0.0   0.1   0:00.00 top
   3354 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
