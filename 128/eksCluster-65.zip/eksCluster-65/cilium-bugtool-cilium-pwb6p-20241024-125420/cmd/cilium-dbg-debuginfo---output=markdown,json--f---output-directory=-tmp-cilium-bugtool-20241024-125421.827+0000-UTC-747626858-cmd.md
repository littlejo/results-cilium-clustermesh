markdown output at /tmp/cilium-bugtool-20241024-125421.827+0000-UTC-747626858/cmd/cilium-debuginfo-20241024-125422.909+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125421.827+0000-UTC-747626858/cmd/cilium-debuginfo-20241024-125422.909+0000-UTC.json
