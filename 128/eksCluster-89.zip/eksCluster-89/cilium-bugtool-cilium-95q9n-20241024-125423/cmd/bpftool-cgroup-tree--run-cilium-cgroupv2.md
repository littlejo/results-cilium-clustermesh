CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf55c7000_c65c_48d1_838f_d2dbdd0c6e2e.slice/cri-containerd-0ea31603324323329d6a1f6286a31f6e09806799e52ba0f0b45fed7d4fd20aee.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf55c7000_c65c_48d1_838f_d2dbdd0c6e2e.slice/cri-containerd-caf700d1dfd05e3740290edc2f4e2133f7fb20030b1ac01c253ace8e97f350cb.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod92d0ce41_f538_451e_956f_0ff329b65bdc.slice/cri-containerd-b839b0f175920361b03e5b4f86e6b12e8777904112273834360d0a194dfbc875.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod92d0ce41_f538_451e_956f_0ff329b65bdc.slice/cri-containerd-6ed313d14d455d3b349973cb67730741324da0cf096b697aafac5601a35e150c.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcb9df1c6_e7f6_49ef_9606_c0c7a6e013ce.slice/cri-containerd-dbcbbcb2e9207c60696c9f3acf003ee7e0c562d7a843cf5b6869367936c3d4ce.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcb9df1c6_e7f6_49ef_9606_c0c7a6e013ce.slice/cri-containerd-0b54348741b26d25dbf7d5449814984e05d1f75c096e90a5959a8b95fff9c817.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3e9f2b6_bd9f_479b_ac53_c6ee839a1840.slice/cri-containerd-682d5923e6e9413907068bfb51f3dc27c7d75aa47a3a7270c054d15c814b75c5.scope
    492      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3e9f2b6_bd9f_479b_ac53_c6ee839a1840.slice/cri-containerd-18832b3c4455567cd3ee6c97b01e2563a2324fdcac6c719fa9e602f0fc52979d.scope
    496      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8329f25b_755a_4e21_a47a_655d58f5b936.slice/cri-containerd-c310a742fcceb46c4cfd714c132d4cb6e076ded4a2cac6c15054c06f82671270.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8329f25b_755a_4e21_a47a_655d58f5b936.slice/cri-containerd-c237d4005684fa79a18f01ea0c71a77c01220fd2824cfec846a4f060ddbbc65c.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8329f25b_755a_4e21_a47a_655d58f5b936.slice/cri-containerd-c5691b882c0fd8c991e290520ac9200847952c43bffeaf3e17dece6ce7e99848.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2696dedb_b8b6_48bd_86a8_4a5a396b8283.slice/cri-containerd-c99a81ca4cd26fc7757eceaefe114074d315fef7dc549ebc579e62fb9dfa8cfd.scope
    669      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2696dedb_b8b6_48bd_86a8_4a5a396b8283.slice/cri-containerd-e649aadcc1d7b3fc2e82f4142c742b2c4944c23b436dcb997912cd92bc0b3854.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2696dedb_b8b6_48bd_86a8_4a5a396b8283.slice/cri-containerd-aad3640b410d734ba88bc636fe63914303ccba782f7edeea9c708810eadd0ade.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2696dedb_b8b6_48bd_86a8_4a5a396b8283.slice/cri-containerd-c930e73ce20f6c8879f196b9cd9b1f77d9c2a47cfb4794ea048cafe75ac21788.scope
    665      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod088cf58b_e860_4a7c_a592_d7f988eb3ec1.slice/cri-containerd-6c1e8652f4f997d1ae75b62def469a96ad952fd7ea74e8d3ea2f2126cc35abaa.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod088cf58b_e860_4a7c_a592_d7f988eb3ec1.slice/cri-containerd-b8cdb3fd10d6583bae629907b32bc40f43e5ecd092c4fbacd58108582aaf0111.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2fe2dc83_a87e_4049_9261_28800a3eff31.slice/cri-containerd-872aa784851bb4dffb060d0339d2f84167dcf2a7bb3cf5d0ab9286138a81c07a.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2fe2dc83_a87e_4049_9261_28800a3eff31.slice/cri-containerd-b6199369b7fd17c6ac7786c024f09163c1b5404ac1777838b0c587fe456f024c.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf9d6b6d_2c53_4895_9552_f9a9e2cfdc57.slice/cri-containerd-cf270b927e542cd327ef65675c7a3c7b9f82002597df214d1d19c94512bc7f2a.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf9d6b6d_2c53_4895_9552_f9a9e2cfdc57.slice/cri-containerd-42daa323ecbc1871547aa52666d9a0ac3b961b8f75fa57788966872e510aee93.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c3b391b_543f_4fc8_b709_1ed352adf534.slice/cri-containerd-ece9e16ee516833c624af0972b6b4f40a39e3aa2a1bae448feeadcc987083f46.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c3b391b_543f_4fc8_b709_1ed352adf534.slice/cri-containerd-05ec28d5ab30965607cfdb4bb0022bb3ed650e56258eefe801827115cd28d05d.scope
    722      cgroup_device   multi                                          
