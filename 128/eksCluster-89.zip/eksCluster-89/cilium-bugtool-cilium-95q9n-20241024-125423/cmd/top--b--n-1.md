top - 12:54:25 up 31 min,  0 users,  load average: 0.21, 0.31, 0.25
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 17.9 us, 25.0 sy,  0.0 ni, 57.1 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    327.9 free,   1041.5 used,   2466.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2613.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3224 root      20   0 1240432  16064  10832 S  13.3   0.4   0:00.03 cilium-+
      1 root      20   0 1539060 287584  78588 S   0.0   7.3   1:06.27 cilium-+
    417 root      20   0 1229744  10208   3900 S   0.0   0.3   0:04.48 cilium-+
   3190 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
   3211 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3218 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3265 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3283 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
   3289 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
