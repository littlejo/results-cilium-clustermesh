alloc: 110.81MB (116187768 bytes)
total-alloc: 3.06GB (3288902680 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 74844029
frees: 73759594
heap-alloc: 110.81MB (116187768 bytes)
heap-sys: 172.70MB (181092352 bytes)
heap-idle: 37.35MB (39165952 bytes)
heap-in-use: 135.35MB (141926400 bytes)
heap-released: 4.82MB (5054464 bytes)
heap-objects: 1084435
stack-in-use: 35.25MB (36962304 bytes)
stack-sys: 35.25MB (36962304 bytes)
stack-mspan-inuse: 2.11MB (2212160 bytes)
stack-mspan-sys: 2.72MB (2856000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1023.75KB (1048321 bytes)
gc-sys: 5.53MB (5801104 bytes)
next-gc: when heap-alloc >= 149.40MB (156652136 bytes)
last-gc: 2024-10-24 12:54:31.652073641 +0000 UTC
gc-pause-total: 12.149169ms
gc-pause: 102071
gc-pause-end: 1729774471652073641
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0006341244339219371
enable-gc: true
debug-gc: false
