ip-172-31-223-204.eu-west-3.compute.internal
