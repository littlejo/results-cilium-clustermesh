xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 579
ens6(5) clsact/ingress cil_from_netdev-ens6 id 590
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 575
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 567
cilium_host(7) clsact/egress cil_from_host-cilium_host id 570
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 498
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 499
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 539
lxc19a1ae385e2a(12) clsact/ingress cil_from_container-lxc19a1ae385e2a id 526
lxc079d48acf8f3(14) clsact/ingress cil_from_container-lxc079d48acf8f3 id 554
lxc9be79d17af8b(18) clsact/ingress cil_from_container-lxc9be79d17af8b id 641
lxcfa477ec83415(20) clsact/ingress cil_from_container-lxcfa477ec83415 id 3340
lxce8275f85f6e8(22) clsact/ingress cil_from_container-lxce8275f85f6e8 id 3338
lxcb4cd9fc82b91(24) clsact/ingress cil_from_container-lxcb4cd9fc82b91 id 3298

flow_dissector:

netfilter:

