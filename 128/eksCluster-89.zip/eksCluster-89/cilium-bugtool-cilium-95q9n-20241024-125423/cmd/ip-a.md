1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c6:f4:21:72:d7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.223.204/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3505sec preferred_lft 3505sec
    inet6 fe80::8c6:f4ff:fe21:72d7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:4e:a0:e9:2d:33 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.245.15/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::84e:a0ff:fee9:2d33/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:c2:ac:81:8c:d7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::68c2:acff:fe81:8cd7/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:52:fc:72:66:01 brd ff:ff:ff:ff:ff:ff
    inet 10.89.0.17/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::dc52:fcff:fe72:6601/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 7a:ff:67:0f:a0:0b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::78ff:67ff:fe0f:a00b/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:b0:86:dc:24:04 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::78b0:86ff:fedc:2404/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc19a1ae385e2a@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:b2:89:5c:2a:2d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b4b2:89ff:fe5c:2a2d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc079d48acf8f3@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:34:85:a1:26:a3 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::dc34:85ff:fea1:26a3/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc9be79d17af8b@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:03:5c:73:6a:38 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::3:5cff:fe73:6a38/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcfa477ec83415@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:6b:ef:ab:6b:06 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::986b:efff:feab:6b06/64 scope link 
       valid_lft forever preferred_lft forever
22: lxce8275f85f6e8@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:0c:ab:c9:a6:15 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::580c:abff:fec9:a615/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcb4cd9fc82b91@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:0f:67:1a:b6:81 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::c0f:67ff:fe1a:b681/64 scope link 
       valid_lft forever preferred_lft forever
