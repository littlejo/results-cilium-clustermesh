[
  {
    "containers": [
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8329f25b_755a_4e21_a47a_655d58f5b936.slice/cri-containerd-c5691b882c0fd8c991e290520ac9200847952c43bffeaf3e17dece6ce7e99848.scope"
      },
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8329f25b_755a_4e21_a47a_655d58f5b936.slice/cri-containerd-c310a742fcceb46c4cfd714c132d4cb6e076ded4a2cac6c15054c06f82671270.scope"
      }
    ],
    "ips": [
      "10.89.0.65"
    ],
    "name": "echo-same-node-86d9cc975c-gjg22",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7488,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3e9f2b6_bd9f_479b_ac53_c6ee839a1840.slice/cri-containerd-18832b3c4455567cd3ee6c97b01e2563a2324fdcac6c719fa9e602f0fc52979d.scope"
      }
    ],
    "ips": [
      "10.89.0.5"
    ],
    "name": "coredns-cc6ccd49c-h2258",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf55c7000_c65c_48d1_838f_d2dbdd0c6e2e.slice/cri-containerd-0ea31603324323329d6a1f6286a31f6e09806799e52ba0f0b45fed7d4fd20aee.scope"
      }
    ],
    "ips": [
      "10.89.0.91"
    ],
    "name": "coredns-cc6ccd49c-tzxzn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c3b391b_543f_4fc8_b709_1ed352adf534.slice/cri-containerd-05ec28d5ab30965607cfdb4bb0022bb3ed650e56258eefe801827115cd28d05d.scope"
      }
    ],
    "ips": [
      "10.89.0.229"
    ],
    "name": "client-974f6c69d-2rhdg",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf9d6b6d_2c53_4895_9552_f9a9e2cfdc57.slice/cri-containerd-42daa323ecbc1871547aa52666d9a0ac3b961b8f75fa57788966872e510aee93.scope"
      }
    ],
    "ips": [
      "10.89.0.30"
    ],
    "name": "client2-57cf4468f-2zvz8",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2696dedb_b8b6_48bd_86a8_4a5a396b8283.slice/cri-containerd-c930e73ce20f6c8879f196b9cd9b1f77d9c2a47cfb4794ea048cafe75ac21788.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2696dedb_b8b6_48bd_86a8_4a5a396b8283.slice/cri-containerd-aad3640b410d734ba88bc636fe63914303ccba782f7edeea9c708810eadd0ade.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2696dedb_b8b6_48bd_86a8_4a5a396b8283.slice/cri-containerd-c99a81ca4cd26fc7757eceaefe114074d315fef7dc549ebc579e62fb9dfa8cfd.scope"
      }
    ],
    "ips": [
      "10.89.0.159"
    ],
    "name": "clustermesh-apiserver-5466d8878f-gfhwd",
    "namespace": "kube-system"
  }
]

