KEY             VALUE
AgentLiveness   1937060211871
UTimeOffset     3378462029296875
