Endpoint ID: 61
Path: /sys/fs/bpf/tc/globals/cilium_policy_00061

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 207
Path: /sys/fs/bpf/tc/globals/cilium_policy_00207

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6123667   60814     0        
Allow    Ingress     1          ANY          NONE         disabled    5316876   56161     0        
Allow    Egress      0          ANY          NONE         disabled    6049745   60673     0        


Endpoint ID: 359
Path: /sys/fs/bpf/tc/globals/cilium_policy_00359

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 752
Path: /sys/fs/bpf/tc/globals/cilium_policy_00752

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6217558   77131     0        
Allow    Ingress     1          ANY          NONE         disabled    60754     739       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 793
Path: /sys/fs/bpf/tc/globals/cilium_policy_00793

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1147
Path: /sys/fs/bpf/tc/globals/cilium_policy_01147

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2680     27        0        
Allow    Ingress     1          ANY          NONE         disabled    136784   1573      0        
Allow    Egress      0          ANY          NONE         disabled    18943    208       0        


Endpoint ID: 1352
Path: /sys/fs/bpf/tc/globals/cilium_policy_01352

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3216     33        0        
Allow    Ingress     1          ANY          NONE         disabled    136039   1566      0        
Allow    Egress      0          ANY          NONE         disabled    19750    218       0        


Endpoint ID: 2435
Path: /sys/fs/bpf/tc/globals/cilium_policy_02435

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379878   4435      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


