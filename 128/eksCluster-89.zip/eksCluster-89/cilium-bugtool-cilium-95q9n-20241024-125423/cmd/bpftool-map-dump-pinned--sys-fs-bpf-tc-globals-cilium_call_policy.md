key: 3d 00 00 00  value: 1e 0d 00 00
key: cf 00 00 00  value: 7d 02 00 00
key: 67 01 00 00  value: 0b 0d 00 00
key: f0 02 00 00  value: 21 02 00 00
key: 7b 04 00 00  value: 2d 02 00 00
key: 48 05 00 00  value: 0b 02 00 00
key: 83 09 00 00  value: d4 0c 00 00
Found 7 elements
