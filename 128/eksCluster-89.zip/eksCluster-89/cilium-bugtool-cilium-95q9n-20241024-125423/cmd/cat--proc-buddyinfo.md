Node 0, zone      DMA     18      1     25     35     16      8      4      3      2      3     49 
Node 0, zone   Normal      4      5      1      1      0      7      4      2      3      2      8 
