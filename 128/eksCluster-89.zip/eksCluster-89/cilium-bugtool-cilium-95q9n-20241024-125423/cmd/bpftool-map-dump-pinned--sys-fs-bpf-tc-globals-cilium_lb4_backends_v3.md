key: 06 00 00 00  value: 0a 59 00 05 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 92 3e 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 59 00 05 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f df cc 10 94 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f fb 84 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 59 00 9f 09 4b 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 59 00 5b 00 35 00 00  00 00 00 00
key: 0c 00 00 00  value: 0a 59 00 41 1f 90 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 59 00 5b 23 c1 00 00  00 00 00 00
Found 9 elements
