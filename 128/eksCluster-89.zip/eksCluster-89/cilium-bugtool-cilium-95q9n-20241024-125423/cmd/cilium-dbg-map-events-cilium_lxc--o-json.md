{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.237Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.247Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.283Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.304Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.320Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.536Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.564Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.624Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.639Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.670Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.238Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.239Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.293Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.296Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.338Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.370Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.412Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.644Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.669Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.709Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.746Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.750Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.345Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.348Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.384Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.395Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.433Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.451Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.472Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.781Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.791Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.847Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.866Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.901Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.500Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.538Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.548Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.589Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.593Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.632Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.893Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.912Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.960Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.981Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.014Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.412Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.425Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.462Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.493Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.514Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.738Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.755Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.794Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.803Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.849Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.278Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.279Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.327Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.356Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.368Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.611Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.616Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.664Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.684Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.757Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.171Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.212Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.219Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.261Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.262Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.272Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.499Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.511Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.561Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.569Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.619Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.027Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.063Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.085Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.127Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.135Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.170Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.392Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.395Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.453Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.473Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.528Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.908Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.995Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.011Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.072Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.073Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.116Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.295Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.323Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.347Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.379Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.398Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.688Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.746Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.750Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.792Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.812Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.839Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.082Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.101Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.129Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.163Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.189Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.482Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.533Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.554Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.581Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.602Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.619Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.871Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.921Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.927Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.980Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.677Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.679Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.729Z",
  "value": "id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.745Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.769Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.016Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.026Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.723Z",
  "value": "id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.733Z",
  "value": "id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15"
}

