IP ADDRESS         LOCAL ENDPOINT INFO
10.89.0.5:0        id=1352  sec_id=5907300 flags=0x0000 ifindex=12  mac=66:E3:CB:63:FC:B9 nodemac=B6:B2:89:5C:2A:2D   
10.89.0.65:0       id=2435  sec_id=5946324 flags=0x0000 ifindex=24  mac=92:5F:2B:FF:63:91 nodemac=0E:0F:67:1A:B6:81   
172.31.245.15:0    (localhost)                                                                                        
10.89.0.229:0      id=61    sec_id=5936071 flags=0x0000 ifindex=22  mac=6A:57:45:72:AA:8C nodemac=5A:0C:AB:C9:A6:15   
10.89.0.17:0       (localhost)                                                                                        
10.89.0.91:0       id=1147  sec_id=5907300 flags=0x0000 ifindex=14  mac=5E:B6:BC:F9:C1:BC nodemac=DE:34:85:A1:26:A3   
10.89.0.159:0      id=207   sec_id=5900895 flags=0x0000 ifindex=18  mac=FE:C0:FF:D3:2C:E0 nodemac=02:03:5C:73:6A:38   
172.31.223.204:0   (localhost)                                                                                        
10.89.0.30:0       id=359   sec_id=5918486 flags=0x0000 ifindex=20  mac=A2:25:38:94:92:5F nodemac=9A:6B:EF:AB:6B:06   
10.89.0.6:0        id=752   sec_id=4     flags=0x0000 ifindex=10  mac=6A:CF:5E:E8:DF:0B nodemac=7A:B0:86:DC:24:04     
