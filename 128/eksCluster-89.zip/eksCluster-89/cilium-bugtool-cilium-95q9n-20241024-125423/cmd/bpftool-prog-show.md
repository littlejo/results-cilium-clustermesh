29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:42+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:42+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:43+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:43+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:43+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:43+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:47+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:23:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:23:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
489: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
492: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
493: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
496: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
497: sched_cls  name tail_handle_ipv4  tag 42686451ebd81032  gpl
	loaded_at 2024-10-24T12:30:59+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,104
	btf_id 136
498: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:30:59+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,104
	btf_id 137
499: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:30:59+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 138
500: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:30:59+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 139
523: sched_cls  name handle_policy  tag 1cb9623550fd36a9  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,111,41,80,91,39,84,75,40,37,38
	btf_id 165
524: sched_cls  name __send_drop_notify  tag 567ca7f878d37272  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 166
525: sched_cls  name tail_handle_ipv4  tag 85ee59a960a47b92  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 167
526: sched_cls  name cil_from_container  tag 3d2a78554ba33d7d  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 168
528: sched_cls  name tail_handle_ipv4_cont  tag b4bbb233a0a3e698  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,111,41,91,82,83,39,76,74,77,112,40,37,38,81
	btf_id 170
529: sched_cls  name tail_ipv4_to_endpoint  tag 19d9007ae6299d8c  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,111,41,82,83,80,91,39,112,40,37,38
	btf_id 171
530: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 172
531: sched_cls  name tail_ipv4_ct_egress  tag 1f2f5eb169c7e7f9  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 173
532: sched_cls  name tail_handle_arp  tag b5e64a925a1f9c87  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 174
533: sched_cls  name tail_ipv4_ct_ingress  tag 1bf02c5029c49f11  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 175
535: sched_cls  name __send_drop_notify  tag 9cc9f35d8bdbaead  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 178
536: sched_cls  name tail_handle_ipv4  tag d4fe10ed21942487  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,114
	btf_id 179
537: sched_cls  name tail_handle_arp  tag bdb064404770e652  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,114
	btf_id 180
538: sched_cls  name tail_handle_ipv4_cont  tag 64296dfbbd92a405  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,113,41,105,82,83,39,76,74,77,114,40,37,38,81
	btf_id 181
539: sched_cls  name cil_from_container  tag 1b63ab583a3a89fc  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 114,76
	btf_id 182
540: sched_cls  name tail_ipv4_ct_ingress  tag 33a51af925e963b5  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 183
541: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
544: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
545: sched_cls  name handle_policy  tag 4482894fe47d276f  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,114,82,83,113,41,80,105,39,84,75,40,37,38
	btf_id 184
546: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,114
	btf_id 185
547: sched_cls  name tail_ipv4_to_endpoint  tag 77a3214fce5bee94  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,113,41,82,83,80,105,39,114,40,37,38
	btf_id 186
548: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 187
549: sched_cls  name tail_ipv4_ct_ingress  tag 00b8b5a7d1460c40  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,117,82,83,116,84
	btf_id 189
550: sched_cls  name tail_ipv4_to_endpoint  tag bbf5851d6cafdd7a  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,106,39,117,40,37,38
	btf_id 190
551: sched_cls  name tail_ipv4_ct_egress  tag 1f2f5eb169c7e7f9  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,117,82,83,116,84
	btf_id 191
552: sched_cls  name tail_handle_arp  tag 292b6ba15bcf65f4  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 192
553: sched_cls  name tail_handle_ipv4_cont  tag 98f3788776557577  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,106,82,83,39,76,74,77,117,40,37,38,81
	btf_id 193
554: sched_cls  name cil_from_container  tag bdf744b1ad1cf843  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 117,76
	btf_id 194
555: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 195
557: sched_cls  name handle_policy  tag 4ad3bb570fabc29f  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,117,82,83,116,41,80,106,39,84,75,40,37,38
	btf_id 197
558: sched_cls  name __send_drop_notify  tag 66e175853f3c9653  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 198
559: sched_cls  name tail_handle_ipv4  tag e35efcba9d216297  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 199
560: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
563: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
564: sched_cls  name __send_drop_notify  tag b9f58330a8db821d  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
565: sched_cls  name tail_handle_ipv4_from_host  tag 16e907f31a71ddef  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 202
566: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 203
567: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 204
570: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,120
	btf_id 207
572: sched_cls  name __send_drop_notify  tag b9f58330a8db821d  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 210
573: sched_cls  name tail_handle_ipv4_from_host  tag 16e907f31a71ddef  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 211
574: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 212
575: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 213
579: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 218
582: sched_cls  name __send_drop_notify  tag b9f58330a8db821d  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 221
583: sched_cls  name tail_handle_ipv4_from_host  tag 16e907f31a71ddef  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 222
584: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 223
586: sched_cls  name __send_drop_notify  tag b9f58330a8db821d  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 226
587: sched_cls  name tail_handle_ipv4_from_host  tag 16e907f31a71ddef  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,125
	btf_id 227
588: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,125
	btf_id 228
590: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:31:02+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,125,75
	btf_id 230
631: sched_cls  name tail_ipv4_to_endpoint  tag 8d169b8faecb3c30  gpl
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,138,41,82,83,80,137,39,139,40,37,38
	btf_id 245
632: sched_cls  name tail_ipv4_ct_ingress  tag a7c30100d635460c  gpl
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 246
633: sched_cls  name tail_ipv4_ct_egress  tag 4a21ae1b19ea942b  gpl
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 247
634: sched_cls  name tail_handle_ipv4_cont  tag dc4e2088525abd46  gpl
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,138,41,137,82,83,39,76,74,77,139,40,37,38,81
	btf_id 248
636: sched_cls  name __send_drop_notify  tag 8e7a7fb38b452d34  gpl
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 250
637: sched_cls  name handle_policy  tag 27b7121b49fa880e  gpl
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,139,82,83,138,41,80,137,39,84,75,40,37,38
	btf_id 251
638: sched_cls  name tail_handle_ipv4  tag c71562a662795291  gpl
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,139
	btf_id 252
639: sched_cls  name tail_handle_arp  tag 6291c8441ac27ff4  gpl
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,139
	btf_id 253
640: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,139
	btf_id 254
641: sched_cls  name cil_from_container  tag 52a2df7c27a226fd  gpl
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 139,76
	btf_id 255
642: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
645: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
658: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
661: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
662: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
665: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
666: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
669: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
703: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
706: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
707: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
710: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
711: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
714: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
715: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
718: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
719: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
722: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
723: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
726: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
727: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
730: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3284: sched_cls  name handle_policy  tag 91334ebd58bfe35b  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,627,82,83,628,41,80,153,39,84,75,40,37,38
	btf_id 3077
3285: sched_cls  name tail_handle_arp  tag 8f8c912ece336a3d  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,627
	btf_id 3081
3286: sched_cls  name __send_drop_notify  tag 745202d867ef855a  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3082
3290: sched_cls  name tail_ipv4_ct_egress  tag 7e1b4195e04febbc  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3083
3292: sched_cls  name tail_handle_ipv4_cont  tag ba4172e5bb9e7c5f  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,628,41,153,82,83,39,76,74,77,627,40,37,38,81
	btf_id 3088
3295: sched_cls  name tail_ipv4_ct_ingress  tag 9e088dea06bf5ae8  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3089
3296: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,627
	btf_id 3092
3298: sched_cls  name cil_from_container  tag af95e30e13d74041  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 627,76
	btf_id 3093
3301: sched_cls  name tail_ipv4_to_endpoint  tag 00794fb09f3abd26  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,628,41,82,83,80,153,39,627,40,37,38
	btf_id 3096
3302: sched_cls  name tail_handle_ipv4  tag 18b72903dedc9fe6  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,627
	btf_id 3098
3338: sched_cls  name cil_from_container  tag c69aef8a8de98613  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 640,76
	btf_id 3139
3339: sched_cls  name handle_policy  tag 6d270e2577baeace  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,637,82,83,638,41,80,147,39,84,75,40,37,38
	btf_id 3137
3340: sched_cls  name cil_from_container  tag 61f6dfd1545a6691  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 637,76
	btf_id 3140
3341: sched_cls  name tail_handle_arp  tag 4d0cb8a94c6817f5  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,637
	btf_id 3141
3342: sched_cls  name tail_ipv4_ct_ingress  tag 83dbcc82b750cd78  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3142
3343: sched_cls  name tail_handle_ipv4_cont  tag 6c2484a5088efb78  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,638,41,147,82,83,39,76,74,77,637,40,37,38,81
	btf_id 3143
3344: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,640
	btf_id 3145
3345: sched_cls  name tail_handle_arp  tag a3da170e7a669682  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,640
	btf_id 3146
3346: sched_cls  name tail_handle_ipv4_cont  tag 520d26e02ab8651c  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,639,41,150,82,83,39,76,74,77,640,40,37,38,81
	btf_id 3147
3348: sched_cls  name tail_ipv4_to_endpoint  tag dbf79451f4f978f8  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,638,41,82,83,80,147,39,637,40,37,38
	btf_id 3144
3349: sched_cls  name tail_ipv4_ct_egress  tag bc46c93473b7c306  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3149
3350: sched_cls  name tail_ipv4_ct_egress  tag c929171cbdb88783  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3150
3351: sched_cls  name tail_ipv4_ct_ingress  tag f3a42a32dce4ede0  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3152
3352: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,637
	btf_id 3153
3354: sched_cls  name tail_handle_ipv4  tag 191a360b3ead8ebd  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,640
	btf_id 3151
3355: sched_cls  name __send_drop_notify  tag a46c7d4a937213ee  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3156
3356: sched_cls  name tail_handle_ipv4  tag 84427b88efcadc7a  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,637
	btf_id 3155
3357: sched_cls  name __send_drop_notify  tag 8312f787f11a67b4  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3158
3358: sched_cls  name handle_policy  tag 41c792328c774cfd  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,640,82,83,639,41,80,150,39,84,75,40,37,38
	btf_id 3157
3359: sched_cls  name tail_ipv4_to_endpoint  tag 14950aa4604f9d4b  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,639,41,82,83,80,150,39,640,40,37,38
	btf_id 3159
