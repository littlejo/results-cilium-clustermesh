qdisc noqueue 0: dev lo root refcnt 2 
qdisc mq 0: dev ens5 root 
qdisc fq_codel 0: dev ens5 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens5 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens5 parent ffff:fff1 
qdisc mq 0: dev ens6 root 
qdisc fq_codel 0: dev ens6 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens6 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens6 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
qdisc noqueue 0: dev lxc399f55d768bf root refcnt 2 
qdisc clsact ffff: dev lxc399f55d768bf parent ffff:fff1 
qdisc noqueue 0: dev lxcdc4ccf6a0789 root refcnt 2 
qdisc clsact ffff: dev lxcdc4ccf6a0789 parent ffff:fff1 
qdisc noqueue 0: dev lxc0b7992004aa2 root refcnt 2 
qdisc clsact ffff: dev lxc0b7992004aa2 parent ffff:fff1 
qdisc noqueue 0: dev lxc8f80227d3126 root refcnt 2 
qdisc clsact ffff: dev lxc8f80227d3126 parent ffff:fff1 
qdisc noqueue 0: dev lxc3d4495fadfb6 root refcnt 2 
qdisc clsact ffff: dev lxc3d4495fadfb6 parent ffff:fff1 
qdisc noqueue 0: dev lxce39f2115bb5e root refcnt 2 
qdisc clsact ffff: dev lxce39f2115bb5e parent ffff:fff1 
