[
  {
    "containers": [
      {
        "cgroup-id": 7625,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod40f041fc_69a7_42cc_b9db_4b33ba473408.slice/cri-containerd-b04649255137c5f24abdb779f6034a412440d24ec69601b4259a845f3defdfe9.scope"
      }
    ],
    "ips": [
      "10.101.0.133"
    ],
    "name": "coredns-cc6ccd49c-q5p69",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9941,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod107d6a1a_62a9_42d7_8491_4e2cf0af7161.slice/cri-containerd-cb7708b8f01e978027df03021434e7714cbbb1342a3246376bae0829e849d5fa.scope"
      }
    ],
    "ips": [
      "10.101.0.170"
    ],
    "name": "client-974f6c69d-6cjpr",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9857,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8bc0d853_a3d7_4be7_9f4f_e1bfd8e1c485.slice/cri-containerd-31378fbcf7f4c24c9e1b1608054de9e612a4ec31ed440e047baa31971f9deb53.scope"
      }
    ],
    "ips": [
      "10.101.0.155"
    ],
    "name": "client2-57cf4468f-rx9xc",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9185,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod363b6582_3521_4f74_882a_3e9ad3e6f17c.slice/cri-containerd-122eea153789efcb4f9dc2e3d15f2c8b059741078774c536353ddcda24c2078b.scope"
      },
      {
        "cgroup-id": 9101,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod363b6582_3521_4f74_882a_3e9ad3e6f17c.slice/cri-containerd-67bcc035badd0e73904454b6984845f39c5e5286767edb364aed8759018d62ad.scope"
      },
      {
        "cgroup-id": 9269,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod363b6582_3521_4f74_882a_3e9ad3e6f17c.slice/cri-containerd-948292dd60436416969d500e1529bfee657641f3886d0751f494ce6e87aca176.scope"
      }
    ],
    "ips": [
      "10.101.0.213"
    ],
    "name": "clustermesh-apiserver-7c88dd7598-m48qf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10025,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2e1e5b1a_9a6d_474e_8df9_c55cf67fb556.slice/cri-containerd-4b9f7af7067d2b10d14c881dd83c9f242dd033166e1e3a3470a790adc1b13871.scope"
      },
      {
        "cgroup-id": 10109,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2e1e5b1a_9a6d_474e_8df9_c55cf67fb556.slice/cri-containerd-658117371ea3903d9137fbae1b1e8c92b26e2f8f9e48eb2f663495e96e853664.scope"
      }
    ],
    "ips": [
      "10.101.0.56"
    ],
    "name": "echo-same-node-86d9cc975c-mjl9r",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7709,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47ac24e0_50e9_4a34_9e8c_fa41253eda73.slice/cri-containerd-bea6709aa6e2a51e9eae03492ad02bb82462824c3710942150d9db27a940a2b6.scope"
      }
    ],
    "ips": [
      "10.101.0.179"
    ],
    "name": "coredns-cc6ccd49c-q7b8b",
    "namespace": "kube-system"
  }
]

