USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3326  0.0  0.4 1240432 16548 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3347  0.0  0.0   6408  1636 ?        R    12:54   0:00  \_ ps auxfw
root        3348  0.0  0.0   3852  1292 ?        R    12:54   0:00  \_ bash -c hostname
root        3312  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  4.3  7.4 1539060 291176 ?      Ssl  12:31   0:58 cilium-agent --config-dir=/tmp/cilium/config-map
root         392  0.2  0.2 1229744 8928 ?        Sl   12:32   0:03 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
