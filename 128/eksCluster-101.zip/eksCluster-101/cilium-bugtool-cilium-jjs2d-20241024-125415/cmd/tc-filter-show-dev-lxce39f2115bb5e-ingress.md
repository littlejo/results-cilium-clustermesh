filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxce39f2115bb5e direct-action not_in_hw id 3343 tag 047629888333cab1 jited 
