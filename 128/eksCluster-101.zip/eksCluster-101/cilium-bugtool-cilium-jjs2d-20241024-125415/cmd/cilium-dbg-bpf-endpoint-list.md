IP ADDRESS         LOCAL ENDPOINT INFO
10.101.0.213:0     id=2998  sec_id=6711080 flags=0x0000 ifindex=18  mac=CA:5E:AB:25:6F:8D nodemac=AA:FB:A9:DF:68:57   
10.101.0.56:0      id=1589  sec_id=6694331 flags=0x0000 ifindex=22  mac=6A:48:B1:79:D3:0E nodemac=1A:D7:E9:5D:47:85   
172.31.205.43:0    (localhost)                                                                                        
10.101.0.133:0     id=2919  sec_id=6716542 flags=0x0000 ifindex=12  mac=9A:81:96:F0:A5:E6 nodemac=0A:70:9F:9B:DD:96   
10.101.0.219:0     (localhost)                                                                                        
10.101.0.134:0     id=2981  sec_id=4     flags=0x0000 ifindex=10  mac=C6:0F:42:88:2D:60 nodemac=AA:B1:A4:89:BC:66     
10.101.0.155:0     id=516   sec_id=6704587 flags=0x0000 ifindex=24  mac=D6:04:20:F3:06:3B nodemac=8A:63:67:AF:83:01   
10.101.0.179:0     id=3296  sec_id=6716542 flags=0x0000 ifindex=14  mac=4E:AE:93:47:F3:13 nodemac=52:CE:C1:C4:C6:49   
10.101.0.170:0     id=2803  sec_id=6730983 flags=0x0000 ifindex=20  mac=82:51:3D:49:80:07 nodemac=8E:12:E8:C7:E3:B3   
172.31.245.185:0   (localhost)                                                                                        
