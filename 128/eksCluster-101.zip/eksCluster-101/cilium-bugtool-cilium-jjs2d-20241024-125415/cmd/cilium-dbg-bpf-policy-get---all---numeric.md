Endpoint ID: 516
Path: /sys/fs/bpf/tc/globals/cilium_policy_00516

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1589
Path: /sys/fs/bpf/tc/globals/cilium_policy_01589

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378953   4425      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2099
Path: /sys/fs/bpf/tc/globals/cilium_policy_02099

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2803
Path: /sys/fs/bpf/tc/globals/cilium_policy_02803

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2919
Path: /sys/fs/bpf/tc/globals/cilium_policy_02919

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4026     41        0        
Allow    Ingress     1          ANY          NONE         disabled    130636   1500      0        
Allow    Egress      0          ANY          NONE         disabled    18458    202       0        


Endpoint ID: 2981
Path: /sys/fs/bpf/tc/globals/cilium_policy_02981

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6247792   77114     0        
Allow    Ingress     1          ANY          NONE         disabled    64990     784       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2998
Path: /sys/fs/bpf/tc/globals/cilium_policy_02998

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6103157   60929     0        
Allow    Ingress     1          ANY          NONE         disabled    5222676   55069     0        
Allow    Egress      0          ANY          NONE         disabled    6404323   63721     0        


Endpoint ID: 3296
Path: /sys/fs/bpf/tc/globals/cilium_policy_03296

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1870     19        0        
Allow    Ingress     1          ANY          NONE         disabled    129646   1485      0        
Allow    Egress      0          ANY          NONE         disabled    17832    197       0        


