Node 0, zone      DMA      2      3      6     26     16      8      6      3      2      4     47 
Node 0, zone   Normal    230      4      3     10     12     13      3      1      1      2      8 
