alloc: 120.33MB (126175144 bytes)
total-alloc: 3.12GB (3352456592 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 75716196
frees: 74455746
heap-alloc: 120.33MB (126175144 bytes)
heap-sys: 172.70MB (181092352 bytes)
heap-idle: 30.56MB (32047104 bytes)
heap-in-use: 142.14MB (149045248 bytes)
heap-released: 6.33MB (6635520 bytes)
heap-objects: 1260450
stack-in-use: 35.25MB (36962304 bytes)
stack-sys: 35.25MB (36962304 bytes)
stack-mspan-inuse: 2.33MB (2439840 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1000.02KB (1024025 bytes)
gc-sys: 5.53MB (5799032 bytes)
next-gc: when heap-alloc >= 158.25MB (165935112 bytes)
last-gc: 2024-10-24 12:54:16.514671544 +0000 UTC
gc-pause-total: 19.384034ms
gc-pause: 93775
gc-pause-end: 1729774456514671544
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0006288986230768921
enable-gc: true
debug-gc: false
