1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:78:06:c3:1d:3d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.205.43/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3533sec preferred_lft 3533sec
    inet6 fe80::878:6ff:fec3:1d3d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:21:ef:ac:30:cb brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.245.185/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::821:efff:feac:30cb/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:af:11:93:9b:24 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::64af:11ff:fe93:9b24/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:65:e2:83:79:3b brd ff:ff:ff:ff:ff:ff
    inet 10.101.0.219/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a465:e2ff:fe83:793b/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ba:23:83:a4:0d:39 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b823:83ff:fea4:d39/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:b1:a4:89:bc:66 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a8b1:a4ff:fe89:bc66/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc399f55d768bf@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:70:9f:9b:dd:96 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::870:9fff:fe9b:dd96/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcdc4ccf6a0789@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:ce:c1:c4:c6:49 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::50ce:c1ff:fec4:c649/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc0b7992004aa2@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:fb:a9:df:68:57 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a8fb:a9ff:fedf:6857/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc8f80227d3126@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:12:e8:c7:e3:b3 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::8c12:e8ff:fec7:e3b3/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc3d4495fadfb6@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:d7:e9:5d:47:85 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::18d7:e9ff:fe5d:4785/64 scope link 
       valid_lft forever preferred_lft forever
24: lxce39f2115bb5e@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:63:67:af:83:01 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::8863:67ff:feaf:8301/64 scope link 
       valid_lft forever preferred_lft forever
