key: 04 02 00 00  value: 07 0d 00 00
key: 35 06 00 00  value: de 0c 00 00
key: f3 0a 00 00  value: 0c 0d 00 00
key: 67 0b 00 00  value: 16 02 00 00
key: a5 0b 00 00  value: 11 02 00 00
key: b6 0b 00 00  value: 71 02 00 00
key: e0 0c 00 00  value: f8 01 00 00
Found 7 elements
