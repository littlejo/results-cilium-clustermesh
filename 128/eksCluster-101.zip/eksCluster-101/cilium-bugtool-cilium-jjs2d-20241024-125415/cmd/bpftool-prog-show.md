29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:02+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:23:02+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:23:03+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:23:03+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:23:03+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:03+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:23:07+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:23:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:23:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:32:08+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
479: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:32:08+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 125
480: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:32:08+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
481: sched_cls  name tail_handle_ipv4  tag 7a365e5bd385d6b3  gpl
	loaded_at 2024-10-24T12:32:08+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
504: sched_cls  name handle_policy  tag 98a02b566f7d4af2  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 153
505: sched_cls  name tail_ipv4_to_endpoint  tag e5a59f837b2a9d1a  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 154
506: sched_cls  name tail_handle_ipv4_cont  tag a3a8a6e5961017f4  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 155
507: sched_cls  name __send_drop_notify  tag 5c04cb82d849aee2  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 156
508: sched_cls  name tail_ipv4_ct_egress  tag 565576be0e275a02  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 157
509: sched_cls  name tail_handle_arp  tag b241f051430efba2  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 158
510: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 159
511: sched_cls  name cil_from_container  tag ac3072ec7f97e38c  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,76
	btf_id 160
512: sched_cls  name tail_handle_ipv4  tag ef463e46ac73b95d  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 161
514: sched_cls  name tail_ipv4_ct_ingress  tag 4ae7d36e2e6e1cd6  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 163
516: sched_cls  name __send_drop_notify  tag 46dadb44af850454  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 166
517: sched_cls  name tail_handle_ipv4_cont  tag a193eb46b45cb834  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,110,41,100,82,83,39,76,74,77,109,40,37,38,81
	btf_id 167
518: sched_cls  name tail_ipv4_ct_ingress  tag 5bc7e0fd8a1cf312  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 168
519: sched_cls  name tail_handle_arp  tag 09696bfeace41bfa  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 169
520: sched_cls  name tail_ipv4_to_endpoint  tag ad27c2d6f0704dcf  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,110,41,82,83,80,100,39,109,40,37,38
	btf_id 170
521: sched_cls  name cil_from_container  tag 1e096ad0b9015b00  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 109,76
	btf_id 171
522: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 172
523: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
524: sched_cls  name tail_handle_ipv4  tag 9603d216880df19e  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 173
527: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
528: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 174
529: sched_cls  name handle_policy  tag 735b1a6d33c69d3f  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,109,82,83,110,41,80,100,39,84,75,40,37,38
	btf_id 175
530: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 177
531: sched_cls  name tail_handle_ipv4_cont  tag dc65b0cdd7d6b858  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,101,82,83,39,76,74,77,112,40,37,38,81
	btf_id 178
532: sched_cls  name tail_ipv4_ct_ingress  tag f9cea23183a53dd5  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 179
533: sched_cls  name cil_from_container  tag edbc4cb0e1fef13f  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 180
534: sched_cls  name handle_policy  tag 2362c42fcbac7f86  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,101,39,84,75,40,37,38
	btf_id 181
535: sched_cls  name tail_handle_ipv4  tag ac507eb341e5cc74  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 182
536: sched_cls  name tail_ipv4_ct_egress  tag 565576be0e275a02  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 183
537: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
540: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
541: sched_cls  name tail_ipv4_to_endpoint  tag 37156a8c0737d20e  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,101,39,112,40,37,38
	btf_id 184
542: sched_cls  name tail_handle_arp  tag e50e4e8993cbcc86  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 185
543: sched_cls  name __send_drop_notify  tag ac2270008e7a8ab1  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 186
545: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
548: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
549: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
552: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
554: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 190
555: sched_cls  name __send_drop_notify  tag 2f20e51b790b7fec  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 191
556: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 192
558: sched_cls  name tail_handle_ipv4_from_host  tag 66eb0cb51b89a5cb  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 194
559: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 195
561: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 198
562: sched_cls  name __send_drop_notify  tag 2f20e51b790b7fec  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
563: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 200
565: sched_cls  name tail_handle_ipv4_from_host  tag 66eb0cb51b89a5cb  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 202
570: sched_cls  name __send_drop_notify  tag 2f20e51b790b7fec  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 208
571: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 209
572: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 210
573: sched_cls  name tail_handle_ipv4_from_host  tag 66eb0cb51b89a5cb  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 211
574: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 213
575: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 214
576: sched_cls  name tail_handle_ipv4_from_host  tag 66eb0cb51b89a5cb  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 215
580: sched_cls  name __send_drop_notify  tag 2f20e51b790b7fec  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 219
620: sched_cls  name tail_ipv4_ct_egress  tag 7904aee5ea669c40  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 233
621: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 234
622: sched_cls  name cil_from_container  tag fa708ff25c21104d  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 235
624: sched_cls  name tail_handle_ipv4_cont  tag 3643ae3c49e87822  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 237
625: sched_cls  name handle_policy  tag 987ea256325a359a  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 238
626: sched_cls  name tail_handle_arp  tag 62c8ba8ee864489a  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 239
627: sched_cls  name tail_ipv4_to_endpoint  tag c1327124c386f98b  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 240
628: sched_cls  name tail_handle_ipv4  tag 42e6857499638054  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 241
629: sched_cls  name tail_ipv4_ct_ingress  tag 4aa8e368b006232a  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 242
630: sched_cls  name __send_drop_notify  tag 2726b24d50263c0b  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 243
631: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
634: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
647: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
650: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
655: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
658: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
692: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
695: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
696: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
699: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
700: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
703: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
704: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
707: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
708: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
711: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
712: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
715: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
716: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
719: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3272: sched_cls  name cil_from_container  tag 6d72d3bda30b9ba3  gpl
	loaded_at 2024-10-24T12:51:13+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 626,76
	btf_id 3065
3273: sched_cls  name tail_handle_ipv4_cont  tag 72e12a0542aa82e7  gpl
	loaded_at 2024-10-24T12:51:13+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,625,41,148,82,83,39,76,74,77,626,40,37,38,81
	btf_id 3066
3274: sched_cls  name tail_ipv4_ct_ingress  tag 87eb846fdaa8f31a  gpl
	loaded_at 2024-10-24T12:51:13+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,626,82,83,625,84
	btf_id 3069
3275: sched_cls  name tail_ipv4_ct_egress  tag bb431a96065619f2  gpl
	loaded_at 2024-10-24T12:51:13+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,626,82,83,625,84
	btf_id 3070
3277: sched_cls  name tail_handle_ipv4  tag cf7980d486bee3d3  gpl
	loaded_at 2024-10-24T12:51:13+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,626
	btf_id 3071
3280: sched_cls  name tail_ipv4_to_endpoint  tag 797c3effa33b5d93  gpl
	loaded_at 2024-10-24T12:51:13+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,625,41,82,83,80,148,39,626,40,37,38
	btf_id 3073
3283: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:13+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,626
	btf_id 3076
3285: sched_cls  name __send_drop_notify  tag ee99302af08bf216  gpl
	loaded_at 2024-10-24T12:51:13+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3079
3294: sched_cls  name handle_policy  tag e2d1c3334718a21c  gpl
	loaded_at 2024-10-24T12:51:13+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,626,82,83,625,41,80,148,39,84,75,40,37,38
	btf_id 3081
3295: sched_cls  name tail_handle_arp  tag 826492097e7bf9a6  gpl
	loaded_at 2024-10-24T12:51:13+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,626
	btf_id 3091
3327: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,635
	btf_id 3125
3328: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,637
	btf_id 3128
3329: sched_cls  name tail_ipv4_ct_ingress  tag b00e21f88cb932af  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3129
3330: sched_cls  name tail_handle_ipv4  tag cca8cb402035178a  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,637
	btf_id 3130
3332: sched_cls  name tail_handle_arp  tag 0cba5b944d407050  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,637
	btf_id 3132
3333: sched_cls  name tail_ipv4_to_endpoint  tag b7141bbdcf7308d7  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,636,41,82,83,80,145,39,635,40,37,38
	btf_id 3126
3334: sched_cls  name cil_from_container  tag 6342346f78f3bae5  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 635,76
	btf_id 3134
3335: sched_cls  name handle_policy  tag 2aa724f360e0e444  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,637,82,83,638,41,80,151,39,84,75,40,37,38
	btf_id 3133
3336: sched_cls  name tail_ipv4_ct_egress  tag 83c4010bed16708c  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3136
3337: sched_cls  name tail_ipv4_ct_ingress  tag dd53773a11a3ccd5  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,635,82,83,636,84
	btf_id 3135
3338: sched_cls  name tail_ipv4_ct_egress  tag b8a02f22a50ba437  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,635,82,83,636,84
	btf_id 3137
3339: sched_cls  name tail_handle_arp  tag b7ea7b63699d95ad  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,635
	btf_id 3139
3340: sched_cls  name handle_policy  tag 4681fa581907d97f  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,635,82,83,636,41,80,145,39,84,75,40,37,38
	btf_id 3140
3341: sched_cls  name tail_ipv4_to_endpoint  tag e26db624086102fe  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,638,41,82,83,80,151,39,637,40,37,38
	btf_id 3138
3342: sched_cls  name __send_drop_notify  tag 9e141cdc14136357  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3141
3343: sched_cls  name cil_from_container  tag 047629888333cab1  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 637,76
	btf_id 3142
3344: sched_cls  name tail_handle_ipv4_cont  tag 02b6163248c2822b  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,638,41,151,82,83,39,76,74,77,637,40,37,38,81
	btf_id 3143
3345: sched_cls  name tail_handle_ipv4_cont  tag 3b2d200e8d926478  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,636,41,145,82,83,39,76,74,77,635,40,37,38,81
	btf_id 3144
3347: sched_cls  name tail_handle_ipv4  tag a122d62eca077255  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,635
	btf_id 3146
3348: sched_cls  name __send_drop_notify  tag 81183ec890feef53  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3147
