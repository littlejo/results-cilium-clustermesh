xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 572
ens6(5) clsact/ingress cil_from_netdev-ens6 id 575
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 561
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 554
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 521
lxc399f55d768bf(12) clsact/ingress cil_from_container-lxc399f55d768bf id 533
lxcdc4ccf6a0789(14) clsact/ingress cil_from_container-lxcdc4ccf6a0789 id 511
lxc0b7992004aa2(18) clsact/ingress cil_from_container-lxc0b7992004aa2 id 622
lxc8f80227d3126(20) clsact/ingress cil_from_container-lxc8f80227d3126 id 3334
lxc3d4495fadfb6(22) clsact/ingress cil_from_container-lxc3d4495fadfb6 id 3272
lxce39f2115bb5e(24) clsact/ingress cil_from_container-lxce39f2115bb5e id 3343

flow_dissector:

netfilter:

