top - 12:54:16 up 31 min,  0 users,  load average: 0.21, 0.39, 0.27
Tasks:   8 total,   2 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 43.3 us, 43.3 sy,  0.0 ni, 10.0 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   3836.2 total,    309.3 free,   1049.8 used,   2477.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2605.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3381 root      20   0 1244340  21324  13636 S  26.7   0.5   0:00.04 hubble
      1 root      20   0 1539060 291176  77824 S   6.7   7.4   0:58.59 cilium-+
    392 root      20   0 1229744   8928   2924 S   0.0   0.2   0:03.65 cilium-+
   3312 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3326 root      20   0 1240432  16804  11356 S   0.0   0.4   0:00.02 cilium-+
   3364 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
   3369 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
   3403 root      20   0    4128    752    656 R   0.0   0.0   0:00.00 ip
