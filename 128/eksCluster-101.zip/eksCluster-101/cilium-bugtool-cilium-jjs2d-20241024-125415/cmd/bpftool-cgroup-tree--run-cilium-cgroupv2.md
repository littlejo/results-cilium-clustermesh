CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4cafa50_8b03_42e9_bf72_627c355fbadb.slice/cri-containerd-d9f9864f7cd1b18b2532257c783a8c33ed5340738262ca36ae0094d7e1378613.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4cafa50_8b03_42e9_bf72_627c355fbadb.slice/cri-containerd-174d21b61ba7823c40a5f5e3b37810f795a2d7b6ca74925cac05002b102cf485.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod40f041fc_69a7_42cc_b9db_4b33ba473408.slice/cri-containerd-b04649255137c5f24abdb779f6034a412440d24ec69601b4259a845f3defdfe9.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod40f041fc_69a7_42cc_b9db_4b33ba473408.slice/cri-containerd-c4792aabfc0a11fbd1437ff537e316ec166edb854167f628c42859f7ad7db9c2.scope
    527      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4766f14e_6ca7_4c08_88c7_9e1b34232479.slice/cri-containerd-3d34510bc2efde56df88f91aeab5f7dfa8f2336d513af20a27483f83d51c3d50.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4766f14e_6ca7_4c08_88c7_9e1b34232479.slice/cri-containerd-81127382ca0cedc4bcdb73f19bb0e1a92554d63959dcfedb334ccc9f6f386c3b.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47ac24e0_50e9_4a34_9e8c_fa41253eda73.slice/cri-containerd-bea6709aa6e2a51e9eae03492ad02bb82462824c3710942150d9db27a940a2b6.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47ac24e0_50e9_4a34_9e8c_fa41253eda73.slice/cri-containerd-e3f3439574f0530c30f18ed5491691539f2509d965aa6c68b47e784371732af5.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75904cfc_9858_4ff1_9120_29351bf6ebdc.slice/cri-containerd-b43f6ee677e0aedfaeb577e4c5cc88d1ed490c2a5b1bbfa1324d369cda57da37.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75904cfc_9858_4ff1_9120_29351bf6ebdc.slice/cri-containerd-3a87b23d9ed993a9303a64768d9edbccb57b37cade06fdbceaab646e0210ecbb.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod363b6582_3521_4f74_882a_3e9ad3e6f17c.slice/cri-containerd-67bcc035badd0e73904454b6984845f39c5e5286767edb364aed8759018d62ad.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod363b6582_3521_4f74_882a_3e9ad3e6f17c.slice/cri-containerd-122eea153789efcb4f9dc2e3d15f2c8b059741078774c536353ddcda24c2078b.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod363b6582_3521_4f74_882a_3e9ad3e6f17c.slice/cri-containerd-948292dd60436416969d500e1529bfee657641f3886d0751f494ce6e87aca176.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod363b6582_3521_4f74_882a_3e9ad3e6f17c.slice/cri-containerd-ada49a7270b56ea3b476db69ae5d8dfc95f82a3f7b174d9bc9e34b072ce45604.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod107d6a1a_62a9_42d7_8491_4e2cf0af7161.slice/cri-containerd-cb7708b8f01e978027df03021434e7714cbbb1342a3246376bae0829e849d5fa.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod107d6a1a_62a9_42d7_8491_4e2cf0af7161.slice/cri-containerd-e41fa5a3da98f4a7d045b88cefa60cb174b23cf7822db62c7730cef5094a3807.scope
    695      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8bc0d853_a3d7_4be7_9f4f_e1bfd8e1c485.slice/cri-containerd-87692a31ef618846ac36ba142e6dddc93a6fe8f48ab0ea366dfefbe50ab5ded9.scope
    699      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8bc0d853_a3d7_4be7_9f4f_e1bfd8e1c485.slice/cri-containerd-31378fbcf7f4c24c9e1b1608054de9e612a4ec31ed440e047baa31971f9deb53.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2e1e5b1a_9a6d_474e_8df9_c55cf67fb556.slice/cri-containerd-4b9f7af7067d2b10d14c881dd83c9f242dd033166e1e3a3470a790adc1b13871.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2e1e5b1a_9a6d_474e_8df9_c55cf67fb556.slice/cri-containerd-996f04e6d21caef5478b6aecaf8b6f6ad438ac29d8849ad361bcb30eb75ad090.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2e1e5b1a_9a6d_474e_8df9_c55cf67fb556.slice/cri-containerd-658117371ea3903d9137fbae1b1e8c92b26e2f8f9e48eb2f663495e96e853664.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5ad7be5c_d64e_4171_8876_f50914beb566.slice/cri-containerd-64c6d809b223dc57ec44175a9748a8cca8a3e5b294c2ff2a2436631ddb22d8db.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5ad7be5c_d64e_4171_8876_f50914beb566.slice/cri-containerd-09fca0d16b55dc50135011a5ef53e6e7c78837ab0ecca04fe336d939a0dce745.scope
    103      cgroup_device   multi                                          
