USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3293  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root        3278  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3277  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3255  0.0  0.4 1240432 16128 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3307  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root           1  4.3  7.5 1539132 294640 ?      Ssl  12:27   1:09 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.2  0.2 1229744 8956 ?        Sl   12:27   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
