alloc: 141.17MB (148029384 bytes)
total-alloc: 3.30GB (3540001608 bytes)
sys: 227.39MB (238437716 bytes)
lookups: 0
mallocs: 78372402
frees: 76886584
heap-alloc: 141.17MB (148029384 bytes)
heap-sys: 178.95MB (187645952 bytes)
heap-idle: 14.01MB (14688256 bytes)
heap-in-use: 164.95MB (172957696 bytes)
heap-released: 6.06MB (6356992 bytes)
heap-objects: 1485818
stack-in-use: 37.00MB (38797312 bytes)
stack-sys: 37.00MB (38797312 bytes)
stack-mspan-inuse: 2.58MB (2703200 bytes)
stack-mspan-sys: 2.89MB (3035520 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 928.95KB (951249 bytes)
gc-sys: 5.52MB (5784624 bytes)
next-gc: when heap-alloc >= 148.37MB (155578376 bytes)
last-gc: 2024-10-24 12:54:03.986807617 +0000 UTC
gc-pause-total: 25.28403ms
gc-pause: 81880
gc-pause-end: 1729774443986807617
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0005843096246431684
enable-gc: true
debug-gc: false
