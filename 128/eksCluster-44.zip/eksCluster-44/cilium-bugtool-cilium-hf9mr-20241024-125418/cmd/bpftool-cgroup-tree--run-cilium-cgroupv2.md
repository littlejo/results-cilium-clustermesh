CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda9dea1b4_de67_41ae_a9a1_5816628e217d.slice/cri-containerd-1a00a77984c7313e1470347df76706df5ee94587c783ac27948bbbe40082ab2b.scope
    586      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda9dea1b4_de67_41ae_a9a1_5816628e217d.slice/cri-containerd-13005da7116614a0e6e103f03a171b6938de3072f379764744dd53ac1ee0b5dc.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4eb9e625_dbcf_449c_9e60_dbd02316cdf0.slice/cri-containerd-44c93aef13135c86c23c6d5e9523f68998bf94029df46ac3a92bf89c4097b8a8.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4eb9e625_dbcf_449c_9e60_dbd02316cdf0.slice/cri-containerd-5c4e914170d9893b4a9bb9374995f4c6f09892371ceac6038f70334a395789d9.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb855cdc1_9003_4770_bb91_b9f6f45b672a.slice/cri-containerd-9ec88262fede800dcd4c3c32cbaccd9168b5c491dc1e5230b4ed99562a24a235.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb855cdc1_9003_4770_bb91_b9f6f45b672a.slice/cri-containerd-7abc6d4be7417be2073af80e56413ceeace2fc433db751799771023fabd9fe54.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod44f1cc1c_33d7_4f84_a88a_ede0c3f9d51f.slice/cri-containerd-ae1e52e1d2272157033cab794c34095004d7d2860521587835d4b13526b0cee4.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod44f1cc1c_33d7_4f84_a88a_ede0c3f9d51f.slice/cri-containerd-39bdb9e1357877fa0399af73b74a2e0c03d7a04fa1c7dfc04267dab4e0ba6ee7.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6915cda2_248c_408c_ae96_23e2c1ed54db.slice/cri-containerd-e4da545e0f3c36dfa641b085a8960c8e751400f7a9b12ddd40510c0b7fd1e538.scope
    727      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6915cda2_248c_408c_ae96_23e2c1ed54db.slice/cri-containerd-fe349f624501fe3ad66ce778c89310a6a9730067cea30e5e4e77ffd70bca47c2.scope
    693      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29dd4b74_f827_4fa5_9634_8759eb32da43.slice/cri-containerd-dfa4374ad4ca4f242c632b0be5996125774d41005b25995547c2de049b841e40.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29dd4b74_f827_4fa5_9634_8759eb32da43.slice/cri-containerd-86a6a061c693f17a7b258bddd02e099c48dce1cca0fe19b75445d0ee9408cbae.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda439c8ea_cef2_42d3_ae91_79a1aa811fe3.slice/cri-containerd-3440236cafe0e2b3aff7753d5ee610a44c6745a430b49d0135078241e767f04a.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda439c8ea_cef2_42d3_ae91_79a1aa811fe3.slice/cri-containerd-730cf9e88244232cc2b02c9ee73ef972c558fb87201336f7a7e0de8491f14bc5.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f0a3b5b_cac8_41b9_98ff_64b5231e148f.slice/cri-containerd-5ca3a8df22be5c434b6eb7263dafa8be9420a7274c03184cdd49e207e609bf62.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f0a3b5b_cac8_41b9_98ff_64b5231e148f.slice/cri-containerd-f673fc99ed27b375170e41df94490c97f487d765af8d5aa0a9be7c3eec798be5.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f0a3b5b_cac8_41b9_98ff_64b5231e148f.slice/cri-containerd-166091c4162b7588f57fbf49d80d5e09b49ec798f5828bc1d709d18ba62767bf.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f0a3b5b_cac8_41b9_98ff_64b5231e148f.slice/cri-containerd-f07563ca9fb84cdf587773e058945535317605d78f406acd0ea101cd8d423a06.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod814f4794_e748_4b26_a2b3_2475dace7d81.slice/cri-containerd-6dc3f914e63b6d18690813900f4c819efe16fd7da35e03d4dd028c61ea8cf83e.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod814f4794_e748_4b26_a2b3_2475dace7d81.slice/cri-containerd-f581ca2371faaa62bfe32fc0d5cdbdd90abe8abf21847b6e62b741d8384791ba.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod814f4794_e748_4b26_a2b3_2475dace7d81.slice/cri-containerd-a964a4d9ab4c640ce21f26cfbff94a1c859e9fb8dafbb06435f70d223a329b34.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb197de2_c0ab_45ec_8b8a_87f96136cc12.slice/cri-containerd-dfdc3d2570014990221bf6ee6a561d0f9bfc12b5b9b06e339855fc73e5e6ef43.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb197de2_c0ab_45ec_8b8a_87f96136cc12.slice/cri-containerd-bc78370e61c918000350bb740a8d4a3c74ab87ced1213c8534673b01f620ea50.scope
    90       cgroup_device   multi                                          
