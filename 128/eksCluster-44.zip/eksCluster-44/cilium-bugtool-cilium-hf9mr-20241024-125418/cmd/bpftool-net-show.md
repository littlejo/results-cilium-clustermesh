xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 562
ens6(5) clsact/ingress cil_from_netdev-ens6 id 571
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 556
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 545
cilium_host(7) clsact/egress cil_from_host-cilium_host id 549
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 588
lxc0c74789326d7(12) clsact/ingress cil_from_container-lxc0c74789326d7 id 535
lxcd3a7f1c4719f(14) clsact/ingress cil_from_container-lxcd3a7f1c4719f id 541
lxc3a51e605b2a5(18) clsact/ingress cil_from_container-lxc3a51e605b2a5 id 646
lxcd25b4156c50e(20) clsact/ingress cil_from_container-lxcd25b4156c50e id 3358
lxc4f38a23970e2(22) clsact/ingress cil_from_container-lxc4f38a23970e2 id 3366
lxcb6cd233c0332(24) clsact/ingress cil_from_container-lxcb6cd233c0332 id 3302

flow_dissector:

netfilter:

