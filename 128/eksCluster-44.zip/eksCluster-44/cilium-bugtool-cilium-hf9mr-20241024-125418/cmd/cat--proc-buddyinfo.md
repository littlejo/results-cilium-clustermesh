Node 0, zone      DMA    120    104     33      8      1      1      3      2      1      4     38 
Node 0, zone   Normal    687    160     16      5      9     10      3      2      2      2      7 
