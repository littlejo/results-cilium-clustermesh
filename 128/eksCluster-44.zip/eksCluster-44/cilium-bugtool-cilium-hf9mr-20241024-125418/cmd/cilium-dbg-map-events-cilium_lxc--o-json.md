{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:29.870Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:29.909Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.465Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.467Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.511Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.520Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.551Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.803Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.821Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.899Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.923Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.956Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.508Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.527Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.569Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.570Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.608Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.811Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.825Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.872Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.884Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.923Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.460Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.468Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.502Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.515Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.560Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.569Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.600Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.833Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.837Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.901Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.923Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.008Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.551Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.554Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.587Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.609Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.634Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.666Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.667Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.917Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.925Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.977Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.004Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.031Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.448Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.448Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.498Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.521Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.551Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.729Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.763Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.786Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.822Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.839Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.223Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.317Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.346Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.364Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.406Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.409Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.637Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.639Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.688Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.698Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.736Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.131Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.169Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.169Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.223Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.225Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.258Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.486Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.491Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.534Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.562Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.573Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.018Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.024Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.092Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.150Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.168Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.369Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.387Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.436Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.478Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.490Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.841Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.877Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.881Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.932Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.933Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.970Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.204Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.208Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.257Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.259Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.310Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.611Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.643Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.650Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.679Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.712Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.740Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.051Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.072Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.094Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.113Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.428Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.437Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.485Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.496Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.525Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.736Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.775Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.781Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.789Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.792Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.470Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.474Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.526Z",
  "value": "id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.528Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.560Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.808Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.810Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.505Z",
  "value": "id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.513Z",
  "value": "id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA"
}

