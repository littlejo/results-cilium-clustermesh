Total: 579
TCP:   3735 (estab 302, closed 3414, orphaned 0, timewait 2955)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  321       310       11       
INET	  331       316       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                            127.0.0.1:38371      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:31179 sk:101c fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.160.162%ens5:68         0.0.0.0:*    uid:192 ino:106537 sk:101d cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:31865 sk:101e cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15421 sk:101f cgroup:unreachable:e8e <->                                    
UNCONN 0      0      [fe80::4e8:cbff:fe0c:9fb5]%ens5:546           [::]:*    uid:192 ino:15594 sk:1020 cgroup:unreachable:bd0 v6only:1 <->                   
UNCONN 0      0                                 [::]:8472          [::]:*    ino:31864 sk:1021 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15422 sk:1022 cgroup:unreachable:e8e v6only:1 <->                           
