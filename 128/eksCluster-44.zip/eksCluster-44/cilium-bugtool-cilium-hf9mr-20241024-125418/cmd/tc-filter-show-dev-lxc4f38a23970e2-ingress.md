filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc4f38a23970e2 direct-action not_in_hw id 3366 tag 158122f40d4e7079 jited 
