Endpoint ID: 326
Path: /sys/fs/bpf/tc/globals/cilium_policy_00326

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    216885   1957      0        
Allow    Ingress     1          ANY          NONE         disabled    153932   1768      0        
Allow    Egress      0          ANY          NONE         disabled    67877    674       0        


Endpoint ID: 623
Path: /sys/fs/bpf/tc/globals/cilium_policy_00623

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 888
Path: /sys/fs/bpf/tc/globals/cilium_policy_00888

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    380071   4435      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1073
Path: /sys/fs/bpf/tc/globals/cilium_policy_01073

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6226800   76965     0        
Allow    Ingress     1          ANY          NONE         disabled    68852     832       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1981
Path: /sys/fs/bpf/tc/globals/cilium_policy_01981

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    212025   1915      0        
Allow    Ingress     1          ANY          NONE         disabled    151846   1746      0        
Allow    Egress      0          ANY          NONE         disabled    66534    659       0        


Endpoint ID: 2977
Path: /sys/fs/bpf/tc/globals/cilium_policy_02977

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3079
Path: /sys/fs/bpf/tc/globals/cilium_policy_03079

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 4023
Path: /sys/fs/bpf/tc/globals/cilium_policy_04023

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6048142   61429     0        
Allow    Ingress     1          ANY          NONE         disabled    6242427   64667     0        
Allow    Egress      0          ANY          NONE         disabled    7673398   74958     0        


