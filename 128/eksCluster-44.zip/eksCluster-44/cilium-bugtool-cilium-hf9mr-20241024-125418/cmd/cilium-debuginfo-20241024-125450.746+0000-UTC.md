# Cilium debug information

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 34093977                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 34093977                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 34093977                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400dc00000 rw-p 00000000 00:00 0 
400dc00000-4010000000 ---p 00000000 00:00 0 
ffff61775000-ffff6198c000 rw-p 00000000 00:00 0 
ffff61990000-ffff61a81000 rw-p 00000000 00:00 0 
ffff61a89000-ffff61baa000 rw-p 00000000 00:00 0 
ffff61baa000-ffff61beb000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff61beb000-ffff61c2c000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff61c2c000-ffff61c2e000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff61c2e000-ffff61c30000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff61c30000-ffff621f7000 rw-p 00000000 00:00 0 
ffff621f7000-ffff622f7000 rw-p 00000000 00:00 0 
ffff622f7000-ffff62308000 rw-p 00000000 00:00 0 
ffff62308000-ffff64308000 rw-p 00000000 00:00 0 
ffff64308000-ffff64388000 ---p 00000000 00:00 0 
ffff64388000-ffff64389000 rw-p 00000000 00:00 0 
ffff64389000-ffff84388000 ---p 00000000 00:00 0 
ffff84388000-ffff84389000 rw-p 00000000 00:00 0 
ffff84389000-ffffa4318000 ---p 00000000 00:00 0 
ffffa4318000-ffffa4319000 rw-p 00000000 00:00 0 
ffffa4319000-ffffa830a000 ---p 00000000 00:00 0 
ffffa830a000-ffffa830b000 rw-p 00000000 00:00 0 
ffffa830b000-ffffa8b08000 ---p 00000000 00:00 0 
ffffa8b08000-ffffa8b09000 rw-p 00000000 00:00 0 
ffffa8b09000-ffffa8c08000 ---p 00000000 00:00 0 
ffffa8c08000-ffffa8c68000 rw-p 00000000 00:00 0 
ffffa8c68000-ffffa8c6a000 r--p 00000000 00:00 0                          [vvar]
ffffa8c6a000-ffffa8c6b000 r-xp 00000000 00:00 0                          [vdso]
ffffd3c02000-ffffd3c23000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=8) {
  (string) (len=9) "10.44.0.2": (string) (len=35) "kube-system/coredns-cc6ccd49c-tvkqv",
  (string) (len=11) "10.44.0.217": (string) (len=35) "kube-system/coredns-cc6ccd49c-mtttl",
  (string) (len=11) "10.44.0.194": (string) (len=36) "cilium-test-1/client-974f6c69d-95n76",
  (string) (len=11) "10.44.0.127": (string) (len=49) "kube-system/clustermesh-apiserver-6bd68d548-rlk6p",
  (string) (len=10) "10.44.0.92": (string) (len=37) "cilium-test-1/client2-57cf4468f-4sddm",
  (string) (len=11) "10.44.0.161": (string) (len=45) "cilium-test-1/echo-same-node-86d9cc975c-frhdd",
  (string) (len=11) "10.44.0.216": (string) (len=6) "router",
  (string) (len=11) "10.44.0.197": (string) (len=6) "health"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.160.162": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40022ea630)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4000179f20,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4000179f20,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=6) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4000e33ad0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4000e33b80)(frontends:[10.100.92.155]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4000e33c30)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4002a8f4a0)(frontends:[]/ports=[etcd-metrics apiserv-metrics kvmesh-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4002a8f550)(frontends:[10.100.218.90]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.Service)(0x4003270f20)(frontends:[10.100.140.42]/ports=[http]/selector=map[name:echo-same-node])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=5) {
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.EndpointSlices)(0x40015d44d0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-pl4kx": (*k8s.Endpoints)(0x4003e0add0)(10.44.0.161:8080/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40019943b0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002177450)(172.31.185.90:443/TCP,172.31.225.125:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40019943b8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-l4zxv": (*k8s.Endpoints)(0x4002c6e340)(172.31.160.162:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40019943c0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-blchw": (*k8s.Endpoints)(0x400229b6c0)(10.44.0.217:53/TCP[eu-west-3a],10.44.0.217:53/UDP[eu-west-3a],10.44.0.217:9153/TCP[eu-west-3a],10.44.0.2:53/TCP[eu-west-3a],10.44.0.2:53/UDP[eu-west-3a],10.44.0.2:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4000835830)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-rczxp": (*k8s.Endpoints)(0x4008919520)(10.44.0.127:2379/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x400249a770)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4002691720)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400b3f0378
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40026a8600,
  gcExited: (chan struct {}) 0x40026a8660,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x400241fc00)({
     ObserverVec: (*prometheus.HistogramVec)(0x40012faa80)({
      MetricVec: (*prometheus.MetricVec)(0x4000858630)({
       metricMap: (*prometheus.metricMap)(0x4000858660)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024f0420)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x400241fc80)({
     ObserverVec: (*prometheus.HistogramVec)(0x40012faa88)({
      MetricVec: (*prometheus.MetricVec)(0x40008586c0)({
       metricMap: (*prometheus.metricMap)(0x40008586f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024f0480)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x400241fd00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012faa90)({
      MetricVec: (*prometheus.MetricVec)(0x4000858750)({
       metricMap: (*prometheus.metricMap)(0x40008587b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024f04e0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x400241fd80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012faa98)({
      MetricVec: (*prometheus.MetricVec)(0x4000858810)({
       metricMap: (*prometheus.metricMap)(0x4000858840)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024f0540)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x400241fe00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012faaa0)({
      MetricVec: (*prometheus.MetricVec)(0x40008588a0)({
       metricMap: (*prometheus.metricMap)(0x40008588d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024f05a0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x400241fe80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012faaa8)({
      MetricVec: (*prometheus.MetricVec)(0x4000858960)({
       metricMap: (*prometheus.metricMap)(0x4000858990)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024f0600)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x400241ff00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012faab0)({
      MetricVec: (*prometheus.MetricVec)(0x40008589f0)({
       metricMap: (*prometheus.metricMap)(0x4000858a20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024f0660)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001206000)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012faab8)({
      MetricVec: (*prometheus.MetricVec)(0x4000858a80)({
       metricMap: (*prometheus.metricMap)(0x4000858ab0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024f06c0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001206080)({
     ObserverVec: (*prometheus.HistogramVec)(0x40012faac0)({
      MetricVec: (*prometheus.MetricVec)(0x4000858c00)({
       metricMap: (*prometheus.metricMap)(0x4000858c30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024f0720)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x400249a770)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x400249b8f0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001a88a38)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 296ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   },
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Policy get

```
:
 []
Revision: 129

```


#### Service list

```
ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.185.90:443 (active)     
                                         2 => 172.31.225.125:443 (active)    
2    10.100.92.155:443    ClusterIP      1 => 172.31.160.162:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.44.0.2:53 (active)          
                                         2 => 10.44.0.217:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.44.0.2:9153 (active)        
                                         2 => 10.44.0.217:9153 (active)      
5    10.100.218.90:2379   ClusterIP      1 => 10.44.0.127:2379 (active)      
6    10.100.140.42:8080   ClusterIP      1 => 10.44.0.161:8080 (active)      
```

#### Cilium encryption



#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.44.0.0/24, 
Allocated addresses:
  10.44.0.127 (kube-system/clustermesh-apiserver-6bd68d548-rlk6p)
  10.44.0.161 (cilium-test-1/echo-same-node-86d9cc975c-frhdd)
  10.44.0.194 (cilium-test-1/client-974f6c69d-95n76)
  10.44.0.197 (health)
  10.44.0.2 (kube-system/coredns-cc6ccd49c-tvkqv)
  10.44.0.216 (router)
  10.44.0.217 (kube-system/coredns-cc6ccd49c-mtttl)
  10.44.0.92 (cilium-test-1/client2-57cf4468f-4sddm)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m45s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m45s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m45s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m45s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m45s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m45s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m47s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 13m46s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3e282f6697890f71
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      177/177 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   54s ago        never        0       no error   
  ct-map-pressure                                                    25s ago        never        0       no error   
  daemon-validate-config                                             29s ago        never        0       no error   
  dns-garbage-collector-job                                          57s ago        never        0       no error   
  endpoint-1073-regeneration-recovery                                never          never        0       no error   
  endpoint-1981-regeneration-recovery                                never          never        0       no error   
  endpoint-2977-regeneration-recovery                                never          never        0       no error   
  endpoint-3079-regeneration-recovery                                never          never        0       no error   
  endpoint-326-regeneration-recovery                                 never          never        0       no error   
  endpoint-4023-regeneration-recovery                                never          never        0       no error   
  endpoint-623-regeneration-recovery                                 never          never        0       no error   
  endpoint-888-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                        1m57s ago      never        0       no error   
  ep-bpf-prog-watchdog                                               25s ago        never        0       no error   
  ipcache-inject-labels                                              55s ago        never        0       no error   
  k8s-heartbeat                                                      27s ago        never        0       no error   
  link-cache                                                         10s ago        never        0       no error   
  local-identity-checkpoint                                          3m11s ago      never        0       no error   
  node-neighbor-link-updater                                         5s ago         never        0       no error   
  remote-etcd-cmesh1                                                 13m46s ago     never        0       no error   
  remote-etcd-cmesh10                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh100                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh101                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh102                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh103                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh104                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh105                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh106                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh107                                               13m45s ago     never        0       no error   
  remote-etcd-cmesh108                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh109                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh11                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh110                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh111                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh112                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh113                                               13m45s ago     never        0       no error   
  remote-etcd-cmesh114                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh115                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh116                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh117                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh118                                               13m45s ago     never        0       no error   
  remote-etcd-cmesh119                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh12                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh120                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh121                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh122                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh123                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh124                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh125                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh126                                               13m45s ago     never        0       no error   
  remote-etcd-cmesh127                                               13m45s ago     never        0       no error   
  remote-etcd-cmesh128                                               13m46s ago     never        0       no error   
  remote-etcd-cmesh13                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh14                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh15                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh16                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh17                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh18                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh19                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh2                                                 13m46s ago     never        0       no error   
  remote-etcd-cmesh20                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh21                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh22                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh23                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh24                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh25                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh26                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh27                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh28                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh29                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh3                                                 13m46s ago     never        0       no error   
  remote-etcd-cmesh30                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh31                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh32                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh33                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh34                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh35                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh36                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh37                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh38                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh39                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh4                                                 13m45s ago     never        0       no error   
  remote-etcd-cmesh40                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh41                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh42                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh43                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh44                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh46                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh47                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh48                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh49                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh5                                                 13m46s ago     never        0       no error   
  remote-etcd-cmesh50                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh51                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh52                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh53                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh54                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh55                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh56                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh57                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh58                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh59                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh6                                                 13m45s ago     never        0       no error   
  remote-etcd-cmesh60                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh61                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh62                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh63                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh64                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh65                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh66                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh67                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh68                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh69                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh7                                                 13m46s ago     never        0       no error   
  remote-etcd-cmesh70                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh71                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh72                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh73                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh74                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh75                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh76                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh77                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh78                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh79                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh8                                                 13m46s ago     never        0       no error   
  remote-etcd-cmesh80                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh81                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh82                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh83                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh84                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh85                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh86                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh87                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh88                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh89                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh9                                                 13m46s ago     never        0       no error   
  remote-etcd-cmesh90                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh91                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh92                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh93                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh94                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh95                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh96                                                13m46s ago     never        0       no error   
  remote-etcd-cmesh97                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh98                                                13m45s ago     never        0       no error   
  remote-etcd-cmesh99                                                13m45s ago     never        0       no error   
  resolve-identity-1073                                              1m54s ago      never        0       no error   
  resolve-identity-1981                                              1m53s ago      never        0       no error   
  resolve-identity-2977                                              1m55s ago      never        0       no error   
  resolve-identity-3079                                              1m28s ago      never        0       no error   
  resolve-identity-326                                               1m53s ago      never        0       no error   
  resolve-identity-4023                                              3m54s ago      never        0       no error   
  resolve-identity-623                                               1m29s ago      never        0       no error   
  resolve-identity-888                                               1m28s ago      never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-95n76                6m29s ago      never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-4sddm               6m28s ago      never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-frhdd       6m28s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-6bd68d548-rlk6p   13m54s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-mtttl                 26m53s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-tvkqv                 26m53s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                     26m55s ago     never        0       no error   
  sync-policymap-1073                                                11m50s ago     never        0       no error   
  sync-policymap-1981                                                11m50s ago     never        0       no error   
  sync-policymap-2977                                                11m54s ago     never        0       no error   
  sync-policymap-3079                                                6m28s ago      never        0       no error   
  sync-policymap-326                                                 11m50s ago     never        0       no error   
  sync-policymap-4023                                                13m54s ago     never        0       no error   
  sync-policymap-623                                                 6m29s ago      never        0       no error   
  sync-policymap-888                                                 6m28s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (1981)                                  13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3079)                                  8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (326)                                   13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (4023)                                  14s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (623)                                   9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (888)                                   8s ago         never        0       no error   
  sync-utime                                                         55s ago        never        0       no error   
  write-cni-file                                                     26m57s ago     never        0       no error   
Proxy Status:            OK, ip 10.44.0.216, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 2949120, max 3014655
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 185.01   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
egress-masquerade-interfaces:ens+
http-retry-count:3
bpf-ct-timeout-service-tcp:2h13m20s
tofqdns-min-ttl:0
monitor-aggregation-interval:5s
node-labels:
label-prefix-file:
enable-endpoint-routes:false
enable-session-affinity:false
config-dir:/tmp/cilium/config-map
ipam-cilium-node-update-rate:15s
enable-well-known-identities:false
hubble-recorder-sink-queue-size:1024
bpf-filter-priority:1
bypass-ip-availability-upon-restore:false
enable-monitor:true
max-internal-timer-delay:0s
hubble-export-file-path:
identity-gc-interval:15m0s
enable-ipv6-ndp:false
encryption-strict-mode-allow-remote-node-identities:false
hubble-redact-enabled:false
enable-ipsec-key-watcher:true
vtep-cidr:
http-normalize-path:true
ipv4-pod-subnets:
bpf-node-map-max:16384
proxy-idle-timeout-seconds:60
encrypt-interface:
bpf-neigh-global-max:524288
enable-k8s-terminating-endpoint:true
bpf-lb-source-range-map-max:0
bpf-ct-global-tcp-max:524288
bpf-lb-rss-ipv4-src-cidr:
enable-bpf-clock-probe:false
bpf-events-trace-enabled:true
conntrack-gc-interval:0s
k8s-client-connection-keep-alive:30s
enable-ipv4-egress-gateway:false
bpf-ct-global-any-max:262144
bpf-lb-rev-nat-map-max:0
enable-nat46x64-gateway:false
cflags:
remove-cilium-node-taints:true
trace-payloadlen:128
ipv6-mcast-device:
hubble-disable-tls:false
bpf-lb-sock-terminate-pod-connections:false
unmanaged-pod-watcher-interval:15
enable-health-checking:true
mesh-auth-mutual-listener-port:0
enable-health-check-nodeport:true
enable-recorder:false
cni-log-file:/var/run/cilium/cilium-cni.log
bpf-policy-map-full-reconciliation-interval:15m0s
ipam:cluster-pool
auto-create-cilium-node-resource:true
cluster-name:cmesh45
tofqdns-enable-dns-compression:true
enable-tracing:false
bpf-lb-mode:snat
static-cnp-path:
enable-xdp-prefilter:false
l2-announcements-lease-duration:15s
enable-l7-proxy:true
identity-change-grace-period:5s
force-device-detection:false
cluster-health-port:4240
k8s-namespace:kube-system
enable-tcx:true
hubble-redact-http-userinfo:true
tofqdns-idle-connection-grace-period:0s
bpf-lb-dsr-l4-xlate:frontend
ipv6-range:auto
k8s-require-ipv4-pod-cidr:false
mesh-auth-mutual-connect-timeout:5s
tofqdns-proxy-response-max-delay:100ms
enable-health-check-loadbalancer-ip:false
node-port-bind-protection:true
bpf-map-event-buffers:
enable-bpf-masquerade:false
enable-wireguard:false
config:
dns-max-ips-per-restored-rule:1000
hubble-flowlogs-config-path:
tofqdns-max-deferred-connection-deletes:10000
http-retry-timeout:0
enable-host-firewall:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
clustermesh-ip-identities-sync-timeout:1m0s
enable-bpf-tproxy:false
disable-endpoint-crd:false
k8s-api-server:
enable-ipsec:false
agent-labels:
exclude-node-label-patterns:
ipv4-service-range:auto
ipv4-service-loopback-address:169.254.42.1
enable-ipv4:true
mesh-auth-signal-backoff-duration:1s
k8s-heartbeat-timeout:30s
trace-sock:true
l2-announcements-renew-deadline:5s
enable-envoy-config:false
proxy-portrange-max:20000
egress-gateway-reconciliation-trigger-interval:1s
bgp-announce-lb-ip:false
policy-audit-mode:false
policy-accounting:true
procfs:/host/proc
bpf-sock-rev-map-max:262144
conntrack-gc-max-interval:0s
endpoint-queue-size:25
egress-gateway-policy-map-max:16384
bpf-ct-timeout-regular-tcp-fin:10s
enable-ipsec-encrypted-overlay:false
policy-trigger-interval:1s
ipsec-key-file:
cilium-endpoint-gc-interval:5m0s
cluster-pool-ipv4-cidr:10.44.0.0/16
hubble-event-queue-size:0
k8s-kubeconfig-path:
enable-route-mtu-for-cni-chaining:false
monitor-aggregation-flags:all
hubble-socket-path:/var/run/cilium/hubble.sock
custom-cni-conf:false
l2-pod-announcements-interface:
cni-chaining-mode:none
tunnel-protocol:vxlan
l2-announcements-retry-period:2s
mtu:0
bpf-lb-maglev-table-size:16381
enable-k8s:true
enable-cilium-api-server-access:
enable-ipv6-masquerade:true
encryption-strict-mode-cidr:
ipv6-pod-subnets:
auto-direct-node-routes:false
srv6-encap-mode:reduced
bpf-root:/sys/fs/bpf
proxy-xff-num-trusted-hops-egress:0
debug-verbose:
enable-bbr:false
state-dir:/var/run/cilium
enable-local-redirect-policy:false
bpf-ct-timeout-service-tcp-grace:1m0s
service-no-backend-response:reject
operator-prometheus-serve-addr::9963
node-port-acceleration:disabled
ipv4-native-routing-cidr:
monitor-queue-size:0
routing-mode:tunnel
ipam-multi-pool-pre-allocation:
allow-icmp-frag-needed:true
derive-masq-ip-addr-from-device:
install-iptables-rules:true
enable-sctp:false
proxy-max-connection-duration-seconds:0
ipv4-node:auto
bpf-ct-timeout-regular-any:1m0s
enable-cilium-endpoint-slice:false
enable-high-scale-ipcache:false
clustermesh-enable-mcs-api:false
pprof:false
bgp-config-path:/var/lib/cilium/bgp/config.yaml
k8s-service-proxy-name:
endpoint-gc-interval:5m0s
bpf-lb-dsr-dispatch:opt
kvstore-connectivity-timeout:2m0s
nat-map-stats-interval:30s
enable-gateway-api:false
egress-multi-home-ip-rule-compat:false
cmdref:
arping-refresh-period:30s
read-cni-conf:
enable-ipip-termination:false
dnsproxy-concurrency-processing-grace-period:0s
http-max-grpc-timeout:0
http-request-timeout:3600
vtep-mask:
hubble-redact-http-headers-allow:
preallocate-bpf-maps:false
external-envoy-proxy:true
proxy-connect-timeout:2
nodes-gc-interval:5m0s
set-cilium-is-up-condition:true
enable-ipv4-masquerade:true
use-full-tls-context:false
cni-external-routing:false
disable-envoy-version-check:false
vtep-mac:
endpoint-bpf-prog-watchdog-interval:30s
enable-icmp-rules:true
mesh-auth-spiffe-trust-domain:spiffe.cilium
ipv6-service-range:auto
synchronize-k8s-nodes:true
labels:
debug:false
k8s-sync-timeout:3m0s
bpf-map-dynamic-size-ratio:0.0025
kvstore-max-consecutive-quorum-errors:2
enable-bandwidth-manager:false
log-opt:
mke-cgroup-mount:
annotate-k8s-node:false
route-metric:0
api-rate-limit:
tofqdns-dns-reject-response-code:refused
proxy-gid:1337
kvstore-periodic-sync:5m0s
hubble-export-file-max-size-mb:10
enable-mke:false
agent-liveness-update-interval:1s
certificates-directory:/var/run/cilium/certs
restore:true
ipv6-node:auto
prometheus-serve-addr:
nat-map-stats-entries:32
enable-xt-socket-fallback:true
enable-ip-masq-agent:false
agent-health-port:9879
bpf-nat-global-max:524288
hubble-monitor-events:
envoy-secrets-namespace:
cni-exclusive:true
policy-queue-size:100
local-router-ipv4:
allow-localhost:auto
nodeport-addresses:
enable-host-legacy-routing:false
dnsproxy-lock-timeout:500ms
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
bpf-lb-sock-hostns-only:false
kvstore-opt:
hubble-export-file-max-backups:5
enable-k8s-api-discovery:false
devices:
mesh-auth-enabled:true
envoy-config-retry-interval:15s
bpf-auth-map-max:524288
bpf-lb-sock:false
enable-host-port:false
hubble-drop-events:false
encrypt-node:false
enable-bgp-control-plane:false
enable-unreachable-routes:false
enable-vtep:false
hubble-drop-events-interval:2m0s
lib-dir:/var/lib/cilium
enable-ipv6-big-tcp:false
dnsproxy-lock-count:131
proxy-admin-port:0
identity-restore-grace-period:30s
hubble-prefer-ipv6:false
max-connected-clusters:255
hubble-drop-events-reasons:auth_required,policy_denied
vlan-bpf-bypass:
hubble-export-denylist:
hubble-redact-http-urlquery:false
enable-node-port:false
vtep-endpoint:
disable-iptables-feeder-rules:
node-port-mode:snat
policy-cidr-match-mode:
bpf-lb-rss-ipv6-src-cidr:
mesh-auth-gc-interval:5m0s
config-sources:config-map:kube-system/cilium-config
enable-policy:default
enable-active-connection-tracking:false
enable-k8s-networkpolicy:true
enable-runtime-device-detection:true
envoy-base-id:0
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
envoy-keep-cap-netbindservice:false
hubble-metrics:
enable-identity-mark:true
envoy-config-timeout:2m0s
enable-ipv4-big-tcp:false
clustermesh-sync-timeout:1m0s
datapath-mode:veth
proxy-prometheus-port:0
log-driver:
tunnel-port:0
hubble-export-allowlist:
hubble-export-fieldmask:
identity-allocation-mode:crd
allocator-list-timeout:3m0s
ipv4-range:auto
enable-service-topology:false
iptables-lock-timeout:5s
controller-group-metrics:
hubble-recorder-storage-path:/var/run/cilium/pcaps
bpf-events-policy-verdict-enabled:true
enable-l2-announcements:false
wireguard-persistent-keepalive:0s
bpf-lb-map-max:65536
fixed-identity-mapping:
tofqdns-endpoint-max-ip-per-hostname:50
hubble-event-buffer-capacity:4095
k8s-require-ipv6-pod-cidr:false
join-cluster:false
bpf-lb-maglev-map-max:0
enable-metrics:true
http-idle-timeout:0
monitor-aggregation:medium
kube-proxy-replacement-healthz-bind-address:
ipam-default-ip-pool:default
k8s-service-cache-size:128
ipsec-key-rotation-duration:5m0s
prepend-iptables-chains:true
tofqdns-pre-cache:
kube-proxy-replacement:false
operator-api-serve-addr:127.0.0.1:9234
multicast-enabled:false
dnsproxy-concurrency-limit:0
enable-node-selector-labels:false
crd-wait-timeout:5m0s
enable-ipsec-xfrm-state-caching:true
max-controller-interval:0
local-router-ipv6:
enable-hubble:true
enable-local-node-route:true
dnsproxy-enable-transparent-mode:true
cluster-pool-ipv4-mask-size:24
enable-stale-cilium-endpoint-cleanup:true
enable-k8s-endpoint-slice:true
clustermesh-enable-endpoint-sync:false
log-system-load:false
pprof-port:6060
install-no-conntrack-iptables-rules:false
node-port-range:
enable-custom-calls:false
hubble-listen-address::4244
cluster-id:45
set-cilium-node-taints:true
enable-external-ips:false
enable-encryption-strict-mode:false
dns-policy-unload-on-shutdown:false
enable-masquerade-to-route-source:false
hubble-redact-kafka-apikey:false
proxy-xff-num-trusted-hops-ingress:0
enable-endpoint-health-checking:true
k8s-client-connection-timeout:30s
kvstore-lease-ttl:15m0s
enable-ipv4-fragment-tracking:true
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-ingress-controller:false
hubble-metrics-server:
pprof-address:localhost
k8s-client-burst:20
bpf-lb-affinity-map-max:0
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
enable-pmtu-discovery:false
direct-routing-skip-unreachable:false
k8s-client-qps:10
kvstore:
enable-svc-source-range-check:true
cni-chaining-target:
hubble-export-file-compress:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
bpf-lb-service-map-max:0
identity-heartbeat-timeout:30m0s
tofqdns-proxy-port:0
enable-srv6:false
fqdn-regex-compile-lru-size:1024
version:false
metrics:
gateway-api-secrets-namespace:
bpf-lb-external-clusterip:false
bpf-events-drop-enabled:true
node-port-algorithm:random
mesh-auth-rotated-identities-queue-size:1024
proxy-portrange-min:10000
mesh-auth-queue-size:1024
bpf-lb-acceleration:disabled
gops-port:9890
disable-external-ip-mitigation:false
enable-hubble-recorder-api:true
enable-cilium-health-api-server-access:
bpf-ct-timeout-service-any:1m0s
use-cilium-internal-ip-for-ipsec:false
cgroup-root:/run/cilium/cgroupv2
hubble-skip-unknown-cgroup-ids:true
bpf-ct-timeout-regular-tcp-syn:1m0s
bgp-announce-pod-cidr:false
bpf-lb-algorithm:random
exclude-local-address:
ipv6-cluster-alloc-cidr:f00d::/64
iptables-random-fully:false
enable-auto-protect-node-port-range:true
keep-config:false
bpf-lb-service-backend-map-max:0
direct-routing-device:
socket-path:/var/run/cilium/cilium.sock
envoy-log:
ipv6-native-routing-cidr:
enable-l2-pod-announcements:false
dnsproxy-insecure-skip-transparent-mode-check:false
ingress-secrets-namespace:
container-ip-local-reserved-ports:auto
bpf-fragments-map-max:8192
bpf-policy-map-max:16384
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
proxy-max-requests-per-connection:0
hubble-redact-http-headers-deny:
enable-ipv6:false
bpf-ct-timeout-regular-tcp:2h13m20s
enable-l2-neigh-discovery:true
ip-masq-agent-config-path:/etc/config/ip-masq-agent
mesh-auth-spire-admin-socket:
enable-wireguard-userspace-fallback:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
clustermesh-config:/var/lib/cilium/clustermesh/
local-max-addr-scope:252
dnsproxy-socket-linger-timeout:10
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                    IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                      
326        Disabled           Disabled          2997539    k8s:eks.amazonaws.com/component=coredns                                               10.44.0.217   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh45                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=kube-dns                                                                                        
623        Disabled           Disabled          3006200    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.44.0.194   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh45                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client                                                              
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                               
                                                           k8s:kind=client                                                                                             
                                                           k8s:name=client                                                                                             
888        Disabled           Disabled          2966929    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.44.0.161   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh45                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node                                                      
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                               
                                                           k8s:kind=echo                                                                                               
                                                           k8s:name=echo-same-node                                                                                     
                                                           k8s:other=echo                                                                                              
1073       Disabled           Disabled          4          reserved:health                                                                       10.44.0.197   ready   
1981       Disabled           Disabled          2997539    k8s:eks.amazonaws.com/component=coredns                                               10.44.0.2     ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh45                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=kube-dns                                                                                        
2977       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                     ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                       
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                                 
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                  
                                                           reserved:host                                                                                               
3079       Disabled           Disabled          2953912    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.44.0.92    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh45                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client2                                                             
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                               
                                                           k8s:kind=client                                                                                             
                                                           k8s:name=client2                                                                                            
                                                           k8s:other=client                                                                                            
4023       Disabled           Disabled          2969204    k8s:app.kubernetes.io/name=clustermesh-apiserver                                      10.44.0.127   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                        
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh45                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                               
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=clustermesh-apiserver                                                                           
```

#### BPF Policy Get 326

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    216885   1957      0        
Allow    Ingress     1          ANY          NONE         disabled    153932   1768      0        
Allow    Egress      0          ANY          NONE         disabled    67877    674       0        

```


#### BPF CT List 326

```
Invalid argument: unknown type 326
```


#### Endpoint Get 326

```
[
  {
    "id": 326,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-326-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "774adefa-1acd-41dc-b80b-e3ab1e70ca06"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-326",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:52:57.302Z",
            "success-count": 6
          },
          "uuid": "c979d143-535f-4c25-a1f6-81148775ab8b"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-mtttl",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:27:57.299Z",
            "success-count": 1
          },
          "uuid": "37857535-6f4b-4584-8137-9dc5dd055232"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-326",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:43:00.093Z",
            "success-count": 2
          },
          "uuid": "fdd27d18-dae5-42d8-a3cb-b5eed67e94d9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (326)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:47.424Z",
            "success-count": 163
          },
          "uuid": "87475157-ee79-429b-8316-2900d87ad23b"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "7abc6d4be7417be2073af80e56413ceeace2fc433db751799771023fabd9fe54:eth0",
        "container-id": "7abc6d4be7417be2073af80e56413ceeace2fc433db751799771023fabd9fe54",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-mtttl",
        "pod-name": "kube-system/coredns-cc6ccd49c-mtttl"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2997539,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.44.0.217",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "1a:ea:06:d0:91:00",
        "interface-index": 14,
        "interface-name": "lxcd3a7f1c4719f",
        "mac": "06:60:3d:f9:4c:a2"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2997539,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2997539,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 326

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 326

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:41:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:41:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:05Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:41:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:41:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:41:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:04Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:41:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:41:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:41:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:03Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:41:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:36:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:36:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:36:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:36:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:28:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:28:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:28:00Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:27:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:27:57Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:27:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:27:57Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:27:57Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2997539

```
ID        LABELS
2997539   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh45
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 623

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 623

```
Invalid argument: unknown type 623
```


#### Endpoint Get 623

```
[
  {
    "id": 623,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-623-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ef762ccd-5039-489e-a6d7-87cffb9012d9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-623",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:21.061Z",
            "success-count": 2
          },
          "uuid": "297f432e-b6af-4246-be05-3ba215028d90"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client-974f6c69d-95n76",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:21.060Z",
            "success-count": 1
          },
          "uuid": "4ba52434-a585-40f6-a013-12a8045c3434"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-623",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:21.105Z",
            "success-count": 1
          },
          "uuid": "66fbfe7a-7ec7-4ea5-8491-b98dcddb3938"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (623)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:51.103Z",
            "success-count": 41
          },
          "uuid": "fe48dce1-dea3-4c6d-b074-05de742d2679"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "fe349f624501fe3ad66ce778c89310a6a9730067cea30e5e4e77ffd70bca47c2:eth0",
        "container-id": "fe349f624501fe3ad66ce778c89310a6a9730067cea30e5e4e77ffd70bca47c2",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client-974f6c69d-95n76",
        "pod-name": "cilium-test-1/client-974f6c69d-95n76"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3006200,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=974f6c69d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:23Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.44.0.194",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ca:ec:5b:85:75:ea",
        "interface-index": 20,
        "interface-name": "lxcd25b4156c50e",
        "mac": "9a:ec:c8:e2:a5:08"
      },
      "policy": {
        "proxy-policy-revision": 129,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3006200,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3006200,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 623

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 623

```
Timestamp              Status   State                   Message
2024-10-24T12:51:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:29Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)

```


#### Identity get 3006200

```
ID        LABELS
3006200   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh45
          k8s:io.cilium.k8s.policy.serviceaccount=client
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=client
          k8s:name=client

```


#### BPF Policy Get 888

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379050   4423      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 888

```
Invalid argument: unknown type 888
```


#### Endpoint Get 888

```
[
  {
    "id": 888,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-888-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "39a8007d-2e9b-4b02-9c46-371fbaca3e70"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-888",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:22.221Z",
            "success-count": 2
          },
          "uuid": "1073bf54-93ba-4be4-8c70-87989833ca7f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-frhdd",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:22.220Z",
            "success-count": 1
          },
          "uuid": "81a5654c-a15e-42bf-a6e8-788c935a4289"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-888",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:22.271Z",
            "success-count": 1
          },
          "uuid": "f164339d-6bc8-412f-b267-4cec3c9d4c52"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (888)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:42.259Z",
            "success-count": 40
          },
          "uuid": "3ec8bf83-bb98-4372-ad12-346026c9a097"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "6dc3f914e63b6d18690813900f4c819efe16fd7da35e03d4dd028c61ea8cf83e:eth0",
        "container-id": "6dc3f914e63b6d18690813900f4c819efe16fd7da35e03d4dd028c61ea8cf83e",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "echo-same-node-86d9cc975c-frhdd",
        "pod-name": "cilium-test-1/echo-same-node-86d9cc975c-frhdd"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2966929,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=86d9cc975c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:14Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns-53",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "dns-udp-53",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "http-8080",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.44.0.161",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "e2:e6:ac:21:5c:52",
        "interface-index": 24,
        "interface-name": "lxcb6cd233c0332",
        "mac": "4e:0d:b7:58:0f:b3"
      },
      "policy": {
        "proxy-policy-revision": 126,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2966929,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 126,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2966929,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 126
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 888

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 888

```
Timestamp              Status   State                   Message
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:29Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:29Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests

```


#### Identity get 2966929

```
ID        LABELS
2966929   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh45
          k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=echo
          k8s:name=echo-same-node
          k8s:other=echo

```


#### BPF Policy Get 1073

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6226536   76961     0        
Allow    Ingress     1          ANY          NONE         disabled    68852     832       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        

```


#### BPF CT List 1073

```
Invalid argument: unknown type 1073
```


#### Endpoint Get 1073

```
[
  {
    "id": 1073,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1073-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d3821364-496d-4018-bdba-94620c47db23"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1073",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:52:56.623Z",
            "success-count": 6
          },
          "uuid": "ffbd03e7-ad0e-404e-ba6b-ef369d17b235"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1073",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:43:00.035Z",
            "success-count": 2
          },
          "uuid": "642d15a5-d0c3-472b-828b-33b569b7443f"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.44.0.197",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "c6:b2:8a:c9:ca:77",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "22:50:7b:e3:15:5c"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1073

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1073

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:41:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:41:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:05Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:41:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:41:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:41:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:04Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:41:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:41:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:41:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:03Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:41:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:36:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:36:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:36:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:36:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:28:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:28:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:28:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:28:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:27:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:27:57Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:27:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:27:56Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:27:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:27:56Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:27:55Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 1981

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    212025   1915      0        
Allow    Ingress     1          ANY          NONE         disabled    151846   1746      0        
Allow    Egress      0          ANY          NONE         disabled    66534    659       0        

```


#### BPF CT List 1981

```
Invalid argument: unknown type 1981
```


#### Endpoint Get 1981

```
[
  {
    "id": 1981,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1981-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "907a3292-f24f-4527-86c1-f1a7baaa3db2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1981",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:52:57.195Z",
            "success-count": 6
          },
          "uuid": "9bc88bea-1a09-4297-89c3-7d617938c787"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-tvkqv",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:27:57.191Z",
            "success-count": 1
          },
          "uuid": "11421b11-4b4a-4336-8e30-7dfc4343c38e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1981",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:43:00.045Z",
            "success-count": 2
          },
          "uuid": "c960667c-9e31-4d93-8cba-6089eb0578b8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1981)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:47.316Z",
            "success-count": 163
          },
          "uuid": "46dd743e-26d3-4b46-a6fb-34ff5ab94070"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "1a00a77984c7313e1470347df76706df5ee94587c783ac27948bbbe40082ab2b:eth0",
        "container-id": "1a00a77984c7313e1470347df76706df5ee94587c783ac27948bbbe40082ab2b",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-tvkqv",
        "pod-name": "kube-system/coredns-cc6ccd49c-tvkqv"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2997539,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.44.0.2",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "9a:75:51:7b:2a:19",
        "interface-index": 12,
        "interface-name": "lxc0c74789326d7",
        "mac": "02:6c:d2:b1:9a:44"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2997539,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2997539,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1981

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1981

```
Timestamp              Status    State                   Message
2024-10-24T12:48:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:41:05Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:41:05Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:05Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T12:41:05Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:41:04Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:41:04Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:04Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:41:04Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:41:03Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:41:03Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:03Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:41:03Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:36:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:36:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:36:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:36:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:28:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:28:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:27:58Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:27:58Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:27:57Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:27:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:27:57Z   OK        ready                   Set identity for this endpoint
2024-10-24T12:27:57Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:27:57Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 2997539

```
ID        LABELS
2997539   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh45
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2977

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2977

```
Invalid argument: unknown type 2977
```


#### Endpoint Get 2977

```
[
  {
    "id": 2977,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2977-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "dcbfc774-bc9f-4539-8d64-a760bbf96f56"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2977",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:52:55.552Z",
            "success-count": 6
          },
          "uuid": "9f2a8404-f0d4-4ef1-8655-f9bbe3603151"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2977",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:42:56.628Z",
            "success-count": 2
          },
          "uuid": "a3fb5ab1-4571-45ef-b43d-64be7af694d3"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "92:d1:7e:d1:31:fa",
        "interface-name": "cilium_host",
        "mac": "92:d1:7e:d1:31:fa"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2977

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2977

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:41:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:41:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:05Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:41:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:41:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:41:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:04Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:41:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:41:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:41:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:03Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:41:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:36:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:36:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:36:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:36:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:28:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-24T12:28:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:28:00Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-24T12:27:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:27:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T12:27:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-24T12:27:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:27:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:27:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:27:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:27:55Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:27:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:27:55Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:27:55Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 3079

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3079

```
Invalid argument: unknown type 3079
```


#### Endpoint Get 3079

```
[
  {
    "id": 3079,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3079-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ad6c78f2-6af5-4fec-8896-53b1d0fdd98b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3079",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:22.129Z",
            "success-count": 2
          },
          "uuid": "2bfe508e-22c7-4bb1-a73b-a6501a59660f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client2-57cf4468f-4sddm",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:22.127Z",
            "success-count": 1
          },
          "uuid": "9f0a3020-1d87-47da-b108-b78e47aab498"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3079",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:22.210Z",
            "success-count": 1
          },
          "uuid": "d3701181-b0c8-4cb4-a8df-a3c1e8fea883"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3079)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:52.171Z",
            "success-count": 41
          },
          "uuid": "2f51f945-b69e-468d-9e9e-33e2286b4be4"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "dfa4374ad4ca4f242c632b0be5996125774d41005b25995547c2de049b841e40:eth0",
        "container-id": "dfa4374ad4ca4f242c632b0be5996125774d41005b25995547c2de049b841e40",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client2-57cf4468f-4sddm",
        "pod-name": "cilium-test-1/client2-57cf4468f-4sddm"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2953912,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=57cf4468f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:23Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.44.0.92",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "82:40:1f:38:88:eb",
        "interface-index": 22,
        "interface-name": "lxc4f38a23970e2",
        "mac": "ba:cf:1a:1a:b1:46"
      },
      "policy": {
        "proxy-policy-revision": 129,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2953912,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2953912,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3079

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3079

```
Timestamp              Status   State                   Message
2024-10-24T12:51:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:29Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added

```


#### Identity get 2953912

```
ID        LABELS
2953912   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh45
          k8s:io.cilium.k8s.policy.serviceaccount=client2
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=client
          k8s:name=client2
          k8s:other=client

```


#### BPF Policy Get 4023

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6051722   61469     0        
Allow    Ingress     1          ANY          NONE         disabled    6242427   64667     0        
Allow    Egress      0          ANY          NONE         disabled    7676768   74995     0        

```


#### BPF CT List 4023

```
Invalid argument: unknown type 4023
```


#### Endpoint Get 4023

```
[
  {
    "id": 4023,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-4023-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f87c6fc3-8409-4534-8939-4cca5b762ab1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-4023",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:50:56.501Z",
            "success-count": 3
          },
          "uuid": "1e6641e8-afd5-48f6-bf95-5bce56cddd61"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-6bd68d548-rlk6p",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:40:56.492Z",
            "success-count": 1
          },
          "uuid": "727ad534-4606-4a5e-9851-d28570972e1b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-4023",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:40:56.557Z",
            "success-count": 1
          },
          "uuid": "760df69b-f465-47af-86c3-1bfb55a1e5a7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (4023)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:46.595Z",
            "success-count": 85
          },
          "uuid": "9e4d996f-9bfd-41a7-b885-20aa9a2a8fd7"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "5ca3a8df22be5c434b6eb7263dafa8be9420a7274c03184cdd49e207e609bf62:eth0",
        "container-id": "5ca3a8df22be5c434b6eb7263dafa8be9420a7274c03184cdd49e207e609bf62",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-6bd68d548-rlk6p",
        "pod-name": "kube-system/clustermesh-apiserver-6bd68d548-rlk6p"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2969204,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6bd68d548"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.44.0.127",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "36:c1:9a:89:32:ea",
        "interface-index": 18,
        "interface-name": "lxc3a51e605b2a5",
        "mac": "de:20:f9:3d:1a:a4"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2969204,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2969204,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 4023

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 4023

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:41:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:41:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:05Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:41:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:41:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:41:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:04Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:41:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:41:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:41:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:41:03Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:41:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:40:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:40:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:40:56Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:40:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:40:56Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:40:56Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2969204

```
ID        LABELS
2969204   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh45
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```

