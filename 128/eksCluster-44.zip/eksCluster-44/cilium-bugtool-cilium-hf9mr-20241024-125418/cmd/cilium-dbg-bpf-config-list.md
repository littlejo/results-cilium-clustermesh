KEY             VALUE
AgentLiveness   1995973884692
UTimeOffset     3378461904296875
