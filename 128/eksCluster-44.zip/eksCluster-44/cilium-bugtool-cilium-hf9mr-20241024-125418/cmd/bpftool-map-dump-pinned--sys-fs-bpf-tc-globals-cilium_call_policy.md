key: 46 01 00 00  value: 18 02 00 00
key: 6f 02 00 00  value: 27 0d 00 00
key: 78 03 00 00  value: e0 0c 00 00
key: 31 04 00 00  value: 4b 02 00 00
key: bd 07 00 00  value: 0a 02 00 00
key: 07 0c 00 00  value: 24 0d 00 00
key: b7 0f 00 00  value: 89 02 00 00
Found 7 elements
