top - 12:54:19 up 32 min,  0 users,  load average: 0.67, 0.54, 0.30
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 14.8 us, 18.5 sy,  0.0 ni, 66.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    285.1 free,   1057.7 used,   2493.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2597.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539132 294640  78592 S   6.7   7.5   1:09.64 cilium-+
   3255 root      20   0 1240432  16560  11356 S   6.7   0.4   0:00.03 cilium-+
    393 root      20   0 1229744   8956   2924 S   0.0   0.2   0:04.10 cilium-+
   3277 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3278 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3293 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3319 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3325 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3348 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
