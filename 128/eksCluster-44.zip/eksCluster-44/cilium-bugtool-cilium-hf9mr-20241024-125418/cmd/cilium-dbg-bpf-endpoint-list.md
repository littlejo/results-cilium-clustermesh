IP ADDRESS         LOCAL ENDPOINT INFO
10.44.0.217:0      id=326   sec_id=2997539 flags=0x0000 ifindex=14  mac=06:60:3D:F9:4C:A2 nodemac=1A:EA:06:D0:91:00   
10.44.0.197:0      id=1073  sec_id=4     flags=0x0000 ifindex=10  mac=22:50:7B:E3:15:5C nodemac=C6:B2:8A:C9:CA:77     
10.44.0.161:0      id=888   sec_id=2966929 flags=0x0000 ifindex=24  mac=4E:0D:B7:58:0F:B3 nodemac=E2:E6:AC:21:5C:52   
172.31.160.162:0   (localhost)                                                                                        
10.44.0.194:0      id=623   sec_id=3006200 flags=0x0000 ifindex=20  mac=9A:EC:C8:E2:A5:08 nodemac=CA:EC:5B:85:75:EA   
10.44.0.127:0      id=4023  sec_id=2969204 flags=0x0000 ifindex=18  mac=DE:20:F9:3D:1A:A4 nodemac=36:C1:9A:89:32:EA   
10.44.0.2:0        id=1981  sec_id=2997539 flags=0x0000 ifindex=12  mac=02:6C:D2:B1:9A:44 nodemac=9A:75:51:7B:2A:19   
172.31.128.30:0    (localhost)                                                                                        
10.44.0.92:0       id=3079  sec_id=2953912 flags=0x0000 ifindex=22  mac=BA:CF:1A:1A:B1:46 nodemac=82:40:1F:38:88:EB   
10.44.0.216:0      (localhost)                                                                                        
