filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcb6cd233c0332 direct-action not_in_hw id 3302 tag f37dc2b94bac24fc jited 
