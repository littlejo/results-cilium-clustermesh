[
  {
    "containers": [
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod814f4794_e748_4b26_a2b3_2475dace7d81.slice/cri-containerd-a964a4d9ab4c640ce21f26cfbff94a1c859e9fb8dafbb06435f70d223a329b34.scope"
      },
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod814f4794_e748_4b26_a2b3_2475dace7d81.slice/cri-containerd-f581ca2371faaa62bfe32fc0d5cdbdd90abe8abf21847b6e62b741d8384791ba.scope"
      }
    ],
    "ips": [
      "10.44.0.161"
    ],
    "name": "echo-same-node-86d9cc975c-frhdd",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb855cdc1_9003_4770_bb91_b9f6f45b672a.slice/cri-containerd-9ec88262fede800dcd4c3c32cbaccd9168b5c491dc1e5230b4ed99562a24a235.scope"
      }
    ],
    "ips": [
      "10.44.0.217"
    ],
    "name": "coredns-cc6ccd49c-mtttl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6915cda2_248c_408c_ae96_23e2c1ed54db.slice/cri-containerd-e4da545e0f3c36dfa641b085a8960c8e751400f7a9b12ddd40510c0b7fd1e538.scope"
      }
    ],
    "ips": [
      "10.44.0.194"
    ],
    "name": "client-974f6c69d-95n76",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29dd4b74_f827_4fa5_9634_8759eb32da43.slice/cri-containerd-86a6a061c693f17a7b258bddd02e099c48dce1cca0fe19b75445d0ee9408cbae.scope"
      }
    ],
    "ips": [
      "10.44.0.92"
    ],
    "name": "client2-57cf4468f-4sddm",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda9dea1b4_de67_41ae_a9a1_5816628e217d.slice/cri-containerd-13005da7116614a0e6e103f03a171b6938de3072f379764744dd53ac1ee0b5dc.scope"
      }
    ],
    "ips": [
      "10.44.0.2"
    ],
    "name": "coredns-cc6ccd49c-tvkqv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f0a3b5b_cac8_41b9_98ff_64b5231e148f.slice/cri-containerd-166091c4162b7588f57fbf49d80d5e09b49ec798f5828bc1d709d18ba62767bf.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f0a3b5b_cac8_41b9_98ff_64b5231e148f.slice/cri-containerd-f673fc99ed27b375170e41df94490c97f487d765af8d5aa0a9be7c3eec798be5.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f0a3b5b_cac8_41b9_98ff_64b5231e148f.slice/cri-containerd-f07563ca9fb84cdf587773e058945535317605d78f406acd0ea101cd8d423a06.scope"
      }
    ],
    "ips": [
      "10.44.0.127"
    ],
    "name": "clustermesh-apiserver-6bd68d548-rlk6p",
    "namespace": "kube-system"
  }
]

