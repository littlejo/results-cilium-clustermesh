[
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1db9bd89_05f0_4495_b78e_40b077361ae8.slice/cri-containerd-9f754eefae7eaeb5a0a0a4a0caaa42c89bbb7b005bc44e5c14938544b13a0d8b.scope"
      }
    ],
    "ips": [
      "10.82.0.125"
    ],
    "name": "client2-57cf4468f-gvl88",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74c1e97c_0985_43d3_8ab5_7a08b1a4fcc3.slice/cri-containerd-167fa657c7f567f3bafa8078ffb62c3818b373c1a13dc553e473e32a686f05bd.scope"
      },
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74c1e97c_0985_43d3_8ab5_7a08b1a4fcc3.slice/cri-containerd-81757a7efb99af377b0edb53c5b2677557fcef2a773b27f1498692e75e648e85.scope"
      }
    ],
    "ips": [
      "10.82.0.18"
    ],
    "name": "echo-same-node-86d9cc975c-l7r47",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode5a8235d_a07a_4c6f_98b4_40c1d5d942ea.slice/cri-containerd-7776b95fe89936a480469f017f101f8508ff4cff4d3f955ea8edc219c96a9f3d.scope"
      }
    ],
    "ips": [
      "10.82.0.30"
    ],
    "name": "coredns-cc6ccd49c-md8n2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7493,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode26853e4_bb51_4edd_884d_11cc6fa779a0.slice/cri-containerd-641527e1fb4c32c38598ccac76134e158c3aff8196ea36c5eed0bbc33fb27cd7.scope"
      }
    ],
    "ips": [
      "10.82.0.175"
    ],
    "name": "coredns-cc6ccd49c-z4jwj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71ab0256_66f3_4519_9222_6f33b9d2a044.slice/cri-containerd-c216158c28f043fc4964153ce4c446ebf7ff4518d8d46a42dd0204e46029c18c.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71ab0256_66f3_4519_9222_6f33b9d2a044.slice/cri-containerd-b39166abc0aa4d983e3a5175df3ac1b377f690911cce3f3d0182ca9b66f20a0d.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71ab0256_66f3_4519_9222_6f33b9d2a044.slice/cri-containerd-4345be577679247a30683d9b81ff69ce7c741827dbea05386285e9e22202d4c3.scope"
      }
    ],
    "ips": [
      "10.82.0.50"
    ],
    "name": "clustermesh-apiserver-6f69788544-9wmss",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e959407_ce2e_41f2_8367_274c035273a7.slice/cri-containerd-c0ce6b0393d7120f10af88e28facfbb839f9b22ba02c9d856025ef596113c14f.scope"
      }
    ],
    "ips": [
      "10.82.0.82"
    ],
    "name": "client-974f6c69d-t8vdz",
    "namespace": "cilium-test-1"
  }
]

