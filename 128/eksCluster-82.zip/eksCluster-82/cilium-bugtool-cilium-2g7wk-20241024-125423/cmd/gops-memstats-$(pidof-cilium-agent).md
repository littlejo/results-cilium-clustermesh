alloc: 83.42MB (87476288 bytes)
total-alloc: 3.10GB (3325126248 bytes)
sys: 215.32MB (225781076 bytes)
lookups: 0
mallocs: 75582330
frees: 74831768
heap-alloc: 83.42MB (87476288 bytes)
heap-sys: 168.72MB (176914432 bytes)
heap-idle: 44.23MB (46374912 bytes)
heap-in-use: 124.49MB (130539520 bytes)
heap-released: 7.39MB (7749632 bytes)
heap-objects: 750562
stack-in-use: 35.28MB (36995072 bytes)
stack-sys: 35.28MB (36995072 bytes)
stack-mspan-inuse: 2.12MB (2222720 bytes)
stack-mspan-sys: 2.80MB (2937600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 962.12KB (985209 bytes)
gc-sys: 5.48MB (5741688 bytes)
next-gc: when heap-alloc >= 148.81MB (156040008 bytes)
last-gc: 2024-10-24 12:54:14.832100774 +0000 UTC
gc-pause-total: 14.095589ms
gc-pause: 77186
gc-pause-end: 1729774454832100774
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0006229269901748248
enable-gc: true
debug-gc: false
