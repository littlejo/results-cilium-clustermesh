Error: Unable to open /sys/fs/bpf/tc/globals/cilium_snat_v4_external: loading pinned map /sys/fs/bpf/tc/globals/cilium_snat_v4_external: no such file or directory
> Error while running 'cilium-dbg bpf nat list':  exit status 1

