Endpoint ID: 197
Path: /sys/fs/bpf/tc/globals/cilium_policy_00197

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5426873   56634     0        
Allow    Ingress     1          ANY          NONE         disabled    5659806   59954     0        
Allow    Egress      0          ANY          NONE         disabled    6972418   69860     0        


Endpoint ID: 400
Path: /sys/fs/bpf/tc/globals/cilium_policy_00400

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1631
Path: /sys/fs/bpf/tc/globals/cilium_policy_01631

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2578     27        0        
Allow    Ingress     1          ANY          NONE         disabled    137840   1589      0        
Allow    Egress      0          ANY          NONE         disabled    18345    202       0        


Endpoint ID: 2208
Path: /sys/fs/bpf/tc/globals/cilium_policy_02208

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3318     33        0        
Allow    Ingress     1          ANY          NONE         disabled    137925   1586      0        
Allow    Egress      0          ANY          NONE         disabled    19653    218       0        


Endpoint ID: 2235
Path: /sys/fs/bpf/tc/globals/cilium_policy_02235

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2511
Path: /sys/fs/bpf/tc/globals/cilium_policy_02511

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6193632   76534     0        
Allow    Ingress     1          ANY          NONE         disabled    64048     773       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2524
Path: /sys/fs/bpf/tc/globals/cilium_policy_02524

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2545
Path: /sys/fs/bpf/tc/globals/cilium_policy_02545

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    355116   4151      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


