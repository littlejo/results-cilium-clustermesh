CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2c2827da_7f9c_406a_be9d_5a0368a99a30.slice/cri-containerd-af3ec6481d4b4f171887d3b0817e633abefd24744c649781fa94e174c7c72470.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2c2827da_7f9c_406a_be9d_5a0368a99a30.slice/cri-containerd-823ff7e996687fe48ecdde4817825a8ac7589c14d2d983bb1bd10e18b7711bbd.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode26853e4_bb51_4edd_884d_11cc6fa779a0.slice/cri-containerd-03b1d30fbab05a8fa3c7879310ed17e091458ab7b4bf3fc687c3ab9c484c52c5.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode26853e4_bb51_4edd_884d_11cc6fa779a0.slice/cri-containerd-641527e1fb4c32c38598ccac76134e158c3aff8196ea36c5eed0bbc33fb27cd7.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode5a8235d_a07a_4c6f_98b4_40c1d5d942ea.slice/cri-containerd-7776b95fe89936a480469f017f101f8508ff4cff4d3f955ea8edc219c96a9f3d.scope
    614      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode5a8235d_a07a_4c6f_98b4_40c1d5d942ea.slice/cri-containerd-e83d54c13ce404575260b948c733a2d59f3b5044861cb09912cbfc2127101a4f.scope
    606      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda11c78df_4cbd_432a_93ff_ee3daeaafee4.slice/cri-containerd-78748c40f9d8aef95906e0505168482c23e3a1608f0d0a2f9aaa1437f70b2242.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda11c78df_4cbd_432a_93ff_ee3daeaafee4.slice/cri-containerd-76064db55dbc388d986365a26b1ddbe25a2e27875cacba2a69ba58b506282545.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb1f5e046_c9e3_4ede_88c5_0610eeac19e9.slice/cri-containerd-ee62ffcee5c6adedd5e3f580c917199f55b90f6bf96a788c99574de50a7c32a9.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb1f5e046_c9e3_4ede_88c5_0610eeac19e9.slice/cri-containerd-93a66a7761b7195850ac266a7156f2a14edbd6081cd36877c7abdd0b23e4dfde.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14ea9633_9617_473e_8aa7_bfafe7f44575.slice/cri-containerd-6d651054c9fc15f891d48a4b63e5940d5f496b3900bd17514a00d240e0d17d80.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14ea9633_9617_473e_8aa7_bfafe7f44575.slice/cri-containerd-a5ff6f0d6fa437d726393bd0b2acc4248395074b60e0aafa9212c253f9a29017.scope
    128      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1db9bd89_05f0_4495_b78e_40b077361ae8.slice/cri-containerd-d70768fff67fd6b449e186ad60586ff7a882858882127932b418c62564a2206a.scope
    737      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1db9bd89_05f0_4495_b78e_40b077361ae8.slice/cri-containerd-9f754eefae7eaeb5a0a0a4a0caaa42c89bbb7b005bc44e5c14938544b13a0d8b.scope
    741      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71ab0256_66f3_4519_9222_6f33b9d2a044.slice/cri-containerd-b39166abc0aa4d983e3a5175df3ac1b377f690911cce3f3d0182ca9b66f20a0d.scope
    684      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71ab0256_66f3_4519_9222_6f33b9d2a044.slice/cri-containerd-c216158c28f043fc4964153ce4c446ebf7ff4518d8d46a42dd0204e46029c18c.scope
    688      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71ab0256_66f3_4519_9222_6f33b9d2a044.slice/cri-containerd-4345be577679247a30683d9b81ff69ce7c741827dbea05386285e9e22202d4c3.scope
    692      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71ab0256_66f3_4519_9222_6f33b9d2a044.slice/cri-containerd-e19ef8abe8221d025ac125a766fb0661022c23f03260157560f1e1ea85612e0a.scope
    668      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74c1e97c_0985_43d3_8ab5_7a08b1a4fcc3.slice/cri-containerd-81757a7efb99af377b0edb53c5b2677557fcef2a773b27f1498692e75e648e85.scope
    753      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74c1e97c_0985_43d3_8ab5_7a08b1a4fcc3.slice/cri-containerd-721522d2bc1d1192012fd1fa1666ca7a4e9d1b06e1718c653c89341ec2670e49.scope
    729      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74c1e97c_0985_43d3_8ab5_7a08b1a4fcc3.slice/cri-containerd-167fa657c7f567f3bafa8078ffb62c3818b373c1a13dc553e473e32a686f05bd.scope
    749      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e959407_ce2e_41f2_8367_274c035273a7.slice/cri-containerd-77aeaa4bffc53b419ba7460481dbdb1bfdace53d4c8e65bcbe040872675991e8.scope
    733      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e959407_ce2e_41f2_8367_274c035273a7.slice/cri-containerd-c0ce6b0393d7120f10af88e28facfbb839f9b22ba02c9d856025ef596113c14f.scope
    745      cgroup_device   multi                                          
