IP ADDRESS         LOCAL ENDPOINT INFO
10.82.0.125:0      id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72   
10.82.0.30:0       id=1631  sec_id=5478420 flags=0x0000 ifindex=14  mac=5A:C7:17:0F:27:9E nodemac=E2:65:65:41:76:7C   
10.82.0.97:0       (localhost)                                                                                        
10.82.0.175:0      id=2208  sec_id=5478420 flags=0x0000 ifindex=12  mac=46:BF:F3:F2:51:B2 nodemac=3E:02:08:1B:91:B0   
172.31.156.172:0   (localhost)                                                                                        
10.82.0.219:0      id=2511  sec_id=4     flags=0x0000 ifindex=10  mac=D2:04:8E:BF:03:AC nodemac=22:54:78:AD:82:96     
10.82.0.50:0       id=197   sec_id=5458880 flags=0x0000 ifindex=18  mac=36:C6:95:FD:F1:C1 nodemac=6A:27:92:CC:BF:A8   
10.82.0.18:0       id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5   
10.82.0.82:0       id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2   
172.31.155.29:0    (localhost)                                                                                        
