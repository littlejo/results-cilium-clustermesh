1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:56:c4:c5:23:f1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.156.172/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3494sec preferred_lft 3494sec
    inet6 fe80::456:c4ff:fec5:23f1/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:61:81:94:c1:4b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.155.29/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::461:81ff:fe94:c14b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:cd:8a:0d:e2:ac brd ff:ff:ff:ff:ff:ff
    inet6 fe80::84cd:8aff:fe0d:e2ac/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:a8:e1:87:cc:7b brd ff:ff:ff:ff:ff:ff
    inet 10.82.0.97/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::4a8:e1ff:fe87:cc7b/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 92:80:59:9e:fc:3d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9080:59ff:fe9e:fc3d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:54:78:ad:82:96 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::2054:78ff:fead:8296/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc5a06480afe9c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:02:08:1b:91:b0 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::3c02:8ff:fe1b:91b0/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc21e78d023caf@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:65:65:41:76:7c brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::e065:65ff:fe41:767c/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc501f7c6a236c@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:27:92:cc:bf:a8 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::6827:92ff:fecc:bfa8/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcebc743bbbac4@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:55:9c:45:8f:a5 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::9855:9cff:fe45:8fa5/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc0abf52647c0a@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:a0:0f:e6:e0:e2 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::a0:fff:fee6:e0e2/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc20d6e042e1a8@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:2d:11:7f:10:72 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::9c2d:11ff:fe7f:1072/64 scope link 
       valid_lft forever preferred_lft forever
