{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.317Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.345Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.976Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.000Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.026Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.040Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.067Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.300Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.319Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.376Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.415Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.445Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.091Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.128Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.171Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.178Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.206Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.372Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.378Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.438Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.465Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.504Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.070Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.105Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.113Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.169Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.170Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.202Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.426Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.433Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.485Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.510Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.540Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.098Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.103Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.149Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.161Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.194Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.203Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.249Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.524Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.537Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.586Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.608Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.629Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.027Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.032Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.079Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.093Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.117Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.326Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.333Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.375Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.396Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.434Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.781Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.828Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.875Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.937Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.969Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.022Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.313Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.361Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.586Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.636Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.670Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.027Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.074Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.080Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.116Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.129Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.387Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.388Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.434Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.458Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.486Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.929Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.951Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.977Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.008Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.014Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.238Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.268Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.299Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.326Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.350Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.771Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.813Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.813Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.936Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.949Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.983Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.180Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.211Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.230Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.269Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.279Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.542Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.575Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.585Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.632Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.635Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.666Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.892Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.904Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.948Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.974Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.996Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.291Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.324Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.354Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.383Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.407Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.426Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.705Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.737Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.764Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.771Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.799Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.412Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.416Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.448Z",
  "value": "id=2545  sec_id=5444850 flags=0x0000 ifindex=20  mac=A2:63:66:C5:29:75 nodemac=9A:55:9C:45:8F:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.480Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.492Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.767Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.781Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.390Z",
  "value": "id=400   sec_id=5455655 flags=0x0000 ifindex=24  mac=4E:33:76:65:1E:D9 nodemac=9E:2D:11:7F:10:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.393Z",
  "value": "id=2235  sec_id=5465776 flags=0x0000 ifindex=22  mac=76:66:DE:E6:DA:B6 nodemac=02:A0:0F:E6:E0:E2"
}

