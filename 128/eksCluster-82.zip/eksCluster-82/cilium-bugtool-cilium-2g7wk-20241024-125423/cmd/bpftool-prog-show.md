35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:31+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:32+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:33+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:33+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:33+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:33+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:36+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:50+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
125: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
128: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
495: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
498: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
499: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
502: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
503: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,104
	btf_id 136
504: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 137
505: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 138
506: sched_cls  name tail_handle_ipv4  tag a7a456c5ae0d2842  gpl
	loaded_at 2024-10-24T12:30:23+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,104
	btf_id 139
536: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 175
541: sched_cls  name tail_handle_ipv4_cont  tag a102b8eb3b799bef  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,118,41,114,82,83,39,76,74,77,117,40,37,38,81
	btf_id 181
542: sched_cls  name tail_ipv4_ct_ingress  tag 41a58e92cc5eccc1  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 182
543: sched_cls  name tail_handle_arp  tag e845aae80856c3ec  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 183
544: sched_cls  name cil_from_container  tag ecb93d5c681a3bdf  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 117,76
	btf_id 184
549: sched_cls  name handle_policy  tag f1a3782c5eea3158  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,117,82,83,118,41,80,114,39,84,75,40,37,38
	btf_id 186
550: sched_cls  name __send_drop_notify  tag a405c5f2b00dbeb5  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 190
554: sched_cls  name tail_ipv4_to_endpoint  tag cbaf3500250d74dd  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,118,41,82,83,80,114,39,117,40,37,38
	btf_id 191
555: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 196
556: sched_cls  name tail_ipv4_to_endpoint  tag b703cf150521674e  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,120,41,82,83,80,91,39,119,40,37,38
	btf_id 195
557: sched_cls  name cil_from_container  tag 4702b421629b0448  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 119,76
	btf_id 197
558: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,119
	btf_id 199
559: sched_cls  name tail_handle_ipv4  tag e6ff4602df64eddc  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,119
	btf_id 200
560: sched_cls  name tail_handle_arp  tag 0b70085f0c1f5e3f  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,119
	btf_id 201
561: sched_cls  name tail_handle_ipv4  tag 7fabc663a103aaab  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 198
562: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 204
564: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,122
	btf_id 206
566: sched_cls  name tail_handle_ipv4_from_host  tag 06399840518e127d  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 208
567: sched_cls  name __send_drop_notify  tag a0a49b051dafceff  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 209
568: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 210
571: sched_cls  name tail_handle_ipv4_from_host  tag 06399840518e127d  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 214
572: sched_cls  name __send_drop_notify  tag a0a49b051dafceff  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 215
573: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 216
574: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 217
577: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,126,75
	btf_id 221
580: sched_cls  name tail_handle_ipv4_from_host  tag 06399840518e127d  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,126
	btf_id 224
581: sched_cls  name handle_policy  tag 2679d13f6f27f0e3  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,119,82,83,120,41,80,91,39,84,75,40,37,38
	btf_id 202
582: sched_cls  name __send_drop_notify  tag a0a49b051dafceff  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 225
583: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,126
	btf_id 226
584: sched_cls  name __send_drop_notify  tag a0a49b051dafceff  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 228
585: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,127
	btf_id 229
587: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,127,75
	btf_id 231
590: sched_cls  name tail_handle_ipv4_from_host  tag 06399840518e127d  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,127
	btf_id 235
591: sched_cls  name tail_ipv4_ct_egress  tag 0ef1efa106ab0424  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,119,82,83,120,84
	btf_id 232
592: sched_cls  name tail_handle_arp  tag f3afcdd3c2f711e2  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,129
	btf_id 237
594: sched_cls  name tail_ipv4_ct_ingress  tag b11a3ca74d6d2de4  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,119,82,83,120,84
	btf_id 239
595: sched_cls  name handle_policy  tag 0923cd52f1e26b76  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,129,82,83,130,41,80,105,39,84,75,40,37,38
	btf_id 240
596: sched_cls  name __send_drop_notify  tag 4eead6c93bfc04ef  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 241
597: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,129
	btf_id 242
599: sched_cls  name __send_drop_notify  tag f88e7229a1034b78  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 245
600: sched_cls  name tail_handle_ipv4  tag 87509f0052d53fc0  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,129
	btf_id 244
601: sched_cls  name tail_handle_ipv4_cont  tag 97fd508797da67a8  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,120,41,91,82,83,39,76,74,77,119,40,37,38,81
	btf_id 246
602: sched_cls  name cil_from_container  tag 9992f993f308e6b0  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 129,76
	btf_id 247
603: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
606: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
607: sched_cls  name tail_ipv4_to_endpoint  tag 9fbd6534e2686326  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,130,41,82,83,80,105,39,129,40,37,38
	btf_id 248
608: sched_cls  name tail_ipv4_ct_ingress  tag 4eb34d4d3a36c120  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,129,82,83,130,84
	btf_id 249
609: sched_cls  name tail_ipv4_ct_egress  tag 0ef1efa106ab0424  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,129,82,83,130,84
	btf_id 250
610: sched_cls  name tail_handle_ipv4_cont  tag 61b2fab69085455d  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,130,41,105,82,83,39,76,74,77,129,40,37,38,81
	btf_id 251
611: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
614: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
654: sched_cls  name tail_ipv4_ct_ingress  tag 537c8ab2f97c27ea  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,145,82,83,144,84
	btf_id 265
655: sched_cls  name tail_ipv4_ct_egress  tag b3e8935cc8c0272a  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,145,82,83,144,84
	btf_id 266
657: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,145
	btf_id 268
658: sched_cls  name __send_drop_notify  tag 6c1b1e334d481d03  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 269
659: sched_cls  name tail_handle_arp  tag 7f722a5888e85930  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,145
	btf_id 270
660: sched_cls  name handle_policy  tag df83d6401c589cda  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,145,82,83,144,41,80,143,39,84,75,40,37,38
	btf_id 271
661: sched_cls  name tail_handle_ipv4  tag 37e93d7be4b1a4f8  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,145
	btf_id 272
662: sched_cls  name cil_from_container  tag 0462fee9cbde71e4  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 145,76
	btf_id 273
663: sched_cls  name tail_handle_ipv4_cont  tag 365e62c4ca258edd  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,144,41,143,82,83,39,76,74,77,145,40,37,38,81
	btf_id 274
664: sched_cls  name tail_ipv4_to_endpoint  tag ae34fc947c64e1db  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,144,41,82,83,80,143,39,145,40,37,38
	btf_id 275
665: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
668: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
681: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
684: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
685: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
688: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
689: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
692: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
726: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
729: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
730: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
733: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
734: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
737: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
738: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
741: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
742: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
745: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
746: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
749: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
750: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
753: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3306: sched_cls  name tail_handle_ipv4_cont  tag f53a559952c96dea  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,633,41,153,82,83,39,76,74,77,634,40,37,38,81
	btf_id 3097
3307: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,634
	btf_id 3098
3308: sched_cls  name __send_drop_notify  tag 473b0f97e61fbea6  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3099
3309: sched_cls  name tail_ipv4_ct_ingress  tag d081903598c646be  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3100
3313: sched_cls  name handle_policy  tag 03089bece6ae5db8  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,634,82,83,633,41,80,153,39,84,75,40,37,38
	btf_id 3101
3315: sched_cls  name tail_ipv4_to_endpoint  tag 27bad4cae3b6dcba  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,633,41,82,83,80,153,39,634,40,37,38
	btf_id 3107
3319: sched_cls  name cil_from_container  tag 55a69eada4f40da3  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 634,76
	btf_id 3111
3321: sched_cls  name tail_handle_ipv4  tag 6fdb85bd7f9f21b3  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,634
	btf_id 3112
3322: sched_cls  name tail_handle_arp  tag b0c3d47f5490b83c  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,634
	btf_id 3115
3323: sched_cls  name tail_ipv4_ct_egress  tag 3ff03cca4e441a26  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3116
3361: sched_cls  name tail_ipv4_ct_ingress  tag 31f3b8313e318305  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,644,82,83,643,84
	btf_id 3157
3362: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,646
	btf_id 3159
3363: sched_cls  name tail_handle_arp  tag 8d5cf5c0e743c944  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,646
	btf_id 3161
3364: sched_cls  name tail_handle_ipv4_cont  tag 16be5dc4b968b909  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,643,41,157,82,83,39,76,74,77,644,40,37,38,81
	btf_id 3160
3365: sched_cls  name __send_drop_notify  tag d33b3d4eb65fa9bf  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3163
3367: sched_cls  name tail_handle_arp  tag d2ecf39ef3c3024e  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,644
	btf_id 3165
3368: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,644
	btf_id 3166
3369: sched_cls  name tail_ipv4_ct_egress  tag 7d73c8b55c7badf5  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,646,82,83,645,84
	btf_id 3162
3370: sched_cls  name cil_from_container  tag c968c6c35924f9b0  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 646,76
	btf_id 3167
3371: sched_cls  name tail_handle_ipv4  tag 8a84f48a827cad25  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,644
	btf_id 3168
3372: sched_cls  name tail_ipv4_ct_egress  tag c215100583cf2e77  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,644,82,83,643,84
	btf_id 3170
3373: sched_cls  name cil_from_container  tag 35572b796276eb81  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 644,76
	btf_id 3171
3374: sched_cls  name tail_ipv4_to_endpoint  tag b3cdb33ca52c384e  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,645,41,82,83,80,156,39,646,40,37,38
	btf_id 3169
3375: sched_cls  name tail_ipv4_to_endpoint  tag 5f7b7f7a64a8910f  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,643,41,82,83,80,157,39,644,40,37,38
	btf_id 3172
3376: sched_cls  name tail_handle_ipv4  tag 0ccb51fe45fd03fb  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,646
	btf_id 3173
3377: sched_cls  name tail_ipv4_ct_ingress  tag 0b5f8ca59daf1a0c  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,646,82,83,645,84
	btf_id 3175
3378: sched_cls  name handle_policy  tag befd83245d1756fa  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,646,82,83,645,41,80,156,39,84,75,40,37,38
	btf_id 3176
3380: sched_cls  name handle_policy  tag ca7d7ea47b993f8e  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,644,82,83,643,41,80,157,39,84,75,40,37,38
	btf_id 3174
3381: sched_cls  name tail_handle_ipv4_cont  tag 487341a073a26916  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,645,41,156,82,83,39,76,74,77,646,40,37,38,81
	btf_id 3178
3382: sched_cls  name __send_drop_notify  tag 4cee57690f0fe956  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3179
