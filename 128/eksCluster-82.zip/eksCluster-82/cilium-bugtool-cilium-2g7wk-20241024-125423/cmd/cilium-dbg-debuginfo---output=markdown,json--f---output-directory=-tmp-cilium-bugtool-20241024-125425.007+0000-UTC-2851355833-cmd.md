markdown output at /tmp/cilium-bugtool-20241024-125425.007+0000-UTC-2851355833/cmd/cilium-debuginfo-20241024-125425.671+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125425.007+0000-UTC-2851355833/cmd/cilium-debuginfo-20241024-125425.671+0000-UTC.json
