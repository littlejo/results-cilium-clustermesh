qdisc noqueue 0: dev lo root refcnt 2 
qdisc mq 0: dev ens5 root 
qdisc fq_codel 0: dev ens5 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens5 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens5 parent ffff:fff1 
qdisc mq 0: dev ens6 root 
qdisc fq_codel 0: dev ens6 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens6 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens6 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
qdisc noqueue 0: dev lxc5a06480afe9c root refcnt 2 
qdisc clsact ffff: dev lxc5a06480afe9c parent ffff:fff1 
qdisc noqueue 0: dev lxc21e78d023caf root refcnt 2 
qdisc clsact ffff: dev lxc21e78d023caf parent ffff:fff1 
qdisc noqueue 0: dev lxc501f7c6a236c root refcnt 2 
qdisc clsact ffff: dev lxc501f7c6a236c parent ffff:fff1 
qdisc noqueue 0: dev lxcebc743bbbac4 root refcnt 2 
qdisc clsact ffff: dev lxcebc743bbbac4 parent ffff:fff1 
qdisc noqueue 0: dev lxc0abf52647c0a root refcnt 2 
qdisc clsact ffff: dev lxc0abf52647c0a parent ffff:fff1 
qdisc noqueue 0: dev lxc20d6e042e1a8 root refcnt 2 
qdisc clsact ffff: dev lxc20d6e042e1a8 parent ffff:fff1 
