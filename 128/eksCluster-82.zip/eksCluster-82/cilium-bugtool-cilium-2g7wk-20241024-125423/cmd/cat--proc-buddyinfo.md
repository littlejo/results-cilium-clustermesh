Node 0, zone      DMA      2      7      2      2      4      3      4      2      3      1     53 
Node 0, zone   Normal    167      7      9      1     14     16     13      6      2      1      7 
