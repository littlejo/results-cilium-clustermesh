xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 577
ens6(5) clsact/ingress cil_from_netdev-ens6 id 587
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 574
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 562
cilium_host(7) clsact/egress cil_from_host-cilium_host id 564
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 503
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 504
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 544
lxc5a06480afe9c(12) clsact/ingress cil_from_container-lxc5a06480afe9c id 557
lxc21e78d023caf(14) clsact/ingress cil_from_container-lxc21e78d023caf id 602
lxc501f7c6a236c(18) clsact/ingress cil_from_container-lxc501f7c6a236c id 662
lxcebc743bbbac4(20) clsact/ingress cil_from_container-lxcebc743bbbac4 id 3319
lxc0abf52647c0a(22) clsact/ingress cil_from_container-lxc0abf52647c0a id 3370
lxc20d6e042e1a8(24) clsact/ingress cil_from_container-lxc20d6e042e1a8 id 3373

flow_dissector:

netfilter:

