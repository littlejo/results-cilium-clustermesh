top - 12:54:25 up 31 min,  0 users,  load average: 0.26, 0.38, 0.22
Tasks:   5 total,   1 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 25.9 us, 25.9 sy,  0.0 ni, 48.1 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    299.9 free,   1040.5 used,   2495.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2614.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 289600  78400 S  40.0   7.4   1:06.11 cilium-+
    396 root      20   0 1229744   9964   3836 S   0.0   0.3   0:04.41 cilium-+
   3220 root      20   0 1240432  16416  11228 S   0.0   0.4   0:00.02 cilium-+
   3255 root      20   0    6576   2420   2096 R   0.0   0.1   0:00.00 top
   3278 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
