KEY             VALUE
AgentLiveness   1919043601423
UTimeOffset     3378462007812500
