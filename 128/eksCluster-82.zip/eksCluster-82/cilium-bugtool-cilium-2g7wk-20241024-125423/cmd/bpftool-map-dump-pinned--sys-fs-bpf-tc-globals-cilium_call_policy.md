key: c5 00 00 00  value: 94 02 00 00
key: 90 01 00 00  value: 34 0d 00 00
key: 5f 06 00 00  value: 53 02 00 00
key: a0 08 00 00  value: 45 02 00 00
key: bb 08 00 00  value: 32 0d 00 00
key: cf 09 00 00  value: 25 02 00 00
key: f1 09 00 00  value: f1 0c 00 00
Found 7 elements
