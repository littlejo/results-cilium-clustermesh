filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcebc743bbbac4 direct-action not_in_hw id 3319 tag 55a69eada4f40da3 jited 
