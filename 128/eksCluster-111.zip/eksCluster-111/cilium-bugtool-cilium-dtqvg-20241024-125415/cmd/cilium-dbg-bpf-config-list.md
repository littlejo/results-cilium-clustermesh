KEY             VALUE
AgentLiveness   1894026656413
UTimeOffset     3378462097656250
