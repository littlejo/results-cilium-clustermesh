Endpoint ID: 362
Path: /sys/fs/bpf/tc/globals/cilium_policy_00362

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2856     29        0        
Allow    Ingress     1          ANY          NONE         disabled    125557   1441      0        
Allow    Egress      0          ANY          NONE         disabled    18224    200       0        


Endpoint ID: 761
Path: /sys/fs/bpf/tc/globals/cilium_policy_00761

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    376795   4394      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 967
Path: /sys/fs/bpf/tc/globals/cilium_policy_00967

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1301
Path: /sys/fs/bpf/tc/globals/cilium_policy_01301

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1403
Path: /sys/fs/bpf/tc/globals/cilium_policy_01403

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3040     31        0        
Allow    Ingress     1          ANY          NONE         disabled    126283   1452      0        
Allow    Egress      0          ANY          NONE         disabled    18293    200       0        


Endpoint ID: 2940
Path: /sys/fs/bpf/tc/globals/cilium_policy_02940

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6135326   61044     0        
Allow    Ingress     1          ANY          NONE         disabled    5163172   54398     0        
Allow    Egress      0          ANY          NONE         disabled    6099264   61043     0        


Endpoint ID: 3491
Path: /sys/fs/bpf/tc/globals/cilium_policy_03491

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3807
Path: /sys/fs/bpf/tc/globals/cilium_policy_03807

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6228892   76817     0        
Allow    Ingress     1          ANY          NONE         disabled    59789     722       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


