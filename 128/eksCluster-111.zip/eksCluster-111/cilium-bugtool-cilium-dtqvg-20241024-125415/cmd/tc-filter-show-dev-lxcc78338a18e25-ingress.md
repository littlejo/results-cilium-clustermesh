filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc78338a18e25 direct-action not_in_hw id 3379 tag f5431e9a349153a9 jited 
