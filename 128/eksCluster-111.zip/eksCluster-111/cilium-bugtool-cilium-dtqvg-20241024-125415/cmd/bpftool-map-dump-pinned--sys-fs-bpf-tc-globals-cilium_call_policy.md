key: 6a 01 00 00  value: 3a 02 00 00
key: f9 02 00 00  value: ee 0c 00 00
key: c7 03 00 00  value: 30 0d 00 00
key: 15 05 00 00  value: 34 0d 00 00
key: 7b 05 00 00  value: 16 02 00 00
key: 7c 0b 00 00  value: 89 02 00 00
key: df 0e 00 00  value: 44 02 00 00
Found 7 elements
