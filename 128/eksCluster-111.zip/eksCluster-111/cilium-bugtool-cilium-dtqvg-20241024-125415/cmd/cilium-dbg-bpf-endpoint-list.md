IP ADDRESS         LOCAL ENDPOINT INFO
10.111.0.170:0     id=3807  sec_id=4     flags=0x0000 ifindex=10  mac=86:C5:06:3C:5C:93 nodemac=6A:EC:8C:A0:C0:C7     
10.111.0.4:0       id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0   
172.31.253.175:0   (localhost)                                                                                        
10.111.0.32:0      id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58   
172.31.207.173:0   (localhost)                                                                                        
10.111.0.239:0     (localhost)                                                                                        
10.111.0.48:0      id=2940  sec_id=7385191 flags=0x0000 ifindex=18  mac=2E:62:4F:FF:EF:BD nodemac=3A:25:A4:76:7A:32   
10.111.0.71:0      id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40   
10.111.0.128:0     id=1403  sec_id=7370249 flags=0x0000 ifindex=12  mac=E2:13:FF:AA:9A:EB nodemac=8E:BA:65:22:64:89   
10.111.0.222:0     id=362   sec_id=7370249 flags=0x0000 ifindex=14  mac=A6:C3:0F:4E:0E:7E nodemac=7E:F0:7E:B6:65:6A   
