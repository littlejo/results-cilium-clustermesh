Node 0, zone      DMA     81     81     33     48     22     11      4      2      2      2     43 
Node 0, zone   Normal    309      5      1     17      9      5      4      2      3      3      7 
