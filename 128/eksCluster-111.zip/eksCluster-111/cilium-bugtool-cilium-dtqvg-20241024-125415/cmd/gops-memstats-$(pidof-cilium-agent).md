alloc: 135.62MB (142205808 bytes)
total-alloc: 3.04GB (3268742088 bytes)
sys: 227.07MB (238101844 bytes)
lookups: 0
mallocs: 74371650
frees: 73087749
heap-alloc: 135.62MB (142205808 bytes)
heap-sys: 180.64MB (189415424 bytes)
heap-idle: 23.64MB (24788992 bytes)
heap-in-use: 157.00MB (164626432 bytes)
heap-released: 7.07MB (7413760 bytes)
heap-objects: 1283901
stack-in-use: 35.31MB (37027840 bytes)
stack-sys: 35.31MB (37027840 bytes)
stack-mspan-inuse: 2.33MB (2443040 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 750.31KB (768313 bytes)
gc-sys: 5.54MB (5807248 bytes)
next-gc: when heap-alloc >= 146.21MB (153311448 bytes)
last-gc: 2024-10-24 12:54:15.342493961 +0000 UTC
gc-pause-total: 15.941626ms
gc-pause: 102401
gc-pause-end: 1729774455342493961
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0006687361575858716
enable-gc: true
debug-gc: false
