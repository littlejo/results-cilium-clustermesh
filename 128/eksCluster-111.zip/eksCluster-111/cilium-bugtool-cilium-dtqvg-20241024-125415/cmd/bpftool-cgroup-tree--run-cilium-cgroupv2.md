CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod11317680_d4a5_4a7e_a4e4_8f0730e0bb2e.slice/cri-containerd-799e92eb7e83b6b65ad1e425638c225721bc1c7e1f5f75b52e6ab9b677b3a108.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod11317680_d4a5_4a7e_a4e4_8f0730e0bb2e.slice/cri-containerd-455883b80139dd27074bec81ad700ea7b764d4323cb1bf3e83502d32d26f8887.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod22ef1b28_6a6a_48f7_a6c4_dfad0a3096ea.slice/cri-containerd-1e17a2dd194fd21c0ea96ae0cde20cbc065398d39111e5a1324bc92129ba03c9.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod22ef1b28_6a6a_48f7_a6c4_dfad0a3096ea.slice/cri-containerd-904b13db5dc54db849139efb64059c6a20a81e960cb5d8cf22cffb023555e6a0.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod57f715a7_db93_4640_95ef_e40d595a71d7.slice/cri-containerd-40184435dc5a199484433d14683018601db33e924052567e0603defac7644a9e.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod57f715a7_db93_4640_95ef_e40d595a71d7.slice/cri-containerd-1891955f25c7db4d475245028e59bd0b08b2d187e8219c75ddc110eebda8f238.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3a571255_42b1_4821_98d8_1fb1b1735574.slice/cri-containerd-b9b7e3de00f8d2099ec9c7be441fb9d515305f3e264bc18613a8a75a6ddc7ebe.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3a571255_42b1_4821_98d8_1fb1b1735574.slice/cri-containerd-18620c597411772e47471322bd39e373457aaddb67db92301e64279a67235875.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aab0fe0_02ce_4b4c_aa2c_ebaef32354e5.slice/cri-containerd-f43490972b22bd1b30975d3149955926e8ca7f759cf1b13fd2cb9d0c1bc4539f.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aab0fe0_02ce_4b4c_aa2c_ebaef32354e5.slice/cri-containerd-13fde7fe6733a23dfee2c8bbcdfd4cd37e6249832b6754d266b53b64eae74c32.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a1704eb_cc90_4e2d_ba30_4ece0c53b5e7.slice/cri-containerd-3faae1ff47526f78f72d506bf362b53c22976106fb50ffb2a3bb07b64c2dadd9.scope
    734      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a1704eb_cc90_4e2d_ba30_4ece0c53b5e7.slice/cri-containerd-68f58fccea0aba549f81bae8464a0fc2ea8c8d24db58cd9771d1c9dbef291fd4.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4dc166eb_686e_4cde_a606_7da31f1d5bbb.slice/cri-containerd-d931864e55a78c98f05149586932a031a11e2467554b0d3dc249b744c069521b.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4dc166eb_686e_4cde_a606_7da31f1d5bbb.slice/cri-containerd-39e31d18e2895d66ad8deefa300ca4c8427931f185e7a3461df6080d8a630da6.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9cb16647_7d96_485a_b8ec_3f9b5a72dfe1.slice/cri-containerd-1eac682aa84feaccb79435d92cbf1073318b95ceb6b638898f6fc2816391f52a.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9cb16647_7d96_485a_b8ec_3f9b5a72dfe1.slice/cri-containerd-611f4db0dfd7ef220047ecb4292b292e242397060d9ac8640687bb6369ec5a14.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9cb16647_7d96_485a_b8ec_3f9b5a72dfe1.slice/cri-containerd-2308d6cae840a688ec5a5f10cf2f8db7d858f04b3cf0dc484923fc25967bc83b.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9cb16647_7d96_485a_b8ec_3f9b5a72dfe1.slice/cri-containerd-13df63b227d092848367d48c899b41c0a951adc52a781f5e084fcf1dfe0e8872.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcbad9b95_53d6_4d4d_856e_05df5727202e.slice/cri-containerd-2270dcc194750006e070da31917756519d2da79c8b87b73c9ed7ccc136b53e0d.scope
    742      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcbad9b95_53d6_4d4d_856e_05df5727202e.slice/cri-containerd-d42d40f2fb0afdeb022cfaef5f6fe52d01dd1f486150e7d6a9b07e0f2aed4ec2.scope
    738      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcbad9b95_53d6_4d4d_856e_05df5727202e.slice/cri-containerd-eada35e96db3a6d0358d3fe780740afeff772134f844d589fe9422ec3717ae3d.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23b1e2bf_4e7e_4830_8831_405e99c4b321.slice/cri-containerd-7bcfa014798b3c8bef9d69235c709a1825546ffb2a79d0557e6574c62690afef.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23b1e2bf_4e7e_4830_8831_405e99c4b321.slice/cri-containerd-6bc42f63877486574b0866a8f9e7ee69dc092f56b3b257b5156d00f66301f8b4.scope
    101      cgroup_device   multi                                          
