xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 557
ens6(5) clsact/ingress cil_from_netdev-ens6 id 568
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 547
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 544
cilium_host(7) clsact/egress cil_from_host-cilium_host id 542
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 583
lxc86c61a26c43f(12) clsact/ingress cil_from_container-lxc86c61a26c43f id 523
lxc5c2870d9b60a(14) clsact/ingress cil_from_container-lxc5c2870d9b60a id 578
lxcc064ab5f2cc8(18) clsact/ingress cil_from_container-lxcc064ab5f2cc8 id 645
lxc5652f2ce4470(20) clsact/ingress cil_from_container-lxc5652f2ce4470 id 3311
lxcf5d980489dd9(22) clsact/ingress cil_from_container-lxcf5d980489dd9 id 3372
lxcc78338a18e25(24) clsact/ingress cil_from_container-lxcc78338a18e25 id 3379

flow_dissector:

netfilter:

