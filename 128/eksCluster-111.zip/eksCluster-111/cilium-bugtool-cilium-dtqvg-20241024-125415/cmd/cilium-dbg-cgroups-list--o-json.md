[
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod11317680_d4a5_4a7e_a4e4_8f0730e0bb2e.slice/cri-containerd-799e92eb7e83b6b65ad1e425638c225721bc1c7e1f5f75b52e6ab9b677b3a108.scope"
      }
    ],
    "ips": [
      "10.111.0.222"
    ],
    "name": "coredns-cc6ccd49c-4z4xv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcbad9b95_53d6_4d4d_856e_05df5727202e.slice/cri-containerd-d42d40f2fb0afdeb022cfaef5f6fe52d01dd1f486150e7d6a9b07e0f2aed4ec2.scope"
      },
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcbad9b95_53d6_4d4d_856e_05df5727202e.slice/cri-containerd-2270dcc194750006e070da31917756519d2da79c8b87b73c9ed7ccc136b53e0d.scope"
      }
    ],
    "ips": [
      "10.111.0.32"
    ],
    "name": "echo-same-node-86d9cc975c-t8rgd",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aab0fe0_02ce_4b4c_aa2c_ebaef32354e5.slice/cri-containerd-13fde7fe6733a23dfee2c8bbcdfd4cd37e6249832b6754d266b53b64eae74c32.scope"
      }
    ],
    "ips": [
      "10.111.0.71"
    ],
    "name": "client2-57cf4468f-6f5jf",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a1704eb_cc90_4e2d_ba30_4ece0c53b5e7.slice/cri-containerd-3faae1ff47526f78f72d506bf362b53c22976106fb50ffb2a3bb07b64c2dadd9.scope"
      }
    ],
    "ips": [
      "10.111.0.4"
    ],
    "name": "client-974f6c69d-74cdd",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9cb16647_7d96_485a_b8ec_3f9b5a72dfe1.slice/cri-containerd-611f4db0dfd7ef220047ecb4292b292e242397060d9ac8640687bb6369ec5a14.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9cb16647_7d96_485a_b8ec_3f9b5a72dfe1.slice/cri-containerd-1eac682aa84feaccb79435d92cbf1073318b95ceb6b638898f6fc2816391f52a.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9cb16647_7d96_485a_b8ec_3f9b5a72dfe1.slice/cri-containerd-13df63b227d092848367d48c899b41c0a951adc52a781f5e084fcf1dfe0e8872.scope"
      }
    ],
    "ips": [
      "10.111.0.48"
    ],
    "name": "clustermesh-apiserver-9554f7f88-wrwnk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod57f715a7_db93_4640_95ef_e40d595a71d7.slice/cri-containerd-40184435dc5a199484433d14683018601db33e924052567e0603defac7644a9e.scope"
      }
    ],
    "ips": [
      "10.111.0.128"
    ],
    "name": "coredns-cc6ccd49c-zfnxg",
    "namespace": "kube-system"
  }
]

