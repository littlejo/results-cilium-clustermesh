 12:54:16 up 31 min,  0 users,  load average: 0.30, 0.44, 0.30
