{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.608Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.191Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.238Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.252Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.297Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.304Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.334Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.575Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.576Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.707Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.708Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.774Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.257Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.261Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.313Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.317Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.350Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.555Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.563Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.628Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.632Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.676Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.191Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.197Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.228Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.240Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.278Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.284Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.318Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.587Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.600Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.663Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.674Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.708Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.265Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.273Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.299Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.321Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.362Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.381Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.396Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.600Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.607Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.679Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.695Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.734Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.151Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.159Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.203Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.210Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.239Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.473Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.489Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.541Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.552Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.595Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.968Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.000Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.018Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.132Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.162Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.180Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.366Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.377Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.438Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.462Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.506Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.896Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.948Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.963Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.993Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.004Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.033Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.273Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.283Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.334Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.361Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.378Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.794Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.826Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.856Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.894Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.897Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.173Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.220Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.313Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.325Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.366Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.714Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.771Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.779Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.845Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.858Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.883Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.091Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.099Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.164Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.177Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.201Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.514Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.517Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.557Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.583Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.611Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.861Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.867Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.917Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.941Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.965Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.264Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.319Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.345Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.431Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.450Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.478Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.662Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.684Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.688Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.720Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.486Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.489Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.520Z",
  "value": "id=761   sec_id=7352070 flags=0x0000 ifindex=20  mac=92:17:42:9D:3B:A1 nodemac=DE:C1:EA:F1:49:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.551Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.563Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.853Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.866Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.610Z",
  "value": "id=967   sec_id=7379131 flags=0x0000 ifindex=24  mac=E6:D5:D1:5B:D9:EA nodemac=9E:66:9D:4C:E5:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:31.611Z",
  "value": "id=1301  sec_id=7343636 flags=0x0000 ifindex=22  mac=FE:FF:31:E3:37:26 nodemac=1A:BB:CF:86:BD:D0"
}

