top - 12:54:17 up 31 min,  0 users,  load average: 0.30, 0.44, 0.30
Tasks:  10 total,   3 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 43.3 us, 40.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi, 16.7 si,  0.0 st
MiB Mem :   3836.2 total,    262.5 free,   1075.3 used,   2498.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2579.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 293804  80192 S  26.7   7.5   1:05.11 cilium-+
   3287 root      20   0 1244340  20212  13888 S  20.0   0.5   0:00.03 hubble
   3190 root      20   0 1229640  22624   4004 S  13.3   0.6   0:00.02 gops
   3192 root      20   0 1240432  15984  10972 S   6.7   0.4   0:00.03 cilium-+
    414 root      20   0 1229744   9036   2864 S   0.0   0.2   0:04.47 cilium-+
   3222 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3279 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
   3280 root      20   0    2208    792    716 S   0.0   0.0   0:00.00 timeout
   3303 root      20   0 1539912   8324   6260 R   0.0   0.2   0:00.00 runc:[2+
   3315 root      20   0    3728    488    436 R   0.0   0.0   0:00.00 bash
