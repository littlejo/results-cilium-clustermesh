35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:18+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:23:18+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:23:19+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:23:19+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:23:19+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:19+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:23:23+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:23:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:23:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:32:50+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 124
485: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:32:50+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
486: sched_cls  name tail_handle_ipv4  tag 989a8c471c7f9530  gpl
	loaded_at 2024-10-24T12:32:50+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
487: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:32:50+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
518: sched_cls  name tail_handle_arp  tag 06ff68e4852bccf5  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 165
519: sched_cls  name tail_handle_ipv4  tag 520da3c9618a19c0  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 166
521: sched_cls  name tail_ipv4_ct_egress  tag 90683afeb7ef8754  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 167
523: sched_cls  name cil_from_container  tag 4c93b63657b0dd87  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 169
527: sched_cls  name tail_ipv4_to_endpoint  tag 7b20d3be17477a81  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,111,40,37,38
	btf_id 171
530: sched_cls  name tail_ipv4_ct_ingress  tag 8a1af68447d19a10  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 175
534: sched_cls  name handle_policy  tag b776fdf61d9cde2c  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 178
535: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 181
536: sched_cls  name __send_drop_notify  tag 3b05d966eb3a9e5e  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 182
537: sched_cls  name tail_handle_ipv4_cont  tag 2c510f4239c62c29  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,111,40,37,38,81
	btf_id 183
538: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 187
540: sched_cls  name __send_drop_notify  tag 6104148df70e3ab7  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 189
541: sched_cls  name tail_handle_ipv4_cont  tag e943a95e5dac83ed  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 185
542: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 190
544: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 193
545: sched_cls  name tail_handle_ipv4_from_host  tag 2380144cc9bc04eb  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 194
547: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 197
548: sched_cls  name tail_handle_ipv4_from_host  tag 2380144cc9bc04eb  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 198
549: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 199
551: sched_cls  name __send_drop_notify  tag 6104148df70e3ab7  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
555: sched_cls  name tail_handle_ipv4_from_host  tag 2380144cc9bc04eb  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 206
556: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 207
557: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 208
558: sched_cls  name __send_drop_notify  tag 6104148df70e3ab7  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 209
559: sched_cls  name tail_handle_ipv4  tag 85f1c9179fa280fb  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 191
561: sched_cls  name tail_handle_arp  tag 6001f995c077dd51  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 211
562: sched_cls  name __send_drop_notify  tag 6104148df70e3ab7  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 213
566: sched_cls  name tail_handle_ipv4_from_host  tag 2380144cc9bc04eb  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 218
567: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 219
568: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 220
569: sched_cls  name tail_handle_ipv4  tag 3a5db2c8c0b2856f  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 222
570: sched_cls  name handle_policy  tag 192d198247dbbf89  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 217
571: sched_cls  name tail_ipv4_to_endpoint  tag 6471f75b0d594604  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,126,41,82,83,80,100,39,125,40,37,38
	btf_id 223
572: sched_cls  name tail_ipv4_ct_ingress  tag 3e43c1996be32b20  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 224
574: sched_cls  name tail_handle_ipv4_cont  tag 3a7f7620220e9100  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,126,41,100,82,83,39,76,74,77,125,40,37,38,81
	btf_id 225
575: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 227
576: sched_cls  name tail_ipv4_to_endpoint  tag 22724479cad37567  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 229
577: sched_cls  name tail_ipv4_ct_egress  tag 90683afeb7ef8754  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 230
578: sched_cls  name cil_from_container  tag 4906d22bcd43c245  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 231
579: sched_cls  name __send_drop_notify  tag 047f8a141a83e4a7  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 232
580: sched_cls  name handle_policy  tag f5a2d11725c94957  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,125,82,83,126,41,80,100,39,84,75,40,37,38
	btf_id 228
581: sched_cls  name __send_drop_notify  tag 49fa9c7ba5e5af74  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 233
582: sched_cls  name tail_handle_arp  tag a68c7e73089d04f6  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 234
583: sched_cls  name cil_from_container  tag 75bc07498e7d9eb6  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 125,76
	btf_id 235
584: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 236
585: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 237
586: sched_cls  name tail_ipv4_ct_ingress  tag 7c1d69599c6aee6a  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 238
588: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
591: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
592: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
595: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
596: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
599: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
644: sched_cls  name tail_handle_arp  tag d3f56650d8fb0d37  gpl
	loaded_at 2024-10-24T12:42:33+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 254
645: sched_cls  name cil_from_container  tag e3cdcaf13685d91d  gpl
	loaded_at 2024-10-24T12:42:33+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 255
646: sched_cls  name tail_ipv4_ct_ingress  tag 20704b89b9a8cc14  gpl
	loaded_at 2024-10-24T12:42:33+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 256
647: sched_cls  name __send_drop_notify  tag 2cccffabed2b0427  gpl
	loaded_at 2024-10-24T12:42:33+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 257
648: sched_cls  name tail_ipv4_to_endpoint  tag e72d55222b0b9b23  gpl
	loaded_at 2024-10-24T12:42:33+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 258
649: sched_cls  name handle_policy  tag cdceadf5e34cd5c2  gpl
	loaded_at 2024-10-24T12:42:33+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 259
650: sched_cls  name tail_handle_ipv4  tag b8c86b7cf47b71d8  gpl
	loaded_at 2024-10-24T12:42:33+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 260
651: sched_cls  name tail_ipv4_ct_egress  tag e76d427454133b56  gpl
	loaded_at 2024-10-24T12:42:33+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 261
652: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:33+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 262
653: sched_cls  name tail_handle_ipv4_cont  tag c82d454fdbca6fbd  gpl
	loaded_at 2024-10-24T12:42:33+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 263
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
670: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
673: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
674: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
677: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
678: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
681: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
715: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
718: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
719: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
722: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
723: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
726: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
727: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
730: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
731: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
734: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
735: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
738: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
739: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
742: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3306: sched_cls  name tail_ipv4_ct_egress  tag 82efe06196dcc124  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3097
3307: sched_cls  name tail_handle_ipv4_cont  tag a98d5c2ca578b8b5  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,634,41,151,82,83,39,76,74,77,633,40,37,38,81
	btf_id 3098
3310: sched_cls  name handle_policy  tag dfc5eb575f847ecd  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,633,82,83,634,41,80,151,39,84,75,40,37,38
	btf_id 3099
3311: sched_cls  name cil_from_container  tag a4bff56a33153d51  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 633,76
	btf_id 3104
3313: sched_cls  name tail_handle_arp  tag 6b8baf9c59128b57  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,633
	btf_id 3106
3315: sched_cls  name tail_ipv4_ct_ingress  tag c0556cc306f32a99  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3107
3317: sched_cls  name tail_handle_ipv4  tag 8de04a8f56c129db  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,633
	btf_id 3109
3318: sched_cls  name tail_ipv4_to_endpoint  tag c13944a8d4ffb327  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,634,41,82,83,80,151,39,633,40,37,38
	btf_id 3111
3319: sched_cls  name __send_drop_notify  tag d498c6b9a198c4ff  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3112
3320: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,633
	btf_id 3113
3361: sched_cls  name __send_drop_notify  tag 7d6bc1b1b8e235b3  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3158
3363: sched_cls  name tail_handle_arp  tag b27de8b07a2a3416  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,646
	btf_id 3160
3364: sched_cls  name tail_ipv4_ct_egress  tag d1909322fd091126  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 6128B  jited 4720B  memlock 8192B  map_ids 76,643,82,83,645,84
	btf_id 3161
3365: sched_cls  name tail_handle_ipv4  tag 1a9aadefa9bd6ce3  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,646
	btf_id 3162
3366: sched_cls  name tail_handle_ipv4_cont  tag c8ef5d2f8a72bf5a  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 9672B  jited 6312B  memlock 12288B  map_ids 75,645,41,154,82,83,39,76,74,77,643,40,37,38,81
	btf_id 3163
3367: sched_cls  name tail_ipv4_ct_ingress  tag e13d8e44c0952966  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,646,82,83,644,84
	btf_id 3164
3368: sched_cls  name tail_ipv4_ct_egress  tag 440d43c4c0edf944  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,646,82,83,644,84
	btf_id 3166
3369: sched_cls  name tail_handle_ipv4  tag f83d5f52101037d1  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,643
	btf_id 3165
3370: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,646
	btf_id 3167
3371: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,643
	btf_id 3168
3372: sched_cls  name cil_from_container  tag 7f065e47a192db03  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 643,76
	btf_id 3170
3373: sched_cls  name tail_ipv4_to_endpoint  tag c4f99bb6cc0be3d9  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 8744B  jited 5752B  memlock 12288B  map_ids 75,76,645,41,82,83,80,154,39,643,40,37,38
	btf_id 3171
3374: sched_cls  name tail_handle_arp  tag e5c094e4b34e5c29  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,643
	btf_id 3172
3376: sched_cls  name handle_policy  tag 898750bda7985adb  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,646,82,83,644,41,80,157,39,84,75,40,37,38
	btf_id 3169
3377: sched_cls  name __send_drop_notify  tag 80bf7b38419a7f3b  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3175
3378: sched_cls  name tail_ipv4_to_endpoint  tag fcb0be3c3147d0f0  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,644,41,82,83,80,157,39,646,40,37,38
	btf_id 3176
3379: sched_cls  name cil_from_container  tag f5431e9a349153a9  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 646,76
	btf_id 3177
3380: sched_cls  name handle_policy  tag 1d5b2b551c96cef8  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 14680B  jited 10080B  memlock 16384B  map_ids 76,643,82,83,645,41,80,154,39,84,75,40,37,38
	btf_id 3174
3381: sched_cls  name tail_handle_ipv4_cont  tag 2519e440477000db  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,644,41,157,82,83,39,76,74,77,646,40,37,38,81
	btf_id 3178
3382: sched_cls  name tail_ipv4_ct_ingress  tag 53a77d8bdf5db5e2  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,643,82,83,645,84
	btf_id 3179
