alloc: 146.04MB (153134208 bytes)
total-alloc: 3.13GB (3360252264 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 75705534
frees: 74166003
heap-alloc: 146.04MB (153134208 bytes)
heap-sys: 170.27MB (178536448 bytes)
heap-idle: 9.18MB (9625600 bytes)
heap-in-use: 161.09MB (168910848 bytes)
heap-released: 3.30MB (3465216 bytes)
heap-objects: 1539531
stack-in-use: 37.44MB (39256064 bytes)
stack-sys: 37.44MB (39256064 bytes)
stack-mspan-inuse: 2.51MB (2636800 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 986.88KB (1010569 bytes)
gc-sys: 5.78MB (6057080 bytes)
next-gc: when heap-alloc >= 151.88MB (159260552 bytes)
last-gc: 2024-10-24 12:54:04.209743837 +0000 UTC
gc-pause-total: 14.714102ms
gc-pause: 76506
gc-pause-end: 1729774444209743837
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0005487956153118054
enable-gc: true
debug-gc: false
