top - 12:54:18 up 33 min,  0 users,  load average: 0.58, 0.63, 0.35
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 10.7 us, 21.4 sy,  0.0 ni, 67.9 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    287.6 free,   1051.7 used,   2496.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2603.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 296536  80440 S   6.7   7.5   1:03.92 cilium-+
   3336 root      20   0 1240432  16212  11228 S   6.7   0.4   0:00.03 cilium-+
    415 root      20   0 1229744   9940   3836 S   0.0   0.3   0:04.11 cilium-+
   3328 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
   3373 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3391 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
