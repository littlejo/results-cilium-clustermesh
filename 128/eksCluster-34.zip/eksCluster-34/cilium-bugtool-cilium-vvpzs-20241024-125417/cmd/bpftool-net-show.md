xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 576
ens6(5) clsact/ingress cil_from_netdev-ens6 id 583
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 570
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 562
cilium_host(7) clsact/egress cil_from_host-cilium_host id 565
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 514
lxc244e74ef7433(12) clsact/ingress cil_from_container-lxc244e74ef7433 id 548
lxc989344b6fb33(14) clsact/ingress cil_from_container-lxc989344b6fb33 id 524
lxc69416e197bee(18) clsact/ingress cil_from_container-lxc69416e197bee id 636
lxc2c1bdf23d918(20) clsact/ingress cil_from_container-lxc2c1bdf23d918 id 3362
lxc7795a7712cd8(22) clsact/ingress cil_from_container-lxc7795a7712cd8 id 3293
lxc21190f4f9d3a(24) clsact/ingress cil_from_container-lxc21190f4f9d3a id 3345

flow_dissector:

netfilter:

