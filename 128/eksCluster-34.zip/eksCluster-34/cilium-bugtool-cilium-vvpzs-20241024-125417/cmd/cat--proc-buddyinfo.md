Node 0, zone      DMA     47    132      8     34     13      5      1      2      3      4     41 
Node 0, zone   Normal    525     95     60      8     29     14     12      5      3      3      5 
