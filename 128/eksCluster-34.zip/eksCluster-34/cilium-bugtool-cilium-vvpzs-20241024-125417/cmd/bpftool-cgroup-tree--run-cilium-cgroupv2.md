CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod76f23174_3f3f_4a8b_bf06_63506824d7d5.slice/cri-containerd-595d9233c5860189dea753e72067846b6ae2a32b4f4d2e07bc854e00db910aac.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod76f23174_3f3f_4a8b_bf06_63506824d7d5.slice/cri-containerd-e204eff7d472b5355b3594f1f15ad040ab45d8388ecae347ca82e9803f30d39d.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0786cc4d_f5a2_4294_bb40_43c042fc4a91.slice/cri-containerd-6b973bf88b153f868a1b80c40e86245d6e946cf1ec355b055a0f12f423afdb8f.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0786cc4d_f5a2_4294_bb40_43c042fc4a91.slice/cri-containerd-65ac59014bdfc1ce4fbb30d71c9d5a46dc6966d32e942238892566de9b391c9d.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb595227e_32dc_4920_9acb_0135d4d7a35c.slice/cri-containerd-b671ff0db560ddce833b38e92db7ba9f9d7a946eb33835d35434f5563af3f064.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb595227e_32dc_4920_9acb_0135d4d7a35c.slice/cri-containerd-a491a91ab097227c498476e72284e84d59729543564d90cf566b1eba5850519b.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8c78f2fe_f31f_4e55_a8b5_6f848c77fb49.slice/cri-containerd-b04418c114c3aeb33943e64bb5fa484368619d74eb6b48d6b006b9f0af6e0245.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8c78f2fe_f31f_4e55_a8b5_6f848c77fb49.slice/cri-containerd-56dfda0e3d8f6da3dbc7bc2d646a04eadeedf934d33fd8f7765b3039853249c9.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb24e84b9_0c61_4139_b1e4_2da9db6d28d5.slice/cri-containerd-574a160ccb2ca049e53b3173432c49a6502b18ff505a51cb8a4cb8f3842f348e.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb24e84b9_0c61_4139_b1e4_2da9db6d28d5.slice/cri-containerd-da44a44ac8bdbb8d5e09943a83ec3ec811bd6382d3502afdec2798bfa9a2c64d.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod543adb5b_8f07_416a_84cb_1c9ae9355a30.slice/cri-containerd-277222f9c40014709cf30810e8c8d2f0df79a23ab7bfbc7aca6b319397c6155e.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod543adb5b_8f07_416a_84cb_1c9ae9355a30.slice/cri-containerd-5c4789f681b7dfe2d182abe5f911f161884410105777facdca31620f8571fc06.scope
    679      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6f7639e_8d8f_4f37_9994_d61fcb3ef3e7.slice/cri-containerd-410a2c9dfb1d35b81e1565383e6eb12abd57d4713a275c7de5bcbafa9d697bfb.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6f7639e_8d8f_4f37_9994_d61fcb3ef3e7.slice/cri-containerd-d49a309a4ce297b0bda797a9ca86514d42996eaa26175e6cc9f7fad55597df83.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd247d14f_7f18_4811_b26f_037b96f4b3c5.slice/cri-containerd-3352bad0b6b65900f3f3e74233d45c0b8040e92c86705cbc8def912a2bbbff34.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd247d14f_7f18_4811_b26f_037b96f4b3c5.slice/cri-containerd-6c9c1190156969dafca25fe0011b0d789a5464093372b15b072e6916e9fb0189.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod99b27463_d59a_4d98_b7a6_75dea2aa3401.slice/cri-containerd-d582ac0f4487bfd0e893b00d68e2b729f26ae5166d107f2083b2832cb9390fb7.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod99b27463_d59a_4d98_b7a6_75dea2aa3401.slice/cri-containerd-b5542eb0e5ecdc531abbacd7c871d9b99b3a81b07c231f1f5607ed97364c24ca.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod99b27463_d59a_4d98_b7a6_75dea2aa3401.slice/cri-containerd-622c4762ce1e6b501073584b61bcaa72f18ecdd0261a4b6814f52fba373fd4b7.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod99b27463_d59a_4d98_b7a6_75dea2aa3401.slice/cri-containerd-6106d1e5e18166498f6911b54f07cece9c068fe68aa14634bd25d01755bbda9c.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40d1dccb_2d99_4ade_9acf_d1d1c944e4ed.slice/cri-containerd-9d9d2e6f5d2cb6aa43249b6fe936b15af7b1b11c43973de5878ead4e4cea5d11.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40d1dccb_2d99_4ade_9acf_d1d1c944e4ed.slice/cri-containerd-7c9107d4c5f61562c5de5cdbe04540de4171013bc5c822a678101b7aa5ffb682.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40d1dccb_2d99_4ade_9acf_d1d1c944e4ed.slice/cri-containerd-949e80dee6f21a81db4d2cbe74068c17158898a4f7ac0096c6a5de5dbf1cf530.scope
    725      cgroup_device   multi                                          
