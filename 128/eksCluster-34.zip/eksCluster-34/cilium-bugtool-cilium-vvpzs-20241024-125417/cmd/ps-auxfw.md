USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3336  0.0  0.4 1240432 16212 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3361  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3363  0.0  0.0   2068   216 ?        R    12:54   0:00  \_ hostname
root        3328  0.0  0.0 1228744 3780 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  3.8  7.5 1539060 296536 ?      Ssl  12:26   1:03 cilium-agent --config-dir=/tmp/cilium/config-map
root         415  0.2  0.2 1229744 9940 ?        Sl   12:27   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
