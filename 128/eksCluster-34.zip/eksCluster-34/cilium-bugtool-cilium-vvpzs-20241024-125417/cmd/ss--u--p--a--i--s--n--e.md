Total: 568
TCP:   3964 (estab 290, closed 3654, orphaned 1, timewait 3194)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  310       301       9        
INET	  320       307       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                            127.0.0.1:42097      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:29218 sk:1001 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.166.19%ens5:68         0.0.0.0:*    uid:192 ino:93139 sk:1002 cgroup:unreachable:bd0 <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:29375 sk:1003 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15116 sk:1004 cgroup:unreachable:e8e <->                                    
UNCONN 0      0      [fe80::4d9:c7ff:fe7d:7fe7]%ens5:546           [::]:*    uid:192 ino:15319 sk:1005 cgroup:unreachable:bd0 v6only:1 <->                   
UNCONN 0      0                                 [::]:8472          [::]:*    ino:29374 sk:1006 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15117 sk:1007 cgroup:unreachable:e8e v6only:1 <->                           
