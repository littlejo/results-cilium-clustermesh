1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d9:c7:7d:7f:e7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.166.19/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3432sec preferred_lft 3432sec
    inet6 fe80::4d9:c7ff:fe7d:7fe7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:50:ff:dc:29:59 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.142.203/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::450:ffff:fedc:2959/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:58:d3:9f:36:f8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d058:d3ff:fe9f:36f8/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:2f:f6:80:b1:2f brd ff:ff:ff:ff:ff:ff
    inet 10.34.0.135/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::842f:f6ff:fe80:b12f/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether e6:4a:61:7a:ae:fb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e44a:61ff:fe7a:aefb/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:80:02:f7:35:90 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d880:2ff:fef7:3590/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc244e74ef7433@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:a1:2d:83:de:bf brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::90a1:2dff:fe83:debf/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc989344b6fb33@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:fc:8f:87:a4:95 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::c0fc:8fff:fe87:a495/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc69416e197bee@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:d3:15:c6:84:02 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::68d3:15ff:fec6:8402/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc2c1bdf23d918@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:9b:b5:89:34:19 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::249b:b5ff:fe89:3419/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc7795a7712cd8@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:2f:2b:98:e2:f4 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::202f:2bff:fe98:e2f4/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc21190f4f9d3a@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:f3:aa:b8:81:9a brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::74f3:aaff:feb8:819a/64 scope link 
       valid_lft forever preferred_lft forever
