key: 4f 00 00 00  value: 79 02 00 00
key: 2a 02 00 00  value: 07 02 00 00
key: e0 05 00 00  value: 1c 0d 00 00
key: 3b 06 00 00  value: 1f 0d 00 00
key: d9 07 00 00  value: 0d 02 00 00
key: 9a 0b 00 00  value: 1c 02 00 00
key: 97 0f 00 00  value: de 0c 00 00
Found 7 elements
