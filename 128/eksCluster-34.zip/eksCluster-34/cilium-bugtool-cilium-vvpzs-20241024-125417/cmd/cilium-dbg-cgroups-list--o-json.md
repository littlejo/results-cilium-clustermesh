[
  {
    "containers": [
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40d1dccb_2d99_4ade_9acf_d1d1c944e4ed.slice/cri-containerd-7c9107d4c5f61562c5de5cdbe04540de4171013bc5c822a678101b7aa5ffb682.scope"
      },
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40d1dccb_2d99_4ade_9acf_d1d1c944e4ed.slice/cri-containerd-949e80dee6f21a81db4d2cbe74068c17158898a4f7ac0096c6a5de5dbf1cf530.scope"
      }
    ],
    "ips": [
      "10.34.0.148"
    ],
    "name": "echo-same-node-86d9cc975c-j4qdt",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod76f23174_3f3f_4a8b_bf06_63506824d7d5.slice/cri-containerd-595d9233c5860189dea753e72067846b6ae2a32b4f4d2e07bc854e00db910aac.scope"
      }
    ],
    "ips": [
      "10.34.0.239"
    ],
    "name": "coredns-cc6ccd49c-pdl2p",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod543adb5b_8f07_416a_84cb_1c9ae9355a30.slice/cri-containerd-277222f9c40014709cf30810e8c8d2f0df79a23ab7bfbc7aca6b319397c6155e.scope"
      }
    ],
    "ips": [
      "10.34.0.136"
    ],
    "name": "client-974f6c69d-znhm8",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0786cc4d_f5a2_4294_bb40_43c042fc4a91.slice/cri-containerd-65ac59014bdfc1ce4fbb30d71c9d5a46dc6966d32e942238892566de9b391c9d.scope"
      }
    ],
    "ips": [
      "10.34.0.221"
    ],
    "name": "coredns-cc6ccd49c-794q4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6f7639e_8d8f_4f37_9994_d61fcb3ef3e7.slice/cri-containerd-410a2c9dfb1d35b81e1565383e6eb12abd57d4713a275c7de5bcbafa9d697bfb.scope"
      }
    ],
    "ips": [
      "10.34.0.101"
    ],
    "name": "client2-57cf4468f-6zg9s",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod99b27463_d59a_4d98_b7a6_75dea2aa3401.slice/cri-containerd-622c4762ce1e6b501073584b61bcaa72f18ecdd0261a4b6814f52fba373fd4b7.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod99b27463_d59a_4d98_b7a6_75dea2aa3401.slice/cri-containerd-d582ac0f4487bfd0e893b00d68e2b729f26ae5166d107f2083b2832cb9390fb7.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod99b27463_d59a_4d98_b7a6_75dea2aa3401.slice/cri-containerd-6106d1e5e18166498f6911b54f07cece9c068fe68aa14634bd25d01755bbda9c.scope"
      }
    ],
    "ips": [
      "10.34.0.209"
    ],
    "name": "clustermesh-apiserver-785784db84-nz6jk",
    "namespace": "kube-system"
  }
]

