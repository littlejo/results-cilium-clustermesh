IP ADDRESS         LOCAL ENDPOINT INFO
10.34.0.136:0      id=1504  sec_id=2310154 flags=0x0000 ifindex=20  mac=3E:94:3E:61:14:FE nodemac=26:9B:B5:89:34:19   
10.34.0.148:0      id=3991  sec_id=2351419 flags=0x0000 ifindex=22  mac=7A:5E:59:39:9A:36 nodemac=22:2F:2B:98:E2:F4   
10.34.0.101:0      id=1595  sec_id=2303026 flags=0x0000 ifindex=24  mac=F2:AE:17:D9:B3:CF nodemac=76:F3:AA:B8:81:9A   
172.31.142.203:0   (localhost)                                                                                        
10.34.0.239:0      id=2970  sec_id=2328115 flags=0x0000 ifindex=12  mac=C2:DA:3C:C0:99:84 nodemac=92:A1:2D:83:DE:BF   
10.34.0.135:0      (localhost)                                                                                        
172.31.166.19:0    (localhost)                                                                                        
10.34.0.204:0      id=554   sec_id=4     flags=0x0000 ifindex=10  mac=2E:C2:05:4C:9B:73 nodemac=DA:80:02:F7:35:90     
10.34.0.209:0      id=79    sec_id=2327556 flags=0x0000 ifindex=18  mac=76:D0:30:EE:C8:24 nodemac=6A:D3:15:C6:84:02   
10.34.0.221:0      id=2009  sec_id=2328115 flags=0x0000 ifindex=14  mac=F2:04:49:76:A0:49 nodemac=C2:FC:8F:87:A4:95   
