35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:22+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:22+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:22+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:22+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:22+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:21:23+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:21:24+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:21:24+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:21:24+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:24+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:21:28+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:21:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:21:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:21:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:27:06+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
485: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:27:06+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 125
486: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:27:06+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
487: sched_cls  name tail_handle_ipv4  tag 2477d352e5157474  gpl
	loaded_at 2024-10-24T12:27:06+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
507: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 151
508: sched_cls  name tail_handle_arp  tag 6b7a4d7f080fae96  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 152
511: sched_cls  name tail_handle_ipv4_cont  tag 06988210e2aec7b2  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,107,41,106,82,83,39,76,74,77,108,40,37,38,81
	btf_id 153
513: sched_cls  name tail_handle_ipv4  tag c3ba7c161bbc148c  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 156
514: sched_cls  name cil_from_container  tag b455acdbfddf150a  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 108,76
	btf_id 157
515: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 158
516: sched_cls  name __send_drop_notify  tag 076c7ffa453fa676  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 159
517: sched_cls  name tail_ipv4_to_endpoint  tag a1a25640e094de42  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,107,41,82,83,80,106,39,108,40,37,38
	btf_id 160
519: sched_cls  name handle_policy  tag 23a0a70a9ce5a446  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,108,82,83,107,41,80,106,39,84,75,40,37,38
	btf_id 162
520: sched_cls  name tail_ipv4_ct_ingress  tag c822b832c114bf41  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 163
521: sched_cls  name tail_ipv4_ct_ingress  tag a8792817a2df0bd4  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 165
522: sched_cls  name tail_ipv4_to_endpoint  tag c92cf0d31e2f788c  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,110,41,82,83,80,100,39,109,40,37,38
	btf_id 166
523: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 167
524: sched_cls  name cil_from_container  tag 522f9687da95c7c1  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 109,76
	btf_id 168
525: sched_cls  name handle_policy  tag 3445c46c1c84068c  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,109,82,83,110,41,80,100,39,84,75,40,37,38
	btf_id 169
526: sched_cls  name __send_drop_notify  tag ed35ac83af8816b6  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 170
527: sched_cls  name tail_handle_arp  tag e3caaf4ad6875b60  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 171
528: sched_cls  name tail_handle_ipv4_cont  tag 98d8eea554012bb4  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,110,41,100,82,83,39,76,74,77,109,40,37,38,81
	btf_id 172
529: sched_cls  name tail_ipv4_ct_egress  tag a72589289dce0674  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 173
531: sched_cls  name tail_handle_ipv4  tag 9bf1937cb25a8ab5  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 175
532: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
535: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
536: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
539: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
540: sched_cls  name handle_policy  tag da8449bbb3c9fc35  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,111,41,80,101,39,84,75,40,37,38
	btf_id 177
541: sched_cls  name tail_ipv4_to_endpoint  tag a8380ad150ca798f  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,111,41,82,83,80,101,39,112,40,37,38
	btf_id 178
542: sched_cls  name tail_handle_arp  tag 3cded3113ed4a68d  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 179
543: sched_cls  name tail_handle_ipv4_cont  tag 2b2f07c91295a877  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,111,41,101,82,83,39,76,74,77,112,40,37,38,81
	btf_id 180
544: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 181
545: sched_cls  name tail_ipv4_ct_ingress  tag 362c0378c0edb286  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 182
546: sched_cls  name tail_ipv4_ct_egress  tag a72589289dce0674  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 183
547: sched_cls  name tail_handle_ipv4  tag 6b689e8b276484e1  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 184
548: sched_cls  name cil_from_container  tag ac19488a482680a1  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 185
550: sched_cls  name __send_drop_notify  tag d446658271c18fa4  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 187
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
559: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 189
560: sched_cls  name __send_drop_notify  tag 4b356e1d4d7caada  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 190
562: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 192
563: sched_cls  name tail_handle_ipv4_from_host  tag 05f3acf1f36a7a2d  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 193
565: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 195
567: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 198
568: sched_cls  name __send_drop_notify  tag 4b356e1d4d7caada  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
570: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 201
571: sched_cls  name tail_handle_ipv4_from_host  tag 05f3acf1f36a7a2d  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 202
575: sched_cls  name tail_handle_ipv4_from_host  tag 05f3acf1f36a7a2d  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 207
576: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 208
578: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 210
579: sched_cls  name __send_drop_notify  tag 4b356e1d4d7caada  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 211
582: sched_cls  name tail_handle_ipv4_from_host  tag 05f3acf1f36a7a2d  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 215
583: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 216
585: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 218
586: sched_cls  name __send_drop_notify  tag 4b356e1d4d7caada  gpl
	loaded_at 2024-10-24T12:27:09+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 219
626: sched_cls  name tail_handle_arp  tag c021dd3d0fc0cffc  gpl
	loaded_at 2024-10-24T12:42:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 233
627: sched_cls  name tail_handle_ipv4  tag c8429343bfe7c00c  gpl
	loaded_at 2024-10-24T12:42:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 234
628: sched_cls  name __send_drop_notify  tag 78d05777a2b25b1c  gpl
	loaded_at 2024-10-24T12:42:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 235
629: sched_cls  name tail_handle_ipv4_cont  tag 3748a9e2de0b3b62  gpl
	loaded_at 2024-10-24T12:42:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 236
631: sched_cls  name tail_ipv4_ct_egress  tag 5cb7900cc06dce48  gpl
	loaded_at 2024-10-24T12:42:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 238
632: sched_cls  name tail_ipv4_to_endpoint  tag e6d2ef52beaf3941  gpl
	loaded_at 2024-10-24T12:42:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 239
633: sched_cls  name handle_policy  tag 0ad7aa5aa2963179  gpl
	loaded_at 2024-10-24T12:42:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 240
634: sched_cls  name tail_ipv4_ct_ingress  tag 2f46b9988e85257c  gpl
	loaded_at 2024-10-24T12:42:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 241
635: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 242
636: sched_cls  name cil_from_container  tag e7209b509186b244  gpl
	loaded_at 2024-10-24T12:42:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 243
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
676: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
679: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
702: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
705: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
706: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
709: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
710: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
713: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
714: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
717: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
718: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
721: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
722: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
725: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3289: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,628
	btf_id 3077
3290: sched_cls  name tail_handle_arp  tag 999199f7bb1886fb  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,628
	btf_id 3078
3291: sched_cls  name __send_drop_notify  tag 50a99fad8a6c6792  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3079
3293: sched_cls  name cil_from_container  tag b10ef228bcf83754  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 628,76
	btf_id 3081
3294: sched_cls  name handle_policy  tag a64efcbd3d7338c7  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,628,82,83,627,41,80,149,39,84,75,40,37,38
	btf_id 3082
3295: sched_cls  name tail_handle_ipv4  tag e81294c159afd30c  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,628
	btf_id 3083
3296: sched_cls  name tail_ipv4_to_endpoint  tag 1d156a3f05132a84  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,627,41,82,83,80,149,39,628,40,37,38
	btf_id 3084
3297: sched_cls  name tail_ipv4_ct_egress  tag 0d5f2ba77fc8fb10  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,628,82,83,627,84
	btf_id 3087
3299: sched_cls  name tail_ipv4_ct_ingress  tag 9d42ce0884cb580c  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,628,82,83,627,84
	btf_id 3088
3300: sched_cls  name tail_handle_ipv4_cont  tag 6c760794eb0a319c  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,627,41,149,82,83,39,76,74,77,628,40,37,38,81
	btf_id 3089
3344: sched_cls  name tail_ipv4_ct_egress  tag 654b06c856413d5f  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3139
3345: sched_cls  name cil_from_container  tag df7d2d05c3825f2d  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 639,76
	btf_id 3140
3347: sched_cls  name tail_ipv4_to_endpoint  tag 312123eaee5454a5  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,637,41,82,83,80,145,39,638,40,37,38
	btf_id 3138
3348: sched_cls  name tail_ipv4_to_endpoint  tag a242a9a5b7e0356b  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,640,41,82,83,80,152,39,639,40,37,38
	btf_id 3142
3349: sched_cls  name tail_handle_ipv4  tag a09e29614b9e66ca  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,638
	btf_id 3143
3350: sched_cls  name tail_handle_ipv4  tag 2bb45783f8592c74  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,639
	btf_id 3144
3351: sched_cls  name tail_handle_ipv4_cont  tag 5baee8d939b3b874  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,640,41,152,82,83,39,76,74,77,639,40,37,38,81
	btf_id 3146
3352: sched_cls  name tail_ipv4_ct_ingress  tag e445bca43a8d170a  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3147
3353: sched_cls  name __send_drop_notify  tag c5a85df431ed93e2  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3148
3354: sched_cls  name tail_handle_arp  tag 4b16dd1ee315aadb  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,639
	btf_id 3149
3355: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,639
	btf_id 3150
3356: sched_cls  name handle_policy  tag 20edd98f8e986b41  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,638,82,83,637,41,80,145,39,84,75,40,37,38
	btf_id 3145
3357: sched_cls  name __send_drop_notify  tag bf38fc27d5d7dc51  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3152
3358: sched_cls  name tail_handle_ipv4_cont  tag 6cd3f0bfb59a9f7c  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,637,41,145,82,83,39,76,74,77,638,40,37,38,81
	btf_id 3153
3359: sched_cls  name handle_policy  tag e62f4d3a793cc435  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,639,82,83,640,41,80,152,39,84,75,40,37,38
	btf_id 3151
3360: sched_cls  name tail_ipv4_ct_ingress  tag b61abcb6bf3d3009  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,637,84
	btf_id 3154
3361: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,638
	btf_id 3155
3362: sched_cls  name cil_from_container  tag dd9e7ed1f35e428a  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 638,76
	btf_id 3156
3364: sched_cls  name tail_ipv4_ct_egress  tag dc6e98f1a6a905e9  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,637,84
	btf_id 3158
3365: sched_cls  name tail_handle_arp  tag bd685f795fcb5385  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,638
	btf_id 3159
