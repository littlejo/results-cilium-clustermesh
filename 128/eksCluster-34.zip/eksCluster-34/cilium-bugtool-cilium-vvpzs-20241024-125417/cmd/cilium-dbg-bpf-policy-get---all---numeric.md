Endpoint ID: 79
Path: /sys/fs/bpf/tc/globals/cilium_policy_00079

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6132216   61105     0        
Allow    Ingress     1          ANY          NONE         disabled    4961977   52170     0        
Allow    Egress      0          ANY          NONE         disabled    6250235   62359     0        


Endpoint ID: 554
Path: /sys/fs/bpf/tc/globals/cilium_policy_00554

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6226934   76965     0        
Allow    Ingress     1          ANY          NONE         disabled    68076     818       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1504
Path: /sys/fs/bpf/tc/globals/cilium_policy_01504

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1595
Path: /sys/fs/bpf/tc/globals/cilium_policy_01595

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2009
Path: /sys/fs/bpf/tc/globals/cilium_policy_02009

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3930     38        0        
Allow    Ingress     1          ANY          NONE         disabled    156493   1789      0        
Allow    Egress      0          ANY          NONE         disabled    22542    254       0        


Endpoint ID: 2964
Path: /sys/fs/bpf/tc/globals/cilium_policy_02964

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2970
Path: /sys/fs/bpf/tc/globals/cilium_policy_02970

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1966     22        0        
Allow    Ingress     1          ANY          NONE         disabled    157549   1805      0        
Allow    Egress      0          ANY          NONE         disabled    21207    238       0        


Endpoint ID: 3991
Path: /sys/fs/bpf/tc/globals/cilium_policy_03991

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377618   4403      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


