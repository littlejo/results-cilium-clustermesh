1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00 promiscuity 0 minmtu 0 maxmtu 0 addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      20915066   53401      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      20915066   53401      0       0       0       0 
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP mode DEFAULT group default qlen 1000
    link/ether 06:d9:c7:7d:7f:e7 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 128 maxmtu 9216 addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 parentbus pci parentdev 0000:00:05.0 
    RX:  bytes packets errors dropped  missed   mcast           
     717061873  851723      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      59135448  427562      0       0       0       0 
    altname enp0s5
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP mode DEFAULT group default qlen 1000
    link/ether 06:50:ff:dc:29:59 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 128 maxmtu 9216 addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 parentbus pci parentdev 0000:00:06.0 
    RX:  bytes packets errors dropped  missed   mcast           
           896      32      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
          2490      47      0       0       0       0 
    altname enp0s6
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether d2:58:d3:9f:36:f8 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         43916     648      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       4803010   59067      0       0       0       0 
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 86:2f:f6:80:b1:2f brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       4803010   59067      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
         43916     648      0       0       0       0 
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000
    link/ether e6:4a:61:7a:ae:fb brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    vxlan external id 0 srcport 0 0 dstport 8472 nolearning ttl auto ageing 300 udpcsum noudp6zerocsumtx noudp6zerocsumrx addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       9086692  135428      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       9194778  137065      0       0       0       0 
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether da:80:02:f7:35:90 brd ff:ff:ff:ff:ff:ff link-netnsid 0 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       4509376   55507      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       6250152   77214      0       0       0       0 
12: lxc244e74ef7433@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 92:a1:2d:83:de:bf brd ff:ff:ff:ff:ff:ff link-netnsid 2 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        169091    1741      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        230482    2005      0       0       0       0 
14: lxc989344b6fb33@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether c2:fc:8f:87:a4:95 brd ff:ff:ff:ff:ff:ff link-netnsid 3 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        173984    1774      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        231503    2019      0       0       0       0 
18: lxc69416e197bee@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 6a:d3:15:c6:84:02 brd ff:ff:ff:ff:ff:ff link-netnsid 4 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      15014688  120655      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      15485187  139859      0       0       0       0 
20: lxc2c1bdf23d918@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 26:9b:b5:89:34:19 brd ff:ff:ff:ff:ff:ff link-netnsid 1 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         40060     408      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        174013     274      0       0       0       0 
22: lxc7795a7712cd8@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 22:2f:2b:98:e2:f4 brd ff:ff:ff:ff:ff:ff link-netnsid 5 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       1208076    3149      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        367499    4301      0       0       0       0 
24: lxc21190f4f9d3a@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 76:f3:aa:b8:81:9a brd ff:ff:ff:ff:ff:ff link-netnsid 6 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         40830     416      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        189340     287      0       0       0       0 
