xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 555
ens6(5) clsact/ingress cil_from_netdev-ens6 id 566
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 547
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 540
cilium_host(7) clsact/egress cil_from_host-cilium_host id 536
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 482
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 583
lxc727d273a15ab(12) clsact/ingress cil_from_container-lxc727d273a15ab id 520
lxc71b3b78a4486(14) clsact/ingress cil_from_container-lxc71b3b78a4486 id 572
lxcd410d440008d(18) clsact/ingress cil_from_container-lxcd410d440008d id 645
lxc3c60ff146689(20) clsact/ingress cil_from_container-lxc3c60ff146689 id 3338
lxce32ce97377a5(22) clsact/ingress cil_from_container-lxce32ce97377a5 id 3282
lxcf66d25c76ba3(24) clsact/ingress cil_from_container-lxcf66d25c76ba3 id 3348

flow_dissector:

netfilter:

