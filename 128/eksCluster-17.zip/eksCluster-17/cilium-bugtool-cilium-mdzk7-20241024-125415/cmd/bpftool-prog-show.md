32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:55+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:20:56+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:20:57+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:20:57+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:20:57+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:57+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:21:01+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:21:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:21:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:21:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:25:54+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
482: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:25:54+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 125
483: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:25:54+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
484: sched_cls  name tail_handle_ipv4  tag 8ad2ae54bf69d4f3  gpl
	loaded_at 2024-10-24T12:25:54+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
514: sched_cls  name tail_ipv4_to_endpoint  tag 75e411cc9e6fb4fe  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 163
517: sched_cls  name tail_ipv4_ct_egress  tag 38a0c4355b9f4468  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 166
518: sched_cls  name tail_ipv4_ct_ingress  tag 09ac807dd4db9f96  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 168
519: sched_cls  name tail_handle_ipv4  tag e8997a8c2b18cb50  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 169
520: sched_cls  name cil_from_container  tag c1195a3f16c53990  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 170
521: sched_cls  name __send_drop_notify  tag 12bd6531b241ba2b  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 171
523: sched_cls  name tail_handle_ipv4_cont  tag aea992adc415e5b0  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 172
527: sched_cls  name handle_policy  tag 7761bcd1ecb79a30  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 174
528: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 178
529: sched_cls  name tail_handle_arp  tag c2b4f21ba997b9b1  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 179
531: sched_cls  name tail_handle_ipv4_cont  tag 760ffd493723e868  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 181
536: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 188
539: sched_cls  name handle_policy  tag 170c15d09383bdd4  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 183
540: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 191
541: sched_cls  name __send_drop_notify  tag 76201f75fd4ec438  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
542: sched_cls  name tail_handle_ipv4_from_host  tag d384276f023a59ac  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 193
543: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 194
547: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 199
548: sched_cls  name __send_drop_notify  tag 76201f75fd4ec438  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 200
549: sched_cls  name tail_handle_ipv4  tag 7396114f14249237  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 201
550: sched_cls  name tail_handle_arp  tag fa5aec64d4110d23  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 203
551: sched_cls  name tail_handle_ipv4_from_host  tag d384276f023a59ac  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 202
552: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 205
554: sched_cls  name tail_ipv4_to_endpoint  tag d54c9342b622084f  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 204
555: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 208
556: sched_cls  name __send_drop_notify  tag 513cd8ea3e047686  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 209
558: sched_cls  name __send_drop_notify  tag 76201f75fd4ec438  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 212
559: sched_cls  name tail_handle_ipv4_from_host  tag d384276f023a59ac  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 213
560: sched_cls  name tail_ipv4_ct_ingress  tag 5b4df8b3aff65e4a  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 211
561: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 214
564: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 215
566: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 221
568: sched_cls  name __send_drop_notify  tag 76201f75fd4ec438  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 223
569: sched_cls  name tail_handle_ipv4_from_host  tag d384276f023a59ac  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 224
570: sched_cls  name tail_ipv4_ct_egress  tag 38a0c4355b9f4468  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 218
571: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 225
572: sched_cls  name cil_from_container  tag 4c35972af21c457e  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 226
574: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,126
	btf_id 229
575: sched_cls  name tail_ipv4_to_endpoint  tag 586c2cf12470af16  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,125,41,82,83,80,100,39,126,40,37,38
	btf_id 230
576: sched_cls  name handle_policy  tag 6e270bdde740f4d2  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,126,82,83,125,41,80,100,39,84,75,40,37,38
	btf_id 231
577: sched_cls  name tail_ipv4_ct_ingress  tag 207a7bce78ed3d5c  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 232
578: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
581: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
582: sched_cls  name tail_handle_ipv4  tag 40b4941c68a6f230  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,126
	btf_id 233
583: sched_cls  name cil_from_container  tag 4c4e4de329b29d98  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 126,76
	btf_id 234
584: sched_cls  name __send_drop_notify  tag 393407d5b9bab0ef  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 235
586: sched_cls  name tail_handle_arp  tag 5dcf0fa271112ef4  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,126
	btf_id 237
587: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 238
588: sched_cls  name tail_handle_ipv4_cont  tag 65e4fe03332ecd3c  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,125,41,100,82,83,39,76,74,77,126,40,37,38,81
	btf_id 239
589: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
592: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: sched_cls  name tail_handle_ipv4_cont  tag 93c9c84a30c06172  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 253
641: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 254
642: sched_cls  name __send_drop_notify  tag 1aab0a66f3190db6  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 255
643: sched_cls  name tail_ipv4_to_endpoint  tag 6bfa5394a8efa3b0  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 256
644: sched_cls  name tail_ipv4_ct_egress  tag 23c71ef43d93522e  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 257
645: sched_cls  name cil_from_container  tag e4f151e1c1cd4572  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 258
647: sched_cls  name tail_ipv4_ct_ingress  tag 46e984c4fed03ffe  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 260
648: sched_cls  name handle_policy  tag 658749bd276f5f51  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 261
649: sched_cls  name tail_handle_ipv4  tag 93cfbf8439db3983  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 262
650: sched_cls  name tail_handle_arp  tag e90618f047f8303a  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 263
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
667: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
670: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
671: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
674: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
712: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
715: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
716: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
719: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
720: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
723: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
724: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
727: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
728: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
731: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
732: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
735: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
736: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
739: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3281: sched_cls  name __send_drop_notify  tag ba4f6783449e15a7  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3073
3282: sched_cls  name cil_from_container  tag 82a143121810a199  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 629,76
	btf_id 3074
3283: sched_cls  name tail_ipv4_to_endpoint  tag 496d03ef938dd6eb  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,630,41,82,83,80,154,39,629,40,37,38
	btf_id 3075
3284: sched_cls  name tail_handle_ipv4_cont  tag 28c92c66dfa93d75  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,630,41,154,82,83,39,76,74,77,629,40,37,38,81
	btf_id 3076
3285: sched_cls  name handle_policy  tag 85f708fe89654769  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,629,82,83,630,41,80,154,39,84,75,40,37,38
	btf_id 3077
3287: sched_cls  name tail_handle_ipv4  tag 93fd07468e5a8ac9  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,629
	btf_id 3080
3288: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,629
	btf_id 3082
3289: sched_cls  name tail_handle_arp  tag 205ba499a1044038  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,629
	btf_id 3083
3290: sched_cls  name tail_ipv4_ct_egress  tag bb5b5683a06fcf92  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,629,82,83,630,84
	btf_id 3084
3292: sched_cls  name tail_ipv4_ct_ingress  tag 9d26859a6c4257fe  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,629,82,83,630,84
	btf_id 3085
3336: sched_cls  name tail_ipv4_ct_ingress  tag e95978f0ce92fbcc  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3133
3337: sched_cls  name __send_drop_notify  tag 8b6fa97ae34be8f6  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3136
3338: sched_cls  name cil_from_container  tag d3d58367fc9f1af9  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 640,76
	btf_id 3137
3339: sched_cls  name tail_handle_ipv4_cont  tag 2c540f6b76f2a6a6  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,642,41,157,82,83,39,76,74,77,641,40,37,38,81
	btf_id 3135
3341: sched_cls  name tail_ipv4_ct_ingress  tag f84c4c3bbb41e370  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,641,82,83,642,84
	btf_id 3139
3342: sched_cls  name handle_policy  tag 541dcf61f49abd2c  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,640,82,83,639,41,80,151,39,84,75,40,37,38
	btf_id 3140
3343: sched_cls  name handle_policy  tag c17ad2f3f9d9c17c  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,641,82,83,642,41,80,157,39,84,75,40,37,38
	btf_id 3141
3344: sched_cls  name tail_handle_ipv4  tag 14c92896f20a11be  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,640
	btf_id 3142
3345: sched_cls  name tail_ipv4_ct_egress  tag 0894d750a2592671  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,641,82,83,642,84
	btf_id 3143
3347: sched_cls  name __send_drop_notify  tag 1f1ec08c41c976fa  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3146
3348: sched_cls  name cil_from_container  tag a62f94fa0bcea780  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 641,76
	btf_id 3147
3349: sched_cls  name tail_handle_ipv4_cont  tag 56dcc863c27ff02a  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,639,41,151,82,83,39,76,74,77,640,40,37,38,81
	btf_id 3144
3350: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,641
	btf_id 3148
3351: sched_cls  name tail_handle_arp  tag 4be781bd7bf13276  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,641
	btf_id 3150
3352: sched_cls  name tail_handle_ipv4  tag ec83c2a8754a5446  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,641
	btf_id 3151
3353: sched_cls  name tail_ipv4_to_endpoint  tag c3d142a8b6e39d82  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,639,41,82,83,80,151,39,640,40,37,38
	btf_id 3149
3354: sched_cls  name tail_ipv4_to_endpoint  tag fc1e1de4d8e3a407  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,642,41,82,83,80,157,39,641,40,37,38
	btf_id 3152
3355: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,640
	btf_id 3153
3356: sched_cls  name tail_ipv4_ct_egress  tag f81e6a141cde9658  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3154
3357: sched_cls  name tail_handle_arp  tag 825567759ea5cdd4  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,640
	btf_id 3155
