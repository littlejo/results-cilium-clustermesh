 12:54:17 up 33 min,  0 users,  load average: 0.71, 0.51, 0.29
