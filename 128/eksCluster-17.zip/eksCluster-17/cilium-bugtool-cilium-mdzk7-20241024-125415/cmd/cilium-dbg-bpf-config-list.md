KEY             VALUE
AgentLiveness   2035445150880
UTimeOffset     3378461820312500
