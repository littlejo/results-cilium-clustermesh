key: 18 01 00 00  value: 1b 02 00 00
key: 92 01 00 00  value: 0e 0d 00 00
key: 42 03 00 00  value: 0f 02 00 00
key: 3a 05 00 00  value: 40 02 00 00
key: 47 09 00 00  value: 88 02 00 00
key: e2 0a 00 00  value: 0f 0d 00 00
key: 8a 0f 00 00  value: d5 0c 00 00
Found 7 elements
