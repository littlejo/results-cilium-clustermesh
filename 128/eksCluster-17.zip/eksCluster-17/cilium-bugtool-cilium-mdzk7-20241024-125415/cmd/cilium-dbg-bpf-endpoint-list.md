IP ADDRESS         LOCAL ENDPOINT INFO
10.17.0.144:0      id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B   
10.17.0.179:0      (localhost)                                                                                        
10.17.0.193:0      id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45   
10.17.0.192:0      id=280   sec_id=1183482 flags=0x0000 ifindex=14  mac=8E:96:D0:71:C5:E3 nodemac=7A:0B:7A:51:93:E4   
10.17.0.68:0       id=1338  sec_id=4     flags=0x0000 ifindex=10  mac=8E:60:AD:3F:33:0D nodemac=4E:9F:97:98:EA:88     
10.17.0.153:0      id=834   sec_id=1183482 flags=0x0000 ifindex=12  mac=E2:06:BC:DF:68:56 nodemac=CA:0B:0E:53:51:02   
172.31.234.150:0   (localhost)                                                                                        
172.31.251.237:0   (localhost)                                                                                        
10.17.0.108:0      id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6   
10.17.0.81:0       id=2375  sec_id=1191303 flags=0x0000 ifindex=18  mac=72:90:96:BD:48:07 nodemac=82:05:E2:D4:7B:22   
