[
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod159cbce4_105a_4ff6_b481_50fecd593901.slice/cri-containerd-d2390df115a09b5792405320a6253bc77c9e84abe6a382d5ff2059ee34aa16d4.scope"
      }
    ],
    "ips": [
      "10.17.0.192"
    ],
    "name": "coredns-cc6ccd49c-b8d2t",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod92791685_f2da_41d6_a529_c8cfa166822e.slice/cri-containerd-c0110517503bd34daa62c8e84abff009b3d27dfdba0412343b44bdd6db0384ea.scope"
      }
    ],
    "ips": [
      "10.17.0.108"
    ],
    "name": "client-974f6c69d-vssxp",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64cbe769_e23a_47b5_9380_e7677335e1df.slice/cri-containerd-70f77855fbb35afbe941cf05122874dfb8d211c376c5df6edfa1a0c7e2b4fc80.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64cbe769_e23a_47b5_9380_e7677335e1df.slice/cri-containerd-58363008e600e713989db2ff2b14625fc5553f843efcc60f034610070a02e5c7.scope"
      }
    ],
    "ips": [
      "10.17.0.144"
    ],
    "name": "echo-same-node-86d9cc975c-dzpms",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3db47aff_2cba_4daf_a944_52b927caf5f0.slice/cri-containerd-f71f5c49ef30da923bb714064e6ad0dc4bbe46cfed20d8e05c275a2e149bf286.scope"
      }
    ],
    "ips": [
      "10.17.0.153"
    ],
    "name": "coredns-cc6ccd49c-b59lz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod126a7946_8681_4680_849b_0f8163946eb3.slice/cri-containerd-90e68ffeb6e6a221a234bf06bff0845c69ea8f5a4cd39893b0a949a84bc18ac8.scope"
      }
    ],
    "ips": [
      "10.17.0.193"
    ],
    "name": "client2-57cf4468f-qlnlb",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod920d7e36_54bd_4066_a580_63bbc3bb7ba4.slice/cri-containerd-c4349b30d06d5190d32ae641dfb1b937fa5c4c556a252a5462d056bb93be71bb.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod920d7e36_54bd_4066_a580_63bbc3bb7ba4.slice/cri-containerd-babe34eb127ab6f8e4a2918a17a71e7981cda9fd1f43aea3a9e71db384f6133b.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod920d7e36_54bd_4066_a580_63bbc3bb7ba4.slice/cri-containerd-a5adad48b661a90db51c30ea942ba3c05f0cd6bdb9651050341c81388d2cdffc.scope"
      }
    ],
    "ips": [
      "10.17.0.81"
    ],
    "name": "clustermesh-apiserver-6cd8b8c4b5-dfnpw",
    "namespace": "kube-system"
  }
]

