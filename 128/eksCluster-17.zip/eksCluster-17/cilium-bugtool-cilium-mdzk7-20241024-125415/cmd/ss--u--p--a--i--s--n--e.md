Total: 589
TCP:   4750 (estab 312, closed 4419, orphaned 0, timewait 3957)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  331       319       12       
INET	  341       325       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                  172.31.234.150%ens5:68         0.0.0.0:*    uid:192 ino:87223 sk:1001 cgroup:unreachable:bd0 <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:28526 sk:1002 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15094 sk:1003 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:45789      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:28458 sk:1004 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:28525 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15095 sk:1006 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::8fb:71ff:fe93:2fdb]%ens5:546           [::]:*    uid:192 ino:15267 sk:1007 cgroup:unreachable:bd0 v6only:1 <->                   
