REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     129662    10495117    677    bpf_overlay.c
Interface                   INGRESS     651792    245010091   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      128601    10419774    53     encap.h
Success                     EGRESS      143229    19368137    1308   bpf_lxc.c
Success                     EGRESS      53493     4332811     1694   bpf_host.c
Success                     EGRESS      596       156299      86     l3.h
Success                     INGRESS     168127    19059781    86     l3.h
Success                     INGRESS     245523    25420856    235    trace.h
Unsupported L3 protocol     EGRESS      72        5420        1492   bpf_lxc.c
