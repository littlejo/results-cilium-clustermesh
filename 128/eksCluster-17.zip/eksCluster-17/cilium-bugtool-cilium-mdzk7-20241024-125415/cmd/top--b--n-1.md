top - 12:54:17 up 33 min,  0 users,  load average: 0.71, 0.51, 0.29
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 53.3 us, 33.3 sy,  0.0 ni,  6.7 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   3836.2 total,    280.5 free,   1057.9 used,   2497.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2597.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 292576  79104 S  53.3   7.4   1:10.20 cilium-+
   3130 root      20   0 1229640  15432   4004 S   6.7   0.4   0:00.01 gops
    394 root      20   0 1229744   9068   2864 S   0.0   0.2   0:04.41 cilium-+
   3124 root      20   0 1240432  16632  11356 S   0.0   0.4   0:00.02 cilium-+
   3140 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
   3141 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3198 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
   3217 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
