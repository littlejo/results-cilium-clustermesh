Node 0, zone      DMA     64     71     10     24     18     10      2     10      3      2     46 
Node 0, zone   Normal      3      0      3      3     15      5      1      2      1      3      8 
