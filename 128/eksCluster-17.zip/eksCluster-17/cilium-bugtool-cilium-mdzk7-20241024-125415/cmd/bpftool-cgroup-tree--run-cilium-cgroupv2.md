CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc595eb27_433e_46a1_8e78_53e4a2c941d4.slice/cri-containerd-6054758c1b73933012a507bbc3feba87f917b7f8276f6eb23b09ac714030698c.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc595eb27_433e_46a1_8e78_53e4a2c941d4.slice/cri-containerd-5a914c1d23e07e8976be55a1a38c6a40f55a484001a2a84f82fae58e363d6477.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf036203c_1165_45cd_953b_5c8035322dfc.slice/cri-containerd-ca1562edbf5bf9e51116b2812a5e399f130246d6349d3e64db79b81891ad6750.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf036203c_1165_45cd_953b_5c8035322dfc.slice/cri-containerd-b908dc13b718d951ed934a1d8d339286e2245bf33b471eff82d45fc93defac8f.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod159cbce4_105a_4ff6_b481_50fecd593901.slice/cri-containerd-ff513051951406aabed403b57bad27cdf331437a08cfd997e72a8092a55e1fd2.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod159cbce4_105a_4ff6_b481_50fecd593901.slice/cri-containerd-d2390df115a09b5792405320a6253bc77c9e84abe6a382d5ff2059ee34aa16d4.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3db47aff_2cba_4daf_a944_52b927caf5f0.slice/cri-containerd-1e56d4c72919dc87d9a10af359a5945fee922eb4ae1f84bc072025e81489150a.scope
    581      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3db47aff_2cba_4daf_a944_52b927caf5f0.slice/cri-containerd-f71f5c49ef30da923bb714064e6ad0dc4bbe46cfed20d8e05c275a2e149bf286.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod92791685_f2da_41d6_a529_c8cfa166822e.slice/cri-containerd-c0110517503bd34daa62c8e84abff009b3d27dfdba0412343b44bdd6db0384ea.scope
    727      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod92791685_f2da_41d6_a529_c8cfa166822e.slice/cri-containerd-38681aae465ff285259c54581b57bb78bc93c0ec1ca73cbe866b6c758c24226e.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod920d7e36_54bd_4066_a580_63bbc3bb7ba4.slice/cri-containerd-a5adad48b661a90db51c30ea942ba3c05f0cd6bdb9651050341c81388d2cdffc.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod920d7e36_54bd_4066_a580_63bbc3bb7ba4.slice/cri-containerd-babe34eb127ab6f8e4a2918a17a71e7981cda9fd1f43aea3a9e71db384f6133b.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod920d7e36_54bd_4066_a580_63bbc3bb7ba4.slice/cri-containerd-717992ea6fc98cdd92b485bae5bee548890bb31767fb6ccb88cf0699cb04b96b.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod920d7e36_54bd_4066_a580_63bbc3bb7ba4.slice/cri-containerd-c4349b30d06d5190d32ae641dfb1b937fa5c4c556a252a5462d056bb93be71bb.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64cbe769_e23a_47b5_9380_e7677335e1df.slice/cri-containerd-70f77855fbb35afbe941cf05122874dfb8d211c376c5df6edfa1a0c7e2b4fc80.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64cbe769_e23a_47b5_9380_e7677335e1df.slice/cri-containerd-4a40e6bedcd2061a990d617b92f158f8a3e5a4be2c3c5e4aad2241dac87b5f63.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64cbe769_e23a_47b5_9380_e7677335e1df.slice/cri-containerd-58363008e600e713989db2ff2b14625fc5553f843efcc60f034610070a02e5c7.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf06bd069_d292_4c1b_a0a8_3f2f01302e3d.slice/cri-containerd-e0661afa6739b139657dc8f81f94d31e22544896779f58a1b9e8db7b4ae622c1.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf06bd069_d292_4c1b_a0a8_3f2f01302e3d.slice/cri-containerd-c42e770818e0f21ab45600dcecccb9575061416260f6b9a06d1c3c98c0170270.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod126a7946_8681_4680_849b_0f8163946eb3.slice/cri-containerd-b43fd7ba35b24457bd2274d659ae1d1ee9103929c5006108e650ec501aa2e518.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod126a7946_8681_4680_849b_0f8163946eb3.slice/cri-containerd-90e68ffeb6e6a221a234bf06bff0845c69ea8f5a4cd39893b0a949a84bc18ac8.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod24260771_a716_449b_82cf_1a02ab438c0c.slice/cri-containerd-1fd3fb54c5c3b2292e5def2d5c126581a85139cf64bb631ec803c09de4f6681f.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod24260771_a716_449b_82cf_1a02ab438c0c.slice/cri-containerd-8fb68bfdf217126a922fba9fa10e180de2f917430c930be8a3994aea36c09a99.scope
    106      cgroup_device   multi                                          
