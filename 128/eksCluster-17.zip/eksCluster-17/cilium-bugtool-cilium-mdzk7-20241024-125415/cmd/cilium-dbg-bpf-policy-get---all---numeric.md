Endpoint ID: 280
Path: /sys/fs/bpf/tc/globals/cilium_policy_00280

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2960     29        0        
Allow    Ingress     1          ANY          NONE         disabled    166652   1918      0        
Allow    Egress      0          ANY          NONE         disabled    22537    254       0        


Endpoint ID: 402
Path: /sys/fs/bpf/tc/globals/cilium_policy_00402

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 834
Path: /sys/fs/bpf/tc/globals/cilium_policy_00834

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2936     31        0        
Allow    Ingress     1          ANY          NONE         disabled    164540   1886      0        
Allow    Egress      0          ANY          NONE         disabled    22354    252       0        


Endpoint ID: 1338
Path: /sys/fs/bpf/tc/globals/cilium_policy_01338

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6207046   76831     0        
Allow    Ingress     1          ANY          NONE         disabled    62523     750       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2375
Path: /sys/fs/bpf/tc/globals/cilium_policy_02375

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6074532   59931     0        
Allow    Ingress     1          ANY          NONE         disabled    5040250   52962     0        
Allow    Egress      0          ANY          NONE         disabled    5720079   57648     0        


Endpoint ID: 2786
Path: /sys/fs/bpf/tc/globals/cilium_policy_02786

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3090
Path: /sys/fs/bpf/tc/globals/cilium_policy_03090

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3978
Path: /sys/fs/bpf/tc/globals/cilium_policy_03978

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378588   4416      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


