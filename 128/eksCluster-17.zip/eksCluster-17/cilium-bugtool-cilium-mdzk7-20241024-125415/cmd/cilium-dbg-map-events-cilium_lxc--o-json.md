{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.457Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.470Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.500Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.755Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.755Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.868Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.963Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.996Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.528Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.529Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.583Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.605Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.648Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.668Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.697Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.935Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.941Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.991Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.012Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.038Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.612Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.620Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.652Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.662Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.718Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.721Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.776Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.979Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.993Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.041Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.057Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.092Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.674Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.678Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.727Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.747Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.799Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.827Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.837Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.023Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.029Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.086Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.097Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.148Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.557Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.560Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.610Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.611Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.653Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.866Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.868Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.917Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.935Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.966Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.465Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.505Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.569Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.582Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.617Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.844Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.884Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.907Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.949Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.964Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.366Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.405Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.416Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.465Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.466Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.477Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.740Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.747Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.794Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.837Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.839Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.247Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.277Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.293Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.330Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.346Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.372Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.635Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.637Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.775Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.842Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.850Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.184Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.222Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.230Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.268Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.289Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.312Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.538Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.558Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.612Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.620Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.659Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.937Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.968Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.993Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.032Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.032Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.047Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.280Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.287Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.346Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.379Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.395Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.709Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.745Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.754Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.857Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.869Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.909Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.109Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.132Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.153Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.158Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.172Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.874Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.878Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.911Z",
  "value": "id=3978  sec_id=1210256 flags=0x0000 ifindex=22  mac=6E:9E:F1:35:43:32 nodemac=4E:A5:EB:D6:D5:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.941Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.955Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.250Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.269Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.954Z",
  "value": "id=2786  sec_id=1210707 flags=0x0000 ifindex=24  mac=02:F4:E7:30:44:50 nodemac=E2:31:92:4E:B6:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.17.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.964Z",
  "value": "id=402   sec_id=1210819 flags=0x0000 ifindex=20  mac=52:D0:60:CB:C5:76 nodemac=4E:5D:00:BE:8A:D6"
}

