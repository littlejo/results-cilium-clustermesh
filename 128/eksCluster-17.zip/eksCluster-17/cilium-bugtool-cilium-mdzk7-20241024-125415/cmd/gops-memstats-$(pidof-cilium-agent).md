alloc: 109.18MB (114481744 bytes)
total-alloc: 3.06GB (3285930696 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 74551362
frees: 73412765
heap-alloc: 109.18MB (114481744 bytes)
heap-sys: 176.67MB (185253888 bytes)
heap-idle: 43.30MB (45408256 bytes)
heap-in-use: 133.37MB (139845632 bytes)
heap-released: 10.66MB (11182080 bytes)
heap-objects: 1138597
stack-in-use: 35.28MB (36995072 bytes)
stack-sys: 35.28MB (36995072 bytes)
stack-mspan-inuse: 2.18MB (2288000 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 984.99KB (1008633 bytes)
gc-sys: 5.57MB (5836064 bytes)
next-gc: when heap-alloc >= 149.26MB (156506440 bytes)
last-gc: 2024-10-24 12:54:20.085560027 +0000 UTC
gc-pause-total: 26.72408ms
gc-pause: 71393
gc-pause-end: 1729774460085560027
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0005160471727420097
enable-gc: true
debug-gc: false
