1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:fb:71:93:2f:db brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.234.150/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3408sec preferred_lft 3408sec
    inet6 fe80::8fb:71ff:fe93:2fdb/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:3a:40:68:37:d1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.251.237/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::83a:40ff:fe68:37d1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:74:2c:41:de:85 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8874:2cff:fe41:de85/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:78:84:43:a6:e4 brd ff:ff:ff:ff:ff:ff
    inet 10.17.0.179/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c878:84ff:fe43:a6e4/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 06:c1:8c:89:c9:2c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4c1:8cff:fe89:c92c/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:9f:97:98:ea:88 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4c9f:97ff:fe98:ea88/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc727d273a15ab@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:0b:0e:53:51:02 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c80b:eff:fe53:5102/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc71b3b78a4486@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:0b:7a:51:93:e4 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::780b:7aff:fe51:93e4/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcd410d440008d@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:05:e2:d4:7b:22 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::8005:e2ff:fed4:7b22/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc3c60ff146689@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:5d:00:be:8a:d6 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::4c5d:ff:febe:8ad6/64 scope link 
       valid_lft forever preferred_lft forever
22: lxce32ce97377a5@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:a5:eb:d6:d5:5b brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::4ca5:ebff:fed6:d55b/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcf66d25c76ba3@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:31:92:4e:b6:45 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::e031:92ff:fe4e:b645/64 scope link 
       valid_lft forever preferred_lft forever
