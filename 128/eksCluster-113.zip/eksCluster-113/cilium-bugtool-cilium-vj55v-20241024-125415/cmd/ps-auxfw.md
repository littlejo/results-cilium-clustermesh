USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3270  0.0  0.4 1240176 15828 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3284  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3286  0.0  0.0   3728   484 ?        R    12:54   0:00  \_ bash -c hostname
root        3243  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3242  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3228  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  5.4  7.7 1539132 304068 ?      Ssl  12:32   1:11 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.3  0.2 1229744 9848 ?        Sl   12:32   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
