Node 0, zone      DMA      0     62     35     43     22     11      7      3      2      3     36 
Node 0, zone   Normal    307     16     37     43     16      8      1      1      0      2      8 
