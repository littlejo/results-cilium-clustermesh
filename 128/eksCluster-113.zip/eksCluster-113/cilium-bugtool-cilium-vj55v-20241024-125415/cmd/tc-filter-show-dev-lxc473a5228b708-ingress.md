filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc473a5228b708 direct-action not_in_hw id 3287 tag fbe0ea688b5eeb05 jited 
