{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.143Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.642Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.649Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.707Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.711Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.741Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.986Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.988Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.044Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.074Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.106Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.592Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.594Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.651Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.660Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.703Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.739Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.752Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.984Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.991Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.055Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.075Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.123Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.681Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.686Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.729Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.729Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.773Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.779Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.813Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.037Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.047Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.088Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.128Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.147Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.686Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.696Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.730Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.760Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.772Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.799Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.810Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.056Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.063Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.146Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.189Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.236Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.598Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.600Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.644Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.665Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.684Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.891Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.903Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.954Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.985Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.009Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.381Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.422Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.431Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.474Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.501Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.532Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.763Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.763Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.815Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.855Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.902Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.298Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.306Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.347Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.363Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.392Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.609Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.614Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.666Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.685Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.713Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.107Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.171Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.176Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.218Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.237Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.263Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.469Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.486Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.525Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.583Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.598Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.943Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.971Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.987Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.011Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.042Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.275Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.279Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.338Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.341Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.380Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.712Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.720Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.771Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.773Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.810Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.030Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.045Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.116Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.126Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.173Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.464Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.500Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.518Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.554Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.561Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.595Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.835Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.843Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.855Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.894Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.607Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.612Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.654Z",
  "value": "id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.663Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.723Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.985Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.986Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.677Z",
  "value": "id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.686Z",
  "value": "id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1"
}

