IP ADDRESS         LOCAL ENDPOINT INFO
10.113.0.159:0     id=1257  sec_id=7478593 flags=0x0000 ifindex=14  mac=A2:DD:6C:36:93:86 nodemac=86:99:0E:57:B0:66   
10.113.0.167:0     id=1681  sec_id=7478593 flags=0x0000 ifindex=12  mac=42:BF:3B:7B:88:CF nodemac=C6:AC:72:77:1F:94   
10.113.0.183:0     id=710   sec_id=7533362 flags=0x0000 ifindex=20  mac=22:4A:E4:8E:3F:B3 nodemac=EE:FB:1C:5C:B4:E1   
10.113.0.105:0     id=1139  sec_id=7485077 flags=0x0000 ifindex=18  mac=66:3E:8B:DF:C9:0E nodemac=6A:5D:A4:18:94:85   
10.113.0.158:0     (localhost)                                                                                        
172.31.233.11:0    (localhost)                                                                                        
10.113.0.44:0      id=1852  sec_id=7482056 flags=0x0000 ifindex=24  mac=AE:11:AB:BE:5E:EE nodemac=C2:EF:CF:1D:C0:0A   
10.113.0.63:0      id=2382  sec_id=7485495 flags=0x0000 ifindex=22  mac=3A:69:41:73:2C:1C nodemac=32:2C:89:C2:93:D1   
172.31.246.108:0   (localhost)                                                                                        
10.113.0.150:0     id=3381  sec_id=4     flags=0x0000 ifindex=10  mac=42:29:AD:C9:C2:A7 nodemac=92:AF:AF:B8:AA:20     
