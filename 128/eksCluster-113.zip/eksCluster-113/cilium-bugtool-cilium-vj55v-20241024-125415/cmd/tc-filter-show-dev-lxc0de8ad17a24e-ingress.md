filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc0de8ad17a24e direct-action not_in_hw id 3327 tag 29e43eef21236afb jited 
