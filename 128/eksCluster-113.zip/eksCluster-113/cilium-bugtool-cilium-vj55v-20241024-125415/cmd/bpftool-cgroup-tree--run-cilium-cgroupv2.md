CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod541ccc23_45b2_4492_9ba8_33cf4508f3be.slice/cri-containerd-36899965a80c8f62add854b7a75506423bfbf8eb71a93d3cffd7020e757bbac9.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod541ccc23_45b2_4492_9ba8_33cf4508f3be.slice/cri-containerd-ba144b675d67f5d51c35389576edab4d4dfd1df8de4c874236ab7e5029f20400.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod292dc1a0_42e2_40bf_b750_215df0c317da.slice/cri-containerd-efdf55a0d1e16542a6e79219e10f5477c7608454cbfdbee850a631cfa0edd532.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod292dc1a0_42e2_40bf_b750_215df0c317da.slice/cri-containerd-c20cfa3809f8a5b7b6996e41dd356c1c4c70f801af761441e16d4a9aa0ac8a5e.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2cbc6fb3_f1a2_40e0_a6d5_c4fec1550d68.slice/cri-containerd-485520bed81194d5de44019a9156532e0b0ce83735764e48453c9cb228464a0a.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2cbc6fb3_f1a2_40e0_a6d5_c4fec1550d68.slice/cri-containerd-373414fa273e28da05b9db41178764feb69ed08529f0786d3c36f9703b3a295d.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9e5ca4f_6fd0_4bea_96ed_61d942f24059.slice/cri-containerd-2f1549e07fd7ea650dcdb350d6fa6bf39aeb09469ae67029708b81edb6d3b28f.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9e5ca4f_6fd0_4bea_96ed_61d942f24059.slice/cri-containerd-4b555365015b1af2e482a880482ea6b91aa33ee000ab2f34101ef969b1e1b6d2.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod710d5431_2940_4cb0_a18b_ab030466ae88.slice/cri-containerd-ce25031732f58a88e74f1df4c969ec541b50daad31f702ca0d66f67ef23eee2c.scope
    688      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod710d5431_2940_4cb0_a18b_ab030466ae88.slice/cri-containerd-cc1615f684701b23df07411c0bd7c911a506b18ef5ffde840f8d5d957d120507.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod710d5431_2940_4cb0_a18b_ab030466ae88.slice/cri-containerd-bcb4e0732fb530978df6c2f0efa444fb8fe55b8d1107afe817248a748723104d.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3119caf9_1223_4424_9e22_0a57f7dc474f.slice/cri-containerd-8ac7c15d050c707b7682d325206200595c56b113ca5ed9d7a0db15da19d85323.scope
    684      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3119caf9_1223_4424_9e22_0a57f7dc474f.slice/cri-containerd-0256ec8c7422c921ba7afe76a6236c9bcaa5cfbe4b812521f4c845afd4f01c17.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5ead1b81_30dd_4224_a654_f67d93d80538.slice/cri-containerd-46da79111978bb3a491303a6b6a7b07bd204cb250598c6f7d3a6035d91976ac0.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5ead1b81_30dd_4224_a654_f67d93d80538.slice/cri-containerd-175c7653dce29ee5b7610b8e48e74cada59a7714dd987ede34846d677c1edf96.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31c2c4d3_a604_407c_9220_272c8b83f0a1.slice/cri-containerd-f35809b5898bd7fbc4f98fa0656f0f1e21163874147e044e49a0af0c900ccd6c.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31c2c4d3_a604_407c_9220_272c8b83f0a1.slice/cri-containerd-ac2b880c1c5de2b95207e2da8f0f6cba3b6a73640923cfb7091a2f7e538c7b89.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b389550_5d07_472a_b80d_8d524f66e715.slice/cri-containerd-b61ec542494412eb5e55e813c6983b132622e95de5e4900b5fe893340e648a06.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b389550_5d07_472a_b80d_8d524f66e715.slice/cri-containerd-35a1ac45c4ef7f49ac441a11458046bb339766408b5f9c74b62d70e809d34afc.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b389550_5d07_472a_b80d_8d524f66e715.slice/cri-containerd-c9bfc522f8c83600b94642e933d346e041d86afd009117aac12cb468c38257bb.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b389550_5d07_472a_b80d_8d524f66e715.slice/cri-containerd-384c01fd8f8d5b15a1e33478696a51dcc201129efd19c4ca811bfecaf2288e5a.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod981b1d5c_f10e_4038_bfc9_c12c7dd27238.slice/cri-containerd-057d6983320834e83834546404a58063f3023c17b7848a919861c403670a7ce9.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod981b1d5c_f10e_4038_bfc9_c12c7dd27238.slice/cri-containerd-f759af8806158382b09446729e8ec0f1c8d6e59c1c0cf2f1a6c6f3997e52b412.scope
    103      cgroup_device   multi                                          
