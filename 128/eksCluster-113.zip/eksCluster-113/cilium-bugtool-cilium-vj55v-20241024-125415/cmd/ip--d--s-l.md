1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00 promiscuity 0 minmtu 0 maxmtu 0 addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      20139713   50279      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      20139713   50279      0       0       0       0 
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP mode DEFAULT group default qlen 1000
    link/ether 0a:95:94:98:fd:cb brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 128 maxmtu 9216 addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 parentbus pci parentdev 0000:00:05.0 
    RX:  bytes packets errors dropped  missed   mcast           
     714912073  799062      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      60506041  426544      0       0       0       0 
    altname enp0s5
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP mode DEFAULT group default qlen 1000
    link/ether 0a:22:d9:af:9a:9f brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 128 maxmtu 9216 addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 parentbus pci parentdev 0000:00:06.0 
    RX:  bytes packets errors dropped  missed   mcast           
           812      29      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
          2294      43      0       0       0       0 
    altname enp0s6
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ae:1b:d4:83:be:aa brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         43990     649      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       4667361   57417      0       0       0       0 
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 32:98:5d:04:5b:2b brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       4667361   57417      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
         43990     649      0       0       0       0 
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000
    link/ether 06:aa:45:14:1e:c1 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    vxlan external id 0 srcport 0 0 dstport 8472 nolearning ttl auto ageing 300 udpcsum noudp6zerocsumtx noudp6zerocsumrx addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       8981726  133711      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       9046944  134980      0       0       0       0 
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 92:af:af:b8:aa:20 brd ff:ff:ff:ff:ff:ff link-netnsid 0 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       4501218   55403      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       6250520   77074      0       0       0       0 
12: lxc5fbde669a8d8@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether c6:ac:72:77:1f:94 brd ff:ff:ff:ff:ff:ff link-netnsid 1 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        137374    1399      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        190682    1581      0       0       0       0 
14: lxc94ac4e7bcf36@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 86:99:0e:57:b0:66 brd ff:ff:ff:ff:ff:ff link-netnsid 2 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        136652    1397      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        190203    1583      0       0       0       0 
18: lxc12a989578c73@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 6a:5d:a4:18:94:85 brd ff:ff:ff:ff:ff:ff link-netnsid 4 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      17032131  136896      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      17835683  158697      0       0       0       0 
20: lxc0de8ad17a24e@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ee:fb:1c:5c:b4:e1 brd ff:ff:ff:ff:ff:ff link-netnsid 3 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         39929     406      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        173468     266      0       0       0       0 
22: lxc473a5228b708@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 32:2c:89:c2:93:d1 brd ff:ff:ff:ff:ff:ff link-netnsid 5 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       1206281    3124      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        367648    4305      0       0       0       0 
24: lxc4b4953b6297e@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether c2:ef:cf:1d:c0:0a brd ff:ff:ff:ff:ff:ff link-netnsid 6 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 2 numrxqueues 2 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         40963     418      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        190008     297      0       0       0       0 
