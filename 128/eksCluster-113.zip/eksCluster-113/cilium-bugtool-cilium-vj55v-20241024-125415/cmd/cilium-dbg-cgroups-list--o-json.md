[
  {
    "containers": [
      {
        "cgroup-id": 10049,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3119caf9_1223_4424_9e22_0a57f7dc474f.slice/cri-containerd-0256ec8c7422c921ba7afe76a6236c9bcaa5cfbe4b812521f4c845afd4f01c17.scope"
      }
    ],
    "ips": [
      "10.113.0.183"
    ],
    "name": "client-974f6c69d-w9f7f",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9965,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31c2c4d3_a604_407c_9220_272c8b83f0a1.slice/cri-containerd-f35809b5898bd7fbc4f98fa0656f0f1e21163874147e044e49a0af0c900ccd6c.scope"
      }
    ],
    "ips": [
      "10.113.0.44"
    ],
    "name": "client2-57cf4468f-2r9jd",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10217,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod710d5431_2940_4cb0_a18b_ab030466ae88.slice/cri-containerd-cc1615f684701b23df07411c0bd7c911a506b18ef5ffde840f8d5d957d120507.scope"
      },
      {
        "cgroup-id": 10133,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod710d5431_2940_4cb0_a18b_ab030466ae88.slice/cri-containerd-bcb4e0732fb530978df6c2f0efa444fb8fe55b8d1107afe817248a748723104d.scope"
      }
    ],
    "ips": [
      "10.113.0.63"
    ],
    "name": "echo-same-node-86d9cc975c-8qsk4",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9293,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b389550_5d07_472a_b80d_8d524f66e715.slice/cri-containerd-c9bfc522f8c83600b94642e933d346e041d86afd009117aac12cb468c38257bb.scope"
      },
      {
        "cgroup-id": 9209,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b389550_5d07_472a_b80d_8d524f66e715.slice/cri-containerd-384c01fd8f8d5b15a1e33478696a51dcc201129efd19c4ca811bfecaf2288e5a.scope"
      },
      {
        "cgroup-id": 9377,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b389550_5d07_472a_b80d_8d524f66e715.slice/cri-containerd-b61ec542494412eb5e55e813c6983b132622e95de5e4900b5fe893340e648a06.scope"
      }
    ],
    "ips": [
      "10.113.0.105"
    ],
    "name": "clustermesh-apiserver-66c7677f94-jw94t",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7733,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2cbc6fb3_f1a2_40e0_a6d5_c4fec1550d68.slice/cri-containerd-373414fa273e28da05b9db41178764feb69ed08529f0786d3c36f9703b3a295d.scope"
      }
    ],
    "ips": [
      "10.113.0.159"
    ],
    "name": "coredns-cc6ccd49c-svkwt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7817,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod292dc1a0_42e2_40bf_b750_215df0c317da.slice/cri-containerd-c20cfa3809f8a5b7b6996e41dd356c1c4c70f801af761441e16d4a9aa0ac8a5e.scope"
      }
    ],
    "ips": [
      "10.113.0.167"
    ],
    "name": "coredns-cc6ccd49c-fhn85",
    "namespace": "kube-system"
  }
]

