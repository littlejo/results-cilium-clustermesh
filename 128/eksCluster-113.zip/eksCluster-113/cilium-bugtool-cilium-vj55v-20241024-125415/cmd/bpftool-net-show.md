xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 570
ens6(5) clsact/ingress cil_from_netdev-ens6 id 576
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 564
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 558
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 505
lxc5fbde669a8d8(12) clsact/ingress cil_from_container-lxc5fbde669a8d8 id 516
lxc94ac4e7bcf36(14) clsact/ingress cil_from_container-lxc94ac4e7bcf36 id 536
lxc12a989578c73(18) clsact/ingress cil_from_container-lxc12a989578c73 id 621
lxc0de8ad17a24e(20) clsact/ingress cil_from_container-lxc0de8ad17a24e id 3327
lxc473a5228b708(22) clsact/ingress cil_from_container-lxc473a5228b708 id 3287
lxc4b4953b6297e(24) clsact/ingress cil_from_container-lxc4b4953b6297e id 3342

flow_dissector:

netfilter:

