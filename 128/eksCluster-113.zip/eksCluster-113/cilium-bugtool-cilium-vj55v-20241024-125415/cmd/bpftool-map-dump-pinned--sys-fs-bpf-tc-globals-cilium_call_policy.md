key: c6 02 00 00  value: 02 0d 00 00
key: 73 04 00 00  value: 6c 02 00 00
key: e9 04 00 00  value: 12 02 00 00
key: 91 06 00 00  value: 0d 02 00 00
key: 3c 07 00 00  value: 05 0d 00 00
key: 4e 09 00 00  value: d4 0c 00 00
key: 35 0d 00 00  value: 01 02 00 00
Found 7 elements
