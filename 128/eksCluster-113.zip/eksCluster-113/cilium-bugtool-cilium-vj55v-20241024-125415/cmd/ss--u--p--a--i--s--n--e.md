Total: 581
TCP:   4182 (estab 305, closed 3858, orphaned 0, timewait 3393)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  324       314       10       
INET	  334       320       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                            127.0.0.1:44941      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:35504 sk:1 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.246.108%ens5:68         0.0.0.0:*    uid:192 ino:156501 sk:2 cgroup:unreachable:c6c <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:35595 sk:3 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15366 sk:4 cgroup:unreachable:f2a <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:35594 sk:1001 cgroup:/ v6only:1 <->                                      
UNCONN 0      0                                [::1]:323           [::]:*    ino:15367 sk:1002 cgroup:unreachable:f2a v6only:1 <->                        
UNCONN 0      0      [fe80::895:94ff:fe98:fdcb]%ens5:546           [::]:*    uid:192 ino:15541 sk:1003 cgroup:unreachable:c6c v6only:1 <->                
