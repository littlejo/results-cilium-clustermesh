1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:95:94:98:fd:cb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.246.108/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3555sec preferred_lft 3555sec
    inet6 fe80::895:94ff:fe98:fdcb/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:22:d9:af:9a:9f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.233.11/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::822:d9ff:feaf:9a9f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:1b:d4:83:be:aa brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ac1b:d4ff:fe83:beaa/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:98:5d:04:5b:2b brd ff:ff:ff:ff:ff:ff
    inet 10.113.0.158/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::3098:5dff:fe04:5b2b/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 06:aa:45:14:1e:c1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4aa:45ff:fe14:1ec1/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:af:af:b8:aa:20 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::90af:afff:feb8:aa20/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc5fbde669a8d8@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:ac:72:77:1f:94 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c4ac:72ff:fe77:1f94/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc94ac4e7bcf36@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:99:0e:57:b0:66 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::8499:eff:fe57:b066/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc12a989578c73@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:5d:a4:18:94:85 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::685d:a4ff:fe18:9485/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc0de8ad17a24e@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:fb:1c:5c:b4:e1 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::ecfb:1cff:fe5c:b4e1/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc473a5228b708@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:2c:89:c2:93:d1 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::302c:89ff:fec2:93d1/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc4b4953b6297e@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:ef:cf:1d:c0:0a brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::c0ef:cfff:fe1d:c00a/64 scope link 
       valid_lft forever preferred_lft forever
