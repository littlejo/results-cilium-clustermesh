top - 12:54:16 up 30 min,  0 users,  load average: 0.53, 0.54, 0.31
Tasks:   9 total,   2 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 27.6 us, 34.5 sy,  0.0 ni, 31.0 id,  0.0 wa,  0.0 hi,  6.9 si,  0.0 st
MiB Mem :   3836.2 total,    269.6 free,   1067.9 used,   2498.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2587.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539132 304068  78072 S  20.0   7.7   1:11.18 cilium-+
   3270 root      20   0 1240432  15828  11100 S   6.7   0.4   0:00.03 cilium-+
    395 root      20   0 1229744   9848   3836 S   0.0   0.3   0:04.47 cilium-+
   3228 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3242 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3243 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3296 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3314 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3320 root      20   0 1616264   9232   6524 R   0.0   0.2   0:00.00 runc:[2+
