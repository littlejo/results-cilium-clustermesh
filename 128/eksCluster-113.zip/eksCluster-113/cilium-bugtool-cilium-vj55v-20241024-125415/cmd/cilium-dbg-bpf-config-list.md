KEY             VALUE
AgentLiveness   1887913787990
UTimeOffset     3378462107421875
