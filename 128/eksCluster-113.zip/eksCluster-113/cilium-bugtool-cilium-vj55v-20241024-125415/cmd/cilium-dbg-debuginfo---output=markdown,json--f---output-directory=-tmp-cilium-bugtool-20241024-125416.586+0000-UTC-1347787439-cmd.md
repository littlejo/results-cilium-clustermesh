markdown output at /tmp/cilium-bugtool-20241024-125416.586+0000-UTC-1347787439/cmd/cilium-debuginfo-20241024-125447.255+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125416.586+0000-UTC-1347787439/cmd/cilium-debuginfo-20241024-125447.255+0000-UTC.json
