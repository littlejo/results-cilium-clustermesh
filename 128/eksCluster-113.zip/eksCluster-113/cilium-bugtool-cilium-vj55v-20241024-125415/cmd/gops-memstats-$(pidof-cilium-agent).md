alloc: 139.81MB (146598344 bytes)
total-alloc: 3.19GB (3426831576 bytes)
sys: 227.39MB (238437716 bytes)
lookups: 0
mallocs: 76664182
frees: 75198512
heap-alloc: 139.81MB (146598344 bytes)
heap-sys: 178.92MB (187613184 bytes)
heap-idle: 14.95MB (15679488 bytes)
heap-in-use: 163.97MB (171933696 bytes)
heap-released: 3.75MB (3932160 bytes)
heap-objects: 1465670
stack-in-use: 37.03MB (38830080 bytes)
stack-sys: 37.03MB (38830080 bytes)
stack-mspan-inuse: 2.56MB (2686080 bytes)
stack-mspan-sys: 2.88MB (3019200 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 913.49KB (935417 bytes)
gc-sys: 5.54MB (5811392 bytes)
next-gc: when heap-alloc >= 146.96MB (154102344 bytes)
last-gc: 2024-10-24 12:54:01.578088294 +0000 UTC
gc-pause-total: 29.815828ms
gc-pause: 78613
gc-pause-end: 1729774441578088294
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0008358129694677318
enable-gc: true
debug-gc: false
