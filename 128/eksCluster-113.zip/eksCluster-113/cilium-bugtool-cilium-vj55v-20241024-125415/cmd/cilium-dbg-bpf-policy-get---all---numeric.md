Endpoint ID: 710
Path: /sys/fs/bpf/tc/globals/cilium_policy_00710

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1139
Path: /sys/fs/bpf/tc/globals/cilium_policy_01139

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6059931   61355     0        
Allow    Ingress     1          ANY          NONE         disabled    6153154   63633     0        
Allow    Egress      0          ANY          NONE         disabled    7369256   72243     0        


Endpoint ID: 1257
Path: /sys/fs/bpf/tc/globals/cilium_policy_01257

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2786     30        0        
Allow    Ingress     1          ANY          NONE         disabled    124012   1414      0        
Allow    Egress      0          ANY          NONE         disabled    17969    198       0        


Endpoint ID: 1681
Path: /sys/fs/bpf/tc/globals/cilium_policy_01681

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3110     30        0        
Allow    Ingress     1          ANY          NONE         disabled    123880   1412      0        
Allow    Egress      0          ANY          NONE         disabled    18094    198       0        


Endpoint ID: 1852
Path: /sys/fs/bpf/tc/globals/cilium_policy_01852

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2382
Path: /sys/fs/bpf/tc/globals/cilium_policy_02382

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377633   4405      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2518
Path: /sys/fs/bpf/tc/globals/cilium_policy_02518

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3381
Path: /sys/fs/bpf/tc/globals/cilium_policy_03381

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6233654   76899     0        
Allow    Ingress     1          ANY          NONE         disabled    62123     751       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


