[
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeedbef66_5ee6_4f04_afae_b2351d21f682.slice/cri-containerd-b044bf4fec066f9e19989e3de48687953608d2460acce572fa4e43b5349ac851.scope"
      }
    ],
    "ips": [
      "10.52.0.34"
    ],
    "name": "coredns-cc6ccd49c-c6d45",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2d954b9_e50c_4798_86b1_19bf7eaf0d0a.slice/cri-containerd-f6cbf5486681c632a2ddaa6f795dd645eada90af92e1bcc87c8cd0ffdcaa7f8c.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2d954b9_e50c_4798_86b1_19bf7eaf0d0a.slice/cri-containerd-99ce0e1dac03690a64b7a186605cb3ae7c9ff47e284afb117318174e358b905f.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2d954b9_e50c_4798_86b1_19bf7eaf0d0a.slice/cri-containerd-f02f167c918cdbc12a7a3de99a47c28539ec8f274f3a871bed2abad2a19eaa88.scope"
      }
    ],
    "ips": [
      "10.52.0.88"
    ],
    "name": "clustermesh-apiserver-7f444cd6b9-7ngv8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67999be0_25b5_43a5_9d3e_843dbbd83ef3.slice/cri-containerd-26ea179935aaf6b1cbdb038a732b2581823a9c4c208bbcff044d35f72b112551.scope"
      },
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67999be0_25b5_43a5_9d3e_843dbbd83ef3.slice/cri-containerd-77f096aafcaf4937aaa20b0efdb22b12fa0bb0c9cbf3a488d305e2c01c21c857.scope"
      }
    ],
    "ips": [
      "10.52.0.70"
    ],
    "name": "echo-same-node-86d9cc975c-npkfc",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9381fa82_2bff_4ae1_baa3_0a990aed16d5.slice/cri-containerd-00167287be1f4bca7f664a20e7d504928c93f121dbe2bb0560c51ea00f4808b5.scope"
      }
    ],
    "ips": [
      "10.52.0.230"
    ],
    "name": "client-974f6c69d-wbjln",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7404,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod80aeadb7_0043_4822_ab90_c0727c33db0d.slice/cri-containerd-0c9fe42f6f8bc5ec16a99ae7d26e3e4cbeebf11e6acf3831e2e92ad0893a70f0.scope"
      }
    ],
    "ips": [
      "10.52.0.116"
    ],
    "name": "coredns-cc6ccd49c-mpp4l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc9ff8551_d2f6_4fa9_9ad7_4cedb04b8da2.slice/cri-containerd-ddeed026589a407b5339039fed396cfbf87a34a971bb8d1b51c3b55f39352af1.scope"
      }
    ],
    "ips": [
      "10.52.0.137"
    ],
    "name": "client2-57cf4468f-56mpf",
    "namespace": "cilium-test-1"
  }
]

