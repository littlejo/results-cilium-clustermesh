markdown output at /tmp/cilium-bugtool-20241024-125420.58+0000-UTC-780947214/cmd/cilium-debuginfo-20241024-125421.795+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125420.58+0000-UTC-780947214/cmd/cilium-debuginfo-20241024-125421.795+0000-UTC.json
