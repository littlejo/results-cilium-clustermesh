IP ADDRESS        LOCAL ENDPOINT INFO
172.31.160.21:0   (localhost)                                                                                        
10.52.0.230:0     id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB   
10.52.0.34:0      id=339   sec_id=3537981 flags=0x0000 ifindex=14  mac=96:37:00:3B:B0:82 nodemac=FE:52:1F:BA:13:15   
172.31.149.14:0   (localhost)                                                                                        
10.52.0.116:0     id=2390  sec_id=3537981 flags=0x0000 ifindex=12  mac=52:89:27:C6:EB:2C nodemac=66:F6:2E:CF:21:6C   
10.52.0.70:0      id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7   
10.52.0.92:0      id=3483  sec_id=4     flags=0x0000 ifindex=10  mac=92:3F:47:02:B1:AF nodemac=16:44:6C:80:6C:84     
10.52.0.137:0     id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76   
10.52.0.88:0      id=1942  sec_id=3478078 flags=0x0000 ifindex=18  mac=16:46:3E:EB:AA:11 nodemac=C6:BD:4C:BE:76:2F   
10.52.0.54:0      (localhost)                                                                                        
