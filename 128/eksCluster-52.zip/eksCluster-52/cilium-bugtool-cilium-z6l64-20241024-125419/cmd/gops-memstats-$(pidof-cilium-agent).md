alloc: 99.50MB (104329912 bytes)
total-alloc: 3.03GB (3255594056 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 74155537
frees: 73317358
heap-alloc: 99.50MB (104329912 bytes)
heap-sys: 172.66MB (181051392 bytes)
heap-idle: 42.32MB (44376064 bytes)
heap-in-use: 130.34MB (136675328 bytes)
heap-released: 6.69MB (7012352 bytes)
heap-objects: 838179
stack-in-use: 35.31MB (37027840 bytes)
stack-sys: 35.31MB (37027840 bytes)
stack-mspan-inuse: 2.06MB (2160800 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 999.56KB (1023553 bytes)
gc-sys: 5.51MB (5780648 bytes)
next-gc: when heap-alloc >= 146.14MB (153243144 bytes)
last-gc: 2024-10-24 12:54:02.956165959 +0000 UTC
gc-pause-total: 11.693735ms
gc-pause: 67645
gc-pause-end: 1729774442956165959
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0005295321364628133
enable-gc: true
debug-gc: false
