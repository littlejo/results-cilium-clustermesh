1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:74:22:81:56:1d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.160.21/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3450sec preferred_lft 3450sec
    inet6 fe80::474:22ff:fe81:561d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:fa:84:17:46:5d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.149.14/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4fa:84ff:fe17:465d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:85:d7:83:24:4b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::485:d7ff:fe83:244b/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:6c:c4:47:f3:e0 brd ff:ff:ff:ff:ff:ff
    inet 10.52.0.54/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::706c:c4ff:fe47:f3e0/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether aa:8f:fd:ca:d9:cf brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a88f:fdff:feca:d9cf/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:44:6c:80:6c:84 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::1444:6cff:fe80:6c84/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc81896c1883ad@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:f6:2e:cf:21:6c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::64f6:2eff:fecf:216c/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc16197f083f6e@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:52:1f:ba:13:15 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::fc52:1fff:feba:1315/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc72a7cac5504e@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:bd:4c:be:76:2f brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c4bd:4cff:febe:762f/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc7143f20e0952@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:91:81:74:17:d7 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b491:81ff:fe74:17d7/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcaafb01622ace@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:82:43:f1:a4:cb brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::5882:43ff:fef1:a4cb/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcc95d5002dfba@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:82:27:37:6b:76 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::e882:27ff:fe37:6b76/64 scope link 
       valid_lft forever preferred_lft forever
