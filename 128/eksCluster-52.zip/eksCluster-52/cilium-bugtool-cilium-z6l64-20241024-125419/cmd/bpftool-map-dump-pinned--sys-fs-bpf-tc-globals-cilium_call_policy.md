key: 53 01 00 00  value: 4e 02 00 00
key: d9 01 00 00  value: dd 0c 00 00
key: 58 03 00 00  value: 17 0d 00 00
key: 96 07 00 00  value: 89 02 00 00
key: 56 09 00 00  value: 20 02 00 00
key: 77 09 00 00  value: 16 0d 00 00
key: 9b 0d 00 00  value: 2e 02 00 00
Found 7 elements
