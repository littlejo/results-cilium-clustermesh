{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.504Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.129Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.134Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.187Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.202Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.226Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.468Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.479Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.546Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.564Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.604Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.204Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.212Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.247Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.257Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.294Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.294Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.333Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.587Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.595Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.651Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.656Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.701Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.300Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.307Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.330Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.349Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.392Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.404Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.444Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.662Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.666Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.733Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.743Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.782Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.294Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.322Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.354Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.411Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.420Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.445Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.634Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.638Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.692Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.707Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.744Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.136Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.146Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.191Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.197Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.225Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.437Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.444Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.490Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.515Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.533Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.918Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.006Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.018Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.076Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.088Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.115Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.328Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.351Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.391Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.400Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.430Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.837Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.872Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.884Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.917Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.921Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.957Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.246Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.261Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.314Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.327Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.357Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.762Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.791Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.806Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.845Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.848Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.882Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.122Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.177Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.223Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.291Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.295Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.666Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.677Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.719Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.735Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.760Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.008Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.023Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.075Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.087Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.122Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.433Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.439Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.494Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.501Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.539Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.778Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.792Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.854Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.870Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.892Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.212Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.242Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.257Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.289Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.290Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.307Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.553Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.561Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.572Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.603Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.257Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.259Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.295Z",
  "value": "id=473   sec_id=3523357 flags=0x0000 ifindex=20  mac=82:B7:B0:E5:94:B4 nodemac=B6:91:81:74:17:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.324Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.338Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.622Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.628Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.279Z",
  "value": "id=856   sec_id=3535422 flags=0x0000 ifindex=22  mac=2E:37:B9:DD:8E:0A nodemac=5A:82:43:F1:A4:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.291Z",
  "value": "id=2423  sec_id=3475753 flags=0x0000 ifindex=24  mac=CA:CE:49:4F:82:55 nodemac=EA:82:27:37:6B:76"
}

