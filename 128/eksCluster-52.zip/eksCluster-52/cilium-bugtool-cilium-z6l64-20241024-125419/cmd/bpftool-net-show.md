xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 550
ens6(5) clsact/ingress cil_from_netdev-ens6 id 556
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 543
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 537
cilium_host(7) clsact/egress cil_from_host-cilium_host id 534
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 567
lxc81896c1883ad(12) clsact/ingress cil_from_container-lxc81896c1883ad id 526
lxc16197f083f6e(14) clsact/ingress cil_from_container-lxc16197f083f6e id 591
lxc72a7cac5504e(18) clsact/ingress cil_from_container-lxc72a7cac5504e id 647
lxc7143f20e0952(20) clsact/ingress cil_from_container-lxc7143f20e0952 id 3301
lxcaafb01622ace(22) clsact/ingress cil_from_container-lxcaafb01622ace id 3355
lxcc95d5002dfba(24) clsact/ingress cil_from_container-lxcc95d5002dfba id 3368

flow_dissector:

netfilter:

