top - 12:54:20 up 32 min,  0 users,  load average: 0.38, 0.48, 0.29
Tasks:   5 total,   1 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 46.7 us, 40.0 sy,  0.0 ni, 13.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    292.4 free,   1045.9 used,   2497.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2609.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 294944  81340 S  66.7   7.5   1:04.70 cilium-+
    417 root      20   0 1229744  10016   3836 S   0.0   0.3   0:04.26 cilium-+
   3214 root      20   0 1240432  16624  11164 S   0.0   0.4   0:00.03 cilium-+
   3278 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3302 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
