Endpoint ID: 79
Path: /sys/fs/bpf/tc/globals/cilium_policy_00079

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 339
Path: /sys/fs/bpf/tc/globals/cilium_policy_00339

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3034     29        0        
Allow    Ingress     1          ANY          NONE         disabled    149216   1719      0        
Allow    Egress      0          ANY          NONE         disabled    19764    219       0        


Endpoint ID: 473
Path: /sys/fs/bpf/tc/globals/cilium_policy_00473

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    349720   4083      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 856
Path: /sys/fs/bpf/tc/globals/cilium_policy_00856

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1942
Path: /sys/fs/bpf/tc/globals/cilium_policy_01942

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5390742   55592     0        
Allow    Ingress     1          ANY          NONE         disabled    4984839   52317     0        
Allow    Egress      0          ANY          NONE         disabled    5551776   57342     0        


Endpoint ID: 2390
Path: /sys/fs/bpf/tc/globals/cilium_policy_02390

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2862     31        0        
Allow    Ingress     1          ANY          NONE         disabled    149721   1722      0        
Allow    Egress      0          ANY          NONE         disabled    20793    232       0        


Endpoint ID: 2423
Path: /sys/fs/bpf/tc/globals/cilium_policy_02423

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3483
Path: /sys/fs/bpf/tc/globals/cilium_policy_03483

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6172256   76387     0        
Allow    Ingress     1          ANY          NONE         disabled    64917     788       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


