Node 0, zone      DMA     43      1      1     13     19      5      6      4      1      3     46 
Node 0, zone   Normal    818     98      2     68     19      3      3      1      1      2      7 
