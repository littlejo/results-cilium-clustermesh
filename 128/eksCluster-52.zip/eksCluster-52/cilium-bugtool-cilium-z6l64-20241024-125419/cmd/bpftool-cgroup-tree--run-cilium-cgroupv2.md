CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod347063b1_366e_46d7_ab51_5ca6bf393721.slice/cri-containerd-1a7744277a94f4660dc31d19d30fbd073cb32264e2592c83f25dcb5d1a0d7ae1.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod347063b1_366e_46d7_ab51_5ca6bf393721.slice/cri-containerd-96342625eed2dda612a69107b7b9f9f3902a62bb8141a1c9c4c9812ad22b048a.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod80aeadb7_0043_4822_ab90_c0727c33db0d.slice/cri-containerd-0c9fe42f6f8bc5ec16a99ae7d26e3e4cbeebf11e6acf3831e2e92ad0893a70f0.scope
    581      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod80aeadb7_0043_4822_ab90_c0727c33db0d.slice/cri-containerd-a2b6b2b778c353f22ee41d308db5fedc7777b04d7dfc17112452d269c22449f1.scope
    577      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5847b7fd_a058_47c0_a38c_9d728335f851.slice/cri-containerd-02a0e91010e45d50bd24a8d50a40089faef8143709013ac3d72963b839316785.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5847b7fd_a058_47c0_a38c_9d728335f851.slice/cri-containerd-f36d163cee8b9d03577a19a8ab20a371486fc61e74761f66d71c17322f5542ab.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeedbef66_5ee6_4f04_afae_b2351d21f682.slice/cri-containerd-b044bf4fec066f9e19989e3de48687953608d2460acce572fa4e43b5349ac851.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeedbef66_5ee6_4f04_afae_b2351d21f682.slice/cri-containerd-0f34916cd7269552b55571701a1bb3fe65a741f1004a1c1cbdae811d2c295d7a.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc9ff8551_d2f6_4fa9_9ad7_4cedb04b8da2.slice/cri-containerd-ddeed026589a407b5339039fed396cfbf87a34a971bb8d1b51c3b55f39352af1.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc9ff8551_d2f6_4fa9_9ad7_4cedb04b8da2.slice/cri-containerd-98b7cadebe0e8a58c14e386e4dad1f490e9054fc83d6ac73c24604171af273bb.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67999be0_25b5_43a5_9d3e_843dbbd83ef3.slice/cri-containerd-77f096aafcaf4937aaa20b0efdb22b12fa0bb0c9cbf3a488d305e2c01c21c857.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67999be0_25b5_43a5_9d3e_843dbbd83ef3.slice/cri-containerd-362cb109fc2b7f9f7f1392a1f7a8e2b566b5e800d66dfef725f45525eff55d6b.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67999be0_25b5_43a5_9d3e_843dbbd83ef3.slice/cri-containerd-26ea179935aaf6b1cbdb038a732b2581823a9c4c208bbcff044d35f72b112551.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc2b886a5_2e3d_417e_835d_0a9272b24666.slice/cri-containerd-2e9390bdaa76d5dcb6a372643de5d8da1d5f5ce1294f2b221f1a12e43c64dcc6.scope
    114      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc2b886a5_2e3d_417e_835d_0a9272b24666.slice/cri-containerd-66eb286724c2969312cd4149e470a2505f82eaa728ac6abb3562a3d417ef4c18.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9381fa82_2bff_4ae1_baa3_0a990aed16d5.slice/cri-containerd-be5a46d05e695f8210445ca0dc01172124f0e1e37262612ded15c73735e2633c.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9381fa82_2bff_4ae1_baa3_0a990aed16d5.slice/cri-containerd-00167287be1f4bca7f664a20e7d504928c93f121dbe2bb0560c51ea00f4808b5.scope
    727      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2d954b9_e50c_4798_86b1_19bf7eaf0d0a.slice/cri-containerd-f02f167c918cdbc12a7a3de99a47c28539ec8f274f3a871bed2abad2a19eaa88.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2d954b9_e50c_4798_86b1_19bf7eaf0d0a.slice/cri-containerd-460a29073653c133b0eaaeef467e6ad99b43190390c03fbf9f30625dd784704e.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2d954b9_e50c_4798_86b1_19bf7eaf0d0a.slice/cri-containerd-99ce0e1dac03690a64b7a186605cb3ae7c9ff47e284afb117318174e358b905f.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2d954b9_e50c_4798_86b1_19bf7eaf0d0a.slice/cri-containerd-f6cbf5486681c632a2ddaa6f795dd645eada90af92e1bcc87c8cd0ffdcaa7f8c.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ed9f4a6_aa35_4248_88e1_ea00448075f5.slice/cri-containerd-9a3ce5777c5c31c5e7b5051fb8f58780843f0738ec831b62f70e4db2038b55d0.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ed9f4a6_aa35_4248_88e1_ea00448075f5.slice/cri-containerd-b44739c3a364f831b0a6bac092c9b1ba545c93a9565a6a45a070fcf2d3ec6f8c.scope
    98       cgroup_device   multi                                          
