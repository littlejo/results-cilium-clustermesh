filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcaafb01622ace direct-action not_in_hw id 3355 tag 568c650b104ea15b jited 
