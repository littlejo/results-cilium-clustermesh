filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc72a7cac5504e direct-action not_in_hw id 647 tag e04819b931206fae jited 
