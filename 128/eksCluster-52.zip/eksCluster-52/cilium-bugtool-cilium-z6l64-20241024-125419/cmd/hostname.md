ip-172-31-160-21.eu-west-3.compute.internal
