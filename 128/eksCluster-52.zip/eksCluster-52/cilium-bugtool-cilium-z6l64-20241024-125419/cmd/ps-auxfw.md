USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3228  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3221  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3220  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3214  0.0  0.4 1240432 16624 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3266  0.0  0.0   6408  1648 ?        R    12:54   0:00  \_ ps auxfw
root        3270  0.0  0.4 1240432 16624 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  4.1  7.2 1538804 284336 ?      Ssl  12:28   1:04 cilium-agent --config-dir=/tmp/cilium/config-map
root         417  0.2  0.2 1229744 10016 ?       Sl   12:28   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
