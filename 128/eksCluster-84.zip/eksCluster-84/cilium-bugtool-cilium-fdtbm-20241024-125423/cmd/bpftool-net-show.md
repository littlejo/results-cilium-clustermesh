xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 499
ens6(5) clsact/ingress cil_from_netdev-ens6 id 508
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 497
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 490
cilium_host(7) clsact/egress cil_from_host-cilium_host id 489
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 482
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 537
lxce108a0723eab(12) clsact/ingress cil_from_container-lxce108a0723eab id 526
lxc8c984108562c(14) clsact/ingress cil_from_container-lxc8c984108562c id 540
lxcc47936e04360(18) clsact/ingress cil_from_container-lxcc47936e04360 id 622
lxc556b8dbd3ccc(20) clsact/ingress cil_from_container-lxc556b8dbd3ccc id 3333
lxc985bd4090f9e(22) clsact/ingress cil_from_container-lxc985bd4090f9e id 3289
lxc0b95e642762c(24) clsact/ingress cil_from_container-lxc0b95e642762c id 3342

flow_dissector:

netfilter:

