[
  {
    "containers": [
      {
        "cgroup-id": 7620,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7674f97b_e2b6_4563_8e5d_ff2683d506f8.slice/cri-containerd-0e809a022ccf0038195bd3216c8f8a2aad90212a5a8473cfe3f4d6761612d25f.scope"
      }
    ],
    "ips": [
      "10.84.0.195"
    ],
    "name": "coredns-cc6ccd49c-v7sfq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod22f13fea_6432_41dc_bca4_c912723b2463.slice/cri-containerd-e92b51a6069f076d0643f564391e24fdd5651017aebd83d0af738ff87ba12a41.scope"
      }
    ],
    "ips": [
      "10.84.0.179"
    ],
    "name": "client2-57cf4468f-77j7p",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7704,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc210a4ed_4ded_49ac_b323_4530c2bcce9e.slice/cri-containerd-d778aa85ef2b7af249794b01c78fa87446a9f68b4cc32a4f25be7eea0a29f8ef.scope"
      }
    ],
    "ips": [
      "10.84.0.129"
    ],
    "name": "coredns-cc6ccd49c-9rsc6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod66bcf055_4671_4b45_b134_1e93508961f1.slice/cri-containerd-353c37491be22f482080604360c8e1bd05b3519f150a61846ddad361a1dbee5a.scope"
      },
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod66bcf055_4671_4b45_b134_1e93508961f1.slice/cri-containerd-8835e049bb7b16b2083b716ab65465b2b4caa69a40d67f8aac018f61d3b6f871.scope"
      }
    ],
    "ips": [
      "10.84.0.104"
    ],
    "name": "echo-same-node-86d9cc975c-9vkdx",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9180,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc03046a3_9253_4449_a401_c0bcadc68282.slice/cri-containerd-ffa7c554bdced1b231554d2cf9a55459f642da74136d4b62a5ea994b86fb8f44.scope"
      },
      {
        "cgroup-id": 9096,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc03046a3_9253_4449_a401_c0bcadc68282.slice/cri-containerd-b50c3459e03aa2250b860e50d14b210702fe6bf5d7dc2c455e78287c142d7c61.scope"
      },
      {
        "cgroup-id": 9264,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc03046a3_9253_4449_a401_c0bcadc68282.slice/cri-containerd-7575b99b2cdd1002d76bbddeb4762b35ea8a3a43291f3a3569b08427b590f757.scope"
      }
    ],
    "ips": [
      "10.84.0.45"
    ],
    "name": "clustermesh-apiserver-754fc6bb8c-pf49j",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2636c682_fc0d_4cef_af09_5d6c170db296.slice/cri-containerd-40aab9029c3867d4d5502d219c8c6f6e5628bde7096db73157002c4162bb15da.scope"
      }
    ],
    "ips": [
      "10.84.0.60"
    ],
    "name": "client-974f6c69d-9mkg8",
    "namespace": "cilium-test-1"
  }
]

