Found 127 cluster configurations

Cluster "cmesh1":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh1

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh10":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh10

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh100":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh100

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh101":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh101

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh102":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh102

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh103":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh103

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh104":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh104

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh105":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh105

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh106":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh106

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh107":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh107

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh108":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh108

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh109":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh109

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh11":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh11

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh110":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh110

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh111":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh111

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh112":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh112

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh113":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh113

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh114":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh114

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh115":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh115

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh116":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh116

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh117":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh117

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh118":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh118

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh119":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh119

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh12":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh12

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh120":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh120

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh121":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh121

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh122":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh122

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh123":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh123

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh124":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh124

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh125":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh125

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh126":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh126

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh127":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh127

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh128":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh128

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh13":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh13

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh14":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh14

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh15":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh15

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh16":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh16

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh17":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh17

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh18":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh18

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh19":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh19

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh2":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh2

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh20":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh20

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh21":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh21

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh22":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh22

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh23":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh23

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh24":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh24

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh25":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh25

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh26":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh26

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh27":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh27

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh28":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh28

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh29":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh29

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh3":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh3

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh30":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh30

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh31":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh31

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh32":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh32

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh33":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh33

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh34":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh34

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh35":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh35

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh36":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh36

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh37":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh37

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh38":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh38

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh39":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh39

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh4":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh4

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh40":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh40

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh41":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh41

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh42":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh42

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh43":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh43

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh44":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh44

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh45":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh45

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh46":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh46

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh47":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh47

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh48":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh48

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh49":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh49

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh5":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh5

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh50":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh50

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh51":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh51

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh52":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh52

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh53":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh53

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh54":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh54

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh55":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh55

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh56":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh56

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh57":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh57

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh58":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh58

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh59":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh59

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh6":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh6

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh60":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh60

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh61":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh61

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh62":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh62

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh63":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh63

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh64":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh64

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh65":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh65

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh66":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh66

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh67":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh67

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh68":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh68

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh69":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh69

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh7":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh7

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh70":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh70

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh71":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh71

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh72":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh72

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh73":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh73

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh74":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh74

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh75":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh75

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh76":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh76

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh77":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh77

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh78":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh78

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh79":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh79

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh8":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh8

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh80":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh80

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh81":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh81

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh82":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh82

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh83":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh83

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh84":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh84

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh86":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh86

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh87":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh87

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh88":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh88

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh89":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh89

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh9":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh9

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh90":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh90

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh91":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh91

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh92":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh92

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh93":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh93

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh94":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh94

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh95":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh95

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh96":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh96

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh97":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh97

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh98":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh98

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1

Cluster "cmesh99":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh99

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.45.183
     ✅ TCP connection successfully established to 10.100.45.183:2379
     ✅ TLS connection successfully established to 10.100.45.183:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       7d:59:9d:2a:79:1c:9a:43:27:eb:cb:40:2a:0b:b0:f5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:30:14 +0000 UTC
          Not after:   2027-10-24 12:30:14 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       27:c4:c6:91:dd:4b:a2:ae:4c:73:00:69:84:7b:32:2e:3f:1e:89:9e
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 12:37:00 +0000 UTC
          Not after:   2027-10-24 12:37:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 88a38472f26960d1
