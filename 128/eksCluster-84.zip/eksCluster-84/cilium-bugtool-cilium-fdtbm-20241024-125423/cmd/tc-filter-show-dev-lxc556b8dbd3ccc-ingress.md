filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc556b8dbd3ccc direct-action not_in_hw id 3333 tag f9f8aaa5d6cf0d97 jited 
