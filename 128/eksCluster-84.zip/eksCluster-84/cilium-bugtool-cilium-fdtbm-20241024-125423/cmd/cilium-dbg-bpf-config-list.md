KEY             VALUE
AgentLiveness   1945873357123
UTimeOffset     3378462011718750
