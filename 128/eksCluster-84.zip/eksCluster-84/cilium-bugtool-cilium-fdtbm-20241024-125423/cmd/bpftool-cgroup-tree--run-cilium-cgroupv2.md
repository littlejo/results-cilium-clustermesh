CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod564bf0bd_654e_4d32_8f65_269826dbe4ea.slice/cri-containerd-3fa47ba9f5c7fccc952ca26e7e931b10143fe90894547907dd85a0a4074a7ff8.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod564bf0bd_654e_4d32_8f65_269826dbe4ea.slice/cri-containerd-4e6d956c723f1739f43f2a4fa18cef64a884d26f01dd2eae924648f690609ed6.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4fef9b1b_da51_428b_8686_029e1f03b24a.slice/cri-containerd-25c38803cfc8d25c53c64af4b58abd369947b62c614b0ad517ccef2ced7e2b1c.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4fef9b1b_da51_428b_8686_029e1f03b24a.slice/cri-containerd-c5056831f756b8418aa3b6bac3866830ab880fe9170e8d31d60883034e064b89.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc210a4ed_4ded_49ac_b323_4530c2bcce9e.slice/cri-containerd-d778aa85ef2b7af249794b01c78fa87446a9f68b4cc32a4f25be7eea0a29f8ef.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc210a4ed_4ded_49ac_b323_4530c2bcce9e.slice/cri-containerd-f3f7069ca771622705840f3ddada08ab8dfb87d834566ae9cbbcd33a2358ac8c.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7674f97b_e2b6_4563_8e5d_ff2683d506f8.slice/cri-containerd-b68399e998a23c03ac9ea557f7c94a3d13eebecf200a5dbacc5182887666437e.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7674f97b_e2b6_4563_8e5d_ff2683d506f8.slice/cri-containerd-0e809a022ccf0038195bd3216c8f8a2aad90212a5a8473cfe3f4d6761612d25f.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod22f13fea_6432_41dc_bca4_c912723b2463.slice/cri-containerd-e92b51a6069f076d0643f564391e24fdd5651017aebd83d0af738ff87ba12a41.scope
    699      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod22f13fea_6432_41dc_bca4_c912723b2463.slice/cri-containerd-688fdfe14cf995a5dddffd236bf562845977cfe7b8f0158072a471c933ea8e8a.scope
    691      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2928b97a_7993_4d4f_a0cd_16043dcaa31a.slice/cri-containerd-cabde255847122d6a70267ca1b1a1589fc5f6ec255d9426a75b16d3e155def2a.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2928b97a_7993_4d4f_a0cd_16043dcaa31a.slice/cri-containerd-094edcdc988e476da3f02dc42c001dc18aafd3e4ac52843574c2e4b251c51852.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod66bcf055_4671_4b45_b134_1e93508961f1.slice/cri-containerd-353c37491be22f482080604360c8e1bd05b3519f150a61846ddad361a1dbee5a.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod66bcf055_4671_4b45_b134_1e93508961f1.slice/cri-containerd-8835e049bb7b16b2083b716ab65465b2b4caa69a40d67f8aac018f61d3b6f871.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod66bcf055_4671_4b45_b134_1e93508961f1.slice/cri-containerd-25c713b5a6891a1380455babb216224063daf8d03d63086fc641a2eea4f2d971.scope
    695      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a6c8751_b685_47df_ad8a_5b94020bde19.slice/cri-containerd-5b3c4e2963ab01fd5376cc485609202b01e5fd992eb9a101ae482614980eeeeb.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a6c8751_b685_47df_ad8a_5b94020bde19.slice/cri-containerd-ab37c1151751d89af1bb48200aa30c5d86e4b68ad9c2c57104913f3b8e4621fc.scope
    110      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc03046a3_9253_4449_a401_c0bcadc68282.slice/cri-containerd-b50c3459e03aa2250b860e50d14b210702fe6bf5d7dc2c455e78287c142d7c61.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc03046a3_9253_4449_a401_c0bcadc68282.slice/cri-containerd-0e02939db6b8f42c3fb7d7fc965465ac8cd7db14e090add2bfd08009e3a1161d.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc03046a3_9253_4449_a401_c0bcadc68282.slice/cri-containerd-ffa7c554bdced1b231554d2cf9a55459f642da74136d4b62a5ea994b86fb8f44.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc03046a3_9253_4449_a401_c0bcadc68282.slice/cri-containerd-7575b99b2cdd1002d76bbddeb4762b35ea8a3a43291f3a3569b08427b590f757.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2636c682_fc0d_4cef_af09_5d6c170db296.slice/cri-containerd-40aab9029c3867d4d5502d219c8c6f6e5628bde7096db73157002c4162bb15da.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2636c682_fc0d_4cef_af09_5d6c170db296.slice/cri-containerd-679bcef12aa3e3a8e5cb1bbfc409361db0e02ad3c14954a5a1790f69c56dd855.scope
    665      cgroup_device   multi                                          
