Endpoint ID: 282
Path: /sys/fs/bpf/tc/globals/cilium_policy_00282

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    210150   1901      0        
Allow    Ingress     1          ANY          NONE         disabled    136077   1558      0        
Allow    Egress      0          ANY          NONE         disabled    65400    650       0        


Endpoint ID: 374
Path: /sys/fs/bpf/tc/globals/cilium_policy_00374

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    381849   4455      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 542
Path: /sys/fs/bpf/tc/globals/cilium_policy_00542

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 574
Path: /sys/fs/bpf/tc/globals/cilium_policy_00574

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2135
Path: /sys/fs/bpf/tc/globals/cilium_policy_02135

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    213756   1925      0        
Allow    Ingress     1          ANY          NONE         disabled    137397   1578      0        
Allow    Egress      0          ANY          NONE         disabled    65822    649       0        


Endpoint ID: 2671
Path: /sys/fs/bpf/tc/globals/cilium_policy_02671

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6121542   61677     0        
Allow    Ingress     1          ANY          NONE         disabled    5403163   57080     0        
Allow    Egress      0          ANY          NONE         disabled    7034842   69420     0        


Endpoint ID: 2693
Path: /sys/fs/bpf/tc/globals/cilium_policy_02693

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6211766   76884     0        
Allow    Ingress     1          ANY          NONE         disabled    62983     762       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3885
Path: /sys/fs/bpf/tc/globals/cilium_policy_03885

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


