key: 1a 01 00 00  value: 0d 02 00 00
key: 76 01 00 00  value: d7 0c 00 00
key: 1e 02 00 00  value: 0b 0d 00 00
key: 3e 02 00 00  value: 13 0d 00 00
key: 57 08 00 00  value: 23 02 00 00
key: 6f 0a 00 00  value: 6b 02 00 00
key: 85 0a 00 00  value: 1f 02 00 00
Found 7 elements
