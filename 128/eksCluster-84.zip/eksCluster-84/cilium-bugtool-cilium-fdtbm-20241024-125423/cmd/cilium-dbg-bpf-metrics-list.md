REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     133354    10796520    677    bpf_overlay.c
Interface                   INGRESS     675226    248060627   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      133884    10845479    53     encap.h
Success                     EGRESS      151482    19974052    1308   bpf_lxc.c
Success                     EGRESS      57158     4631739     1694   bpf_host.c
Success                     EGRESS      8128      1347097     86     l3.h
Success                     INGRESS     175220    20170918    86     l3.h
Success                     INGRESS     260175    27725266    235    trace.h
Unsupported L3 protocol     EGRESS      78        5920        1492   bpf_lxc.c
