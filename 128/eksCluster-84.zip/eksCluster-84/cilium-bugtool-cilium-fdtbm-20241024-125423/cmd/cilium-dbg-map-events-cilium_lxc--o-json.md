{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.767Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.786Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.822Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.404Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.409Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.450Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.467Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.488Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.724Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.732Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.800Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.812Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.854Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.426Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.466Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.491Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.509Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.532Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.787Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.792Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.863Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.871Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.904Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.282Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.283Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.330Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.332Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.381Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.397Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.421Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.627Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.630Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.684Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.690Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.736Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.264Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.271Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.304Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.327Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.356Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.374Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.412Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.621Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.635Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.735Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.758Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.792Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.185Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.186Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.242Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.261Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.293Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.498Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.507Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.561Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.571Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.610Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.054Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.092Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.120Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.158Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.179Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.417Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.433Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.494Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.497Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.541Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.846Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.929Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.942Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.999Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.041Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.057Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.237Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.237Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.318Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.324Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.358Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.772Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.781Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.830Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.839Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.868Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.096Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.122Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.168Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.233Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.239Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.648Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.682Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.690Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.735Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.737Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.779Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.035Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.066Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.125Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.182Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.225Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.512Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.525Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.586Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.596Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.621Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.843Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.867Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.920Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.931Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.961Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.308Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.324Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.368Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.379Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.406Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.632Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.648Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.657Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.664Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.693Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.350Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.350Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.399Z",
  "value": "id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.417Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.482Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.727Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.738Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.373Z",
  "value": "id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.377Z",
  "value": "id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52"
}

