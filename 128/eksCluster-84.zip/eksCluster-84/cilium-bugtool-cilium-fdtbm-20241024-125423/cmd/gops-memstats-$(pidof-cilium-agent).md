alloc: 115.89MB (121520320 bytes)
total-alloc: 3.13GB (3357832352 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 76010094
frees: 74933266
heap-alloc: 115.89MB (121520320 bytes)
heap-sys: 176.58MB (185155584 bytes)
heap-idle: 33.62MB (35250176 bytes)
heap-in-use: 142.96MB (149905408 bytes)
heap-released: 4.34MB (4546560 bytes)
heap-objects: 1076828
stack-in-use: 35.38MB (37093376 bytes)
stack-sys: 35.38MB (37093376 bytes)
stack-mspan-inuse: 2.22MB (2327680 bytes)
stack-mspan-sys: 2.82MB (2953920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 925.95KB (948177 bytes)
gc-sys: 5.53MB (5801056 bytes)
next-gc: when heap-alloc >= 151.17MB (158513880 bytes)
last-gc: 2024-10-24 12:54:30.345799882 +0000 UTC
gc-pause-total: 10.103175ms
gc-pause: 62935
gc-pause-end: 1729774470345799882
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006023060903970112
enable-gc: true
debug-gc: false
