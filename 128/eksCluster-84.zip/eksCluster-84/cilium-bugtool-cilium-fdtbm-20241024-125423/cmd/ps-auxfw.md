USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3238  0.0  0.4 1240176 16132 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3261  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3263  0.0  0.0   3720  1284 ?        R    12:54   0:00  \_ bash -c hostname
root        3237  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3225  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3219  0.0  0.0 1228744 3660 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3206  0.0  0.0 1229000 3656 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  4.5  7.4 1539060 292004 ?      Ssl  12:30   1:04 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.3  0.2 1229744 9180 ?        Sl   12:30   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
