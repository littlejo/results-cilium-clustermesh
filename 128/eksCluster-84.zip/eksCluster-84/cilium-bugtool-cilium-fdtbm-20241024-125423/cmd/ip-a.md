1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:b8:2a:35:44:7b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.140.202/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3497sec preferred_lft 3497sec
    inet6 fe80::4b8:2aff:fe35:447b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:04:20:fc:fa:29 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.154.122/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::404:20ff:fefc:fa29/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:76:37:c1:47:cb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8c76:37ff:fec1:47cb/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:37:45:d6:7c:a8 brd ff:ff:ff:ff:ff:ff
    inet 10.84.0.235/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::dc37:45ff:fed6:7ca8/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether de:40:d8:b1:12:97 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::dc40:d8ff:feb1:1297/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:cb:96:c3:30:c4 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::14cb:96ff:fec3:30c4/64 scope link 
       valid_lft forever preferred_lft forever
12: lxce108a0723eab@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:23:38:93:27:a5 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b823:38ff:fe93:27a5/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc8c984108562c@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:2d:f0:40:0e:ea brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::82d:f0ff:fe40:eea/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcc47936e04360@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:3d:79:52:0b:27 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e43d:79ff:fe52:b27/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc556b8dbd3ccc@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:8e:40:d6:2f:ff brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::848e:40ff:fed6:2fff/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc985bd4090f9e@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:89:0e:fe:bd:9e brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::d889:eff:fefe:bd9e/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc0b95e642762c@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:60:95:5c:e8:52 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::4060:95ff:fe5c:e852/64 scope link 
       valid_lft forever preferred_lft forever
