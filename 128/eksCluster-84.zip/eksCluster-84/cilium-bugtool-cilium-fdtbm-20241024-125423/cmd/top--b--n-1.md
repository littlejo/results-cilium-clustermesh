top - 12:54:25 up 31 min,  0 users,  load average: 0.61, 0.54, 0.28
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s):  0.0 us, 35.7 sy,  0.0 ni, 64.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    291.2 free,   1049.4 used,   2495.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2605.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 292004  77888 S   6.7   7.4   1:04.66 cilium-+
   3238 root      20   0 1240432  16132  11164 S   6.7   0.4   0:00.03 cilium-+
    395 root      20   0 1229744   9180   3052 S   0.0   0.2   0:04.35 cilium-+
   3206 root      20   0 1229000   3656   2976 S   0.0   0.1   0:00.00 gops
   3219 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
   3225 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3237 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3273 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3291 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
