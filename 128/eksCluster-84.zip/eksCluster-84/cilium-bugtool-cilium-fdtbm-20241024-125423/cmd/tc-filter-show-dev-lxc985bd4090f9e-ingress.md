filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc985bd4090f9e direct-action not_in_hw id 3289 tag 04480d7a0203d71a jited 
