IP ADDRESS         LOCAL ENDPOINT INFO
10.84.0.104:0      id=374   sec_id=5580219 flags=0x0000 ifindex=22  mac=2E:DD:87:75:8C:92 nodemac=DA:89:0E:FE:BD:9E   
10.84.0.195:0      id=282   sec_id=5621025 flags=0x0000 ifindex=12  mac=7A:11:37:7E:60:E0 nodemac=BA:23:38:93:27:A5   
10.84.0.60:0       id=574   sec_id=5572239 flags=0x0000 ifindex=20  mac=D2:27:E2:82:2F:1A nodemac=86:8E:40:D6:2F:FF   
172.31.154.122:0   (localhost)                                                                                        
10.84.0.45:0       id=2671  sec_id=5575241 flags=0x0000 ifindex=18  mac=86:EA:EF:5A:14:3E nodemac=E6:3D:79:52:0B:27   
10.84.0.129:0      id=2135  sec_id=5621025 flags=0x0000 ifindex=14  mac=26:A0:B9:F4:7F:73 nodemac=0A:2D:F0:40:0E:EA   
10.84.0.235:0      (localhost)                                                                                        
172.31.140.202:0   (localhost)                                                                                        
10.84.0.179:0      id=542   sec_id=5609800 flags=0x0000 ifindex=24  mac=DE:24:8B:96:8D:38 nodemac=42:60:95:5C:E8:52   
10.84.0.20:0       id=2693  sec_id=4     flags=0x0000 ifindex=10  mac=42:C1:7F:CD:15:02 nodemac=16:CB:96:C3:30:C4     
