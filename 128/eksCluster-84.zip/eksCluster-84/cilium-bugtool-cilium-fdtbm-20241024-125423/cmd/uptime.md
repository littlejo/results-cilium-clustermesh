 12:54:24 up 31 min,  0 users,  load average: 0.61, 0.54, 0.28
