Node 0, zone      DMA     62      2     24     52     15     11      7      4      4      2     40 
Node 0, zone   Normal    551     89      8     15     20      6      6      4      5      2      6 
