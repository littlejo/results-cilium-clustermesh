32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:05+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:23:05+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:23:06+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:23:06+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:23:06+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:06+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:23:09+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:23:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:23:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:23+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:32:08+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
482: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:32:08+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 125
483: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:32:08+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
484: sched_cls  name tail_handle_ipv4  tag 6503138fed946baa  gpl
	loaded_at 2024-10-24T12:32:08+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
514: sched_cls  name tail_ipv4_ct_egress  tag f13d380ae159489b  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 163
516: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 166
517: sched_cls  name tail_handle_arp  tag 0d5aea48df22757e  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 167
518: sched_cls  name tail_handle_ipv4_cont  tag 748c4c465eb3d47f  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 168
520: sched_cls  name tail_handle_ipv4  tag ba7524a717ff57b4  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 169
521: sched_cls  name __send_drop_notify  tag 8a504bb5e09d9b67  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 171
524: sched_cls  name tail_ipv4_ct_ingress  tag cfef060b43d68f61  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 172
526: sched_cls  name tail_ipv4_to_endpoint  tag 9f87e83f6a695bf8  gpl
	loaded_at 2024-10-24T12:32:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 175
527: sched_cls  name cil_from_container  tag fe8f31b267106964  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 177
534: sched_cls  name handle_policy  tag 923798edcacc0e5c  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 178
535: sched_cls  name tail_handle_arp  tag 52ad0f9d9cbfd3f6  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 186
536: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 187
539: sched_cls  name __send_drop_notify  tag d21ccb1376de8837  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 190
540: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 191
541: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 192
542: sched_cls  name tail_handle_ipv4_from_host  tag 864f8501eb5571e8  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 194
544: sched_cls  name tail_handle_ipv4_from_host  tag 864f8501eb5571e8  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 197
548: sched_cls  name __send_drop_notify  tag d21ccb1376de8837  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
549: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 202
550: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 203
552: sched_cls  name tail_ipv4_to_endpoint  tag 9f93c6b68805d0a1  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,118,41,82,83,80,114,39,115,40,37,38
	btf_id 193
553: sched_cls  name __send_drop_notify  tag d21ccb1376de8837  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
554: sched_cls  name __send_drop_notify  tag 09fe55a6f9d6eada  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 207
556: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 209
557: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 210
558: sched_cls  name tail_handle_ipv4_from_host  tag 864f8501eb5571e8  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 211
559: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 212
561: sched_cls  name __send_drop_notify  tag d21ccb1376de8837  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 216
563: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 218
564: sched_cls  name tail_handle_ipv4_cont  tag 7afbbc6e45d7fbb3  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,118,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 213
565: sched_cls  name cil_from_container  tag 4d79f26c9e5d304f  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 220
566: sched_cls  name tail_handle_ipv4_from_host  tag 864f8501eb5571e8  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 219
567: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 221
570: sched_cls  name tail_ipv4_ct_ingress  tag 865c071e9f7cdc25  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 226
571: sched_cls  name tail_handle_arp  tag 02a3695687bea581  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,126
	btf_id 227
572: sched_cls  name handle_policy  tag 263addffd8c887d8  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,118,41,80,114,39,84,75,40,37,38
	btf_id 222
573: sched_cls  name tail_ipv4_ct_egress  tag f13d380ae159489b  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,118,84
	btf_id 229
574: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 228
575: sched_cls  name tail_ipv4_ct_ingress  tag a1dc77bd3d93c22a  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,118,84
	btf_id 230
576: sched_cls  name tail_handle_ipv4  tag 1a837749c480a4f3  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 231
578: sched_cls  name tail_handle_ipv4_cont  tag 0167261b3b183478  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,125,41,100,82,83,39,76,74,77,126,40,37,38,81
	btf_id 233
579: sched_cls  name cil_from_container  tag 269925f5f8b7c032  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 126,76
	btf_id 234
580: sched_cls  name tail_handle_ipv4  tag 3f293704dbe30011  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,126
	btf_id 235
581: sched_cls  name handle_policy  tag a3e680ef7b5db59c  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,126,82,83,125,41,80,100,39,84,75,40,37,38
	btf_id 236
582: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,126
	btf_id 237
583: sched_cls  name __send_drop_notify  tag 9f61190fd939dfbd  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 238
584: sched_cls  name tail_ipv4_to_endpoint  tag 9892744068e1373f  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,125,41,82,83,80,100,39,126,40,37,38
	btf_id 239
585: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
588: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
589: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
592: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: sched_cls  name tail_handle_ipv4  tag c1a9be8bf315e099  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 253
641: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 254
642: sched_cls  name cil_from_container  tag cfc033f9a2b6f591  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 255
643: sched_cls  name handle_policy  tag cffa67472fb0d901  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 256
644: sched_cls  name tail_ipv4_ct_egress  tag 03be82dcb05adde8  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 257
645: sched_cls  name tail_ipv4_ct_ingress  tag 2f35c2cfc5ea9397  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 258
646: sched_cls  name tail_handle_arp  tag fc416607c1de3860  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 259
647: sched_cls  name tail_handle_ipv4_cont  tag e221269b3f5ee8af  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 260
648: sched_cls  name tail_ipv4_to_endpoint  tag 1c0d12685b75e9f0  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 261
649: sched_cls  name __send_drop_notify  tag ebcffe222e008688  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 262
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
667: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
670: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
671: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
674: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
712: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
715: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
716: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
719: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
720: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
723: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
724: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
725: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
728: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
731: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
732: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
735: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
736: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
739: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3293: sched_cls  name tail_handle_arp  tag 73e4fdcefc68591b  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,632
	btf_id 3086
3294: sched_cls  name tail_ipv4_to_endpoint  tag 600bc67c1f26049c  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,631,41,82,83,80,157,39,632,40,37,38
	btf_id 3087
3295: sched_cls  name cil_from_container  tag f29bdc35b2a985a5  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 632,76
	btf_id 3088
3297: sched_cls  name tail_handle_ipv4_cont  tag 166442af6cc6ea82  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,631,41,157,82,83,39,76,74,77,632,40,37,38,81
	btf_id 3091
3298: sched_cls  name __send_drop_notify  tag cb8ed9dfa83f152b  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3093
3301: sched_cls  name tail_handle_ipv4  tag e69a0df54f799c54  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,632
	btf_id 3094
3306: sched_cls  name handle_policy  tag 7531c1cfd660725f  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,632,82,83,631,41,80,157,39,84,75,40,37,38
	btf_id 3097
3307: sched_cls  name tail_ipv4_ct_ingress  tag ac117416c438e306  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,632,82,83,631,84
	btf_id 3102
3309: sched_cls  name tail_ipv4_ct_egress  tag d9d4940ccaf776a9  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,632,82,83,631,84
	btf_id 3103
3310: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,632
	btf_id 3104
3347: sched_cls  name tail_handle_ipv4_cont  tag f542b98161118e61  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,643,41,151,82,83,39,76,74,77,644,40,37,38,81
	btf_id 3147
3348: sched_cls  name cil_from_container  tag aa9a05bb2f1fda1a  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 644,76
	btf_id 3148
3349: sched_cls  name tail_handle_ipv4  tag 2d2ea0b0208d48f8  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,641
	btf_id 3145
3350: sched_cls  name __send_drop_notify  tag a6531ea6c5fdd839  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3149
3351: sched_cls  name cil_from_container  tag 4ec0b90566152df5  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 641,76
	btf_id 3150
3352: sched_cls  name tail_ipv4_ct_ingress  tag f468bef565a93f0a  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,641,82,83,642,84
	btf_id 3152
3353: sched_cls  name tail_handle_arp  tag b2c90807cf131acd  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,641
	btf_id 3153
3354: sched_cls  name tail_ipv4_ct_ingress  tag 12e9e0b16563cc13  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,644,82,83,643,84
	btf_id 3151
3355: sched_cls  name tail_handle_ipv4_cont  tag 38aa30db8c5a922a  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,642,41,154,82,83,39,76,74,77,641,40,37,38,81
	btf_id 3154
3356: sched_cls  name tail_ipv4_to_endpoint  tag 78c8ed2879479f0f  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,642,41,82,83,80,154,39,641,40,37,38
	btf_id 3156
3357: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,641
	btf_id 3157
3358: sched_cls  name handle_policy  tag ce3d45887eced6ed  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,644,82,83,643,41,80,151,39,84,75,40,37,38
	btf_id 3155
3359: sched_cls  name handle_policy  tag 783c90d9cc5d6ace  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,641,82,83,642,41,80,154,39,84,75,40,37,38
	btf_id 3158
3361: sched_cls  name tail_handle_ipv4  tag 00baf2e1af934017  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,644
	btf_id 3159
3362: sched_cls  name __send_drop_notify  tag 60aa2a700e5e0050  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3162
3363: sched_cls  name tail_ipv4_ct_egress  tag 5b2a229b5b5a6850  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,641,82,83,642,84
	btf_id 3161
3364: sched_cls  name tail_ipv4_to_endpoint  tag f74d9264006a58a4  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,643,41,82,83,80,151,39,644,40,37,38
	btf_id 3163
3365: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,644
	btf_id 3164
3366: sched_cls  name tail_ipv4_ct_egress  tag 6b5a2afd137bbaac  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,644,82,83,643,84
	btf_id 3165
3367: sched_cls  name tail_handle_arp  tag 456682f2a89084d6  gpl
	loaded_at 2024-10-24T12:51:20+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,644
	btf_id 3166
