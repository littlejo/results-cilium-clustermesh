Endpoint ID: 108
Path: /sys/fs/bpf/tc/globals/cilium_policy_00108

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6061377   61334     0        
Allow    Ingress     1          ANY          NONE         disabled    5776774   61103     0        
Allow    Egress      0          ANY          NONE         disabled    7368769   72244     0        


Endpoint ID: 505
Path: /sys/fs/bpf/tc/globals/cilium_policy_00505

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    376771   4400      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 716
Path: /sys/fs/bpf/tc/globals/cilium_policy_00716

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 819
Path: /sys/fs/bpf/tc/globals/cilium_policy_00819

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3272     34        0        
Allow    Ingress     1          ANY          NONE         disabled    128859   1477      0        
Allow    Egress      0          ANY          NONE         disabled    18112    198       0        


Endpoint ID: 1027
Path: /sys/fs/bpf/tc/globals/cilium_policy_01027

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2624     26        0        
Allow    Ingress     1          ANY          NONE         disabled    128397   1470      0        
Allow    Egress      0          ANY          NONE         disabled    19243    211       0        


Endpoint ID: 1566
Path: /sys/fs/bpf/tc/globals/cilium_policy_01566

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1575
Path: /sys/fs/bpf/tc/globals/cilium_policy_01575

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6232217   76889     0        
Allow    Ingress     1          ANY          NONE         disabled    66656     806       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1710
Path: /sys/fs/bpf/tc/globals/cilium_policy_01710

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


