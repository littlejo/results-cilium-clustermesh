alloc: 136.59MB (143220416 bytes)
total-alloc: 3.18GB (3410690752 bytes)
sys: 231.07MB (242296148 bytes)
lookups: 0
mallocs: 76610513
frees: 75205501
heap-alloc: 136.59MB (143220416 bytes)
heap-sys: 184.55MB (193511424 bytes)
heap-idle: 28.09MB (29450240 bytes)
heap-in-use: 156.46MB (164061184 bytes)
heap-released: 14.87MB (15589376 bytes)
heap-objects: 1405012
stack-in-use: 35.41MB (37126144 bytes)
stack-sys: 35.41MB (37126144 bytes)
stack-mspan-inuse: 2.45MB (2568480 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 735.05KB (752689 bytes)
gc-sys: 5.52MB (5784600 bytes)
next-gc: when heap-alloc >= 148.51MB (155728296 bytes)
last-gc: 2024-10-24 12:54:09.040836722 +0000 UTC
gc-pause-total: 8.809685ms
gc-pause: 135895
gc-pause-end: 1729774449040836722
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0007077067085668414
enable-gc: true
debug-gc: false
