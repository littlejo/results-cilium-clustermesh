[
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9da3d931_4400_42ae_a6a6_69acd11feabc.slice/cri-containerd-5eb04f9a3f22439b7cfca82560aff3fa7ff07cd8c81e1e5536021a54502ec6c1.scope"
      }
    ],
    "ips": [
      "10.104.0.66"
    ],
    "name": "coredns-cc6ccd49c-8ldd7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6dd88606_7454_448b_a413_485a1bc33e4a.slice/cri-containerd-15675f953902c66311b5b55ff4556862b5f982d462a128298a60f9dd1d531116.scope"
      }
    ],
    "ips": [
      "10.104.0.79"
    ],
    "name": "coredns-cc6ccd49c-9fgh7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda141d292_c17c_46ac_b8cc_f1c7e0d7ca31.slice/cri-containerd-b0ba5b0622f16e579c9d4b93a82d248fc3e79513ffdbdafafc8b5ba20aa17e48.scope"
      }
    ],
    "ips": [
      "10.104.0.229"
    ],
    "name": "client-974f6c69d-8gnzx",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podae730d48_d8d7_4c7c_ac69_3946e03f7e5e.slice/cri-containerd-83cffea81fbd4fa99392c023fbda5449af41f2942ca5a1ecd0331816f260adc6.scope"
      }
    ],
    "ips": [
      "10.104.0.200"
    ],
    "name": "client2-57cf4468f-dnb9z",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd36c7ced_af43_4b95_be4e_4532a74bae3a.slice/cri-containerd-93ba97e6a057a46a609b23da81be9975822cc8aaf82655dca81ec22ec38ba082.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd36c7ced_af43_4b95_be4e_4532a74bae3a.slice/cri-containerd-4d11196678bc0c93e65d69f93fb9518cf59cd909c9fdd7f9f4cb7626244497d6.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd36c7ced_af43_4b95_be4e_4532a74bae3a.slice/cri-containerd-774a23cc7e6db24d511f8bf15e91f7740553f54c52faf4df580a858fa760ea55.scope"
      }
    ],
    "ips": [
      "10.104.0.216"
    ],
    "name": "clustermesh-apiserver-7f47659dc5-xcmkx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0676dbd4_6b4e_4bbf_8ae1_750a3dfc67a4.slice/cri-containerd-563d7dfb621e68a64f575a404e6d50e83e09fffd4610b61a25357fd33cbe068a.scope"
      },
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0676dbd4_6b4e_4bbf_8ae1_750a3dfc67a4.slice/cri-containerd-fcf3ddd0617c1500c3792a0b622bfe793b4bd39f2b24dbe0d0b3d3b1d94d6b27.scope"
      }
    ],
    "ips": [
      "10.104.0.5"
    ],
    "name": "echo-same-node-86d9cc975c-gzdwl",
    "namespace": "cilium-test-1"
  }
]

