xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 559
ens6(5) clsact/ingress cil_from_netdev-ens6 id 567
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 549
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 540
cilium_host(7) clsact/egress cil_from_host-cilium_host id 536
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 482
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 579
lxc9ce741e376cc(12) clsact/ingress cil_from_container-lxc9ce741e376cc id 527
lxcb30cfad2ecfc(14) clsact/ingress cil_from_container-lxcb30cfad2ecfc id 565
lxc72b5c810bb6b(18) clsact/ingress cil_from_container-lxc72b5c810bb6b id 642
lxcf4ef4b2cd15f(20) clsact/ingress cil_from_container-lxcf4ef4b2cd15f id 3348
lxcf0237d176708(22) clsact/ingress cil_from_container-lxcf0237d176708 id 3351
lxca4c3af7039ca(24) clsact/ingress cil_from_container-lxca4c3af7039ca id 3295

flow_dissector:

netfilter:

