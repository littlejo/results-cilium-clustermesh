IP ADDRESS         LOCAL ENDPOINT INFO
10.104.0.216:0     id=108   sec_id=6892285 flags=0x0000 ifindex=18  mac=9A:D4:79:85:D7:91 nodemac=06:73:B9:83:3B:8C   
10.104.0.200:0     id=1566  sec_id=6889673 flags=0x0000 ifindex=22  mac=F2:74:99:BB:08:F0 nodemac=7E:38:BF:C8:6D:83   
10.104.0.66:0      id=819   sec_id=6889063 flags=0x0000 ifindex=14  mac=52:D2:2F:15:D2:18 nodemac=2A:8C:A4:F4:B8:9E   
10.104.0.79:0      id=1027  sec_id=6889063 flags=0x0000 ifindex=12  mac=EA:F7:10:09:7D:03 nodemac=2A:DA:39:62:F1:08   
172.31.180.41:0    (localhost)                                                                                        
172.31.145.233:0   (localhost)                                                                                        
10.104.0.119:0     (localhost)                                                                                        
10.104.0.102:0     id=1575  sec_id=4     flags=0x0000 ifindex=10  mac=F2:6E:58:91:F7:55 nodemac=5E:21:CA:93:2C:41     
10.104.0.5:0       id=505   sec_id=6883961 flags=0x0000 ifindex=24  mac=0E:A8:C5:35:B7:BD nodemac=BA:08:C8:A2:4B:49   
10.104.0.229:0     id=1710  sec_id=6893058 flags=0x0000 ifindex=20  mac=9A:3B:3D:0B:AF:6A nodemac=EA:FB:37:16:5C:4B   
