filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc72b5c810bb6b direct-action not_in_hw id 642 tag cfc033f9a2b6f591 jited 
