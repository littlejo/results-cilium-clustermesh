top - 12:54:16 up 31 min,  0 users,  load average: 0.18, 0.31, 0.20
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 16.7 us, 30.0 sy,  0.0 ni, 50.0 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   3836.2 total,    293.0 free,   1045.3 used,   2497.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2609.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 295148  79488 S   0.0   7.5   1:07.02 cilium-+
    394 root      20   0 1229744  10192   3836 S   0.0   0.3   0:04.41 cilium-+
   3339 root      20   0 1240432  16252  11292 S   0.0   0.4   0:00.03 cilium-+
   3349 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3381 root      20   0    6576   2420   2096 R   0.0   0.1   0:00.00 top
   3400 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
