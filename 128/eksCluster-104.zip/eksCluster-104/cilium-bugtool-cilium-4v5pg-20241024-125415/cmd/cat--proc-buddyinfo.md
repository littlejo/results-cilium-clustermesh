Node 0, zone      DMA     91     38     30      6      1      6      5      3      2      2     44 
Node 0, zone   Normal    496     27     24     22      7      2      2      1      1      2      8 
