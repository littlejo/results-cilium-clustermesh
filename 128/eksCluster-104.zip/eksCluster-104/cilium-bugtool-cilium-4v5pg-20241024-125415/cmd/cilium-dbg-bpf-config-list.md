KEY             VALUE
AgentLiveness   1904237005440
UTimeOffset     3378462076171875
