1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a3:52:47:29:cd brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.180.41/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3536sec preferred_lft 3536sec
    inet6 fe80::4a3:52ff:fe47:29cd/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:36:e4:13:a9:4d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.145.233/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::436:e4ff:fe13:a94d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:ef:e5:4f:e0:ca brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9cef:e5ff:fe4f:e0ca/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:22:b5:8a:38:48 brd ff:ff:ff:ff:ff:ff
    inet 10.104.0.119/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b422:b5ff:fe8a:3848/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 92:1d:fa:af:03:a5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::901d:faff:feaf:3a5/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:21:ca:93:2c:41 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::5c21:caff:fe93:2c41/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc9ce741e376cc@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:da:39:62:f1:08 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::28da:39ff:fe62:f108/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcb30cfad2ecfc@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:8c:a4:f4:b8:9e brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::288c:a4ff:fef4:b89e/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc72b5c810bb6b@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:73:b9:83:3b:8c brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::473:b9ff:fe83:3b8c/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcf4ef4b2cd15f@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:fb:37:16:5c:4b brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::e8fb:37ff:fe16:5c4b/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcf0237d176708@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:38:bf:c8:6d:83 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::7c38:bfff:fec8:6d83/64 scope link 
       valid_lft forever preferred_lft forever
24: lxca4c3af7039ca@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:08:c8:a2:4b:49 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::b808:c8ff:fea2:4b49/64 scope link 
       valid_lft forever preferred_lft forever
