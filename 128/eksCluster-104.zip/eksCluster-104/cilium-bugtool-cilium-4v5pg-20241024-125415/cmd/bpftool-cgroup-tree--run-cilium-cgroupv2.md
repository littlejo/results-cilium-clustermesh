CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6dd88606_7454_448b_a413_485a1bc33e4a.slice/cri-containerd-807a9cbb1246a68e15b6d8075e8b79df0f093c0911a947242050100fc7e8bdd2.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6dd88606_7454_448b_a413_485a1bc33e4a.slice/cri-containerd-15675f953902c66311b5b55ff4556862b5f982d462a128298a60f9dd1d531116.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14f8cee8_ee71_4d60_988f_76c162cc485b.slice/cri-containerd-4249a12d4dcf979758063c251174ca1f79e66d6d2cef325dcaaca19aa143f517.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14f8cee8_ee71_4d60_988f_76c162cc485b.slice/cri-containerd-241e0c16d3f12dbec89685fcf6f36903f217bca81ed6865fc5550e2c55aec367.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7c4f649f_86b5_4a27_a796_8fb7b7c0a0a3.slice/cri-containerd-2a6619c5d3627a68e4c00f64766e2618e36879f8d8c7eafa363f52497bca86ec.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7c4f649f_86b5_4a27_a796_8fb7b7c0a0a3.slice/cri-containerd-c90606ebf9e15bf53e58fd19ce37296b6256a0b1731498c02d0a6188eaecc02a.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9da3d931_4400_42ae_a6a6_69acd11feabc.slice/cri-containerd-97495ab404e78c5e10b295ba6df4b7615799da532ac9b6be49659e466a830947.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9da3d931_4400_42ae_a6a6_69acd11feabc.slice/cri-containerd-5eb04f9a3f22439b7cfca82560aff3fa7ff07cd8c81e1e5536021a54502ec6c1.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0676dbd4_6b4e_4bbf_8ae1_750a3dfc67a4.slice/cri-containerd-fcf3ddd0617c1500c3792a0b622bfe793b4bd39f2b24dbe0d0b3d3b1d94d6b27.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0676dbd4_6b4e_4bbf_8ae1_750a3dfc67a4.slice/cri-containerd-563d7dfb621e68a64f575a404e6d50e83e09fffd4610b61a25357fd33cbe068a.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0676dbd4_6b4e_4bbf_8ae1_750a3dfc67a4.slice/cri-containerd-5dcbd12af2597f01e343424707878d2791cc3f30853963021cca218be47c1bd6.scope
    723      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf61d793f_1fda_43b5_9499_e838afebbdac.slice/cri-containerd-744bd6db66338d2310c4b5d23f66dc6eb6602594d55e32a55061a716e8959ccb.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf61d793f_1fda_43b5_9499_e838afebbdac.slice/cri-containerd-0dcfe54486f29f407a2b0590746d2841e89bac674f78aa2512958a7eda2df8d3.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda141d292_c17c_46ac_b8cc_f1c7e0d7ca31.slice/cri-containerd-b0ba5b0622f16e579c9d4b93a82d248fc3e79513ffdbdafafc8b5ba20aa17e48.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda141d292_c17c_46ac_b8cc_f1c7e0d7ca31.slice/cri-containerd-8255b3bfefa1d6cd8b15188a545423dc03cec9508795c13c756eaa03b5763a4d.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podae730d48_d8d7_4c7c_ac69_3946e03f7e5e.slice/cri-containerd-83cffea81fbd4fa99392c023fbda5449af41f2942ca5a1ecd0331816f260adc6.scope
    728      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podae730d48_d8d7_4c7c_ac69_3946e03f7e5e.slice/cri-containerd-5eef3c8dd848be7f8ef7b105e23091d60007b54c15dc24a4a3dd71c10bd83940.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd36c7ced_af43_4b95_be4e_4532a74bae3a.slice/cri-containerd-4d11196678bc0c93e65d69f93fb9518cf59cd909c9fdd7f9f4cb7626244497d6.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd36c7ced_af43_4b95_be4e_4532a74bae3a.slice/cri-containerd-dd55aeac7ebaa402b90c2e69724fa68a6cf1230eb580ad6e2c7520b7b5676038.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd36c7ced_af43_4b95_be4e_4532a74bae3a.slice/cri-containerd-774a23cc7e6db24d511f8bf15e91f7740553f54c52faf4df580a858fa760ea55.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd36c7ced_af43_4b95_be4e_4532a74bae3a.slice/cri-containerd-93ba97e6a057a46a609b23da81be9975822cc8aaf82655dca81ec22ec38ba082.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod88d41d10_4314_4aa9_b6ba_98115e24c514.slice/cri-containerd-35af40f4a3a586c78f1eb8fb8b0e4d1aa5fad0a85df6ebbf94c91c2870d6bdc4.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod88d41d10_4314_4aa9_b6ba_98115e24c514.slice/cri-containerd-e049448749779c56f56469fa598fb441f3c0c6228fe82d84064484b9a6b74ce5.scope
    98       cgroup_device   multi                                          
