filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcb30cfad2ecfc direct-action not_in_hw id 565 tag 4d79f26c9e5d304f jited 
