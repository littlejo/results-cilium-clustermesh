filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf4ef4b2cd15f direct-action not_in_hw id 3348 tag aa9a05bb2f1fda1a jited 
