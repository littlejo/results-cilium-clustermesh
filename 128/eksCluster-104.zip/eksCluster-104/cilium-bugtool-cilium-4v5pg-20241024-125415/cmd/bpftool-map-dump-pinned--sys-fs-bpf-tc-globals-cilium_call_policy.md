key: 6c 00 00 00  value: 83 02 00 00
key: f9 01 00 00  value: ea 0c 00 00
key: 33 03 00 00  value: 3c 02 00 00
key: 03 04 00 00  value: 16 02 00 00
key: 1e 06 00 00  value: 1f 0d 00 00
key: 27 06 00 00  value: 45 02 00 00
key: ae 06 00 00  value: 1e 0d 00 00
Found 7 elements
