 12:54:21 up 34 min,  0 users,  load average: 0.47, 0.54, 0.30
