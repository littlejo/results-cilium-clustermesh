{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.462Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.470Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.506Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.524Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.544Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.793Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.802Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.845Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.879Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.901Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.477Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.478Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.519Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.543Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.563Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.623Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.641Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.860Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.879Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.926Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.949Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.984Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.531Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.539Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.557Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.584Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.609Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.639Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.648Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.871Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.873Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.944Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.947Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.995Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.494Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.509Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.549Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.556Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.587Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.891Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.904Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.953Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.975Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.007Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.398Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.405Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.451Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.451Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.488Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.727Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.729Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.781Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.786Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.831Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.228Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.274Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.283Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.331Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.338Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.382Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.590Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.604Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.637Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.704Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.710Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.135Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.164Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.187Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.211Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.250Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.260Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.496Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.504Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.546Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.568Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.590Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.981Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.015Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.018Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.062Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.072Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.097Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.327Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.363Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.383Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.430Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.499Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.882Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.933Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.952Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.982Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.993Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.025Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.231Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.241Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.297Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.308Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.339Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.629Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.664Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.669Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.714Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.733Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.751Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.041Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.060Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.091Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.185Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.223Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.464Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.501Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.522Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.543Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.587Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.588Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.848Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.860Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.874Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.900Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.594Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.598Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.631Z",
  "value": "id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.672Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.680Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.983Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.989Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.661Z",
  "value": "id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.666Z",
  "value": "id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4"
}

