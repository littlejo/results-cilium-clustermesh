USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3251  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3212  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3211  0.0  0.4 1240176 16328 ?       Rsl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3263  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3210  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3203  0.0  0.1 1228744 4036 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  3.7  7.2 1538804 284216 ?      Ssl  12:24   1:07 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.2  0.2 1229744 10044 ?       Sl   12:24   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
