Node 0, zone      DMA    128    132     43      4      2      1      2      2      3      4     39 
Node 0, zone   Normal     92     13      3      0      1      6      6      2      4      3      7 
