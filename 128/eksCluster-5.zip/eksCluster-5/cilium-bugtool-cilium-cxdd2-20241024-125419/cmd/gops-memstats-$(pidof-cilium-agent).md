alloc: 88.34MB (92630824 bytes)
total-alloc: 3.12GB (3354004376 bytes)
sys: 219.07MB (229713236 bytes)
lookups: 0
mallocs: 75581322
frees: 74969591
heap-alloc: 88.34MB (92630824 bytes)
heap-sys: 172.83MB (181223424 bytes)
heap-idle: 40.56MB (42532864 bytes)
heap-in-use: 132.27MB (138690560 bytes)
heap-released: 5.23MB (5480448 bytes)
heap-objects: 611731
stack-in-use: 35.12MB (36831232 bytes)
stack-sys: 35.12MB (36831232 bytes)
stack-mspan-inuse: 2.05MB (2154560 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 738.66KB (756385 bytes)
gc-sys: 5.51MB (5780480 bytes)
next-gc: when heap-alloc >= 151.92MB (159303576 bytes)
last-gc: 2024-10-24 12:54:44.643941028 +0000 UTC
gc-pause-total: 17.480081ms
gc-pause: 96399
gc-pause-end: 1729774484643941028
num-gc: 103
num-forced-gc: 0
gc-cpu-fraction: 0.0004963350863693162
enable-gc: true
debug-gc: false
