Endpoint ID: 237
Path: /sys/fs/bpf/tc/globals/cilium_policy_00237

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379205   4430      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 718
Path: /sys/fs/bpf/tc/globals/cilium_policy_00718

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 761
Path: /sys/fs/bpf/tc/globals/cilium_policy_00761

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3766     39        0        
Allow    Ingress     1          ANY          NONE         disabled    173059   1992      0        
Allow    Egress      0          ANY          NONE         disabled    22426    253       0        


Endpoint ID: 1236
Path: /sys/fs/bpf/tc/globals/cilium_policy_01236

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2130     21        0        
Allow    Ingress     1          ANY          NONE         disabled    171751   1983      0        
Allow    Egress      0          ANY          NONE         disabled    22439    254       0        


Endpoint ID: 1763
Path: /sys/fs/bpf/tc/globals/cilium_policy_01763

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2633
Path: /sys/fs/bpf/tc/globals/cilium_policy_02633

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6139042   61058     0        
Allow    Ingress     1          ANY          NONE         disabled    5216521   54989     0        
Allow    Egress      0          ANY          NONE         disabled    6084786   60961     0        


Endpoint ID: 3003
Path: /sys/fs/bpf/tc/globals/cilium_policy_03003

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3451
Path: /sys/fs/bpf/tc/globals/cilium_policy_03451

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6220108   77186     0        
Allow    Ingress     1          ANY          NONE         disabled    69412     842       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


