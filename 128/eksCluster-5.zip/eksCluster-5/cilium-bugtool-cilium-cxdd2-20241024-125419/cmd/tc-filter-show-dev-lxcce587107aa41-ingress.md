filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcce587107aa41 direct-action not_in_hw id 640 tag a4710a1266821255 jited 
