xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 558
ens6(5) clsact/ingress cil_from_netdev-ens6 id 565
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 547
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 536
cilium_host(7) clsact/egress cil_from_host-cilium_host id 540
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 570
lxcd6a14e78d69e(12) clsact/ingress cil_from_container-lxcd6a14e78d69e id 525
lxc84cd3b6d34b3(14) clsact/ingress cil_from_container-lxc84cd3b6d34b3 id 550
lxcce587107aa41(18) clsact/ingress cil_from_container-lxcce587107aa41 id 640
lxc18ef50b21143(20) clsact/ingress cil_from_container-lxc18ef50b21143 id 3369
lxcb6cc90351af2(22) clsact/ingress cil_from_container-lxcb6cc90351af2 id 3305
lxc5cc350bf590b(24) clsact/ingress cil_from_container-lxc5cc350bf590b id 3372

flow_dissector:

netfilter:

