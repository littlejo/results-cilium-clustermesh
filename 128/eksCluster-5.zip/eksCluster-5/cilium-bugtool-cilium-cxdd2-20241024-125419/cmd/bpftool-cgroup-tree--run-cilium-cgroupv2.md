CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9f7fd6e_5bd7_4256_898e_1fe276dde671.slice/cri-containerd-bb0456d80fc8d0a848a5f8531eb0e2b678ff7ca10d323bb05442870f48cd385f.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9f7fd6e_5bd7_4256_898e_1fe276dde671.slice/cri-containerd-23baf0b0a0c456110ec6d3540a908283953c4ab9ec69999caa9fb17e3be75c18.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod99a7025e_b2e6_485a_87b2_e1b7f4392f5d.slice/cri-containerd-f29a2ef43bc66b515b6b9ef1558043eed89c0a29ad34aa5cc4ac72a5f9e7d445.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod99a7025e_b2e6_485a_87b2_e1b7f4392f5d.slice/cri-containerd-167d292d34d5a19017bd467aa8d3f37645029111e1f86e3155de55a277cf8121.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod819e25e1_ba71_481c_b234_ee7dcf843b38.slice/cri-containerd-8070a0df3e4ec8902814399934d5063df0bc282154787476d3d4d5b44450e5bf.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod819e25e1_ba71_481c_b234_ee7dcf843b38.slice/cri-containerd-d2792f812bcfbf2da96356ce12050a721b4f96292e96fe4b0d9ef8d94804f3d9.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e0ff6e5_0756_4770_b916_d5097314fd3d.slice/cri-containerd-3d7d55aa659d555c1737b61249043876adf4e8ba4d1610cfb27a8b63c7822017.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e0ff6e5_0756_4770_b916_d5097314fd3d.slice/cri-containerd-f529d268b0bb1cec49c1f92fab7b235ababcdef8436048231055bc04ec53167d.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62eb7532_5848_4252_81f3_8b770b696b8c.slice/cri-containerd-feab6782c4571147fb55ff620a8d04b5e40d440c9e0890c4ddb42915d6596f23.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62eb7532_5848_4252_81f3_8b770b696b8c.slice/cri-containerd-fe92022ec3309aba65cb1b6de20bdc846c6329ccf7f03507d4fac70e8e9b6ce9.scope
    739      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62eb7532_5848_4252_81f3_8b770b696b8c.slice/cri-containerd-1fe3b9af6724e3b5f70b6e26dbf3981876326b6d7f7a597f222bbf811bafb611.scope
    735      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b9f877b_2fb1_4611_a28a_1ecc3b1cc4ad.slice/cri-containerd-4a6d4899ead9c088f21d8828693e565975f911a26e0e98ce1061d1e2db6c67fb.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b9f877b_2fb1_4611_a28a_1ecc3b1cc4ad.slice/cri-containerd-f745abe35edf71fe3f5126a4d0d94f64d5a613ccc8329cbb1ff0fb9014e816bd.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2608905c_46cf_46f5_8c25_e0f123cedcba.slice/cri-containerd-4c6d0afbaff1cbf6da8bdb185782e72baa7ffd276e2ffb2a4c9cb960e9f7158d.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2608905c_46cf_46f5_8c25_e0f123cedcba.slice/cri-containerd-4f8368189a7b6206851b1c19ee86119afc2cde955a83cd20b02300bce2947bb7.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2608905c_46cf_46f5_8c25_e0f123cedcba.slice/cri-containerd-a652c56fc510a0c2778cec41c4c5135923d803b7aacba5b0fcc988a239cbcc91.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2608905c_46cf_46f5_8c25_e0f123cedcba.slice/cri-containerd-79634b1319fec38e3a43e6eb2773f16bb844d115aeda54de8fe4ecd6fcb3041b.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda636fd6d_1ec5_4a65_aa03_45c93acad25a.slice/cri-containerd-78350e7f1de7ed79371638968ad04f6e3e6e0328005e023d23bd2c91b7704e3e.scope
    693      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda636fd6d_1ec5_4a65_aa03_45c93acad25a.slice/cri-containerd-cd44881651adf0a232f3b621b85950edcaebae968965df7bc625315763bcebb9.scope
    731      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4f8306a9_e3ab_46d2_984a_a6d5378605c8.slice/cri-containerd-26e65d128e7895e37ffce101c9a7d38dbfa40819ee9aa47b62cb970613d86def.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4f8306a9_e3ab_46d2_984a_a6d5378605c8.slice/cri-containerd-4255fbbd2e936e9ee9966e45706c65c83f9b1c7b46849682d0bcc4d56d2e11f2.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc8869c9_7c57_4f1d_b455_3500eb8a892a.slice/cri-containerd-eb07c61fde492227c90311deec36d5b3d2303c70bc44f2e5a1b3518ef70b69e1.scope
    727      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc8869c9_7c57_4f1d_b455_3500eb8a892a.slice/cri-containerd-6ec62c4c202cb5773e1a5bcb41a1f495414290fb4b06f9e0540b5fd171f76bfa.scope
    723      cgroup_device   multi                                          
