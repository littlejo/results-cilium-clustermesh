top - 12:54:21 up 34 min,  0 users,  load average: 0.47, 0.54, 0.30
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 10.3 us, 37.9 sy,  0.0 ni, 51.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    301.9 free,   1037.8 used,   2496.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2617.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3211 root      20   0 1240432  16328  11356 S  13.3   0.4   0:00.03 cilium-+
      1 root      20   0 1538804 284216  77764 S   0.0   7.2   1:07.29 cilium-+
    394 root      20   0 1229744  10044   3836 S   0.0   0.3   0:04.29 cilium-+
   3203 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   3210 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3212 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3251 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3274 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3292 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
