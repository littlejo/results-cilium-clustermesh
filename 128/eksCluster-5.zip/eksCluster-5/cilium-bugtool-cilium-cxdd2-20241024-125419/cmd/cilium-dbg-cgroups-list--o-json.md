[
  {
    "containers": [
      {
        "cgroup-id": 9180,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2608905c_46cf_46f5_8c25_e0f123cedcba.slice/cri-containerd-4f8368189a7b6206851b1c19ee86119afc2cde955a83cd20b02300bce2947bb7.scope"
      },
      {
        "cgroup-id": 9096,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2608905c_46cf_46f5_8c25_e0f123cedcba.slice/cri-containerd-79634b1319fec38e3a43e6eb2773f16bb844d115aeda54de8fe4ecd6fcb3041b.scope"
      },
      {
        "cgroup-id": 9264,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2608905c_46cf_46f5_8c25_e0f123cedcba.slice/cri-containerd-a652c56fc510a0c2778cec41c4c5135923d803b7aacba5b0fcc988a239cbcc91.scope"
      }
    ],
    "ips": [
      "10.5.0.37"
    ],
    "name": "clustermesh-apiserver-67d55c55-ltglm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod99a7025e_b2e6_485a_87b2_e1b7f4392f5d.slice/cri-containerd-167d292d34d5a19017bd467aa8d3f37645029111e1f86e3155de55a277cf8121.scope"
      }
    ],
    "ips": [
      "10.5.0.140"
    ],
    "name": "coredns-cc6ccd49c-2tj8q",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda636fd6d_1ec5_4a65_aa03_45c93acad25a.slice/cri-containerd-cd44881651adf0a232f3b621b85950edcaebae968965df7bc625315763bcebb9.scope"
      }
    ],
    "ips": [
      "10.5.0.219"
    ],
    "name": "client-974f6c69d-qvts8",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e0ff6e5_0756_4770_b916_d5097314fd3d.slice/cri-containerd-f529d268b0bb1cec49c1f92fab7b235ababcdef8436048231055bc04ec53167d.scope"
      }
    ],
    "ips": [
      "10.5.0.7"
    ],
    "name": "coredns-cc6ccd49c-ntq2l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc8869c9_7c57_4f1d_b455_3500eb8a892a.slice/cri-containerd-eb07c61fde492227c90311deec36d5b3d2303c70bc44f2e5a1b3518ef70b69e1.scope"
      }
    ],
    "ips": [
      "10.5.0.193"
    ],
    "name": "client2-57cf4468f-lhdt2",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62eb7532_5848_4252_81f3_8b770b696b8c.slice/cri-containerd-fe92022ec3309aba65cb1b6de20bdc846c6329ccf7f03507d4fac70e8e9b6ce9.scope"
      },
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62eb7532_5848_4252_81f3_8b770b696b8c.slice/cri-containerd-1fe3b9af6724e3b5f70b6e26dbf3981876326b6d7f7a597f222bbf811bafb611.scope"
      }
    ],
    "ips": [
      "10.5.0.207"
    ],
    "name": "echo-same-node-86d9cc975c-w62dm",
    "namespace": "cilium-test-1"
  }
]

