key: ed 00 00 00  value: f5 0c 00 00
key: ce 02 00 00  value: 26 0d 00 00
key: f9 02 00 00  value: 24 02 00 00
key: d4 04 00 00  value: 13 02 00 00
key: e3 06 00 00  value: 24 0d 00 00
key: 49 0a 00 00  value: 89 02 00 00
key: 7b 0d 00 00  value: 43 02 00 00
Found 7 elements
