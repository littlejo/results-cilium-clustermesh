IP ADDRESS         LOCAL ENDPOINT INFO
10.5.0.15:0        (localhost)                                                                                       
10.5.0.140:0       id=761   sec_id=399414 flags=0x0000 ifindex=14  mac=FE:3F:26:05:3F:83 nodemac=EA:A9:1C:51:78:D1   
10.5.0.219:0       id=1763  sec_id=400943 flags=0x0000 ifindex=20  mac=92:C9:A5:88:A8:E9 nodemac=16:DE:13:CC:E9:F4   
10.5.0.26:0        id=3451  sec_id=4     flags=0x0000 ifindex=10  mac=BE:BC:9A:05:B9:C2 nodemac=BA:CA:B6:A2:3F:75    
172.31.228.95:0    (localhost)                                                                                       
10.5.0.207:0       id=237   sec_id=447814 flags=0x0000 ifindex=22  mac=52:E4:12:BA:D6:28 nodemac=E6:9B:E4:8A:E7:EB   
172.31.225.184:0   (localhost)                                                                                       
10.5.0.37:0        id=2633  sec_id=397518 flags=0x0000 ifindex=18  mac=B6:C9:90:4E:34:15 nodemac=8A:2C:CB:BC:D2:DA   
10.5.0.193:0       id=718   sec_id=401207 flags=0x0000 ifindex=24  mac=26:63:6C:B7:B5:C2 nodemac=22:44:0A:99:CF:A0   
10.5.0.7:0         id=1236  sec_id=399414 flags=0x0000 ifindex=12  mac=DA:FA:D4:CE:96:4C nodemac=0E:A2:78:9C:BF:93   
