1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:97:aa:8f:1d:11 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.225.184/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3365sec preferred_lft 3365sec
    inet6 fe80::897:aaff:fe8f:1d11/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:f1:15:7c:f5:6d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.228.95/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8f1:15ff:fe7c:f56d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:19:69:70:3a:d8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b419:69ff:fe70:3ad8/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:ed:91:35:1b:c2 brd ff:ff:ff:ff:ff:ff
    inet 10.5.0.15/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b8ed:91ff:fe35:1bc2/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 12:73:db:d2:50:81 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1073:dbff:fed2:5081/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:ca:b6:a2:3f:75 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b8ca:b6ff:fea2:3f75/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcd6a14e78d69e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:a2:78:9c:bf:93 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::ca2:78ff:fe9c:bf93/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc84cd3b6d34b3@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:a9:1c:51:78:d1 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e8a9:1cff:fe51:78d1/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcce587107aa41@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:2c:cb:bc:d2:da brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::882c:cbff:febc:d2da/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc18ef50b21143@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:de:13:cc:e9:f4 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::14de:13ff:fecc:e9f4/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcb6cc90351af2@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:9b:e4:8a:e7:eb brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::e49b:e4ff:fe8a:e7eb/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc5cc350bf590b@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:44:0a:99:cf:a0 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::2044:aff:fe99:cfa0/64 scope link 
       valid_lft forever preferred_lft forever
