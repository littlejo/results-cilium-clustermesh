markdown output at /tmp/cilium-bugtool-20241024-125421.667+0000-UTC-1244180598/cmd/cilium-debuginfo-20241024-125452.494+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125421.667+0000-UTC-1244180598/cmd/cilium-debuginfo-20241024-125452.494+0000-UTC.json
