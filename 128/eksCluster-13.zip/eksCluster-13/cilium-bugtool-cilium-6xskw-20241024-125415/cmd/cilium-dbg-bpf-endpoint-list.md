IP ADDRESS         LOCAL ENDPOINT INFO
10.13.0.224:0      id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0   
10.13.0.25:0       id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02   
10.13.0.95:0       id=2005  sec_id=947098 flags=0x0000 ifindex=12  mac=2E:EE:29:51:13:4A nodemac=7E:6F:96:C6:30:40   
10.13.0.230:0      id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1   
172.31.192.174:0   (localhost)                                                                                       
10.13.0.100:0      id=2744  sec_id=947098 flags=0x0000 ifindex=14  mac=E6:CD:43:86:51:A7 nodemac=0A:28:7E:FC:77:49   
172.31.205.246:0   (localhost)                                                                                       
10.13.0.218:0      id=812   sec_id=4     flags=0x0000 ifindex=10  mac=66:BB:64:D3:7D:8A nodemac=8E:3D:1D:0E:BD:C1    
10.13.0.179:0      (localhost)                                                                                       
10.13.0.166:0      id=67    sec_id=964271 flags=0x0000 ifindex=18  mac=FE:29:3C:91:0B:EA nodemac=4A:FE:01:74:C5:8E   
