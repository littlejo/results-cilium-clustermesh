[
  {
    "containers": [
      {
        "cgroup-id": 9226,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcfe4835c_3653_493e_9979_f66d80235166.slice/cri-containerd-b314e19fc33f3cea2cb08af5cae3643299a90dffc2217177f78476418a36e9cf.scope"
      },
      {
        "cgroup-id": 9142,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcfe4835c_3653_493e_9979_f66d80235166.slice/cri-containerd-3236fcf6098bfe11c8a7cb0ad2fd11bc133e8fcbd7d2eedfaadf501b5630f3e0.scope"
      },
      {
        "cgroup-id": 9058,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcfe4835c_3653_493e_9979_f66d80235166.slice/cri-containerd-a969e1e2099970969094d7be3ac407ffb2fa1b96d867a388bd297b0303b02871.scope"
      }
    ],
    "ips": [
      "10.13.0.166"
    ],
    "name": "clustermesh-apiserver-78f9f77f45-42bzw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9982,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14b7808a_9066_401e_9560_0726b65c0232.slice/cri-containerd-de63d42fe9263d0762c5bed1bdbf261fa2baf77fd75cf69dd7f67f96b5abcd72.scope"
      },
      {
        "cgroup-id": 10066,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14b7808a_9066_401e_9560_0726b65c0232.slice/cri-containerd-ca25154f9788ff026dd59f59e7597cd55f7544cd97ccfe75c493ee4b394a619c.scope"
      }
    ],
    "ips": [
      "10.13.0.25"
    ],
    "name": "echo-same-node-86d9cc975c-kg2q6",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9898,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83f9c40a_e66d_4b24_bc5a_d15a47b133c0.slice/cri-containerd-b4b259016e06dde8f081c0d9e5eb94cf9550cad69433f1b93a6da0b579ac7334.scope"
      }
    ],
    "ips": [
      "10.13.0.230"
    ],
    "name": "client2-57cf4468f-sgbfd",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9814,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0d57ae8f_88a1_4422_9ac5_d607048807f1.slice/cri-containerd-d31d11f83c6fc307c42c41975aaac991418eba9ef22de83b60aa6f1cd0e0b8a0.scope"
      }
    ],
    "ips": [
      "10.13.0.224"
    ],
    "name": "client-974f6c69d-fsddf",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7630,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod32320e36_f901_4e37_bdc0_cba1125fde70.slice/cri-containerd-8b3d663d95ec23798511da5e2649e843fc237b9dcc5d492987db0489b80e7213.scope"
      }
    ],
    "ips": [
      "10.13.0.95"
    ],
    "name": "coredns-cc6ccd49c-mh24l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7714,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d823a40_922d_4190_86ec_bff54002291d.slice/cri-containerd-f4d597469e808a480174fa9cb0636bd634dc0fa6857ef92c2c985e05e716b24d.scope"
      }
    ],
    "ips": [
      "10.13.0.100"
    ],
    "name": "coredns-cc6ccd49c-5qwls",
    "namespace": "kube-system"
  }
]

