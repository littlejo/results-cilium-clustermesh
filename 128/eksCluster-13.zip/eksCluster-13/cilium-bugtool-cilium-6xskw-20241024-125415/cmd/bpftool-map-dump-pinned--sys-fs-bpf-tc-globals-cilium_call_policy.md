key: 43 00 00 00  value: 87 02 00 00
key: 2d 02 00 00  value: 4a 0d 00 00
key: 2c 03 00 00  value: 47 02 00 00
key: 55 04 00 00  value: 49 0d 00 00
key: d5 07 00 00  value: 0d 02 00 00
key: 55 08 00 00  value: 10 0d 00 00
key: b8 0a 00 00  value: 3c 02 00 00
Found 7 elements
