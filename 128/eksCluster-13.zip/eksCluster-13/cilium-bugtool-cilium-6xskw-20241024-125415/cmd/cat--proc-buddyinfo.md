Node 0, zone      DMA     56    121     12     31     24      7      5      2      2      2     40 
Node 0, zone   Normal    218     42     10     18     21      5      2      1      1      2      8 
