1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:95:59:5f:f6:1b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.205.246/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2048sec preferred_lft 2048sec
    inet6 fe80::895:59ff:fe5f:f61b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:1e:ef:08:a2:f7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.192.174/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::81e:efff:fe08:a2f7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:72:00:e4:d4:11 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5872:ff:fee4:d411/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:e6:96:ac:cf:06 brd ff:ff:ff:ff:ff:ff
    inet 10.13.0.179/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::8e6:96ff:feac:cf06/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ba:0f:7c:c9:e3:10 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b80f:7cff:fec9:e310/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:3d:1d:0e:bd:c1 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::8c3d:1dff:fe0e:bdc1/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc4e77c41380d0@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:6f:96:c6:30:40 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::7c6f:96ff:fec6:3040/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc8285b670e632@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:28:7e:fc:77:49 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::828:7eff:fefc:7749/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcbc12b143948c@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:fe:01:74:c5:8e brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::48fe:1ff:fe74:c58e/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcc2d3101eddb1@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:9c:b9:bb:e0:d0 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::cc9c:b9ff:febb:e0d0/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcf784985ddb2d@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:fe:b8:7c:50:02 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::e4fe:b8ff:fe7c:5002/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc4cf177c940d6@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:75:98:db:df:b1 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::1475:98ff:fedb:dfb1/64 scope link 
       valid_lft forever preferred_lft forever
