KEY             VALUE
AgentLiveness   3392003886434
UTimeOffset     3378459169921875
