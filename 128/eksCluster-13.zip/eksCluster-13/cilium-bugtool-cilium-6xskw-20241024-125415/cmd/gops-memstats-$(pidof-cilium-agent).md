alloc: 78.26MB (82057360 bytes)
total-alloc: 3.12GB (3348150328 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 75453572
frees: 74921981
heap-alloc: 78.26MB (82057360 bytes)
heap-sys: 178.95MB (187637760 bytes)
heap-idle: 52.66MB (55214080 bytes)
heap-in-use: 126.29MB (132423680 bytes)
heap-released: 7.98MB (8372224 bytes)
heap-objects: 531591
stack-in-use: 33.03MB (34635776 bytes)
stack-sys: 33.03MB (34635776 bytes)
stack-mspan-inuse: 2.04MB (2134080 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 950.37KB (973177 bytes)
gc-sys: 5.52MB (5790912 bytes)
next-gc: when heap-alloc >= 149.31MB (156564952 bytes)
last-gc: 2024-10-24 12:54:44.763800795 +0000 UTC
gc-pause-total: 20.416984ms
gc-pause: 98299
gc-pause-end: 1729774484763800795
num-gc: 103
num-forced-gc: 0
gc-cpu-fraction: 0.0005137447468978099
enable-gc: true
debug-gc: false
