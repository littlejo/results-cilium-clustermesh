filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc2d3101eddb1 direct-action not_in_hw id 3396 tag a24c18eb8ef7d3e7 jited 
