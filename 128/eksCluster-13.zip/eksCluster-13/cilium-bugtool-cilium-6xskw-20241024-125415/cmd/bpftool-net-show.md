xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 560
ens6(5) clsact/ingress cil_from_netdev-ens6 id 570
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 554
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 542
cilium_host(7) clsact/egress cil_from_host-cilium_host id 547
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 585
lxc4e77c41380d0(12) clsact/ingress cil_from_container-lxc4e77c41380d0 id 528
lxc8285b670e632(14) clsact/ingress cil_from_container-lxc8285b670e632 id 579
lxcbc12b143948c(18) clsact/ingress cil_from_container-lxcbc12b143948c id 653
lxcc2d3101eddb1(20) clsact/ingress cil_from_container-lxcc2d3101eddb1 id 3396
lxcf784985ddb2d(22) clsact/ingress cil_from_container-lxcf784985ddb2d id 3330
lxc4cf177c940d6(24) clsact/ingress cil_from_container-lxc4cf177c940d6 id 3398

flow_dissector:

netfilter:

