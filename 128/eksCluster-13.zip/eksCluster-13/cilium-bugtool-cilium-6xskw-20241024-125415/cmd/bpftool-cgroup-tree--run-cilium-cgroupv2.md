CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a21091c_ce4c_4e0a_b8dd_b6dc4b677707.slice/cri-containerd-9603aa5d7748f61b296b840da7aec903f583966b54d2040b83e4aae033373589.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a21091c_ce4c_4e0a_b8dd_b6dc4b677707.slice/cri-containerd-4dd02d71883a0f72b8427aea203d420600288bc6f18c3cdc8057f791252b4869.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod32320e36_f901_4e37_bdc0_cba1125fde70.slice/cri-containerd-21b201eaccf83d29afd945fc289f219b1a5dbf88716bd3bfb692a4e877dac076.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod32320e36_f901_4e37_bdc0_cba1125fde70.slice/cri-containerd-8b3d663d95ec23798511da5e2649e843fc237b9dcc5d492987db0489b80e7213.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d823a40_922d_4190_86ec_bff54002291d.slice/cri-containerd-407ac6f3f9d2ffa70203abf71398e8e82551969e4e4401e4b71396d241125973.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d823a40_922d_4190_86ec_bff54002291d.slice/cri-containerd-f4d597469e808a480174fa9cb0636bd634dc0fa6857ef92c2c985e05e716b24d.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbbecd8d6_b3a0_4a3c_baa8_e56262442f0d.slice/cri-containerd-9b312f14285333a5aef9a232a4498c8c43f95d883511f16958a75fce1a552cc2.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbbecd8d6_b3a0_4a3c_baa8_e56262442f0d.slice/cri-containerd-808c3394f5648970066cfa0404bfec00a4ebcb5f5bd20a39cdaf9e41733c405f.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcfe4835c_3653_493e_9979_f66d80235166.slice/cri-containerd-9094ccfb0f71cfc33b0c9703cc31e23846c205bd86839ab96d654682cc0f41ed.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcfe4835c_3653_493e_9979_f66d80235166.slice/cri-containerd-3236fcf6098bfe11c8a7cb0ad2fd11bc133e8fcbd7d2eedfaadf501b5630f3e0.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcfe4835c_3653_493e_9979_f66d80235166.slice/cri-containerd-a969e1e2099970969094d7be3ac407ffb2fa1b96d867a388bd297b0303b02871.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcfe4835c_3653_493e_9979_f66d80235166.slice/cri-containerd-b314e19fc33f3cea2cb08af5cae3643299a90dffc2217177f78476418a36e9cf.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1d369205_bfc8_4f55_b64f_3822343d8cad.slice/cri-containerd-0682c84a117f143ea807ba453a4b615b3b4f45f9cdd07df7333b2c03b1794bd4.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1d369205_bfc8_4f55_b64f_3822343d8cad.slice/cri-containerd-6690df3cb73c9bfffa488816c9a0c939b3ed6dfc6e0fe4bdc892a3afac2d35ac.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83f9c40a_e66d_4b24_bc5a_d15a47b133c0.slice/cri-containerd-b4b259016e06dde8f081c0d9e5eb94cf9550cad69433f1b93a6da0b579ac7334.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod83f9c40a_e66d_4b24_bc5a_d15a47b133c0.slice/cri-containerd-45c1f966a97e7268ac6e384b96b41cafda6f4fef7574d105f5dd02e298c61bcb.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0d57ae8f_88a1_4422_9ac5_d607048807f1.slice/cri-containerd-d31d11f83c6fc307c42c41975aaac991418eba9ef22de83b60aa6f1cd0e0b8a0.scope
    734      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0d57ae8f_88a1_4422_9ac5_d607048807f1.slice/cri-containerd-2827e5c6ab2c66098653816f8313c520f3a91a63edf72ad5ca23dcee18acd133.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod730ed4a7_e775_43dc_bc6a_bf9245681331.slice/cri-containerd-58767dfdf0408ec73f503cf2ceedccde483430abe8e4635f54684b8e25c5f2ff.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod730ed4a7_e775_43dc_bc6a_bf9245681331.slice/cri-containerd-065a4bf5e6c4b0260bdfdc515e93e7cedf59ac52cf2724122b42c509580b9ac2.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14b7808a_9066_401e_9560_0726b65c0232.slice/cri-containerd-89cc51694fc17d129a9f8074f5e40d555b5243963e909c95984220f88acb2a99.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14b7808a_9066_401e_9560_0726b65c0232.slice/cri-containerd-ca25154f9788ff026dd59f59e7597cd55f7544cd97ccfe75c493ee4b394a619c.scope
    742      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14b7808a_9066_401e_9560_0726b65c0232.slice/cri-containerd-de63d42fe9263d0762c5bed1bdbf261fa2baf77fd75cf69dd7f67f96b5abcd72.scope
    738      cgroup_device   multi                                          
