Endpoint ID: 67
Path: /sys/fs/bpf/tc/globals/cilium_policy_00067

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6112302   61257     0        
Allow    Ingress     1          ANY          NONE         disabled    5059123   53187     0        
Allow    Egress      0          ANY          NONE         disabled    6634438   65693     0        


Endpoint ID: 557
Path: /sys/fs/bpf/tc/globals/cilium_policy_00557

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 812
Path: /sys/fs/bpf/tc/globals/cilium_policy_00812

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6216040   76803     0        
Allow    Ingress     1          ANY          NONE         disabled    69194     836       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1109
Path: /sys/fs/bpf/tc/globals/cilium_policy_01109

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1607
Path: /sys/fs/bpf/tc/globals/cilium_policy_01607

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2005
Path: /sys/fs/bpf/tc/globals/cilium_policy_02005

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2730     29        0        
Allow    Ingress     1          ANY          NONE         disabled    169223   1948      0        
Allow    Egress      0          ANY          NONE         disabled    22924    259       0        


Endpoint ID: 2133
Path: /sys/fs/bpf/tc/globals/cilium_policy_02133

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    375480   4389      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2744
Path: /sys/fs/bpf/tc/globals/cilium_policy_02744

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3166     31        0        
Allow    Ingress     1          ANY          NONE         disabled    170496   1962      0        
Allow    Egress      0          ANY          NONE         disabled    22438    252       0        


