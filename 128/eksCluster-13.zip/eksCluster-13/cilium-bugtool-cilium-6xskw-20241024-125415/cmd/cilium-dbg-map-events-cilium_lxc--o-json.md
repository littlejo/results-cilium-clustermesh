{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.634Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.217Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.224Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.268Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.272Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.302Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.548Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.549Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.606Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.644Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.674Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.265Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.267Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.311Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.334Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.357Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.393Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.404Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.652Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.653Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.705Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.721Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.755Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.367Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.387Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.427Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.461Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.464Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.659Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.661Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.726Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.726Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.773Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.313Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.316Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.348Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.384Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.411Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.421Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.444Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.712Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.716Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.776Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.784Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.815Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.157Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.180Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.214Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.241Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.277Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.542Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.550Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.593Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.598Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.644Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.030Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.069Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.074Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.123Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.126Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.161Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.162Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.456Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.480Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.515Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.539Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.557Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.985Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.017Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.023Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.055Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.060Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.090Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.433Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.451Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.542Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.572Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.588Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.972Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.013Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.016Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.060Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.067Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.098Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.310Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.316Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.371Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.387Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.413Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.848Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.851Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.902Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.911Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.947Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.950Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.219Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.226Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.285Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.310Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.371Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.699Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.711Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.760Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.773Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.800Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.024Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.033Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.095Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.100Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.136Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.469Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.503Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.541Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.551Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.578Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.774Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.786Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.800Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.831Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.447Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.450Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.477Z",
  "value": "id=2133  sec_id=929969 flags=0x0000 ifindex=22  mac=86:7B:66:78:C3:58 nodemac=E6:FE:B8:7C:50:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.505Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.517Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.801Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.803Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.500Z",
  "value": "id=1109  sec_id=965807 flags=0x0000 ifindex=24  mac=96:67:5D:6B:FF:58 nodemac=16:75:98:DB:DF:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.508Z",
  "value": "id=557   sec_id=919881 flags=0x0000 ifindex=20  mac=3E:31:5A:22:D8:0F nodemac=CE:9C:B9:BB:E0:D0"
}

