USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3320  0.0  0.2 1616008 8264 ?        Ssl  12:54   0:00 /usr/sbin/runc init
root        3305  0.0  0.4 1240432 16112 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3319  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3327  0.0  0.0      4     4 ?        R    12:54   0:00  \_ [hostname]
root        3286  0.0  0.0 1228744 3776 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3285  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  3.4  7.3 1539060 290668 ?      Ssl  12:25   1:00 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.2  0.2 1229744 10016 ?       Sl   12:25   0:03 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
