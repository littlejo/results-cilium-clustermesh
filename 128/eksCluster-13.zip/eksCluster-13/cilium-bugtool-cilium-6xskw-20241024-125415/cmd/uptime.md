 12:54:16 up 56 min,  0 users,  load average: 0.68, 0.48, 0.23
