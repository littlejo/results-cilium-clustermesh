[
  {
    "containers": [
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfbcd7034_e7e9_46e4_8abc_8748d2434839.slice/cri-containerd-1c067f573ecdc2f8efc20b9e6ed84c8deaebab7a853f0df1f8dbeda92fda938f.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfbcd7034_e7e9_46e4_8abc_8748d2434839.slice/cri-containerd-de9df71ad9312951ed9f32a6d97bf3e5d13c66bcf95eed4e1c179a19d97ed98e.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfbcd7034_e7e9_46e4_8abc_8748d2434839.slice/cri-containerd-1aff8c832c54eb057d0dd8a87baf02ae607f7032d010203ffe56a58ae4beabdf.scope"
      }
    ],
    "ips": [
      "10.41.0.31"
    ],
    "name": "clustermesh-apiserver-68bd6cdc84-lwg9v",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod22ddb318_b16a_4280_b3ef_1df22d1687c9.slice/cri-containerd-7f0d351bcbc79c6c993baaace649160612a552a058b09a160a205b187a230b79.scope"
      }
    ],
    "ips": [
      "10.41.0.73"
    ],
    "name": "coredns-cc6ccd49c-5kdlh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod19f4ea0d_7a25_4678_bda0_8e0ae1f2ee7d.slice/cri-containerd-1c66c2f04cfcafe70e9ef189b32eacac528f0bf24a6b34984be973680646e61a.scope"
      }
    ],
    "ips": [
      "10.41.0.137"
    ],
    "name": "client-974f6c69d-8qc9q",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7e9308ba_79ce_4d26_b03f_7acb02e83dde.slice/cri-containerd-28f43dda43f278e7788917075ccc24f2c80f52044777e45676870c30acf68677.scope"
      }
    ],
    "ips": [
      "10.41.0.177"
    ],
    "name": "coredns-cc6ccd49c-gst4r",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod35bd30c2_06cb_4d38_bae6_f4612fd3173d.slice/cri-containerd-3d582f08847e0613d2a91e4d40ffa7fc4fb1fd675f0d810f54a68953ef4e15a6.scope"
      }
    ],
    "ips": [
      "10.41.0.28"
    ],
    "name": "client2-57cf4468f-pbpvx",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d28d918_010a_4718_a3eb_19123b2b2ace.slice/cri-containerd-a8dce1b50dac699064135b2d88031fa9d7c139863d01abc5f21455065b81467b.scope"
      },
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d28d918_010a_4718_a3eb_19123b2b2ace.slice/cri-containerd-18edeafbeb188cc56b954fa315a00f0595aa7b494b8aad2ce8b6ba74689bdc3f.scope"
      }
    ],
    "ips": [
      "10.41.0.19"
    ],
    "name": "echo-same-node-86d9cc975c-zqc7l",
    "namespace": "cilium-test-1"
  }
]

