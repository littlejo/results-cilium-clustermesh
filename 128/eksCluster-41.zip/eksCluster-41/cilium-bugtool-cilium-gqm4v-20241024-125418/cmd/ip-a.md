1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c2:a1:21:d5:b3 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.252.73/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3429sec preferred_lft 3429sec
    inet6 fe80::8c2:a1ff:fe21:d5b3/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:f1:84:6e:65:39 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.244.222/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8f1:84ff:fe6e:6539/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:25:16:dc:b7:bd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4425:16ff:fedc:b7bd/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:02:d8:37:bc:49 brd ff:ff:ff:ff:ff:ff
    inet 10.41.0.85/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::3002:d8ff:fe37:bc49/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ea:d0:74:b5:45:45 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e8d0:74ff:feb5:4545/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:02:b0:b5:ca:38 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::7c02:b0ff:feb5:ca38/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc95140caf3f77@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:43:81:41:c4:fc brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::1443:81ff:fe41:c4fc/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc43202fc866b9@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:bb:46:27:75:ab brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e4bb:46ff:fe27:75ab/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcdb4b16ea6be7@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:e1:34:ab:67:b1 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::60e1:34ff:feab:67b1/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc43acdf4e615e@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:72:6e:c0:fa:d8 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::c072:6eff:fec0:fad8/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcf8a9530e2168@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:fb:45:ca:59:56 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::ccfb:45ff:feca:5956/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcbbff24086f92@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:a8:1a:83:c8:93 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::fca8:1aff:fe83:c893/64 scope link 
       valid_lft forever preferred_lft forever
