Endpoint ID: 106
Path: /sys/fs/bpf/tc/globals/cilium_policy_00106

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 292
Path: /sys/fs/bpf/tc/globals/cilium_policy_00292

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6195342   76568     0        
Allow    Ingress     1          ANY          NONE         disabled    68506     827       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 649
Path: /sys/fs/bpf/tc/globals/cilium_policy_00649

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 938
Path: /sys/fs/bpf/tc/globals/cilium_policy_00938

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5650462   57577     0        
Allow    Ingress     1          ANY          NONE         disabled    5261778   55469     0        
Allow    Egress      0          ANY          NONE         disabled    6246559   62658     0        


Endpoint ID: 1076
Path: /sys/fs/bpf/tc/globals/cilium_policy_01076

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3024     31        0        
Allow    Ingress     1          ANY          NONE         disabled    155862   1790      0        
Allow    Egress      0          ANY          NONE         disabled    20848    234       0        


Endpoint ID: 1337
Path: /sys/fs/bpf/tc/globals/cilium_policy_01337

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2872     29        0        
Allow    Ingress     1          ANY          NONE         disabled    156177   1798      0        
Allow    Egress      0          ANY          NONE         disabled    19514    217       0        


Endpoint ID: 1865
Path: /sys/fs/bpf/tc/globals/cilium_policy_01865

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    350863   4102      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3340
Path: /sys/fs/bpf/tc/globals/cilium_policy_03340

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


