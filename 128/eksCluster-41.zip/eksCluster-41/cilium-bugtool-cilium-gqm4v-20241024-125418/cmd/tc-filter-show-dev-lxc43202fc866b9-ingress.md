filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc43202fc866b9 direct-action not_in_hw id 540 tag ac263229296c138c jited 
