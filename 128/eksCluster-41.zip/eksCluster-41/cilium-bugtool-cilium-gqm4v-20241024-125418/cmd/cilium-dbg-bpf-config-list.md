KEY             VALUE
AgentLiveness   1985823208212
UTimeOffset     3378461871093750
