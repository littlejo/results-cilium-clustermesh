key: 6a 00 00 00  value: 02 0d 00 00
key: 24 01 00 00  value: 47 02 00 00
key: aa 03 00 00  value: 89 02 00 00
key: 34 04 00 00  value: 09 02 00 00
key: 39 05 00 00  value: 3f 02 00 00
key: 49 07 00 00  value: c9 0c 00 00
key: 0c 0d 00 00  value: 00 0d 00 00
Found 7 elements
