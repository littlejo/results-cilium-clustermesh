ip-172-31-252-73.eu-west-3.compute.internal
