filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcbbff24086f92 direct-action not_in_hw id 3317 tag 3f5ee9a70f5bfea6 jited 
