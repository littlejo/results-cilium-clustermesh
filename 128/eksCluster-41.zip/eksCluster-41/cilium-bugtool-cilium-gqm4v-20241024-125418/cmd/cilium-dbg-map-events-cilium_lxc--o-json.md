{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.488Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.507Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.539Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.544Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.574Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.780Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.797Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.820Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.870Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.881Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.450Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.470Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.582Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.588Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.588Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.625Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.628Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.813Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.817Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.875Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.887Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.914Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.403Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.410Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.438Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.455Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.495Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.504Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.534Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.746Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.783Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.811Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.824Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.851Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.441Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.449Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.468Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.499Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.514Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.600Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.618Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.799Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.805Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.847Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.869Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.898Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.314Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.317Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.361Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.364Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.396Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.617Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.625Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.678Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.683Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.716Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.123Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.126Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.175Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.180Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.210Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.489Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.525Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.576Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.613Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.631Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.010Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.071Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.086Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.119Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.149Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.170Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.377Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.409Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.438Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.490Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.496Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.877Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.909Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.936Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.957Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.983Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.215Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.263Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.267Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.313Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.327Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.714Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.858Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.865Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.914Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.927Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.958Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.146Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.154Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.202Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.213Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.251Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.545Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.570Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.596Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.626Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.626Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.638Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.894Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.899Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.947Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.985Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.992Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.342Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.347Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.381Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.413Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.423Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.716Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.731Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.779Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.792Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.838Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.503Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.504Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.558Z",
  "value": "id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.561Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.592Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.856Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.859Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.535Z",
  "value": "id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.537Z",
  "value": "id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93"
}

