alloc: 131.70MB (138093688 bytes)
total-alloc: 3.10GB (3328958880 bytes)
sys: 223.07MB (233907540 bytes)
lookups: 0
mallocs: 75262062
frees: 73910335
heap-alloc: 131.70MB (138093688 bytes)
heap-sys: 176.70MB (185278464 bytes)
heap-idle: 27.95MB (29310976 bytes)
heap-in-use: 148.74MB (155967488 bytes)
heap-released: 9.81MB (10289152 bytes)
heap-objects: 1351727
stack-in-use: 35.28MB (36995072 bytes)
stack-sys: 35.28MB (36995072 bytes)
stack-mspan-inuse: 2.34MB (2454400 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 722.31KB (739641 bytes)
gc-sys: 5.51MB (5778576 bytes)
next-gc: when heap-alloc >= 147.23MB (154378920 bytes)
last-gc: 2024-10-24 12:53:34.070588983 +0000 UTC
gc-pause-total: 10.697437ms
gc-pause: 95082
gc-pause-end: 1729774414070588983
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0005605159090308074
enable-gc: true
debug-gc: false
