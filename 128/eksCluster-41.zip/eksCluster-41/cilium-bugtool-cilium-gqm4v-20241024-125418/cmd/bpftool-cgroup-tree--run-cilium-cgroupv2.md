CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod22ddb318_b16a_4280_b3ef_1df22d1687c9.slice/cri-containerd-7f0d351bcbc79c6c993baaace649160612a552a058b09a160a205b187a230b79.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod22ddb318_b16a_4280_b3ef_1df22d1687c9.slice/cri-containerd-7804f44d05a552e92f761648db12a0f0a6605e57dd051d763ffd4c35c3f586f3.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod43cc3af7_253f_48c3_88f1_e328a9e2ae7f.slice/cri-containerd-f9cdd104e9beadab8b5c3dbe6a124b06846f12ac1f8966c9718483a5887cd5c1.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod43cc3af7_253f_48c3_88f1_e328a9e2ae7f.slice/cri-containerd-2eb5f031ae38592a68e0763053e241c7373c7ab5e68db50624709e6f7c24aa4a.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7e9308ba_79ce_4d26_b03f_7acb02e83dde.slice/cri-containerd-28f43dda43f278e7788917075ccc24f2c80f52044777e45676870c30acf68677.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7e9308ba_79ce_4d26_b03f_7acb02e83dde.slice/cri-containerd-68fea576e2fbe1cad5ec324898064b71b5d35048f851c76ed1a3881e8c528cc0.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc4b9323_ae31_4f43_9479_8fb9b8978bfe.slice/cri-containerd-d4da10485601fe5c4601234936c3a7123bbc94660b6a4232373820722de3cf06.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc4b9323_ae31_4f43_9479_8fb9b8978bfe.slice/cri-containerd-511f6240b2300a35817216fe8c60701697a4597851d82651172d077d8d07f6be.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc03eb18_28a0_483a_ac91_1b35a4e4a115.slice/cri-containerd-7b7201effe4f9aa24e7e1e4bab98116c2878542810200433dc93a6afc8e072ba.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc03eb18_28a0_483a_ac91_1b35a4e4a115.slice/cri-containerd-c5bc1264d619101f0ecd617c690e1bb0dc1d1bffca97636268052750776e7439.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfbcd7034_e7e9_46e4_8abc_8748d2434839.slice/cri-containerd-1c067f573ecdc2f8efc20b9e6ed84c8deaebab7a853f0df1f8dbeda92fda938f.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfbcd7034_e7e9_46e4_8abc_8748d2434839.slice/cri-containerd-1aff8c832c54eb057d0dd8a87baf02ae607f7032d010203ffe56a58ae4beabdf.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfbcd7034_e7e9_46e4_8abc_8748d2434839.slice/cri-containerd-de9df71ad9312951ed9f32a6d97bf3e5d13c66bcf95eed4e1c179a19d97ed98e.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfbcd7034_e7e9_46e4_8abc_8748d2434839.slice/cri-containerd-1da6aa6bf8b49195696f6152a6a9326e2ee6cd3d5a8e4eb1111c6a2b93984e18.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod35bd30c2_06cb_4d38_bae6_f4612fd3173d.slice/cri-containerd-da9df7f82aaba895b789de589ed54905d8092e29ce856e27b01b0aebec2d7d96.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod35bd30c2_06cb_4d38_bae6_f4612fd3173d.slice/cri-containerd-3d582f08847e0613d2a91e4d40ffa7fc4fb1fd675f0d810f54a68953ef4e15a6.scope
    734      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa7e152d_42b3_41f9_9682_57b0b123e5b6.slice/cri-containerd-b4d8f76fb9411772ed320111deb241ecedd567759ae0d666e03cb159ed905487.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa7e152d_42b3_41f9_9682_57b0b123e5b6.slice/cri-containerd-3b8188b1b0f1da5411d604f65364cecd928ac8c74696325f618662e11d0f71dd.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d28d918_010a_4718_a3eb_19123b2b2ace.slice/cri-containerd-77d5d3482c44d39d7c76eee4d5c3e06f78729bd4586aa8c7785c907d46b9646f.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d28d918_010a_4718_a3eb_19123b2b2ace.slice/cri-containerd-18edeafbeb188cc56b954fa315a00f0595aa7b494b8aad2ce8b6ba74689bdc3f.scope
    738      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d28d918_010a_4718_a3eb_19123b2b2ace.slice/cri-containerd-a8dce1b50dac699064135b2d88031fa9d7c139863d01abc5f21455065b81467b.scope
    742      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod19f4ea0d_7a25_4678_bda0_8e0ae1f2ee7d.slice/cri-containerd-95f4cb08316ee4de60b98ce85170a5f4a32a4cbb25d62591a73fecaffaf3c0d3.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod19f4ea0d_7a25_4678_bda0_8e0ae1f2ee7d.slice/cri-containerd-1c66c2f04cfcafe70e9ef189b32eacac528f0bf24a6b34984be973680646e61a.scope
    730      cgroup_device   multi                                          
