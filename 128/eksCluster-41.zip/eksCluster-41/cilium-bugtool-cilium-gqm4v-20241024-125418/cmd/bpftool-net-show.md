xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 560
ens6(5) clsact/ingress cil_from_netdev-ens6 id 572
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 548
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 542
cilium_host(7) clsact/egress cil_from_host-cilium_host id 547
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 587
lxc95140caf3f77(12) clsact/ingress cil_from_container-lxc95140caf3f77 id 537
lxc43202fc866b9(14) clsact/ingress cil_from_container-lxc43202fc866b9 id 540
lxcdb4b16ea6be7(18) clsact/ingress cil_from_container-lxcdb4b16ea6be7 id 648
lxc43acdf4e615e(20) clsact/ingress cil_from_container-lxc43acdf4e615e id 3327
lxcf8a9530e2168(22) clsact/ingress cil_from_container-lxcf8a9530e2168 id 3281
lxcbbff24086f92(24) clsact/ingress cil_from_container-lxcbbff24086f92 id 3317

flow_dissector:

netfilter:

