USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3293  1.0  0.4 1240432 16320 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3336  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3337  0.0  0.0   3852  1288 ?        R    12:54   0:00  \_ bash -c hostname
root           1  3.7  7.4 1538804 292992 ?      Ssl  12:27   1:01 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.2  0.2 1229744 9924 ?        Sl   12:27   0:03 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
