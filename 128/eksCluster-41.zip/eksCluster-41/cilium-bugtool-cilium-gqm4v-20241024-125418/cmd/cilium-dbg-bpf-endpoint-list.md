IP ADDRESS         LOCAL ENDPOINT INFO
172.31.244.222:0   (localhost)                                                                                        
10.41.0.28:0       id=106   sec_id=2782436 flags=0x0000 ifindex=24  mac=82:A3:5B:C6:FB:09 nodemac=FE:A8:1A:83:C8:93   
10.41.0.177:0      id=1076  sec_id=2767827 flags=0x0000 ifindex=12  mac=3A:1E:8B:FD:EE:52 nodemac=16:43:81:41:C4:FC   
10.41.0.85:0       (localhost)                                                                                        
10.41.0.137:0      id=3340  sec_id=2795893 flags=0x0000 ifindex=20  mac=E2:CC:BF:84:04:88 nodemac=C2:72:6E:C0:FA:D8   
10.41.0.253:0      id=292   sec_id=4     flags=0x0000 ifindex=10  mac=32:EA:6C:1A:66:1C nodemac=7E:02:B0:B5:CA:38     
172.31.252.73:0    (localhost)                                                                                        
10.41.0.73:0       id=1337  sec_id=2767827 flags=0x0000 ifindex=14  mac=A6:D4:8D:EF:80:C6 nodemac=E6:BB:46:27:75:AB   
10.41.0.19:0       id=1865  sec_id=2760232 flags=0x0000 ifindex=22  mac=22:14:77:A1:6B:9A nodemac=CE:FB:45:CA:59:56   
10.41.0.31:0       id=938   sec_id=2756119 flags=0x0000 ifindex=18  mac=8E:ED:AF:3F:A6:EC nodemac=62:E1:34:AB:67:B1   
