Node 0, zone      DMA    756    413    280    172    129     84     64     46     27     21     13 
Node 0, zone   Normal   1343    274     55     82     12      9      3      3      4      5      6 
