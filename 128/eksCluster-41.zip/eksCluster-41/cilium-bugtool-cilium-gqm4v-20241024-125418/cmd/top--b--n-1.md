top - 12:54:19 up 33 min,  0 users,  load average: 0.22, 0.32, 0.19
Tasks:   9 total,   5 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 31.0 us, 48.3 sy,  0.0 ni, 20.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    270.0 free,   1069.5 used,   2496.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2585.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 295068  80376 S  26.7   7.5   1:01.22 cilium-+
   3293 root      20   0 1240432  16540  11356 S   6.7   0.4   0:00.02 cilium-+
    393 root      20   0 1229744   9924   3836 S   0.0   0.3   0:03.87 cilium-+
   3347 root      20   0    6576   2408   2084 R   0.0   0.1   0:00.00 top
   3371 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3377 root      20   0 1616264   9296   6588 R   0.0   0.2   0:00.00 runc:[2+
   3378 root      20   0 1616264   8792   6288 R   0.0   0.2   0:00.00 runc:[2+
   3387 root      20   0 1539912   8756   6476 R   0.0   0.2   0:00.00 runc:[2+
   3394 root      20   0 1616008   8280   6204 R   0.0   0.2   0:00.00 runc:[2+
