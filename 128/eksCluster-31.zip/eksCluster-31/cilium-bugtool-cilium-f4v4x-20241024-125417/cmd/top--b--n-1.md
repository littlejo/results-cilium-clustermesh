top - 12:54:18 up 33 min,  0 users,  load average: 0.58, 0.63, 0.35
Tasks:   5 total,   1 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 23.3 us, 33.3 sy,  0.0 ni, 43.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    299.7 free,   1039.1 used,   2497.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2616.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 286052  78972 S  26.7   7.3   1:23.40 cilium-+
    417 root      20   0 1229744  10052   3836 S   0.0   0.3   0:04.65 cilium-+
   3141 root      20   0 1240432  16368  11292 S   0.0   0.4   0:00.02 cilium-+
   3180 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3204 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
