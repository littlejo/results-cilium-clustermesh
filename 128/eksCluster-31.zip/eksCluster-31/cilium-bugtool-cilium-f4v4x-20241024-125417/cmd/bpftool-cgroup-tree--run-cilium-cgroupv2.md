CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2bacf2ff_8063_4b2c_b63a_0fcceadd663d.slice/cri-containerd-e973571645e1f309fe4156a28babbaf728dff95b6be56c9ff022e7741ec87289.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2bacf2ff_8063_4b2c_b63a_0fcceadd663d.slice/cri-containerd-55d5c33e20c99344ce3683378aa23829c9e5d785bd7886e176aa4147237959a8.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7fbab1d9_7e9a_4d2a_9365_6e40920d9d3d.slice/cri-containerd-532cc6c6d5ae7f78c944504b7b1f0b5def647324591d6eb9fb7cdd458e0f61f1.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7fbab1d9_7e9a_4d2a_9365_6e40920d9d3d.slice/cri-containerd-a02517c46bb7ed65e9fa5206cfa6d80532477937ebf25b59b89a4a1919fa0ba4.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod66279937_95a5_4cba_8c2f_cb9aaa96d18f.slice/cri-containerd-8f59ed5c5d8271e9748c79a517e5217de91d57a11c6cb8ea8d44052c313fcc78.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod66279937_95a5_4cba_8c2f_cb9aaa96d18f.slice/cri-containerd-0188184813bebef166305705badb234bbfeb99272b574b8b392affcb59563c5b.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47bc8772_faaf_4042_b71b_5fa350980c40.slice/cri-containerd-d55f18cff27522de6f6837ec98dec98f4b1721a14ef512f64f78461d036972f0.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47bc8772_faaf_4042_b71b_5fa350980c40.slice/cri-containerd-9668e61e5ab5f4b67b51741b274d2bd40509d06ba75aad5012998403dc62473e.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c190fa7_7509_4098_a511_a6fc3507ffad.slice/cri-containerd-a709e177e7ee4de7092f17479d9106b96bc78fb104d1209745b65f06ce8499f7.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c190fa7_7509_4098_a511_a6fc3507ffad.slice/cri-containerd-ebf0ee66cb7bb279b7138195586bb11d386e082c8fe6e7ba628c01c710f14ef0.scope
    118      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0379128_191c_41cf_8130_9f5be2f3ce4b.slice/cri-containerd-4f6f8c5f1fc5e7f21871ff0d94624702641c727bc1af44675457dafab6dd0580.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0379128_191c_41cf_8130_9f5be2f3ce4b.slice/cri-containerd-df82cfe410beb207f585fddb82eb818812445f78696ac488687faca5d87e40c5.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0379128_191c_41cf_8130_9f5be2f3ce4b.slice/cri-containerd-0cc3f47378f094c33efadce0697cae4791b3ba648fdd2b59cedbfa0d10df56de.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0379128_191c_41cf_8130_9f5be2f3ce4b.slice/cri-containerd-9659584efdd47e12f3f7324cec95fae9f4c0d6ea6ded75fadaa9066b0bf04964.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2e13e88_1ee5_4b45_9120_0282722300de.slice/cri-containerd-a44ce69d6d0be529893553babc71966747462ead55e984370c70803e30747f44.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2e13e88_1ee5_4b45_9120_0282722300de.slice/cri-containerd-777e6634eb2b89bac7fcc988b9747e2ae579b683b1bcd45623be62359ebf58a1.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2e13e88_1ee5_4b45_9120_0282722300de.slice/cri-containerd-34f7f92b7df0556bc42d0ddfe592ec76d0951668edeac473814e479dd0859af2.scope
    680      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd4876f4_44ed_4bbf_99ec_72346629491c.slice/cri-containerd-f15765fcdedd723f2e8acf92b8324033bde45ce8ac4ee2a0e7572256f2269249.scope
    695      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd4876f4_44ed_4bbf_99ec_72346629491c.slice/cri-containerd-81e97c6325f75cca2da394dab8b848306d73850a22c519c9ee661249fe3b15b2.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb19fd7bf_c78e_4333_9080_90139d69b31e.slice/cri-containerd-cd28f56d712993e0942d0844e81b960a9ec1cd750818a4a3148df2caadc77288.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb19fd7bf_c78e_4333_9080_90139d69b31e.slice/cri-containerd-b9bfa33a9795bb190150b5f3db554dc2149aec11bdd54b46d430b08429b9f139.scope
    676      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddbc82b32_a563_4285_b06e_f48c6f18c071.slice/cri-containerd-d29b29d6a240791bc59caa380a38de92b5448ddcb433c3a48b0a7327793c9fb8.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddbc82b32_a563_4285_b06e_f48c6f18c071.slice/cri-containerd-a721229505ba124945a5deeddfab909238395a24f3691140868b0871ce94d343.scope
    94       cgroup_device   multi                                          
