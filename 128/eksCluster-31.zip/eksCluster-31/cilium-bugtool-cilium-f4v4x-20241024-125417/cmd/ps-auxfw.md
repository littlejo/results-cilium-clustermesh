USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3141  0.0  0.4 1240432 16368 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3168  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3170  0.0  0.0   2068   240 ?        R    12:54   0:00  \_ hostname
root           1  5.0  7.2 1539060 284996 ?      Ssl  12:26   1:23 cilium-agent --config-dir=/tmp/cilium/config-map
root         417  0.2  0.2 1229744 10052 ?       Sl   12:26   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
