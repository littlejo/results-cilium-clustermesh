Page block order: 9
Pages per block:  512

Free pages count per migrate type at order       0      1      2      3      4      5      6      7      8      9     10 
Node    0, zone      DMA, type    Unmovable      0     28      1      1     13     10      5      0      1      1      0 
Node    0, zone      DMA, type      Movable      0      0      1      0      0      0      0      1      1      0     30 
Node    0, zone      DMA, type  Reclaimable      1      1      1      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type          CMA      0      0      1      0      0      0      1      0      0      1     15 
Node    0, zone      DMA, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type    Unmovable      1      1      7      9      6      3      4      2      0      4      0 
Node    0, zone   Normal, type      Movable      0      0      0      0      1      1      0      1      0      1      6 
Node    0, zone   Normal, type  Reclaimable      1      3      1      0      1      0      0      0      0      0      1 
Node    0, zone   Normal, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type          CMA      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 

Number of blocks type     Unmovable      Movable  Reclaimable   HighAtomic          CMA      Isolate 
Node 0, zone      DMA           40          426           14            0           32            0 
Node 0, zone   Normal          106         1362           32            0            0            0 
