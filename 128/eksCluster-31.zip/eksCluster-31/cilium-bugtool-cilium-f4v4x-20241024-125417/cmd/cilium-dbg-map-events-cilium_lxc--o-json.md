{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.692Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.421Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.430Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.464Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.473Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.503Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.622Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.662Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.688Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.756Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.760Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.348Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.364Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.406Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.410Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.443Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.684Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.708Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.759Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.811Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.821Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.417Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.464Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.493Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.554Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.639Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.649Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.875Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.886Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.953Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.965Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.003Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.675Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.678Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.715Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.727Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.776Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.809Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.828Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.068Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.078Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.123Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.143Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.175Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.625Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.650Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.706Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.716Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.750Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.067Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.077Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.157Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.179Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.205Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.513Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.568Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.575Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.616Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.620Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.655Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.868Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.874Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.913Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.942Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.963Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.360Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.393Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.407Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.449Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.450Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.455Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.747Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.752Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.806Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.826Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.859Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.215Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.250Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.304Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.308Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.346Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.358Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.644Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.681Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.727Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.770Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.784Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.234Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.296Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.332Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.385Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.404Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.439Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.621Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.640Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.731Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.776Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.825Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.137Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.176Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.178Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.236Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.253Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.281Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.465Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.505Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.552Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.577Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.611Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.948Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.950Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.008Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.021Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.052Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.290Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.303Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.316Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.321Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.339Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.153Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.158Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.228Z",
  "value": "id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.272Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.285Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.547Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.571Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.237Z",
  "value": "id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.243Z",
  "value": "id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B"
}

