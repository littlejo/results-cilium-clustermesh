1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:e7:a6:34:1e:75 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.219.96/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3426sec preferred_lft 3426sec
    inet6 fe80::8e7:a6ff:fe34:1e75/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:70:a0:68:65:6d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.198.14/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::870:a0ff:fe68:656d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:1f:a5:d4:a0:f4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::541f:a5ff:fed4:a0f4/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:67:7f:b0:c8:84 brd ff:ff:ff:ff:ff:ff
    inet 10.31.0.144/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::fc67:7fff:feb0:c884/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether be:66:0f:f1:e1:18 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::bc66:fff:fef1:e118/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:bb:00:d4:3c:6f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::5cbb:ff:fed4:3c6f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf6a5e638ac90@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:ab:1b:81:2b:0a brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::24ab:1bff:fe81:2b0a/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc7dc9a12f2ec8@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:9e:18:67:22:0a brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::9c9e:18ff:fe67:220a/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcdbead4d3d0b6@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:2c:55:bc:bb:c3 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::82c:55ff:febc:bbc3/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc47be7c708142@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:6f:37:27:5e:b6 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::946f:37ff:fe27:5eb6/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcd159ea23dbfe@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:db:b8:ab:da:f3 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::50db:b8ff:feab:daf3/64 scope link 
       valid_lft forever preferred_lft forever
24: lxccea50f8c0092@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:70:d2:38:dd:2b brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::bc70:d2ff:fe38:dd2b/64 scope link 
       valid_lft forever preferred_lft forever
