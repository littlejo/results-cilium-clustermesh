filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc7dc9a12f2ec8 direct-action not_in_hw id 525 tag ab54e2c579551a46 jited 
