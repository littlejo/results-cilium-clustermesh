alloc: 138.90MB (145649120 bytes)
total-alloc: 3.09GB (3321701304 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 75377140
frees: 73707920
heap-alloc: 138.90MB (145649120 bytes)
heap-sys: 172.62MB (181010432 bytes)
heap-idle: 20.72MB (21725184 bytes)
heap-in-use: 151.91MB (159285248 bytes)
heap-released: 13.10MB (13737984 bytes)
heap-objects: 1669220
stack-in-use: 35.38MB (37093376 bytes)
stack-sys: 35.38MB (37093376 bytes)
stack-mspan-inuse: 2.62MB (2746240 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 984.20KB (1007825 bytes)
gc-sys: 5.49MB (5754048 bytes)
next-gc: when heap-alloc >= 146.36MB (153471448 bytes)
last-gc: 2024-10-24 12:53:31.720973431 +0000 UTC
gc-pause-total: 22.191717ms
gc-pause: 175229
gc-pause-end: 1729774411720973431
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006987811483447547
enable-gc: true
debug-gc: false
