filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc47be7c708142 direct-action not_in_hw id 3326 tag 25c1dcbc1bd12add jited 
