xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 503
ens6(5) clsact/ingress cil_from_netdev-ens6 id 509
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 493
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 491
cilium_host(7) clsact/egress cil_from_host-cilium_host id 488
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 548
lxcf6a5e638ac90(12) clsact/ingress cil_from_container-lxcf6a5e638ac90 id 551
lxc7dc9a12f2ec8(14) clsact/ingress cil_from_container-lxc7dc9a12f2ec8 id 525
lxcdbead4d3d0b6(18) clsact/ingress cil_from_container-lxcdbead4d3d0b6 id 621
lxc47be7c708142(20) clsact/ingress cil_from_container-lxc47be7c708142 id 3326
lxcd159ea23dbfe(22) clsact/ingress cil_from_container-lxcd159ea23dbfe id 3267
lxccea50f8c0092(24) clsact/ingress cil_from_container-lxccea50f8c0092 id 3331

flow_dissector:

netfilter:

