IP ADDRESS        LOCAL ENDPOINT INFO
10.31.0.166:0     id=1699  sec_id=2108837 flags=0x0000 ifindex=18  mac=7A:46:0B:7C:3C:66 nodemac=0A:2C:55:BC:BB:C3   
172.31.198.14:0   (localhost)                                                                                        
10.31.0.127:0     id=866   sec_id=2147061 flags=0x0000 ifindex=14  mac=32:9B:F1:86:EE:81 nodemac=9E:9E:18:67:22:0A   
10.31.0.144:0     (localhost)                                                                                        
10.31.0.133:0     id=1754  sec_id=2112703 flags=0x0000 ifindex=22  mac=22:41:2E:3F:B4:21 nodemac=52:DB:B8:AB:DA:F3   
172.31.219.96:0   (localhost)                                                                                        
10.31.0.128:0     id=758   sec_id=2158161 flags=0x0000 ifindex=20  mac=9E:60:AD:E6:12:71 nodemac=96:6F:37:27:5E:B6   
10.31.0.43:0      id=2277  sec_id=2126466 flags=0x0000 ifindex=24  mac=7E:3C:33:55:DD:25 nodemac=BE:70:D2:38:DD:2B   
10.31.0.151:0     id=373   sec_id=2147061 flags=0x0000 ifindex=12  mac=92:6F:DB:B9:31:90 nodemac=26:AB:1B:81:2B:0A   
10.31.0.153:0     id=1080  sec_id=4     flags=0x0000 ifindex=10  mac=42:02:2E:81:B7:0D nodemac=5E:BB:00:D4:3C:6F     
