[
  {
    "containers": [
      {
        "cgroup-id": 10025,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2e13e88_1ee5_4b45_9120_0282722300de.slice/cri-containerd-777e6634eb2b89bac7fcc988b9747e2ae579b683b1bcd45623be62359ebf58a1.scope"
      },
      {
        "cgroup-id": 10109,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2e13e88_1ee5_4b45_9120_0282722300de.slice/cri-containerd-a44ce69d6d0be529893553babc71966747462ead55e984370c70803e30747f44.scope"
      }
    ],
    "ips": [
      "10.31.0.133"
    ],
    "name": "echo-same-node-86d9cc975c-tkmdc",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47bc8772_faaf_4042_b71b_5fa350980c40.slice/cri-containerd-d55f18cff27522de6f6837ec98dec98f4b1721a14ef512f64f78461d036972f0.scope"
      }
    ],
    "ips": [
      "10.31.0.151"
    ],
    "name": "coredns-cc6ccd49c-6n2zt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2bacf2ff_8063_4b2c_b63a_0fcceadd663d.slice/cri-containerd-55d5c33e20c99344ce3683378aa23829c9e5d785bd7886e176aa4147237959a8.scope"
      }
    ],
    "ips": [
      "10.31.0.127"
    ],
    "name": "coredns-cc6ccd49c-vdmjm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9857,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd4876f4_44ed_4bbf_99ec_72346629491c.slice/cri-containerd-81e97c6325f75cca2da394dab8b848306d73850a22c519c9ee661249fe3b15b2.scope"
      }
    ],
    "ips": [
      "10.31.0.43"
    ],
    "name": "client2-57cf4468f-97lmt",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9941,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb19fd7bf_c78e_4333_9080_90139d69b31e.slice/cri-containerd-cd28f56d712993e0942d0844e81b960a9ec1cd750818a4a3148df2caadc77288.scope"
      }
    ],
    "ips": [
      "10.31.0.128"
    ],
    "name": "client-974f6c69d-ps8mr",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9185,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0379128_191c_41cf_8130_9f5be2f3ce4b.slice/cri-containerd-0cc3f47378f094c33efadce0697cae4791b3ba648fdd2b59cedbfa0d10df56de.scope"
      },
      {
        "cgroup-id": 9101,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0379128_191c_41cf_8130_9f5be2f3ce4b.slice/cri-containerd-9659584efdd47e12f3f7324cec95fae9f4c0d6ea6ded75fadaa9066b0bf04964.scope"
      },
      {
        "cgroup-id": 9269,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0379128_191c_41cf_8130_9f5be2f3ce4b.slice/cri-containerd-df82cfe410beb207f585fddb82eb818812445f78696ac488687faca5d87e40c5.scope"
      }
    ],
    "ips": [
      "10.31.0.166"
    ],
    "name": "clustermesh-apiserver-5b57bbfb45-jxhtk",
    "namespace": "kube-system"
  }
]

