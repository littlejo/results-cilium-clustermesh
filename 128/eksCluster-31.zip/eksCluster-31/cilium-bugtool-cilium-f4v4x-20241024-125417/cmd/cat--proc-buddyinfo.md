Node 0, zone      DMA      2     30      3      1     14     11      6      1      2      2     46 
Node 0, zone   Normal      2      4      8      9      8      4      4      3      0      5      7 
