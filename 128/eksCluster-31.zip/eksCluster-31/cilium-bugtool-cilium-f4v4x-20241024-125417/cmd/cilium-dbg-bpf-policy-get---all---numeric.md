Endpoint ID: 373
Path: /sys/fs/bpf/tc/globals/cilium_policy_00373

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2872     29        0        
Allow    Ingress     1          ANY          NONE         disabled    156419   1795      0        
Allow    Egress      0          ANY          NONE         disabled    21508    241       0        


Endpoint ID: 758
Path: /sys/fs/bpf/tc/globals/cilium_policy_00758

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 844
Path: /sys/fs/bpf/tc/globals/cilium_policy_00844

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 866
Path: /sys/fs/bpf/tc/globals/cilium_policy_00866

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3024     31        0        
Allow    Ingress     1          ANY          NONE         disabled    156089   1790      0        
Allow    Egress      0          ANY          NONE         disabled    21455    241       0        


Endpoint ID: 1080
Path: /sys/fs/bpf/tc/globals/cilium_policy_01080

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6188476   76465     0        
Allow    Ingress     1          ANY          NONE         disabled    66272     801       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1699
Path: /sys/fs/bpf/tc/globals/cilium_policy_01699

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5458414   56766     0        
Allow    Ingress     1          ANY          NONE         disabled    5706099   60372     0        
Allow    Egress      0          ANY          NONE         disabled    6922383   69368     0        


Endpoint ID: 1754
Path: /sys/fs/bpf/tc/globals/cilium_policy_01754

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    352493   4116      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2277
Path: /sys/fs/bpf/tc/globals/cilium_policy_02277

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


