key: 75 01 00 00  value: 1a 02 00 00
key: f6 02 00 00  value: 06 0d 00 00
key: 62 03 00 00  value: 08 02 00 00
key: 38 04 00 00  value: 2a 02 00 00
key: a3 06 00 00  value: 6a 02 00 00
key: da 06 00 00  value: c0 0c 00 00
key: e5 08 00 00  value: 0a 0d 00 00
Found 7 elements
