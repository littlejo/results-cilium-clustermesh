key: 09 00 00 00  value: 0a 67 00 dc 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 67 00 93 09 4b 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 67 00 b3 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 67 00 b3 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f 96 cb 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 67 00 dc 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f da 76 10 94 00 00  00 00 00 00
key: 0c 00 00 00  value: 0a 67 00 15 1f 90 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f ff 86 01 bb 00 00  00 00 00 00
Found 9 elements
