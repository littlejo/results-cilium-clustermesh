Node 0, zone      DMA     65     57      7     45     20     11      9      2      0      3     41 
Node 0, zone   Normal    480     99     12      6      7      5      3      2      2      3      7 
