Total: 561
TCP:   4555 (estab 304, closed 4232, orphaned 0, timewait 3773)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  323       311       12       
INET	  333       317       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:34546 sk:1001 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:14967 sk:1002 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:33835      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:35334 sk:1003 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.218.118%ens5:68         0.0.0.0:*    uid:192 ino:149022 sk:1004 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                                 [::]:8472          [::]:*    ino:34545 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:14968 sk:1006 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::8af:a1ff:fe7f:1161]%ens5:546           [::]:*    uid:192 ino:15852 sk:1007 cgroup:unreachable:bd0 v6only:1 <->                   
