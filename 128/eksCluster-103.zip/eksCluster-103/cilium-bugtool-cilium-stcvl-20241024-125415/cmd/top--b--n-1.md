top - 12:54:16 up 31 min,  0 users,  load average: 0.65, 0.58, 0.35
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 26.7 us, 26.7 sy,  0.0 ni, 40.0 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   3836.2 total,    289.8 free,   1050.2 used,   2496.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2605.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 296448  78524 S  13.3   7.5   1:08.41 cilium-+
    418 root      20   0 1229744   9732   3836 S   0.0   0.2   0:04.49 cilium-+
   3184 root      20   0 1240432  16752  11548 S   0.0   0.4   0:00.03 cilium-+
   3245 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3246 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3256 root      20   0    6576   2420   2092 R   0.0   0.1   0:00.00 top
   3282 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
