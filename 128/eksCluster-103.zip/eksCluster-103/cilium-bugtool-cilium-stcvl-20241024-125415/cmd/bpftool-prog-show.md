32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:02+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:23:03+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:23:03+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:23:03+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:23:03+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:03+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:23:07+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:23:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:23:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:31:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:31:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:32:17+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 124
482: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:32:17+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
483: sched_cls  name tail_handle_ipv4  tag 682d0af4ac4d8edf  gpl
	loaded_at 2024-10-24T12:32:17+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:32:17+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
507: sched_cls  name tail_handle_ipv4  tag 331c7a747c3d6545  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 153
508: sched_cls  name tail_handle_arp  tag eb71ed42de783a2f  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 154
509: sched_cls  name tail_handle_ipv4_cont  tag 9429876bce18e183  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 155
510: sched_cls  name handle_policy  tag 69f96217f9063d7d  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 156
511: sched_cls  name __send_drop_notify  tag 8f15adc0f9fa0ee2  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 157
512: sched_cls  name cil_from_container  tag 9875dfcb61c3f4bc  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 107,76
	btf_id 158
513: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 159
514: sched_cls  name tail_ipv4_to_endpoint  tag 04ebc9db931948ee  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 160
515: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 161
516: sched_cls  name tail_ipv4_ct_ingress  tag 75fa8046788391d8  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 162
518: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
521: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
522: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
525: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
526: sched_cls  name tail_ipv4_ct_ingress  tag 93244c8533810493  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 165
528: sched_cls  name handle_policy  tag e1d50053fd9b149d  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,112,41,80,101,39,84,75,40,37,38
	btf_id 167
529: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 168
530: sched_cls  name tail_handle_arp  tag d26447f7d8d9fa63  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 169
531: sched_cls  name cil_from_container  tag 82f13d2fb8e44f45  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 170
532: sched_cls  name tail_ipv4_ct_egress  tag a33b3e8a110e6ea2  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 171
533: sched_cls  name __send_drop_notify  tag cba6df1b6cf4b5dd  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 172
534: sched_cls  name tail_handle_ipv4_cont  tag c94163001ae03466  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,101,82,83,39,76,74,77,111,40,37,38,81
	btf_id 173
535: sched_cls  name tail_ipv4_to_endpoint  tag 473ccb75c981ecbe  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,101,39,111,40,37,38
	btf_id 174
536: sched_cls  name tail_handle_ipv4  tag 497b7813c3ead600  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 175
537: sched_cls  name tail_handle_arp  tag 3c58f87442e74d77  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,114
	btf_id 177
538: sched_cls  name handle_policy  tag ec353c8f586ed0ac  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,114,82,83,113,41,80,100,39,84,75,40,37,38
	btf_id 178
539: sched_cls  name __send_drop_notify  tag 09b2d1e0f39f6147  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 179
540: sched_cls  name tail_ipv4_ct_egress  tag a33b3e8a110e6ea2  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 180
541: sched_cls  name tail_ipv4_to_endpoint  tag 02c71e68f2a7d6d2  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,100,39,114,40,37,38
	btf_id 181
542: sched_cls  name cil_from_container  tag f0bac23e596ecf06  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 114,76
	btf_id 182
543: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,114
	btf_id 183
544: sched_cls  name tail_handle_ipv4  tag adbf74471b0c8f50  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,114
	btf_id 184
545: sched_cls  name tail_handle_ipv4_cont  tag d66da042d8ffd143  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,100,82,83,39,76,74,77,114,40,37,38,81
	btf_id 185
547: sched_cls  name tail_ipv4_ct_ingress  tag 69db7d5c1dd328ca  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 187
548: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
551: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
552: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
555: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
556: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 189
557: sched_cls  name tail_handle_ipv4_from_host  tag 341d1935aed9d385  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 190
559: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 192
561: sched_cls  name __send_drop_notify  tag 2c9f7dfa5ad9a175  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 194
562: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 195
564: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 198
566: sched_cls  name __send_drop_notify  tag 2c9f7dfa5ad9a175  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 200
568: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 202
569: sched_cls  name tail_handle_ipv4_from_host  tag 341d1935aed9d385  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 203
570: sched_cls  name __send_drop_notify  tag 2c9f7dfa5ad9a175  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
572: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 207
573: sched_cls  name tail_handle_ipv4_from_host  tag 341d1935aed9d385  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 208
576: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 211
577: sched_cls  name __send_drop_notify  tag 2c9f7dfa5ad9a175  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 213
579: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 215
580: sched_cls  name tail_handle_ipv4_from_host  tag 341d1935aed9d385  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 216
583: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:20+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 219
623: sched_cls  name handle_policy  tag 3ccba6cb96de957d  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,137,82,83,136,41,80,135,39,84,75,40,37,38
	btf_id 233
624: sched_cls  name tail_ipv4_ct_egress  tag bcf4843dd6268f7e  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 234
625: sched_cls  name cil_from_container  tag 9228683b0a6e274e  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 137,76
	btf_id 235
626: sched_cls  name tail_ipv4_to_endpoint  tag 645af2e44517ad22  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,136,41,82,83,80,135,39,137,40,37,38
	btf_id 236
627: sched_cls  name tail_handle_ipv4  tag 123775aacf76023a  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,137
	btf_id 237
629: sched_cls  name tail_handle_arp  tag 825352127ac8cfc4  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,137
	btf_id 239
630: sched_cls  name tail_handle_ipv4_cont  tag b0f257ae2b5aff85  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,136,41,135,82,83,39,76,74,77,137,40,37,38,81
	btf_id 240
631: sched_cls  name __send_drop_notify  tag c796d58cfb6a9e6b  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 241
632: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,137
	btf_id 242
633: sched_cls  name tail_ipv4_ct_ingress  tag b29500ae9e07c0ad  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 243
634: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
637: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
658: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
661: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
695: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
698: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
699: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
702: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
703: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
706: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
707: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
710: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
711: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
714: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
715: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
718: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
719: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
722: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3264: sched_cls  name tail_handle_arp  tag 69a95cbaa58c0265  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,624
	btf_id 3053
3265: sched_cls  name handle_policy  tag ca4407b6a2f38a1b  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,624,82,83,623,41,80,151,39,84,75,40,37,38
	btf_id 3054
3267: sched_cls  name __send_drop_notify  tag 8b4a5fba42beaae1  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3058
3268: sched_cls  name tail_handle_ipv4_cont  tag 71330e53db885185  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,623,41,151,82,83,39,76,74,77,624,40,37,38,81
	btf_id 3059
3274: sched_cls  name tail_handle_ipv4  tag 60127325934e5ed0  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,624
	btf_id 3062
3276: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,624
	btf_id 3066
3279: sched_cls  name tail_ipv4_to_endpoint  tag 389b5d98c3c1d9b4  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,623,41,82,83,80,151,39,624,40,37,38
	btf_id 3069
3280: sched_cls  name tail_ipv4_ct_ingress  tag a73aa80f3de09cbb  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,624,82,83,623,84
	btf_id 3071
3281: sched_cls  name cil_from_container  tag dced35ade7ea386d  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 624,76
	btf_id 3072
3283: sched_cls  name tail_ipv4_ct_egress  tag 303a46ec8e56873f  gpl
	loaded_at 2024-10-24T12:51:22+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,624,82,83,623,84
	btf_id 3073
3319: sched_cls  name tail_handle_arp  tag b3b86a6c6f01c503  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,633
	btf_id 3113
3320: sched_cls  name cil_from_container  tag 17cbafd7a1d09503  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 633,76
	btf_id 3115
3321: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,636
	btf_id 3116
3322: sched_cls  name __send_drop_notify  tag f1da9a07f1159058  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3118
3323: sched_cls  name tail_ipv4_ct_ingress  tag ed7f2dd33bc2c656  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3117
3324: sched_cls  name tail_handle_ipv4_cont  tag 45ccaac6c73c84f6  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,635,41,148,82,83,39,76,74,77,636,40,37,38,81
	btf_id 3119
3325: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,633
	btf_id 3120
3326: sched_cls  name tail_handle_ipv4  tag 8f525038129c23d1  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,633
	btf_id 3122
3327: sched_cls  name handle_policy  tag c8aa7e727df32f03  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,636,82,83,635,41,80,148,39,84,75,40,37,38
	btf_id 3121
3328: sched_cls  name handle_policy  tag 2ab5676a9b544578  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,633,82,83,634,41,80,145,39,84,75,40,37,38
	btf_id 3123
3330: sched_cls  name tail_handle_ipv4_cont  tag 40d28e15fbda6f5d  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,634,41,145,82,83,39,76,74,77,633,40,37,38,81
	btf_id 3126
3331: sched_cls  name __send_drop_notify  tag 355db1ac74a2e3d9  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3127
3332: sched_cls  name tail_ipv4_to_endpoint  tag a8669b3fc054b430  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,635,41,82,83,80,148,39,636,40,37,38
	btf_id 3124
3333: sched_cls  name tail_ipv4_ct_ingress  tag b96b95200015d26a  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3129
3334: sched_cls  name cil_from_container  tag 2281d85eda947b12  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 636,76
	btf_id 3130
3336: sched_cls  name tail_ipv4_ct_egress  tag 56f237ce6561bdd2  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3132
3337: sched_cls  name tail_handle_ipv4  tag bdaf2fd746832a4d  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,636
	btf_id 3133
3338: sched_cls  name tail_handle_arp  tag 82ea61b3851e91eb  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,636
	btf_id 3134
3339: sched_cls  name tail_ipv4_to_endpoint  tag 05de94455ba1542b  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,634,41,82,83,80,145,39,633,40,37,38
	btf_id 3128
3340: sched_cls  name tail_ipv4_ct_egress  tag 9f69bc7d68b0b9a0  gpl
	loaded_at 2024-10-24T12:51:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3135
