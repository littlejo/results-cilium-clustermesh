KEY             VALUE
AgentLiveness   1907416685435
UTimeOffset     3378462070312500
