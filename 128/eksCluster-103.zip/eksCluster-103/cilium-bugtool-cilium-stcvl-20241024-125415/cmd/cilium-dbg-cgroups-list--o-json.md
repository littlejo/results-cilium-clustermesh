[
  {
    "containers": [
      {
        "cgroup-id": 9857,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6a9a729_6b1a_4afa_a522_9c1d5fea3aa9.slice/cri-containerd-74a91aa07bf99bc8962bb33e5813c8225742b14a802ba23ebdf363b55620fa7d.scope"
      }
    ],
    "ips": [
      "10.103.0.115"
    ],
    "name": "client2-57cf4468f-k8l9b",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9941,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d61515e_406b_4ab6_96f6_630d9fb6f4d2.slice/cri-containerd-1ea9aa902349e560d1c78d137513c9527b42e5784293172bf465d358ce5c1821.scope"
      }
    ],
    "ips": [
      "10.103.0.218"
    ],
    "name": "client-974f6c69d-dlwmc",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5cfa6342_9cc0_4469_9d05_40ff9ac0e5ea.slice/cri-containerd-2b80f8f05c1f24861780a461c69b633ed4f5b0243e8fadf9b59917d4d35482a0.scope"
      }
    ],
    "ips": [
      "10.103.0.179"
    ],
    "name": "coredns-cc6ccd49c-749gh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9185,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podebd7eaa1_2d49_4e08_91c3_f4eb43420d74.slice/cri-containerd-22dbc9edf2fa275239cb93e3234ec781b41e18625188f9dc0a86a5e65d613b0c.scope"
      },
      {
        "cgroup-id": 9269,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podebd7eaa1_2d49_4e08_91c3_f4eb43420d74.slice/cri-containerd-cb29c7021e74ea9f863a2c497426d42d2b0cc87d578f71b96d4bf588cb4871a5.scope"
      },
      {
        "cgroup-id": 9101,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podebd7eaa1_2d49_4e08_91c3_f4eb43420d74.slice/cri-containerd-3d233efee926ee07609f9c4f2a9fa788d9d998da4bc41dc335e914da3a71295d.scope"
      }
    ],
    "ips": [
      "10.103.0.147"
    ],
    "name": "clustermesh-apiserver-599475874f-x8vnr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10025,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod32492ff7_f230_40de_9995_93614a3305b2.slice/cri-containerd-db1ba0b53bbaa5963a66579652d70af5807cb77cc821f05d3d9c9e41113b25bc.scope"
      },
      {
        "cgroup-id": 10109,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod32492ff7_f230_40de_9995_93614a3305b2.slice/cri-containerd-6f02b424c0893321cd534f91cc89a064bfe95ff6864b779489c6d4f8717aa25c.scope"
      }
    ],
    "ips": [
      "10.103.0.21"
    ],
    "name": "echo-same-node-86d9cc975c-jj67t",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9f54a453_387a_4fc8_b724_b2a45a8194ad.slice/cri-containerd-5654e20a8db881752107007e69befaa80d15b14aa00a4dad5a28dd44ca046add.scope"
      }
    ],
    "ips": [
      "10.103.0.220"
    ],
    "name": "coredns-cc6ccd49c-6gfhs",
    "namespace": "kube-system"
  }
]

