filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcce96bb34c651 direct-action not_in_hw id 3334 tag 2281d85eda947b12 jited 
