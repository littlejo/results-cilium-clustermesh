Endpoint ID: 15
Path: /sys/fs/bpf/tc/globals/cilium_policy_00015

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6230591   76846     0        
Allow    Ingress     1          ANY          NONE         disabled    60201     725       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 183
Path: /sys/fs/bpf/tc/globals/cilium_policy_00183

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377653   4407      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 185
Path: /sys/fs/bpf/tc/globals/cilium_policy_00185

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    271134   2448      0        
Allow    Ingress     1          ANY          NONE         disabled    129079   1480      0        
Allow    Egress      0          ANY          NONE         disabled    69068    680       0        


Endpoint ID: 441
Path: /sys/fs/bpf/tc/globals/cilium_policy_00441

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 478
Path: /sys/fs/bpf/tc/globals/cilium_policy_00478

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1035
Path: /sys/fs/bpf/tc/globals/cilium_policy_01035

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    288384   2602      0        
Allow    Ingress     1          ANY          NONE         disabled    129079   1480      0        
Allow    Egress      0          ANY          NONE         disabled    68969    677       0        


Endpoint ID: 1658
Path: /sys/fs/bpf/tc/globals/cilium_policy_01658

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6150736   61736     0        
Allow    Ingress     1          ANY          NONE         disabled    5459460   57690     0        
Allow    Egress      0          ANY          NONE         disabled    6932625   68425     0        


Endpoint ID: 3773
Path: /sys/fs/bpf/tc/globals/cilium_policy_03773

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


