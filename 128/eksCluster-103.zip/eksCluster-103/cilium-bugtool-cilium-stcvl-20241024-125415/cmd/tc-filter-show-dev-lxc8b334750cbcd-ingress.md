filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc8b334750cbcd direct-action not_in_hw id 3281 tag dced35ade7ea386d jited 
