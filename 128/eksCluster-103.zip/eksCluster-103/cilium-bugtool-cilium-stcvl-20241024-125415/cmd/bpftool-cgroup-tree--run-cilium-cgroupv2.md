CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c09d9d1_6360_4d20_b99d_cdb5267fdb0a.slice/cri-containerd-244889b83e41b8f6ce6670d111e8f6526d5377fd454b2e50c0cd0a61d4624299.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c09d9d1_6360_4d20_b99d_cdb5267fdb0a.slice/cri-containerd-3092f5a7037c888a587d424f25a85c09a59e72ad0d4f7ddcac2cc6971db71250.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod88235630_4f81_41c6_b99a_2ff4fc0ec8f8.slice/cri-containerd-6494fb251b2926020c1a11c066c12f54e3cc7c7cbebbbcb39de28fc5d7fc0182.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod88235630_4f81_41c6_b99a_2ff4fc0ec8f8.slice/cri-containerd-4d6af4511c8ddb4d67ad7f92aa1f0fb00ca50a86d7ff1ad3fa74684b5b42b40b.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9f54a453_387a_4fc8_b724_b2a45a8194ad.slice/cri-containerd-24da66fa55586f67fd6c7406038431b7dbe8e7c84ebc1cfaf310909305a8ff28.scope
    525      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9f54a453_387a_4fc8_b724_b2a45a8194ad.slice/cri-containerd-5654e20a8db881752107007e69befaa80d15b14aa00a4dad5a28dd44ca046add.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5cfa6342_9cc0_4469_9d05_40ff9ac0e5ea.slice/cri-containerd-62f7d7d5868231dd3fe63b7fcfd594802dd0d3e059501065f7a95be0373377cc.scope
    521      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5cfa6342_9cc0_4469_9d05_40ff9ac0e5ea.slice/cri-containerd-2b80f8f05c1f24861780a461c69b633ed4f5b0243e8fadf9b59917d4d35482a0.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podebd7eaa1_2d49_4e08_91c3_f4eb43420d74.slice/cri-containerd-22dbc9edf2fa275239cb93e3234ec781b41e18625188f9dc0a86a5e65d613b0c.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podebd7eaa1_2d49_4e08_91c3_f4eb43420d74.slice/cri-containerd-3d233efee926ee07609f9c4f2a9fa788d9d998da4bc41dc335e914da3a71295d.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podebd7eaa1_2d49_4e08_91c3_f4eb43420d74.slice/cri-containerd-cd364ca4b6241b6699c6e1fbbe440823b3eb887ed20f843ceaf90d11292fab1d.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podebd7eaa1_2d49_4e08_91c3_f4eb43420d74.slice/cri-containerd-cb29c7021e74ea9f863a2c497426d42d2b0cc87d578f71b96d4bf588cb4871a5.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ae40987_c555_4d60_8081_069541174c83.slice/cri-containerd-983f8cd35672d7de7fa28ce6318c5f5acb6551340f2d711d2290d3a6aabe4d26.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ae40987_c555_4d60_8081_069541174c83.slice/cri-containerd-aa42de8f4cdfd17688f8ae568539559ff1453923727339bd5f3a4b736d84aaa3.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4065f407_04f8_4451_ad00_73111462fd8b.slice/cri-containerd-201d7ac90fa4e1d0b3809bdf3fe3592fcf6fd19b27d8ac12231bd16e008949de.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4065f407_04f8_4451_ad00_73111462fd8b.slice/cri-containerd-102177a7d052cfc7b2ec038315165506d2bfe778129c37204b9cd30c34097e3a.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod32492ff7_f230_40de_9995_93614a3305b2.slice/cri-containerd-108cbbbabe6b22beed248b42e1f4355040d9c27db41f902ba3423d8c438dd563.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod32492ff7_f230_40de_9995_93614a3305b2.slice/cri-containerd-db1ba0b53bbaa5963a66579652d70af5807cb77cc821f05d3d9c9e41113b25bc.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod32492ff7_f230_40de_9995_93614a3305b2.slice/cri-containerd-6f02b424c0893321cd534f91cc89a064bfe95ff6864b779489c6d4f8717aa25c.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d61515e_406b_4ab6_96f6_630d9fb6f4d2.slice/cri-containerd-1ea9aa902349e560d1c78d137513c9527b42e5784293172bf465d358ce5c1821.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d61515e_406b_4ab6_96f6_630d9fb6f4d2.slice/cri-containerd-64f8ab5208a798a7c21ee46049d8e7629cd2693f4aa01cc4819e53ba458cae3a.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6a9a729_6b1a_4afa_a522_9c1d5fea3aa9.slice/cri-containerd-74a91aa07bf99bc8962bb33e5813c8225742b14a802ba23ebdf363b55620fa7d.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6a9a729_6b1a_4afa_a522_9c1d5fea3aa9.slice/cri-containerd-7fd4c7e1b500bcb862c4bec6926bcccd7cdfd5ce212c99759f9a0a3eea099f87.scope
    698      cgroup_device   multi                                          
