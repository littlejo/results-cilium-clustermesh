key: 0f 00 00 00  value: fe 01 00 00
key: b7 00 00 00  value: c1 0c 00 00
key: b9 00 00 00  value: 1a 02 00 00
key: b9 01 00 00  value: 00 0d 00 00
key: 0b 04 00 00  value: 10 02 00 00
key: 7a 06 00 00  value: 6f 02 00 00
key: bd 0e 00 00  value: ff 0c 00 00
Found 7 elements
