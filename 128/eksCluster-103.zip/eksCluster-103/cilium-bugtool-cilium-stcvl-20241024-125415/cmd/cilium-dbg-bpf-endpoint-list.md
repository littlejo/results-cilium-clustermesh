IP ADDRESS         LOCAL ENDPOINT INFO
10.103.0.21:0      id=183   sec_id=6837340 flags=0x0000 ifindex=24  mac=EA:8C:E9:82:B7:B3 nodemac=42:4F:50:B4:68:DB   
10.103.0.218:0     id=3773  sec_id=6855377 flags=0x0000 ifindex=22  mac=9E:D4:81:3E:FE:E3 nodemac=1A:02:73:7F:4B:27   
10.103.0.179:0     id=185   sec_id=6835843 flags=0x0000 ifindex=14  mac=2E:6F:CD:9D:18:78 nodemac=D2:AF:54:B2:33:D1   
10.103.0.220:0     id=1035  sec_id=6835843 flags=0x0000 ifindex=12  mac=A6:8A:8B:94:37:7A nodemac=82:94:57:F5:98:B0   
172.31.253.94:0    (localhost)                                                                                        
10.103.0.123:0     (localhost)                                                                                        
10.103.0.147:0     id=1658  sec_id=6862600 flags=0x0000 ifindex=18  mac=BE:B4:D0:43:48:F8 nodemac=C6:DD:83:0E:62:EE   
10.103.0.161:0     id=15    sec_id=4     flags=0x0000 ifindex=10  mac=76:36:D5:43:62:A1 nodemac=1A:80:47:11:97:C6     
10.103.0.115:0     id=441   sec_id=6857970 flags=0x0000 ifindex=20  mac=3A:61:FF:F1:2B:B5 nodemac=D2:12:A1:A5:4C:E3   
172.31.218.118:0   (localhost)                                                                                        
