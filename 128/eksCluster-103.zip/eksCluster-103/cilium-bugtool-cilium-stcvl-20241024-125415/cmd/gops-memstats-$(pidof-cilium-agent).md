alloc: 88.95MB (93272096 bytes)
total-alloc: 3.10GB (3327769288 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 75499775
frees: 74777734
heap-alloc: 88.95MB (93272096 bytes)
heap-sys: 172.64MB (181026816 bytes)
heap-idle: 48.37MB (50716672 bytes)
heap-in-use: 124.27MB (130310144 bytes)
heap-released: 5.38MB (5644288 bytes)
heap-objects: 722041
stack-in-use: 35.31MB (37027840 bytes)
stack-sys: 35.31MB (37027840 bytes)
stack-mspan-inuse: 2.01MB (2106080 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 988.43KB (1012153 bytes)
gc-sys: 5.54MB (5809320 bytes)
next-gc: when heap-alloc >= 152.51MB (159922264 bytes)
last-gc: 2024-10-24 12:54:31.127860693 +0000 UTC
gc-pause-total: 15.262108ms
gc-pause: 92758
gc-pause-end: 1729774471127860693
num-gc: 97
num-forced-gc: 0
gc-cpu-fraction: 0.0006949160729074531
enable-gc: true
debug-gc: false
