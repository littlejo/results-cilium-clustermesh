xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 576
ens6(5) clsact/ingress cil_from_netdev-ens6 id 583
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 564
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 559
cilium_host(7) clsact/egress cil_from_host-cilium_host id 562
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 512
lxc1393ed192ab4(12) clsact/ingress cil_from_container-lxc1393ed192ab4 id 531
lxc8cbd8d29d039(14) clsact/ingress cil_from_container-lxc8cbd8d29d039 id 542
lxcd9c44e508eb5(18) clsact/ingress cil_from_container-lxcd9c44e508eb5 id 625
lxcfd8e23dee63f(20) clsact/ingress cil_from_container-lxcfd8e23dee63f id 3320
lxcce96bb34c651(22) clsact/ingress cil_from_container-lxcce96bb34c651 id 3334
lxc8b334750cbcd(24) clsact/ingress cil_from_container-lxc8b334750cbcd id 3281

flow_dissector:

netfilter:

