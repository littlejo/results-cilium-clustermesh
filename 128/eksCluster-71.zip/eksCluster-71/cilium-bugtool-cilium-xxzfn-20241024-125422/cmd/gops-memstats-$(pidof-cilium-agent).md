alloc: 146.75MB (153879656 bytes)
total-alloc: 3.07GB (3299992512 bytes)
sys: 227.32MB (238363988 bytes)
lookups: 0
mallocs: 74999072
frees: 73447517
heap-alloc: 146.75MB (153879656 bytes)
heap-sys: 178.05MB (186695680 bytes)
heap-idle: 13.59MB (14254080 bytes)
heap-in-use: 164.45MB (172441600 bytes)
heap-released: 9.91MB (10387456 bytes)
heap-objects: 1551555
stack-in-use: 37.66MB (39485440 bytes)
stack-sys: 37.66MB (39485440 bytes)
stack-mspan-inuse: 2.58MB (2702560 bytes)
stack-mspan-sys: 2.82MB (2953920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 954.62KB (977529 bytes)
gc-sys: 5.76MB (6044720 bytes)
next-gc: when heap-alloc >= 148.26MB (155461976 bytes)
last-gc: 2024-10-24 12:54:08.308864915 +0000 UTC
gc-pause-total: 10.273554ms
gc-pause: 131962
gc-pause-end: 1729774448308864915
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.000607367944234021
enable-gc: true
debug-gc: false
