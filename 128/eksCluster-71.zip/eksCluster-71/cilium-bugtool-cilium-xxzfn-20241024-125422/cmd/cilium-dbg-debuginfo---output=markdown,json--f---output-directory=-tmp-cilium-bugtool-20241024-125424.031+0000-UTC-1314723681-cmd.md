markdown output at /tmp/cilium-bugtool-20241024-125424.031+0000-UTC-1314723681/cmd/cilium-debuginfo-20241024-125454.552+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125424.031+0000-UTC-1314723681/cmd/cilium-debuginfo-20241024-125454.552+0000-UTC.json
