USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3195  0.0  0.4 1240432 16568 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3221  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3180  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3174  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  4.8  7.4 1539060 290868 ?      Ssl  12:29   1:12 cilium-agent --config-dir=/tmp/cilium/config-map
root         415  0.2  0.2 1229744 10176 ?       Sl   12:29   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
