filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc0bc5f28ab1b direct-action not_in_hw id 3281 tag 7992e85cdde1172a jited 
