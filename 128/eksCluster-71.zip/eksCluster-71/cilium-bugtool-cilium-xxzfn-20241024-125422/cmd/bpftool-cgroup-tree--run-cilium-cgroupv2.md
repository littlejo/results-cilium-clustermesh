CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3bf28aa0_e746_434f_a129_71854fae4368.slice/cri-containerd-8a2d8f589ee017d840a69d5c8c70308eecc99378eedf8933b992aa508ad7a053.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3bf28aa0_e746_434f_a129_71854fae4368.slice/cri-containerd-3af99e44f431b145f3b7afcedf8ec85202075dd46ae2016469a0bd906e3a38d2.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbac07d09_7b10_4631_b217_f228c74e0d27.slice/cri-containerd-af7fff056e9db70cb30b9df8ec1629d2558c03d148fbbbd9ddd877e0ed976266.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbac07d09_7b10_4631_b217_f228c74e0d27.slice/cri-containerd-48357392c97d8d1f30efc24df48d30012fb3a85bc3ce31ebb57c142ab1dcab89.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd5b9418d_1dbc_498e_9961_f0b759c7642d.slice/cri-containerd-afc86dfa618d4c820dddec412e851520d3e73d278d17bf04a547da199afc4d39.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd5b9418d_1dbc_498e_9961_f0b759c7642d.slice/cri-containerd-6a61c23716855357088310b17e42add3f36b74f53042561a3bea21decbc65996.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c0a7e0c_d4fd_46b4_b0f6_07871413f054.slice/cri-containerd-164cd5d8592642453970d8a8d2676b9ffd333ed3aca4e550dd6053db35480b82.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c0a7e0c_d4fd_46b4_b0f6_07871413f054.slice/cri-containerd-c39d4d79579e33928c58588f8fccb36fc4a4b08a037d72aa7c37c0b6eebe7686.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode254ea61_3522_476e_a211_fb7b73689568.slice/cri-containerd-ab3844c3c6d62b9caa0f33b4a8192e700bc6dcc147be47778062698c1480e412.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode254ea61_3522_476e_a211_fb7b73689568.slice/cri-containerd-11bf08b337644117657a8e574341d6b8ff28ec1863079ff73b8b0dbb49c8828d.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode254ea61_3522_476e_a211_fb7b73689568.slice/cri-containerd-0964024f9ba82d6d4215100b87bb48815aeb6976e23ff49c8a940af45a166fc0.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode254ea61_3522_476e_a211_fb7b73689568.slice/cri-containerd-53817bdbf3053ba130f0c37498549abb61183c1ff1b6dae0ec765f94b8fdcb26.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode9dba7ca_276c_4a12_b7a2_1dc36a6ef5a5.slice/cri-containerd-7050a4e90d1752a32fa47291228db6022529685b7e18ab8a9a392193e075a9e5.scope
    716      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode9dba7ca_276c_4a12_b7a2_1dc36a6ef5a5.slice/cri-containerd-3df6a98d8d225a249dc0f435ce19fc8b451fa3d3dfd4141b14f332deccc3ae83.scope
    728      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd8dfca73_e140_4d3f_9a71_2ec70ace6158.slice/cri-containerd-5b01e906b52ef71ca2aab91d1dffd65e23ab87569a883305b3f0655a553df0c8.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd8dfca73_e140_4d3f_9a71_2ec70ace6158.slice/cri-containerd-45d84694d73aa412f9e9e9515b529bb983628513711e34674a342c82da46665d.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2339d3e3_a611_4597_a79b_742c12cedfd6.slice/cri-containerd-d966b24f2a4f510604cd3201458d13482bcb078e9f33625e96138ea3ab6680da.scope
    690      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2339d3e3_a611_4597_a79b_742c12cedfd6.slice/cri-containerd-c292805e087655bdee00f75270cb0837b41fd2c5fed94a98a24f2a78a565c1f4.scope
    724      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5e30e11_38a7_40ed_8e18_592b6b952690.slice/cri-containerd-a29cd17919697c4edeceb651881601858006201e73bd7bb7cc4c0fb9c277bf0e.scope
    736      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5e30e11_38a7_40ed_8e18_592b6b952690.slice/cri-containerd-1eb47014f7fe97406274390dd144988736b03a8c1441105d1cfc837badadb072.scope
    732      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5e30e11_38a7_40ed_8e18_592b6b952690.slice/cri-containerd-3cfaa33736eeb4c87b937a0685a3605afc72930162279f885186bfd6f4ecee64.scope
    720      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6595f64f_e062_46ad_a392_d30846c685e8.slice/cri-containerd-6831585dba4f0b67901f113c36f557d14dae46409c93178b28816a7e447c74d2.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6595f64f_e062_46ad_a392_d30846c685e8.slice/cri-containerd-6aed8895efa44d35e51338365ab4993684fafad976f1eb216c848db3908abe57.scope
    87       cgroup_device   multi                                          
