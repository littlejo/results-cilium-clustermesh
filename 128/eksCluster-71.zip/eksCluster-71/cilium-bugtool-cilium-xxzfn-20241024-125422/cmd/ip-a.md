1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:8a:d7:99:29:7b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.232.106/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3475sec preferred_lft 3475sec
    inet6 fe80::88a:d7ff:fe99:297b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:0d:6a:e6:26:7b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.234.189/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::80d:6aff:fee6:267b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:af:ed:d9:47:b5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f0af:edff:fed9:47b5/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:8a:8d:6f:24:1a brd ff:ff:ff:ff:ff:ff
    inet 10.71.0.211/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::88a:8dff:fe6f:241a/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 46:d2:89:47:47:ac brd ff:ff:ff:ff:ff:ff
    inet6 fe80::44d2:89ff:fe47:47ac/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:50:48:16:ef:58 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::4050:48ff:fe16:ef58/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcef811ece23d5@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:2d:b6:b1:63:a8 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::702d:b6ff:feb1:63a8/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc95725eaeab12@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:1e:9b:df:c9:29 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b81e:9bff:fedf:c929/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc311ce434ee84@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:c8:e8:04:86:fb brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a4c8:e8ff:fe04:86fb/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc0ca3186213d3@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:c6:04:1d:6e:b7 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::58c6:4ff:fe1d:6eb7/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcec6917bbb41e@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:78:9b:59:96:07 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::2878:9bff:fe59:9607/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcc0bc5f28ab1b@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:99:54:af:46:9c brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::899:54ff:feaf:469c/64 scope link 
       valid_lft forever preferred_lft forever
