Node 0, zone      DMA      2     44     49     36     24     13      4      4      2      3     35 
Node 0, zone   Normal    143     95      8     16     19      7      4      2      2      1      8 
