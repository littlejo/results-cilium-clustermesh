[
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c0a7e0c_d4fd_46b4_b0f6_07871413f054.slice/cri-containerd-164cd5d8592642453970d8a8d2676b9ffd333ed3aca4e550dd6053db35480b82.scope"
      }
    ],
    "ips": [
      "10.71.0.210"
    ],
    "name": "coredns-cc6ccd49c-rsc5j",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5e30e11_38a7_40ed_8e18_592b6b952690.slice/cri-containerd-a29cd17919697c4edeceb651881601858006201e73bd7bb7cc4c0fb9c277bf0e.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5e30e11_38a7_40ed_8e18_592b6b952690.slice/cri-containerd-1eb47014f7fe97406274390dd144988736b03a8c1441105d1cfc837badadb072.scope"
      }
    ],
    "ips": [
      "10.71.0.139"
    ],
    "name": "echo-same-node-86d9cc975c-txmrd",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode254ea61_3522_476e_a211_fb7b73689568.slice/cri-containerd-53817bdbf3053ba130f0c37498549abb61183c1ff1b6dae0ec765f94b8fdcb26.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode254ea61_3522_476e_a211_fb7b73689568.slice/cri-containerd-11bf08b337644117657a8e574341d6b8ff28ec1863079ff73b8b0dbb49c8828d.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode254ea61_3522_476e_a211_fb7b73689568.slice/cri-containerd-0964024f9ba82d6d4215100b87bb48815aeb6976e23ff49c8a940af45a166fc0.scope"
      }
    ],
    "ips": [
      "10.71.0.90"
    ],
    "name": "clustermesh-apiserver-6d75f99f86-l2nvr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3bf28aa0_e746_434f_a129_71854fae4368.slice/cri-containerd-8a2d8f589ee017d840a69d5c8c70308eecc99378eedf8933b992aa508ad7a053.scope"
      }
    ],
    "ips": [
      "10.71.0.171"
    ],
    "name": "coredns-cc6ccd49c-7mfrf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode9dba7ca_276c_4a12_b7a2_1dc36a6ef5a5.slice/cri-containerd-3df6a98d8d225a249dc0f435ce19fc8b451fa3d3dfd4141b14f332deccc3ae83.scope"
      }
    ],
    "ips": [
      "10.71.0.1"
    ],
    "name": "client2-57cf4468f-mghdh",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2339d3e3_a611_4597_a79b_742c12cedfd6.slice/cri-containerd-c292805e087655bdee00f75270cb0837b41fd2c5fed94a98a24f2a78a565c1f4.scope"
      }
    ],
    "ips": [
      "10.71.0.130"
    ],
    "name": "client-974f6c69d-6s8xn",
    "namespace": "cilium-test-1"
  }
]

