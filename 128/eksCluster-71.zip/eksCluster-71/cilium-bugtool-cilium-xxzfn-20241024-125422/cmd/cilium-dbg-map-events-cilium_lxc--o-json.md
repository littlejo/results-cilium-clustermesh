{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.410Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.421Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.465Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.478Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.508Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.734Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.758Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.852Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.926Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.933Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.556Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.580Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.630Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.640Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.677Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.911Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.934Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.015Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.033Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.068Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.594Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.602Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.643Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.671Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.722Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.736Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.760Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.981Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.992Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.041Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.087Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.152Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.675Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.719Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.744Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.804Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.812Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.843Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.091Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.112Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.153Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.174Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.206Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.497Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.556Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.566Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.611Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.618Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.650Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.886Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.901Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.964Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.971Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.008Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.453Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.460Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.550Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.564Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.588Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.814Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.831Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.856Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.899Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.929Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.313Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.343Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.364Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.398Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.398Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.414Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.662Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.691Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.733Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.763Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.784Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.192Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.222Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.249Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.286Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.287Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.300Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.568Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.577Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.679Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.730Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.749Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.084Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.153Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.167Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.208Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.231Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.255Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.462Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.481Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.529Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.554Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.574Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.910Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.951Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.979Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.015Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.023Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.075Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.298Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.303Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.363Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.374Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.411Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.726Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.786Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.834Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.886Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.887Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.909Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.109Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.121Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.138Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.142Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.164Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.856Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.859Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.919Z",
  "value": "id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.960Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.961Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.240Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.265Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.986Z",
  "value": "id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.986Z",
  "value": "id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07"
}

