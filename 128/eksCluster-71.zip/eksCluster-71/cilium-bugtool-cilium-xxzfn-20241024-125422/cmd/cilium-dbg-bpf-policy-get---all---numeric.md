Endpoint ID: 45
Path: /sys/fs/bpf/tc/globals/cilium_policy_00045

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 440
Path: /sys/fs/bpf/tc/globals/cilium_policy_00440

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2246     24        0        
Allow    Ingress     1          ANY          NONE         disabled    145378   1674      0        
Allow    Egress      0          ANY          NONE         disabled    20022    223       0        


Endpoint ID: 1014
Path: /sys/fs/bpf/tc/globals/cilium_policy_01014

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6250210   77283     0        
Allow    Ingress     1          ANY          NONE         disabled    63742     773       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1856
Path: /sys/fs/bpf/tc/globals/cilium_policy_01856

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2354
Path: /sys/fs/bpf/tc/globals/cilium_policy_02354

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378324   4412      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2527
Path: /sys/fs/bpf/tc/globals/cilium_policy_02527

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3650     36        0        
Allow    Ingress     1          ANY          NONE         disabled    145048   1669      0        
Allow    Egress      0          ANY          NONE         disabled    20497    229       0        


Endpoint ID: 3730
Path: /sys/fs/bpf/tc/globals/cilium_policy_03730

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6140694   61758     0        
Allow    Ingress     1          ANY          NONE         disabled    5287396   55766     0        
Allow    Egress      0          ANY          NONE         disabled    6776694   67073     0        


Endpoint ID: 4002
Path: /sys/fs/bpf/tc/globals/cilium_policy_04002

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


