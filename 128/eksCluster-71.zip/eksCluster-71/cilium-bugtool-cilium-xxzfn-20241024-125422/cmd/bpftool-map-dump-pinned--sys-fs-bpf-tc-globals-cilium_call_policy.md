key: b8 01 00 00  value: 11 02 00 00
key: f6 03 00 00  value: 43 02 00 00
key: 40 07 00 00  value: ff 0c 00 00
key: 32 09 00 00  value: ca 0c 00 00
key: df 09 00 00  value: 10 02 00 00
key: 92 0e 00 00  value: 87 02 00 00
key: a2 0f 00 00  value: fd 0c 00 00
Found 7 elements
