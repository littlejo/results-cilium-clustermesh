KEY             VALUE
AgentLiveness   1965400261688
UTimeOffset     3378461970703125
