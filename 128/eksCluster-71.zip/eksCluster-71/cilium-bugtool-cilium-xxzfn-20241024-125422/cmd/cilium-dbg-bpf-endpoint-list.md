IP ADDRESS         LOCAL ENDPOINT INFO
10.71.0.1:0        id=4002  sec_id=4724289 flags=0x0000 ifindex=22  mac=0E:1C:E0:17:DF:AC nodemac=2A:78:9B:59:96:07   
172.31.234.189:0   (localhost)                                                                                        
10.71.0.90:0       id=3730  sec_id=4760593 flags=0x0000 ifindex=18  mac=E6:27:47:FF:82:CF nodemac=A6:C8:E8:04:86:FB   
10.71.0.211:0      (localhost)                                                                                        
10.71.0.144:0      id=1014  sec_id=4     flags=0x0000 ifindex=10  mac=B2:6E:4C:38:1B:3D nodemac=42:50:48:16:EF:58     
172.31.232.106:0   (localhost)                                                                                        
10.71.0.130:0      id=1856  sec_id=4782901 flags=0x0000 ifindex=20  mac=56:9F:CD:14:E4:EF nodemac=5A:C6:04:1D:6E:B7   
10.71.0.139:0      id=2354  sec_id=4720537 flags=0x0000 ifindex=24  mac=36:21:51:E2:20:AC nodemac=0A:99:54:AF:46:9C   
10.71.0.171:0      id=440   sec_id=4735951 flags=0x0000 ifindex=12  mac=3A:2B:37:D1:A4:54 nodemac=72:2D:B6:B1:63:A8   
10.71.0.210:0      id=2527  sec_id=4735951 flags=0x0000 ifindex=14  mac=AE:46:CB:76:44:A1 nodemac=BA:1E:9B:DF:C9:29   
