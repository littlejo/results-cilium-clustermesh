{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.959Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.033Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.160Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.206Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.389Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.395Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.454Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.473Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.493Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.144Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.145Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.197Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.220Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.246Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.268Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.283Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.515Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.526Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.591Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.617Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.637Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.173Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.177Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.215Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.230Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.271Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.322Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.324Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.568Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.582Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.712Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.716Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.762Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.310Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.323Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.350Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.365Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.403Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.405Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.436Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.674Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.700Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.745Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.757Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.790Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.179Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.186Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.232Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.248Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.274Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.509Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.511Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.572Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.583Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.625Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.038Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.073Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.077Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.124Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.144Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.159Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.376Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.386Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.433Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.462Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.478Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.834Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.863Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.879Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.910Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.953Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.957Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.206Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.220Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.265Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.282Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.322Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.675Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.703Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.730Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.759Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.759Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.767Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.035Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.035Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.091Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.093Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.144Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.512Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.539Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.567Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.592Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.616Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.631Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.869Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.873Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.935Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.948Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.975Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.290Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.376Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.412Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.439Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.472Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.691Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.695Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.749Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.755Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.791Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.063Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.106Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.109Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.156Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.157Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.169Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.426Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.439Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.449Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.482Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.190Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.193Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.227Z",
  "value": "id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.237Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.268Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.562Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.567Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.182Z",
  "value": "id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.188Z",
  "value": "id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75"
}

