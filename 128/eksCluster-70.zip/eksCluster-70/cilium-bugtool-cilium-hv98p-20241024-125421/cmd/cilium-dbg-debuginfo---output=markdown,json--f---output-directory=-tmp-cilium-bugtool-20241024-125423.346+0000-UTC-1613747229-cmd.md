markdown output at /tmp/cilium-bugtool-20241024-125423.346+0000-UTC-1613747229/cmd/cilium-debuginfo-20241024-125454.066+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125423.346+0000-UTC-1613747229/cmd/cilium-debuginfo-20241024-125454.066+0000-UTC.json
