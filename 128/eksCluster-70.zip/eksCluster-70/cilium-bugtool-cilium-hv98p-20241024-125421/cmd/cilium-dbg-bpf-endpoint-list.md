IP ADDRESS        LOCAL ENDPOINT INFO
10.70.0.183:0     id=169   sec_id=4     flags=0x0000 ifindex=10  mac=E6:D8:23:8C:1D:6A nodemac=52:4B:87:DD:06:E7     
10.70.0.139:0     (localhost)                                                                                        
10.70.0.236:0     id=2314  sec_id=4653104 flags=0x0000 ifindex=12  mac=BA:33:6D:08:29:E2 nodemac=06:74:7D:65:C4:29   
172.31.157.29:0   (localhost)                                                                                        
10.70.0.113:0     id=1432  sec_id=4690407 flags=0x0000 ifindex=22  mac=AA:B2:27:3F:AB:02 nodemac=BE:A9:32:E7:54:75   
10.70.0.11:0      id=2986  sec_id=4659464 flags=0x0000 ifindex=20  mac=B6:94:BF:6A:86:F8 nodemac=5A:52:D6:9F:BA:EA   
10.70.0.238:0     id=3327  sec_id=4653104 flags=0x0000 ifindex=14  mac=EA:C3:E1:81:49:99 nodemac=92:8C:27:84:9A:B5   
10.70.0.32:0      id=3302  sec_id=4717228 flags=0x0000 ifindex=18  mac=32:E9:5C:39:D3:FD nodemac=B6:B8:F7:E7:67:D7   
10.70.0.39:0      id=3621  sec_id=4683353 flags=0x0000 ifindex=24  mac=1E:2B:7D:C2:48:A4 nodemac=BE:21:C3:03:C7:F1   
172.31.151.89:0   (localhost)                                                                                        
