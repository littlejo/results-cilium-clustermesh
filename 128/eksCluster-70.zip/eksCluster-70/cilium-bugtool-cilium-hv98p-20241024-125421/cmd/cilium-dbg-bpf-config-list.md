KEY             VALUE
AgentLiveness   1958626466546
UTimeOffset     3378461982421875
