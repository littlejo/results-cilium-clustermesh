CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podba465447_1291_4ad6_a17a_00ef0f81ad6b.slice/cri-containerd-5b29634f3ff00836986fb6e338542ac4dc159515d448b901f37431874c4e3026.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podba465447_1291_4ad6_a17a_00ef0f81ad6b.slice/cri-containerd-54f245f66c6a71b4da08738e2d0318ce361d9fb32e33c038b4b6370e217014e0.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddd2c763d_3aaf_4c79_b6c9_21c008f851e5.slice/cri-containerd-918d696a6e0676b9e71b3db72e9645fe8407c2b2ef9c032b9417c4c77b8ff0c8.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddd2c763d_3aaf_4c79_b6c9_21c008f851e5.slice/cri-containerd-a78a175231fc20f8d87c0c0b7d9f6d8fc1cbd52e85ee719aef555da0185af559.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod366b286c_1048_4e20_872d_c611db0b9d68.slice/cri-containerd-605b99d116847a687884cc60b0dc849095ebf3fa8a290caf93a3ea80ec85dc5f.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod366b286c_1048_4e20_872d_c611db0b9d68.slice/cri-containerd-353a6c69fa1b7b57f54f6d0fc16508969897f7dc33096d7370df4a160d3b4af3.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod17b88041_e498_4b47_a050_ffd39e36ec31.slice/cri-containerd-d8d92a734813daf114d04adbc7a38e48c190518285cb1c5c455c8e40dfd9f4b8.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod17b88041_e498_4b47_a050_ffd39e36ec31.slice/cri-containerd-d369df43e0d131e8380940e22ea1f0713e49a833a11e7af4c80ccaf60793a1b2.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod09a32ef0_0d3c_4658_97c6_90698cec0b9a.slice/cri-containerd-b64067ebb112b5ddba7f976e362d9612f290096a470d59415a615c8c510fe32a.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod09a32ef0_0d3c_4658_97c6_90698cec0b9a.slice/cri-containerd-ce5429a6d7eb39cbe0672cb0f76bbd155c1d865dddc61be8b6df44afd55531bf.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod118d330a_2737_4b68_a34f_e9c9d83468fc.slice/cri-containerd-7dc88bf6bb1c7d430e0f83afd6e6e72dacd7ffa5b5ddd55d013f031f632497b2.scope
    734      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod118d330a_2737_4b68_a34f_e9c9d83468fc.slice/cri-containerd-33e6419b0a343745c34fe1aa62c0f6326f31f2411b64696bb5fd7ad0797eba89.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podba55791a_f86e_4a9b_a779_985bc05d72e5.slice/cri-containerd-b7120a610831337eee31f89aef974b5ac457280c219f4d0c11093320147e87ad.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podba55791a_f86e_4a9b_a779_985bc05d72e5.slice/cri-containerd-c5fed249e8d878b128f3b5a1d0a11ebde83764fb9fd4abab1dc9739a74fc1e69.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf00162c6_4733_4b94_8448_1e5a39652ef4.slice/cri-containerd-f38777505c4f45cf7d4819e3f80b52a04bb27c7a26d0a750681bc7b4a59dec46.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf00162c6_4733_4b94_8448_1e5a39652ef4.slice/cri-containerd-303d50ae5d1651ba1416a09b4183d8f5533edc80f138a892f41f0da15a9ea853.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfae64bd7_4f92_4cbd_861c_b6086fb26d30.slice/cri-containerd-a0c6e39103737b5480d437a8f9f102c20f90ae059e421885c5d26269d65f5d4c.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfae64bd7_4f92_4cbd_861c_b6086fb26d30.slice/cri-containerd-68351f360edcc1c4dfa136e00634401c79962a3cd740ccfaf303ae07aed8fe65.scope
    738      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfae64bd7_4f92_4cbd_861c_b6086fb26d30.slice/cri-containerd-bfec10f5ef62f443cb820b4ba7a8ea730caf141a3a9a4dc45bb6173a3e92fc86.scope
    742      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef40d035_0507_4f6a_9150_b7d918b35777.slice/cri-containerd-1bdde112cc055b404a2a5027899bae32796eceddc308766a20a163363552281b.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef40d035_0507_4f6a_9150_b7d918b35777.slice/cri-containerd-94a655da13016eef7b81835a11e22f8e6eabe37f1fb2ce3a5db0ba46eac66c42.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef40d035_0507_4f6a_9150_b7d918b35777.slice/cri-containerd-bb060ca36559b13f65782c9e10bd301d8f5fca28de1c531b67747fa15b32a936.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef40d035_0507_4f6a_9150_b7d918b35777.slice/cri-containerd-0ec4aef96bf4d280285076b6bcbddcfe0758d793c3cf47c2c86382686dbb0e62.scope
    677      cgroup_device   multi                                          
