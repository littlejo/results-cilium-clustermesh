Node 0, zone      DMA    128    162     62     42     58    104     19      6      0      3     37 
Node 0, zone   Normal      2      0      2      2      2      1      2      4      3      4      7 
