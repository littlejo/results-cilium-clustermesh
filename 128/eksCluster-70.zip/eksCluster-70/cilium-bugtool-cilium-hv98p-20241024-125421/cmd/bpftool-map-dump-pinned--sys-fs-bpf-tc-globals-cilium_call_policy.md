key: a9 00 00 00  value: 39 02 00 00
key: 98 05 00 00  value: 0d 0d 00 00
key: 0a 09 00 00  value: 14 02 00 00
key: aa 0b 00 00  value: 06 0d 00 00
key: e6 0c 00 00  value: 83 02 00 00
key: ff 0c 00 00  value: 3d 02 00 00
key: 25 0e 00 00  value: cb 0c 00 00
Found 7 elements
