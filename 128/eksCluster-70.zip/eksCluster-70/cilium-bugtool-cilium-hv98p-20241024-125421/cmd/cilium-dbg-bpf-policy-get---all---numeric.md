Endpoint ID: 169
Path: /sys/fs/bpf/tc/globals/cilium_policy_00169

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6241408   77162     0        
Allow    Ingress     1          ANY          NONE         disabled    63850     770       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1432
Path: /sys/fs/bpf/tc/globals/cilium_policy_01432

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2314
Path: /sys/fs/bpf/tc/globals/cilium_policy_02314

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3272     32        0        
Allow    Ingress     1          ANY          NONE         disabled    144190   1656      0        
Allow    Egress      0          ANY          NONE         disabled    19905    222       0        


Endpoint ID: 2986
Path: /sys/fs/bpf/tc/globals/cilium_policy_02986

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3302
Path: /sys/fs/bpf/tc/globals/cilium_policy_03302

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6135181   61962     0        
Allow    Ingress     1          ANY          NONE         disabled    6095406   62925     0        
Allow    Egress      0          ANY          NONE         disabled    7200423   70674     0        


Endpoint ID: 3327
Path: /sys/fs/bpf/tc/globals/cilium_policy_03327

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2624     28        0        
Allow    Ingress     1          ANY          NONE         disabled    144850   1666      0        
Allow    Egress      0          ANY          NONE         disabled    20581    229       0        


Endpoint ID: 3621
Path: /sys/fs/bpf/tc/globals/cilium_policy_03621

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    382468   4476      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3999
Path: /sys/fs/bpf/tc/globals/cilium_policy_03999

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


