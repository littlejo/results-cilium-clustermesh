REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     133842    10849890    677    bpf_overlay.c
Interface                   INGRESS     689773    249562056   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      134592    10904247    53     encap.h
Success                     EGRESS      160686    21208855    1308   bpf_lxc.c
Success                     EGRESS      57349     4653904     1694   bpf_host.c
Success                     EGRESS      596       156261      86     l3.h
Success                     INGRESS     185643    21454637    86     l3.h
Success                     INGRESS     263363    27849354    235    trace.h
Unsupported L3 protocol     EGRESS      72        5424        1492   bpf_lxc.c
