xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 557
ens6(5) clsact/ingress cil_from_netdev-ens6 id 564
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 550
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 541
cilium_host(7) clsact/egress cil_from_host-cilium_host id 540
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 587
lxcd22b64652313(12) clsact/ingress cil_from_container-lxcd22b64652313 id 534
lxcbdb3ea19d0bb(14) clsact/ingress cil_from_container-lxcbdb3ea19d0bb id 575
lxc85302f00547c(18) clsact/ingress cil_from_container-lxc85302f00547c id 647
lxc1531da846982(20) clsact/ingress cil_from_container-lxc1531da846982 id 3338
lxc6772929dd885(22) clsact/ingress cil_from_container-lxc6772929dd885 id 3349
lxc829cdee04576(24) clsact/ingress cil_from_container-lxc829cdee04576 id 3286

flow_dissector:

netfilter:

