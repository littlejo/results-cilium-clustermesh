35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:17+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:17+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:18+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:18+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:18+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:18+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:22+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:34+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name tail_handle_ipv4  tag 02e2057ac24461a7  gpl
	loaded_at 2024-10-24T12:29:41+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
485: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:29:41+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
486: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:29:41+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
487: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:29:41+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
516: sched_cls  name tail_handle_ipv4_cont  tag 55d35e0bd47b8b87  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,111,41,109,82,83,39,76,74,77,110,40,37,38,81
	btf_id 161
517: sched_cls  name __send_drop_notify  tag 44f9273d7ce29714  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 162
519: sched_cls  name tail_ipv4_ct_egress  tag fea57181845f6648  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,111,84
	btf_id 163
520: sched_cls  name tail_ipv4_ct_ingress  tag 62030dbb02acc1ab  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,111,84
	btf_id 167
523: sched_cls  name tail_ipv4_to_endpoint  tag 58109e473197b210  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,111,41,82,83,80,109,39,110,40,37,38
	btf_id 168
524: sched_cls  name tail_handle_ipv4  tag 1ef692f99a6afc60  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 171
525: sched_cls  name tail_handle_arp  tag fd43aeb488f47568  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 172
532: sched_cls  name handle_policy  tag 6e76c493028e7d1b  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,110,82,83,111,41,80,109,39,84,75,40,37,38
	btf_id 173
533: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 180
534: sched_cls  name cil_from_container  tag ae39bc4d31d1ec30  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 110,76
	btf_id 181
538: sched_cls  name tail_handle_ipv4_from_host  tag d3b39382f2596bae  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,115
	btf_id 185
540: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,115
	btf_id 187
541: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 188
542: sched_cls  name __send_drop_notify  tag b4ece1c58e2d601b  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 189
543: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,115
	btf_id 190
545: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 193
547: sched_cls  name tail_handle_ipv4_from_host  tag d3b39382f2596bae  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 195
550: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 198
551: sched_cls  name __send_drop_notify  tag b4ece1c58e2d601b  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
552: sched_cls  name __send_drop_notify  tag b4ece1c58e2d601b  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
553: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 204
555: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,121
	btf_id 202
556: sched_cls  name tail_handle_ipv4_from_host  tag d3b39382f2596bae  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 206
557: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,119,75
	btf_id 208
560: sched_cls  name __send_drop_notify  tag b4ece1c58e2d601b  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 212
561: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 213
563: sched_cls  name tail_handle_ipv4_from_host  tag d3b39382f2596bae  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 215
564: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 216
567: sched_cls  name tail_handle_ipv4  tag 535d563c42a983d1  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,121
	btf_id 207
568: sched_cls  name tail_handle_ipv4_cont  tag c0fca2b3bea8dba8  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,122,41,114,82,83,39,76,74,77,121,40,37,38,81
	btf_id 221
569: sched_cls  name handle_policy  tag 69768c83c634ca27  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,126,82,83,125,41,80,100,39,84,75,40,37,38
	btf_id 220
570: sched_cls  name tail_handle_ipv4  tag 835c3007cb54c5c2  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,126
	btf_id 223
572: sched_cls  name tail_handle_ipv4_cont  tag a669dc16442869c4  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,125,41,100,82,83,39,76,74,77,126,40,37,38,81
	btf_id 225
573: sched_cls  name handle_policy  tag 544d1ee5445c873c  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,121,82,83,122,41,80,114,39,84,75,40,37,38
	btf_id 222
574: sched_cls  name tail_ipv4_to_endpoint  tag 9534dce9fd26b4c1  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,122,41,82,83,80,114,39,121,40,37,38
	btf_id 226
575: sched_cls  name cil_from_container  tag c0122179917cef35  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 121,76
	btf_id 228
576: sched_cls  name tail_ipv4_ct_ingress  tag 9dfa38c84495c628  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 227
577: sched_cls  name tail_ipv4_ct_ingress  tag 11e72d3294eedd22  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,121,82,83,122,84
	btf_id 229
578: sched_cls  name tail_handle_arp  tag 740a2e34a98c2f50  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,121
	btf_id 231
579: sched_cls  name tail_ipv4_ct_egress  tag fea57181845f6648  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,121,82,83,122,84
	btf_id 232
580: sched_cls  name __send_drop_notify  tag 8386e25b2f42d008  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 233
582: sched_cls  name tail_ipv4_to_endpoint  tag 62fb7557e9ab8314  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,125,41,82,83,80,100,39,126,40,37,38
	btf_id 230
583: sched_cls  name __send_drop_notify  tag 221a640ab9f79140  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 235
584: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,126
	btf_id 236
585: sched_cls  name tail_handle_arp  tag ca3120578ef908fe  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,126
	btf_id 237
586: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 238
587: sched_cls  name cil_from_container  tag fd2d3a44a5c7ba7e  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 126,76
	btf_id 239
588: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
591: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
592: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
595: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
596: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
599: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
643: sched_cls  name handle_policy  tag c2e739e319bac037  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 253
644: sched_cls  name tail_ipv4_ct_egress  tag 0981c7609d79f866  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 254
646: sched_cls  name tail_handle_ipv4_cont  tag abec9bd48e217970  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 256
647: sched_cls  name cil_from_container  tag 694636a4202f1222  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 257
648: sched_cls  name tail_ipv4_to_endpoint  tag cfb66042cddc4b61  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 258
649: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 259
650: sched_cls  name tail_ipv4_ct_ingress  tag b890a5216ad7a0ea  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 260
651: sched_cls  name tail_handle_ipv4  tag 1e388d9d10b47a35  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 261
652: sched_cls  name tail_handle_arp  tag 06218bf3c78ce65e  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 262
653: sched_cls  name __send_drop_notify  tag d3b138f7068ccb5d  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 263
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
670: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
673: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
674: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
677: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
678: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
681: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
704: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
707: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
708: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
711: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
723: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
726: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
727: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
730: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
731: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
734: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
735: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
738: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
739: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
742: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3273: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,628
	btf_id 3061
3275: sched_cls  name handle_policy  tag 1f332c52dd8d30c9  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,628,82,83,627,41,80,159,39,84,75,40,37,38
	btf_id 3063
3277: sched_cls  name tail_handle_arp  tag f1c1733e38476c91  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,628
	btf_id 3066
3278: sched_cls  name tail_ipv4_ct_ingress  tag 1ab6095a2bc603af  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,628,82,83,627,84
	btf_id 3068
3280: sched_cls  name tail_handle_ipv4_cont  tag 1991c14db47dabc1  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,627,41,159,82,83,39,76,74,77,628,40,37,38,81
	btf_id 3069
3281: sched_cls  name tail_ipv4_ct_egress  tag 35003a6d25954f80  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,628,82,83,627,84
	btf_id 3070
3282: sched_cls  name __send_drop_notify  tag f471728510496285  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3072
3285: sched_cls  name tail_ipv4_to_endpoint  tag d5dd9fc00fc9dff1  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,627,41,82,83,80,159,39,628,40,37,38
	btf_id 3074
3286: sched_cls  name cil_from_container  tag a7667b633211c0cb  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 628,76
	btf_id 3076
3290: sched_cls  name tail_handle_ipv4  tag 5d4b96d79afda68c  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,628
	btf_id 3077
3328: sched_cls  name tail_handle_arp  tag baa8ba6a6b2ac93e  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,639
	btf_id 3123
3329: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,638
	btf_id 3121
3330: sched_cls  name tail_handle_arp  tag 1cf0278813e8715f  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,638
	btf_id 3124
3332: sched_cls  name tail_handle_ipv4_cont  tag 8cc57c3f4062d53c  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,640,41,154,82,83,39,76,74,77,639,40,37,38,81
	btf_id 3125
3334: sched_cls  name handle_policy  tag 2be7480fe8fe4456  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,638,82,83,637,41,80,151,39,84,75,40,37,38
	btf_id 3127
3335: sched_cls  name tail_ipv4_to_endpoint  tag 60b98a065cafdc7e  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,640,41,82,83,80,154,39,639,40,37,38
	btf_id 3129
3336: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,639
	btf_id 3131
3337: sched_cls  name tail_ipv4_ct_egress  tag aa779632d2f5cc81  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,637,84
	btf_id 3130
3338: sched_cls  name cil_from_container  tag 49266d7d842fa1fd  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 638,76
	btf_id 3133
3339: sched_cls  name tail_ipv4_ct_ingress  tag 2fca7daa9223a436  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3132
3340: sched_cls  name tail_ipv4_to_endpoint  tag ae3641025886d91e  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,637,41,82,83,80,151,39,638,40,37,38
	btf_id 3134
3341: sched_cls  name handle_policy  tag 42ee4f651b8ee297  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,639,82,83,640,41,80,154,39,84,75,40,37,38
	btf_id 3135
3342: sched_cls  name tail_handle_ipv4  tag 3cc9f303e73b67b6  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,638
	btf_id 3136
3343: sched_cls  name __send_drop_notify  tag 8436969da3ed5a7b  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3138
3344: sched_cls  name tail_ipv4_ct_egress  tag 2e0ed58cec9f8f35  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3137
3345: sched_cls  name tail_ipv4_ct_ingress  tag 1df26942857a92f3  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,637,84
	btf_id 3139
3346: sched_cls  name tail_handle_ipv4_cont  tag 94b73902be2ed0c9  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,637,41,151,82,83,39,76,74,77,638,40,37,38,81
	btf_id 3141
3347: sched_cls  name tail_handle_ipv4  tag b8dd1ec338bf7b91  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,639
	btf_id 3140
3348: sched_cls  name __send_drop_notify  tag 87ddd97469f8329d  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3142
3349: sched_cls  name cil_from_container  tag e681b65a0e30930f  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 639,76
	btf_id 3143
