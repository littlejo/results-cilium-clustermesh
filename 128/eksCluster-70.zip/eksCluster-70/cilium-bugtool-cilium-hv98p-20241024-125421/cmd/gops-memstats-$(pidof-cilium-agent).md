alloc: 112.19MB (117638592 bytes)
total-alloc: 3.20GB (3436041880 bytes)
sys: 227.39MB (238437716 bytes)
lookups: 0
mallocs: 76826567
frees: 75684958
heap-alloc: 112.19MB (117638592 bytes)
heap-sys: 178.27MB (186925056 bytes)
heap-idle: 40.13MB (42082304 bytes)
heap-in-use: 138.13MB (144842752 bytes)
heap-released: 7.34MB (7700480 bytes)
heap-objects: 1141609
stack-in-use: 37.69MB (39518208 bytes)
stack-sys: 37.69MB (39518208 bytes)
stack-mspan-inuse: 2.27MB (2376480 bytes)
stack-mspan-sys: 2.83MB (2970240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 988.70KB (1012425 bytes)
gc-sys: 5.52MB (5792816 bytes)
next-gc: when heap-alloc >= 150.83MB (158152968 bytes)
last-gc: 2024-10-24 12:54:27.415310545 +0000 UTC
gc-pause-total: 20.559387ms
gc-pause: 63648
gc-pause-end: 1729774467415310545
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.000648953736455845
enable-gc: true
debug-gc: false
