top - 12:54:23 up 32 min,  0 users,  load average: 0.19, 0.44, 0.36
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 16.1 us, 25.8 sy,  0.0 ni, 58.1 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    270.1 free,   1069.5 used,   2496.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2585.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539132 302620  78592 S   6.7   7.7   1:08.96 cilium-+
   3230 root      20   0 1240432  15956  10704 S   6.7   0.4   0:00.03 cilium-+
    417 root      20   0 1229744  10004   3836 S   0.0   0.3   0:04.31 cilium-+
   3221 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3229 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3231 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   3285 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3303 root      20   0 1228744   3712   3040 S   0.0   0.1   0:00.00 gops
