[
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfae64bd7_4f92_4cbd_861c_b6086fb26d30.slice/cri-containerd-bfec10f5ef62f443cb820b4ba7a8ea730caf141a3a9a4dc45bb6173a3e92fc86.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfae64bd7_4f92_4cbd_861c_b6086fb26d30.slice/cri-containerd-68351f360edcc1c4dfa136e00634401c79962a3cd740ccfaf303ae07aed8fe65.scope"
      }
    ],
    "ips": [
      "10.70.0.39"
    ],
    "name": "echo-same-node-86d9cc975c-8pq5t",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef40d035_0507_4f6a_9150_b7d918b35777.slice/cri-containerd-bb060ca36559b13f65782c9e10bd301d8f5fca28de1c531b67747fa15b32a936.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef40d035_0507_4f6a_9150_b7d918b35777.slice/cri-containerd-0ec4aef96bf4d280285076b6bcbddcfe0758d793c3cf47c2c86382686dbb0e62.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef40d035_0507_4f6a_9150_b7d918b35777.slice/cri-containerd-94a655da13016eef7b81835a11e22f8e6eabe37f1fb2ce3a5db0ba46eac66c42.scope"
      }
    ],
    "ips": [
      "10.70.0.32"
    ],
    "name": "clustermesh-apiserver-849c6ccff7-59fws",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddd2c763d_3aaf_4c79_b6c9_21c008f851e5.slice/cri-containerd-a78a175231fc20f8d87c0c0b7d9f6d8fc1cbd52e85ee719aef555da0185af559.scope"
      }
    ],
    "ips": [
      "10.70.0.236"
    ],
    "name": "coredns-cc6ccd49c-mq6n6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod17b88041_e498_4b47_a050_ffd39e36ec31.slice/cri-containerd-d8d92a734813daf114d04adbc7a38e48c190518285cb1c5c455c8e40dfd9f4b8.scope"
      }
    ],
    "ips": [
      "10.70.0.238"
    ],
    "name": "coredns-cc6ccd49c-vmq6p",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod118d330a_2737_4b68_a34f_e9c9d83468fc.slice/cri-containerd-7dc88bf6bb1c7d430e0f83afd6e6e72dacd7ffa5b5ddd55d013f031f632497b2.scope"
      }
    ],
    "ips": [
      "10.70.0.113"
    ],
    "name": "client2-57cf4468f-5wgrz",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podba55791a_f86e_4a9b_a779_985bc05d72e5.slice/cri-containerd-b7120a610831337eee31f89aef974b5ac457280c219f4d0c11093320147e87ad.scope"
      }
    ],
    "ips": [
      "10.70.0.11"
    ],
    "name": "client-974f6c69d-8wg5r",
    "namespace": "cilium-test-1"
  }
]

