32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:07+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:07+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:08+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:08+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:08+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:08+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:12+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:23+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:29:31+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
482: sched_cls  name tail_handle_ipv4  tag e8cc2bfb1c5156e3  gpl
	loaded_at 2024-10-24T12:29:31+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
483: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:29:31+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
484: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:29:31+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
486: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 130
487: sched_cls  name __send_drop_notify  tag 488a899e2d01d52b  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 131
488: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,102
	btf_id 132
489: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,102
	btf_id 133
491: sched_cls  name tail_handle_ipv4_from_host  tag 10c2febe3ed8a073  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,102
	btf_id 135
494: sched_cls  name tail_handle_ipv4_from_host  tag 10c2febe3ed8a073  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,104
	btf_id 139
496: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 141
497: sched_cls  name __send_drop_notify  tag 488a899e2d01d52b  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 142
498: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,104
	btf_id 143
499: sched_cls  name __send_drop_notify  tag 488a899e2d01d52b  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 145
500: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,106
	btf_id 146
502: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,106,75
	btf_id 148
503: sched_cls  name tail_handle_ipv4_from_host  tag 10c2febe3ed8a073  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,106
	btf_id 149
506: sched_cls  name __send_drop_notify  tag 488a899e2d01d52b  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 153
507: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,108
	btf_id 154
509: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,108,75
	btf_id 156
510: sched_cls  name tail_handle_ipv4_from_host  tag 10c2febe3ed8a073  gpl
	loaded_at 2024-10-24T12:29:33+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,108
	btf_id 157
513: sched_cls  name tail_ipv4_ct_ingress  tag ea200a16cb87db89  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 162
514: sched_cls  name tail_handle_arp  tag 456e4d73aabf9e8f  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 164
515: sched_cls  name tail_handle_ipv4_cont  tag dae5318f4b69f300  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 165
518: sched_cls  name handle_policy  tag 53b2dc66b2082c8c  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 166
522: sched_cls  name __send_drop_notify  tag de3b313b162c591f  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 171
523: sched_cls  name tail_ipv4_ct_egress  tag 98f01cd5534f99da  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 172
524: sched_cls  name cil_from_container  tag 7b0e75e52c0c006c  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 174
526: sched_cls  name tail_handle_ipv4  tag 5fcc1c8b916c6b18  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 175
530: sched_cls  name tail_ipv4_to_endpoint  tag 3864670f13daaea6  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 177
532: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 181
535: sched_cls  name tail_handle_ipv4_cont  tag d24c2a3cc2c5138a  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 185
537: sched_cls  name tail_ipv4_ct_egress  tag 98f01cd5534f99da  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 189
538: sched_cls  name cil_from_container  tag 917b79e427f45d35  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 190
539: sched_cls  name __send_drop_notify  tag e2bb13320d1c1e17  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 191
540: sched_cls  name tail_handle_ipv4  tag d6d7cc16ab239d6a  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 192
541: sched_cls  name tail_ipv4_ct_ingress  tag 1d58bd1ca5ad7d7e  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 193
542: sched_cls  name tail_ipv4_to_endpoint  tag 33c523826f4eea35  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,117,41,82,83,80,100,39,118,40,37,38
	btf_id 188
543: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,118
	btf_id 195
544: sched_cls  name cil_from_container  tag 8fd85c44fe79b40e  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 118,76
	btf_id 196
545: sched_cls  name tail_handle_arp  tag 63fb8c374742e10f  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,118
	btf_id 197
547: sched_cls  name __send_drop_notify  tag 237263a0db1836a9  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
548: sched_cls  name tail_handle_ipv4  tag ff48c80c07f65d22  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,118
	btf_id 200
549: sched_cls  name tail_ipv4_ct_ingress  tag 00661689baa078f7  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 201
550: sched_cls  name tail_handle_ipv4_cont  tag 47f1e223a188d0b2  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,117,41,100,82,83,39,76,74,77,118,40,37,38,81
	btf_id 202
551: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 203
552: sched_cls  name handle_policy  tag 7de6d10091d32f48  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 194
553: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 205
554: sched_cls  name tail_handle_arp  tag a1d07d74be2b53f5  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 206
555: sched_cls  name handle_policy  tag 28939b5e306cfdb2  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,118,82,83,117,41,80,100,39,84,75,40,37,38
	btf_id 204
556: sched_cls  name tail_ipv4_to_endpoint  tag b52046de8eebdb46  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 207
557: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
560: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
561: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
564: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
565: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
568: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
569: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
572: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
612: sched_cls  name handle_policy  tag 1386d0f3758e08ab  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,135,82,83,134,41,80,133,39,84,75,40,37,38
	btf_id 221
614: sched_cls  name __send_drop_notify  tag 567df280e7e0012e  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 223
615: sched_cls  name cil_from_container  tag 23cb7ba98e18687f  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 135,76
	btf_id 224
616: sched_cls  name tail_ipv4_ct_ingress  tag 2893b0e9acb7b706  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 225
617: sched_cls  name tail_handle_ipv4_cont  tag 09346b3004ec4ab5  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,134,41,133,82,83,39,76,74,77,135,40,37,38,81
	btf_id 226
618: sched_cls  name tail_handle_ipv4  tag 61f6e1b77a0b6fbf  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,135
	btf_id 227
619: sched_cls  name tail_ipv4_ct_egress  tag 09d313ef82ed544a  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 228
620: sched_cls  name tail_ipv4_to_endpoint  tag 477169e2b876d148  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,134,41,82,83,80,133,39,135,40,37,38
	btf_id 229
621: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,135
	btf_id 230
622: sched_cls  name tail_handle_arp  tag 44553ed56d2b6184  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,135
	btf_id 231
623: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
626: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
639: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
642: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
643: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
646: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
647: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
650: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
684: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
687: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
688: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
691: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
692: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
695: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
696: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
699: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
700: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
703: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
704: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
707: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
708: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
711: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3286: sched_cls  name tail_handle_ipv4  tag 32002a0cff9e4fe8  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,628
	btf_id 3077
3289: sched_cls  name tail_ipv4_to_endpoint  tag 078d8ad86b6e45b8  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,627,41,82,83,80,149,39,628,40,37,38
	btf_id 3078
3290: sched_cls  name tail_ipv4_ct_egress  tag a90fa4f2f6372cf6  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,628,82,83,627,84
	btf_id 3082
3293: sched_cls  name handle_policy  tag a793426f7cb087bf  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,628,82,83,627,41,80,149,39,84,75,40,37,38
	btf_id 3084
3294: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,628
	btf_id 3086
3295: sched_cls  name tail_handle_ipv4_cont  tag 9561feddf74ac281  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,627,41,149,82,83,39,76,74,77,628,40,37,38,81
	btf_id 3088
3297: sched_cls  name __send_drop_notify  tag 9a431b02b6624826  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3090
3299: sched_cls  name tail_handle_arp  tag fce9a50ff90c3a4e  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,628
	btf_id 3091
3300: sched_cls  name cil_from_container  tag 8c09182a71f1b861  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 628,76
	btf_id 3093
3302: sched_cls  name tail_ipv4_ct_ingress  tag 0f0e742eab3d4b4d  gpl
	loaded_at 2024-10-24T12:51:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,628,82,83,627,84
	btf_id 3095
3341: sched_cls  name tail_ipv4_ct_egress  tag 46d3d204007284f6  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3139
3342: sched_cls  name __send_drop_notify  tag 2375ea45c7ca2faf  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3140
3343: sched_cls  name tail_handle_ipv4  tag b9179ca557a37373  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,638
	btf_id 3137
3344: sched_cls  name tail_ipv4_to_endpoint  tag f4515d27017db9d5  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,640,41,82,83,80,146,39,639,40,37,38
	btf_id 3141
3345: sched_cls  name tail_ipv4_to_endpoint  tag d4d10b54fb6afc51  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,637,41,82,83,80,143,39,638,40,37,38
	btf_id 3142
3346: sched_cls  name cil_from_container  tag cb43db9cfc9b57bf  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 639,76
	btf_id 3143
3348: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,638
	btf_id 3146
3349: sched_cls  name tail_handle_ipv4  tag b55a94aede9eb73d  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,639
	btf_id 3144
3351: sched_cls  name handle_policy  tag 579e99de39c299b7  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,638,82,83,637,41,80,143,39,84,75,40,37,38
	btf_id 3147
3352: sched_cls  name tail_handle_ipv4_cont  tag 8ae2799e8ce2087f  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,637,41,143,82,83,39,76,74,77,638,40,37,38,81
	btf_id 3150
3353: sched_cls  name tail_ipv4_ct_egress  tag d069fc0d12da0e69  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,637,84
	btf_id 3151
3354: sched_cls  name handle_policy  tag 8a9af33bc8c5693d  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,639,82,83,640,41,80,146,39,84,75,40,37,38
	btf_id 3149
3355: sched_cls  name tail_handle_arp  tag 4230c244e8de28fc  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,638
	btf_id 3153
3356: sched_cls  name cil_from_container  tag 50b32fac3635c9fb  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 638,76
	btf_id 3154
3357: sched_cls  name tail_ipv4_ct_ingress  tag 178f877fbfbdb001  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,637,84
	btf_id 3155
3358: sched_cls  name __send_drop_notify  tag 9e06fd89615b42ce  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3156
3359: sched_cls  name tail_ipv4_ct_ingress  tag c202c8467301f397  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,639,82,83,640,84
	btf_id 3152
3360: sched_cls  name tail_handle_ipv4_cont  tag 8ecbadf577167388  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,640,41,146,82,83,39,76,74,77,639,40,37,38,81
	btf_id 3157
3361: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,639
	btf_id 3158
3362: sched_cls  name tail_handle_arp  tag 3b182e7613247796  gpl
	loaded_at 2024-10-24T12:51:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,639
	btf_id 3159
