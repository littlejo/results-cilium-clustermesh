top - 12:54:22 up 32 min,  0 users,  load average: 0.86, 0.60, 0.36
Tasks:   7 total,   2 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 18.5 us, 51.9 sy,  0.0 ni, 29.6 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    291.0 free,   1050.1 used,   2495.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2605.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 285140  79616 S   6.7   7.3   1:14.21 cilium-+
   3220 root      20   0 1240432  16736  11292 S   6.7   0.4   0:00.03 cilium-+
    417 root      20   0 1229488   9040   2864 S   0.0   0.2   0:04.54 cilium-+
   3267 root      20   0    6576   2432   2104 R   0.0   0.1   0:00.00 top
   3284 root      20   0 1228488   1756   1456 S   0.0   0.0   0:00.00 gops
   3297 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3303 root      20   0 1616008   8804   6528 R   0.0   0.2   0:00.00 runc:[2+
