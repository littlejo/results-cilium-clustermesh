filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc54d70be2f263 direct-action not_in_hw id 3346 tag cb43db9cfc9b57bf jited 
