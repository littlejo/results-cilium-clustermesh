CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaf447625_917b_4217_8a03_88ecaaf913d1.slice/cri-containerd-4e07ec0fd02746978fb83747d31539a414343696ed3a1f95b37b2c23b89ed05f.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaf447625_917b_4217_8a03_88ecaaf913d1.slice/cri-containerd-e77e9e09b6a608fd3139b282801d4f7df971b0fca6485a11aaf10b8fbb540c7b.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf80e47a3_2fe0_40f2_85c0_40131beb7c1c.slice/cri-containerd-5e107cc543ff667fca0ec22f4ba61311e64f1c64863ccb5d3516465162433079.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf80e47a3_2fe0_40f2_85c0_40131beb7c1c.slice/cri-containerd-41a1046b24c1567d3d33be300783c690f3bd405995245e13923c72b546d985f4.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc80cac9f_60e1_48d4_b189_3958283d8c6b.slice/cri-containerd-ae4b217c22d8c7fcf454cb4976d78c067094e175aef7f438f9f5f43d27606bac.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc80cac9f_60e1_48d4_b189_3958283d8c6b.slice/cri-containerd-fe77cc3c88a44f2720862ba96a6620eb6357dab355592001ffa117500aee8cc1.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcf730f67_853e_4bef_860d_658790425c15.slice/cri-containerd-aa19c8b85a81556a8a4796afafadf45edfdb0a9104eb6c47f9c782154cf5a942.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcf730f67_853e_4bef_860d_658790425c15.slice/cri-containerd-bd1a686375997ad23c343fad40e62d024a9a390741359aa0348266de3a24a0bc.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c64d6fd_bf3e_4fc1_9b34_154174596743.slice/cri-containerd-331f39749382143a196a101a1b76dd83db39b457b8433b5b1be55fb5075e8eaa.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c64d6fd_bf3e_4fc1_9b34_154174596743.slice/cri-containerd-c3ca93e50e30351aa140a1877f997f194d3f719b1d5f4362db857d4bebbbd487.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c64d6fd_bf3e_4fc1_9b34_154174596743.slice/cri-containerd-81a4ddb8b7c32e1a74acec5d2f08263646a894f2e1241a4dabca97c07f233124.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c64d6fd_bf3e_4fc1_9b34_154174596743.slice/cri-containerd-2415f8a4618e2ead01d3ac9e1ae8c3aebacbef476ca5fbccbb472b58138c726d.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00dec9ef_95e4_476d_9fb3_08986aea48a3.slice/cri-containerd-c0139ad95c3e824cac8fcb4db581449759c50edd9e4803004e07db5d8dfb5887.scope
    691      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00dec9ef_95e4_476d_9fb3_08986aea48a3.slice/cri-containerd-bbc4df8fc4c9383b8fc769f34ec0fe01f312ea9aa1230ea9af36c60ff245eeb3.scope
    699      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ddf8654_bb4f_4ad8_8c66_826261e151e7.slice/cri-containerd-f4c138e85fba518bae971352bb7fe1e948293c0ed830ddf4baada72706921f5f.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ddf8654_bb4f_4ad8_8c66_826261e151e7.slice/cri-containerd-a0ce12e41d851d91b3abd55e6c3ae65fc6acb63b216b4410bc2217ab1f51c867.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc035f023_3f92_4142_adfa_1067a22aa7ab.slice/cri-containerd-e406aa3b7945c8f184e4cf10516fd7aab636497c4fa567be7b0990b6966baebc.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc035f023_3f92_4142_adfa_1067a22aa7ab.slice/cri-containerd-6f9d06c291dd31b0aec08501438b9ae5a889e4872c6b143580beaed74dbf8664.scope
    687      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56cf6e3b_0329_4baa_b696_5be98e46b11f.slice/cri-containerd-0c411187796084b37b3699392810634abc4eac8988f7cc79f31b5f835840c17a.scope
    695      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56cf6e3b_0329_4baa_b696_5be98e46b11f.slice/cri-containerd-e0dc62faa93ac1ee91d654a85ae7e1e2eeafde5c49801e27f101ec0bd866add0.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56cf6e3b_0329_4baa_b696_5be98e46b11f.slice/cri-containerd-a4e7c92ff7c34da5287a8d3ea3f44586121d373101490a1f2db5c1eb4b4d826f.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86f6d0e5_0193_4df0_8a0b_9b9ee65f67d0.slice/cri-containerd-e43e2e3f353cd87b60adf4c6c8fb61bb227ce2c5a4ab31d72dd16f1b115af2ea.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86f6d0e5_0193_4df0_8a0b_9b9ee65f67d0.slice/cri-containerd-26f07449b1a6db10c471371808cd3d3b585ba03fda808769a89a77e8e4f734e2.scope
    90       cgroup_device   multi                                          
