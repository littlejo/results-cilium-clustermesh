Node 0, zone      DMA      6     30      3      4      3      1      3      1      1      3     50 
Node 0, zone   Normal   1287    337     88     28     27     14      6      6      4      4      3 
