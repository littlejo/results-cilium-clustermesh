filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf9c02adef2ff direct-action not_in_hw id 3300 tag 8c09182a71f1b861 jited 
