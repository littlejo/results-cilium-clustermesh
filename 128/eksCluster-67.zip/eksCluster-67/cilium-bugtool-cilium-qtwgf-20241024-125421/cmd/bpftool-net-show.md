xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 502
ens6(5) clsact/ingress cil_from_netdev-ens6 id 509
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 496
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 486
cilium_host(7) clsact/egress cil_from_host-cilium_host id 489
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 544
lxcb4d6e8c955a1(12) clsact/ingress cil_from_container-lxcb4d6e8c955a1 id 524
lxc73245cb60a6d(14) clsact/ingress cil_from_container-lxc73245cb60a6d id 538
lxc1f8b60d66146(18) clsact/ingress cil_from_container-lxc1f8b60d66146 id 615
lxc4bdf34c3e71d(20) clsact/ingress cil_from_container-lxc4bdf34c3e71d id 3356
lxc54d70be2f263(22) clsact/ingress cil_from_container-lxc54d70be2f263 id 3346
lxcf9c02adef2ff(24) clsact/ingress cil_from_container-lxcf9c02adef2ff id 3300

flow_dissector:

netfilter:

