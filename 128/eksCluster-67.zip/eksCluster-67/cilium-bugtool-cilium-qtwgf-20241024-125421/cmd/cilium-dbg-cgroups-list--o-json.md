[
  {
    "containers": [
      {
        "cgroup-id": 7582,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaf447625_917b_4217_8a03_88ecaaf913d1.slice/cri-containerd-4e07ec0fd02746978fb83747d31539a414343696ed3a1f95b37b2c23b89ed05f.scope"
      }
    ],
    "ips": [
      "10.67.0.18"
    ],
    "name": "coredns-cc6ccd49c-dn54b",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9946,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc035f023_3f92_4142_adfa_1067a22aa7ab.slice/cri-containerd-e406aa3b7945c8f184e4cf10516fd7aab636497c4fa567be7b0990b6966baebc.scope"
      }
    ],
    "ips": [
      "10.67.0.10"
    ],
    "name": "client-974f6c69d-6nt6x",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7666,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf80e47a3_2fe0_40f2_85c0_40131beb7c1c.slice/cri-containerd-41a1046b24c1567d3d33be300783c690f3bd405995245e13923c72b546d985f4.scope"
      }
    ],
    "ips": [
      "10.67.0.116"
    ],
    "name": "coredns-cc6ccd49c-2kw2g",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10114,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56cf6e3b_0329_4baa_b696_5be98e46b11f.slice/cri-containerd-a4e7c92ff7c34da5287a8d3ea3f44586121d373101490a1f2db5c1eb4b4d826f.scope"
      },
      {
        "cgroup-id": 10030,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56cf6e3b_0329_4baa_b696_5be98e46b11f.slice/cri-containerd-e0dc62faa93ac1ee91d654a85ae7e1e2eeafde5c49801e27f101ec0bd866add0.scope"
      }
    ],
    "ips": [
      "10.67.0.235"
    ],
    "name": "echo-same-node-86d9cc975c-jqrpw",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9190,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c64d6fd_bf3e_4fc1_9b34_154174596743.slice/cri-containerd-2415f8a4618e2ead01d3ac9e1ae8c3aebacbef476ca5fbccbb472b58138c726d.scope"
      },
      {
        "cgroup-id": 9106,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c64d6fd_bf3e_4fc1_9b34_154174596743.slice/cri-containerd-c3ca93e50e30351aa140a1877f997f194d3f719b1d5f4362db857d4bebbbd487.scope"
      },
      {
        "cgroup-id": 9274,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c64d6fd_bf3e_4fc1_9b34_154174596743.slice/cri-containerd-331f39749382143a196a101a1b76dd83db39b457b8433b5b1be55fb5075e8eaa.scope"
      }
    ],
    "ips": [
      "10.67.0.50"
    ],
    "name": "clustermesh-apiserver-76665475fb-q8482",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9862,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00dec9ef_95e4_476d_9fb3_08986aea48a3.slice/cri-containerd-bbc4df8fc4c9383b8fc769f34ec0fe01f312ea9aa1230ea9af36c60ff245eeb3.scope"
      }
    ],
    "ips": [
      "10.67.0.145"
    ],
    "name": "client2-57cf4468f-jn752",
    "namespace": "cilium-test-1"
  }
]

