key: 70 02 00 00  value: 2b 02 00 00
key: e3 03 00 00  value: dd 0c 00 00
key: 9c 05 00 00  value: 17 0d 00 00
key: 23 06 00 00  value: 06 02 00 00
key: 42 07 00 00  value: 28 02 00 00
key: 84 07 00 00  value: 1a 0d 00 00
key: 2c 0a 00 00  value: 64 02 00 00
Found 7 elements
