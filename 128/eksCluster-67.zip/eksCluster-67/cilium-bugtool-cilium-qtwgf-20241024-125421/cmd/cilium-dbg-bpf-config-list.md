KEY             VALUE
AgentLiveness   1939432155987
UTimeOffset     3378461962890625
