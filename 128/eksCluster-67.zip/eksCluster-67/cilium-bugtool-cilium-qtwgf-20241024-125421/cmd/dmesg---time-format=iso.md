2024-10-24T12:22:05,000000+00:00 Booting Linux on physical CPU 0x0000000000 [0x413fd0c1]
2024-10-24T12:22:05,000000+00:00 Linux version 6.1.112-122.189.amzn2023.aarch64 (mockbuild@ip-10-0-39-248) (gcc (GCC) 11.4.1 20230605 (Red Hat 11.4.1-2), GNU ld version 2.39-6.amzn2023.0.10) #1 SMP Tue Oct  8 17:01:34 UTC 2024
2024-10-24T12:22:05,000000+00:00 efi: EFI v2.70 by EDK II
2024-10-24T12:22:05,000000+00:00 efi: SMBIOS=0x7bed0000 SMBIOS 3.0=0x7beb0000 ACPI=0x786e0000 ACPI 2.0=0x786e0014 MEMATTR=0x7aff0a98 RNG=0x74ca0018 MEMRESERVE=0x784d0d98 
2024-10-24T12:22:05,000000+00:00 random: crng init done
2024-10-24T12:22:05,000000+00:00 ACPI: Early table checksum verification disabled
2024-10-24T12:22:05,000000+00:00 ACPI: RSDP 0x00000000786E0014 000024 (v02 AMAZON)
2024-10-24T12:22:05,000000+00:00 ACPI: XSDT 0x00000000786D00E8 000064 (v01 AMAZON AMZNFACP 00000001      01000013)
2024-10-24T12:22:05,000000+00:00 ACPI: FACP 0x00000000786B0000 000114 (v06 AMAZON AMZNFACP 00000001 AMZN 00000001)
2024-10-24T12:22:05,000000+00:00 ACPI: DSDT 0x0000000078640000 00159D (v02 AMAZON AMZNDSDT 00000001 INTL 20160527)
2024-10-24T12:22:05,000000+00:00 ACPI: FACS 0x0000000078630000 000040
2024-10-24T12:22:05,000000+00:00 ACPI: APIC 0x00000000786C0000 000108 (v04 AMAZON AMZNAPIC 00000001 AMZN 00000001)
2024-10-24T12:22:05,000000+00:00 ACPI: SPCR 0x00000000786A0000 000050 (v02 AMAZON AMZNSPCR 00000001 AMZN 00000001)
2024-10-24T12:22:05,000000+00:00 ACPI: GTDT 0x0000000078690000 000060 (v02 AMAZON AMZNGTDT 00000001 AMZN 00000001)
2024-10-24T12:22:05,000000+00:00 ACPI: MCFG 0x0000000078680000 00003C (v02 AMAZON AMZNMCFG 00000001 AMZN 00000001)
2024-10-24T12:22:05,000000+00:00 ACPI: SLIT 0x0000000078670000 00002D (v01 AMAZON AMZNSLIT 00000001 AMZN 00000001)
2024-10-24T12:22:05,000000+00:00 ACPI: IORT 0x0000000078660000 000078 (v01 AMAZON AMZNIORT 00000001 AMZN 00000001)
2024-10-24T12:22:05,000000+00:00 ACPI: PPTT 0x0000000078650000 0000D4 (v02 AMAZON AMZNPPTT 00000001 AMZN 00000001)
2024-10-24T12:22:05,000000+00:00 ACPI: SPCR: console: uart,mmio,0x90a0000,115200
2024-10-24T12:22:05,000000+00:00 NUMA: Failed to initialise from firmware
2024-10-24T12:22:05,000000+00:00 NUMA: Faking a node at [mem 0x0000000040000000-0x00000004bb7fffff]
2024-10-24T12:22:05,000000+00:00 NUMA: NODE_DATA [mem 0x4bb01a7c0-0x4bb01cfff]
2024-10-24T12:22:05,000000+00:00 Zone ranges:
2024-10-24T12:22:05,000000+00:00   DMA      [mem 0x0000000040000000-0x00000000ffffffff]
2024-10-24T12:22:05,000000+00:00   DMA32    empty
2024-10-24T12:22:05,000000+00:00   Normal   [mem 0x0000000100000000-0x00000004bb7fffff]
2024-10-24T12:22:05,000000+00:00   Device   empty
2024-10-24T12:22:05,000000+00:00 Movable zone start for each node
2024-10-24T12:22:05,000000+00:00 Early memory node ranges
2024-10-24T12:22:05,000000+00:00   node   0: [mem 0x0000000040000000-0x000000007862ffff]
2024-10-24T12:22:05,000000+00:00   node   0: [mem 0x0000000078630000-0x000000007863ffff]
2024-10-24T12:22:05,000000+00:00   node   0: [mem 0x0000000078640000-0x00000000786effff]
2024-10-24T12:22:05,000000+00:00   node   0: [mem 0x00000000786f0000-0x000000007872ffff]
2024-10-24T12:22:05,000000+00:00   node   0: [mem 0x0000000078730000-0x000000007bbfffff]
2024-10-24T12:22:05,000000+00:00   node   0: [mem 0x000000007bc00000-0x000000007bfdffff]
2024-10-24T12:22:05,000000+00:00   node   0: [mem 0x000000007bfe0000-0x000000007fffffff]
2024-10-24T12:22:05,000000+00:00   node   0: [mem 0x0000000400000000-0x00000004bb7fffff]
2024-10-24T12:22:05,000000+00:00 Initmem setup node 0 [mem 0x0000000040000000-0x00000004bb7fffff]
2024-10-24T12:22:05,000000+00:00 On node 0, zone Normal: 18432 pages in unavailable ranges
2024-10-24T12:22:05,000000+00:00 cma: Reserved 64 MiB at 0x000000007c000000 on node -1
2024-10-24T12:22:05,000000+00:00 psci: probing for conduit method from ACPI.
2024-10-24T12:22:05,000000+00:00 psci: PSCIv1.0 detected in firmware.
2024-10-24T12:22:05,000000+00:00 psci: Using standard PSCI v0.2 function IDs
2024-10-24T12:22:05,000000+00:00 psci: Trusted OS migration not required
2024-10-24T12:22:05,000000+00:00 psci: SMC Calling Convention v1.1
2024-10-24T12:22:05,000000+00:00 percpu: Embedded 31 pages/cpu s86440 r8192 d32344 u126976
2024-10-24T12:22:05,000000+00:00 pcpu-alloc: s86440 r8192 d32344 u126976 alloc=31*4096
2024-10-24T12:22:05,000000+00:00 pcpu-alloc: [0] 0 [0] 1 
2024-10-24T12:22:05,000000+00:00 Detected PIPT I-cache on CPU0
2024-10-24T12:22:05,000000+00:00 CPU features: detected: GIC system register CPU interface
2024-10-24T12:22:05,000000+00:00 CPU features: detected: Hardware dirty bit management
2024-10-24T12:22:05,000000+00:00 CPU features: detected: Spectre-v4
2024-10-24T12:22:05,000000+00:00 CPU features: detected: Spectre-BHB
2024-10-24T12:22:05,000000+00:00 CPU features: detected: ARM erratum 1418040
2024-10-24T12:22:05,000000+00:00 CPU features: detected: ARM erratum 1542419 (kernel portion)
2024-10-24T12:22:05,000000+00:00 CPU features: detected: SSBS not fully self-synchronizing
2024-10-24T12:22:05,000000+00:00 alternatives: applying boot alternatives
2024-10-24T12:22:05,000000+00:00 Fallback order for Node 0: 0 
2024-10-24T12:22:05,000000+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 1014048
2024-10-24T12:22:05,000000+00:00 Policy zone: Normal
2024-10-24T12:22:05,000000+00:00 Kernel command line: BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64 root=UUID=b5c7fae5-1de8-4038-8408-06c720e69aff ro console=tty0 console=ttyS0,115200n8 nvme_core.io_timeout=4294967295 rd.emergency=poweroff rd.shell=0 selinux=1 security=selinux quiet numa_cma=1:64M
2024-10-24T12:22:05,000000+00:00 Unknown kernel command line parameters "BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64", will be passed to user space.
2024-10-24T12:22:05,000000+00:00 Dentry cache hash table entries: 524288 (order: 10, 4194304 bytes, linear)
2024-10-24T12:22:05,000000+00:00 Inode-cache hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2024-10-24T12:22:05,000000+00:00 mem auto-init: stack:off, heap alloc:off, heap free:off
2024-10-24T12:22:05,000000+00:00 software IO TLB: area num 2.
2024-10-24T12:22:05,000000+00:00 software IO TLB: mapped [mem 0x000000006de00000-0x0000000071e00000] (64MB)
2024-10-24T12:22:05,000000+00:00 Memory: 3846296K/4120576K available (12096K kernel code, 8838K rwdata, 8416K rodata, 4480K init, 11359K bss, 208744K reserved, 65536K cma-reserved)
2024-10-24T12:22:05,000000+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=2, Nodes=1
2024-10-24T12:22:05,000000+00:00 ftrace: allocating 40237 entries in 158 pages
2024-10-24T12:22:05,000000+00:00 ftrace: allocated 158 pages with 5 groups
2024-10-24T12:22:05,000000+00:00 trace event string verifier disabled
2024-10-24T12:22:05,000000+00:00 rcu: Hierarchical RCU implementation.
2024-10-24T12:22:05,000000+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=4096 to nr_cpu_ids=2.
2024-10-24T12:22:05,000000+00:00 	Rude variant of Tasks RCU enabled.
2024-10-24T12:22:05,000000+00:00 	Tracing variant of Tasks RCU enabled.
2024-10-24T12:22:05,000000+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 10 jiffies.
2024-10-24T12:22:05,000000+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=2
2024-10-24T12:22:05,000000+00:00 NR_IRQS: 64, nr_irqs: 64, preallocated irqs: 0
2024-10-24T12:22:05,000000+00:00 GICv3: 96 SPIs implemented
2024-10-24T12:22:05,000000+00:00 GICv3: 0 Extended SPIs implemented
2024-10-24T12:22:05,000000+00:00 Root IRQ handler: gic_handle_irq
2024-10-24T12:22:05,000000+00:00 GICv3: GICv3 features: 16 PPIs
2024-10-24T12:22:05,000000+00:00 GICv3: CPU0: found redistributor 0 region 0:0x0000000010200000
2024-10-24T12:22:05,000000+00:00 ITS [mem 0x10080000-0x1009ffff]
2024-10-24T12:22:05,000000+00:00 ITS@0x0000000010080000: allocated 8192 Devices @4001a0000 (indirect, esz 8, psz 64K, shr 1)
2024-10-24T12:22:05,000000+00:00 ITS@0x0000000010080000: allocated 8192 Interrupt Collections @4001b0000 (flat, esz 8, psz 64K, shr 1)
2024-10-24T12:22:05,000000+00:00 GICv3: using LPI property table @0x00000004001c0000
2024-10-24T12:22:05,000000+00:00 ITS: Using hypervisor restricted LPI range [128]
2024-10-24T12:22:05,000000+00:00 GICv3: CPU0: using allocated LPI pending table @0x00000004001d0000
2024-10-24T12:22:05,000000+00:00 rcu: srcu_init: Setting srcu_struct sizes based on contention.
2024-10-24T12:22:05,000000+00:00 arch_timer: Enabling local workaround for ARM erratum 1418040
2024-10-24T12:22:05,000000+00:00 arch_timer: cp15 timer(s) running at 121.87MHz (virt).
2024-10-24T12:22:05,000000+00:00 clocksource: arch_sys_counter: mask: 0x3ffffffffffffff max_cycles: 0x383759f8ff, max_idle_ns: 881590415659 ns
2024-10-24T12:22:05,000000+00:00 sched_clock: 58 bits at 122MHz, resolution 8ns, wraps every 4398046511103ns
2024-10-24T12:22:05,000020+00:00 arm-pv: using stolen time PV
2024-10-24T12:22:05,000083+00:00 Console: colour dummy device 80x25
2024-10-24T12:22:05,000095+00:00 printk: console [tty0] enabled
2024-10-24T12:22:05,000113+00:00 ACPI: Core revision 20220331
2024-10-24T12:22:05,000147+00:00 Calibrating delay loop (skipped), value calculated using timer frequency.. 243.75 BogoMIPS (lpj=1218750)
2024-10-24T12:22:05,000150+00:00 pid_max: default: 32768 minimum: 301
2024-10-24T12:22:05,000171+00:00 LSM: Security Framework initializing
2024-10-24T12:22:05,000188+00:00 Yama: becoming mindful.
2024-10-24T12:22:05,000194+00:00 SELinux:  Initializing.
2024-10-24T12:22:05,000209+00:00 LSM support for eBPF active
2024-10-24T12:22:05,000227+00:00 Mount-cache hash table entries: 8192 (order: 4, 65536 bytes, linear)
2024-10-24T12:22:05,000231+00:00 Mountpoint-cache hash table entries: 8192 (order: 4, 65536 bytes, linear)
2024-10-24T12:22:05,000562+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-10-24T12:22:05,000564+00:00 cblist_init_generic: Setting shift to 1 and lim to 1.
2024-10-24T12:22:05,000577+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-10-24T12:22:05,000578+00:00 cblist_init_generic: Setting shift to 1 and lim to 1.
2024-10-24T12:22:05,000619+00:00 rcu: Hierarchical SRCU implementation.
2024-10-24T12:22:05,000620+00:00 rcu: 	Max phase no-delay instances is 1000.
2024-10-24T12:22:05,000812+00:00 Platform MSI: ITS@0x10080000 domain created
2024-10-24T12:22:05,000817+00:00 PCI/MSI: ITS@0x10080000 domain created
2024-10-24T12:22:05,000821+00:00 Remapping and enabling EFI services.
2024-10-24T12:22:05,000930+00:00 smp: Bringing up secondary CPUs ...
2024-10-24T12:22:05,001096+00:00 Detected PIPT I-cache on CPU1
2024-10-24T12:22:05,001125+00:00 GICv3: CPU1: found redistributor 1 region 0:0x0000000010220000
2024-10-24T12:22:05,001154+00:00 GICv3: CPU1: using allocated LPI pending table @0x00000004001e0000
2024-10-24T12:22:05,001172+00:00 arch_timer: Enabling local workaround for ARM erratum 1418040
2024-10-24T12:22:05,001186+00:00 CPU1: Booted secondary processor 0x0000000001 [0x413fd0c1]
2024-10-24T12:22:05,001265+00:00 smp: Brought up 1 node, 2 CPUs
2024-10-24T12:22:05,001269+00:00 SMP: Total of 2 processors activated.
2024-10-24T12:22:05,001271+00:00 CPU features: detected: 32-bit EL0 Support
2024-10-24T12:22:05,001272+00:00 CPU features: detected: Instruction cache invalidation not required for I/D coherence
2024-10-24T12:22:05,001274+00:00 CPU features: detected: Data cache clean to the PoU not required for I/D coherence
2024-10-24T12:22:05,001275+00:00 CPU features: detected: Common not Private translations
2024-10-24T12:22:05,001276+00:00 CPU features: detected: CRC32 instructions
2024-10-24T12:22:05,001278+00:00 CPU features: detected: RCpc load-acquire (LDAPR)
2024-10-24T12:22:05,001278+00:00 CPU features: detected: LSE atomic instructions
2024-10-24T12:22:05,001279+00:00 CPU features: detected: Privileged Access Never
2024-10-24T12:22:05,001280+00:00 CPU features: detected: RAS Extension Support
2024-10-24T12:22:05,001282+00:00 CPU features: detected: Speculative Store Bypassing Safe (SSBS)
2024-10-24T12:22:05,001329+00:00 CPU: All CPU(s) started at EL1
2024-10-24T12:22:05,001332+00:00 alternatives: applying system-wide alternatives
2024-10-24T12:22:05,003526+00:00 devtmpfs: initialized
2024-10-24T12:22:05,004008+00:00 Registered cp15_barrier emulation handler
2024-10-24T12:22:05,004019+00:00 Registered setend emulation handler
2024-10-24T12:22:05,004055+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 19112604462750000 ns
2024-10-24T12:22:05,004059+00:00 futex hash table entries: 512 (order: 3, 32768 bytes, linear)
2024-10-24T12:22:05,004282+00:00 pinctrl core: initialized pinctrl subsystem
2024-10-24T12:22:05,004328+00:00 SMBIOS 3.0.0 present.
2024-10-24T12:22:05,004331+00:00 DMI: Amazon EC2 t4g.medium/, BIOS 1.0 11/1/2018
2024-10-24T12:22:05,004435+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2024-10-24T12:22:05,004619+00:00 DMA: preallocated 512 KiB GFP_KERNEL pool for atomic allocations
2024-10-24T12:22:05,004642+00:00 DMA: preallocated 512 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2024-10-24T12:22:05,004674+00:00 DMA: preallocated 512 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2024-10-24T12:22:05,004684+00:00 audit: initializing netlink subsys (disabled)
2024-10-24T12:22:05,004744+00:00 audit: type=2000 audit(0.000:1): state=initialized audit_enabled=0 res=1
2024-10-24T12:22:05,004798+00:00 thermal_sys: Registered thermal governor 'fair_share'
2024-10-24T12:22:05,004800+00:00 thermal_sys: Registered thermal governor 'step_wise'
2024-10-24T12:22:05,004801+00:00 thermal_sys: Registered thermal governor 'user_space'
2024-10-24T12:22:05,004809+00:00 cpuidle: using governor ladder
2024-10-24T12:22:05,004813+00:00 cpuidle: using governor menu
2024-10-24T12:22:05,004850+00:00 hw-breakpoint: found 6 breakpoint and 4 watchpoint registers.
2024-10-24T12:22:05,004900+00:00 ASID allocator initialised with 65536 entries
2024-10-24T12:22:05,004906+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2024-10-24T12:22:05,004918+00:00 Serial: AMBA PL011 UART driver
2024-10-24T12:22:05,010160+00:00 HugeTLB: registered 1.00 GiB page size, pre-allocated 0 pages
2024-10-24T12:22:05,010163+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 1.00 GiB page
2024-10-24T12:22:05,010165+00:00 HugeTLB: registered 32.0 MiB page size, pre-allocated 0 pages
2024-10-24T12:22:05,010166+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 32.0 MiB page
2024-10-24T12:22:05,010167+00:00 HugeTLB: registered 2.00 MiB page size, pre-allocated 0 pages
2024-10-24T12:22:05,010168+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 2.00 MiB page
2024-10-24T12:22:05,010169+00:00 HugeTLB: registered 64.0 KiB page size, pre-allocated 0 pages
2024-10-24T12:22:05,010170+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 64.0 KiB page
2024-10-24T12:22:05,010726+00:00 ACPI: Added _OSI(Module Device)
2024-10-24T12:22:05,010728+00:00 ACPI: Added _OSI(Processor Device)
2024-10-24T12:22:05,010729+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2024-10-24T12:22:05,010730+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2024-10-24T12:22:05,011300+00:00 ACPI: 1 ACPI AML tables successfully acquired and loaded
2024-10-24T12:22:05,011691+00:00 ACPI: Interpreter enabled
2024-10-24T12:22:05,011693+00:00 ACPI: Using GIC for interrupt routing
2024-10-24T12:22:05,011703+00:00 ACPI: MCFG table detected, 1 entries
2024-10-24T12:22:05,013160+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-0f])
2024-10-24T12:22:05,013169+00:00 acpi PNP0A08:00: _OSC: OS supports [ExtendedConfig ASPM ClockPM Segments MSI HPX-Type3]
2024-10-24T12:22:05,013208+00:00 acpi PNP0A08:00: _OSC: platform does not support [SHPCHotplug LTR]
2024-10-24T12:22:05,013260+00:00 acpi PNP0A08:00: _OSC: OS now controls [PCIeHotplug PME PCIeCapability]
2024-10-24T12:22:05,013335+00:00 acpi PNP0A08:00: ECAM area [mem 0x20000000-0x20ffffff] reserved by PNP0C02:00
2024-10-24T12:22:05,013341+00:00 acpi PNP0A08:00: ECAM at [mem 0x20000000-0x20ffffff] for [bus 00-0f]
2024-10-24T12:22:05,013354+00:00 ACPI: Remapped I/O 0x000000001fff0000 to [io  0x0000-0xffff window]
2024-10-24T12:22:05,013602+00:00 acpiphp: Slot [1] registered
2024-10-24T12:22:05,013614+00:00 acpiphp: Slot [2] registered
2024-10-24T12:22:05,013625+00:00 acpiphp: Slot [3] registered
2024-10-24T12:22:05,013635+00:00 acpiphp: Slot [4] registered
2024-10-24T12:22:05,013645+00:00 acpiphp: Slot [5] registered
2024-10-24T12:22:05,013654+00:00 acpiphp: Slot [6] registered
2024-10-24T12:22:05,013664+00:00 acpiphp: Slot [7] registered
2024-10-24T12:22:05,013674+00:00 acpiphp: Slot [8] registered
2024-10-24T12:22:05,013683+00:00 acpiphp: Slot [9] registered
2024-10-24T12:22:05,013692+00:00 acpiphp: Slot [10] registered
2024-10-24T12:22:05,013701+00:00 acpiphp: Slot [11] registered
2024-10-24T12:22:05,013710+00:00 acpiphp: Slot [12] registered
2024-10-24T12:22:05,013720+00:00 acpiphp: Slot [13] registered
2024-10-24T12:22:05,013730+00:00 acpiphp: Slot [14] registered
2024-10-24T12:22:05,013740+00:00 acpiphp: Slot [15] registered
2024-10-24T12:22:05,013749+00:00 acpiphp: Slot [16] registered
2024-10-24T12:22:05,013759+00:00 acpiphp: Slot [17] registered
2024-10-24T12:22:05,013768+00:00 acpiphp: Slot [18] registered
2024-10-24T12:22:05,013777+00:00 acpiphp: Slot [19] registered
2024-10-24T12:22:05,013787+00:00 acpiphp: Slot [20] registered
2024-10-24T12:22:05,013796+00:00 acpiphp: Slot [21] registered
2024-10-24T12:22:05,013805+00:00 acpiphp: Slot [22] registered
2024-10-24T12:22:05,013814+00:00 acpiphp: Slot [23] registered
2024-10-24T12:22:05,013823+00:00 acpiphp: Slot [24] registered
2024-10-24T12:22:05,013834+00:00 acpiphp: Slot [25] registered
2024-10-24T12:22:05,013844+00:00 acpiphp: Slot [26] registered
2024-10-24T12:22:05,013854+00:00 acpiphp: Slot [27] registered
2024-10-24T12:22:05,013863+00:00 acpiphp: Slot [28] registered
2024-10-24T12:22:05,013872+00:00 acpiphp: Slot [29] registered
2024-10-24T12:22:05,013881+00:00 acpiphp: Slot [30] registered
2024-10-24T12:22:05,013890+00:00 acpiphp: Slot [31] registered
2024-10-24T12:22:05,013906+00:00 PCI host bridge to bus 0000:00
2024-10-24T12:22:05,013907+00:00 pci_bus 0000:00: root bus resource [mem 0x80000000-0xffffffff window]
2024-10-24T12:22:05,013909+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0xffff window]
2024-10-24T12:22:05,013911+00:00 pci_bus 0000:00: root bus resource [mem 0x400000000000-0x407fffffffff window]
2024-10-24T12:22:05,013913+00:00 pci_bus 0000:00: root bus resource [bus 00-0f]
2024-10-24T12:22:05,013948+00:00 pci 0000:00:00.0: [1d0f:0200] type 00 class 0x060000
2024-10-24T12:22:05,014186+00:00 pci 0000:00:01.0: [1d0f:8250] type 00 class 0x070003
2024-10-24T12:22:05,014233+00:00 pci 0000:00:01.0: reg 0x10: [mem 0x80008000-0x80008fff]
2024-10-24T12:22:05,014424+00:00 pci 0000:00:04.0: [1d0f:8061] type 00 class 0x010802
2024-10-24T12:22:05,015786+00:00 pci 0000:00:04.0: reg 0x10: [mem 0x80004000-0x80007fff]
2024-10-24T12:22:05,021485+00:00 pci 0000:00:04.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-24T12:22:05,021680+00:00 pci 0000:00:05.0: [1d0f:ec20] type 00 class 0x020000
2024-10-24T12:22:05,021720+00:00 pci 0000:00:05.0: reg 0x10: [mem 0x80000000-0x80003fff]
2024-10-24T12:22:05,021915+00:00 pci 0000:00:05.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-24T12:22:05,022076+00:00 pci 0000:00:04.0: BAR 0: assigned [mem 0x80000000-0x80003fff]
2024-10-24T12:22:05,022575+00:00 pci 0000:00:05.0: BAR 0: assigned [mem 0x80004000-0x80007fff]
2024-10-24T12:22:05,022584+00:00 pci 0000:00:01.0: BAR 0: assigned [mem 0x80008000-0x80008fff]
2024-10-24T12:22:05,022592+00:00 pci_bus 0000:00: resource 4 [mem 0x80000000-0xffffffff window]
2024-10-24T12:22:05,022594+00:00 pci_bus 0000:00: resource 5 [io  0x0000-0xffff window]
2024-10-24T12:22:05,022596+00:00 pci_bus 0000:00: resource 6 [mem 0x400000000000-0x407fffffffff window]
2024-10-24T12:22:05,022630+00:00 ACPI: PCI: Interrupt link GSI0 configured for IRQ 35
2024-10-24T12:22:05,022637+00:00 ACPI: PCI: Interrupt link GSI1 configured for IRQ 36
2024-10-24T12:22:05,022642+00:00 ACPI: PCI: Interrupt link GSI2 configured for IRQ 37
2024-10-24T12:22:05,022647+00:00 ACPI: PCI: Interrupt link GSI3 configured for IRQ 38
2024-10-24T12:22:05,023029+00:00 iommu: Default domain type: Translated 
2024-10-24T12:22:05,023031+00:00 iommu: DMA domain TLB invalidation policy: lazy mode 
2024-10-24T12:22:05,023069+00:00 pps_core: LinuxPPS API ver. 1 registered
2024-10-24T12:22:05,023070+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2024-10-24T12:22:05,023072+00:00 PTP clock support registered
2024-10-24T12:22:05,023102+00:00 EDAC MC: Ver: 3.0.0
2024-10-24T12:22:05,023280+00:00 Registered efivars operations
2024-10-24T12:22:05,023537+00:00 NetLabel: Initializing
2024-10-24T12:22:05,023538+00:00 NetLabel:  domain hash size = 128
2024-10-24T12:22:05,023539+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2024-10-24T12:22:05,023550+00:00 NetLabel:  unlabeled traffic allowed by default
2024-10-24T12:22:05,023594+00:00 vgaarb: loaded
2024-10-24T12:22:05,023687+00:00 clocksource: Switched to clocksource arch_sys_counter
2024-10-24T12:22:05,023758+00:00 VFS: Disk quotas dquot_6.6.0
2024-10-24T12:22:05,023768+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2024-10-24T12:22:05,023822+00:00 pnp: PnP ACPI init
2024-10-24T12:22:05,023902+00:00 system 00:00: [mem 0x20000000-0x2fffffff] could not be reserved
2024-10-24T12:22:05,023913+00:00 pnp: PnP ACPI: found 1 devices
2024-10-24T12:22:05,030915+00:00 NET: Registered PF_INET protocol family
2024-10-24T12:22:05,030950+00:00 IP idents hash table entries: 65536 (order: 7, 524288 bytes, linear)
2024-10-24T12:22:05,031704+00:00 tcp_listen_portaddr_hash hash table entries: 2048 (order: 3, 32768 bytes, linear)
2024-10-24T12:22:05,031718+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2024-10-24T12:22:05,031722+00:00 TCP established hash table entries: 32768 (order: 6, 262144 bytes, linear)
2024-10-24T12:22:05,031834+00:00 TCP bind hash table entries: 32768 (order: 8, 1048576 bytes, linear)
2024-10-24T12:22:05,032141+00:00 TCP: Hash tables configured (established 32768 bind 32768)
2024-10-24T12:22:05,032177+00:00 MPTCP token hash table entries: 4096 (order: 4, 98304 bytes, linear)
2024-10-24T12:22:05,032192+00:00 UDP hash table entries: 2048 (order: 4, 65536 bytes, linear)
2024-10-24T12:22:05,032223+00:00 UDP-Lite hash table entries: 2048 (order: 4, 65536 bytes, linear)
2024-10-24T12:22:05,032277+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2024-10-24T12:22:05,032285+00:00 NET: Registered PF_XDP protocol family
2024-10-24T12:22:05,032333+00:00 PCI: CLS 0 bytes, default 64
2024-10-24T12:22:05,032477+00:00 Trying to unpack rootfs image as initramfs...
2024-10-24T12:22:05,044277+00:00 hw perfevents: enabled with armv8_pmuv3_0 PMU driver, 3 counters available
2024-10-24T12:22:05,044305+00:00 kvm [1]: HYP mode not available
2024-10-24T12:22:05,044522+00:00 Initialise system trusted keyrings
2024-10-24T12:22:05,044528+00:00 Key type blacklist registered
2024-10-24T12:22:05,044741+00:00 workingset: timestamp_bits=44 max_order=20 bucket_order=0
2024-10-24T12:22:05,045731+00:00 zbud: loaded
2024-10-24T12:22:05,045866+00:00 SGI XFS with ACLs, security attributes, quota, no debug enabled
2024-10-24T12:22:05,046336+00:00 integrity: Platform Keyring initialized
2024-10-24T12:22:05,053356+00:00 Key type asymmetric registered
2024-10-24T12:22:05,053359+00:00 Asymmetric key parser 'x509' registered
2024-10-24T12:22:05,053379+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 248)
2024-10-24T12:22:05,053416+00:00 io scheduler mq-deadline registered
2024-10-24T12:22:05,053418+00:00 io scheduler kyber registered
2024-10-24T12:22:05,053442+00:00 io scheduler bfq registered
2024-10-24T12:22:05,055351+00:00 pl061_gpio ARMH0061:00: PL061 GPIO chip registered
2024-10-24T12:22:05,055398+00:00 shpchp: Standard Hot Plug PCI Controller Driver version: 0.4
2024-10-24T12:22:05,056609+00:00 Serial: 8250/16550 driver, 4 ports, IRQ sharing disabled
2024-10-24T12:22:05,057096+00:00 ACPI: \_SB_.PCI0.GSI2: Enabled at IRQ 37
2024-10-24T12:22:05,057123+00:00 serial 0000:00:01.0: enabling device (0010 -> 0012)
2024-10-24T12:22:05,057422+00:00 printk: console [ttyS0] disabled
2024-10-24T12:22:05,057564+00:00 0000:00:01.0: ttyS0 at MMIO 0x80008000 (irq = 14, base_baud = 115200) is a 16550A
2024-10-24T12:22:05,057664+00:00 printk: console [ttyS0] enabled
2024-10-24T12:22:05,058454+00:00 ACPI: \_SB_.PCI0.GSI0: Enabled at IRQ 35
2024-10-24T12:22:05,058536+00:00 nvme nvme0: pci function 0000:00:04.0
2024-10-24T12:22:05,059110+00:00 rtc-efi rtc-efi.0: registered as rtc0
2024-10-24T12:22:05,059142+00:00 rtc-efi rtc-efi.0: setting system clock to 2024-10-24T12:22:05 UTC (1729772525)
2024-10-24T12:22:05,059205+00:00 pstore: Registered efi as persistent store backend
2024-10-24T12:22:05,059217+00:00 hid: raw HID events driver (C) Jiri Kosina
2024-10-24T12:22:05,068322+00:00 nvme nvme0: 2/0/0 default/read/poll queues
2024-10-24T12:22:05,068910+00:00 NET: Registered PF_INET6 protocol family
2024-10-24T12:22:05,073144+00:00  nvme0n1: p1 p128
2024-10-24T12:22:05,146263+00:00 Freeing initrd memory: 11908K
2024-10-24T12:22:05,152561+00:00 Segment Routing with IPv6
2024-10-24T12:22:05,152576+00:00 In-situ OAM (IOAM) with IPv6
2024-10-24T12:22:05,152611+00:00 NET: Registered PF_PACKET protocol family
2024-10-24T12:22:05,152828+00:00 registered taskstats version 1
2024-10-24T12:22:05,152836+00:00 Loading compiled-in X.509 certificates
2024-10-24T12:22:05,164620+00:00 Loaded X.509 cert 'Amazon.com: Amazon Linux Kernel Signing Key: 3c3163dcb84c1049cf8b75ca4bcf01c5583dbccb'
2024-10-24T12:22:05,164757+00:00 zswap: loaded using pool lzo/zbud
2024-10-24T12:22:05,164920+00:00 Key type .fscrypt registered
2024-10-24T12:22:05,164922+00:00 Key type fscrypt-provisioning registered
2024-10-24T12:22:05,165123+00:00 pstore: Using crash dump compression: deflate
2024-10-24T12:22:05,165438+00:00 ima: secureboot mode disabled
2024-10-24T12:22:05,165442+00:00 ima: No TPM chip found, activating TPM-bypass!
2024-10-24T12:22:05,165446+00:00 ima: Allocated hash algorithm: sha256
2024-10-24T12:22:05,165457+00:00 ima: No architecture policies found
2024-10-24T12:22:05,306651+00:00 clk: Disabling unused clocks
2024-10-24T12:22:05,307956+00:00 Freeing unused kernel memory: 4480K
2024-10-24T12:22:05,307977+00:00 Run /init as init process
2024-10-24T12:22:05,307979+00:00   with arguments:
2024-10-24T12:22:05,307980+00:00     /init
2024-10-24T12:22:05,307981+00:00   with environment:
2024-10-24T12:22:05,307982+00:00     HOME=/
2024-10-24T12:22:05,307983+00:00     TERM=linux
2024-10-24T12:22:05,307984+00:00     BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64
2024-10-24T12:22:05,334032+00:00 systemd[1]: systemd 252.23-2.amzn2023 running in system mode (+PAM +AUDIT +SELINUX -APPARMOR +IMA +SMACK +SECCOMP -GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN -IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 -BZIP2 -LZ4 +XZ -ZLIB -ZSTD +BPF_FRAMEWORK +XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2024-10-24T12:22:05,334038+00:00 systemd[1]: Detected virtualization amazon.
2024-10-24T12:22:05,334041+00:00 systemd[1]: Detected architecture arm64.
2024-10-24T12:22:05,334043+00:00 systemd[1]: Running in initrd.
2024-10-24T12:22:05,334139+00:00 systemd[1]: No hostname configured, using default hostname.
2024-10-24T12:22:05,334179+00:00 systemd[1]: Hostname set to <localhost>.
2024-10-24T12:22:05,334250+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-10-24T12:22:05,425206+00:00 systemd[1]: Queued start job for default target initrd.target.
2024-10-24T12:22:05,444171+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2024-10-24T12:22:05,444221+00:00 systemd[1]: Expecting device dev-disk-by\x2duuid-b5c7fae5\x2d1de8\x2d4038\x2d8408\x2d06c720e69aff.device - /dev/disk/by-uuid/b5c7fae5-1de8-4038-8408-06c720e69aff...
2024-10-24T12:22:05,444251+00:00 systemd[1]: Reached target initrd-usr-fs.target - Initrd /usr File System.
2024-10-24T12:22:05,444266+00:00 systemd[1]: Reached target local-fs.target - Local File Systems.
2024-10-24T12:22:05,444276+00:00 systemd[1]: Reached target paths.target - Path Units.
2024-10-24T12:22:05,444295+00:00 systemd[1]: Reached target slices.target - Slice Units.
2024-10-24T12:22:05,444311+00:00 systemd[1]: Reached target swap.target - Swaps.
2024-10-24T12:22:05,444323+00:00 systemd[1]: Reached target timers.target - Timer Units.
2024-10-24T12:22:05,444628+00:00 systemd[1]: Listening on systemd-journald-audit.socket - Journal Audit Socket.
2024-10-24T12:22:05,444741+00:00 systemd[1]: Listening on systemd-journald-dev-log.socket - Journal Socket (/dev/log).
2024-10-24T12:22:05,444820+00:00 systemd[1]: Listening on systemd-journald.socket - Journal Socket.
2024-10-24T12:22:05,444909+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2024-10-24T12:22:05,444971+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2024-10-24T12:22:05,444988+00:00 systemd[1]: Reached target sockets.target - Socket Units.
2024-10-24T12:22:05,445051+00:00 systemd[1]: kmod-static-nodes.service - Create List of Static Device Nodes was skipped because of an unmet condition check (ConditionFileNotEmpty=/lib/modules/6.1.112-122.189.amzn2023.aarch64/modules.devname).
2024-10-24T12:22:05,445965+00:00 systemd[1]: Started rngd.service - Hardware RNG Entropy Gatherer Daemon.
2024-10-24T12:22:05,447278+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2024-10-24T12:22:05,447406+00:00 systemd[1]: systemd-modules-load.service - Load Kernel Modules was skipped because no trigger condition checks were met.
2024-10-24T12:22:05,448181+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2024-10-24T12:22:05,448944+00:00 systemd[1]: Starting systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev...
2024-10-24T12:22:05,449741+00:00 systemd[1]: Starting systemd-vconsole-setup.service - Setup Virtual Console...
2024-10-24T12:22:05,457853+00:00 systemd[1]: Finished systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev.
2024-10-24T12:22:05,474017+00:00 systemd[1]: Finished systemd-vconsole-setup.service - Setup Virtual Console.
2024-10-24T12:22:05,474076+00:00 audit: type=1130 audit(1729772525.909:2): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-vconsole-setup comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:22:05,474185+00:00 systemd[1]: dracut-cmdline-ask.service - dracut ask for additional cmdline parameters was skipped because no trigger condition checks were met.
2024-10-24T12:22:05,475087+00:00 systemd[1]: Starting dracut-cmdline.service - dracut cmdline hook...
2024-10-24T12:22:05,475593+00:00 systemd[1]: Finished systemd-sysctl.service - Apply Kernel Variables.
2024-10-24T12:22:05,475709+00:00 audit: type=1130 audit(1729772525.909:3): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-sysctl comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:22:05,481758+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2024-10-24T12:22:05,483015+00:00 audit: type=1130 audit(1729772525.909:4): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-journald comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:22:05,491952+00:00 audit: type=1130 audit(1729772525.919:5): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-tmpfiles-setup comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:22:05,542373+00:00 audit: type=1130 audit(1729772525.969:6): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=dracut-cmdline comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:22:05,542381+00:00 audit: type=1334 audit(1729772525.969:7): prog-id=6 op=LOAD
2024-10-24T12:22:05,542383+00:00 audit: type=1334 audit(1729772525.969:8): prog-id=7 op=LOAD
2024-10-24T12:22:05,600145+00:00 audit: type=1130 audit(1729772526.029:9): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-udevd comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:22:05,669799+00:00 audit: type=1130 audit(1729772526.099:10): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-udev-trigger comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-24T12:22:05,884923+00:00 XFS (nvme0n1p1): Mounting V5 Filesystem
2024-10-24T12:22:05,971587+00:00 XFS (nvme0n1p1): Ending clean mount
2024-10-24T12:22:06,285618+00:00 systemd-journald[325]: Received SIGTERM from PID 1 (systemd).
2024-10-24T12:22:06,413733+00:00 SELinux:  Class user_namespace not defined in policy.
2024-10-24T12:22:06,413739+00:00 SELinux: the above unknown classes and permissions will be allowed
2024-10-24T12:22:06,416678+00:00 SELinux:  policy capability network_peer_controls=1
2024-10-24T12:22:06,416683+00:00 SELinux:  policy capability open_perms=1
2024-10-24T12:22:06,416684+00:00 SELinux:  policy capability extended_socket_class=1
2024-10-24T12:22:06,416685+00:00 SELinux:  policy capability always_check_network=0
2024-10-24T12:22:06,416686+00:00 SELinux:  policy capability cgroup_seclabel=1
2024-10-24T12:22:06,416687+00:00 SELinux:  policy capability nnp_nosuid_transition=1
2024-10-24T12:22:06,416688+00:00 SELinux:  policy capability genfs_seclabel_symlinks=1
2024-10-24T12:22:06,416689+00:00 SELinux:  policy capability ioctl_skip_cloexec=0
2024-10-24T12:22:06,523140+00:00 systemd[1]: Successfully loaded SELinux policy in 141.145ms.
2024-10-24T12:22:06,575708+00:00 systemd[1]: Relabelled /dev, /dev/shm, /run, /sys/fs/cgroup in 22.809ms.
2024-10-24T12:22:06,583333+00:00 systemd[1]: systemd 252.23-2.amzn2023 running in system mode (+PAM +AUDIT +SELINUX -APPARMOR +IMA +SMACK +SECCOMP -GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN -IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 -BZIP2 -LZ4 +XZ -ZLIB -ZSTD +BPF_FRAMEWORK +XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2024-10-24T12:22:06,583339+00:00 systemd[1]: Detected virtualization amazon.
2024-10-24T12:22:06,583351+00:00 systemd[1]: Detected architecture arm64.
2024-10-24T12:22:06,586187+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-10-24T12:22:06,586271+00:00 systemd[1]: Installed transient /etc/machine-id file.
2024-10-24T12:22:06,649350+00:00 systemd[1]: bpf-lsm: Failed to link program; assuming BPF LSM is not available
2024-10-24T12:22:06,689632+00:00 zram_generator::config[822]: zram0: system has too much memory (3836MB), limit is 800MB, ignoring.
2024-10-24T12:22:06,780998+00:00 systemd[1]: /usr/lib/systemd/system/update-motd.service:40: Invalid CPU quota '25', ignoring.
2024-10-24T12:22:06,957689+00:00 systemd[1]: initrd-switch-root.service: Deactivated successfully.
2024-10-24T12:22:06,957856+00:00 systemd[1]: Stopped initrd-switch-root.service - Switch Root.
2024-10-24T12:22:06,958400+00:00 systemd[1]: systemd-journald.service: Scheduled restart job, restart counter is at 1.
2024-10-24T12:22:06,958845+00:00 systemd[1]: Created slice system-getty.slice - Slice /system/getty.
2024-10-24T12:22:06,959189+00:00 systemd[1]: Created slice system-modprobe.slice - Slice /system/modprobe.
2024-10-24T12:22:06,959512+00:00 systemd[1]: Created slice system-serial\x2dgetty.slice - Slice /system/serial-getty.
2024-10-24T12:22:06,959836+00:00 systemd[1]: Created slice system-sshd\x2dkeygen.slice - Slice /system/sshd-keygen.
2024-10-24T12:22:06,960164+00:00 systemd[1]: Created slice user.slice - User and Session Slice.
2024-10-24T12:22:06,960319+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2024-10-24T12:22:06,960415+00:00 systemd[1]: Started systemd-ask-password-wall.path - Forward Password Requests to Wall Directory Watch.
2024-10-24T12:22:06,960861+00:00 systemd[1]: Set up automount proc-sys-fs-binfmt_misc.automount - Arbitrary Executable File Formats File System Automount Point.
2024-10-24T12:22:06,960885+00:00 systemd[1]: Expecting device dev-ttyS0.device - /dev/ttyS0...
2024-10-24T12:22:06,960911+00:00 systemd[1]: Reached target cryptsetup.target - Local Encrypted Volumes.
2024-10-24T12:22:06,960944+00:00 systemd[1]: Stopped target initrd-switch-root.target - Switch Root.
2024-10-24T12:22:06,960961+00:00 systemd[1]: Stopped target initrd-fs.target - Initrd File Systems.
2024-10-24T12:22:06,960971+00:00 systemd[1]: Stopped target initrd-root-fs.target - Initrd Root File System.
2024-10-24T12:22:06,960983+00:00 systemd[1]: Reached target integritysetup.target - Local Integrity Protected Volumes.
2024-10-24T12:22:06,961022+00:00 systemd[1]: Reached target paths.target - Path Units.
2024-10-24T12:22:06,961075+00:00 systemd[1]: Reached target slices.target - Slice Units.
2024-10-24T12:22:06,961100+00:00 systemd[1]: Reached target swap.target - Swaps.
2024-10-24T12:22:06,961118+00:00 systemd[1]: Reached target veritysetup.target - Local Verity Protected Volumes.
2024-10-24T12:22:06,961617+00:00 systemd[1]: Listening on dm-event.socket - Device-mapper event daemon FIFOs.
2024-10-24T12:22:06,963277+00:00 systemd[1]: Listening on lvm2-lvmpolld.socket - LVM2 poll daemon socket.
2024-10-24T12:22:06,965135+00:00 systemd[1]: Listening on systemd-coredump.socket - Process Core Dump Socket.
2024-10-24T12:22:06,965284+00:00 systemd[1]: Listening on systemd-initctl.socket - initctl Compatibility Named Pipe.
2024-10-24T12:22:06,965569+00:00 systemd[1]: Listening on systemd-networkd.socket - Network Service Netlink Socket.
2024-10-24T12:22:06,966715+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2024-10-24T12:22:06,967085+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2024-10-24T12:22:06,967431+00:00 systemd[1]: Listening on systemd-userdbd.socket - User Database Manager Socket.
2024-10-24T12:22:06,968851+00:00 systemd[1]: Mounting dev-hugepages.mount - Huge Pages File System...
2024-10-24T12:22:06,970474+00:00 systemd[1]: Mounting dev-mqueue.mount - POSIX Message Queue File System...
2024-10-24T12:22:06,972371+00:00 systemd[1]: Mounting sys-kernel-debug.mount - Kernel Debug File System...
2024-10-24T12:22:06,973561+00:00 systemd[1]: Mounting sys-kernel-tracing.mount - Kernel Trace File System...
2024-10-24T12:22:06,974849+00:00 systemd[1]: Mounting tmp.mount - Temporary Directory /tmp...
2024-10-24T12:22:06,974935+00:00 systemd[1]: auth-rpcgss-module.service - Kernel Module supporting RPCSEC_GSS was skipped because of an unmet condition check (ConditionPathExists=/etc/krb5.keytab).
2024-10-24T12:22:06,976278+00:00 systemd[1]: Starting kmod-static-nodes.service - Create List of Static Device Nodes...
2024-10-24T12:22:06,977486+00:00 systemd[1]: Starting lvm2-monitor.service - Monitoring of LVM2 mirrors, snapshots etc. using dmeventd or progress polling...
2024-10-24T12:22:06,978693+00:00 systemd[1]: Starting modprobe@configfs.service - Load Kernel Module configfs...
2024-10-24T12:22:06,979893+00:00 systemd[1]: Starting modprobe@dm_mod.service - Load Kernel Module dm_mod...
2024-10-24T12:22:06,981063+00:00 systemd[1]: Starting modprobe@drm.service - Load Kernel Module drm...
2024-10-24T12:22:06,982331+00:00 systemd[1]: Starting modprobe@efi_pstore.service - Load Kernel Module efi_pstore...
2024-10-24T12:22:06,983537+00:00 systemd[1]: Starting modprobe@fuse.service - Load Kernel Module fuse...
2024-10-24T12:22:06,988305+00:00 systemd[1]: Starting modprobe@loop.service - Load Kernel Module loop...
2024-10-24T12:22:06,989580+00:00 systemd[1]: Starting nfs-convert.service - Preprocess NFS configuration convertion...
2024-10-24T12:22:06,990988+00:00 systemd[1]: Starting systemd-fsck-root.service - File System Check on Root Device...
2024-10-24T12:22:06,991068+00:00 systemd[1]: Stopped systemd-journald.service - Journal Service.
2024-10-24T12:22:06,994285+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2024-10-24T12:22:06,996275+00:00 systemd[1]: Starting systemd-modules-load.service - Load Kernel Modules...
2024-10-24T12:22:06,998314+00:00 systemd[1]: Starting systemd-network-generator.service - Generate network units from Kernel command line...
2024-10-24T12:22:07,000291+00:00 systemd[1]: Starting systemd-udev-trigger.service - Coldplug All udev Devices...
2024-10-24T12:22:07,002070+00:00 systemd[1]: Mounted dev-hugepages.mount - Huge Pages File System.
2024-10-24T12:22:07,002188+00:00 systemd[1]: Mounted dev-mqueue.mount - POSIX Message Queue File System.
2024-10-24T12:22:07,002259+00:00 systemd[1]: Mounted sys-kernel-debug.mount - Kernel Debug File System.
2024-10-24T12:22:07,002322+00:00 systemd[1]: Mounted sys-kernel-tracing.mount - Kernel Trace File System.
2024-10-24T12:22:07,002392+00:00 systemd[1]: Mounted tmp.mount - Temporary Directory /tmp.
2024-10-24T12:22:07,006248+00:00 systemd[1]: Finished kmod-static-nodes.service - Create List of Static Device Nodes.
2024-10-24T12:22:07,006615+00:00 systemd[1]: modprobe@drm.service: Deactivated successfully.
2024-10-24T12:22:07,006766+00:00 systemd[1]: Finished modprobe@drm.service - Load Kernel Module drm.
2024-10-24T12:22:07,007327+00:00 systemd[1]: nfs-convert.service: Deactivated successfully.
2024-10-24T12:22:07,007492+00:00 systemd[1]: Finished nfs-convert.service - Preprocess NFS configuration convertion.
2024-10-24T12:22:07,008791+00:00 systemd[1]: modprobe@efi_pstore.service: Deactivated successfully.
2024-10-24T12:22:07,008945+00:00 systemd[1]: Finished modprobe@efi_pstore.service - Load Kernel Module efi_pstore.
2024-10-24T12:22:07,014679+00:00 systemd[1]: Finished systemd-network-generator.service - Generate network units from Kernel command line.
2024-10-24T12:22:07,015747+00:00 systemd[1]: Finished systemd-modules-load.service - Load Kernel Modules.
2024-10-24T12:22:07,017225+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2024-10-24T12:22:07,033009+00:00 systemd[1]: modprobe@configfs.service: Deactivated successfully.
2024-10-24T12:22:07,033176+00:00 systemd[1]: Finished modprobe@configfs.service - Load Kernel Module configfs.
2024-10-24T12:22:07,035065+00:00 systemd[1]: Mounting sys-kernel-config.mount - Kernel Configuration File System...
2024-10-24T12:22:07,038451+00:00 systemd[1]: Mounted sys-kernel-config.mount - Kernel Configuration File System.
2024-10-24T12:22:07,041983+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2024-10-24T12:22:07,053521+00:00 loop: module loaded
2024-10-24T12:22:07,055178+00:00 fuse: init (API version 7.38)
2024-10-24T12:22:07,056192+00:00 device-mapper: core: CONFIG_IMA_DISABLE_HTABLE is disabled. Duplicate IMA measurements will not be recorded in the IMA log.
2024-10-24T12:22:07,058272+00:00 device-mapper: uevent: version 1.0.3
2024-10-24T12:22:07,063093+00:00 device-mapper: ioctl: 4.47.0-ioctl (2022-07-28) initialised: dm-devel@redhat.com
2024-10-24T12:22:07,132011+00:00 systemd-journald[844]: Received client request to flush runtime journal.
2024-10-24T12:22:07,469860+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0C:00/input/input0
2024-10-24T12:22:07,484729+00:00 ACPI: button: Power Button [PWRB]
2024-10-24T12:22:07,485191+00:00 input: Sleep Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0E:00/input/input1
2024-10-24T12:22:07,488201+00:00 ACPI: \_SB_.PCI0.GSI1: Enabled at IRQ 36
2024-10-24T12:22:07,488629+00:00 ena 0000:00:05.0: Elastic Network Adapter (ENA) v2.13.0g
2024-10-24T12:22:07,489152+00:00 ena 0000:00:05.0: enabling device (0010 -> 0012)
2024-10-24T12:22:07,489306+00:00 ACPI: button: Sleep Button [SLPB]
2024-10-24T12:22:07,502057+00:00 ena 0000:00:05.0: ENA device version: 0.10
2024-10-24T12:22:07,502514+00:00 ena 0000:00:05.0: ENA controller version: 0.0.1 implementation version 1
2024-10-24T12:22:07,583391+00:00 ena 0000:00:05.0: LLQ is not supported Fallback to host mode policy.
2024-10-24T12:22:07,598681+00:00 ena 0000:00:05.0: Elastic Network Adapter (ENA) found at mem 80004000, mac addr 0a:0e:f7:20:64:bf
2024-10-24T12:22:07,683778+00:00 ena 0000:00:05.0 ens5: renamed from eth0
2024-10-24T12:22:08,094079+00:00 RPC: Registered named UNIX socket transport module.
2024-10-24T12:22:08,094578+00:00 RPC: Registered udp transport module.
2024-10-24T12:22:08,094953+00:00 RPC: Registered tcp transport module.
2024-10-24T12:22:08,095339+00:00 RPC: Registered tcp NFSv4.1 backchannel transport module.
2024-10-24T12:22:08,318602+00:00 ena 0000:00:05.0 ens5: Local page cache is disabled for less than 16 channels
2024-10-24T12:22:30,225645+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:22:30,233378+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:22:31,192782+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eni64f17778e51: link becomes ready
2024-10-24T12:22:33,310624+00:00 pci 0000:00:06.0: [1d0f:ec20] type 00 class 0x020000
2024-10-24T12:22:33,311205+00:00 pci 0000:00:06.0: reg 0x10: [mem 0x00000000-0x00003fff]
2024-10-24T12:22:33,311908+00:00 pci 0000:00:06.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-24T12:22:33,312717+00:00 pci 0000:00:06.0: BAR 0: assigned [mem 0x8000c000-0x8000ffff]
2024-10-24T12:22:33,313598+00:00 ena 0000:00:06.0: enabling device (0000 -> 0002)
2024-10-24T12:22:33,322950+00:00 ena 0000:00:06.0: ENA device version: 0.10
2024-10-24T12:22:33,323392+00:00 ena 0000:00:06.0: ENA controller version: 0.0.1 implementation version 1
2024-10-24T12:22:33,402821+00:00 ena 0000:00:06.0: LLQ is not supported Fallback to host mode policy.
2024-10-24T12:22:33,414270+00:00 ena 0000:00:06.0: Elastic Network Adapter (ENA) found at mem 8000c000, mac addr 0a:02:e0:ac:4a:4f
2024-10-24T12:22:33,452979+00:00 ena 0000:00:06.0 ens6: renamed from eth0
2024-10-24T12:22:33,505326+00:00 ena 0000:00:06.0 ens6: Local page cache is disabled for less than 16 channels
2024-10-24T12:29:25,392646+00:00 Initializing XFRM netlink socket
2024-10-24T12:29:28,134532+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): cilium_net: link becomes ready
2024-10-24T12:29:28,135173+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): cilium_host: link becomes ready
2024-10-24T12:29:29,100551+00:00 cilium_vxlan: Caught tx_queue_len zero misconfig
2024-10-24T12:29:29,347022+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2024-10-24T12:29:31,806302+00:00 eth0: renamed from tmpe77e9
2024-10-24T12:29:31,876448+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:29:31,877005+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcb4d6e8c955a1: link becomes ready
2024-10-24T12:29:31,931825+00:00 eth0: renamed from tmp5e107
2024-10-24T12:29:31,975770+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc73245cb60a6d: link becomes ready
2024-10-24T12:36:51,928899+00:00 eth0: renamed from tmpaaa9a
2024-10-24T12:36:51,987989+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:36:51,988544+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc4d660fe7c2e4: link becomes ready
2024-10-24T12:41:28,230488+00:00 eth0: renamed from tmp81a4d
2024-10-24T12:41:28,269491+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:41:28,270070+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc1f8b60d66146: link becomes ready
2024-10-24T12:48:21,457337+00:00 eth0: renamed from tmp6f9d0
2024-10-24T12:48:21,502934+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-24T12:48:21,503495+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc4bdf34c3e71d: link becomes ready
2024-10-24T12:48:21,541945+00:00 eth0: renamed from tmpc0139
2024-10-24T12:48:21,631781+00:00 eth0: renamed from tmp0c411
2024-10-24T12:48:21,671179+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc54d70be2f263: link becomes ready
2024-10-24T12:48:21,677401+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcf9c02adef2ff: link becomes ready
2024-10-24T12:54:21,903699+00:00 printk: dmesg (16033): Attempt to access syslog with CAP_SYS_ADMIN but no CAP_SYSLOG (deprecated).
