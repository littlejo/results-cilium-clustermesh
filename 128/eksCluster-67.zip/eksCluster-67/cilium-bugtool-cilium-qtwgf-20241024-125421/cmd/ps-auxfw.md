USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3220  0.0  0.4 1240432 16420 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3255  0.0  0.0   6408  1644 ?        R    12:54   0:00  \_ ps auxfw
root        3257  0.0  0.0   3728   488 ?        R    12:54   0:00  \_ bash -c hostname
root           1  4.9  7.1 1539060 282828 ?      Ssl  12:29   1:14 cilium-agent --config-dir=/tmp/cilium/config-map
root         417  0.3  0.2 1229488 9040 ?        Sl   12:29   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
