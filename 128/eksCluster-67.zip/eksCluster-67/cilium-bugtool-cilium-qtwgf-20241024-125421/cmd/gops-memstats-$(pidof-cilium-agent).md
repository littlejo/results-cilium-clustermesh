alloc: 94.40MB (98990792 bytes)
total-alloc: 3.07GB (3295842248 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 74995859
frees: 74116426
heap-alloc: 94.40MB (98990792 bytes)
heap-sys: 176.57MB (185147392 bytes)
heap-idle: 49.39MB (51789824 bytes)
heap-in-use: 127.18MB (133357568 bytes)
heap-released: 18.55MB (19456000 bytes)
heap-objects: 879433
stack-in-use: 35.41MB (37126144 bytes)
stack-sys: 35.41MB (37126144 bytes)
stack-mspan-inuse: 2.10MB (2206080 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1005.70KB (1029841 bytes)
gc-sys: 5.51MB (5776528 bytes)
next-gc: when heap-alloc >= 146.45MB (153565752 bytes)
last-gc: 2024-10-24 12:53:55.355226846 +0000 UTC
gc-pause-total: 13.119176ms
gc-pause: 775094
gc-pause-end: 1729774435355226846
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006116120484804786
enable-gc: true
debug-gc: false
