IP ADDRESS         LOCAL ENDPOINT INFO
10.67.0.91:0       id=624   sec_id=4     flags=0x0000 ifindex=10  mac=E6:29:53:2C:FD:FB nodemac=EE:37:6C:42:0D:AC     
10.67.0.235:0      id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC   
10.67.0.145:0      id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63   
10.67.0.18:0       id=1571  sec_id=4468415 flags=0x0000 ifindex=12  mac=DE:C0:05:1F:A7:FA nodemac=62:D9:D1:B6:B0:3A   
10.67.0.50:0       id=2604  sec_id=4501785 flags=0x0000 ifindex=18  mac=AE:5B:12:E6:05:43 nodemac=E2:53:A0:DD:92:CF   
10.67.0.199:0      (localhost)                                                                                        
10.67.0.10:0       id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D   
172.31.214.255:0   (localhost)                                                                                        
172.31.227.110:0   (localhost)                                                                                        
10.67.0.116:0      id=1858  sec_id=4468415 flags=0x0000 ifindex=14  mac=AA:F0:14:76:88:09 nodemac=F2:12:E7:CE:8C:1C   
