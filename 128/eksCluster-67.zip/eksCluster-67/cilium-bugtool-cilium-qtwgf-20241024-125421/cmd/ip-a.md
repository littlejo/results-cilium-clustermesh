1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:0e:f7:20:64:bf brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.214.255/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3471sec preferred_lft 3471sec
    inet6 fe80::80e:f7ff:fe20:64bf/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:02:e0:ac:4a:4f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.227.110/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::802:e0ff:feac:4a4f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:10:21:ac:db:3d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7010:21ff:feac:db3d/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:63:b6:c1:6d:ed brd ff:ff:ff:ff:ff:ff
    inet 10.67.0.199/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c863:b6ff:fec1:6ded/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether b2:98:66:49:4c:23 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b098:66ff:fe49:4c23/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:37:6c:42:0d:ac brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::ec37:6cff:fe42:dac/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb4d6e8c955a1@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:d9:d1:b6:b0:3a brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::60d9:d1ff:feb6:b03a/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc73245cb60a6d@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:12:e7:ce:8c:1c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f012:e7ff:fece:8c1c/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc1f8b60d66146@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:53:a0:dd:92:cf brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e053:a0ff:fedd:92cf/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc4bdf34c3e71d@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:c0:ca:28:3d:4d brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::64c0:caff:fe28:3d4d/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc54d70be2f263@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:92:34:0f:6e:63 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::e492:34ff:fe0f:6e63/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcf9c02adef2ff@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:59:a3:1e:57:ac brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::859:a3ff:fe1e:57ac/64 scope link 
       valid_lft forever preferred_lft forever
