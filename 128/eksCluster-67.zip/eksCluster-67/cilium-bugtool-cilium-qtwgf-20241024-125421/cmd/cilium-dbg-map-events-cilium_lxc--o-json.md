{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.157Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.721Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.733Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.782Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.788Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.819Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.033Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.034Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.098Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.138Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.149Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.786Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.805Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.853Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.875Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.893Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.087Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.089Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.160Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.180Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.212Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.702Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.710Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.742Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.754Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.801Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.825Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.839Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.084Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.088Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.165Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.198Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.215Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.826Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.827Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.885Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.887Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.931Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.960Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.975Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.234Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.244Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.288Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.308Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.340Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.790Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.800Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.849Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.860Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.887Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.112Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.134Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.167Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.190Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.219Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.658Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.715Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.722Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.767Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.799Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.802Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.038Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.067Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.123Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.159Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.169Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.654Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.697Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.805Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.812Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.842Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.005Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.014Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.081Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.090Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.142Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.560Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.609Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.617Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.661Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.672Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.702Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.931Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.937Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.992Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.998Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.033Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.439Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.473Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.485Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.532Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.535Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.570Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.888Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.917Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.971Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.979Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.013Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.350Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.354Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.396Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.403Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.440Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.447Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.696Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.741Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.759Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.811Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.815Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.148Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.180Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.199Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.236Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.240Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.275Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.497Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.510Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.522Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.556Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.306Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.311Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.392Z",
  "value": "id=995   sec_id=4457369 flags=0x0000 ifindex=24  mac=F6:0D:52:A0:73:44 nodemac=0A:59:A3:1E:57:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.423Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.461Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.709Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.713Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.423Z",
  "value": "id=1436  sec_id=4456692 flags=0x0000 ifindex=20  mac=82:26:DA:4E:99:10 nodemac=66:C0:CA:28:3D:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.431Z",
  "value": "id=1924  sec_id=4466109 flags=0x0000 ifindex=22  mac=D2:6C:AF:D6:FA:0D nodemac=E6:92:34:0F:6E:63"
}

