Endpoint ID: 624
Path: /sys/fs/bpf/tc/globals/cilium_policy_00624

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6164966   76278     0        
Allow    Ingress     1          ANY          NONE         disabled    64222     779       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 995
Path: /sys/fs/bpf/tc/globals/cilium_policy_00995

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    353824   4131      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1436
Path: /sys/fs/bpf/tc/globals/cilium_policy_01436

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1571
Path: /sys/fs/bpf/tc/globals/cilium_policy_01571

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2594     24        0        
Allow    Ingress     1          ANY          NONE         disabled    142107   1636      0        
Allow    Egress      0          ANY          NONE         disabled    19919    222       0        


Endpoint ID: 1618
Path: /sys/fs/bpf/tc/globals/cilium_policy_01618

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1858
Path: /sys/fs/bpf/tc/globals/cilium_policy_01858

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3302     36        0        
Allow    Ingress     1          ANY          NONE         disabled    142862   1643      0        
Allow    Egress      0          ANY          NONE         disabled    19036    211       0        


Endpoint ID: 1924
Path: /sys/fs/bpf/tc/globals/cilium_policy_01924

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2604
Path: /sys/fs/bpf/tc/globals/cilium_policy_02604

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5366954   56070     0        
Allow    Ingress     1          ANY          NONE         disabled    5370987   56664     0        
Allow    Egress      0          ANY          NONE         disabled    6422327   64963     0        


