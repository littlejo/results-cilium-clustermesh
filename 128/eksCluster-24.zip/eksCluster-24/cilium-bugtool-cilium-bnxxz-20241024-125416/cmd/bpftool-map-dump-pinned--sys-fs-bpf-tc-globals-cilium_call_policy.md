key: f3 00 00 00  value: 18 02 00 00
key: 0e 02 00 00  value: 0a 0d 00 00
key: 51 04 00 00  value: 03 02 00 00
key: 68 04 00 00  value: cb 0c 00 00
key: f3 04 00 00  value: 71 02 00 00
key: 07 0a 00 00  value: 0e 0d 00 00
key: 9f 0c 00 00  value: fa 01 00 00
Found 7 elements
