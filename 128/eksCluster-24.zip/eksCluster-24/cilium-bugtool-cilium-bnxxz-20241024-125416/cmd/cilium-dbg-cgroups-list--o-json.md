[
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod19da4e22_b6ba_40b2_b001_14dd5cf2b9d3.slice/cri-containerd-0bc364de01808fd61c58dbafbf4455c873df7369e1aff1741981ee3eb20b293f.scope"
      }
    ],
    "ips": [
      "10.24.0.185"
    ],
    "name": "client2-57cf4468f-86gf9",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod398a7048_9aaa_455d_8cde_bbe45558ac25.slice/cri-containerd-ba22d0cde1b76697a0ac8752c9993a12b731cf0c8e731745b8849b00510d9e35.scope"
      }
    ],
    "ips": [
      "10.24.0.192"
    ],
    "name": "client-974f6c69d-dqqnr",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c00511e_3448_4eae_b7a4_5871889275ab.slice/cri-containerd-58623ea372d406fd4f7d9662b74cd8e050065a2eedb8669622d232c5d118d549.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c00511e_3448_4eae_b7a4_5871889275ab.slice/cri-containerd-9fb975650386bd96ce353e453944604d33753b9f4208ca95eaa74f033f179a3a.scope"
      }
    ],
    "ips": [
      "10.24.0.144"
    ],
    "name": "echo-same-node-86d9cc975c-j7s6d",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfea98533_cf04_44c5_9178_60da91f1e39c.slice/cri-containerd-b94ffe1b912d133d3264191b6f5c25ff4ea9a57bf2a061a32ffa57535fa9288f.scope"
      }
    ],
    "ips": [
      "10.24.0.247"
    ],
    "name": "coredns-cc6ccd49c-rlv7p",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc6ad896a_6574_47aa_9426_08b773a5a9d1.slice/cri-containerd-6055ca2f10879a5185df5721bbf46abdf331bc8a34e9490e2adae084e121c5c6.scope"
      }
    ],
    "ips": [
      "10.24.0.244"
    ],
    "name": "coredns-cc6ccd49c-v7b7p",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1508e8b8_353f_4775_a287_5ebc9ecd8c6b.slice/cri-containerd-4cb3f862b2509ebb2231bf43ca30d83d7097fa8a1bff52eebc4a0b8ee190b545.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1508e8b8_353f_4775_a287_5ebc9ecd8c6b.slice/cri-containerd-ab7b559127ead6e8dbe27c8f843fd02f17ec68f9ed2ab5b3d6d4de76a800bce2.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1508e8b8_353f_4775_a287_5ebc9ecd8c6b.slice/cri-containerd-df8956a88f3e3e4aa1a26b9dfc4e3f69df2af3686b6840106ec236adf32545f6.scope"
      }
    ],
    "ips": [
      "10.24.0.213"
    ],
    "name": "clustermesh-apiserver-7fd5c47c9f-896gb",
    "namespace": "kube-system"
  }
]

