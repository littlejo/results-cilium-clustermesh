USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3296  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3291  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3285  0.0  0.4 1240176 16304 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3319  0.0  0.0   6408  1636 ?        R    12:54   0:00  \_ ps auxfw
root        3320  0.0  0.4 1240176 16304 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root        3274  0.0  0.3 1229640 13376 ?       Rsl  12:54   0:00 /bin/gops stack 1
root           1  3.7  7.3 1538804 290088 ?      Ssl  12:25   1:04 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.2  0.2 1229744 8876 ?        Sl   12:25   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
