top - 12:54:18 up 33 min,  0 users,  load average: 0.51, 0.50, 0.27
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s):  0.0 us, 34.5 sy,  0.0 ni, 65.5 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    288.9 free,   1051.3 used,   2495.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2603.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3285 root      20   0 1240432  16508  11356 S   6.7   0.4   0:00.03 cilium-+
      1 root      20   0 1538804 290088  78396 S   0.0   7.4   1:04.95 cilium-+
    395 root      20   0 1229744   8876   2864 S   0.0   0.2   0:04.12 cilium-+
   3291 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3296 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3330 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3348 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
