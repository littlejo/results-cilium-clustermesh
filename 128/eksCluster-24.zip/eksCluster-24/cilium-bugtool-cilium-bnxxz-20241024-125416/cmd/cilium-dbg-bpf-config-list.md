KEY             VALUE
AgentLiveness   2026558168560
UTimeOffset     3378461839843750
