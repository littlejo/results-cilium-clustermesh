 12:54:18 up 33 min,  0 users,  load average: 0.51, 0.50, 0.27
