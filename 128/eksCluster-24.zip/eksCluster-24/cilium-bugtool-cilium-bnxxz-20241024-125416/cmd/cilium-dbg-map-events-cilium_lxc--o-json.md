{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.710Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:32.757Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.273Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.275Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.313Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.332Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.351Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.622Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.627Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.677Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.685Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.727Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.437Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.452Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.497Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.513Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.576Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.826Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.827Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.879Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.894Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.940Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.462Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.463Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.508Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.525Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.558Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.569Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.596Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.807Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.813Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.870Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.874Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.918Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.506Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.522Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.563Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.568Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.598Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.792Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.798Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.908Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.941Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.952Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.373Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.376Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.433Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.434Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.468Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.664Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.695Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.719Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.773Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.778Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.140Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.168Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.179Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.220Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.220Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.238Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.492Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.496Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.545Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.562Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.592Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.933Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.969Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.976Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.007Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.053Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.064Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.332Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.337Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.379Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.383Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.432Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.777Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.814Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.845Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.866Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.888Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.909Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.131Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.132Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.241Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.307Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.317Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.640Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.689Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.694Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.739Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.752Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.782Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.008Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.036Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.067Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.125Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.132Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.462Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.532Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.544Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.585Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.601Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.621Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.809Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.827Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.864Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.912Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.930Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.217Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.330Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.332Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.391Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.395Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.426Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.630Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.640Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.672Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.689Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.395Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.399Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.431Z",
  "value": "id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.444Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.470Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.746Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.752Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.438Z",
  "value": "id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.446Z",
  "value": "id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5"
}

