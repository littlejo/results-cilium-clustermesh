CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a09152c_b862_4eba_b3a9_0225a84cc97b.slice/cri-containerd-6b0380640050d37bcc2df813bb7c700654b9f17b0a6ffa6e3e7f7d05ec60475d.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a09152c_b862_4eba_b3a9_0225a84cc97b.slice/cri-containerd-a63bd87a2e166a9810ce6f6de4af6025ea4e683c7e1991d1bd17ec5dc809e0fa.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfea98533_cf04_44c5_9178_60da91f1e39c.slice/cri-containerd-b94ffe1b912d133d3264191b6f5c25ff4ea9a57bf2a061a32ffa57535fa9288f.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfea98533_cf04_44c5_9178_60da91f1e39c.slice/cri-containerd-5922d4f7728a48faa5d5f68958c556692e55fdf551b8766860c28b8ae09b1bf6.scope
    530      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc6ad896a_6574_47aa_9426_08b773a5a9d1.slice/cri-containerd-6055ca2f10879a5185df5721bbf46abdf331bc8a34e9490e2adae084e121c5c6.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc6ad896a_6574_47aa_9426_08b773a5a9d1.slice/cri-containerd-f24a9e561ee3406b5cb8afb99096e97d87e656395e8bbcf970a0778e3783ea1b.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9b35c2c3_ac0c_4f6c_87bb_95c2cd4d72bb.slice/cri-containerd-3146b393d2be53175f0a997f12163021b8516bd9ae90cc64220438e98842ec1a.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9b35c2c3_ac0c_4f6c_87bb_95c2cd4d72bb.slice/cri-containerd-891afaca97c8b3664af82386c3af668f011461e37103066c31144e99ef0434f0.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod19da4e22_b6ba_40b2_b001_14dd5cf2b9d3.slice/cri-containerd-70d84934c12a9d3835dd903976be9749aad84ff83401c10bbaaae3f9aa5b04ae.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod19da4e22_b6ba_40b2_b001_14dd5cf2b9d3.slice/cri-containerd-0bc364de01808fd61c58dbafbf4455c873df7369e1aff1741981ee3eb20b293f.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod69e89503_a452_4d49_8ece_79885c5d2137.slice/cri-containerd-dd67b6706beb207a067fbc92348390f79b79c7da8d414865ad201ffda2e2b6fa.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod69e89503_a452_4d49_8ece_79885c5d2137.slice/cri-containerd-b7de1cd64ee24aae97d656dff0e896456aa2078e4ce56946cc9a4d0c32a6e334.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod398a7048_9aaa_455d_8cde_bbe45558ac25.slice/cri-containerd-ba22d0cde1b76697a0ac8752c9993a12b731cf0c8e731745b8849b00510d9e35.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod398a7048_9aaa_455d_8cde_bbe45558ac25.slice/cri-containerd-b802124d516f6c019808bbd509d963636f539b7875d1ca80177f05ccdc4c7861.scope
    684      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c00511e_3448_4eae_b7a4_5871889275ab.slice/cri-containerd-58623ea372d406fd4f7d9662b74cd8e050065a2eedb8669622d232c5d118d549.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c00511e_3448_4eae_b7a4_5871889275ab.slice/cri-containerd-19fba92d8a9833698b99d97f2fd28e9ed695ed6b321f0f05ae4dccb52213f0b0.scope
    688      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c00511e_3448_4eae_b7a4_5871889275ab.slice/cri-containerd-9fb975650386bd96ce353e453944604d33753b9f4208ca95eaa74f033f179a3a.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6b53441_7750_4bdf_9cd8_3543d133ac79.slice/cri-containerd-30ca8d28a883612e0573e6786587670e591b39d5c97631fa50627f325dd04e12.scope
    115      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6b53441_7750_4bdf_9cd8_3543d133ac79.slice/cri-containerd-4b24582f5f50ede90ecfbfdaeac238ef023cf27fe9fc7ecc5eb43723b6035829.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1508e8b8_353f_4775_a287_5ebc9ecd8c6b.slice/cri-containerd-184dc675f2062744654becec81ae313fe1e9abcb2c2963c68d671fa1470c6c75.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1508e8b8_353f_4775_a287_5ebc9ecd8c6b.slice/cri-containerd-ab7b559127ead6e8dbe27c8f843fd02f17ec68f9ed2ab5b3d6d4de76a800bce2.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1508e8b8_353f_4775_a287_5ebc9ecd8c6b.slice/cri-containerd-df8956a88f3e3e4aa1a26b9dfc4e3f69df2af3686b6840106ec236adf32545f6.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1508e8b8_353f_4775_a287_5ebc9ecd8c6b.slice/cri-containerd-4cb3f862b2509ebb2231bf43ca30d83d7097fa8a1bff52eebc4a0b8ee190b545.scope
    650      cgroup_device   multi                                          
