IP ADDRESS         LOCAL ENDPOINT INFO
172.31.178.110:0   (localhost)                                                                                        
10.24.0.247:0      id=3231  sec_id=1671966 flags=0x0000 ifindex=14  mac=F2:0F:38:18:3C:91 nodemac=C6:38:1A:53:7B:1F   
10.24.0.244:0      id=243   sec_id=1671966 flags=0x0000 ifindex=12  mac=76:0F:58:9E:AC:98 nodemac=A6:E0:D4:6D:F0:E3   
10.24.0.62:0       (localhost)                                                                                        
10.24.0.185:0      id=2567  sec_id=1673992 flags=0x0000 ifindex=24  mac=FE:11:3A:9F:B7:EB nodemac=76:E1:19:10:63:1F   
172.31.182.187:0   (localhost)                                                                                        
10.24.0.141:0      id=1105  sec_id=4     flags=0x0000 ifindex=10  mac=56:7A:CF:7B:FA:21 nodemac=F6:F9:A9:EC:51:7E     
10.24.0.192:0      id=526   sec_id=1640820 flags=0x0000 ifindex=20  mac=A2:B6:A4:69:12:39 nodemac=D6:84:37:3C:32:C5   
10.24.0.144:0      id=1128  sec_id=1666670 flags=0x0000 ifindex=22  mac=26:02:7B:BC:8C:4E nodemac=8E:AE:97:C5:5A:CF   
10.24.0.213:0      id=1267  sec_id=1692266 flags=0x0000 ifindex=18  mac=0A:62:58:E1:CA:C6 nodemac=0E:2A:80:4A:61:A3   
