1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:7c:ee:57:91:51 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.182.187/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3414sec preferred_lft 3414sec
    inet6 fe80::47c:eeff:fe57:9151/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:5f:d4:cc:d5:ad brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.178.110/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::45f:d4ff:fecc:d5ad/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:60:04:33:08:ad brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5860:4ff:fe33:8ad/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:48:13:d1:4d:6f brd ff:ff:ff:ff:ff:ff
    inet 10.24.0.62/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::2448:13ff:fed1:4d6f/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 1a:0a:60:ea:97:7f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::180a:60ff:feea:977f/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:f9:a9:ec:51:7e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f4f9:a9ff:feec:517e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc089910835afc@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:e0:d4:6d:f0:e3 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a4e0:d4ff:fe6d:f0e3/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc1488e287431d@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:38:1a:53:7b:1f brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::c438:1aff:fe53:7b1f/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf93ad4aff3f9@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:2a:80:4a:61:a3 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c2a:80ff:fe4a:61a3/64 scope link 
       valid_lft forever preferred_lft forever
20: lxce485331ce5ed@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:84:37:3c:32:c5 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d484:37ff:fe3c:32c5/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc4df451525ade@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:ae:97:c5:5a:cf brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::8cae:97ff:fec5:5acf/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc24dc8e3dca2b@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:e1:19:10:63:1f brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::74e1:19ff:fe10:631f/64 scope link 
       valid_lft forever preferred_lft forever
