Endpoint ID: 243
Path: /sys/fs/bpf/tc/globals/cilium_policy_00243

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4370     45        0        
Allow    Ingress     1          ANY          NONE         disabled    165398   1899      0        
Allow    Egress      0          ANY          NONE         disabled    21064    237       0        


Endpoint ID: 526
Path: /sys/fs/bpf/tc/globals/cilium_policy_00526

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1105
Path: /sys/fs/bpf/tc/globals/cilium_policy_01105

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6230094   77012     0        
Allow    Ingress     1          ANY          NONE         disabled    69374     836       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1128
Path: /sys/fs/bpf/tc/globals/cilium_policy_01128

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377715   4401      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1267
Path: /sys/fs/bpf/tc/globals/cilium_policy_01267

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6129957   61032     0        
Allow    Ingress     1          ANY          NONE         disabled    5282061   55725     0        
Allow    Egress      0          ANY          NONE         disabled    6197819   61841     0        


Endpoint ID: 1532
Path: /sys/fs/bpf/tc/globals/cilium_policy_01532

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2567
Path: /sys/fs/bpf/tc/globals/cilium_policy_02567

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3231
Path: /sys/fs/bpf/tc/globals/cilium_policy_03231

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1526     15        0        
Allow    Ingress     1          ANY          NONE         disabled    165596   1902      0        
Allow    Egress      0          ANY          NONE         disabled    21673    244       0        


