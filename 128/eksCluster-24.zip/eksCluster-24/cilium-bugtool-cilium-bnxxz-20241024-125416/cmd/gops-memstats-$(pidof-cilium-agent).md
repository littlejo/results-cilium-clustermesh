alloc: 136.27MB (142891592 bytes)
total-alloc: 3.15GB (3385670952 bytes)
sys: 215.07MB (225518932 bytes)
lookups: 0
mallocs: 76077063
frees: 74661391
heap-alloc: 136.27MB (142891592 bytes)
heap-sys: 168.48MB (176668672 bytes)
heap-idle: 15.76MB (16523264 bytes)
heap-in-use: 152.73MB (160145408 bytes)
heap-released: 2.00MB (2097152 bytes)
heap-objects: 1415672
stack-in-use: 35.47MB (37191680 bytes)
stack-sys: 35.47MB (37191680 bytes)
stack-mspan-inuse: 2.37MB (2485280 bytes)
stack-mspan-sys: 2.74MB (2872320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 777.56KB (796217 bytes)
gc-sys: 5.52MB (5792816 bytes)
next-gc: when heap-alloc >= 147.80MB (154974376 bytes)
last-gc: 2024-10-24 12:54:07.251221865 +0000 UTC
gc-pause-total: 12.743083ms
gc-pause: 81511
gc-pause-end: 1729774447251221865
num-gc: 102
num-forced-gc: 0
gc-cpu-fraction: 0.0005251211305829523
enable-gc: true
debug-gc: false
