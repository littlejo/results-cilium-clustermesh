Node 0, zone      DMA      3      2      3      2      6      8      9      1      3      3     42 
Node 0, zone   Normal      2      2      0     15     18      3      2      1      5      3      7 
