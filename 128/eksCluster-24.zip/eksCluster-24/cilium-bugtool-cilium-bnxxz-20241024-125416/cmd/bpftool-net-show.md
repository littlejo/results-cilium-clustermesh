xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 571
ens6(5) clsact/ingress cil_from_netdev-ens6 id 578
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 566
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 556
cilium_host(7) clsact/egress cil_from_host-cilium_host id 553
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 517
lxc089910835afc(12) clsact/ingress cil_from_container-lxc089910835afc id 534
lxc1488e287431d(14) clsact/ingress cil_from_container-lxc1488e287431d id 513
lxcf93ad4aff3f9(18) clsact/ingress cil_from_container-lxcf93ad4aff3f9 id 622
lxce485331ce5ed(20) clsact/ingress cil_from_container-lxce485331ce5ed id 3340
lxc4df451525ade(22) clsact/ingress cil_from_container-lxc4df451525ade id 3276
lxc24dc8e3dca2b(24) clsact/ingress cil_from_container-lxc24dc8e3dca2b id 3343

flow_dissector:

netfilter:

