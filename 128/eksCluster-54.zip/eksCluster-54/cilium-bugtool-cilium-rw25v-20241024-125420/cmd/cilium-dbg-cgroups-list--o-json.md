[
  {
    "containers": [
      {
        "cgroup-id": 7592,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e2c2c9a_a993_4d66_bdbd_afb66642e997.slice/cri-containerd-239076b05d51315b190b9c7b11355b62b1879c78778ac4aa9e212973bd6ad520.scope"
      }
    ],
    "ips": [
      "10.54.0.133"
    ],
    "name": "coredns-cc6ccd49c-fphl7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7676,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod280b1bf5_9614_49a4_ac25_c83af24009ac.slice/cri-containerd-04811163dac2f608f7bf5dfa6e4081f12c9ddfbe3edb56eb59c52adba3ff1a70.scope"
      }
    ],
    "ips": [
      "10.54.0.65"
    ],
    "name": "coredns-cc6ccd49c-w8cv4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9200,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd63c7d18_665f_431e_b0d7_0f169791365c.slice/cri-containerd-ba42a5a8d5739f0298765e71ce2948644ecd9a269d78ceeb47010cc360c47a65.scope"
      },
      {
        "cgroup-id": 9284,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd63c7d18_665f_431e_b0d7_0f169791365c.slice/cri-containerd-bdf8a79971c833e421d9492cf97960528e3be1aa81af5c2eabf6effb15c5e48f.scope"
      },
      {
        "cgroup-id": 9116,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd63c7d18_665f_431e_b0d7_0f169791365c.slice/cri-containerd-39cf44eb3a2c8f4a16f54f033e63ae096c10fba5e002bc0141fecc8fae8cdb15.scope"
      }
    ],
    "ips": [
      "10.54.0.115"
    ],
    "name": "clustermesh-apiserver-7ccc6c6bf8-hbh9r",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10040,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3cbdf45_fdef_4119_bfed_135aea53f370.slice/cri-containerd-f8067819754d86122dd47154be24a42ec043e491df63357a9f6fd10d18f58b0c.scope"
      },
      {
        "cgroup-id": 10124,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3cbdf45_fdef_4119_bfed_135aea53f370.slice/cri-containerd-3b021fcea6ce797fe92e77d92c51d63fd312388dc2596b4ddd6bd1dd1c9fbb44.scope"
      }
    ],
    "ips": [
      "10.54.0.169"
    ],
    "name": "echo-same-node-86d9cc975c-rk452",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9872,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6aa1891e_58fc_41f0_be96_f1cbfb847503.slice/cri-containerd-eeca32af7918db0339654d8a9ff8c9907465f73ecbc61ff5579bb8039f28dcce.scope"
      }
    ],
    "ips": [
      "10.54.0.191"
    ],
    "name": "client-974f6c69d-twvnz",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9956,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod02f4ab07_5b14_4d47_8156_e53f7bda6301.slice/cri-containerd-4cee89199c3844fa73e34ed6cd086128e3fb976f161861b0b9ff7365944d93f5.scope"
      }
    ],
    "ips": [
      "10.54.0.29"
    ],
    "name": "client2-57cf4468f-9btgc",
    "namespace": "cilium-test-1"
  }
]

