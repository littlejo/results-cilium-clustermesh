{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.882Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.937Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.939Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.976Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.262Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.270Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.368Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.385Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.409Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.924Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.946Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.980Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.008Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.021Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.332Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.343Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.411Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.424Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.457Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.984Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.988Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.029Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.032Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.076Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.081Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.111Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.333Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.375Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.406Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.442Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.473Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.019Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.023Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.057Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.067Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.111Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.122Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.149Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.381Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.393Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.488Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.515Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.529Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.870Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.880Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.924Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.949Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.993Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.997Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.213Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.246Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.298Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.301Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.352Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.730Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.742Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.787Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.788Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.823Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.053Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.062Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.111Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.119Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.150Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.555Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.661Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.671Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.749Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.750Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.771Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.961Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.963Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.023Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.049Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.073Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.486Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.528Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.529Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.572Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.603Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.620Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.882Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.884Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.945Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.993Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.995Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.370Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.412Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.418Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.460Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.492Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.503Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.797Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.806Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.901Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.935Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.950Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.251Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.307Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.336Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.365Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.417Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.418Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.621Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.622Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.676Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.688Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.718Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.034Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.072Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.073Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.120Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.124Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.160Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.411Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.426Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.486Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.493Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.530Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.127Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.133Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.173Z",
  "value": "id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.191Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.220Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.478Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.490Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:42.138Z",
  "value": "id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:42.140Z",
  "value": "id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2"
}

