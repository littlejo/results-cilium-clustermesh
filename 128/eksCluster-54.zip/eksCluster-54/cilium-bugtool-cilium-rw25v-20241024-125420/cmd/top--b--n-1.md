top - 12:54:22 up 32 min,  0 users,  load average: 0.35, 0.63, 0.39
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 53.3 us, 40.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   3836.2 total,    264.2 free,   1074.5 used,   2497.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2580.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 294472  79168 S  33.3   7.5   1:04.79 cilium-+
    394 root      20   0 1229744  10192   3900 S   0.0   0.3   0:04.25 cilium-+
   3136 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3146 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3149 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3167 root      20   0 1240432  16180  11228 S   0.0   0.4   0:00.03 cilium-+
   3218 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
