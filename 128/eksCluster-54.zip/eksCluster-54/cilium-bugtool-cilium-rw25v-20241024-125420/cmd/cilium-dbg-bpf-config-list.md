KEY             VALUE
AgentLiveness   1990175200612
UTimeOffset     3378461919921875
