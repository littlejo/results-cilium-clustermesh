1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:1f:0a:6b:48:43 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.188.31/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3452sec preferred_lft 3452sec
    inet6 fe80::41f:aff:fe6b:4843/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:8a:a5:d5:88:49 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.182.30/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::48a:a5ff:fed5:8849/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:f7:fd:da:4b:f3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5cf7:fdff:feda:4bf3/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:a9:eb:91:43:56 brd ff:ff:ff:ff:ff:ff
    inet 10.54.0.96/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::74a9:ebff:fe91:4356/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 32:68:06:bb:c8:c8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3068:6ff:febb:c8c8/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:e9:06:9e:ca:37 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::cce9:6ff:fe9e:ca37/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc9c31e97698b6@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:ff:ae:80:8a:8c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e4ff:aeff:fe80:8a8c/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcbcffc53c66c0@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:e4:04:98:32:3e brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::9ce4:4ff:fe98:323e/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf4d8fa2d31df@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:9c:42:09:63:88 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::ec9c:42ff:fe09:6388/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc833dc0264f61@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:88:bd:6a:8d:52 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::1c88:bdff:fe6a:8d52/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc1a03eacb30e6@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:c5:3e:8c:60:e2 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::84c5:3eff:fe8c:60e2/64 scope link 
       valid_lft forever preferred_lft forever
24: lxca120c62ca27e@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:c7:24:71:fa:3d brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::78c7:24ff:fe71:fa3d/64 scope link 
       valid_lft forever preferred_lft forever
