Endpoint ID: 529
Path: /sys/fs/bpf/tc/globals/cilium_policy_00529

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4144     41        0        
Allow    Ingress     1          ANY          NONE         disabled    151631   1745      0        
Allow    Egress      0          ANY          NONE         disabled    20794    232       0        


Endpoint ID: 674
Path: /sys/fs/bpf/tc/globals/cilium_policy_00674

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6218714   77155     0        
Allow    Ingress     1          ANY          NONE         disabled    62006     751       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 818
Path: /sys/fs/bpf/tc/globals/cilium_policy_00818

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1752     19        0        
Allow    Ingress     1          ANY          NONE         disabled    151416   1737      0        
Allow    Egress      0          ANY          NONE         disabled    19049    210       0        


Endpoint ID: 908
Path: /sys/fs/bpf/tc/globals/cilium_policy_00908

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6148094   61915     0        
Allow    Ingress     1          ANY          NONE         disabled    5386796   56891     0        
Allow    Egress      0          ANY          NONE         disabled    6914528   68240     0        


Endpoint ID: 1364
Path: /sys/fs/bpf/tc/globals/cilium_policy_01364

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1564
Path: /sys/fs/bpf/tc/globals/cilium_policy_01564

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1907
Path: /sys/fs/bpf/tc/globals/cilium_policy_01907

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3250
Path: /sys/fs/bpf/tc/globals/cilium_policy_03250

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    382758   4467      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


