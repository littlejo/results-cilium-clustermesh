key: 11 02 00 00  value: 25 02 00 00
key: a2 02 00 00  value: 26 02 00 00
key: 32 03 00 00  value: 10 02 00 00
key: 8c 03 00 00  value: 6c 02 00 00
key: 54 05 00 00  value: 0a 0d 00 00
key: 73 07 00 00  value: 12 0d 00 00
key: b2 0c 00 00  value: db 0c 00 00
Found 7 elements
