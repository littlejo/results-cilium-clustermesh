USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3167  0.0  0.4 1240432 16180 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3207  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3208  0.0  0.0   3728   488 ?        R    12:54   0:00  \_ bash -c hostname
root        3149  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3146  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3140  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root        3136  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3135  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  4.1  7.3 1539060 289192 ?      Ssl  12:28   1:04 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.2  0.2 1229744 10192 ?       Sl   12:28   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
