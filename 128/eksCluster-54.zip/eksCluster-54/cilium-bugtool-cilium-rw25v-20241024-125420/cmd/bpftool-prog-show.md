35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:46+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:21:46+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:21:47+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:21:47+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:47+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:47+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:21:47+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:47+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:21:51+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:04+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name tail_handle_ipv4  tag cf69817bb5325ba0  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
485: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
486: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
487: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:28:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
488: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,101
	btf_id 129
489: sched_cls  name __send_drop_notify  tag 1d3aee36816a7dba  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 130
491: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 132
492: sched_cls  name tail_handle_ipv4_from_host  tag 9692b19cb57ef6d8  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,101
	btf_id 133
493: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,101
	btf_id 134
495: sched_cls  name __send_drop_notify  tag 1d3aee36816a7dba  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 137
497: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 139
498: sched_cls  name tail_handle_ipv4_from_host  tag 9692b19cb57ef6d8  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,103
	btf_id 140
501: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,103
	btf_id 143
502: sched_cls  name __send_drop_notify  tag 1d3aee36816a7dba  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 145
505: sched_cls  name tail_handle_ipv4_from_host  tag 9692b19cb57ef6d8  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,106
	btf_id 148
507: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,106,75
	btf_id 150
508: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,106
	btf_id 151
511: sched_cls  name tail_handle_ipv4_from_host  tag 9692b19cb57ef6d8  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,108
	btf_id 155
513: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,108,75
	btf_id 157
514: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,108
	btf_id 158
515: sched_cls  name __send_drop_notify  tag 1d3aee36816a7dba  gpl
	loaded_at 2024-10-24T12:28:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 159
517: sched_cls  name tail_handle_ipv4_cont  tag d7d6b3318d6b246c  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 163
518: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 165
519: sched_cls  name cil_from_container  tag 5b7ea5c648d86ad3  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 166
524: sched_cls  name tail_ipv4_to_endpoint  tag 86ec693983bcf09f  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 168
526: sched_cls  name tail_ipv4_ct_egress  tag 67901092f28eb1e9  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 172
528: sched_cls  name handle_policy  tag 72812fc3226d3a8e  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 174
529: sched_cls  name __send_drop_notify  tag 2063dec7d5f72ec9  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 176
531: sched_cls  name tail_handle_ipv4  tag 24be80aac50adb51  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 177
533: sched_cls  name tail_ipv4_ct_ingress  tag 911e115c80676c27  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 179
536: sched_cls  name tail_handle_arp  tag b109af15324303f5  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 182
538: sched_cls  name tail_ipv4_ct_egress  tag 67901092f28eb1e9  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 186
540: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 189
541: sched_cls  name cil_from_container  tag 0be729948b78aba4  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 190
542: sched_cls  name tail_handle_ipv4  tag 72d34076726e2601  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 187
543: sched_cls  name tail_handle_arp  tag 820c75926cdc9468  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 192
544: sched_cls  name tail_ipv4_to_endpoint  tag dc7001681d4c451b  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 191
545: sched_cls  name tail_ipv4_to_endpoint  tag 91b0c90b0ff25101  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,118,41,82,83,80,100,39,117,40,37,38
	btf_id 193
546: sched_cls  name tail_handle_ipv4  tag 3086f0cc344aab6a  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 194
547: sched_cls  name __send_drop_notify  tag 96aa797bc5c1be0e  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 196
548: sched_cls  name tail_handle_arp  tag 29884f2456e3e25f  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 197
549: sched_cls  name handle_policy  tag 716aa964aacf1e78  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 198
550: sched_cls  name handle_policy  tag bcbfd87d543ac1a2  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,117,82,83,118,41,80,100,39,84,75,40,37,38
	btf_id 195
551: sched_cls  name tail_ipv4_ct_ingress  tag e58eb5118ef5e507  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 200
552: sched_cls  name __send_drop_notify  tag 4079cbd5934f2a0a  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
553: sched_cls  name cil_from_container  tag 02b7e8ca90dfb0e0  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 117,76
	btf_id 202
554: sched_cls  name tail_ipv4_ct_ingress  tag 0d7b93e081045b2c  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 199
555: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 203
557: sched_cls  name tail_handle_ipv4_cont  tag 6820efcc4edc6687  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,118,41,100,82,83,39,76,74,77,117,40,37,38,81
	btf_id 205
558: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 207
559: sched_cls  name tail_handle_ipv4_cont  tag f83c7bac2d93e06d  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 206
560: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
563: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
564: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
567: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
568: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
571: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
572: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
575: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
615: sched_cls  name tail_handle_ipv4_cont  tag ec0d6db8df1c5a14  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,134,41,133,82,83,39,76,74,77,135,40,37,38,81
	btf_id 221
616: sched_cls  name tail_handle_arp  tag afc7b04eb4958913  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,135
	btf_id 222
617: sched_cls  name __send_drop_notify  tag 11b26896e3d00254  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 223
618: sched_cls  name cil_from_container  tag 5757b6eb3ec8aff4  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 135,76
	btf_id 224
619: sched_cls  name tail_ipv4_to_endpoint  tag 5d73e8b5b86f2fd3  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,134,41,82,83,80,133,39,135,40,37,38
	btf_id 225
620: sched_cls  name handle_policy  tag 0c1af2c901291a9c  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,135,82,83,134,41,80,133,39,84,75,40,37,38
	btf_id 226
621: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,135
	btf_id 227
622: sched_cls  name tail_handle_ipv4  tag e784e0f3a035e1f0  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,135
	btf_id 228
624: sched_cls  name tail_ipv4_ct_ingress  tag fc7183aac9c090da  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 230
625: sched_cls  name tail_ipv4_ct_egress  tag 8ce685db877d23cf  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 231
626: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
629: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
642: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
645: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
646: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
649: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
676: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
679: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
680: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
683: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
695: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
698: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
699: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
702: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
703: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
706: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
707: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
710: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
711: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
714: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3279: sched_cls  name tail_ipv4_to_endpoint  tag 0109b0c9151a6f64  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,626,41,82,83,80,143,39,625,40,37,38
	btf_id 3066
3280: sched_cls  name tail_ipv4_ct_egress  tag 0b1ee830bf1d0604  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,625,82,83,626,84
	btf_id 3067
3282: sched_cls  name tail_ipv4_ct_ingress  tag 75435ef4b626c7d3  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,625,82,83,626,84
	btf_id 3070
3283: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,625
	btf_id 3072
3285: sched_cls  name tail_handle_ipv4  tag 7e2fd268f0cbab59  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,625
	btf_id 3073
3291: sched_cls  name handle_policy  tag 4bf5ccf1c7bd5a3d  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,625,82,83,626,41,80,143,39,84,75,40,37,38
	btf_id 3075
3292: sched_cls  name tail_handle_arp  tag 9c174ad57944d053  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,625
	btf_id 3081
3293: sched_cls  name __send_drop_notify  tag 18727ae400ec039a  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3082
3296: sched_cls  name tail_handle_ipv4_cont  tag ef0bc0e3ccb2f991  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,626,41,143,82,83,39,76,74,77,625,40,37,38,81
	btf_id 3083
3297: sched_cls  name cil_from_container  tag 253bb6f603c64087  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 625,76
	btf_id 3086
3333: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,635
	btf_id 3125
3334: sched_cls  name tail_ipv4_ct_egress  tag cc29ebd242794373  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3127
3335: sched_cls  name tail_handle_ipv4_cont  tag 03020c7345d305e7  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,638,41,146,82,83,39,76,74,77,637,40,37,38,81
	btf_id 3129
3336: sched_cls  name tail_handle_arp  tag 43788f58b1e7b8a1  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,637
	btf_id 3130
3337: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,637
	btf_id 3131
3338: sched_cls  name handle_policy  tag 790e54e51cc18082  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,635,82,83,636,41,80,151,39,84,75,40,37,38
	btf_id 3128
3339: sched_cls  name tail_handle_ipv4_cont  tag 218936789f401bc8  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,636,41,151,82,83,39,76,74,77,635,40,37,38,81
	btf_id 3133
3340: sched_cls  name tail_ipv4_to_endpoint  tag b85793a5d0f6029d  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,638,41,82,83,80,146,39,637,40,37,38
	btf_id 3132
3341: sched_cls  name cil_from_container  tag c5937173adcb1dc0  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 637,76
	btf_id 3135
3342: sched_cls  name tail_handle_ipv4  tag 8431ca946cfec2af  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,635
	btf_id 3134
3343: sched_cls  name tail_ipv4_ct_ingress  tag 08b8a3b01ac0cb5a  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3136
3344: sched_cls  name tail_ipv4_ct_ingress  tag d272c38f762ab42e  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,635,82,83,636,84
	btf_id 3137
3345: sched_cls  name tail_ipv4_to_endpoint  tag c52a3226936076fc  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,636,41,82,83,80,151,39,635,40,37,38
	btf_id 3139
3346: sched_cls  name handle_policy  tag c4ba1a7fdbc71acd  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,637,82,83,638,41,80,146,39,84,75,40,37,38
	btf_id 3138
3347: sched_cls  name cil_from_container  tag e4ad5149eb3da00d  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 635,76
	btf_id 3140
3348: sched_cls  name tail_handle_arp  tag 693a431459ffe785  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,635
	btf_id 3141
3349: sched_cls  name __send_drop_notify  tag 253d94bc54031536  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3142
3350: sched_cls  name __send_drop_notify  tag 101dea1b241398f0  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3143
3351: sched_cls  name tail_ipv4_ct_egress  tag c6d8a865566aa96a  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,635,82,83,636,84
	btf_id 3144
3353: sched_cls  name tail_handle_ipv4  tag f25211fce0c81737  gpl
	loaded_at 2024-10-24T12:51:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,637
	btf_id 3145
