Node 0, zone      DMA      1    102     23      3    114     90     31      6      2      2     34 
Node 0, zone   Normal   1262    247     19      9      0      4      2      1      3      3      6 
