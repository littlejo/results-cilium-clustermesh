alloc: 96.88MB (101582800 bytes)
total-alloc: 3.07GB (3299282968 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 74896722
frees: 74028706
heap-alloc: 96.88MB (101582800 bytes)
heap-sys: 176.77MB (185352192 bytes)
heap-idle: 46.90MB (49176576 bytes)
heap-in-use: 129.87MB (136175616 bytes)
heap-released: 9.07MB (9510912 bytes)
heap-objects: 868016
stack-in-use: 35.19MB (36896768 bytes)
stack-sys: 35.19MB (36896768 bytes)
stack-mspan-inuse: 2.11MB (2213280 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 988.84KB (1012577 bytes)
gc-sys: 5.53MB (5799032 bytes)
next-gc: when heap-alloc >= 151.64MB (159009224 bytes)
last-gc: 2024-10-24 12:54:31.227455967 +0000 UTC
gc-pause-total: 11.297585ms
gc-pause: 113560
gc-pause-end: 1729774471227455967
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006006392995909174
enable-gc: true
debug-gc: false
