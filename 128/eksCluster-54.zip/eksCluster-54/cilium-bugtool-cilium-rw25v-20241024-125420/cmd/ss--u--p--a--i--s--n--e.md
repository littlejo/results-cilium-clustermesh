Total: 597
TCP:   4198 (estab 319, closed 3860, orphaned 0, timewait 3395)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  338       325       13       
INET	  348       331       17       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                  Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                             0.0.0.0:8472       0.0.0.0:*    ino:31589 sk:1 cgroup:/ <->                                                  
UNCONN 0      0                           127.0.0.1:323        0.0.0.0:*    ino:15244 sk:2 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                           127.0.0.1:46507      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:31472 sk:3 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.188.31%ens5:68         0.0.0.0:*    uid:192 ino:102554 sk:4 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                                [::]:8472          [::]:*    ino:31588 sk:5 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                               [::1]:323           [::]:*    ino:15245 sk:6 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::41f:aff:fe6b:4843]%ens5:546           [::]:*    uid:192 ino:16526 sk:7 cgroup:unreachable:bd0 v6only:1 <->                   
