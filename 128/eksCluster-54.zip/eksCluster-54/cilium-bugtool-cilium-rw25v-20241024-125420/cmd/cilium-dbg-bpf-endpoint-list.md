IP ADDRESS        LOCAL ENDPOINT INFO
172.31.182.30:0   (localhost)                                                                                        
172.31.188.31:0   (localhost)                                                                                        
10.54.0.133:0     id=818   sec_id=3618648 flags=0x0000 ifindex=12  mac=06:C2:A4:38:76:7A nodemac=E6:FF:AE:80:8A:8C   
10.54.0.65:0      id=529   sec_id=3618648 flags=0x0000 ifindex=14  mac=CA:FA:36:B4:DF:7A nodemac=9E:E4:04:98:32:3E   
10.54.0.115:0     id=908   sec_id=3608271 flags=0x0000 ifindex=18  mac=E6:65:BC:D2:05:A2 nodemac=EE:9C:42:09:63:88   
10.54.0.169:0     id=3250  sec_id=3610146 flags=0x0000 ifindex=20  mac=3E:02:24:E7:F8:DF nodemac=1E:88:BD:6A:8D:52   
10.54.0.96:0      (localhost)                                                                                        
10.54.0.4:0       id=674   sec_id=4     flags=0x0000 ifindex=10  mac=7E:BE:87:23:1A:42 nodemac=CE:E9:06:9E:CA:37     
10.54.0.29:0      id=1364  sec_id=3614473 flags=0x0000 ifindex=24  mac=CE:EA:3C:15:FB:40 nodemac=7A:C7:24:71:FA:3D   
10.54.0.191:0     id=1907  sec_id=3623440 flags=0x0000 ifindex=22  mac=D6:AB:47:17:06:5B nodemac=86:C5:3E:8C:60:E2   
