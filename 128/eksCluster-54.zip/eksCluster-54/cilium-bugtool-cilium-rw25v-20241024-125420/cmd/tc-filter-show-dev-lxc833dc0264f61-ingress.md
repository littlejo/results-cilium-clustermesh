filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc833dc0264f61 direct-action not_in_hw id 3297 tag 253bb6f603c64087 jited 
