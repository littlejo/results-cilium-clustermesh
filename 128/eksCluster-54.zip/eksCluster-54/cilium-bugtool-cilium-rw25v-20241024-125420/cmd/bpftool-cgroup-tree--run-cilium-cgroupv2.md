CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a94d0e6_fb34_4861_a022_d9701e8a9130.slice/cri-containerd-f88b485d1566b013859d78719e8513306128f55adb071506a8f04483bd3cc9ce.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a94d0e6_fb34_4861_a022_d9701e8a9130.slice/cri-containerd-725d4fccd91ca73e2887355a5af3968ea180eca47f6873702dd55e368729032a.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e2c2c9a_a993_4d66_bdbd_afb66642e997.slice/cri-containerd-239076b05d51315b190b9c7b11355b62b1879c78778ac4aa9e212973bd6ad520.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e2c2c9a_a993_4d66_bdbd_afb66642e997.slice/cri-containerd-bb1decc9655c9129339b921f28af25c9b13b7c67988cc8a3e725af71a494bd93.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod280b1bf5_9614_49a4_ac25_c83af24009ac.slice/cri-containerd-b137106249f2af2861634d60cbcdbe0ae5200a58e0e2534bb2db7893ec8c16d6.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod280b1bf5_9614_49a4_ac25_c83af24009ac.slice/cri-containerd-04811163dac2f608f7bf5dfa6e4081f12c9ddfbe3edb56eb59c52adba3ff1a70.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f50f0ca_fff7_477a_8c34_b5c02ffa35c0.slice/cri-containerd-8d48a62f7d885d52f4d2e41be4d735a62ae218f64e191804fde17c38678bfea1.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f50f0ca_fff7_477a_8c34_b5c02ffa35c0.slice/cri-containerd-42b1ee84e195db620ddbdcb3a91245dec4019826a4e9cb00ac2eb25b3d3274c5.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54cebe1b_af28_4de1_b20b_7827c8a1ef76.slice/cri-containerd-fd9e34ff416649c854b8cfcb20cd0b25b5de4e85fddcb107377bf8142415faa7.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54cebe1b_af28_4de1_b20b_7827c8a1ef76.slice/cri-containerd-a9538e284c7ed65187c84b1b3fb35b2b79a1bba8b01e289b5089a73c2c91da0e.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd63c7d18_665f_431e_b0d7_0f169791365c.slice/cri-containerd-ba42a5a8d5739f0298765e71ce2948644ecd9a269d78ceeb47010cc360c47a65.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd63c7d18_665f_431e_b0d7_0f169791365c.slice/cri-containerd-bdf8a79971c833e421d9492cf97960528e3be1aa81af5c2eabf6effb15c5e48f.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd63c7d18_665f_431e_b0d7_0f169791365c.slice/cri-containerd-39cf44eb3a2c8f4a16f54f033e63ae096c10fba5e002bc0141fecc8fae8cdb15.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd63c7d18_665f_431e_b0d7_0f169791365c.slice/cri-containerd-94977ef5e919b3e570f7f3846c8242501fc2f58dcdc7aad74742dee554a0f17e.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6aa1891e_58fc_41f0_be96_f1cbfb847503.slice/cri-containerd-6364938be5f505b731db257b2cd13c42e7b1e6d7dc2ee626df641f5fce96f355.scope
    683      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6aa1891e_58fc_41f0_be96_f1cbfb847503.slice/cri-containerd-eeca32af7918db0339654d8a9ff8c9907465f73ecbc61ff5579bb8039f28dcce.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod02f4ab07_5b14_4d47_8156_e53f7bda6301.slice/cri-containerd-398bfa89b0a9347b792f638fb029be6fda4ef9b9e33beed5b41b3c69d1d4e409.scope
    698      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod02f4ab07_5b14_4d47_8156_e53f7bda6301.slice/cri-containerd-4cee89199c3844fa73e34ed6cd086128e3fb976f161861b0b9ff7365944d93f5.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod08f87aaf_a3dc_46e5_9400_3c227988063b.slice/cri-containerd-13bd9e382835926f189cac82f71e1308404252aa54d3389b3f67790644ee4660.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod08f87aaf_a3dc_46e5_9400_3c227988063b.slice/cri-containerd-8ceb512003faab5fcee552c92bada0cdd9aca27edbd48f7efd1d10e838e85e7f.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3cbdf45_fdef_4119_bfed_135aea53f370.slice/cri-containerd-f8067819754d86122dd47154be24a42ec043e491df63357a9f6fd10d18f58b0c.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3cbdf45_fdef_4119_bfed_135aea53f370.slice/cri-containerd-2b78b4f6de67df6efe838da0e0290d9f7230ca1b060d698eba4b581ea475f40e.scope
    679      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3cbdf45_fdef_4119_bfed_135aea53f370.slice/cri-containerd-3b021fcea6ce797fe92e77d92c51d63fd312388dc2596b4ddd6bd1dd1c9fbb44.scope
    714      cgroup_device   multi                                          
