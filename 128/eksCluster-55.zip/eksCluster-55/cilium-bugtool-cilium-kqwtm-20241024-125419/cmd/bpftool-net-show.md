xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 553
ens6(5) clsact/ingress cil_from_netdev-ens6 id 557
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 546
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 539
cilium_host(7) clsact/egress cil_from_host-cilium_host id 538
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 568
lxc17dfbfe64344(12) clsact/ingress cil_from_container-lxc17dfbfe64344 id 515
lxce5e184a72a36(14) clsact/ingress cil_from_container-lxce5e184a72a36 id 576
lxc84f7d5792361(18) clsact/ingress cil_from_container-lxc84f7d5792361 id 640
lxc38ae56ac5ff1(20) clsact/ingress cil_from_container-lxc38ae56ac5ff1 id 3342
lxc6de7c6db0067(22) clsact/ingress cil_from_container-lxc6de7c6db0067 id 3333
lxcf058444caf32(24) clsact/ingress cil_from_container-lxcf058444caf32 id 3275

flow_dissector:

netfilter:

