markdown output at /tmp/cilium-bugtool-20241024-125421.858+0000-UTC-2816922902/cmd/cilium-debuginfo-20241024-125451.865+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125421.858+0000-UTC-2816922902/cmd/cilium-debuginfo-20241024-125451.865+0000-UTC.json
