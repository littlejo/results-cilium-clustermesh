CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ef40638_b0ce_47a5_b20f_eee8b8968424.slice/cri-containerd-db6cb313cc8b7fbf17ff143af7daa5c5298042a7360bb3762ef0b341a1894778.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ef40638_b0ce_47a5_b20f_eee8b8968424.slice/cri-containerd-c6340b28683021e4216d4ed912704d2c448927c5d6384db04412153c591411be.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod39e021dc_2805_4915_9624_a875accbfe26.slice/cri-containerd-a6fa4b100af15ac570d62ae2472473ff7a17b78f76fd4d2975cabd5d43789b02.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod39e021dc_2805_4915_9624_a875accbfe26.slice/cri-containerd-7e453a19b7e28c526c0736a8768bf04ea63c7c6f4fe87d49bb0a1c2ab7beadb3.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa879b0a_5a94_4b30_a410_720173fc5e09.slice/cri-containerd-9283aa21fea1e589973df1b808a319c5c707ef34ff43e1dda35bd012aec2a9cc.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa879b0a_5a94_4b30_a410_720173fc5e09.slice/cri-containerd-821628015ea25ffb13b24f592a7e238857635ac3be637aad7ed48461291eb369.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3844a545_45e0_469a_a9bd_6b6ef8238cc0.slice/cri-containerd-4336b1dadb8caaadb7a6f6d134118ef4eb9daabea904cdda8168bd67c19b6b4d.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3844a545_45e0_469a_a9bd_6b6ef8238cc0.slice/cri-containerd-fb89ac734ebf7cc406ae729654bc80b84939ab360764aab064ed22352968b83f.scope
    584      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod69dc03b6_52b2_4590_b352_17482aa36bfe.slice/cri-containerd-bb391f36a3faa01e2bdb978acfd573a9f3b9ccca07d71dbd4a3ce10c68bb90ee.scope
    728      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod69dc03b6_52b2_4590_b352_17482aa36bfe.slice/cri-containerd-c1357cc763e778f0ec3f8c78b33eb94a8bcf24bd9d4d39b81d711363c01606d9.scope
    712      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9f34c6dd_cd1a_42f5_91a9_4ff6d36a0361.slice/cri-containerd-2473048942228f2a27b1071ae3bbda3b923f1159c592bab0316b376d7b136d1a.scope
    732      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9f34c6dd_cd1a_42f5_91a9_4ff6d36a0361.slice/cri-containerd-ac6111e392462b7aecb678f80c8fd4dbcf8d748b298e104f62c5e106a1a9b9cb.scope
    716      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9f34c6dd_cd1a_42f5_91a9_4ff6d36a0361.slice/cri-containerd-74fa514a698a4719b88d042b89188495b3a76839c8e82f202ab9fb884911b553.scope
    736      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b67667c_51b7_4faa_99fc_efb90b9a1093.slice/cri-containerd-d029de5ed7f6d8238e9b2b3c1eef441dd3e14e5ddce176b6d6791b0a4dcde461.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b67667c_51b7_4faa_99fc_efb90b9a1093.slice/cri-containerd-0e95f34aed5200fe24741463950c6896ffe4ea567d65459cf00a41ead549534c.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b67667c_51b7_4faa_99fc_efb90b9a1093.slice/cri-containerd-e1e582b569f6766e74b3745a652b9153ab87fb30aabcd786229e337ccea5347d.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b67667c_51b7_4faa_99fc_efb90b9a1093.slice/cri-containerd-3257a31c48a522fac4eaa3cc597f42f6442d6a7934ea1d183ba817088881fa25.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode22c0aab_9930_4a1e_a9ff_184e4ebfb294.slice/cri-containerd-f1a1c6f4ddebf0ee5222a72b3f7ace5d9b785469cad5804711dcfba8dbf0c8a6.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode22c0aab_9930_4a1e_a9ff_184e4ebfb294.slice/cri-containerd-19e242be336dba7eecaddd092fa18fa79b1f2e146f4baa70b40e1c8c4a8435a8.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod655faaab_6486_44f8_b935_9f1743f64c9c.slice/cri-containerd-9f90cee3a6325e0e64fb84216cc3768a3e4a0bc87c482751fe5e59f0950b4298.scope
    724      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod655faaab_6486_44f8_b935_9f1743f64c9c.slice/cri-containerd-63477624757054cbc9db90d6cf820ec3c23bc55ffec0a0bd2ceffba2e5e0f7a1.scope
    720      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd87458c9_a4f7_4f4e_a84b_76b288718345.slice/cri-containerd-15c4f8773b31bd8e6817b42c6c1ecc614874329e478a0b3c729b96e0dc05bb5d.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd87458c9_a4f7_4f4e_a84b_76b288718345.slice/cri-containerd-123411b1957bed0547434c5a8ac4cb6551e83ea2383819909a877325fc669e9f.scope
    99       cgroup_device   multi                                          
