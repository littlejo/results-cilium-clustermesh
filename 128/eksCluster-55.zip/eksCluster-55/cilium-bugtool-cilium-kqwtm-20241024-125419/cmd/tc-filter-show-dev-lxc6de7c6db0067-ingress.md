filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc6de7c6db0067 direct-action not_in_hw id 3333 tag d162167f61816249 jited 
