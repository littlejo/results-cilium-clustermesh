{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.441Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.445Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.540Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.139Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.142Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.192Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.203Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.238Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.477Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.480Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.545Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.558Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.602Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.186Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.207Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.275Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.282Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.322Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.546Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.565Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.620Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.621Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.675Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.170Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.187Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.279Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.295Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.337Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.341Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.587Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.617Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.666Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.672Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.714Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.199Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.203Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.246Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.260Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.296Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.297Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.305Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.573Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.583Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.635Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.640Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.678Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.136Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.142Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.186Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.235Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.241Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.508Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.509Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.616Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.623Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.659Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.075Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.081Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.127Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.150Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.172Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.394Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.398Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.456Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.458Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.497Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.850Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.901Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.922Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.949Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.988Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.995Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.231Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.257Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.296Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.307Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.346Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.759Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.848Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.897Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.904Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.905Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.934Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.155Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.164Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.223Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.235Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.272Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.660Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.697Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.732Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.750Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.773Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.792Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.025Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.027Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.085Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.091Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.127Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.409Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.445Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.455Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.502Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.502Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.540Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.792Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.815Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.906Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.954Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.976Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.273Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.282Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.323Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.354Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.359Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.627Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.631Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.647Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.680Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.276Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.279Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.311Z",
  "value": "id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.332Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.352Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.621Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.638Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.302Z",
  "value": "id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.309Z",
  "value": "id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD"
}

