[
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod39e021dc_2805_4915_9624_a875accbfe26.slice/cri-containerd-7e453a19b7e28c526c0736a8768bf04ea63c7c6f4fe87d49bb0a1c2ab7beadb3.scope"
      }
    ],
    "ips": [
      "10.55.0.233"
    ],
    "name": "coredns-cc6ccd49c-5hwkc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod655faaab_6486_44f8_b935_9f1743f64c9c.slice/cri-containerd-9f90cee3a6325e0e64fb84216cc3768a3e4a0bc87c482751fe5e59f0950b4298.scope"
      }
    ],
    "ips": [
      "10.55.0.45"
    ],
    "name": "client2-57cf4468f-vcpq5",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3844a545_45e0_469a_a9bd_6b6ef8238cc0.slice/cri-containerd-4336b1dadb8caaadb7a6f6d134118ef4eb9daabea904cdda8168bd67c19b6b4d.scope"
      }
    ],
    "ips": [
      "10.55.0.7"
    ],
    "name": "coredns-cc6ccd49c-bbz55",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod69dc03b6_52b2_4590_b352_17482aa36bfe.slice/cri-containerd-bb391f36a3faa01e2bdb978acfd573a9f3b9ccca07d71dbd4a3ce10c68bb90ee.scope"
      }
    ],
    "ips": [
      "10.55.0.8"
    ],
    "name": "client-974f6c69d-jnlkh",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9f34c6dd_cd1a_42f5_91a9_4ff6d36a0361.slice/cri-containerd-74fa514a698a4719b88d042b89188495b3a76839c8e82f202ab9fb884911b553.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9f34c6dd_cd1a_42f5_91a9_4ff6d36a0361.slice/cri-containerd-2473048942228f2a27b1071ae3bbda3b923f1159c592bab0316b376d7b136d1a.scope"
      }
    ],
    "ips": [
      "10.55.0.118"
    ],
    "name": "echo-same-node-86d9cc975c-zlwjl",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b67667c_51b7_4faa_99fc_efb90b9a1093.slice/cri-containerd-d029de5ed7f6d8238e9b2b3c1eef441dd3e14e5ddce176b6d6791b0a4dcde461.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b67667c_51b7_4faa_99fc_efb90b9a1093.slice/cri-containerd-3257a31c48a522fac4eaa3cc597f42f6442d6a7934ea1d183ba817088881fa25.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b67667c_51b7_4faa_99fc_efb90b9a1093.slice/cri-containerd-0e95f34aed5200fe24741463950c6896ffe4ea567d65459cf00a41ead549534c.scope"
      }
    ],
    "ips": [
      "10.55.0.46"
    ],
    "name": "clustermesh-apiserver-5b9c9f6d75-txfsb",
    "namespace": "kube-system"
  }
]

