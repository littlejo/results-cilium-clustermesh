1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:07:40:53:91:d5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.225.88/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3451sec preferred_lft 3451sec
    inet6 fe80::807:40ff:fe53:91d5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:e7:e3:bc:8a:cb brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.218.203/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8e7:e3ff:febc:8acb/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:74:fd:fc:bd:b8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c074:fdff:fefc:bdb8/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:8b:fb:33:66:cc brd ff:ff:ff:ff:ff:ff
    inet 10.55.0.120/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::408b:fbff:fe33:66cc/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 42:0a:f9:89:91:36 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::400a:f9ff:fe89:9136/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:d6:7c:55:10:df brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::74d6:7cff:fe55:10df/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc17dfbfe64344@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:4c:a4:dd:30:f7 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::184c:a4ff:fedd:30f7/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce5e184a72a36@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:61:18:04:3b:24 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::4461:18ff:fe04:3b24/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc84f7d5792361@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:96:bb:eb:66:ae brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::1896:bbff:feeb:66ae/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc38ae56ac5ff1@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:a0:a9:78:bb:fd brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::74a0:a9ff:fe78:bbfd/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc6de7c6db0067@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:14:4b:5c:9d:86 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::6014:4bff:fe5c:9d86/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcf058444caf32@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:ca:4a:05:1c:02 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::14ca:4aff:fe05:1c02/64 scope link 
       valid_lft forever preferred_lft forever
