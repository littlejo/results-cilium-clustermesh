top - 12:54:22 up 32 min,  0 users,  load average: 0.20, 0.44, 0.32
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 34.5 us, 27.6 sy,  0.0 ni, 37.9 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    288.2 free,   1051.1 used,   2496.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2604.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3244 root      20   0 1240432  16560  11356 S   6.7   0.4   0:00.04 cilium-+
      1 root      20   0 1539060 291704  78916 S   0.0   7.4   1:10.04 cilium-+
    395 root      20   0 1229744   8868   2864 S   0.0   0.2   0:04.48 cilium-+
   3217 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3230 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3271 root      20   0    6576   2428   2100 R   0.0   0.1   0:00.00 top
   3289 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
