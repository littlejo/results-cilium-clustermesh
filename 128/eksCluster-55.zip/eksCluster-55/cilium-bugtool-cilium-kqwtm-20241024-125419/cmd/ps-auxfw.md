USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3244  0.0  0.3 1240432 15348 ?       Dsl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3259  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3261  0.0  0.3 1240432 15348 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root        3230  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3217  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  4.4  7.4 1539060 291704 ?      Ssl  12:28   1:10 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.2  0.2 1229744 8868 ?        Sl   12:28   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
