IP ADDRESS         LOCAL ENDPOINT INFO
10.55.0.45:0       id=1123  sec_id=3676488 flags=0x0000 ifindex=22  mac=B6:5A:21:81:B3:A6 nodemac=62:14:4B:5C:9D:86   
10.55.0.7:0        id=1363  sec_id=3682229 flags=0x0000 ifindex=12  mac=A6:B4:4E:8D:42:C3 nodemac=1A:4C:A4:DD:30:F7   
10.55.0.233:0      id=3029  sec_id=3682229 flags=0x0000 ifindex=14  mac=BA:31:8E:BC:4E:AC nodemac=46:61:18:04:3B:24   
10.55.0.120:0      (localhost)                                                                                        
10.55.0.8:0        id=427   sec_id=3689515 flags=0x0000 ifindex=20  mac=D6:A6:2C:D1:1D:7C nodemac=76:A0:A9:78:BB:FD   
10.55.0.46:0       id=1168  sec_id=3671478 flags=0x0000 ifindex=18  mac=DE:DA:BB:8C:42:22 nodemac=1A:96:BB:EB:66:AE   
10.55.0.52:0       id=302   sec_id=4     flags=0x0000 ifindex=10  mac=F6:2C:C2:97:BB:55 nodemac=76:D6:7C:55:10:DF     
172.31.218.203:0   (localhost)                                                                                        
10.55.0.118:0      id=496   sec_id=3698433 flags=0x0000 ifindex=24  mac=DA:45:B2:DB:59:4D nodemac=16:CA:4A:05:1C:02   
172.31.225.88:0    (localhost)                                                                                        
