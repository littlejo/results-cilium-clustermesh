alloc: 98.25MB (103026680 bytes)
total-alloc: 3.12GB (3352472504 bytes)
sys: 227.32MB (238363988 bytes)
lookups: 0
mallocs: 75743789
frees: 74841349
heap-alloc: 98.25MB (103026680 bytes)
heap-sys: 180.67MB (189448192 bytes)
heap-idle: 53.75MB (56360960 bytes)
heap-in-use: 126.92MB (133087232 bytes)
heap-released: 12.88MB (13508608 bytes)
heap-objects: 902440
stack-in-use: 35.28MB (36995072 bytes)
stack-sys: 35.28MB (36995072 bytes)
stack-mspan-inuse: 2.07MB (2171520 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 972.10KB (995433 bytes)
gc-sys: 5.54MB (5805200 bytes)
next-gc: when heap-alloc >= 152.02MB (159408920 bytes)
last-gc: 2024-10-24 12:54:29.916535106 +0000 UTC
gc-pause-total: 11.554313ms
gc-pause: 73764
gc-pause-end: 1729774469916535106
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0005691368935684941
enable-gc: true
debug-gc: false
