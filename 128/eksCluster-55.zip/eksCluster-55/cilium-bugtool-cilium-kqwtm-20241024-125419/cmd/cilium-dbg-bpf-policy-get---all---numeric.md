Endpoint ID: 302
Path: /sys/fs/bpf/tc/globals/cilium_policy_00302

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6228775   77147     0        
Allow    Ingress     1          ANY          NONE         disabled    65158     790       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 427
Path: /sys/fs/bpf/tc/globals/cilium_policy_00427

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 496
Path: /sys/fs/bpf/tc/globals/cilium_policy_00496

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    382661   4469      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1123
Path: /sys/fs/bpf/tc/globals/cilium_policy_01123

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1168
Path: /sys/fs/bpf/tc/globals/cilium_policy_01168

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6036092   61230     0        
Allow    Ingress     1          ANY          NONE         disabled    5538082   58531     0        
Allow    Egress      0          ANY          NONE         disabled    7695416   75158     0        


Endpoint ID: 1363
Path: /sys/fs/bpf/tc/globals/cilium_policy_01363

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1768     18        0        
Allow    Ingress     1          ANY          NONE         disabled    149107   1715      0        
Allow    Egress      0          ANY          NONE         disabled    20925    233       0        


Endpoint ID: 1829
Path: /sys/fs/bpf/tc/globals/cilium_policy_01829

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3029
Path: /sys/fs/bpf/tc/globals/cilium_policy_03029

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4128     42        0        
Allow    Ingress     1          ANY          NONE         disabled    150521   1727      0        
Allow    Egress      0          ANY          NONE         disabled    21520    240       0        


