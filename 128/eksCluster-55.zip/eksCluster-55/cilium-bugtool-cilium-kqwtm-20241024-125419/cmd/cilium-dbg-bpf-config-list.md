KEY             VALUE
AgentLiveness   1988903058658
UTimeOffset     3378461919921875
