Node 0, zone      DMA      1     82     37     47     69    110     56     31      7      3     30 
Node 0, zone   Normal     34     53     11      4      1      1      0      2      2      1      9 
