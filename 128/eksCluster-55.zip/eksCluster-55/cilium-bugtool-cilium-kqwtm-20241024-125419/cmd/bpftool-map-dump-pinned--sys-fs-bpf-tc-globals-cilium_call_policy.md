key: 2e 01 00 00  value: 45 02 00 00
key: ab 01 00 00  value: 06 0d 00 00
key: f0 01 00 00  value: c5 0c 00 00
key: 63 04 00 00  value: 02 0d 00 00
key: 90 04 00 00  value: 86 02 00 00
key: 53 05 00 00  value: 00 02 00 00
key: d5 0b 00 00  value: 39 02 00 00
Found 7 elements
