IP ADDRESS         LOCAL ENDPOINT INFO
10.68.0.50:0       id=1795  sec_id=4     flags=0x0000 ifindex=10  mac=12:58:BD:68:AC:D2 nodemac=92:63:51:BB:E7:FE     
10.68.0.43:0       id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A   
10.68.0.108:0      id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38   
172.31.135.109:0   (localhost)                                                                                        
10.68.0.96:0       id=586   sec_id=4523841 flags=0x0000 ifindex=18  mac=1E:29:C9:34:30:71 nodemac=52:C5:29:2F:86:A7   
10.68.0.225:0      id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE   
10.68.0.251:0      id=1657  sec_id=4545743 flags=0x0000 ifindex=14  mac=4A:D0:3F:1F:31:4F nodemac=3E:23:60:2F:0A:4C   
10.68.0.204:0      id=3950  sec_id=4545743 flags=0x0000 ifindex=12  mac=82:E7:FC:53:53:E5 nodemac=0A:35:9E:D6:A8:13   
10.68.0.27:0       (localhost)                                                                                        
172.31.191.76:0    (localhost)                                                                                        
