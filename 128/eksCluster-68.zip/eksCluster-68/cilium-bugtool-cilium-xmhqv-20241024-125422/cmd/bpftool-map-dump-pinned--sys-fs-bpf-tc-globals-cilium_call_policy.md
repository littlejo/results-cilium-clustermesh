key: 4a 02 00 00  value: 7d 02 00 00
key: 75 02 00 00  value: f1 0c 00 00
key: 24 04 00 00  value: 37 0d 00 00
key: 79 06 00 00  value: 28 02 00 00
key: 03 07 00 00  value: 2c 02 00 00
key: 43 07 00 00  value: 2f 0d 00 00
key: 6e 0f 00 00  value: 1e 02 00 00
Found 7 elements
