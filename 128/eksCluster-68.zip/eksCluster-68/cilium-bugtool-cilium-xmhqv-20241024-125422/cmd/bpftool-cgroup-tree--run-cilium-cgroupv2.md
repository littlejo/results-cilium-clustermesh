CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf51f5235_5e8b_4b4f_b371_069efc307c0e.slice/cri-containerd-ac7411256219117a0dcf13f9114a9802f4bc1c86fb9499fcfcf4993986040065.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf51f5235_5e8b_4b4f_b371_069efc307c0e.slice/cri-containerd-0fade2f972abfcd53477c083368d867b6f60ee49757275cf8d8c8484c39d4301.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod70dc8299_b5ff_487c_944a_ce6618b9ee77.slice/cri-containerd-913e871a9e8d799bd8744bf4161831de938baf7cfa74222ded04bf6d90451384.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod70dc8299_b5ff_487c_944a_ce6618b9ee77.slice/cri-containerd-1a680c603e4e955c8f56943231efd1c2096f348196cd67034ae3c2e3714cdab1.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd7e88550_bd96_4f10_a8fc_9a94969e3a02.slice/cri-containerd-ee9924540ccbe34458287a9634b0414a1cc5743c0913b5a5589d80205b916572.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd7e88550_bd96_4f10_a8fc_9a94969e3a02.slice/cri-containerd-a0d3a3549e2e7e166fa614956eec0788eb7f23344f6a410f01afdc5d1e7e9c8a.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbe9e1c2b_af34_4541_8637_2d0f72df1e13.slice/cri-containerd-817c55dbe44dd69dc04dd9935e37298c8238c36e4169671b49d8929340608602.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbe9e1c2b_af34_4541_8637_2d0f72df1e13.slice/cri-containerd-54bb3b259b061a290e3b4ecfb6f4e7b1181dbefeab58f1f8f00912f24fccc2df.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod22492198_0ba5_434d_a805_e5ba45cb4b34.slice/cri-containerd-af13b0424cc18c697ca22f0fd82d8918be29174be1f699f62e05b1a612d3d80e.scope
    113      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod22492198_0ba5_434d_a805_e5ba45cb4b34.slice/cri-containerd-9867f8c39b35a8aa7b7dc812727583466eca5b940de4c2dfc77069ed5450ec70.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a61918b_f182_4fa3_ab31_5ccc5f17c30d.slice/cri-containerd-1186ea54d7847aa026af5e9419693032991feff0aa24c30b508aa2533f1819e6.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a61918b_f182_4fa3_ab31_5ccc5f17c30d.slice/cri-containerd-51e72bbc00ec3d3a0082fb0a7d614fa6fa1260fd6880c057a82580c21b3e2dca.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ab15730_bfae_4e63_be02_727429639825.slice/cri-containerd-b6fb35d1d61436aa1b25c563da40fda2800b0abdd6fc43cfc7b8b79fa75009bc.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ab15730_bfae_4e63_be02_727429639825.slice/cri-containerd-3e707be2429c976c97fb3c4c67c9dc9bec1aa0610e729c250ca685126f0dc6b2.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ab15730_bfae_4e63_be02_727429639825.slice/cri-containerd-2ad5bbff8165af8a61f936224e7ebaee073407a3eaa01295830c64afdb8f5949.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ab15730_bfae_4e63_be02_727429639825.slice/cri-containerd-6de4424c397fce138900785aa3b23ea23861c0059a7c806cff6d1f63da917606.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc17b3efb_ab00_4084_ac38_e425f4fc7cf8.slice/cri-containerd-2b54525210791585bd0d36fa9e8745de893ad38362d6ab0203fffac8ca05893a.scope
    728      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc17b3efb_ab00_4084_ac38_e425f4fc7cf8.slice/cri-containerd-9c1b01b27cab48bc327b8a3a1ac3cb9dc8dc1e5b71eecee101be99310ad991fe.scope
    716      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda66cc69_6cb0_4017_aaea_8194a05bb3b1.slice/cri-containerd-d9e567c1e6dc37e7054342d81e36ca4c8bcd2b96014e19a581896eb67b0f39b1.scope
    690      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda66cc69_6cb0_4017_aaea_8194a05bb3b1.slice/cri-containerd-56281e1e9f6fc40143e13018d9217f23dd49090c64dc4b6556fc1a254f38973b.scope
    736      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda66cc69_6cb0_4017_aaea_8194a05bb3b1.slice/cri-containerd-b9c31303603acc2d35e5c473c41c3acd13888715f0a910a095f4be6d6b7726ba.scope
    732      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf38f5b15_7d75_42c5_a438_c91ee81c4b5d.slice/cri-containerd-62bc57c8461e5782947724f2bf121f871fe8cac0d18aa44b69fd52a2fe50a40c.scope
    724      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf38f5b15_7d75_42c5_a438_c91ee81c4b5d.slice/cri-containerd-061491602996b084cceb37cc3b9f3f7a19fb4bc1f0a08be88a9045c2733fb21c.scope
    720      cgroup_device   multi                                          
