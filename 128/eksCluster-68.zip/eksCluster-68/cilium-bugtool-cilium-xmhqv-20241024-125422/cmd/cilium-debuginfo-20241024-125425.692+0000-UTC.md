# Cilium debug information

#### Cilium environment keys

```
proxy-admin-port:0
install-iptables-rules:true
nat-map-stats-interval:30s
hubble-event-queue-size:0
bpf-lb-sock:false
http-retry-timeout:0
set-cilium-is-up-condition:true
tofqdns-enable-dns-compression:true
enable-xt-socket-fallback:true
use-full-tls-context:false
cni-log-file:/var/run/cilium/cilium-cni.log
bpf-filter-priority:1
vtep-cidr:
enable-host-port:false
ingress-secrets-namespace:
encrypt-interface:
dnsproxy-concurrency-processing-grace-period:0s
cluster-pool-ipv4-cidr:10.68.0.0/16
hubble-redact-enabled:false
debug-verbose:
proxy-xff-num-trusted-hops-egress:0
cluster-pool-ipv4-mask-size:24
mke-cgroup-mount:
enable-tcx:true
keep-config:false
tofqdns-idle-connection-grace-period:0s
clustermesh-enable-endpoint-sync:false
envoy-log:
node-port-algorithm:random
enable-l2-neigh-discovery:true
monitor-queue-size:0
enable-k8s-terminating-endpoint:true
lib-dir:/var/lib/cilium
certificates-directory:/var/run/cilium/certs
ipam-default-ip-pool:default
multicast-enabled:false
tofqdns-min-ttl:0
enable-bpf-clock-probe:false
policy-audit-mode:false
mesh-auth-signal-backoff-duration:1s
ipsec-key-file:
hubble-redact-http-headers-allow:
mesh-auth-gc-interval:5m0s
enable-nat46x64-gateway:false
l2-announcements-retry-period:2s
node-port-mode:snat
ipsec-key-rotation-duration:5m0s
hubble-export-file-path:
enable-pmtu-discovery:false
trace-payloadlen:128
gops-port:9890
local-router-ipv4:
kvstore-periodic-sync:5m0s
operator-api-serve-addr:127.0.0.1:9234
bpf-lb-rss-ipv6-src-cidr:
bpf-policy-map-full-reconciliation-interval:15m0s
enable-bpf-tproxy:false
bpf-lb-dsr-dispatch:opt
service-no-backend-response:reject
pprof-port:6060
exclude-local-address:
egress-masquerade-interfaces:ens+
envoy-secrets-namespace:
bgp-announce-pod-cidr:false
enable-local-node-route:true
node-labels:
max-connected-clusters:255
endpoint-queue-size:25
ipam-multi-pool-pre-allocation:
enable-health-check-loadbalancer-ip:false
enable-masquerade-to-route-source:false
hubble-metrics:
dnsproxy-lock-count:131
cflags:
clustermesh-enable-mcs-api:false
enable-node-selector-labels:false
k8s-client-burst:20
enable-tracing:false
derive-masq-ip-addr-from-device:
bgp-config-path:/var/lib/cilium/bgp/config.yaml
proxy-portrange-max:20000
bpf-ct-timeout-regular-tcp:2h13m20s
hubble-event-buffer-capacity:4095
l2-pod-announcements-interface:
policy-accounting:true
enable-endpoint-health-checking:true
bpf-policy-map-max:16384
enable-metrics:true
enable-endpoint-routes:false
bpf-sock-rev-map-max:262144
hubble-metrics-server:
state-dir:/var/run/cilium
bpf-lb-maglev-table-size:16381
cni-chaining-target:
policy-queue-size:100
bpf-ct-timeout-regular-tcp-fin:10s
vtep-mask:
dns-max-ips-per-restored-rule:1000
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
envoy-config-retry-interval:15s
ipv6-mcast-device:
prometheus-serve-addr:
monitor-aggregation-interval:5s
dnsproxy-insecure-skip-transparent-mode-check:false
direct-routing-device:
enable-ingress-controller:false
enable-health-check-nodeport:true
hubble-drop-events:false
enable-wireguard:false
vtep-mac:
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
mtu:0
encryption-strict-mode-cidr:
bpf-lb-dsr-l4-xlate:frontend
enable-ipsec-key-watcher:true
ipv6-cluster-alloc-cidr:f00d::/64
egress-gateway-reconciliation-trigger-interval:1s
ipv6-node:auto
cluster-id:69
disable-iptables-feeder-rules:
ip-masq-agent-config-path:/etc/config/ip-masq-agent
identity-change-grace-period:5s
fixed-identity-mapping:
hubble-socket-path:/var/run/cilium/hubble.sock
identity-restore-grace-period:30s
enable-ipsec:false
hubble-redact-http-urlquery:false
enable-bgp-control-plane:false
kube-proxy-replacement:false
ipv4-service-range:auto
kvstore-max-consecutive-quorum-errors:2
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
policy-cidr-match-mode:
allocator-list-timeout:3m0s
mesh-auth-mutual-listener-port:0
container-ip-local-reserved-ports:auto
enable-unreachable-routes:false
hubble-export-file-max-size-mb:10
bpf-lb-affinity-map-max:0
iptables-lock-timeout:5s
max-controller-interval:0
allow-localhost:auto
enable-auto-protect-node-port-range:true
identity-heartbeat-timeout:30m0s
enable-gateway-api:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
tofqdns-proxy-port:0
bpf-ct-timeout-service-any:1m0s
bpf-lb-maglev-map-max:0
hubble-export-file-max-backups:5
enable-sctp:false
hubble-export-denylist:
bpf-ct-timeout-regular-tcp-syn:1m0s
enable-cilium-health-api-server-access:
enable-ipv6-masquerade:true
monitor-aggregation-flags:all
hubble-monitor-events:
node-port-acceleration:disabled
enable-svc-source-range-check:true
k8s-kubeconfig-path:
bpf-ct-timeout-service-tcp:2h13m20s
agent-liveness-update-interval:1s
enable-k8s-api-discovery:false
k8s-require-ipv6-pod-cidr:false
bpf-map-dynamic-size-ratio:0.0025
socket-path:/var/run/cilium/cilium.sock
kvstore:
bpf-events-drop-enabled:true
bpf-ct-timeout-service-tcp-grace:1m0s
cluster-name:cmesh69
bpf-ct-global-any-max:262144
log-system-load:false
bpf-lb-map-max:65536
bpf-lb-mode:snat
hubble-prefer-ipv6:false
enable-host-legacy-routing:false
srv6-encap-mode:reduced
tofqdns-pre-cache:
enable-k8s-endpoint-slice:true
policy-trigger-interval:1s
enable-l2-announcements:false
bypass-ip-availability-upon-restore:false
http-max-grpc-timeout:0
proxy-portrange-min:10000
enable-cilium-api-server-access:
cilium-endpoint-gc-interval:5m0s
dnsproxy-concurrency-limit:0
synchronize-k8s-nodes:true
nodes-gc-interval:5m0s
hubble-export-fieldmask:
conntrack-gc-max-interval:0s
bpf-root:/sys/fs/bpf
enable-bpf-masquerade:false
read-cni-conf:
bpf-node-map-max:16384
enable-ipip-termination:false
conntrack-gc-interval:0s
unmanaged-pod-watcher-interval:15
pprof:false
enable-srv6:false
kube-proxy-replacement-healthz-bind-address:
cluster-health-port:4240
bpf-lb-service-backend-map-max:0
identity-gc-interval:15m0s
enable-l2-pod-announcements:false
procfs:/host/proc
enable-service-topology:false
bpf-lb-sock-hostns-only:false
enable-ipv4-big-tcp:false
enable-vtep:false
enable-route-mtu-for-cni-chaining:false
direct-routing-skip-unreachable:false
mesh-auth-rotated-identities-queue-size:1024
ipam-cilium-node-update-rate:15s
bpf-nat-global-max:524288
devices:
enable-encryption-strict-mode:false
hubble-redact-kafka-apikey:false
hubble-drop-events-interval:2m0s
dnsproxy-lock-timeout:500ms
enable-ipsec-xfrm-state-caching:true
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
http-retry-count:3
nodeport-addresses:
disable-envoy-version-check:false
disable-external-ip-mitigation:false
enable-ipv6:false
enable-xdp-prefilter:false
tofqdns-dns-reject-response-code:refused
crd-wait-timeout:5m0s
enable-ip-masq-agent:false
http-request-timeout:3600
enable-k8s:true
cni-chaining-mode:none
enable-bandwidth-manager:false
use-cilium-internal-ip-for-ipsec:false
force-device-detection:false
hubble-recorder-sink-queue-size:1024
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
bpf-lb-source-range-map-max:0
hubble-disable-tls:false
enable-ipv4-masquerade:true
ipv4-service-loopback-address:169.254.42.1
k8s-sync-timeout:3m0s
proxy-max-connection-duration-seconds:0
hubble-skip-unknown-cgroup-ids:true
cni-external-routing:false
enable-local-redirect-policy:false
enable-high-scale-ipcache:false
k8s-client-connection-timeout:30s
allow-icmp-frag-needed:true
bpf-ct-global-tcp-max:524288
mesh-auth-mutual-connect-timeout:5s
enable-monitor:true
hubble-recorder-storage-path:/var/run/cilium/pcaps
bpf-neigh-global-max:524288
enable-node-port:false
wireguard-persistent-keepalive:0s
bpf-fragments-map-max:8192
max-internal-timer-delay:0s
enable-identity-mark:true
envoy-keep-cap-netbindservice:false
enable-envoy-config:false
restore:true
tofqdns-endpoint-max-ip-per-hostname:50
l2-announcements-lease-duration:15s
arping-refresh-period:30s
bpf-lb-service-map-max:0
k8s-client-qps:10
enable-mke:false
enable-runtime-device-detection:true
ipv6-service-range:auto
log-opt:
k8s-client-connection-keep-alive:30s
route-metric:0
version:false
bpf-lb-rev-nat-map-max:0
bpf-lb-acceleration:disabled
custom-cni-conf:false
kvstore-connectivity-timeout:2m0s
dns-policy-unload-on-shutdown:false
proxy-connect-timeout:2
ipam:cluster-pool
envoy-config-timeout:2m0s
monitor-aggregation:medium
annotate-k8s-node:false
enable-active-connection-tracking:false
config-sources:config-map:kube-system/cilium-config
bpf-lb-rss-ipv4-src-cidr:
tunnel-protocol:vxlan
enable-policy:default
bpf-lb-external-clusterip:false
identity-allocation-mode:crd
enable-ipv6-ndp:false
bpf-lb-algorithm:random
proxy-idle-timeout-seconds:60
ipv6-range:auto
bgp-announce-lb-ip:false
clustermesh-ip-identities-sync-timeout:1m0s
install-no-conntrack-iptables-rules:false
proxy-max-requests-per-connection:0
fqdn-regex-compile-lru-size:1024
static-cnp-path:
enable-recorder:false
k8s-heartbeat-timeout:30s
mesh-auth-spire-admin-socket:
gateway-api-secrets-namespace:
remove-cilium-node-taints:true
enable-cilium-endpoint-slice:false
node-port-range:
encrypt-node:false
http-idle-timeout:0
config:
auto-create-cilium-node-resource:true
enable-ipsec-encrypted-overlay:false
ipv4-node:auto
egress-gateway-policy-map-max:16384
enable-icmp-rules:true
node-port-bind-protection:true
k8s-require-ipv4-pod-cidr:false
enable-ipv4-fragment-tracking:true
cni-exclusive:true
operator-prometheus-serve-addr::9963
bpf-ct-timeout-regular-any:1m0s
kvstore-opt:
dnsproxy-socket-linger-timeout:10
label-prefix-file:
bpf-auth-map-max:524288
enable-hubble:true
hubble-redact-http-userinfo:true
proxy-xff-num-trusted-hops-ingress:0
config-dir:/tmp/cilium/config-map
routing-mode:tunnel
proxy-prometheus-port:0
enable-health-checking:true
dnsproxy-enable-transparent-mode:true
join-cluster:false
kvstore-lease-ttl:15m0s
encryption-strict-mode-allow-remote-node-identities:false
prepend-iptables-chains:true
tofqdns-max-deferred-connection-deletes:10000
disable-endpoint-crd:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
ipv4-pod-subnets:
enable-session-affinity:false
mesh-auth-queue-size:1024
metrics:
debug:false
enable-ipv4:true
k8s-api-server:
cmdref:
api-rate-limit:
mesh-auth-enabled:true
iptables-random-fully:false
hubble-flowlogs-config-path:
tunnel-port:0
external-envoy-proxy:true
endpoint-bpf-prog-watchdog-interval:30s
trace-sock:true
agent-health-port:9879
enable-bbr:false
pprof-address:localhost
cgroup-root:/run/cilium/cgroupv2
proxy-gid:1337
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-hubble-recorder-api:true
bpf-map-event-buffers:
endpoint-gc-interval:5m0s
hubble-export-allowlist:
agent-labels:
http-normalize-path:true
enable-host-firewall:false
enable-k8s-networkpolicy:true
k8s-namespace:kube-system
controller-group-metrics:
local-router-ipv6:
preallocate-bpf-maps:false
enable-l7-proxy:true
enable-external-ips:false
egress-multi-home-ip-rule-compat:false
datapath-mode:veth
enable-well-known-identities:false
ipv4-native-routing-cidr:
exclude-node-label-patterns:
k8s-service-proxy-name:
bpf-events-trace-enabled:true
ipv4-range:auto
enable-wireguard-userspace-fallback:false
enable-ipv6-big-tcp:false
envoy-base-id:0
hubble-redact-http-headers-deny:
auto-direct-node-routes:false
ipv6-native-routing-cidr:
local-max-addr-scope:252
bpf-lb-sock-terminate-pod-connections:false
set-cilium-node-taints:true
enable-custom-calls:false
hubble-drop-events-reasons:auth_required,policy_denied
hubble-export-file-compress:false
nat-map-stats-entries:32
k8s-service-cache-size:128
enable-ipv4-egress-gateway:false
clustermesh-config:/var/lib/cilium/clustermesh/
log-driver:
labels:
vlan-bpf-bypass:
vtep-endpoint:
clustermesh-sync-timeout:1m0s
tofqdns-proxy-response-max-delay:100ms
enable-stale-cilium-endpoint-cleanup:true
l2-announcements-renew-deadline:5s
hubble-listen-address::4244
bpf-events-policy-verdict-enabled:true
ipv6-pod-subnets:
```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 4215893                           /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 4215893                           /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 4215893                           /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400e000000 rw-p 00000000 00:00 0 
400e000000-4010000000 ---p 00000000 00:00 0 
ffff77072000-ffff77328000 rw-p 00000000 00:00 0 
ffff77330000-ffff77451000 rw-p 00000000 00:00 0 
ffff77451000-ffff77492000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff77492000-ffff774d3000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff774d3000-ffff77513000 rw-p 00000000 00:00 0 
ffff77513000-ffff77515000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff77515000-ffff77517000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff77517000-ffff77ade000 rw-p 00000000 00:00 0 
ffff77ade000-ffff77bde000 rw-p 00000000 00:00 0 
ffff77bde000-ffff77bef000 rw-p 00000000 00:00 0 
ffff77bef000-ffff79bef000 rw-p 00000000 00:00 0 
ffff79bef000-ffff79c6f000 ---p 00000000 00:00 0 
ffff79c6f000-ffff79c70000 rw-p 00000000 00:00 0 
ffff79c70000-ffff99c6f000 ---p 00000000 00:00 0 
ffff99c6f000-ffff99c70000 rw-p 00000000 00:00 0 
ffff99c70000-ffffb9bff000 ---p 00000000 00:00 0 
ffffb9bff000-ffffb9c00000 rw-p 00000000 00:00 0 
ffffb9c00000-ffffbdbf1000 ---p 00000000 00:00 0 
ffffbdbf1000-ffffbdbf2000 rw-p 00000000 00:00 0 
ffffbdbf2000-ffffbe3ef000 ---p 00000000 00:00 0 
ffffbe3ef000-ffffbe3f0000 rw-p 00000000 00:00 0 
ffffbe3f0000-ffffbe4ef000 ---p 00000000 00:00 0 
ffffbe4ef000-ffffbe54f000 rw-p 00000000 00:00 0 
ffffbe54f000-ffffbe551000 r--p 00000000 00:00 0                          [vvar]
ffffbe551000-ffffbe552000 r-xp 00000000 00:00 0                          [vdso]
fffff1dcc000-fffff1ded000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=8) {
  (string) (len=11) "10.68.0.225": (string) (len=45) "cilium-test-1/echo-same-node-86d9cc975c-c4l95",
  (string) (len=10) "10.68.0.96": (string) (len=50) "kube-system/clustermesh-apiserver-58d4b777bf-99qpn",
  (string) (len=10) "10.68.0.43": (string) (len=36) "cilium-test-1/client-974f6c69d-bt9vc",
  (string) (len=11) "10.68.0.108": (string) (len=37) "cilium-test-1/client2-57cf4468f-lnxds",
  (string) (len=10) "10.68.0.27": (string) (len=6) "router",
  (string) (len=10) "10.68.0.50": (string) (len=6) "health",
  (string) (len=11) "10.68.0.204": (string) (len=35) "kube-system/coredns-cc6ccd49c-829ft",
  (string) (len=11) "10.68.0.251": (string) (len=35) "kube-system/coredns-cc6ccd49c-q2q86"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.135.109": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40024cb760)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x40018a4fc0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x40018a4fc0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=6) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4000f378c0)(frontends:[10.100.35.22]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.Service)(0x400675c370)(frontends:[10.100.117.102]/ports=[http]/selector=map[name:echo-same-node]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x400205dad0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x400205db80)(frontends:[10.100.230.119]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x400205dc30)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4000b19c30)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=5) {
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.EndpointSlices)(0x4000e8ed58)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-jzsmb": (*k8s.Endpoints)(0x400318cd00)(10.68.0.225:8080/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001622260)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40025224e0)(172.31.140.140:443/TCP,172.31.200.26:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001622268)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-7mrj7": (*k8s.Endpoints)(0x4003948c30)(172.31.135.109:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001622270)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-gq5xg": (*k8s.Endpoints)(0x4003cf5040)(10.68.0.204:53/TCP[eu-west-3a],10.68.0.204:53/UDP[eu-west-3a],10.68.0.204:9153/TCP[eu-west-3a],10.68.0.251:53/TCP[eu-west-3a],10.68.0.251:53/UDP[eu-west-3a],10.68.0.251:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40016236b8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-r7jw8": (*k8s.Endpoints)(0x4007a465b0)(10.68.0.96:2379/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40005fb0a0)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40029cb590)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4002339518
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40029c7b00,
  gcExited: (chan struct {}) 0x40029c7b60,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4000c41280)({
     ObserverVec: (*prometheus.HistogramVec)(0x400087b960)({
      MetricVec: (*prometheus.MetricVec)(0x4000b508a0)({
       metricMap: (*prometheus.metricMap)(0x4000b508d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000270600)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4000c41300)({
     ObserverVec: (*prometheus.HistogramVec)(0x400087b968)({
      MetricVec: (*prometheus.MetricVec)(0x4000b50990)({
       metricMap: (*prometheus.metricMap)(0x4000b509c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40005f0120)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4000c41380)({
     GaugeVec: (*prometheus.GaugeVec)(0x400087b980)({
      MetricVec: (*prometheus.MetricVec)(0x4000b50a20)({
       metricMap: (*prometheus.metricMap)(0x4000b50a50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40005f0180)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4000c41400)({
     GaugeVec: (*prometheus.GaugeVec)(0x400087b988)({
      MetricVec: (*prometheus.MetricVec)(0x4000b50ab0)({
       metricMap: (*prometheus.metricMap)(0x4000b50b10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40005f01e0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4000c41480)({
     GaugeVec: (*prometheus.GaugeVec)(0x400087b9a0)({
      MetricVec: (*prometheus.MetricVec)(0x4000b50ba0)({
       metricMap: (*prometheus.metricMap)(0x4000b50bd0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40005f0240)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4000c41500)({
     GaugeVec: (*prometheus.GaugeVec)(0x400087b9a8)({
      MetricVec: (*prometheus.MetricVec)(0x4000b50c30)({
       metricMap: (*prometheus.metricMap)(0x4000b50c60)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40005f1140)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4000c41580)({
     GaugeVec: (*prometheus.GaugeVec)(0x400087b9c0)({
      MetricVec: (*prometheus.MetricVec)(0x4000b50cf0)({
       metricMap: (*prometheus.metricMap)(0x4000b50d50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40005f1380)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4000c41600)({
     GaugeVec: (*prometheus.GaugeVec)(0x400087b9c8)({
      MetricVec: (*prometheus.MetricVec)(0x4000b50db0)({
       metricMap: (*prometheus.metricMap)(0x4000b50de0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40005f13e0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4000c41680)({
     ObserverVec: (*prometheus.HistogramVec)(0x400087b9e0)({
      MetricVec: (*prometheus.MetricVec)(0x4000b50e40)({
       metricMap: (*prometheus.metricMap)(0x4000b50e70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40005f1440)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40005fb0a0)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x400029c4d0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4000079080)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 287ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.68.0.0/24, 
Allocated addresses:
  10.68.0.108 (cilium-test-1/client2-57cf4468f-lnxds)
  10.68.0.204 (kube-system/coredns-cc6ccd49c-829ft)
  10.68.0.225 (cilium-test-1/echo-same-node-86d9cc975c-c4l95)
  10.68.0.251 (kube-system/coredns-cc6ccd49c-q2q86)
  10.68.0.27 (router)
  10.68.0.43 (cilium-test-1/client-974f6c69d-bt9vc)
  10.68.0.50 (health)
  10.68.0.96 (kube-system/clustermesh-apiserver-58d4b777bf-99qpn)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m58s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 11m59s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b19ded4dd5cc98cf
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      177/177 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    54s ago        never        0       no error   
  ct-map-pressure                                                     26s ago        never        0       no error   
  daemon-validate-config                                              32s ago        never        0       no error   
  dns-garbage-collector-job                                           59s ago        never        0       no error   
  endpoint-1060-regeneration-recovery                                 never          never        0       no error   
  endpoint-1657-regeneration-recovery                                 never          never        0       no error   
  endpoint-1795-regeneration-recovery                                 never          never        0       no error   
  endpoint-1859-regeneration-recovery                                 never          never        0       no error   
  endpoint-3950-regeneration-recovery                                 never          never        0       no error   
  endpoint-396-regeneration-recovery                                  never          never        0       no error   
  endpoint-586-regeneration-recovery                                  never          never        0       no error   
  endpoint-629-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         4m59s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                26s ago        never        0       no error   
  ipcache-inject-labels                                               56s ago        never        0       no error   
  k8s-heartbeat                                                       29s ago        never        0       no error   
  link-cache                                                          11s ago        never        0       no error   
  local-identity-checkpoint                                           2m35s ago      never        0       no error   
  node-neighbor-link-updater                                          6s ago         never        0       no error   
  remote-etcd-cmesh1                                                  11m59s ago     never        0       no error   
  remote-etcd-cmesh10                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh100                                                11m58s ago     never        0       no error   
  remote-etcd-cmesh101                                                11m59s ago     never        0       no error   
  remote-etcd-cmesh102                                                11m59s ago     never        0       no error   
  remote-etcd-cmesh103                                                11m58s ago     never        0       no error   
  remote-etcd-cmesh104                                                11m58s ago     never        0       no error   
  remote-etcd-cmesh105                                                11m59s ago     never        0       no error   
  remote-etcd-cmesh106                                                11m58s ago     never        0       no error   
  remote-etcd-cmesh107                                                11m59s ago     never        0       no error   
  remote-etcd-cmesh108                                                11m59s ago     never        0       no error   
  remote-etcd-cmesh109                                                11m58s ago     never        0       no error   
  remote-etcd-cmesh11                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh110                                                11m59s ago     never        0       no error   
  remote-etcd-cmesh111                                                11m59s ago     never        0       no error   
  remote-etcd-cmesh112                                                11m59s ago     never        0       no error   
  remote-etcd-cmesh113                                                11m58s ago     never        0       no error   
  remote-etcd-cmesh114                                                11m59s ago     never        0       no error   
  remote-etcd-cmesh115                                                11m58s ago     never        0       no error   
  remote-etcd-cmesh116                                                11m58s ago     never        0       no error   
  remote-etcd-cmesh117                                                11m59s ago     never        0       no error   
  remote-etcd-cmesh118                                                11m58s ago     never        0       no error   
  remote-etcd-cmesh119                                                11m59s ago     never        0       no error   
  remote-etcd-cmesh12                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh120                                                11m59s ago     never        0       no error   
  remote-etcd-cmesh121                                                11m59s ago     never        0       no error   
  remote-etcd-cmesh122                                                11m59s ago     never        0       no error   
  remote-etcd-cmesh123                                                11m59s ago     never        0       no error   
  remote-etcd-cmesh124                                                11m59s ago     never        0       no error   
  remote-etcd-cmesh125                                                11m58s ago     never        0       no error   
  remote-etcd-cmesh126                                                11m58s ago     never        0       no error   
  remote-etcd-cmesh127                                                11m57s ago     never        0       no error   
  remote-etcd-cmesh128                                                11m58s ago     never        0       no error   
  remote-etcd-cmesh13                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh14                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh15                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh16                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh17                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh18                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh19                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh2                                                  11m59s ago     never        0       no error   
  remote-etcd-cmesh20                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh21                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh22                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh23                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh24                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh25                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh26                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh27                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh28                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh29                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh3                                                  11m59s ago     never        0       no error   
  remote-etcd-cmesh30                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh31                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh32                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh33                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh34                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh35                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh36                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh37                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh38                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh39                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh4                                                  11m58s ago     never        0       no error   
  remote-etcd-cmesh40                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh41                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh42                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh43                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh44                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh45                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh46                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh47                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh48                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh49                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh5                                                  11m58s ago     never        0       no error   
  remote-etcd-cmesh50                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh51                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh52                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh53                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh54                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh55                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh56                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh57                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh58                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh59                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh6                                                  11m58s ago     never        0       no error   
  remote-etcd-cmesh60                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh61                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh62                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh63                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh64                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh65                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh66                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh67                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh68                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh7                                                  11m59s ago     never        0       no error   
  remote-etcd-cmesh70                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh71                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh72                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh73                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh74                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh75                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh76                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh77                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh78                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh79                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh8                                                  11m59s ago     never        0       no error   
  remote-etcd-cmesh80                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh81                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh82                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh83                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh84                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh85                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh86                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh87                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh88                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh89                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh9                                                  11m59s ago     never        0       no error   
  remote-etcd-cmesh90                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh91                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh92                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh93                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh94                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh95                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh96                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh97                                                 11m58s ago     never        0       no error   
  remote-etcd-cmesh98                                                 11m59s ago     never        0       no error   
  remote-etcd-cmesh99                                                 11m59s ago     never        0       no error   
  resolve-identity-1060                                               1m3s ago       never        0       no error   
  resolve-identity-1657                                               4m55s ago      never        0       no error   
  resolve-identity-1795                                               4m55s ago      never        0       no error   
  resolve-identity-1859                                               1m3s ago       never        0       no error   
  resolve-identity-3950                                               4m56s ago      never        0       no error   
  resolve-identity-396                                                4m56s ago      never        0       no error   
  resolve-identity-586                                                2m10s ago      never        0       no error   
  resolve-identity-629                                                1m4s ago       never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-bt9vc                 6m3s ago       never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-lnxds                6m3s ago       never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-c4l95        6m4s ago       never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-58d4b777bf-99qpn   12m10s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-829ft                  24m56s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-q2q86                  24m55s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      24m56s ago     never        0       no error   
  sync-policymap-1060                                                 6m3s ago       never        0       no error   
  sync-policymap-1657                                                 9m50s ago      never        0       no error   
  sync-policymap-1795                                                 9m50s ago      never        0       no error   
  sync-policymap-1859                                                 6m3s ago       never        0       no error   
  sync-policymap-3950                                                 9m53s ago      never        0       no error   
  sync-policymap-396                                                  9m55s ago      never        0       no error   
  sync-policymap-586                                                  12m10s ago     never        0       no error   
  sync-policymap-629                                                  6m4s ago       never        0       no error   
  sync-to-k8s-ciliumendpoint (1060)                                   3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1657)                                   5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1859)                                   3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3950)                                   6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (586)                                    10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (629)                                    4s ago         never        0       no error   
  sync-utime                                                          56s ago        never        0       no error   
  write-cni-file                                                      24m59s ago     never        0       no error   
Proxy Status:            OK, ip 10.68.0.27, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 4521984, max 4587519
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 181.24   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.140.140:443 (active)    
                                          2 => 172.31.200.26:443 (active)     
2    10.100.230.119:443    ClusterIP      1 => 172.31.135.109:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.68.0.204:53 (active)        
                                          2 => 10.68.0.251:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.68.0.204:9153 (active)      
                                          2 => 10.68.0.251:9153 (active)      
5    10.100.35.22:2379     ClusterIP      1 => 10.68.0.96:2379 (active)       
6    10.100.117.102:8080   ClusterIP      1 => 10.68.0.225:8080 (active)      
```

#### Policy get

```
:
 []
Revision: 129

```


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                    IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                      
396        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                     ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                       
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                                 
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                  
                                                           reserved:host                                                                                               
586        Disabled           Disabled          4523841    k8s:app.kubernetes.io/name=clustermesh-apiserver                                      10.68.0.96    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                        
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh69                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                               
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=clustermesh-apiserver                                                                           
629        Disabled           Disabled          4578226    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.68.0.225   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh69                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node                                                      
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                               
                                                           k8s:kind=echo                                                                                               
                                                           k8s:name=echo-same-node                                                                                     
                                                           k8s:other=echo                                                                                              
1060       Disabled           Disabled          4522166    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.68.0.43    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh69                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client                                                              
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                               
                                                           k8s:kind=client                                                                                             
                                                           k8s:name=client                                                                                             
1657       Disabled           Disabled          4545743    k8s:eks.amazonaws.com/component=coredns                                               10.68.0.251   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh69                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=kube-dns                                                                                        
1795       Disabled           Disabled          4          reserved:health                                                                       10.68.0.50    ready   
1859       Disabled           Disabled          4574229    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.68.0.108   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh69                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client2                                                             
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                               
                                                           k8s:kind=client                                                                                             
                                                           k8s:name=client2                                                                                            
                                                           k8s:other=client                                                                                            
3950       Disabled           Disabled          4545743    k8s:eks.amazonaws.com/component=coredns                                               10.68.0.204   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh69                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=kube-dns                                                                                        
```

#### BPF Policy Get 396

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 396

```
Invalid argument: unknown type 396
```


#### Endpoint Get 396

```
[
  {
    "id": 396,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-396-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "3226d8fd-2f3d-417c-8295-75937ae36945"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-396",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:49:28.885Z",
            "success-count": 5
          },
          "uuid": "719003e6-d527-403d-9d88-ab8257c5a610"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-396",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:44:30.088Z",
            "success-count": 2
          },
          "uuid": "8f85ab83-bf18-4f5d-8d68-3d46a3a9442f"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "d6:9a:8b:ab:b3:45",
        "interface-name": "cilium_host",
        "mac": "d6:9a:8b:ab:b3:45"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 396

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 396

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:29Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:37:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:37:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:37:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:37:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:36:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:36:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:36:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:36:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:29:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:29:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:29:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:29:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:29:30Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T12:29:30Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:29:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:29:28Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:29:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:29:28Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:29:28Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 586

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5469744   56521     0        
Allow    Ingress     1          ANY          NONE         disabled    5622907   57635     0        
Allow    Egress      0          ANY          NONE         disabled    5707013   58628     0        

```


#### BPF CT List 586

```
Invalid argument: unknown type 586
```


#### Endpoint Get 586

```
[
  {
    "id": 586,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-586-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "e555403b-53d9-4eb2-b21d-2152f5dddcc6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-586",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:52:15.520Z",
            "success-count": 3
          },
          "uuid": "fe2a0cbd-2651-4811-8da1-c0f0e4904b27"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-58d4b777bf-99qpn",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:42:15.519Z",
            "success-count": 1
          },
          "uuid": "2fdffffd-e229-4f89-87da-9888cdb876dc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-586",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:42:15.550Z",
            "success-count": 1
          },
          "uuid": "af9f8b58-6d4e-44b1-9c6c-0cc83d305abd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (586)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:25.622Z",
            "success-count": 75
          },
          "uuid": "1ffb9857-178c-40d2-ab2b-8efa5ff9f586"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "2ad5bbff8165af8a61f936224e7ebaee073407a3eaa01295830c64afdb8f5949:eth0",
        "container-id": "2ad5bbff8165af8a61f936224e7ebaee073407a3eaa01295830c64afdb8f5949",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-58d4b777bf-99qpn",
        "pod-name": "kube-system/clustermesh-apiserver-58d4b777bf-99qpn"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4523841,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh69",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=58d4b777bf"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh69",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.68.0.96",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "52:c5:29:2f:86:a7",
        "interface-index": 18,
        "interface-name": "lxca69d37345a4b",
        "mac": "1e:29:c9:34:30:71"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4523841,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4523841,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 586

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 586

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:29Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:42:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:15Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:42:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:42:15Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:42:15Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4523841

```
ID        LABELS
4523841   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh69
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 629

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    356161   4156      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 629

```
Invalid argument: unknown type 629
```


#### Endpoint Get 629

```
[
  {
    "id": 629,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-629-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c98c155d-201b-41c2-9938-d97fdb917285"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-629",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:21.597Z",
            "success-count": 2
          },
          "uuid": "abaa1f08-9bf7-4286-a390-8e66dc859e2e"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-c4l95",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:21.596Z",
            "success-count": 1
          },
          "uuid": "f73bbf28-d112-4a69-a842-3091a3aba362"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-629",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:21.646Z",
            "success-count": 1
          },
          "uuid": "e7b1c368-118c-45d9-92e9-f3f715a3894c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (629)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:21.645Z",
            "success-count": 38
          },
          "uuid": "65563e95-03be-4fae-a229-16d0c7fbb9c3"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "d9e567c1e6dc37e7054342d81e36ca4c8bcd2b96014e19a581896eb67b0f39b1:eth0",
        "container-id": "d9e567c1e6dc37e7054342d81e36ca4c8bcd2b96014e19a581896eb67b0f39b1",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "echo-same-node-86d9cc975c-c4l95",
        "pod-name": "cilium-test-1/echo-same-node-86d9cc975c-c4l95"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4578226,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh69",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=86d9cc975c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh69",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:24Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns-53",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "dns-udp-53",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "http-8080",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.68.0.225",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "72:4d:49:16:de:de",
        "interface-index": 20,
        "interface-name": "lxcf31f9246134b",
        "mac": "2a:c1:be:81:4b:11"
      },
      "policy": {
        "proxy-policy-revision": 126,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4578226,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 126,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4578226,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 126
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 629

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 629

```
Timestamp              Status   State                   Message
2024-10-24T12:51:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:39Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added

```


#### Identity get 4578226

```
ID        LABELS
4578226   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh69
          k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=echo
          k8s:name=echo-same-node
          k8s:other=echo

```


#### BPF Policy Get 1060

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1060

```
Invalid argument: unknown type 1060
```


#### Endpoint Get 1060

```
[
  {
    "id": 1060,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1060-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ebe4f472-4709-485c-8c3d-2d3cf16f6c24"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1060",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:21.913Z",
            "success-count": 2
          },
          "uuid": "3ba77852-55ca-41d1-a7b7-2a60d6a303f3"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client-974f6c69d-bt9vc",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:21.910Z",
            "success-count": 1
          },
          "uuid": "6193e92e-1dea-4024-b00a-28a989829fa7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1060",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:21.968Z",
            "success-count": 1
          },
          "uuid": "67dfbf47-b1ac-4ca0-b8e0-896d2aa34ea9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1060)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:21.952Z",
            "success-count": 38
          },
          "uuid": "68145b8b-7294-49b9-b65c-f1367e104cfa"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "9c1b01b27cab48bc327b8a3a1ac3cb9dc8dc1e5b71eecee101be99310ad991fe:eth0",
        "container-id": "9c1b01b27cab48bc327b8a3a1ac3cb9dc8dc1e5b71eecee101be99310ad991fe",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client-974f6c69d-bt9vc",
        "pod-name": "cilium-test-1/client-974f6c69d-bt9vc"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4522166,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh69",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=974f6c69d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh69",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:33Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.68.0.43",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "c6:ec:84:78:ba:4a",
        "interface-index": 22,
        "interface-name": "lxc2b154f7c41a0",
        "mac": "fa:fc:fb:e4:e8:0a"
      },
      "policy": {
        "proxy-policy-revision": 129,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4522166,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4522166,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1060

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1060

```
Timestamp              Status   State                   Message
2024-10-24T12:51:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:39Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:28Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)

```


#### Identity get 4522166

```
ID        LABELS
4522166   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh69
          k8s:io.cilium.k8s.policy.serviceaccount=client
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=client
          k8s:name=client

```


#### BPF Policy Get 1657

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2862     27        0        
Allow    Ingress     1          ANY          NONE         disabled    141806   1627      0        
Allow    Egress      0          ANY          NONE         disabled    20061    223       0        

```


#### BPF CT List 1657

```
Invalid argument: unknown type 1657
```


#### Endpoint Get 1657

```
[
  {
    "id": 1657,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1657-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f8640f5c-0214-4137-9f3d-c06bb0ce080b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1657",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:49:29.806Z",
            "success-count": 5
          },
          "uuid": "b4e347e8-a0b6-42ee-b8aa-48d18c68c54c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-q2q86",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:29:29.804Z",
            "success-count": 1
          },
          "uuid": "8de958b0-953e-465b-b5ee-a5149be5a246"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1657",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:44:34.944Z",
            "success-count": 2
          },
          "uuid": "369ae0fc-cfee-4033-bfff-65b6ea1d31cc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1657)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:19.933Z",
            "success-count": 151
          },
          "uuid": "e6101a9e-cdfd-4073-ae30-e66ab0d2ca09"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "a0d3a3549e2e7e166fa614956eec0788eb7f23344f6a410f01afdc5d1e7e9c8a:eth0",
        "container-id": "a0d3a3549e2e7e166fa614956eec0788eb7f23344f6a410f01afdc5d1e7e9c8a",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-q2q86",
        "pod-name": "kube-system/coredns-cc6ccd49c-q2q86"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4545743,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh69",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh69",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.68.0.251",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "3e:23:60:2f:0a:4c",
        "interface-index": 14,
        "interface-name": "lxc96bc180bf6c0",
        "mac": "4a:d0:3f:1f:31:4f"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4545743,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4545743,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1657

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1657

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:29Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:37:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:37:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:37:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:37:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:36:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:36:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:36:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:36:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:29:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:29:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:29:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:29:34Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:29:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:29:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:29:30Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:29:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:29:29Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:29:29Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4545743

```
ID        LABELS
4545743   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh69
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1795

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6188904   76625     0        
Allow    Ingress     1          ANY          NONE         disabled    62571     756       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        

```


#### BPF CT List 1795

```
Invalid argument: unknown type 1795
```


#### Endpoint Get 1795

```
[
  {
    "id": 1795,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1795-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "abf01971-3ae0-485d-bfdf-3f4eab719b38"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1795",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:49:29.966Z",
            "success-count": 5
          },
          "uuid": "0a0b4d1c-938e-4261-9382-80dd830b9371"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1795",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:44:35.018Z",
            "success-count": 2
          },
          "uuid": "c6eda0da-1046-41c1-ae7c-6d8be92a1699"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.68.0.50",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "92:63:51:bb:e7:fe",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "12:58:bd:68:ac:d2"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1795

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1795

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:29Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:42:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:37:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:37:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:37:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:37:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:36:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:36:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:36:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:36:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:29:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-24T12:29:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:29:35Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-24T12:29:35Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:29:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-24T12:29:31Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:29:30Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T12:29:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:29:29Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:29:28Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 1859

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1859

```
Invalid argument: unknown type 1859
```


#### Endpoint Get 1859

```
[
  {
    "id": 1859,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1859-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5ee5cc82-20e2-45d1-8ec0-54595821b45c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1859",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:21.982Z",
            "success-count": 2
          },
          "uuid": "097ff386-c297-43e2-a007-b0d64e668dc8"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client2-57cf4468f-lnxds",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:21.982Z",
            "success-count": 1
          },
          "uuid": "30a1f2bb-3301-41c0-b796-277dcf77c5df"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1859",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:22.034Z",
            "success-count": 1
          },
          "uuid": "dea34abe-ce8d-4db3-a44f-da17aae66009"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1859)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:22.024Z",
            "success-count": 38
          },
          "uuid": "9f4cdd50-b278-4e30-a06a-e9f9fd48e45a"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "061491602996b084cceb37cc3b9f3f7a19fb4bc1f0a08be88a9045c2733fb21c:eth0",
        "container-id": "061491602996b084cceb37cc3b9f3f7a19fb4bc1f0a08be88a9045c2733fb21c",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client2-57cf4468f-lnxds",
        "pod-name": "cilium-test-1/client2-57cf4468f-lnxds"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4574229,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh69",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=57cf4468f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh69",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:33Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.68.0.108",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "b2:24:60:89:0e:38",
        "interface-index": 24,
        "interface-name": "lxc33385c5d2182",
        "mac": "02:bf:bb:73:00:46"
      },
      "policy": {
        "proxy-policy-revision": 129,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4574229,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4574229,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1859

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1859

```
Timestamp              Status   State                   Message
2024-10-24T12:51:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:28Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests

```


#### Identity get 4574229

```
ID        LABELS
4574229   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh69
          k8s:io.cilium.k8s.policy.serviceaccount=client2
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=client
          k8s:name=client2
          k8s:other=client

```


#### BPF Policy Get 3950

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3034     33        0        
Allow    Ingress     1          ANY          NONE         disabled    141410   1621      0        
Allow    Egress      0          ANY          NONE         disabled    20503    228       0        

```


#### BPF CT List 3950

```
Invalid argument: unknown type 3950
```


#### Endpoint Get 3950

```
[
  {
    "id": 3950,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3950-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "717b3033-beb1-48b4-bc30-ba0924100688"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3950",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:49:29.541Z",
            "success-count": 5
          },
          "uuid": "1a7c66a2-3f1a-4de9-877d-fb6929ba6a24"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-829ft",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:29:29.539Z",
            "success-count": 1
          },
          "uuid": "51573c68-2222-481a-ae58-36fe72ad3740"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3950",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:44:31.911Z",
            "success-count": 2
          },
          "uuid": "d04ce791-8c7b-4fc2-b775-55836423a6fc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3950)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:19.646Z",
            "success-count": 151
          },
          "uuid": "c4210a63-3054-4915-8195-4f03ed6804c1"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "0fade2f972abfcd53477c083368d867b6f60ee49757275cf8d8c8484c39d4301:eth0",
        "container-id": "0fade2f972abfcd53477c083368d867b6f60ee49757275cf8d8c8484c39d4301",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-829ft",
        "pod-name": "kube-system/coredns-cc6ccd49c-829ft"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4545743,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh69",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh69",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.68.0.204",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "0a:35:9e:d6:a8:13",
        "interface-index": 12,
        "interface-name": "lxc002133366046",
        "mac": "82:e7:fc:53:53:e5"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4545743,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4545743,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3950

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3950

```
Timestamp              Status    State                   Message
2024-10-24T12:48:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:29Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:42:29Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:29Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T12:42:29Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:42:28Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:28Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:28Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:28Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:27Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:27Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:26Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:42:26Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:26Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:42:26Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:37:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:37:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:37:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:37:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:36:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:36:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:36:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:36:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:29:35Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:29:35Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:29:35Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:29:32Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:29:31Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:29:30Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:29:29Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:29:29Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:29:29Z   OK        ready                   Set identity for this endpoint
2024-10-24T12:29:29Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:29:29Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 4545743

```
ID        LABELS
4545743   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh69
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```

