35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:16+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:16+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:17+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:17+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:17+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:17+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:21+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
110: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
113: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
495: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
498: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
499: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
502: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
503: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:29:32+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 136
504: sched_cls  name tail_handle_ipv4  tag 63c6dc4bdfcdd982  gpl
	loaded_at 2024-10-24T12:29:32+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,104
	btf_id 137
505: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:29:32+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,104
	btf_id 138
506: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:29:32+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 139
528: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
532: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
533: sched_cls  name cil_from_container  tag c75ca4e885908907  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 165
534: sched_cls  name tail_handle_ipv4  tag 538389b60cf8d8fc  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 166
535: sched_cls  name tail_ipv4_to_endpoint  tag 3e681e9903b0d291  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,91,39,112,40,37,38
	btf_id 167
536: sched_cls  name tail_ipv4_ct_ingress  tag b3387ec7e333b62f  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 168
537: sched_cls  name tail_handle_arp  tag cd86c1372052b53a  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 169
539: sched_cls  name __send_drop_notify  tag 94bf4bfe542b6df4  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 171
540: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 172
541: sched_cls  name tail_ipv4_ct_egress  tag f5c9eacbd3fae423  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 173
542: sched_cls  name handle_policy  tag 26ab05a3ad61ec65  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,91,39,84,75,40,37,38
	btf_id 174
543: sched_cls  name tail_handle_ipv4_cont  tag 10259d3313cd4aa0  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,91,82,83,39,76,74,77,112,40,37,38,81
	btf_id 175
544: sched_cls  name cil_from_container  tag 51e2f103170d02bf  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 177
545: sched_cls  name tail_handle_ipv4_cont  tag 0de77ad582546d5b  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,114,41,106,82,83,39,76,74,77,115,40,37,38,81
	btf_id 178
546: sched_cls  name tail_ipv4_ct_ingress  tag a4e1572d97b66bf5  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,114,84
	btf_id 179
547: sched_cls  name tail_handle_arp  tag 4a0643be56cb3cb5  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 180
549: sched_cls  name __send_drop_notify  tag ae1681113212b338  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 182
550: sched_cls  name tail_ipv4_ct_egress  tag f5c9eacbd3fae423  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,114,84
	btf_id 183
551: sched_cls  name tail_ipv4_to_endpoint  tag 6510463c1a16c86d  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,114,41,82,83,80,106,39,115,40,37,38
	btf_id 184
552: sched_cls  name handle_policy  tag 903f2e85701f550b  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,114,41,80,106,39,84,75,40,37,38
	btf_id 185
553: sched_cls  name tail_handle_ipv4  tag 77ceaea4e71e7be1  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 186
554: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 187
555: sched_cls  name tail_handle_ipv4_cont  tag 24dfbad039b05cb8  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,117,41,105,82,83,39,76,74,77,116,40,37,38,81
	btf_id 189
556: sched_cls  name handle_policy  tag 2dabb50318583bc9  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,116,82,83,117,41,80,105,39,84,75,40,37,38
	btf_id 190
557: sched_cls  name tail_handle_ipv4  tag 62dfb67d2e79885e  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 191
558: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,116,82,83,117,84
	btf_id 192
560: sched_cls  name tail_ipv4_to_endpoint  tag 9fc248606caaa773  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,117,41,82,83,80,105,39,116,40,37,38
	btf_id 194
561: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 195
562: sched_cls  name tail_handle_arp  tag 4ac22bc0cd8a2537  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 196
563: sched_cls  name cil_from_container  tag 9695fbdfd9d97c85  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 116,76
	btf_id 197
564: sched_cls  name __send_drop_notify  tag b45289ee30b48f56  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 198
565: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
568: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
569: sched_cls  name tail_ipv4_ct_ingress  tag 7211ddd9b9d236bb  gpl
	loaded_at 2024-10-24T12:29:35+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,116,82,83,117,84
	btf_id 199
571: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,119
	btf_id 202
572: sched_cls  name __send_drop_notify  tag 72abf04db3189f89  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
573: sched_cls  name tail_handle_ipv4_from_host  tag 64c1e084fbdc2529  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 204
574: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 205
576: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 207
578: sched_cls  name __send_drop_notify  tag 72abf04db3189f89  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 210
579: sched_cls  name tail_handle_ipv4_from_host  tag 64c1e084fbdc2529  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 211
580: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 212
582: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 214
586: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 219
588: sched_cls  name __send_drop_notify  tag 72abf04db3189f89  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 221
589: sched_cls  name tail_handle_ipv4_from_host  tag 64c1e084fbdc2529  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 222
590: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 223
592: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,126,75
	btf_id 226
594: sched_cls  name __send_drop_notify  tag 72abf04db3189f89  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 228
595: sched_cls  name tail_handle_ipv4_from_host  tag 64c1e084fbdc2529  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,126
	btf_id 229
596: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:29:36+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,126
	btf_id 230
637: sched_cls  name handle_policy  tag fbcd11d315b472f5  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,139,82,83,138,41,80,137,39,84,75,40,37,38
	btf_id 245
638: sched_cls  name __send_drop_notify  tag a8de63a7d420b71e  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 246
639: sched_cls  name tail_ipv4_ct_ingress  tag eb0b6b7a67fdf131  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 247
640: sched_cls  name tail_handle_arp  tag f0b9766563cf6a04  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,139
	btf_id 248
641: sched_cls  name cil_from_container  tag 6aade2c659a89a90  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 139,76
	btf_id 249
643: sched_cls  name tail_handle_ipv4_cont  tag 2ee822efc22f4281  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,138,41,137,82,83,39,76,74,77,139,40,37,38,81
	btf_id 251
644: sched_cls  name tail_ipv4_to_endpoint  tag c77ff620ccfd61c9  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,138,41,82,83,80,137,39,139,40,37,38
	btf_id 252
645: sched_cls  name tail_ipv4_ct_egress  tag e03d78fec9725e47  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 253
646: sched_cls  name tail_handle_ipv4  tag e68d4f0285b2f3ef  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,139
	btf_id 254
647: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,139
	btf_id 255
648: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
651: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
664: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
667: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
668: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
671: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
687: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
690: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
713: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
716: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
717: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
720: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
721: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
724: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
725: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
728: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
729: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
732: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
733: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
736: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3311: sched_cls  name tail_ipv4_to_endpoint  tag 9275df09d0d0e6f1  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,631,41,82,83,80,147,39,632,40,37,38
	btf_id 3101
3313: sched_cls  name handle_policy  tag c98eda5a13c2e8a1  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,632,82,83,631,41,80,147,39,84,75,40,37,38
	btf_id 3102
3314: sched_cls  name tail_handle_ipv4_cont  tag dcac46de10d9d5b8  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,631,41,147,82,83,39,76,74,77,632,40,37,38,81
	btf_id 3106
3315: sched_cls  name cil_from_container  tag 5b56d12b320ba4e7  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 632,76
	btf_id 3107
3317: sched_cls  name tail_ipv4_ct_egress  tag 3525e66c7b7ee860  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,632,82,83,631,84
	btf_id 3109
3318: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,632
	btf_id 3110
3319: sched_cls  name tail_handle_arp  tag 42608198a00a25b5  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,632
	btf_id 3111
3321: sched_cls  name tail_handle_ipv4  tag a4859070672e2470  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,632
	btf_id 3112
3322: sched_cls  name tail_ipv4_ct_ingress  tag 515b5127848a32a6  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,632,82,83,631,84
	btf_id 3114
3323: sched_cls  name __send_drop_notify  tag a3fba6035879ceb0  gpl
	loaded_at 2024-10-24T12:51:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3115
3366: sched_cls  name cil_from_container  tag 91f24a54071d8b00  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 643,76
	btf_id 3163
3367: sched_cls  name __send_drop_notify  tag 3ad7b3f874f01916  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3164
3368: sched_cls  name tail_ipv4_ct_ingress  tag 4a5eaf487e3e2f07  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,641,82,83,642,84
	btf_id 3161
3369: sched_cls  name tail_handle_arp  tag f092b698b6b908b1  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,641
	btf_id 3166
3370: sched_cls  name tail_ipv4_ct_ingress  tag 9830a7166fb082d8  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,643,82,83,644,84
	btf_id 3165
3371: sched_cls  name tail_handle_arp  tag 49972db82781594d  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,643
	btf_id 3168
3372: sched_cls  name tail_ipv4_to_endpoint  tag 2bb81f59f0c9ffac  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,642,41,82,83,80,154,39,641,40,37,38
	btf_id 3167
3373: sched_cls  name tail_handle_ipv4  tag f216c7f9b94f7d2b  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,643
	btf_id 3169
3374: sched_cls  name tail_handle_ipv4_cont  tag 8d01edc58f250c42  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,644,41,151,82,83,39,76,74,77,643,40,37,38,81
	btf_id 3171
3375: sched_cls  name handle_policy  tag 31b6a7ced726acf3  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,641,82,83,642,41,80,154,39,84,75,40,37,38
	btf_id 3170
3376: sched_cls  name tail_handle_ipv4_cont  tag 729b0a85eb3914ad  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,642,41,154,82,83,39,76,74,77,641,40,37,38,81
	btf_id 3173
3377: sched_cls  name tail_handle_ipv4  tag e3a4bf815db06a25  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,641
	btf_id 3174
3378: sched_cls  name cil_from_container  tag 672d1447de30df6a  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 641,76
	btf_id 3175
3379: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,641
	btf_id 3176
3381: sched_cls  name __send_drop_notify  tag 489ce40286d9c124  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3178
3382: sched_cls  name tail_ipv4_ct_egress  tag ca0e8be364cbcba6  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,641,82,83,642,84
	btf_id 3179
3383: sched_cls  name handle_policy  tag ad13baf829a3392e  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,643,82,83,644,41,80,151,39,84,75,40,37,38
	btf_id 3172
3384: sched_cls  name tail_ipv4_ct_egress  tag 4203a56e5e38eba0  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,643,82,83,644,84
	btf_id 3180
3386: sched_cls  name tail_ipv4_to_endpoint  tag 1ae967787829e19f  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,644,41,82,83,80,151,39,643,40,37,38
	btf_id 3182
3387: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:33+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,643
	btf_id 3183
