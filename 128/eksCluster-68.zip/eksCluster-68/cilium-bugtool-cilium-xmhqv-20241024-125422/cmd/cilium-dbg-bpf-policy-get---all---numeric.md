Endpoint ID: 396
Path: /sys/fs/bpf/tc/globals/cilium_policy_00396

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 586
Path: /sys/fs/bpf/tc/globals/cilium_policy_00586

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5557052   57040     0        
Allow    Ingress     1          ANY          NONE         disabled    5622907   57635     0        
Allow    Egress      0          ANY          NONE         disabled    5737234   58830     0        


Endpoint ID: 629
Path: /sys/fs/bpf/tc/globals/cilium_policy_00629

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    358203   4180      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1060
Path: /sys/fs/bpf/tc/globals/cilium_policy_01060

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1657
Path: /sys/fs/bpf/tc/globals/cilium_policy_01657

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2862     27        0        
Allow    Ingress     1          ANY          NONE         disabled    141806   1627      0        
Allow    Egress      0          ANY          NONE         disabled    20061    223       0        


Endpoint ID: 1795
Path: /sys/fs/bpf/tc/globals/cilium_policy_01795

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6188970   76626     0        
Allow    Ingress     1          ANY          NONE         disabled    62571     756       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1859
Path: /sys/fs/bpf/tc/globals/cilium_policy_01859

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3950
Path: /sys/fs/bpf/tc/globals/cilium_policy_03950

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3034     33        0        
Allow    Ingress     1          ANY          NONE         disabled    141410   1621      0        
Allow    Egress      0          ANY          NONE         disabled    20503    228       0        


