top - 12:54:24 up 32 min,  0 users,  load average: 0.47, 0.50, 0.32
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 39.3 us, 50.0 sy,  0.0 ni, 10.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    282.2 free,   1060.4 used,   2493.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2594.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 300176  78724 S  40.0   7.6   1:07.98 cilium-+
   3243 root      20   0 1240432  15840  10576 S   6.7   0.4   0:00.03 cilium-+
    396 root      20   0 1229744  10240   3836 S   0.0   0.3   0:04.29 cilium-+
   3286 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3305 root      20   0 1539912   8356   6288 S   0.0   0.2   0:00.00 runc:[2+
   3316 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3322 root      20   0 1616008   8392   6320 S   0.0   0.2   0:00.00 runc:[2+
