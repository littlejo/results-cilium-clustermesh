1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:24:58:2a:4e:5d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.135.109/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3481sec preferred_lft 3481sec
    inet6 fe80::424:58ff:fe2a:4e5d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:88:8d:09:2d:03 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.191.76/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::488:8dff:fe09:2d03/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:8f:78:1b:16:c1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::388f:78ff:fe1b:16c1/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:9a:8b:ab:b3:45 brd ff:ff:ff:ff:ff:ff
    inet 10.68.0.27/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d49a:8bff:feab:b345/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 16:36:50:a7:95:92 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1436:50ff:fea7:9592/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:63:51:bb:e7:fe brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::9063:51ff:febb:e7fe/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc002133366046@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:35:9e:d6:a8:13 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::835:9eff:fed6:a813/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc96bc180bf6c0@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:23:60:2f:0a:4c brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::3c23:60ff:fe2f:a4c/64 scope link 
       valid_lft forever preferred_lft forever
18: lxca69d37345a4b@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:c5:29:2f:86:a7 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::50c5:29ff:fe2f:86a7/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcf31f9246134b@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:4d:49:16:de:de brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::704d:49ff:fe16:dede/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc2b154f7c41a0@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:ec:84:78:ba:4a brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::c4ec:84ff:fe78:ba4a/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc33385c5d2182@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:24:60:89:0e:38 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::b024:60ff:fe89:e38/64 scope link 
       valid_lft forever preferred_lft forever
