xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 586
ens6(5) clsact/ingress cil_from_netdev-ens6 id 592
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 582
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 576
cilium_host(7) clsact/egress cil_from_host-cilium_host id 571
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 505
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 506
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 563
lxc002133366046(12) clsact/ingress cil_from_container-lxc002133366046 id 533
lxc96bc180bf6c0(14) clsact/ingress cil_from_container-lxc96bc180bf6c0 id 544
lxca69d37345a4b(18) clsact/ingress cil_from_container-lxca69d37345a4b id 641
lxcf31f9246134b(20) clsact/ingress cil_from_container-lxcf31f9246134b id 3315
lxc2b154f7c41a0(22) clsact/ingress cil_from_container-lxc2b154f7c41a0 id 3366
lxc33385c5d2182(24) clsact/ingress cil_from_container-lxc33385c5d2182 id 3378

flow_dissector:

netfilter:

