Node 0, zone      DMA      1      2     17      2     12      7      4      4      1      3     37 
Node 0, zone   Normal    136     10     19     12     16      9      6      8      3      3      6 
