[
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda66cc69_6cb0_4017_aaea_8194a05bb3b1.slice/cri-containerd-56281e1e9f6fc40143e13018d9217f23dd49090c64dc4b6556fc1a254f38973b.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda66cc69_6cb0_4017_aaea_8194a05bb3b1.slice/cri-containerd-b9c31303603acc2d35e5c473c41c3acd13888715f0a910a095f4be6d6b7726ba.scope"
      }
    ],
    "ips": [
      "10.68.0.225"
    ],
    "name": "echo-same-node-86d9cc975c-c4l95",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd7e88550_bd96_4f10_a8fc_9a94969e3a02.slice/cri-containerd-ee9924540ccbe34458287a9634b0414a1cc5743c0913b5a5589d80205b916572.scope"
      }
    ],
    "ips": [
      "10.68.0.251"
    ],
    "name": "coredns-cc6ccd49c-q2q86",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf38f5b15_7d75_42c5_a438_c91ee81c4b5d.slice/cri-containerd-62bc57c8461e5782947724f2bf121f871fe8cac0d18aa44b69fd52a2fe50a40c.scope"
      }
    ],
    "ips": [
      "10.68.0.108"
    ],
    "name": "client2-57cf4468f-lnxds",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc17b3efb_ab00_4084_ac38_e425f4fc7cf8.slice/cri-containerd-2b54525210791585bd0d36fa9e8745de893ad38362d6ab0203fffac8ca05893a.scope"
      }
    ],
    "ips": [
      "10.68.0.43"
    ],
    "name": "client-974f6c69d-bt9vc",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ab15730_bfae_4e63_be02_727429639825.slice/cri-containerd-3e707be2429c976c97fb3c4c67c9dc9bec1aa0610e729c250ca685126f0dc6b2.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ab15730_bfae_4e63_be02_727429639825.slice/cri-containerd-6de4424c397fce138900785aa3b23ea23861c0059a7c806cff6d1f63da917606.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ab15730_bfae_4e63_be02_727429639825.slice/cri-containerd-b6fb35d1d61436aa1b25c563da40fda2800b0abdd6fc43cfc7b8b79fa75009bc.scope"
      }
    ],
    "ips": [
      "10.68.0.96"
    ],
    "name": "clustermesh-apiserver-58d4b777bf-99qpn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7493,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf51f5235_5e8b_4b4f_b371_069efc307c0e.slice/cri-containerd-ac7411256219117a0dcf13f9114a9802f4bc1c86fb9499fcfcf4993986040065.scope"
      }
    ],
    "ips": [
      "10.68.0.204"
    ],
    "name": "coredns-cc6ccd49c-829ft",
    "namespace": "kube-system"
  }
]

