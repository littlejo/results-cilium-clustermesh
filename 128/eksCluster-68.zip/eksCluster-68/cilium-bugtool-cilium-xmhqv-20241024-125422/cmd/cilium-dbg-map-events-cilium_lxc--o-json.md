{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.433Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.460Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.502Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.179Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.206Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.263Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.274Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.299Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.513Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.520Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.559Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.605Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.633Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.213Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.227Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.272Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.278Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.313Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.542Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.554Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.606Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.626Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.654Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.251Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.258Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.302Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.315Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.343Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.629Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.641Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.720Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.733Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.760Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.336Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.344Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.369Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.407Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.418Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.457Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.465Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.737Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.744Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.805Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.807Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.854Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.272Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.284Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.321Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.340Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.362Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.622Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.631Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.715Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.722Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.807Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.156Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.207Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.216Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.275Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.281Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.315Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.541Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.566Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.605Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.616Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.659Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.060Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.075Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.116Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.123Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.155Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.164Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.411Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.422Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.472Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.499Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.518Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.920Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.951Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.962Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.009Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.019Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.049Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.358Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.368Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.402Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.424Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.442Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.036Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.046Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.095Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.098Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.133Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.361Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.368Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.408Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.436Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.456Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.760Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.817Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.819Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.877Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.880Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.913Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.172Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.174Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.238Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.246Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.281Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.579Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.612Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.621Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.663Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.677Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.702Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.950Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.951Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.969Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.000Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.682Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.685Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.720Z",
  "value": "id=629   sec_id=4578226 flags=0x0000 ifindex=20  mac=2A:C1:BE:81:4B:11 nodemac=72:4D:49:16:DE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.737Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.762Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.010Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:25.018Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.798Z",
  "value": "id=1859  sec_id=4574229 flags=0x0000 ifindex=24  mac=02:BF:BB:73:00:46 nodemac=B2:24:60:89:0E:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.806Z",
  "value": "id=1060  sec_id=4522166 flags=0x0000 ifindex=22  mac=FA:FC:FB:E4:E8:0A nodemac=C6:EC:84:78:BA:4A"
}

