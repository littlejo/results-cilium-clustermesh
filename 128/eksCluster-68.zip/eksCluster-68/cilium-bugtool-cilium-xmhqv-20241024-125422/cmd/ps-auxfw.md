USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3244  0.0  0.1 1228744 4036 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3243  0.0  0.3 1240432 15524 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3273  0.0  0.0   6408  1636 ?        R    12:54   0:00  \_ ps auxfw
root        3274  0.0  0.3 1240432 15524 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root        3227  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3221  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root           1  4.5  7.5 1539060 295160 ?      Ssl  12:29   1:07 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.2  0.2 1229744 10240 ?       Sl   12:29   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
