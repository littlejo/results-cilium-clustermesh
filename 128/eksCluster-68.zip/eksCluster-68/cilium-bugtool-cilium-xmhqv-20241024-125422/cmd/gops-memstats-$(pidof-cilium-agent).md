alloc: 127.00MB (133168752 bytes)
total-alloc: 3.13GB (3358304920 bytes)
sys: 227.32MB (238363988 bytes)
lookups: 0
mallocs: 75625709
frees: 74230947
heap-alloc: 127.00MB (133168752 bytes)
heap-sys: 178.34MB (187006976 bytes)
heap-idle: 31.02MB (32530432 bytes)
heap-in-use: 147.32MB (154476544 bytes)
heap-released: 10.34MB (10846208 bytes)
heap-objects: 1394762
stack-in-use: 37.66MB (39485440 bytes)
stack-sys: 37.66MB (39485440 bytes)
stack-mspan-inuse: 2.40MB (2514080 bytes)
stack-mspan-sys: 2.82MB (2953920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 910.88KB (932745 bytes)
gc-sys: 5.50MB (5764312 bytes)
next-gc: when heap-alloc >= 145.60MB (152671400 bytes)
last-gc: 2024-10-24 12:53:33.883229239 +0000 UTC
gc-pause-total: 17.884375ms
gc-pause: 73946
gc-pause-end: 1729774413883229239
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006033197930578719
enable-gc: true
debug-gc: false
