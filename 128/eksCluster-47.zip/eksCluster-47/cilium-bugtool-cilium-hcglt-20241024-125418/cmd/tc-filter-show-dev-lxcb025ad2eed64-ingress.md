filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcb025ad2eed64 direct-action not_in_hw id 625 tag 3fc38d6a229c4823 jited 
