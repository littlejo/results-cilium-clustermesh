top - 12:54:20 up 32 min,  0 users,  load average: 0.83, 0.58, 0.33
Tasks:   8 total,   2 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 53.3 us, 43.3 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   3836.2 total,    279.2 free,   1061.8 used,   2495.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2593.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 292952  78460 S  86.7   7.5   1:12.97 cilium-+
   3221 root      20   0 1244340  20448  14020 S  20.0   0.5   0:00.03 hubble
   3148 root      20   0 1240432  16520  11292 S  13.3   0.4   0:00.03 cilium-+
    393 root      20   0 1229744   8696   2864 S   0.0   0.2   0:04.43 cilium-+
   3206 root      20   0    6576   2408   2084 R   0.0   0.1   0:00.00 top
   3207 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
   3208 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
   3232 root      20   0    3132    988    868 R   0.0   0.0   0:00.00 bpftool
