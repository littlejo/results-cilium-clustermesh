{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:46.654Z",
  "value": "1 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:46.654Z",
  "value": "2 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:46.654Z",
  "value": "0 2 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.136.66:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:46.654Z",
  "value": "0 0 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:46.654Z",
  "value": "3 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:46.654Z",
  "value": "0 1 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:46.654Z",
  "value": "4 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:46.654Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.136.66:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:50.710Z",
  "value": "5 0 (2) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.136.66:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:50.710Z",
  "value": "0 1 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:51.829Z",
  "value": "0 0 (3) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:51.829Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:51.829Z",
  "value": "0 0 (4) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:51.829Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:54.224Z",
  "value": "0 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:54.224Z",
  "value": "0 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:54.254Z",
  "value": "6 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:54.254Z",
  "value": "0 1 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:54.254Z",
  "value": "7 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:54.254Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:54.294Z",
  "value": "6 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:54.294Z",
  "value": "8 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:54.294Z",
  "value": "0 2 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:54.295Z",
  "value": "7 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:54.295Z",
  "value": "9 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:27:54.295Z",
  "value": "0 2 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.57.107:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:35:52.503Z",
  "value": "0 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.57.107:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:36:06.152Z",
  "value": "0 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.57.107:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:36:10.190Z",
  "value": "10 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.57.107:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:36:10.190Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.57.107:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:41:11.765Z",
  "value": "10 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.57.107:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:41:11.765Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.57.107:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:41:16.761Z",
  "value": "10 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.57.107:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:41:16.761Z",
  "value": "11 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.57.107:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:41:16.761Z",
  "value": "0 2 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.57.107:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:41:16.835Z",
  "value": "11 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.57.107:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:41:16.835Z",
  "value": "10 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.57.107:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:41:16.835Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.57.107:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:41:17.381Z",
  "value": "11 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.57.107:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:41:17.381Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.57.107:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:41:17.381Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.235.45:8080 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:48:20.427Z",
  "value": "0 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.235.45:8080 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:48:37.659Z",
  "value": "0 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.235.45:8080 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:48:38.674Z",
  "value": "12 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.235.45:8080 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:48:38.674Z",
  "value": "0 1 (6) [0x0 0x0]"
}

