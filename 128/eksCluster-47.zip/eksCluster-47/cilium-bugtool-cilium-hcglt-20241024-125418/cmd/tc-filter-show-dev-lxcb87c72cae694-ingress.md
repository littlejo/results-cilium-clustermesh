filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcb87c72cae694 direct-action not_in_hw id 3300 tag 21e419ebd7bdafeb jited 
