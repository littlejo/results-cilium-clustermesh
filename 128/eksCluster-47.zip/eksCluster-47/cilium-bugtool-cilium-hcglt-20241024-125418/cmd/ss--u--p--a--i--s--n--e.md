Total: 551
TCP:   3610 (estab 293, closed 3297, orphaned 1, timewait 2842)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  313       302       11       
INET	  323       308       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:42475      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=41)) ino:30554 sk:998 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.195.85%ens5:68         0.0.0.0:*    uid:192 ino:96585 sk:999 cgroup:unreachable:bd0 <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:31057 sk:99a cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15177 sk:99b cgroup:unreachable:e8e <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:31056 sk:99c cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15178 sk:99d cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::85f:dfff:fe71:eef9]%ens5:546           [::]:*    uid:192 ino:15620 sk:99e cgroup:unreachable:bd0 v6only:1 <->                   
