markdown output at /tmp/cilium-bugtool-20241024-125419.953+0000-UTC-3852934035/cmd/cilium-debuginfo-20241024-125450.978+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125419.953+0000-UTC-3852934035/cmd/cilium-debuginfo-20241024-125450.978+0000-UTC.json
