CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfc81b5e4_3fb8_42d4_9238_2a325aaa428b.slice/cri-containerd-2ac0e6b26fb078f2a2c279bfbe720bb7c1b6384ed4419f3afb4f3ef9401fd4ca.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfc81b5e4_3fb8_42d4_9238_2a325aaa428b.slice/cri-containerd-ec833bc5e8e67407e760ca2aaee6cb6e651a91aa6ed8d80047c97aa68a526b0c.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2304a19d_0c15_4167_8cfb_4bbef7950000.slice/cri-containerd-ae375d29acb041228cbe60097f465fdba473ffc5ab7b7311995b2a16c3055f53.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2304a19d_0c15_4167_8cfb_4bbef7950000.slice/cri-containerd-d78910f3d20a4d1f67e85ff1025ec4e112622411da2482d0b74959c283eac82e.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6b2cd0e_a587_4eb7_9cce_747fc2331fdb.slice/cri-containerd-87d5b974a1c1d222bb0f40afc17711ffa0f80afe0282fd4168eab37d56f1a5af.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6b2cd0e_a587_4eb7_9cce_747fc2331fdb.slice/cri-containerd-1268f29b8406812a18ac162a44da398180037b17b1030706d579b36d47ca9de6.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab70e4fe_3299_4ded_8d12_4b9fd6c9120e.slice/cri-containerd-1971d8a92d1e0bb5a67ffe529364a4e1df79d8e15b4642ec4f55b523cfba24ac.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab70e4fe_3299_4ded_8d12_4b9fd6c9120e.slice/cri-containerd-f8f6c9fb6cae52e084b0e88f0129bddcb6f1e63c1f44b6b1abdcb4714f7bf4ed.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod88f13584_9a56_4ba8_8dec_8789759f86da.slice/cri-containerd-cb463a9c778ca8a5ac82f9a7c9706c053db7f82545d1ca8da5481483e1a6d756.scope
    668      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod88f13584_9a56_4ba8_8dec_8789759f86da.slice/cri-containerd-2c2bdc763f990890c248427cfc660fb8221708b002a1f0be3d140d2c17de67a1.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9eebe08f_fe54_4797_b65f_56bc1f1669e5.slice/cri-containerd-e6aa529d0ff537dfd7440f9450c1edbf3a0087d401d496007b096f743ca1b837.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9eebe08f_fe54_4797_b65f_56bc1f1669e5.slice/cri-containerd-dcd7e4278e75e4f7388b02757f641e12c55ef6df99a5d16512776b949fb35768.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9eebe08f_fe54_4797_b65f_56bc1f1669e5.slice/cri-containerd-f702169f542b02c6f824b1866cc667e2ca4da0992684288b42d15d5841d25890.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9eebe08f_fe54_4797_b65f_56bc1f1669e5.slice/cri-containerd-74270dc095a9b65a14ea1204e35b1d27e2df6942017bbdeeec5a692ab453b73f.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod81c79989_afc1_4312_9fc7_154d7cbc8b77.slice/cri-containerd-6c50b1bdbeff1f1d6a1fa5d075c46b7dd5ed7c0e0c84e46dfc607a3824233a77.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod81c79989_afc1_4312_9fc7_154d7cbc8b77.slice/cri-containerd-8dbb3be5d3ce75296f4659e5bbeecc08bfca67e8104025026edb0aab8bf2d70e.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod81c79989_afc1_4312_9fc7_154d7cbc8b77.slice/cri-containerd-f0e7f6f496c4048c90ed628e5079cdd87eeb2c038f4136138362e20be5c134f5.scope
    694      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc902cefd_6df8_4e51_96b8_14b57b8c42cb.slice/cri-containerd-bebbf1878f7e872e2e9a6d2d63b2c87efb2635167d04cad3b78cb2f8354e1ad0.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc902cefd_6df8_4e51_96b8_14b57b8c42cb.slice/cri-containerd-ee84f511dcf568a92681b3b4b6a1f4995130cac0f9adb1d51d0b13e59755df1d.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6eaa9d8_609a_43cd_ba12_9b397d477e3a.slice/cri-containerd-a08555b71f575bfbf651a8be2c26629f2596c09c6ec9b8d6628fbf6a24ed163b.scope
    698      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6eaa9d8_609a_43cd_ba12_9b397d477e3a.slice/cri-containerd-2e3516b15898bc769f23dd045e420601defb3e94050ce6d73a44a4264fadde50.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf338fe4c_088c_440a_b14b_ec70545333b0.slice/cri-containerd-e52f7d634ce9d929ff4fe9bcf057a9d44038ac2aa29529e3a3a9b4034dcb0e7a.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf338fe4c_088c_440a_b14b_ec70545333b0.slice/cri-containerd-24d3da567e9248669515e40b4da7343e9ba3cba22f7719a4818e23c289e07e4e.scope
    105      cgroup_device   multi                                          
