key: 16 00 00 00  value: 70 02 00 00
key: d2 01 00 00  value: ec 0c 00 00
key: 70 08 00 00  value: 2a 02 00 00
key: 89 08 00 00  value: bd 0c 00 00
key: 75 09 00 00  value: eb 0c 00 00
key: 7e 0b 00 00  value: 1f 02 00 00
key: 69 0e 00 00  value: 17 02 00 00
Found 7 elements
