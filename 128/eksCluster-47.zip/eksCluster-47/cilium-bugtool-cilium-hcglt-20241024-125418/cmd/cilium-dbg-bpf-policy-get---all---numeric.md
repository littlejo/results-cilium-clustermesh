Endpoint ID: 22
Path: /sys/fs/bpf/tc/globals/cilium_policy_00022

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6082459   61608     0        
Allow    Ingress     1          ANY          NONE         disabled    5721070   60550     0        
Allow    Egress      0          ANY          NONE         disabled    7447384   72865     0        


Endpoint ID: 466
Path: /sys/fs/bpf/tc/globals/cilium_policy_00466

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 622
Path: /sys/fs/bpf/tc/globals/cilium_policy_00622

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2160
Path: /sys/fs/bpf/tc/globals/cilium_policy_02160

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6218840   76835     0        
Allow    Ingress     1          ANY          NONE         disabled    63974     772       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2185
Path: /sys/fs/bpf/tc/globals/cilium_policy_02185

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    375149   4376      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2421
Path: /sys/fs/bpf/tc/globals/cilium_policy_02421

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2942
Path: /sys/fs/bpf/tc/globals/cilium_policy_02942

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3680     38        0        
Allow    Ingress     1          ANY          NONE         disabled    154178   1773      0        
Allow    Egress      0          ANY          NONE         disabled    21266    237       0        


Endpoint ID: 3689
Path: /sys/fs/bpf/tc/globals/cilium_policy_03689

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2216     22        0        
Allow    Ingress     1          ANY          NONE         disabled    155025   1781      0        
Allow    Egress      0          ANY          NONE         disabled    20980    235       0        


