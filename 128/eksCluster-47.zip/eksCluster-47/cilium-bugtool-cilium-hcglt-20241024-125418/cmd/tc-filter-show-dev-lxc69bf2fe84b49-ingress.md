filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc69bf2fe84b49 direct-action not_in_hw id 3305 tag 95f5909c45237b6e jited 
