REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     131178    10631969    677    bpf_overlay.c
Interface                   INGRESS     673535    248148172   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      130987    10609575    53     encap.h
Success                     EGRESS      154803    20232223    1308   bpf_lxc.c
Success                     EGRESS      54997     4457373     1694   bpf_host.c
Success                     EGRESS      596       156299      86     l3.h
Success                     INGRESS     179577    20661487    86     l3.h
Success                     INGRESS     256985    27034852    235    trace.h
Unsupported L3 protocol     EGRESS      74        5600        1492   bpf_lxc.c
