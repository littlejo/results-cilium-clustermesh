IP ADDRESS         LOCAL ENDPOINT INFO
10.47.0.31:0       id=2942  sec_id=3199420 flags=0x0000 ifindex=14  mac=E2:BC:F7:D0:70:04 nodemac=26:4F:6A:64:E7:78   
10.47.0.112:0      id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9   
10.47.0.140:0      id=3689  sec_id=3199420 flags=0x0000 ifindex=12  mac=CE:E8:A9:F8:F9:80 nodemac=AA:20:2D:31:31:F9   
172.31.195.85:0    (localhost)                                                                                        
10.47.0.165:0      id=22    sec_id=3149746 flags=0x0000 ifindex=18  mac=46:AF:F8:6A:AA:98 nodemac=82:BC:3B:49:89:56   
172.31.233.126:0   (localhost)                                                                                        
10.47.0.111:0      id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D   
10.47.0.47:0       id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89   
10.47.0.107:0      id=2160  sec_id=4     flags=0x0000 ifindex=10  mac=A6:20:04:E9:C4:30 nodemac=F2:0D:66:33:01:D7     
10.47.0.219:0      (localhost)                                                                                        
