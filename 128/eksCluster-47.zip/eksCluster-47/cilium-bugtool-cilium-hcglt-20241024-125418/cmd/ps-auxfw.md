USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3148  0.0  0.4 1240432 16520 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3184  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3135  0.0  0.0 1228744 3660 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  4.5  7.3 1539060 289628 ?      Ssl  12:27   1:12 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.2  0.2 1229744 8696 ?        Sl   12:27   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
