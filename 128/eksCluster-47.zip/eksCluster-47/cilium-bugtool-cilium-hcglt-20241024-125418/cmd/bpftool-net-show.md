xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 508
ens6(5) clsact/ingress cil_from_netdev-ens6 id 510
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 500
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 492
cilium_host(7) clsact/egress cil_from_host-cilium_host id 489
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 558
lxc2c8074852958(12) clsact/ingress cil_from_container-lxc2c8074852958 id 521
lxc5c85fbe061cb(14) clsact/ingress cil_from_container-lxc5c85fbe061cb id 545
lxcb025ad2eed64(18) clsact/ingress cil_from_container-lxcb025ad2eed64 id 625
lxc69bf2fe84b49(20) clsact/ingress cil_from_container-lxc69bf2fe84b49 id 3305
lxcd24725ebecf5(22) clsact/ingress cil_from_container-lxcd24725ebecf5 id 3263
lxcb87c72cae694(24) clsact/ingress cil_from_container-lxcb87c72cae694 id 3300

flow_dissector:

netfilter:

