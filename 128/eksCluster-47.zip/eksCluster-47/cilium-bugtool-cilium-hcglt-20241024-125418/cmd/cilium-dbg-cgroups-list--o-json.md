[
  {
    "containers": [
      {
        "cgroup-id": 10109,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod81c79989_afc1_4312_9fc7_154d7cbc8b77.slice/cri-containerd-6c50b1bdbeff1f1d6a1fa5d075c46b7dd5ed7c0e0c84e46dfc607a3824233a77.scope"
      },
      {
        "cgroup-id": 10025,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod81c79989_afc1_4312_9fc7_154d7cbc8b77.slice/cri-containerd-8dbb3be5d3ce75296f4659e5bbeecc08bfca67e8104025026edb0aab8bf2d70e.scope"
      }
    ],
    "ips": [
      "10.47.0.111"
    ],
    "name": "echo-same-node-86d9cc975c-f5cp5",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9eebe08f_fe54_4797_b65f_56bc1f1669e5.slice/cri-containerd-f702169f542b02c6f824b1866cc667e2ca4da0992684288b42d15d5841d25890.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9eebe08f_fe54_4797_b65f_56bc1f1669e5.slice/cri-containerd-dcd7e4278e75e4f7388b02757f641e12c55ef6df99a5d16512776b949fb35768.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9eebe08f_fe54_4797_b65f_56bc1f1669e5.slice/cri-containerd-e6aa529d0ff537dfd7440f9450c1edbf3a0087d401d496007b096f743ca1b837.scope"
      }
    ],
    "ips": [
      "10.47.0.165"
    ],
    "name": "clustermesh-apiserver-694cbdcdbc-q4qtp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab70e4fe_3299_4ded_8d12_4b9fd6c9120e.slice/cri-containerd-f8f6c9fb6cae52e084b0e88f0129bddcb6f1e63c1f44b6b1abdcb4714f7bf4ed.scope"
      }
    ],
    "ips": [
      "10.47.0.31"
    ],
    "name": "coredns-cc6ccd49c-jxflf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2304a19d_0c15_4167_8cfb_4bbef7950000.slice/cri-containerd-ae375d29acb041228cbe60097f465fdba473ffc5ab7b7311995b2a16c3055f53.scope"
      }
    ],
    "ips": [
      "10.47.0.140"
    ],
    "name": "coredns-cc6ccd49c-pzc98",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9941,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6eaa9d8_609a_43cd_ba12_9b397d477e3a.slice/cri-containerd-2e3516b15898bc769f23dd045e420601defb3e94050ce6d73a44a4264fadde50.scope"
      }
    ],
    "ips": [
      "10.47.0.112"
    ],
    "name": "client2-57cf4468f-w7j6j",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9857,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod88f13584_9a56_4ba8_8dec_8789759f86da.slice/cri-containerd-2c2bdc763f990890c248427cfc660fb8221708b002a1f0be3d140d2c17de67a1.scope"
      }
    ],
    "ips": [
      "10.47.0.47"
    ],
    "name": "client-974f6c69d-c4clq",
    "namespace": "cilium-test-1"
  }
]

