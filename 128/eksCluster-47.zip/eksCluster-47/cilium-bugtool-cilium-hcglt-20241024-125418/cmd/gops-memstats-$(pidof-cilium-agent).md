alloc: 124.83MB (130897864 bytes)
total-alloc: 3.12GB (3346796712 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 75512412
frees: 74271313
heap-alloc: 124.83MB (130897864 bytes)
heap-sys: 176.48MB (185057280 bytes)
heap-idle: 29.66MB (31105024 bytes)
heap-in-use: 146.82MB (153952256 bytes)
heap-released: 8.06MB (8454144 bytes)
heap-objects: 1241099
stack-in-use: 35.47MB (37191680 bytes)
stack-sys: 35.47MB (37191680 bytes)
stack-mspan-inuse: 2.28MB (2385760 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 994.12KB (1017977 bytes)
gc-sys: 5.54MB (5807272 bytes)
next-gc: when heap-alloc >= 157.12MB (164753512 bytes)
last-gc: 2024-10-24 12:54:20.301809451 +0000 UTC
gc-pause-total: 19.95726ms
gc-pause: 137739
gc-pause-end: 1729774460301809451
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0005966287301933922
enable-gc: true
debug-gc: false
