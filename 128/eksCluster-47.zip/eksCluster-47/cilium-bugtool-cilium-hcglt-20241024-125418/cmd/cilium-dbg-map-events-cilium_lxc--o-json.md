{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.995Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.651Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.672Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.716Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.726Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.753Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.970Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.997Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.045Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.145Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.172Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.772Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.776Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.824Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.835Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.882Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.168Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.178Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.218Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.241Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.280Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.820Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.827Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.867Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.883Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.941Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.941Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.945Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.174Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.193Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.241Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.264Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.291Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.878Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.887Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.917Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.928Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.984Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.990Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.021Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.294Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.303Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.357Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.367Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.399Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.877Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.901Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.942Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.959Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.987Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.222Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.232Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.278Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.279Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.331Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.748Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.856Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.884Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.885Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.948Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.955Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.195Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.206Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.276Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.278Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.345Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.724Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.780Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.797Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.833Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.834Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.838Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.101Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.144Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.190Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.238Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.248Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.670Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.690Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.737Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.757Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.778Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.058Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.106Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.189Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.239Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.295Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.639Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.674Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.700Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.763Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.771Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.803Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.020Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.036Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.102Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.109Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.144Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.468Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.477Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.547Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.553Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.585Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.798Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.800Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.867Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.873Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.929Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.205Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.296Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.307Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.375Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.415Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.429Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.611Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.613Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.632Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.638Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.662Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.396Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.400Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.442Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.452Z",
  "value": "id=2185  sec_id=3161731 flags=0x0000 ifindex=22  mac=9A:A0:BE:F5:CD:64 nodemac=6A:8A:66:26:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.480Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.768Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.781Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.494Z",
  "value": "id=466   sec_id=3182032 flags=0x0000 ifindex=24  mac=42:EE:CD:9A:E2:E3 nodemac=A6:BB:10:DA:4C:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:33.496Z",
  "value": "id=2421  sec_id=3183234 flags=0x0000 ifindex=20  mac=4A:B9:5C:78:B3:D5 nodemac=32:68:C8:77:32:89"
}

