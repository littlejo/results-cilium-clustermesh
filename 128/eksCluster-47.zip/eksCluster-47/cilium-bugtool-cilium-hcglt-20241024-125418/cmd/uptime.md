 12:54:20 up 32 min,  0 users,  load average: 0.83, 0.58, 0.33
