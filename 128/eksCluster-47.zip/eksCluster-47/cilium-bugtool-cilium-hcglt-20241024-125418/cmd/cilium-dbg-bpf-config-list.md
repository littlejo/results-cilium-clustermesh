KEY             VALUE
AgentLiveness   2002413691991
UTimeOffset     3378461892578125
