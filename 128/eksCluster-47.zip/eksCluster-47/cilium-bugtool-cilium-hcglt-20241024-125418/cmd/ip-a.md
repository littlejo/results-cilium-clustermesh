1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:5f:df:71:ee:f9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.195.85/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3440sec preferred_lft 3440sec
    inet6 fe80::85f:dfff:fe71:eef9/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:ab:63:e4:5f:29 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.233.126/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8ab:63ff:fee4:5f29/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:59:c2:13:9a:7b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::cc59:c2ff:fe13:9a7b/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:12:b6:e2:89:2e brd ff:ff:ff:ff:ff:ff
    inet 10.47.0.219/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::412:b6ff:fee2:892e/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 42:8c:d6:59:a4:ea brd ff:ff:ff:ff:ff:ff
    inet6 fe80::408c:d6ff:fe59:a4ea/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:0d:66:33:01:d7 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f00d:66ff:fe33:1d7/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc2c8074852958@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:20:2d:31:31:f9 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a820:2dff:fe31:31f9/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc5c85fbe061cb@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:4f:6a:64:e7:78 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::244f:6aff:fe64:e778/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb025ad2eed64@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:bc:3b:49:89:56 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::80bc:3bff:fe49:8956/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc69bf2fe84b49@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:68:c8:77:32:89 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::3068:c8ff:fe77:3289/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcd24725ebecf5@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:8a:66:26:09:6d brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::688a:66ff:fe26:96d/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcb87c72cae694@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:bb:10:da:4c:b9 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::a4bb:10ff:feda:4cb9/64 scope link 
       valid_lft forever preferred_lft forever
