Node 0, zone      DMA    153    112     15     25     11     13     18      8      2      4     40 
Node 0, zone   Normal    113     46     23     29     17     12      1      4      5      1      7 
