markdown output at /tmp/cilium-bugtool-20241024-125422.208+0000-UTC-1664589211/cmd/cilium-debuginfo-20241024-125453+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125422.208+0000-UTC-1664589211/cmd/cilium-debuginfo-20241024-125453+0000-UTC.json
