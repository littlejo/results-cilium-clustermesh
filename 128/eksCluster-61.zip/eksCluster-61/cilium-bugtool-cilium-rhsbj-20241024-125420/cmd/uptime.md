 12:54:22 up 32 min,  0 users,  load average: 0.45, 0.50, 0.30
