{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.864Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.903Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.913Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.945Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.175Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.188Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.232Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.257Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.283Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.825Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.831Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.857Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.881Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.912Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.926Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:38.948Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.192Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.210Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.256Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.263Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.300Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.860Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.867Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.935Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.967Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.004Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.037Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.047Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.251Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.259Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.317Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.318Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.368Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.869Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.873Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.909Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.922Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.962Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.971Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.997Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.222Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.230Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.291Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.295Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.336Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.756Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.765Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.801Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.819Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.847Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.142Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.155Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.223Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.231Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.262Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.780Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.814Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.816Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.893Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.897Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.942Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.948Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.215Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.221Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.274Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.284Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.318Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.719Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.754Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.766Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.799Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.800Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.814Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.071Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.081Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.167Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.197Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.232Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.655Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.664Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.701Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.723Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.741Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.967Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.979Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.025Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.028Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.036Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.414Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.446Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.453Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.494Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.500Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.529Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.532Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.788Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.794Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.849Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.866Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.902Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.271Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.275Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.363Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.376Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.401Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.577Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.579Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.635Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.659Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.685Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.041Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.042Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.095Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.104Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.130Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.375Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.377Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.393Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.433Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.155Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.156Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.209Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.213Z",
  "value": "id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.242Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.509Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.524Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.228Z",
  "value": "id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.228Z",
  "value": "id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45"
}

