xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 501
ens6(5) clsact/ingress cil_from_netdev-ens6 id 509
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 489
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 487
cilium_host(7) clsact/egress cil_from_host-cilium_host id 483
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 548
lxcf5719f12db3e(12) clsact/ingress cil_from_container-lxcf5719f12db3e id 520
lxcbbe6113f4a36(14) clsact/ingress cil_from_container-lxcbbe6113f4a36 id 552
lxc07fed5efa631(18) clsact/ingress cil_from_container-lxc07fed5efa631 id 617
lxcbc48e4c62075(20) clsact/ingress cil_from_container-lxcbc48e4c62075 id 3284
lxc002d7c7b2615(22) clsact/ingress cil_from_container-lxc002d7c7b2615 id 3340
lxc11c505cf90d2(24) clsact/ingress cil_from_container-lxc11c505cf90d2 id 3327

flow_dissector:

netfilter:

