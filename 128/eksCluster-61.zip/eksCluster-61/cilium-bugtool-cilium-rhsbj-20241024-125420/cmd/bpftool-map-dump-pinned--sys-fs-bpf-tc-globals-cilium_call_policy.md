key: 08 01 00 00  value: 17 02 00 00
key: 53 01 00 00  value: 67 02 00 00
key: a6 02 00 00  value: d2 0c 00 00
key: 78 05 00 00  value: 02 0d 00 00
key: e4 05 00 00  value: 01 0d 00 00
key: 9b 07 00 00  value: 04 02 00 00
key: 0b 0f 00 00  value: 1b 02 00 00
Found 7 elements
