filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcbc48e4c62075 direct-action not_in_hw id 3284 tag 01bb66217c9b0d62 jited 
