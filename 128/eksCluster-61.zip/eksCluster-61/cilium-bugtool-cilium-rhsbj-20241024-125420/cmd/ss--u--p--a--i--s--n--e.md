Total: 580
TCP:   3288 (estab 303, closed 2966, orphaned 0, timewait 2508)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  322       311       11       
INET	  332       317       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                  172.31.248.119%ens5:68         0.0.0.0:*    uid:192 ino:111278 sk:1001 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:32788 sk:1002 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15758 sk:1003 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:33687      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=43)) ino:31879 sk:1004 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:32787 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15759 sk:1006 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::8eb:6bff:fe5b:8841]%ens5:546           [::]:*    uid:192 ino:16018 sk:1007 cgroup:unreachable:bd0 v6only:1 <->                   
