IP ADDRESS         LOCAL ENDPOINT INFO
10.61.0.1:0        id=1947  sec_id=4094181 flags=0x0000 ifindex=12  mac=C2:3F:FF:4E:CA:7F nodemac=FE:E4:B8:2C:2F:30   
10.61.0.153:0      id=678   sec_id=4066500 flags=0x0000 ifindex=20  mac=86:C9:22:1D:1E:04 nodemac=62:0A:C4:68:59:7A   
172.31.196.190:0   (localhost)                                                                                        
10.61.0.109:0      id=1400  sec_id=4084097 flags=0x0000 ifindex=24  mac=EA:A5:21:77:CF:25 nodemac=96:4A:42:6C:15:14   
10.61.0.132:0      id=3851  sec_id=4     flags=0x0000 ifindex=10  mac=5A:60:71:98:8A:B9 nodemac=3E:95:9F:C6:DF:2F     
10.61.0.108:0      id=1508  sec_id=4126622 flags=0x0000 ifindex=22  mac=6A:8D:C2:71:14:6E nodemac=2E:29:B3:E7:83:45   
10.61.0.141:0      id=339   sec_id=4076919 flags=0x0000 ifindex=18  mac=3A:25:1F:C2:97:0D nodemac=1E:8B:AD:21:6F:E8   
10.61.0.24:0       id=264   sec_id=4094181 flags=0x0000 ifindex=14  mac=46:B0:66:C7:E4:99 nodemac=0A:B8:6C:FC:D2:AC   
172.31.248.119:0   (localhost)                                                                                        
10.61.0.12:0       (localhost)                                                                                        
