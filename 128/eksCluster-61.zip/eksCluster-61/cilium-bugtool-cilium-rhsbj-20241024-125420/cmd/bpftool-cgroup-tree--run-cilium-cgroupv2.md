CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod401c2c45_eff8_43bc_8dd7_aa784fd50a70.slice/cri-containerd-960e9a2c61b745cb8a99cd693aebc122ee7305ffdce9c8fe0cde1819eb0e8098.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod401c2c45_eff8_43bc_8dd7_aa784fd50a70.slice/cri-containerd-6f99c31efd21d4f655b00c895b7df377c82aa050cceb102039e93b7ec01b7a8a.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf02a4081_6194_44b6_a375_f870ffd0e96c.slice/cri-containerd-e75608d1fd1c276a582eb416e3f0a2abb8e45b7d30bc3d851a9bb3b9e67fecd1.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf02a4081_6194_44b6_a375_f870ffd0e96c.slice/cri-containerd-cc713d711876e5a6a4f533358fc3700813bf62223ef3df839696f2b3f36b95dc.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f980828_32ad_4c0d_8e30_8d4f18c38286.slice/cri-containerd-84a5b5753573a1714be7a88ee6c9d8be2b4ac520515ef73e6be589cb8dd1681b.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f980828_32ad_4c0d_8e30_8d4f18c38286.slice/cri-containerd-eadd15f51b9f647da5dcf5ad8a0c83a36530c5bdc4840a831fc3498c0a150bd0.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ac99187_ee70_4b77_b18a_31099e470534.slice/cri-containerd-d77595e27ae6b1af0f6d181442b846f0e6965300a131f6097a74ca6fe7e7ade7.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ac99187_ee70_4b77_b18a_31099e470534.slice/cri-containerd-bf041420e4e20a2d635ecbf2973f6a7fcb0344f99f2fb2777056de132851d90c.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfbd0294e_32b3_4b78_9063_da62688fc02b.slice/cri-containerd-4bd7252d94819c5c583548833f66a3261548dfd4d490d2ca04b128b1187c47b3.scope
    700      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfbd0294e_32b3_4b78_9063_da62688fc02b.slice/cri-containerd-1127943b90f8fc833adb0a14362d08ec62b8a46f57a10ee040ac4ccf989bf039.scope
    688      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd72dfb94_da78_4624_8465_74dfaed291d5.slice/cri-containerd-30f8fb9a1753ed5e1cc888eef2602ef543d8e143cc67e700fc7b224e23894a49.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd72dfb94_da78_4624_8465_74dfaed291d5.slice/cri-containerd-2feaf6af76807f5c6a730828c02102a9a53f92369cedde0bbb4db177c76fe34f.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd72dfb94_da78_4624_8465_74dfaed291d5.slice/cri-containerd-7fff54beffcc3ab1ce6c391b378cf06fda3065245a09e82a4d60ffa05c60430a.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd72dfb94_da78_4624_8465_74dfaed291d5.slice/cri-containerd-c287c5af9e646b93c1d9b8ffc6ac6584a0d163f4589dc123d0ec21769f3f5853.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda55607e4_58e0_47a0_aff8_597a1d1bbb59.slice/cri-containerd-15f7f33ddb0f310aeb7e99dfb16bc627fd7c2fb1e6a27afc6f72245676291a7f.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda55607e4_58e0_47a0_aff8_597a1d1bbb59.slice/cri-containerd-76053f7a64a6503eb2b4e263ceac5f2059d4037b9ff0e0496d63003e14743203.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41c8eb6a_ff4f_48ab_b24a_44bc51674691.slice/cri-containerd-152349243a57e64b93508c88232a52b09550eb5b7e228dea5d4c1eb3d174812d.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41c8eb6a_ff4f_48ab_b24a_44bc51674691.slice/cri-containerd-faa2593eb75e1b53585316355593817c52e2c9fc751ef3e0428879a618b44ab9.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3b9f2f3_d9fe_4208_b7bb_f8371430c85d.slice/cri-containerd-f58be558fca5785b2a9c95a69e0b943d732fb587184654fe07a76bc2e1649cd0.scope
    696      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3b9f2f3_d9fe_4208_b7bb_f8371430c85d.slice/cri-containerd-8f0e663a3f6f9cc4421ad8a4fa22638609671dd16029f97bbce55020cf3820d9.scope
    692      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03fd0610_9280_44ae_8875_cc0357cb9ca1.slice/cri-containerd-5dfb66771d6a907446e3a28b137be7465e9f9d7742a73237b918b1f8ecb4c125.scope
    704      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03fd0610_9280_44ae_8875_cc0357cb9ca1.slice/cri-containerd-354e40b099d50cc34a4d0bd3a13183049a50ee7f640ab40c4a17d751c9fe14b2.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03fd0610_9280_44ae_8875_cc0357cb9ca1.slice/cri-containerd-54caade31560ef5b7e3d94cf082bf84046df115443b1d2cb7720e0710f1f1d2b.scope
    708      cgroup_device   multi                                          
