1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:eb:6b:5b:88:41 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.248.119/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3463sec preferred_lft 3463sec
    inet6 fe80::8eb:6bff:fe5b:8841/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:3b:65:e6:62:9b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.196.190/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::83b:65ff:fee6:629b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:4a:40:7e:de:da brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4c4a:40ff:fe7e:deda/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:c4:84:fc:b5:e5 brd ff:ff:ff:ff:ff:ff
    inet 10.61.0.12/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::44c4:84ff:fefc:b5e5/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether de:2c:8b:29:bc:b0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::dc2c:8bff:fe29:bcb0/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:95:9f:c6:df:2f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::3c95:9fff:fec6:df2f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf5719f12db3e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:e4:b8:2c:2f:30 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::fce4:b8ff:fe2c:2f30/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcbbe6113f4a36@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:b8:6c:fc:d2:ac brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::8b8:6cff:fefc:d2ac/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc07fed5efa631@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:8b:ad:21:6f:e8 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::1c8b:adff:fe21:6fe8/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcbc48e4c62075@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:0a:c4:68:59:7a brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::600a:c4ff:fe68:597a/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc002d7c7b2615@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:29:b3:e7:83:45 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::2c29:b3ff:fee7:8345/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc11c505cf90d2@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:4a:42:6c:15:14 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::944a:42ff:fe6c:1514/64 scope link 
       valid_lft forever preferred_lft forever
