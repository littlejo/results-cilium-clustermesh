top - 12:54:22 up 32 min,  0 users,  load average: 0.57, 0.52, 0.31
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s):  6.9 us, 27.6 sy,  0.0 ni, 65.5 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    292.5 free,   1045.8 used,   2497.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2609.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 287740  80124 S   6.7   7.3   1:01.29 cilium-+
    394 root      20   0 1229744   8996   2924 S   0.0   0.2   0:03.87 cilium-+
   3262 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3288 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3289 root      20   0 1240432  16556  11356 S   0.0   0.4   0:00.02 cilium-+
   3306 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3313 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3342 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3360 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
