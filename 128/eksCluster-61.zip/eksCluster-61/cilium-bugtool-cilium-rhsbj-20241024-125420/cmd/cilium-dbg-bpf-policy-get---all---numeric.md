Endpoint ID: 264
Path: /sys/fs/bpf/tc/globals/cilium_policy_00264

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2532     27        0        
Allow    Ingress     1          ANY          NONE         disabled    147069   1690      0        
Allow    Egress      0          ANY          NONE         disabled    20495    229       0        


Endpoint ID: 339
Path: /sys/fs/bpf/tc/globals/cilium_policy_00339

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6105881   61405     0        
Allow    Ingress     1          ANY          NONE         disabled    5653585   59865     0        
Allow    Egress      0          ANY          NONE         disabled    6929031   68384     0        


Endpoint ID: 648
Path: /sys/fs/bpf/tc/globals/cilium_policy_00648

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 678
Path: /sys/fs/bpf/tc/globals/cilium_policy_00678

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379904   4429      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1400
Path: /sys/fs/bpf/tc/globals/cilium_policy_01400

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1508
Path: /sys/fs/bpf/tc/globals/cilium_policy_01508

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1947
Path: /sys/fs/bpf/tc/globals/cilium_policy_01947

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3364     33        0        
Allow    Ingress     1          ANY          NONE         disabled    146764   1690      0        
Allow    Egress      0          ANY          NONE         disabled    19185    213       0        


Endpoint ID: 3851
Path: /sys/fs/bpf/tc/globals/cilium_policy_03851

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6244220   77208     0        
Allow    Ingress     1          ANY          NONE         disabled    67170     814       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


