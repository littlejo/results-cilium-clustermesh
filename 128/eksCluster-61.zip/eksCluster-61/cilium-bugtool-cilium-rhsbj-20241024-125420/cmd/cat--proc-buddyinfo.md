Node 0, zone      DMA      1     78     33     16     14     13      5      5      4      3     37 
Node 0, zone   Normal    333    124      8     13     30     18      6      5      5      1      6 
