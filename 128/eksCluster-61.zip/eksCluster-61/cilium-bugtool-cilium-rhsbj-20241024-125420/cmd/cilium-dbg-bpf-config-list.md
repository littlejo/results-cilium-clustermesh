KEY             VALUE
AgentLiveness   1979664787391
UTimeOffset     3378461939453125
