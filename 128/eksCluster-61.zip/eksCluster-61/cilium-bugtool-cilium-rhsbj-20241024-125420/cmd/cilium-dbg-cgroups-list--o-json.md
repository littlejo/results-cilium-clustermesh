[
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfbd0294e_32b3_4b78_9063_da62688fc02b.slice/cri-containerd-4bd7252d94819c5c583548833f66a3261548dfd4d490d2ca04b128b1187c47b3.scope"
      }
    ],
    "ips": [
      "10.61.0.108"
    ],
    "name": "client-974f6c69d-qxvl8",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda3b9f2f3_d9fe_4208_b7bb_f8371430c85d.slice/cri-containerd-f58be558fca5785b2a9c95a69e0b943d732fb587184654fe07a76bc2e1649cd0.scope"
      }
    ],
    "ips": [
      "10.61.0.109"
    ],
    "name": "client2-57cf4468f-ggwqc",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03fd0610_9280_44ae_8875_cc0357cb9ca1.slice/cri-containerd-54caade31560ef5b7e3d94cf082bf84046df115443b1d2cb7720e0710f1f1d2b.scope"
      },
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03fd0610_9280_44ae_8875_cc0357cb9ca1.slice/cri-containerd-5dfb66771d6a907446e3a28b137be7465e9f9d7742a73237b918b1f8ecb4c125.scope"
      }
    ],
    "ips": [
      "10.61.0.153"
    ],
    "name": "echo-same-node-86d9cc975c-chgcw",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd72dfb94_da78_4624_8465_74dfaed291d5.slice/cri-containerd-30f8fb9a1753ed5e1cc888eef2602ef543d8e143cc67e700fc7b224e23894a49.scope"
      },
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd72dfb94_da78_4624_8465_74dfaed291d5.slice/cri-containerd-2feaf6af76807f5c6a730828c02102a9a53f92369cedde0bbb4db177c76fe34f.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd72dfb94_da78_4624_8465_74dfaed291d5.slice/cri-containerd-c287c5af9e646b93c1d9b8ffc6ac6584a0d163f4589dc123d0ec21769f3f5853.scope"
      }
    ],
    "ips": [
      "10.61.0.141"
    ],
    "name": "clustermesh-apiserver-5d49d56474-ksfh8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod401c2c45_eff8_43bc_8dd7_aa784fd50a70.slice/cri-containerd-960e9a2c61b745cb8a99cd693aebc122ee7305ffdce9c8fe0cde1819eb0e8098.scope"
      }
    ],
    "ips": [
      "10.61.0.24"
    ],
    "name": "coredns-cc6ccd49c-ct7rj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ac99187_ee70_4b77_b18a_31099e470534.slice/cri-containerd-d77595e27ae6b1af0f6d181442b846f0e6965300a131f6097a74ca6fe7e7ade7.scope"
      }
    ],
    "ips": [
      "10.61.0.1"
    ],
    "name": "coredns-cc6ccd49c-9dfl8",
    "namespace": "kube-system"
  }
]

