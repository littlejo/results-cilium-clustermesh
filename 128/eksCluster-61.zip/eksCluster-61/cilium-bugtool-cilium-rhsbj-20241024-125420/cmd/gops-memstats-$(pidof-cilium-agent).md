alloc: 136.74MB (143382776 bytes)
total-alloc: 3.15GB (3382168720 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 76192510
frees: 74766938
heap-alloc: 136.74MB (143382776 bytes)
heap-sys: 176.39MB (184958976 bytes)
heap-idle: 20.71MB (21716992 bytes)
heap-in-use: 155.68MB (163241984 bytes)
heap-released: 9.16MB (9609216 bytes)
heap-objects: 1425572
stack-in-use: 35.56MB (37289984 bytes)
stack-sys: 35.56MB (37289984 bytes)
stack-mspan-inuse: 2.42MB (2542080 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1017.58KB (1042001 bytes)
gc-sys: 5.52MB (5790816 bytes)
next-gc: when heap-alloc >= 145.76MB (152843384 bytes)
last-gc: 2024-10-24 12:54:09.779267904 +0000 UTC
gc-pause-total: 16.457097ms
gc-pause: 93679
gc-pause-end: 1729774449779267904
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0005476654939596253
enable-gc: true
debug-gc: false
