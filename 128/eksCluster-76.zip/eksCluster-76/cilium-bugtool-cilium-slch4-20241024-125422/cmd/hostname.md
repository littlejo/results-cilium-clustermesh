ip-172-31-131-33.eu-west-3.compute.internal
