35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:21+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:22:21+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:22:22+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:22:22+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:22+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:22:22+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:22:22+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:22:22+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:22:26+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:29:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:29:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name tail_handle_ipv4  tag 29b3e4755447796d  gpl
	loaded_at 2024-10-24T12:30:08+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
485: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:30:08+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
486: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:30:08+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
487: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:30:08+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
510: sched_cls  name tail_ipv4_ct_egress  tag d762d07dd99dacd7  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 153
511: sched_cls  name tail_handle_ipv4_cont  tag 7d8ce50a69c17a62  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,107,41,106,82,83,39,76,74,77,108,40,37,38,81
	btf_id 154
512: sched_cls  name tail_handle_arp  tag 3296d9457211cb9a  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 155
513: sched_cls  name handle_policy  tag d95b146112d1c247  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,108,82,83,107,41,80,106,39,84,75,40,37,38
	btf_id 156
514: sched_cls  name tail_ipv4_ct_ingress  tag ac45d9dcf4725d18  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 157
515: sched_cls  name tail_ipv4_to_endpoint  tag fd9fd1b4daf0eac1  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,107,41,82,83,80,106,39,108,40,37,38
	btf_id 158
516: sched_cls  name tail_handle_ipv4  tag 23ec1c1088dd911b  gpl
	loaded_at 2024-10-24T12:30:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 159
517: sched_cls  name cil_from_container  tag 736cc854559d314d  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,76
	btf_id 160
518: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 161
520: sched_cls  name __send_drop_notify  tag c890e385b7147b72  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 163
521: sched_cls  name __send_drop_notify  tag 65c40e121b78b5d7  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 165
522: sched_cls  name tail_handle_ipv4  tag 4b381035b69260aa  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 166
523: sched_cls  name handle_policy  tag 250a3925c9dcc3b0  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,109,82,83,110,41,80,100,39,84,75,40,37,38
	btf_id 167
524: sched_cls  name tail_ipv4_ct_egress  tag d762d07dd99dacd7  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 168
525: sched_cls  name tail_ipv4_ct_ingress  tag 41176d4b126e7eb3  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 169
526: sched_cls  name tail_handle_arp  tag 2f9a4106172856c9  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 170
527: sched_cls  name tail_ipv4_to_endpoint  tag 62b3ceb6028e81af  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,110,41,82,83,80,100,39,109,40,37,38
	btf_id 171
528: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
531: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
532: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 172
533: sched_cls  name tail_handle_ipv4_cont  tag 6ee5506e44f74f4d  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,110,41,100,82,83,39,76,74,77,109,40,37,38,81
	btf_id 173
534: sched_cls  name cil_from_container  tag 526888a5f6d603fb  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 109,76
	btf_id 174
537: sched_cls  name handle_policy  tag 4bd9ed9a89892633  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,113,82,83,112,41,80,101,39,84,75,40,37,38
	btf_id 178
538: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
541: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
542: sched_cls  name cil_from_container  tag be2648f0ea14d3f9  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 113,76
	btf_id 179
543: sched_cls  name tail_ipv4_ct_ingress  tag 4121da28ca757063  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 180
544: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 181
545: sched_cls  name tail_handle_arp  tag 11b36e56b7fa79ff  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 182
546: sched_cls  name __send_drop_notify  tag 90934f58ec087d76  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 183
547: sched_cls  name tail_ipv4_to_endpoint  tag 2f25a111295c5f19  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,112,41,82,83,80,101,39,113,40,37,38
	btf_id 184
548: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 185
549: sched_cls  name tail_handle_ipv4_cont  tag 79df19bf34957fc0  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,112,41,101,82,83,39,76,74,77,113,40,37,38,81
	btf_id 186
550: sched_cls  name tail_handle_ipv4  tag 54fe99d281b41c09  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 187
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:30:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
559: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 189
561: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 191
563: sched_cls  name __send_drop_notify  tag 730d7e9bc852a4e2  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 193
564: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 194
565: sched_cls  name tail_handle_ipv4_from_host  tag e9c0ffcf98f64ce4  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 195
567: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 198
569: sched_cls  name __send_drop_notify  tag 730d7e9bc852a4e2  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 200
570: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 201
571: sched_cls  name tail_handle_ipv4_from_host  tag e9c0ffcf98f64ce4  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 202
573: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 205
574: sched_cls  name __send_drop_notify  tag 730d7e9bc852a4e2  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
575: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 207
576: sched_cls  name tail_handle_ipv4_from_host  tag e9c0ffcf98f64ce4  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 208
580: sched_cls  name tail_handle_ipv4_from_host  tag e9c0ffcf98f64ce4  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 213
584: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 217
585: sched_cls  name __send_drop_notify  tag 730d7e9bc852a4e2  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 218
586: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:30:12+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 219
626: sched_cls  name tail_ipv4_ct_ingress  tag 1aa2449c5d477a46  gpl
	loaded_at 2024-10-24T12:42:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 233
627: sched_cls  name tail_handle_ipv4_cont  tag 40c2c740a519e22a  gpl
	loaded_at 2024-10-24T12:42:30+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,136,41,135,82,83,39,76,74,77,137,40,37,38,81
	btf_id 234
628: sched_cls  name tail_handle_arp  tag c6bfbd5b7caaa140  gpl
	loaded_at 2024-10-24T12:42:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,137
	btf_id 235
630: sched_cls  name handle_policy  tag 51a7dedc3e1f5c6e  gpl
	loaded_at 2024-10-24T12:42:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,137,82,83,136,41,80,135,39,84,75,40,37,38
	btf_id 237
631: sched_cls  name tail_handle_ipv4  tag ce9187ddcd4e12f5  gpl
	loaded_at 2024-10-24T12:42:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,137
	btf_id 238
632: sched_cls  name tail_ipv4_ct_egress  tag 808c3ad01d6251de  gpl
	loaded_at 2024-10-24T12:42:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 239
633: sched_cls  name tail_ipv4_to_endpoint  tag 92c4e4869a5dbea1  gpl
	loaded_at 2024-10-24T12:42:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,136,41,82,83,80,135,39,137,40,37,38
	btf_id 240
634: sched_cls  name __send_drop_notify  tag 0937eea12c580c27  gpl
	loaded_at 2024-10-24T12:42:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 241
635: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,137
	btf_id 242
636: sched_cls  name cil_from_container  tag 6516a7976ea4dfbd  gpl
	loaded_at 2024-10-24T12:42:30+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 137,76
	btf_id 243
641: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
644: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
676: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
679: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
702: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
705: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
706: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
709: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
710: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
713: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
714: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
717: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
718: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
721: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
722: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
725: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3289: sched_cls  name tail_ipv4_ct_egress  tag 6f9136bb38ebbcb8  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3077
3290: sched_cls  name tail_handle_arp  tag 94893fef840f0ab2  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,627
	btf_id 3078
3291: sched_cls  name tail_handle_ipv4_cont  tag 275a12855f607fdb  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,628,41,149,82,83,39,76,74,77,627,40,37,38,81
	btf_id 3079
3293: sched_cls  name tail_handle_ipv4  tag 452192623e7f5a55  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,627
	btf_id 3080
3294: sched_cls  name cil_from_container  tag 9befd54355eacea0  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 627,76
	btf_id 3084
3296: sched_cls  name tail_ipv4_to_endpoint  tag f89404c080d008d4  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,628,41,82,83,80,149,39,627,40,37,38
	btf_id 3085
3298: sched_cls  name __send_drop_notify  tag 5e6c1f23fb346af8  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3088
3299: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,627
	btf_id 3089
3302: sched_cls  name tail_ipv4_ct_ingress  tag 4f54f06f19047cee  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3090
3311: sched_cls  name handle_policy  tag f7d946ced31c1744  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,627,82,83,628,41,80,149,39,84,75,40,37,38
	btf_id 3093
3344: sched_cls  name tail_ipv4_ct_egress  tag c19b252a6ee37d47  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,640,84
	btf_id 3139
3345: sched_cls  name tail_ipv4_ct_ingress  tag 74cfdf615cfa22ad  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,639,84
	btf_id 3138
3346: sched_cls  name cil_from_container  tag 26d2b1c048a42e6d  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 638,76
	btf_id 3141
3347: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,637
	btf_id 3140
3348: sched_cls  name tail_handle_ipv4_cont  tag d29b38c71b9603be  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,639,41,145,82,83,39,76,74,77,637,40,37,38,81
	btf_id 3143
3349: sched_cls  name tail_ipv4_to_endpoint  tag ad8ec78fc5283a37  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,640,41,82,83,80,152,39,638,40,37,38
	btf_id 3142
3350: sched_cls  name tail_ipv4_ct_egress  tag 616c8ec469e52b61  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,639,84
	btf_id 3144
3351: sched_cls  name tail_handle_ipv4  tag a037ebd9b8942269  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,637
	btf_id 3145
3353: sched_cls  name handle_policy  tag e3bba7a60ddc7f7f  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,638,82,83,640,41,80,152,39,84,75,40,37,38
	btf_id 3146
3354: sched_cls  name tail_handle_arp  tag cfb6f41d77270115  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,638
	btf_id 3149
3355: sched_cls  name tail_handle_ipv4  tag 4772b952a9fa2075  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,638
	btf_id 3150
3356: sched_cls  name tail_handle_ipv4_cont  tag 68a3df81a0a97fd1  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,640,41,152,82,83,39,76,74,77,638,40,37,38,81
	btf_id 3151
3358: sched_cls  name tail_ipv4_ct_ingress  tag aac1fb135ab3d560  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,638,82,83,640,84
	btf_id 3153
3359: sched_cls  name __send_drop_notify  tag d95ed931e38d7301  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3154
3360: sched_cls  name handle_policy  tag 7b00a07cd9859087  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,637,82,83,639,41,80,145,39,84,75,40,37,38
	btf_id 3148
3361: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,638
	btf_id 3155
3362: sched_cls  name __send_drop_notify  tag ee2105519ac84161  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3156
3363: sched_cls  name cil_from_container  tag abc46d86791d1e5b  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 637,76
	btf_id 3157
3364: sched_cls  name tail_handle_arp  tag dc00622d4f9f3bf1  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,637
	btf_id 3158
3365: sched_cls  name tail_ipv4_to_endpoint  tag a08125c874a1228f  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,639,41,82,83,80,145,39,637,40,37,38
	btf_id 3159
