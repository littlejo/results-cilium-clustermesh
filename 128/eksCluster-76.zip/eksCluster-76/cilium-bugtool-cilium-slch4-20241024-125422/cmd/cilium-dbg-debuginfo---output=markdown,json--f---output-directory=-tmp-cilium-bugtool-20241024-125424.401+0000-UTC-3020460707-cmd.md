markdown output at /tmp/cilium-bugtool-20241024-125424.401+0000-UTC-3020460707/cmd/cilium-debuginfo-20241024-125455.127+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125424.401+0000-UTC-3020460707/cmd/cilium-debuginfo-20241024-125455.127+0000-UTC.json
