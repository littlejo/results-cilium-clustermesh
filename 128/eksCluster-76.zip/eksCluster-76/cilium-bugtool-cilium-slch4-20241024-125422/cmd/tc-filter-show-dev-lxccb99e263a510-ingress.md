filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxccb99e263a510 direct-action not_in_hw id 636 tag 6516a7976ea4dfbd jited 
