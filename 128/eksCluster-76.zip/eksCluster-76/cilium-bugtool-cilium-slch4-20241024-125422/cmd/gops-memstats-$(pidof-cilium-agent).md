alloc: 127.24MB (133419056 bytes)
total-alloc: 3.09GB (3316458008 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 75250346
frees: 74000956
heap-alloc: 127.24MB (133419056 bytes)
heap-sys: 172.80MB (181190656 bytes)
heap-idle: 22.80MB (23904256 bytes)
heap-in-use: 150.00MB (157286400 bytes)
heap-released: 3.21MB (3366912 bytes)
heap-objects: 1249390
stack-in-use: 35.16MB (36864000 bytes)
stack-sys: 35.16MB (36864000 bytes)
stack-mspan-inuse: 2.32MB (2428000 bytes)
stack-mspan-sys: 2.74MB (2872320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1057161 bytes)
gc-sys: 5.52MB (5790768 bytes)
next-gc: when heap-alloc >= 156.26MB (163849832 bytes)
last-gc: 2024-10-24 12:54:24.452353233 +0000 UTC
gc-pause-total: 20.286524ms
gc-pause: 153249
gc-pause-end: 1729774464452353233
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0006467292476040718
enable-gc: true
debug-gc: false
