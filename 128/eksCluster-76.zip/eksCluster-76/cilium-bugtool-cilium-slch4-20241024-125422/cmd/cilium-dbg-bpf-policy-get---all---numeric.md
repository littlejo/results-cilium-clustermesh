Endpoint ID: 397
Path: /sys/fs/bpf/tc/globals/cilium_policy_00397

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6246558   77231     0        
Allow    Ingress     1          ANY          NONE         disabled    63696     771       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 596
Path: /sys/fs/bpf/tc/globals/cilium_policy_00596

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 661
Path: /sys/fs/bpf/tc/globals/cilium_policy_00661

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1890     21        0        
Allow    Ingress     1          ANY          NONE         disabled    141016   1623      0        
Allow    Egress      0          ANY          NONE         disabled    20688    230       0        


Endpoint ID: 676
Path: /sys/fs/bpf/tc/globals/cilium_policy_00676

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 776
Path: /sys/fs/bpf/tc/globals/cilium_policy_00776

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 847
Path: /sys/fs/bpf/tc/globals/cilium_policy_00847

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4006     39        0        
Allow    Ingress     1          ANY          NONE         disabled    142600   1647      0        
Allow    Egress      0          ANY          NONE         disabled    19251    213       0        


Endpoint ID: 1729
Path: /sys/fs/bpf/tc/globals/cilium_policy_01729

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6157810   61332     0        
Allow    Ingress     1          ANY          NONE         disabled    5240052   55229     0        
Allow    Egress      0          ANY          NONE         disabled    6240332   62279     0        


Endpoint ID: 1843
Path: /sys/fs/bpf/tc/globals/cilium_policy_01843

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379411   4425      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


