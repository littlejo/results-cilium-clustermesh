KEY             VALUE
AgentLiveness   1957174980581
UTimeOffset     3378461988281250
