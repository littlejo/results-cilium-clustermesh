REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     132973    10773132    677    bpf_overlay.c
Interface                   INGRESS     669352    246385919   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      133030    10776426    53     encap.h
Success                     EGRESS      146808    19641761    1308   bpf_lxc.c
Success                     EGRESS      56427     4573264     1694   bpf_host.c
Success                     EGRESS      596       156299      86     l3.h
Success                     INGRESS     171766    19563275    86     l3.h
Success                     INGRESS     249539    25961912    235    trace.h
Unsupported L3 protocol     EGRESS      72        5420        1492   bpf_lxc.c
