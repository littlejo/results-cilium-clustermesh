Page block order: 9
Pages per block:  512

Free pages count per migrate type at order       0      1      2      3      4      5      6      7      8      9     10 
Node    0, zone      DMA, type    Unmovable      1     61     33     53     20      7      3      2      2      0      0 
Node    0, zone      DMA, type      Movable      1      1      0      1      0      1     16     18      6      2     19 
Node    0, zone      DMA, type  Reclaimable      0      0      1      0      0      1      0      1      1      1      0 
Node    0, zone      DMA, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type          CMA      0      0      1      0      0      0      1      0      0      1     15 
Node    0, zone      DMA, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type    Unmovable     11     61      5     22     29      7      3      1      1      2      0 
Node    0, zone   Normal, type      Movable      0      1      1      1      1      1      0      1      1      1      6 
Node    0, zone   Normal, type  Reclaimable      2      3      0      0      2      0      1      1      1      1      0 
Node    0, zone   Normal, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type          CMA      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 

Number of blocks type     Unmovable      Movable  Reclaimable   HighAtomic          CMA      Isolate 
Node 0, zone      DMA           40          424           16            0           32            0 
Node 0, zone   Normal          106         1362           32            0            0            0 
