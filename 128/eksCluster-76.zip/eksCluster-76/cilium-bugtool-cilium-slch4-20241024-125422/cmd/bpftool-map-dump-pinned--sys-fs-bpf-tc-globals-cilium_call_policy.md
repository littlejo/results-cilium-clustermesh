key: 8d 01 00 00  value: 19 02 00 00
key: 54 02 00 00  value: 19 0d 00 00
key: 95 02 00 00  value: 01 02 00 00
key: 08 03 00 00  value: 20 0d 00 00
key: 4f 03 00 00  value: 0b 02 00 00
key: c1 06 00 00  value: 76 02 00 00
key: 33 07 00 00  value: ef 0c 00 00
Found 7 elements
