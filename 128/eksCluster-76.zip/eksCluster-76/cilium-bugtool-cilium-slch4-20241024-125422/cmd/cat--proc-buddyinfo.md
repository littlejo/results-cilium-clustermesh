Node 0, zone      DMA      2     62     36     54     21      8     32     21      9      4     34 
Node 0, zone   Normal     13     65      6     23     32      8      4      3      3      4      6 
