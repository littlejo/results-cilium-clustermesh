USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3258  0.0  0.2 1616264 8784 ?        Ssl  12:54   0:00 /usr/sbin/runc init
root        3241  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3234  0.0  0.1 1229000 4052 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3225  1.0  0.4 1240432 16740 ?       Dsl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3264  0.0  0.4 1240432 16740 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root        3265  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3196  0.0  0.1 1228744 5000 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root           1  4.4  7.2 1539060 286756 ?      Ssl  12:29   1:05 cilium-agent --config-dir=/tmp/cilium/config-map
root         399  0.3  0.2 1229744 9892 ?        Sl   12:30   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
