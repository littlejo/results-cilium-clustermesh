[
  {
    "containers": [
      {
        "cgroup-id": 7671,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd377cde3_6ef6_43c5_81a7_ded55114d9ec.slice/cri-containerd-31a3c4c9630e9eac1cc66170bd85e40cce798599088af1818d2207bafe924e90.scope"
      }
    ],
    "ips": [
      "10.76.0.61"
    ],
    "name": "coredns-cc6ccd49c-4q2t8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7587,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda59f9f06_1a78_48da_8cda_d70c32e64097.slice/cri-containerd-fe00d18a7e2a7d4ab2044985b55b2cd8796a0bd8df19e91478a78c8561feed7c.scope"
      }
    ],
    "ips": [
      "10.76.0.39"
    ],
    "name": "coredns-cc6ccd49c-qmfz5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10119,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52af1e8d_bb74_49da_b6be_91f7f815713f.slice/cri-containerd-9a1abfad5958dcdc3e5dd8b2a4ae254579b029c2603aa571b8f44d675eaf8c2b.scope"
      },
      {
        "cgroup-id": 10035,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52af1e8d_bb74_49da_b6be_91f7f815713f.slice/cri-containerd-7f0de12b942271ae7b59a9a087f9ab5171d83a53d40370fe4169aac7c290a71d.scope"
      }
    ],
    "ips": [
      "10.76.0.195"
    ],
    "name": "echo-same-node-86d9cc975c-tbb7w",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9867,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc90b4ad5_8402_4e79_a475_4f6dc3dd25ac.slice/cri-containerd-362be1ee7aeae186135f5be5dde8d7e3c15eb46d21338cb1e9a318286db51b5f.scope"
      }
    ],
    "ips": [
      "10.76.0.123"
    ],
    "name": "client-974f6c69d-9dshz",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9951,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2861af93_9170_4ba2_8ee0_394e47bf8c7d.slice/cri-containerd-5807d12e46a3b0dd2241a1e11f62bbd4c119ab982f2e35d1eed533798b3e0150.scope"
      }
    ],
    "ips": [
      "10.76.0.7"
    ],
    "name": "client2-57cf4468f-xkjhv",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9195,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b97bd75_6231_44c6_aed7_7044e1d97ccd.slice/cri-containerd-cc0725990803a08b59124edad8fdb7c5ed980c84ddcb9dc1313ada1b30cdacbf.scope"
      },
      {
        "cgroup-id": 9111,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b97bd75_6231_44c6_aed7_7044e1d97ccd.slice/cri-containerd-942ffd36f9117c008e49847e653f75c2a5c47473652aedb7e3785347572cbe15.scope"
      },
      {
        "cgroup-id": 9279,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b97bd75_6231_44c6_aed7_7044e1d97ccd.slice/cri-containerd-26d91093bb7e05bf9cbd5f1ad368427fb25509dbd7ba7a79d56178ed78bd56b9.scope"
      }
    ],
    "ips": [
      "10.76.0.206"
    ],
    "name": "clustermesh-apiserver-c6dd44d54-7x7jd",
    "namespace": "kube-system"
  }
]

