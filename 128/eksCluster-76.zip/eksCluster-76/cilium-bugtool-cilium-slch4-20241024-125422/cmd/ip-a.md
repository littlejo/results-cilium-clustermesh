1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c2:f8:a9:0d:41 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.131.33/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3483sec preferred_lft 3483sec
    inet6 fe80::4c2:f8ff:fea9:d41/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ff:56:b0:d7:87 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.133.15/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4ff:56ff:feb0:d787/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:84:ad:4f:38:5f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a484:adff:fe4f:385f/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:68:20:ae:49:ff brd ff:ff:ff:ff:ff:ff
    inet 10.76.0.110/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::f468:20ff:feae:49ff/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether c6:68:79:0d:25:21 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c468:79ff:fe0d:2521/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:d2:90:86:4c:2e brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b0d2:90ff:fe86:4c2e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca9a96c01f416@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:92:b4:96:f7:63 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b492:b4ff:fe96:f763/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc6a66d9106f7f@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:6b:43:6a:62:07 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::86b:43ff:fe6a:6207/64 scope link 
       valid_lft forever preferred_lft forever
18: lxccb99e263a510@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:0d:91:86:a5:36 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::80d:91ff:fe86:a536/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcee02740955ff@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:cf:88:3c:1b:a0 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::a0cf:88ff:fe3c:1ba0/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc934a6ff8a1bc@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:39:0f:2f:1f:48 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::5839:fff:fe2f:1f48/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc000760397e07@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:16:ca:66:51:4c brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::6816:caff:fe66:514c/64 scope link 
       valid_lft forever preferred_lft forever
