xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 573
ens6(5) clsact/ingress cil_from_netdev-ens6 id 584
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 567
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 561
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 542
lxca9a96c01f416(12) clsact/ingress cil_from_container-lxca9a96c01f416 id 534
lxc6a66d9106f7f(14) clsact/ingress cil_from_container-lxc6a66d9106f7f id 517
lxccb99e263a510(18) clsact/ingress cil_from_container-lxccb99e263a510 id 636
lxcee02740955ff(20) clsact/ingress cil_from_container-lxcee02740955ff id 3363
lxc934a6ff8a1bc(22) clsact/ingress cil_from_container-lxc934a6ff8a1bc id 3294
lxc000760397e07(24) clsact/ingress cil_from_container-lxc000760397e07 id 3346

flow_dissector:

netfilter:

