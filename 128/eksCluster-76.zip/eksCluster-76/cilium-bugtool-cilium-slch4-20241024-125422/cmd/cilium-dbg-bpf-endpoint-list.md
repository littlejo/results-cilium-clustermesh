IP ADDRESS        LOCAL ENDPOINT INFO
172.31.133.15:0   (localhost)                                                                                        
10.76.0.206:0     id=1729  sec_id=5066838 flags=0x0000 ifindex=18  mac=92:9F:9E:E3:DD:C5 nodemac=0A:0D:91:86:A5:36   
10.76.0.39:0      id=847   sec_id=5077494 flags=0x0000 ifindex=12  mac=B6:31:45:92:26:F1 nodemac=B6:92:B4:96:F7:63   
10.76.0.110:0     (localhost)                                                                                        
10.76.0.156:0     id=397   sec_id=4     flags=0x0000 ifindex=10  mac=8A:35:C1:99:23:BA nodemac=B2:D2:90:86:4C:2E     
172.31.131.33:0   (localhost)                                                                                        
10.76.0.123:0     id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0   
10.76.0.7:0       id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C   
10.76.0.195:0     id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48   
10.76.0.61:0      id=661   sec_id=5077494 flags=0x0000 ifindex=14  mac=82:32:72:BE:C2:B2 nodemac=0A:6B:43:6A:62:07   
