CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda59f9f06_1a78_48da_8cda_d70c32e64097.slice/cri-containerd-fe00d18a7e2a7d4ab2044985b55b2cd8796a0bd8df19e91478a78c8561feed7c.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda59f9f06_1a78_48da_8cda_d70c32e64097.slice/cri-containerd-c15d58a60420ee48b6e4b68cbee9b015d6f3f81bcb8cdab09b88cb334b6c9693.scope
    531      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode5eaea04_ee82_4a81_8b3e_f446b30c14a0.slice/cri-containerd-664c18f608d12ed5d699332b7338a8541904044789c2b9a88c53b31ee376dc70.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode5eaea04_ee82_4a81_8b3e_f446b30c14a0.slice/cri-containerd-9d95140a8dfde337851bcb58fd11a18fce8d8d39c932b5a29f01b98c926627b5.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9586cefc_9bfa_4bcc_aedf_cedcf5fdaa41.slice/cri-containerd-6903d298479766bc60302eb12fb538b469e6cea83000f8626c2b15552fef2209.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9586cefc_9bfa_4bcc_aedf_cedcf5fdaa41.slice/cri-containerd-b5877a4cc1fa5fde451d86c28e38cf535761ca6fca1ea0fc9ef2ef6d3f345082.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd377cde3_6ef6_43c5_81a7_ded55114d9ec.slice/cri-containerd-eccec73c1e327f54d2a0c4d414f073a2fb5d9045263750415ec5b08db764120a.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd377cde3_6ef6_43c5_81a7_ded55114d9ec.slice/cri-containerd-31a3c4c9630e9eac1cc66170bd85e40cce798599088af1818d2207bafe924e90.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52af1e8d_bb74_49da_b6be_91f7f815713f.slice/cri-containerd-7f0de12b942271ae7b59a9a087f9ab5171d83a53d40370fe4169aac7c290a71d.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52af1e8d_bb74_49da_b6be_91f7f815713f.slice/cri-containerd-4242db0df91fc3fe02e34ff3209b3579d48a20ef1d0421b3c52e9b2d685beeb2.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52af1e8d_bb74_49da_b6be_91f7f815713f.slice/cri-containerd-9a1abfad5958dcdc3e5dd8b2a4ae254579b029c2603aa571b8f44d675eaf8c2b.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62baa458_8df7_4a8f_986a_d95435d04c67.slice/cri-containerd-e86500ba853683742d5db4b2c2b7f58ea0ad2c5ab03af3761981b76cc566be74.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62baa458_8df7_4a8f_986a_d95435d04c67.slice/cri-containerd-c9ed310c775886cedcc099b0805909eebd1deb4e3223230d73c3b52d5cacec6a.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode39c3fb9_a919_4b47_aa78_bc3d45e7ed21.slice/cri-containerd-37f6d1eac7ea714ae49e41c7444493843ab4e3478b916797ee2908ac3e349d11.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode39c3fb9_a919_4b47_aa78_bc3d45e7ed21.slice/cri-containerd-e34e52e5c3dd99ac6f917e0dae45627f9eb15517f885dd08f9e5e3efbfcd9a01.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2861af93_9170_4ba2_8ee0_394e47bf8c7d.slice/cri-containerd-5807d12e46a3b0dd2241a1e11f62bbd4c119ab982f2e35d1eed533798b3e0150.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2861af93_9170_4ba2_8ee0_394e47bf8c7d.slice/cri-containerd-7cf0b9d09007ab1238d4e748ca3f739abc7fa6bf280370c387d584efc58d6bd4.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc90b4ad5_8402_4e79_a475_4f6dc3dd25ac.slice/cri-containerd-362be1ee7aeae186135f5be5dde8d7e3c15eb46d21338cb1e9a318286db51b5f.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc90b4ad5_8402_4e79_a475_4f6dc3dd25ac.slice/cri-containerd-2920ca18a8f36d644c0b79255c10ff610d102d018172f4d48b5cd7f5b9316822.scope
    679      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b97bd75_6231_44c6_aed7_7044e1d97ccd.slice/cri-containerd-b937c739130501d1ecb6164af341d6bd8fdf50d3f8664adac2cbbb51d2c0cf3f.scope
    644      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b97bd75_6231_44c6_aed7_7044e1d97ccd.slice/cri-containerd-26d91093bb7e05bf9cbd5f1ad368427fb25509dbd7ba7a79d56178ed78bd56b9.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b97bd75_6231_44c6_aed7_7044e1d97ccd.slice/cri-containerd-942ffd36f9117c008e49847e653f75c2a5c47473652aedb7e3785347572cbe15.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b97bd75_6231_44c6_aed7_7044e1d97ccd.slice/cri-containerd-cc0725990803a08b59124edad8fdb7c5ed980c84ddcb9dc1313ada1b30cdacbf.scope
    660      cgroup_device   multi                                          
