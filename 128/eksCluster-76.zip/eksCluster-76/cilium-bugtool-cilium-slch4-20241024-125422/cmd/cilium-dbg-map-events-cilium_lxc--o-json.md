{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.110Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.125Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.169Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.740Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.749Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.797Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.798Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.846Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.072Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.076Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.187Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.187Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.238Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.802Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.813Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.841Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.872Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.884Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.134Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.159Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.265Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.293Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.337Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.847Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.852Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.888Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.896Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.938Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.943Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.972Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.220Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.223Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.273Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.290Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.328Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.877Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.881Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.919Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.920Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.965Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.993Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.005Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.232Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.260Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.287Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.311Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.339Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.749Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.759Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.802Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.828Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.840Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.106Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.128Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.164Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.172Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.221Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.645Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.650Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.698Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.699Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.734Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.962Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.962Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.015Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.042Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.060Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.484Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.583Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.591Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.635Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.642Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.858Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.863Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.907Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.953Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.957Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.351Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.397Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.404Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.442Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.452Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.479Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.710Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.731Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.770Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.778Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.814Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.201Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.234Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.243Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.274Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.337Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.375Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.612Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.622Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.667Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.688Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.718Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.039Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.048Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.103Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.124Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.153Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.368Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.380Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.427Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.436Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.488Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.815Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.815Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.875Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.878Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.912Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.181Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.203Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.232Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.250Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.290Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.922Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.925Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.964Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.967Z",
  "value": "id=1843  sec_id=5052253 flags=0x0000 ifindex=22  mac=12:01:D8:61:38:62 nodemac=5A:39:0F:2F:1F:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.000Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.282Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.285Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.980Z",
  "value": "id=596   sec_id=5054456 flags=0x0000 ifindex=24  mac=42:67:11:B4:18:AF nodemac=6A:16:CA:66:51:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.76.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.989Z",
  "value": "id=776   sec_id=5048122 flags=0x0000 ifindex=20  mac=C2:D5:B7:48:EF:CB nodemac=A2:CF:88:3C:1B:A0"
}

