Node 0, zone      DMA    123     79     15     41     19     10      6      2      3      3     41 
Node 0, zone   Normal   1043    444    103     43     19      6      2      2      2      1      6 
