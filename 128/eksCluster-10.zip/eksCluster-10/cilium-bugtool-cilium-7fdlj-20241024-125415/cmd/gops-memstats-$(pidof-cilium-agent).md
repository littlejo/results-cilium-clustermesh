alloc: 125.13MB (131208248 bytes)
total-alloc: 3.16GB (3388056192 bytes)
sys: 223.07MB (233907540 bytes)
lookups: 0
mallocs: 76182494
frees: 74950025
heap-alloc: 125.13MB (131208248 bytes)
heap-sys: 176.61MB (185188352 bytes)
heap-idle: 28.70MB (30089216 bytes)
heap-in-use: 147.91MB (155099136 bytes)
heap-released: 8.22MB (8617984 bytes)
heap-objects: 1232469
stack-in-use: 35.34MB (37060608 bytes)
stack-sys: 35.34MB (37060608 bytes)
stack-mspan-inuse: 2.30MB (2410240 bytes)
stack-mspan-sys: 2.80MB (2937600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 690.81KB (707385 bytes)
gc-sys: 5.54MB (5809296 bytes)
next-gc: when heap-alloc >= 154.04MB (161523608 bytes)
last-gc: 2024-10-24 12:54:15.951886356 +0000 UTC
gc-pause-total: 9.02942ms
gc-pause: 84503
gc-pause-end: 1729774455951886356
num-gc: 103
num-forced-gc: 0
gc-cpu-fraction: 0.000515936335145776
enable-gc: true
debug-gc: false
