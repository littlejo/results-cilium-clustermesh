filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf34a68b414ff direct-action not_in_hw id 514 tag cd901737346e3c74 jited 
