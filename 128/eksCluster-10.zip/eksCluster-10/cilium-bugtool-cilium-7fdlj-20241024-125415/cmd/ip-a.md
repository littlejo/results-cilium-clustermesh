1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:84:30:b3:9c:87 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.158.205/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3391sec preferred_lft 3391sec
    inet6 fe80::484:30ff:feb3:9c87/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ff:64:2a:eb:3d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.143.95/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4ff:64ff:fe2a:eb3d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:15:cb:21:79:29 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f815:cbff:fe21:7929/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:0d:6b:41:95:24 brd ff:ff:ff:ff:ff:ff
    inet 10.10.0.123/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::980d:6bff:fe41:9524/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether b2:dd:0d:76:af:b7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b0dd:dff:fe76:afb7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:b3:12:e7:14:e9 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::fcb3:12ff:fee7:14e9/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc9596327e672d@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:af:f1:5a:06:a8 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d0af:f1ff:fe5a:6a8/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcf34a68b414ff@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:40:5b:bb:54:ac brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::6c40:5bff:febb:54ac/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc1321d1ed7244@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:04:41:68:69:b0 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::f804:41ff:fe68:69b0/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcd393acd7da47@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:91:c3:ea:01:51 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::cc91:c3ff:feea:151/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc308b5649dc31@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:45:6e:be:ff:a4 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::fc45:6eff:febe:ffa4/64 scope link 
       valid_lft forever preferred_lft forever
24: lxce770727e42e3@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:aa:fc:cd:8e:3a brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::caa:fcff:fecd:8e3a/64 scope link 
       valid_lft forever preferred_lft forever
