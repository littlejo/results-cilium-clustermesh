REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     135722    10999747    677    bpf_overlay.c
Interface                   INGRESS     679449    247945582   1132   bpf_host.c
Policy denied               EGRESS      60        4440        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      10676     1749451     86     l3.h
Success                     EGRESS      136942    11098311    53     encap.h
Success                     EGRESS      144468    19461572    1308   bpf_lxc.c
Success                     EGRESS      59334     4812431     1694   bpf_host.c
Success                     INGRESS     167680    19094223    86     l3.h
Success                     INGRESS     255375    27073460    235    trace.h
Unsupported L3 protocol     EGRESS      72        5420        1492   bpf_lxc.c
