filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc308b5649dc31 direct-action not_in_hw id 3283 tag bb301d0f73108fad jited 
