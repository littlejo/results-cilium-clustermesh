USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3284  0.0  0.1 1229000 4760 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3272  0.0  0.4 1240432 15984 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3307  0.0  0.0   6408  1636 ?        R    12:54   0:00  \_ ps auxfw
root        3308  0.0  0.4 1240432 15984 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  3.9  7.3 1538804 288384 ?      Ssl  12:25   1:09 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.2  0.2 1229744 8912 ?        Sl   12:25   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
