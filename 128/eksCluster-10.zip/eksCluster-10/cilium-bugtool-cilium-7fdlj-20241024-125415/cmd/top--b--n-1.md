top - 12:54:16 up 33 min,  0 users,  load average: 0.39, 0.45, 0.30
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 65.5 us, 31.0 sy,  0.0 ni,  3.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    278.8 free,   1061.9 used,   2495.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2593.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 297888  80000 S  80.0   7.6   1:10.17 cilium-+
   3312 root      20   0 1229640  18404   4004 S   6.7   0.5   0:00.01 gops
    394 root      20   0 1229744   8912   2924 S   0.0   0.2   0:04.33 cilium-+
   3272 root      20   0 1240432  15984  11228 S   0.0   0.4   0:00.02 cilium-+
   3315 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3335 root      20   0    6576   2412   2088 R   0.0   0.1   0:00.00 top
   3361 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
