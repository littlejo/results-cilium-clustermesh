35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:39+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:20:39+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:20:40+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:20:40+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:40+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:20:40+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:20:40+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:20:40+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:20:44+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:20:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:20:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:20:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:24:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:24:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:25:14+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 124
485: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:25:14+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
486: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:25:14+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
487: sched_cls  name tail_handle_ipv4  tag 425ef97ec307599e  gpl
	loaded_at 2024-10-24T12:25:14+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
510: sched_cls  name tail_ipv4_ct_egress  tag 4390209af9a16468  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 153
511: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 154
513: sched_cls  name tail_handle_ipv4_cont  tag 6748ff23345c49ca  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,107,41,106,82,83,39,76,74,77,108,40,37,38,81
	btf_id 156
514: sched_cls  name cil_from_container  tag cd901737346e3c74  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,76
	btf_id 157
515: sched_cls  name tail_ipv4_to_endpoint  tag 67a9119085b7318c  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,107,41,82,83,80,106,39,108,40,37,38
	btf_id 158
516: sched_cls  name tail_handle_arp  tag 3a375704b5fd1f35  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 159
517: sched_cls  name tail_handle_ipv4  tag 5a89a4551f0f8c36  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 160
518: sched_cls  name handle_policy  tag bae5c4a898f42746  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,108,82,83,107,41,80,106,39,84,75,40,37,38
	btf_id 161
519: sched_cls  name tail_ipv4_ct_ingress  tag 1355b2c39007e614  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 162
520: sched_cls  name __send_drop_notify  tag 9bf83e5c772a6177  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 163
521: sched_cls  name tail_ipv4_to_endpoint  tag 9550b1430b7f4318  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,110,41,82,83,80,100,39,109,40,37,38
	btf_id 165
522: sched_cls  name tail_handle_ipv4_cont  tag 203af811911461ef  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,110,41,100,82,83,39,76,74,77,109,40,37,38,81
	btf_id 166
523: sched_cls  name cil_from_container  tag be251ab6de9ee69c  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 109,76
	btf_id 167
524: sched_cls  name handle_policy  tag cc54e195e159c17d  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,109,82,83,110,41,80,100,39,84,75,40,37,38
	btf_id 168
525: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
526: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 169
529: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
530: sched_cls  name tail_ipv4_ct_ingress  tag 7e37d0342f8e2225  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 170
531: sched_cls  name __send_drop_notify  tag 3fa8eb6ed8503ec5  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 171
532: sched_cls  name tail_handle_arp  tag 59ec0a4eddca2b56  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 172
533: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 173
535: sched_cls  name tail_handle_ipv4  tag 6465d80e955e5c11  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 175
536: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
539: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
540: sched_cls  name tail_ipv4_to_endpoint  tag 55db42ff7379c75b  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,101,39,114,40,37,38
	btf_id 177
541: sched_cls  name tail_handle_ipv4  tag 0c37954be2b96e2f  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,114
	btf_id 178
542: sched_cls  name tail_handle_arp  tag 47d09aa7de24aed6  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,114
	btf_id 179
543: sched_cls  name tail_ipv4_ct_ingress  tag d57a526acf9a2819  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 180
544: sched_cls  name tail_handle_ipv4_cont  tag d2168f27d984e25c  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,101,82,83,39,76,74,77,114,40,37,38,81
	btf_id 181
545: sched_cls  name __send_drop_notify  tag 47302513db83f4ad  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 182
546: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,114
	btf_id 183
547: sched_cls  name cil_from_container  tag 39427a4a7f5d3c52  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 114,76
	btf_id 184
549: sched_cls  name handle_policy  tag 0d864adbd977fd48  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,114,82,83,113,41,80,101,39,84,75,40,37,38
	btf_id 186
550: sched_cls  name tail_ipv4_ct_egress  tag 4390209af9a16468  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 187
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:25:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
560: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 190
561: sched_cls  name __send_drop_notify  tag e4a2ff3c333debfd  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 191
562: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 192
564: sched_cls  name tail_handle_ipv4_from_host  tag 9259b1ee7fc083cf  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 194
565: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 195
566: sched_cls  name tail_handle_ipv4_from_host  tag 9259b1ee7fc083cf  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 197
567: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 198
569: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 200
570: sched_cls  name __send_drop_notify  tag e4a2ff3c333debfd  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
573: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 205
574: sched_cls  name tail_handle_ipv4_from_host  tag 9259b1ee7fc083cf  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 206
575: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 207
578: sched_cls  name __send_drop_notify  tag e4a2ff3c333debfd  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 210
580: sched_cls  name __send_drop_notify  tag e4a2ff3c333debfd  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 213
582: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 215
583: sched_cls  name tail_handle_ipv4_from_host  tag 9259b1ee7fc083cf  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 216
584: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:25:18+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 217
626: sched_cls  name tail_handle_ipv4_cont  tag 6001b3aa524d2e00  gpl
	loaded_at 2024-10-24T12:42:58+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 233
627: sched_cls  name handle_policy  tag 738fd7746163a790  gpl
	loaded_at 2024-10-24T12:42:58+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 234
628: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 235
629: sched_cls  name tail_ipv4_ct_egress  tag e82fa9f7497ccf22  gpl
	loaded_at 2024-10-24T12:42:58+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 236
630: sched_cls  name tail_handle_ipv4  tag 649a5040cba64d0a  gpl
	loaded_at 2024-10-24T12:42:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 237
631: sched_cls  name tail_ipv4_to_endpoint  tag 152f2b4eb3cf85e2  gpl
	loaded_at 2024-10-24T12:42:58+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 238
632: sched_cls  name __send_drop_notify  tag 1d5754d05de69338  gpl
	loaded_at 2024-10-24T12:42:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 239
633: sched_cls  name tail_ipv4_ct_ingress  tag 582c065217011dd3  gpl
	loaded_at 2024-10-24T12:42:58+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 240
634: sched_cls  name tail_handle_arp  tag bdab9e254319371d  gpl
	loaded_at 2024-10-24T12:42:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 241
635: sched_cls  name cil_from_container  tag 2d062e3272378641  gpl
	loaded_at 2024-10-24T12:42:58+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 242
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:43:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:43:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
687: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
690: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
691: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
694: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
706: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
709: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
710: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
713: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
714: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
717: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
718: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
721: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
722: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
725: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3278: sched_cls  name tail_handle_ipv4_cont  tag f10ff0b4e42601cc  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,625,41,148,82,83,39,76,74,77,626,40,37,38,81
	btf_id 3065
3280: sched_cls  name tail_ipv4_to_endpoint  tag 2316e0fad4fdb7d6  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,625,41,82,83,80,148,39,626,40,37,38
	btf_id 3066
3282: sched_cls  name __send_drop_notify  tag 1617c9b983ce1eb6  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3070
3283: sched_cls  name cil_from_container  tag bb301d0f73108fad  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 626,76
	btf_id 3072
3285: sched_cls  name tail_handle_arp  tag 311be03336457a53  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,626
	btf_id 3074
3288: sched_cls  name tail_handle_ipv4  tag 3d5140d9d155a478  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,626
	btf_id 3075
3290: sched_cls  name handle_policy  tag fa0927a249e116d1  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,626,82,83,625,41,80,148,39,84,75,40,37,38
	btf_id 3078
3291: sched_cls  name tail_ipv4_ct_egress  tag 762eed644d1c04e0  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,626,82,83,625,84
	btf_id 3080
3293: sched_cls  name tail_ipv4_ct_ingress  tag 53e37ebcbe55cda7  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,626,82,83,625,84
	btf_id 3081
3295: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:14+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,626
	btf_id 3083
3333: sched_cls  name tail_ipv4_ct_egress  tag b5e69205bfc8712d  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,635,82,83,636,84
	btf_id 3125
3334: sched_cls  name __send_drop_notify  tag 49345a2346f01fd1  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3127
3335: sched_cls  name cil_from_container  tag 1e061467856f9bea  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 637,76
	btf_id 3128
3336: sched_cls  name tail_ipv4_to_endpoint  tag 43d6992d94fea473  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,638,41,82,83,80,145,39,637,40,37,38
	btf_id 3130
3337: sched_cls  name handle_policy  tag e3842918a02a6f9f  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,635,82,83,636,41,80,153,39,84,75,40,37,38
	btf_id 3129
3338: sched_cls  name tail_handle_arp  tag fe62f40f4334a591  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,635
	btf_id 3132
3339: sched_cls  name tail_ipv4_to_endpoint  tag 0385c82686ec8c36  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,636,41,82,83,80,153,39,635,40,37,38
	btf_id 3133
3340: sched_cls  name handle_policy  tag 3d09106aa37e2848  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,637,82,83,638,41,80,145,39,84,75,40,37,38
	btf_id 3131
3341: sched_cls  name tail_handle_ipv4  tag 0981826460fe2b4e  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,635
	btf_id 3134
3342: sched_cls  name tail_handle_arp  tag af7eb67e8145b53c  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,637
	btf_id 3135
3343: sched_cls  name tail_ipv4_ct_ingress  tag e644aa32a4a1d6ee  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3136
3344: sched_cls  name tail_ipv4_ct_ingress  tag a6a7d311b02869cc  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,635,82,83,636,84
	btf_id 3137
3345: sched_cls  name cil_from_container  tag 7fca77545d69014a  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 635,76
	btf_id 3139
3347: sched_cls  name tail_handle_ipv4_cont  tag bc205703e3cdb8d9  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,636,41,153,82,83,39,76,74,77,635,40,37,38,81
	btf_id 3141
3348: sched_cls  name __send_drop_notify  tag 419bcb2bd577d247  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3142
3349: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,635
	btf_id 3143
3350: sched_cls  name tail_handle_ipv4_cont  tag 4fe3e2138f10040e  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,638,41,145,82,83,39,76,74,77,637,40,37,38,81
	btf_id 3138
3352: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,637
	btf_id 3145
3353: sched_cls  name tail_handle_ipv4  tag 841f68844b42a8cb  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,637
	btf_id 3146
3354: sched_cls  name tail_ipv4_ct_egress  tag 485bb5f7f9b01817  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3147
