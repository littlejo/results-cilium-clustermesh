key: 1e 00 00 00  value: 06 02 00 00
key: 9c 01 00 00  value: 73 02 00 00
key: 96 08 00 00  value: da 0c 00 00
key: 3d 09 00 00  value: 09 0d 00 00
key: bc 09 00 00  value: 0c 02 00 00
key: 06 0b 00 00  value: 25 02 00 00
key: 01 0f 00 00  value: 0c 0d 00 00
Found 7 elements
