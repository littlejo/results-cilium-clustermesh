CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcae083a6_8848_4828_a94b_537b7c5fdf58.slice/cri-containerd-83f103277015636dcaaf0fc223c3811167f16d59c051635ea37e98be8bd78f78.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcae083a6_8848_4828_a94b_537b7c5fdf58.slice/cri-containerd-d32d4584305e1c64a424a7bd625ceda150b0462aacccef153ece3839b7f2c5b9.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc2d99125_d6de_4be4_9c1a_c15a2ae8858c.slice/cri-containerd-dc4f6e0c3fb7eee2784f9d626b9c89d9cccb64d32fecf02e71d6b0ad83323d80.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc2d99125_d6de_4be4_9c1a_c15a2ae8858c.slice/cri-containerd-036ac43c00208750c8df39767c5310ec5448a5e6815a5cc0b4272e33a5134c42.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0e5f9724_494d_4e40_9ca1_dfbf7789101e.slice/cri-containerd-66f41d4f1f12bc63710933583257573ff496a81db272493125fb6546457aa4b4.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0e5f9724_494d_4e40_9ca1_dfbf7789101e.slice/cri-containerd-787210cd76415417217cddaf42e31d7f26e29dc6c1f97a6c54753604fd37ee31.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14fe20fa_adf1_4e12_894e_c0ab8621ed24.slice/cri-containerd-0f142d2dfb0397d460f0c744a2c14b9a069aa702821e2a1d60be8f03a5fa5ecf.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14fe20fa_adf1_4e12_894e_c0ab8621ed24.slice/cri-containerd-79399902acbb9f8f1d797b77bcce3b56382d97abb5125a0722fcc51a001cbb00.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7598e9ec_bc78_4981_a60a_850d7c8235af.slice/cri-containerd-e477f4aca66c909ba46a1d431ded4927a5a4e07c2db0467f4166bb1f8e170224.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7598e9ec_bc78_4981_a60a_850d7c8235af.slice/cri-containerd-cf42e0835a7db2dad62054b0bbcf7b4e4255807d3dfa2cc20bb00dc2c504efcd.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf76ce2a7_74ec_449a_aed0_c4f7917ddd09.slice/cri-containerd-b7ab287d5f5f1d657ce41c7a7bde0d574a4af8221d5bcf7214acaa14f27737e4.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf76ce2a7_74ec_449a_aed0_c4f7917ddd09.slice/cri-containerd-8d9058fddd701688c79817883af10dc9295483a3a399b11fa9ab4e11752837c7.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf76ce2a7_74ec_449a_aed0_c4f7917ddd09.slice/cri-containerd-591cbec4ac930f56a7d812f05387063d48630fa85a0f49d2361844beb676a68b.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf76ce2a7_74ec_449a_aed0_c4f7917ddd09.slice/cri-containerd-13d23c2f75c446e659aed4ada925dff4de514e9bc66e617a9dc01532999a3ec1.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa17dc31_f4d4_4fdf_b525_de1c4fe1da6e.slice/cri-containerd-ec91b59141774601d7951c0f49f1880c701797eb0c9156d851c1c115181d94d2.scope
    690      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa17dc31_f4d4_4fdf_b525_de1c4fe1da6e.slice/cri-containerd-575aaf81d0fe8c4b767b0dcf756d6e992666ce3d18584791a78ffac2f7d59914.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb501671b_d83a_4241_8e02_cf9941281872.slice/cri-containerd-ae241e1c8d289109eae0a9f8d3e064abe8316d0b3de920738b639aa2286315f8.scope
    694      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb501671b_d83a_4241_8e02_cf9941281872.slice/cri-containerd-b2a7a523c0179cbecf866e9bfb4282b5d5291ec497f2eaf002e0305224141d6e.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb501671b_d83a_4241_8e02_cf9941281872.slice/cri-containerd-f120fb086781b466c45f610652ad503d043ea1435f26e07fc5939f9279db40e4.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a9466f2_54d9_48df_9ac5_db96a78ed8ea.slice/cri-containerd-fd566d76640616314c507dde06ec7ba2447d8df043e3469ab7a236a2935a71f3.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a9466f2_54d9_48df_9ac5_db96a78ed8ea.slice/cri-containerd-79e156dbaa2a7e483d44e6e7c420f46e88b8076a0656a7239dc4e6dfb4ae2f44.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod556c74e4_982a_468d_b208_9cdc4a3102c3.slice/cri-containerd-ffaaac62c15effc52b27eb1694e555355d493cf8003549792d660cd4117a2752.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod556c74e4_982a_468d_b208_9cdc4a3102c3.slice/cri-containerd-71ec4da8c48b405f22bcaaee6cad1611aca98b39360cf4f4bf0a3a07e8e693c4.scope
    97       cgroup_device   multi                                          
