Page block order: 9
Pages per block:  512

Free pages count per migrate type at order       0      1      2      3      4      5      6      7      8      9     10 
Node    0, zone      DMA, type    Unmovable    123     77     13     40     17      9      3      0      1      1      0 
Node    0, zone      DMA, type      Movable      1      1      0      1      1      0      0      1      1      0     26 
Node    0, zone      DMA, type  Reclaimable      0      1      1      0      1      1      1      1      1      1      0 
Node    0, zone      DMA, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type          CMA      0      0      1      0      0      0      1      0      0      1     15 
Node    0, zone      DMA, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type    Unmovable   1035    265     43      0      0      0      1      1      1      0      0 
Node    0, zone   Normal, type      Movable      0    175     54     40     16      5      0      1      0      0      6 
Node    0, zone   Normal, type  Reclaimable      8      4      6      3      3      1      1      0      1      1      0 
Node    0, zone   Normal, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type          CMA      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 

Number of blocks type     Unmovable      Movable  Reclaimable   HighAtomic          CMA      Isolate 
Node 0, zone      DMA           38          426           16            0           32            0 
Node 0, zone   Normal          106         1362           32            0            0            0 
