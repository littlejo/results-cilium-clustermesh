IP ADDRESS         LOCAL ENDPOINT INFO
10.10.0.64:0       id=2822  sec_id=733382 flags=0x0000 ifindex=12  mac=42:1C:B5:F8:89:BB nodemac=D2:AF:F1:5A:06:A8   
10.10.0.179:0      id=2492  sec_id=4     flags=0x0000 ifindex=10  mac=46:2B:DC:D1:42:C5 nodemac=FE:B3:12:E7:14:E9    
10.10.0.68:0       id=30    sec_id=733382 flags=0x0000 ifindex=14  mac=DA:85:A8:A1:AD:AD nodemac=6E:40:5B:BB:54:AC   
10.10.0.126:0      id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4   
10.10.0.19:0       id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A   
10.10.0.78:0       id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51   
10.10.0.166:0      id=412   sec_id=721526 flags=0x0000 ifindex=18  mac=5E:52:7F:D3:D4:7C nodemac=FA:04:41:68:69:B0   
172.31.158.205:0   (localhost)                                                                                       
172.31.143.95:0    (localhost)                                                                                       
10.10.0.123:0      (localhost)                                                                                       
