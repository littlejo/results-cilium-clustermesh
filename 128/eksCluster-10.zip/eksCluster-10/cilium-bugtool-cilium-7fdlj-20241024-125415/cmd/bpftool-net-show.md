xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 573
ens6(5) clsact/ingress cil_from_netdev-ens6 id 582
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 569
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 560
cilium_host(7) clsact/egress cil_from_host-cilium_host id 562
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 523
lxc9596327e672d(12) clsact/ingress cil_from_container-lxc9596327e672d id 547
lxcf34a68b414ff(14) clsact/ingress cil_from_container-lxcf34a68b414ff id 514
lxc1321d1ed7244(18) clsact/ingress cil_from_container-lxc1321d1ed7244 id 635
lxcd393acd7da47(20) clsact/ingress cil_from_container-lxcd393acd7da47 id 3335
lxc308b5649dc31(22) clsact/ingress cil_from_container-lxc308b5649dc31 id 3283
lxce770727e42e3(24) clsact/ingress cil_from_container-lxce770727e42e3 id 3345

flow_dissector:

netfilter:

