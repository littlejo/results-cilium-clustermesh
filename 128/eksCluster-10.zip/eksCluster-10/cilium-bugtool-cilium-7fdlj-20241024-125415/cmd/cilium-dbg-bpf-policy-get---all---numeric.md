Endpoint ID: 16
Path: /sys/fs/bpf/tc/globals/cilium_policy_00016

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 30
Path: /sys/fs/bpf/tc/globals/cilium_policy_00030

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    281376   2541      0        
Allow    Ingress     1          ANY          NONE         disabled    169949   1959      0        
Allow    Egress      0          ANY          NONE         disabled    71911    714       0        


Endpoint ID: 412
Path: /sys/fs/bpf/tc/globals/cilium_policy_00412

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6075036   59945     0        
Allow    Ingress     1          ANY          NONE         disabled    4840814   50761     0        
Allow    Egress      0          ANY          NONE         disabled    5690038   57320     0        


Endpoint ID: 2198
Path: /sys/fs/bpf/tc/globals/cilium_policy_02198

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379015   4419      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2365
Path: /sys/fs/bpf/tc/globals/cilium_policy_02365

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2492
Path: /sys/fs/bpf/tc/globals/cilium_policy_02492

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6232498   77053     0        
Allow    Ingress     1          ANY          NONE         disabled    70634     852       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2822
Path: /sys/fs/bpf/tc/globals/cilium_policy_02822

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    283712   2559      0        
Allow    Ingress     1          ANY          NONE         disabled    168101   1931      0        
Allow    Egress      0          ANY          NONE         disabled    72900    723       0        


Endpoint ID: 3841
Path: /sys/fs/bpf/tc/globals/cilium_policy_03841

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


