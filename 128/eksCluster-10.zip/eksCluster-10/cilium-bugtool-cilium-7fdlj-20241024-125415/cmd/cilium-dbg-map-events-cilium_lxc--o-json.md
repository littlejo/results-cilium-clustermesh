{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:28.218Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:28.246Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:28.267Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.802Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.853Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.854Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.907Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.924Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:30.945Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.153Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.162Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.218Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.242Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:31.264Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.889Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.940Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.028Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.041Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:34.075Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.284Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.288Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.337Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.345Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:35.388Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.962Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.968Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.994Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.014Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.070Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.071Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.110Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.331Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.354Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.411Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.414Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.416Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.953Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:44.954Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.010Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.032Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.138Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.151Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.226Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.387Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.391Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.443Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.474Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.490Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.901Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.905Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.953Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.967Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.992Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.224Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.225Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.290Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.290Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.331Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.808Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.811Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.856Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.869Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.894Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.121Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.124Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.218Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.246Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.272Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.686Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.688Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.732Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.754Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.799Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.012Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.021Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.085Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.108Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.139Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.560Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.571Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.619Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.624Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.656Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.876Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.884Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.937Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.946Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.987Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.468Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.480Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.535Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.563Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.575Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.773Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.775Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.874Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.883Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.920Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.182Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.220Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.230Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.271Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.298Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.311Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.575Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.579Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.623Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.639Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.674Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.003Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.019Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.053Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.082Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.082Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.098Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.405Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.411Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.450Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.487Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.172Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.175Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.212Z",
  "value": "id=2198  sec_id=721853 flags=0x0000 ifindex=22  mac=C6:02:AC:1B:3A:AB nodemac=FE:45:6E:BE:FF:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.237Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.253Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.526Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.528Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.153Z",
  "value": "id=2365  sec_id=731723 flags=0x0000 ifindex=24  mac=6A:DC:F2:0D:EF:57 nodemac=0E:AA:FC:CD:8E:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.166Z",
  "value": "id=3841  sec_id=724676 flags=0x0000 ifindex=20  mac=52:16:BC:28:83:A5 nodemac=CE:91:C3:EA:01:51"
}

