[
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0e5f9724_494d_4e40_9ca1_dfbf7789101e.slice/cri-containerd-787210cd76415417217cddaf42e31d7f26e29dc6c1f97a6c54753604fd37ee31.scope"
      }
    ],
    "ips": [
      "10.10.0.68"
    ],
    "name": "coredns-cc6ccd49c-j49nf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14fe20fa_adf1_4e12_894e_c0ab8621ed24.slice/cri-containerd-79399902acbb9f8f1d797b77bcce3b56382d97abb5125a0722fcc51a001cbb00.scope"
      }
    ],
    "ips": [
      "10.10.0.64"
    ],
    "name": "coredns-cc6ccd49c-c2jgs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa17dc31_f4d4_4fdf_b525_de1c4fe1da6e.slice/cri-containerd-575aaf81d0fe8c4b767b0dcf756d6e992666ce3d18584791a78ffac2f7d59914.scope"
      }
    ],
    "ips": [
      "10.10.0.78"
    ],
    "name": "client-974f6c69d-2dj86",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf76ce2a7_74ec_449a_aed0_c4f7917ddd09.slice/cri-containerd-13d23c2f75c446e659aed4ada925dff4de514e9bc66e617a9dc01532999a3ec1.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf76ce2a7_74ec_449a_aed0_c4f7917ddd09.slice/cri-containerd-b7ab287d5f5f1d657ce41c7a7bde0d574a4af8221d5bcf7214acaa14f27737e4.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf76ce2a7_74ec_449a_aed0_c4f7917ddd09.slice/cri-containerd-591cbec4ac930f56a7d812f05387063d48630fa85a0f49d2361844beb676a68b.scope"
      }
    ],
    "ips": [
      "10.10.0.166"
    ],
    "name": "clustermesh-apiserver-6dcb7575d8-c2hgk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a9466f2_54d9_48df_9ac5_db96a78ed8ea.slice/cri-containerd-fd566d76640616314c507dde06ec7ba2447d8df043e3469ab7a236a2935a71f3.scope"
      }
    ],
    "ips": [
      "10.10.0.19"
    ],
    "name": "client2-57cf4468f-pl2sf",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb501671b_d83a_4241_8e02_cf9941281872.slice/cri-containerd-b2a7a523c0179cbecf866e9bfb4282b5d5291ec497f2eaf002e0305224141d6e.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb501671b_d83a_4241_8e02_cf9941281872.slice/cri-containerd-f120fb086781b466c45f610652ad503d043ea1435f26e07fc5939f9279db40e4.scope"
      }
    ],
    "ips": [
      "10.10.0.126"
    ],
    "name": "echo-same-node-86d9cc975c-qrd8d",
    "namespace": "cilium-test-1"
  }
]

