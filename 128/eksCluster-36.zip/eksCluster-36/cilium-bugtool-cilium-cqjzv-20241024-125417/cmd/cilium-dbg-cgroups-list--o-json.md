[
  {
    "containers": [
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52df3ea0_0f35_429b_b55d_ca7cca5f396d.slice/cri-containerd-9be66d69183e1f5d9f7f8fba6133c3c3eb47f7dc83f0dc17eecdada4f816d0ca.scope"
      },
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52df3ea0_0f35_429b_b55d_ca7cca5f396d.slice/cri-containerd-9f53a32f303ed3c265816dedc1806240c80c933f6e71894d1f255dc5da1bf15f.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52df3ea0_0f35_429b_b55d_ca7cca5f396d.slice/cri-containerd-62ae6f638009b56a9aa3bc60b22186688caf6a903ed6f8eebda83247159a8ad7.scope"
      }
    ],
    "ips": [
      "10.36.0.26"
    ],
    "name": "clustermesh-apiserver-bcb687b66-6f2d4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3430eb64_b582_40ae_94ea_05cf9c587824.slice/cri-containerd-997e0186ce27cfd8618776c9c3f86d5b783dbb9f9381391fb3c84717b35f852c.scope"
      }
    ],
    "ips": [
      "10.36.0.155"
    ],
    "name": "coredns-cc6ccd49c-2nf42",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod668cc123_6b67_48fd_ad0d_ff07c6377d15.slice/cri-containerd-5a201840e655f8700011f5d5600950386c40813a93d6f644f24f8db656f01823.scope"
      }
    ],
    "ips": [
      "10.36.0.157"
    ],
    "name": "client2-57cf4468f-qf7k6",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91ead822_34ee_4f5b_9f2d_7e1728d5d893.slice/cri-containerd-b426e68e7e84e4be20b50f6c603778dc2cc5a029b932c6557ed14202b0b3e439.scope"
      }
    ],
    "ips": [
      "10.36.0.15"
    ],
    "name": "client-974f6c69d-qnvlj",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfd6836b6_dab1_402c_8499_c9a903a594c2.slice/cri-containerd-8770b934caf5d77aa94ab751be67af2fdcedafc6b2b50eb102e83657e278ab17.scope"
      }
    ],
    "ips": [
      "10.36.0.68"
    ],
    "name": "coredns-cc6ccd49c-qzzqn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9fd59de_f32f_4b4c_9ddf_ff1aaa2ec3ba.slice/cri-containerd-70ce302009e53405520beba3dcb6a11f2412dce9507f1297ed73828af4a41595.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9fd59de_f32f_4b4c_9ddf_ff1aaa2ec3ba.slice/cri-containerd-d707b7cf726e5605131c43f8fb36df5e3ed854d655309080d76e358f87af9c68.scope"
      }
    ],
    "ips": [
      "10.36.0.205"
    ],
    "name": "echo-same-node-86d9cc975c-vnc5h",
    "namespace": "cilium-test-1"
  }
]

