CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5a6f8cc6_9319_472e_a96a_d401309aa7be.slice/cri-containerd-61ce5060110d16372f84e1a94b739210efd58c1349e549eea700fd2906006451.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5a6f8cc6_9319_472e_a96a_d401309aa7be.slice/cri-containerd-8b32afa8e9d3509a87cd56149f737a6c2e44b294c69307ee95d3b1b9a6cdcb67.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfd6836b6_dab1_402c_8499_c9a903a594c2.slice/cri-containerd-c0fbe6fb681d0a7ae6b800d6abbd7b388e543316909360a07a01c62d008ba2f2.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfd6836b6_dab1_402c_8499_c9a903a594c2.slice/cri-containerd-8770b934caf5d77aa94ab751be67af2fdcedafc6b2b50eb102e83657e278ab17.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3430eb64_b582_40ae_94ea_05cf9c587824.slice/cri-containerd-9bebaac3c4a37da793f3d100c7d6cf951c711b33fbe84a03e33f87e833d0b61c.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3430eb64_b582_40ae_94ea_05cf9c587824.slice/cri-containerd-997e0186ce27cfd8618776c9c3f86d5b783dbb9f9381391fb3c84717b35f852c.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod586fece2_b5a1_4b01_b152_ce3e21d9624f.slice/cri-containerd-18bb4b6091b500cf4e37bd2ea38c35aebb708e925d9c3e285d5a4ddfb157a3bd.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod586fece2_b5a1_4b01_b152_ce3e21d9624f.slice/cri-containerd-7c874f7d623895c404ba53ea2f7deaabb72fc94b4581b00b5da11368123ec5c4.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91ead822_34ee_4f5b_9f2d_7e1728d5d893.slice/cri-containerd-b426e68e7e84e4be20b50f6c603778dc2cc5a029b932c6557ed14202b0b3e439.scope
    734      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91ead822_34ee_4f5b_9f2d_7e1728d5d893.slice/cri-containerd-e29920fd2a953f383a9e4948b08bc691cb21b092c159b4d3efee3539edeebd18.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e242589_5135_4f5c_b0be_589eef19ebb0.slice/cri-containerd-1fbd029f07a361a4ea3b9f2e94348256796c4bf1e63834bd8ae41639d9fc15f6.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e242589_5135_4f5c_b0be_589eef19ebb0.slice/cri-containerd-91b0317372856022f843945965381c114098a2cde3d5b203e9f10c3778f91aa5.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod668cc123_6b67_48fd_ad0d_ff07c6377d15.slice/cri-containerd-6b04b1810b2d84993e6e2f3f2eb12cab2e6e4995195dc0b154ecbee04a36a083.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod668cc123_6b67_48fd_ad0d_ff07c6377d15.slice/cri-containerd-5a201840e655f8700011f5d5600950386c40813a93d6f644f24f8db656f01823.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9fd59de_f32f_4b4c_9ddf_ff1aaa2ec3ba.slice/cri-containerd-70ce302009e53405520beba3dcb6a11f2412dce9507f1297ed73828af4a41595.scope
    742      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9fd59de_f32f_4b4c_9ddf_ff1aaa2ec3ba.slice/cri-containerd-d707b7cf726e5605131c43f8fb36df5e3ed854d655309080d76e358f87af9c68.scope
    738      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9fd59de_f32f_4b4c_9ddf_ff1aaa2ec3ba.slice/cri-containerd-a8d93ba97760568fdbc45dde06549a90496810a9a1e3efd464e3e793736672a0.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52df3ea0_0f35_429b_b55d_ca7cca5f396d.slice/cri-containerd-f4b3ae2b528c2df35f1610e72e303b56f220b225167383313468e5f29c20d7d0.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52df3ea0_0f35_429b_b55d_ca7cca5f396d.slice/cri-containerd-9be66d69183e1f5d9f7f8fba6133c3c3eb47f7dc83f0dc17eecdada4f816d0ca.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52df3ea0_0f35_429b_b55d_ca7cca5f396d.slice/cri-containerd-9f53a32f303ed3c265816dedc1806240c80c933f6e71894d1f255dc5da1bf15f.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod52df3ea0_0f35_429b_b55d_ca7cca5f396d.slice/cri-containerd-62ae6f638009b56a9aa3bc60b22186688caf6a903ed6f8eebda83247159a8ad7.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ea3e15e_5287_4d1e_b467_65b53729a46c.slice/cri-containerd-686718383feb92902e5aebab0ae326279704ec7f9de22dca7e03ae766a851479.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ea3e15e_5287_4d1e_b467_65b53729a46c.slice/cri-containerd-69b14a76bdac9e14a1bad115dc478e56283a25739d4a7eb7cca9a2d5a4c88dcf.scope
    109      cgroup_device   multi                                          
