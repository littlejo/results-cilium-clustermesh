{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:33.883Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.466Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.472Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.504Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.506Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.539Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.837Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.848Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.899Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.914Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:36.952Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.533Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.534Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.594Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.606Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.648Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.681Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:39.697Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.856Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.876Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.975Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.012Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.043Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.631Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.669Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.673Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.721Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.735Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.759Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.949Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.963Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.017Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.040Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.071Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.577Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.582Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.620Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.632Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.669Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.671Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.703Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.916Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.940Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.013Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.054Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:52.083Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.419Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.430Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.470Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.496Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.507Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.751Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.762Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.806Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.821Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.851Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.231Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.292Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.297Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.335Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.345Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.371Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.568Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.574Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.628Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.651Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.669Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.086Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.095Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.136Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.149Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.173Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.410Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.415Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.465Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.475Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.523Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.885Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.923Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.924Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.960Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.972Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.001Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.278Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.281Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.349Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.388Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.430Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.804Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.812Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.843Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.871Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.887Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.177Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.190Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.242Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.257Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.290Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.639Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.649Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.679Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.693Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.694Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.721Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.990Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.999Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.109Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.137Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.171Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.439Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.443Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.482Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.516Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.531Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.786Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.796Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.817Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.829Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.835Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.593Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.596Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.628Z",
  "value": "id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.642Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.666Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.969Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.973Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.637Z",
  "value": "id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.645Z",
  "value": "id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63"
}

