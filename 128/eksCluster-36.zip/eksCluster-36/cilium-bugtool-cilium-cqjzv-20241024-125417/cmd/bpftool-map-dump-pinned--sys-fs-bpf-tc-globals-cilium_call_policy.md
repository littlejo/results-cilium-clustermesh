key: 45 02 00 00  value: f8 0c 00 00
key: d5 02 00 00  value: 84 02 00 00
key: 2c 06 00 00  value: 16 02 00 00
key: ae 06 00 00  value: 27 02 00 00
key: 2e 09 00 00  value: 2c 02 00 00
key: b6 0a 00 00  value: 26 0d 00 00
key: 2c 0c 00 00  value: 2d 0d 00 00
Found 7 elements
