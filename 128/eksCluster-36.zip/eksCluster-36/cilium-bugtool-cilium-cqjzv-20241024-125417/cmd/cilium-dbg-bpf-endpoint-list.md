IP ADDRESS         LOCAL ENDPOINT INFO
10.36.0.155:0      id=1580  sec_id=2448936 flags=0x0000 ifindex=12  mac=DA:E2:EC:5A:B5:5E nodemac=B6:19:69:8C:5A:30   
10.36.0.208:0      (localhost)                                                                                        
10.36.0.68:0       id=1710  sec_id=2448936 flags=0x0000 ifindex=14  mac=96:20:7B:2F:55:33 nodemac=96:B1:74:ED:B1:21   
172.31.135.11:0    (localhost)                                                                                        
10.36.0.205:0      id=581   sec_id=2436339 flags=0x0000 ifindex=24  mac=1A:01:32:4B:81:9D nodemac=8E:95:30:5E:B3:1F   
10.36.0.190:0      id=2350  sec_id=4     flags=0x0000 ifindex=10  mac=5A:4D:9C:98:30:C9 nodemac=FA:07:D8:72:C6:98     
172.31.147.126:0   (localhost)                                                                                        
10.36.0.15:0       id=2742  sec_id=2442388 flags=0x0000 ifindex=20  mac=8A:66:D6:0A:16:24 nodemac=D6:E4:2F:8F:AA:63   
10.36.0.26:0       id=725   sec_id=2480534 flags=0x0000 ifindex=18  mac=86:13:71:99:F4:91 nodemac=F6:84:DE:9A:AE:18   
10.36.0.157:0      id=3116  sec_id=2465861 flags=0x0000 ifindex=22  mac=FA:97:54:6B:42:74 nodemac=42:3C:D6:AC:B6:B8   
