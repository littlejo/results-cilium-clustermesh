Endpoint ID: 470
Path: /sys/fs/bpf/tc/globals/cilium_policy_00470

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 581
Path: /sys/fs/bpf/tc/globals/cilium_policy_00581

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379858   4430      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 725
Path: /sys/fs/bpf/tc/globals/cilium_policy_00725

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6026941   61181     0        
Allow    Ingress     1          ANY          NONE         disabled    5871998   62363     0        
Allow    Egress      0          ANY          NONE         disabled    7669763   74890     0        


Endpoint ID: 1580
Path: /sys/fs/bpf/tc/globals/cilium_policy_01580

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2518     27        0        
Allow    Ingress     1          ANY          NONE         disabled    158077   1813      0        
Allow    Egress      0          ANY          NONE         disabled    21815    246       0        


Endpoint ID: 1710
Path: /sys/fs/bpf/tc/globals/cilium_policy_01710

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3378     33        0        
Allow    Ingress     1          ANY          NONE         disabled    158212   1820      0        
Allow    Egress      0          ANY          NONE         disabled    20344    228       0        


Endpoint ID: 2350
Path: /sys/fs/bpf/tc/globals/cilium_policy_02350

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6226822   76957     0        
Allow    Ingress     1          ANY          NONE         disabled    68376     828       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2742
Path: /sys/fs/bpf/tc/globals/cilium_policy_02742

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3116
Path: /sys/fs/bpf/tc/globals/cilium_policy_03116

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


