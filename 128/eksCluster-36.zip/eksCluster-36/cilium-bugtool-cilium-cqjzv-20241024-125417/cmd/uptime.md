 12:54:19 up 33 min,  0 users,  load average: 0.20, 0.50, 0.35
