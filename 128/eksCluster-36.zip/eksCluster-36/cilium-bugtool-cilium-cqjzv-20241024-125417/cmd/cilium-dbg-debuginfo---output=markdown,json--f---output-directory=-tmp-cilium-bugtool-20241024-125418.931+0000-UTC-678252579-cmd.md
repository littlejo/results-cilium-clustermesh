markdown output at /tmp/cilium-bugtool-20241024-125418.931+0000-UTC-678252579/cmd/cilium-debuginfo-20241024-125449.726+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125418.931+0000-UTC-678252579/cmd/cilium-debuginfo-20241024-125449.726+0000-UTC.json
