alloc: 119.02MB (124801288 bytes)
total-alloc: 3.18GB (3414814072 bytes)
sys: 215.32MB (225781076 bytes)
lookups: 0
mallocs: 76586218
frees: 75334828
heap-alloc: 119.02MB (124801288 bytes)
heap-sys: 168.58MB (176766976 bytes)
heap-idle: 28.52MB (29900800 bytes)
heap-in-use: 140.06MB (146866176 bytes)
heap-released: 4.93MB (5169152 bytes)
heap-objects: 1251390
stack-in-use: 35.38MB (37093376 bytes)
stack-sys: 35.38MB (37093376 bytes)
stack-mspan-inuse: 2.28MB (2392480 bytes)
stack-mspan-sys: 2.72MB (2856000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1011.52KB (1035793 bytes)
gc-sys: 5.54MB (5811392 bytes)
next-gc: when heap-alloc >= 155.85MB (163418888 bytes)
last-gc: 2024-10-24 12:54:19.026894718 +0000 UTC
gc-pause-total: 11.849452ms
gc-pause: 1169326
gc-pause-end: 1729774459026894718
num-gc: 102
num-forced-gc: 0
gc-cpu-fraction: 0.0005887917418335773
enable-gc: true
debug-gc: false
