Node 0, zone      DMA      1      0      6     34     26     19     10      3      7      4     39 
Node 0, zone   Normal     32      6      1      2      5      3      4      2      1      3      8 
