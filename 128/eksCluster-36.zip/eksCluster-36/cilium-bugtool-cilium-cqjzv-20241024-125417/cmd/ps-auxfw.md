USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3291  0.0  0.2 1616264 8756 ?        Ssl  12:54   0:00 /usr/sbin/runc init
root        3270  0.0  0.1 1229000 4760 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3264  0.0  0.4 1240432 16528 ?       Dsl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3298  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3300  0.0  0.4 1240432 16528 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  4.1  7.4 1539060 291548 ?      Rsl  12:26   1:07 cilium-agent --config-dir=/tmp/cilium/config-map
root         397  0.2  0.2 1229744 9980 ?        Sl   12:27   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
