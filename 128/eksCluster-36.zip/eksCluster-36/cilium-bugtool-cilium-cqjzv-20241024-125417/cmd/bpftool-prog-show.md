35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:20+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:21:20+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:21:21+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:21:21+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:21:21+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:21+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:21:25+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:21:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:21:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:21:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:27:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
485: sched_cls  name tail_handle_ipv4  tag 8393d3ee56270616  gpl
	loaded_at 2024-10-24T12:27:07+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
486: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:27:07+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
487: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:27:07+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
522: sched_cls  name cil_from_container  tag 5825b475d7c55253  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 168
523: sched_cls  name tail_handle_ipv4_cont  tag eee40d2b3d409728  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 170
526: sched_cls  name tail_handle_arp  tag 93c8a41e2c0bdd51  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 172
528: sched_cls  name __send_drop_notify  tag 462491afaeb8bc1d  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 174
529: sched_cls  name tail_ipv4_ct_ingress  tag 32b1fcb80d8e2829  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 175
530: sched_cls  name tail_ipv4_ct_egress  tag 333d29ae8090b7ff  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 177
532: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 178
534: sched_cls  name handle_policy  tag 706e3ff514f90f66  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 180
536: sched_cls  name tail_ipv4_to_endpoint  tag 47edcc82b6153461  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 182
538: sched_cls  name tail_handle_ipv4  tag d6e3abb0c6402543  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 183
539: sched_cls  name tail_ipv4_to_endpoint  tag ddd89ae5d69a4ca4  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 186
540: sched_cls  name tail_handle_ipv4_cont  tag b40e55663229f7af  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 187
541: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 188
542: sched_cls  name __send_drop_notify  tag 60aa2a700e5e0050  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 189
543: sched_cls  name cil_from_container  tag 8c59bf964c21e4fb  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 190
544: sched_cls  name tail_ipv4_ct_ingress  tag 3ed4a33b04d59e35  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 191
545: sched_cls  name tail_handle_ipv4  tag a61a147446d72f1a  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 192
546: sched_cls  name tail_ipv4_ct_egress  tag 333d29ae8090b7ff  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 193
547: sched_cls  name tail_handle_arp  tag 716c0e9977575ce6  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 196
549: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 198
550: sched_cls  name __send_drop_notify  tag d36c7b1575889456  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
551: sched_cls  name handle_policy  tag f7aafc6ee0a5d505  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 197
552: sched_cls  name tail_handle_ipv4  tag 5a9e506936c0cdb8  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,119
	btf_id 202
553: sched_cls  name tail_handle_ipv4_from_host  tag 9ac28ec1397a20cf  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 200
554: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 204
555: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 205
556: sched_cls  name handle_policy  tag fb9a0d32bf10768a  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,119,82,83,120,41,80,100,39,84,75,40,37,38
	btf_id 203
557: sched_cls  name __send_drop_notify  tag e99683d89a95ac98  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
558: sched_cls  name cil_from_container  tag 343e423096853d10  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 119,76
	btf_id 207
560: sched_cls  name tail_ipv4_to_endpoint  tag 3eaf5c2a0660b209  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,120,41,82,83,80,100,39,119,40,37,38
	btf_id 209
561: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 211
562: sched_cls  name __send_drop_notify  tag d36c7b1575889456  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 212
563: sched_cls  name tail_handle_ipv4_from_host  tag 9ac28ec1397a20cf  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 214
564: sched_cls  name tail_handle_ipv4_cont  tag 32dfcf370c584b55  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,120,41,100,82,83,39,76,74,77,119,40,37,38,81
	btf_id 213
565: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 216
566: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,119,82,83,120,84
	btf_id 215
568: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,119
	btf_id 218
570: sched_cls  name tail_ipv4_ct_ingress  tag fdf4dc8f5c28a535  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,119,82,83,120,84
	btf_id 220
573: sched_cls  name tail_handle_arp  tag f6d3a81032a6315c  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,119
	btf_id 223
574: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 225
576: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 227
579: sched_cls  name __send_drop_notify  tag d36c7b1575889456  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 230
580: sched_cls  name tail_handle_ipv4_from_host  tag 9ac28ec1397a20cf  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 231
581: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,126,75
	btf_id 233
584: sched_cls  name __send_drop_notify  tag d36c7b1575889456  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 236
585: sched_cls  name tail_handle_ipv4_from_host  tag 9ac28ec1397a20cf  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,126
	btf_id 237
586: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,126
	btf_id 238
588: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
591: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
592: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
595: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
596: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
599: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:27:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
644: sched_cls  name handle_policy  tag 39bdb845a74e22d0  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 254
645: sched_cls  name __send_drop_notify  tag 84fc7e89cf7411fc  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 255
646: sched_cls  name tail_ipv4_to_endpoint  tag d9119fef2210734b  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 256
647: sched_cls  name tail_handle_ipv4  tag 38f6af5468c97a0d  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 257
648: sched_cls  name tail_handle_ipv4_cont  tag bacc9d4b88bdc180  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 258
649: sched_cls  name tail_handle_arp  tag 40e3434f7b0dbccc  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 259
650: sched_cls  name tail_ipv4_ct_egress  tag df65a8e7d67425dc  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 260
651: sched_cls  name tail_ipv4_ct_ingress  tag daea2eb6d2b815b1  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 261
652: sched_cls  name cil_from_container  tag 24cce21cdb26e8cc  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 262
653: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 263
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
670: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
673: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
674: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
677: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
678: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
681: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
704: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
707: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
708: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
711: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
723: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
726: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
727: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
730: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
731: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
734: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
735: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
738: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
739: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
742: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3306: sched_cls  name tail_ipv4_ct_egress  tag 6e113b6c92843daa  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3097
3307: sched_cls  name __send_drop_notify  tag 7df673cc1f3e9cce  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3098
3308: sched_cls  name tail_handle_ipv4  tag 497b253789b2d151  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,633
	btf_id 3099
3309: sched_cls  name tail_ipv4_to_endpoint  tag 2e7aa12798459115  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,634,41,82,83,80,159,39,633,40,37,38
	btf_id 3100
3311: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,633
	btf_id 3103
3312: sched_cls  name tail_handle_arp  tag f541d2cc72d1783b  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,633
	btf_id 3105
3315: sched_cls  name tail_ipv4_ct_ingress  tag f691444e6be851a6  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,633,82,83,634,84
	btf_id 3106
3317: sched_cls  name tail_handle_ipv4_cont  tag b22165796ec03081  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,634,41,159,82,83,39,76,74,77,633,40,37,38,81
	btf_id 3109
3320: sched_cls  name handle_policy  tag cc9159c55836e4df  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,633,82,83,634,41,80,159,39,84,75,40,37,38
	btf_id 3111
3322: sched_cls  name cil_from_container  tag c381b6214fca3685  gpl
	loaded_at 2024-10-24T12:51:19+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 633,76
	btf_id 3115
3361: sched_cls  name tail_handle_arp  tag 20325b6afa8b0ce3  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,643
	btf_id 3158
3362: sched_cls  name tail_ipv4_ct_ingress  tag eaea7236c1082a04  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,646,82,83,645,84
	btf_id 3159
3363: sched_cls  name tail_ipv4_ct_egress  tag 045382197de7ae66  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,643,82,83,644,84
	btf_id 3160
3364: sched_cls  name tail_handle_ipv4  tag f3afa71f77c0fc5d  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,643
	btf_id 3162
3365: sched_cls  name cil_from_container  tag ef80791262a48c52  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 643,76
	btf_id 3163
3366: sched_cls  name handle_policy  tag 83e152ff3cbd10e3  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,646,82,83,645,41,80,151,39,84,75,40,37,38
	btf_id 3161
3367: sched_cls  name tail_ipv4_to_endpoint  tag 7a0936677528bcad  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,644,41,82,83,80,154,39,643,40,37,38
	btf_id 3164
3368: sched_cls  name __send_drop_notify  tag 986d1c20e057e7c0  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3165
3369: sched_cls  name cil_from_container  tag 1bfec82807e56caf  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 646,76
	btf_id 3166
3371: sched_cls  name tail_handle_arp  tag c3411e3e5d1cab68  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,646
	btf_id 3169
3372: sched_cls  name __send_drop_notify  tag 7180a7c1a24b33cf  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3170
3373: sched_cls  name handle_policy  tag fceeed948cdc9f28  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,643,82,83,644,41,80,154,39,84,75,40,37,38
	btf_id 3168
3375: sched_cls  name tail_ipv4_ct_egress  tag 5a0ccecce1426736  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,646,82,83,645,84
	btf_id 3171
3376: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,643
	btf_id 3173
3377: sched_cls  name tail_ipv4_ct_ingress  tag e8bc964e92b075b0  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,643,82,83,644,84
	btf_id 3174
3378: sched_cls  name tail_handle_ipv4  tag f2e1e78fc9f1110c  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,646
	btf_id 3175
3379: sched_cls  name tail_handle_ipv4_cont  tag 50a04e03ca74f8b5  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,644,41,154,82,83,39,76,74,77,643,40,37,38,81
	btf_id 3177
3380: sched_cls  name tail_ipv4_to_endpoint  tag b9ec5e1e025cbbf4  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,645,41,82,83,80,151,39,646,40,37,38
	btf_id 3176
3381: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,646
	btf_id 3178
3382: sched_cls  name tail_handle_ipv4_cont  tag d24100f2f2319bd7  gpl
	loaded_at 2024-10-24T12:51:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,645,41,151,82,83,39,76,74,77,646,40,37,38,81
	btf_id 3179
