KEY             VALUE
AgentLiveness   2011172825587
UTimeOffset     3378461871093750
