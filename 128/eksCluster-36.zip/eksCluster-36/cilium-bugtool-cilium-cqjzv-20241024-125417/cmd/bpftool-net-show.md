xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 576
ens6(5) clsact/ingress cil_from_netdev-ens6 id 581
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 561
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 549
cilium_host(7) clsact/egress cil_from_host-cilium_host id 555
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 558
lxcf51a3e1fe183(12) clsact/ingress cil_from_container-lxcf51a3e1fe183 id 522
lxc7ce10c137d83(14) clsact/ingress cil_from_container-lxc7ce10c137d83 id 543
lxc7b4d388e90c0(18) clsact/ingress cil_from_container-lxc7b4d388e90c0 id 652
lxc82f89abec73c(20) clsact/ingress cil_from_container-lxc82f89abec73c id 3369
lxc66a62ac0958c(22) clsact/ingress cil_from_container-lxc66a62ac0958c id 3365
lxc4119e4580d5d(24) clsact/ingress cil_from_container-lxc4119e4580d5d id 3322

flow_dissector:

netfilter:

