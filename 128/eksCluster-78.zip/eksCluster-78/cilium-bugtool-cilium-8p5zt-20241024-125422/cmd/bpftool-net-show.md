xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 572
ens6(5) clsact/ingress cil_from_netdev-ens6 id 581
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 564
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 557
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 513
lxcbdc6a4321e81(12) clsact/ingress cil_from_container-lxcbdc6a4321e81 id 532
lxc3f42bb7a9e26(14) clsact/ingress cil_from_container-lxc3f42bb7a9e26 id 522
lxca5e920fafcf6(18) clsact/ingress cil_from_container-lxca5e920fafcf6 id 630
lxcdc57dec30b41(20) clsact/ingress cil_from_container-lxcdc57dec30b41 id 3287
lxcdd6630e2f07b(22) clsact/ingress cil_from_container-lxcdd6630e2f07b id 3360
lxc5f8235e6e653(24) clsact/ingress cil_from_container-lxc5f8235e6e653 id 3357

flow_dissector:

netfilter:

