IP ADDRESS         LOCAL ENDPOINT INFO
10.78.0.93:0       id=1490  sec_id=5179309 flags=0x0000 ifindex=12  mac=7A:0C:45:1E:35:AD nodemac=5A:DE:2A:E4:D2:2E   
10.78.0.54:0       id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73   
172.31.171.223:0   (localhost)                                                                                        
10.78.0.82:0       id=1257  sec_id=5179309 flags=0x0000 ifindex=14  mac=F2:D1:2C:D3:92:76 nodemac=1E:16:82:A5:9B:75   
172.31.190.99:0    (localhost)                                                                                        
10.78.0.109:0      id=223   sec_id=4     flags=0x0000 ifindex=10  mac=3A:8E:8B:57:34:32 nodemac=EE:13:CA:24:84:BD     
10.78.0.169:0      id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D   
10.78.0.121:0      id=708   sec_id=5229043 flags=0x0000 ifindex=18  mac=22:3B:93:17:D1:C7 nodemac=76:79:12:DB:E3:11   
10.78.0.246:0      (localhost)                                                                                        
10.78.0.120:0      id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62   
