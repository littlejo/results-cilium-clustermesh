KEY             VALUE
AgentLiveness   1954403039799
UTimeOffset     3378461992187500
