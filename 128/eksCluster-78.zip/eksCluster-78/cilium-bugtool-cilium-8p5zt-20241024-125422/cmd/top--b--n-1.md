top - 12:54:24 up 32 min,  0 users,  load average: 0.68, 0.44, 0.23
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 26.7 us, 36.7 sy,  0.0 ni, 36.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    291.1 free,   1048.7 used,   2496.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2606.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 290552  78528 S  26.7   7.4   1:04.33 cilium-+
   3197 root      20   0 1240432  16692  11484 S   6.7   0.4   0:00.02 cilium-+
    396 root      20   0 1229744   8876   2864 S   0.0   0.2   0:04.38 cilium-+
   3187 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3198 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   3224 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3225 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3256 root      20   0    6576   2424   2096 R   0.0   0.1   0:00.00 top
   3275 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
