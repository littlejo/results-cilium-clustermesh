 12:54:24 up 32 min,  0 users,  load average: 0.68, 0.44, 0.23
