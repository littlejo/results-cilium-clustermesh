key: df 00 00 00  value: fe 01 00 00
key: e3 00 00 00  value: d9 0c 00 00
key: c4 02 00 00  value: 71 02 00 00
key: 14 03 00 00  value: 1f 0d 00 00
key: e9 04 00 00  value: 0d 02 00 00
key: 4f 05 00 00  value: 17 0d 00 00
key: d2 05 00 00  value: 1f 02 00 00
Found 7 elements
