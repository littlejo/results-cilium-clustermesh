USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3225  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stats 1
root        3224  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3198  0.0  0.1 1228744 4036 ?        Ssl  12:54   0:00 /bin/gops memstats 1
root        3197  0.0  0.4 1240432 16256 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3244  0.0  0.0   6408  1648 ?        R    12:54   0:00  \_ ps auxfw
root        3245  0.0  0.4 1240432 16256 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root        3187  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3180  0.0  0.0 1228744 3600 ?        Ssl  12:54   0:00 /bin/gops stack 1
root           1  4.3  7.2 1539060 285536 ?      Ssl  12:30   1:04 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.3  0.2 1229744 8876 ?        Sl   12:30   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
