1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:7f:5f:a2:d5:1d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.190.99/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3485sec preferred_lft 3485sec
    inet6 fe80::47f:5fff:fea2:d51d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:7a:32:66:a7:ed brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.171.223/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::47a:32ff:fe66:a7ed/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:e4:0a:35:31:a1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5ce4:aff:fe35:31a1/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:ad:ed:05:2f:13 brd ff:ff:ff:ff:ff:ff
    inet 10.78.0.246/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::f0ad:edff:fe05:2f13/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 22:17:ae:01:d3:99 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2017:aeff:fe01:d399/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:13:ca:24:84:bd brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::ec13:caff:fe24:84bd/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcbdc6a4321e81@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:de:2a:e4:d2:2e brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::58de:2aff:fee4:d22e/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc3f42bb7a9e26@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:16:82:a5:9b:75 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::1c16:82ff:fea5:9b75/64 scope link 
       valid_lft forever preferred_lft forever
18: lxca5e920fafcf6@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:79:12:db:e3:11 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7479:12ff:fedb:e311/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcdc57dec30b41@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:ab:10:76:68:2d brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b0ab:10ff:fe76:682d/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcdd6630e2f07b@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:fb:5e:a9:81:62 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::90fb:5eff:fea9:8162/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc5f8235e6e653@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:fd:be:43:59:73 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::88fd:beff:fe43:5973/64 scope link 
       valid_lft forever preferred_lft forever
