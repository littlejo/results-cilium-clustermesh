alloc: 131.13MB (137496440 bytes)
total-alloc: 3.09GB (3317311904 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 75256865
frees: 73923374
heap-alloc: 131.13MB (137496440 bytes)
heap-sys: 172.70MB (181092352 bytes)
heap-idle: 21.91MB (22978560 bytes)
heap-in-use: 150.79MB (158113792 bytes)
heap-released: 6.21MB (6512640 bytes)
heap-objects: 1333491
stack-in-use: 35.25MB (36962304 bytes)
stack-sys: 35.25MB (36962304 bytes)
stack-mspan-inuse: 2.34MB (2448960 bytes)
stack-mspan-sys: 2.75MB (2888640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 997.60KB (1021545 bytes)
gc-sys: 5.53MB (5803152 bytes)
next-gc: when heap-alloc >= 145.49MB (152562008 bytes)
last-gc: 2024-10-24 12:54:17.74747139 +0000 UTC
gc-pause-total: 19.825312ms
gc-pause: 101582
gc-pause-end: 1729774457747471390
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006325164095672131
enable-gc: true
debug-gc: false
