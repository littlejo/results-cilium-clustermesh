CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode4451202_2428_4560_8274_1fb281c56032.slice/cri-containerd-219462402c9a9bf4702c2ac1c399f2344e0bd5cc62f1306e9a6e0365f7a4c0c1.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode4451202_2428_4560_8274_1fb281c56032.slice/cri-containerd-2e27f26c5c5776c7ebfa33c10d250855f400d8936cf4768065bf75b057e7139c.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf89dbfb7_ee13_4219_b8d7_42f6586b9823.slice/cri-containerd-e18cbec8e7dd8ab4fa3216583c939ae15ec26073d5a87fdbead597689f79476b.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf89dbfb7_ee13_4219_b8d7_42f6586b9823.slice/cri-containerd-6be6f3b52dca8849b5f4cb7c603920b17434d547f7d3fbeaa605763d9da62875.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a69a5f7_3035_4b42_91fb_1b31579d7ee3.slice/cri-containerd-5642a3acd15a62e4559d80efde99224b8e2c97c9561bcaab11a0729d95a66a33.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a69a5f7_3035_4b42_91fb_1b31579d7ee3.slice/cri-containerd-ec04aa652dbb50a61105a9e3836dfb96186c47c498422c10fc751e638dcd9d6b.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod37f9dc62_d9f4_465a_9d70_3ce4689b404e.slice/cri-containerd-eca33d61aaac027f5106eeb2e48984ed59a35d559ab4a932460f764385180708.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod37f9dc62_d9f4_465a_9d70_3ce4689b404e.slice/cri-containerd-baf2d36cd4085b5a9f3c3f29b658d9233044e76c6945825b0523457650cfee38.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54ac2c75_37e2_4d98_af95_39859996f906.slice/cri-containerd-934389901a200758226acb86a5d05e2782e6099436a33a31c2d84ed64c66db5c.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54ac2c75_37e2_4d98_af95_39859996f906.slice/cri-containerd-1341627c00ef840607fb09f85c24c9d061ddb4fc52ccbb786c86f83ad76b23b4.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54ac2c75_37e2_4d98_af95_39859996f906.slice/cri-containerd-26b3d8dd452f426c7f2ce036471313f09ab8b0c3b7844190fd8eb5f69143bb98.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54ac2c75_37e2_4d98_af95_39859996f906.slice/cri-containerd-f84744c98c248d441b61057cf1327ae0156161d37a22692cb338cfcae35c32ea.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod764a8ef2_899d_4659_bec4_e8e9af709adc.slice/cri-containerd-c8814284d5d7c7c86f037ee0d68f6aa151c41ae7cc99e08be8e678c25c072fab.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod764a8ef2_899d_4659_bec4_e8e9af709adc.slice/cri-containerd-a28c384b2a0617926a325eb5e8a5e45fa72c43b7ef9e0233bf5e6aa665b082ec.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod048da8f2_bd0f_43b6_b53d_b8740678b0c2.slice/cri-containerd-90fb8c81fcca9e4241e8ced334ff72a210adfe2719a99b36076bbf153850db09.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod048da8f2_bd0f_43b6_b53d_b8740678b0c2.slice/cri-containerd-bbd7f6e80b8eaf9e43e4458ca64b795f84fcb7b0d6fed008d205d81fbc8c40c9.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcdc25419_28b5_42d7_83dd_dbe119f6bfd7.slice/cri-containerd-f2f3abb91020e06412c078f40416b618d98ccd95dff2e6e9fa5f5ae5c4d6fc50.scope
    718      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcdc25419_28b5_42d7_83dd_dbe119f6bfd7.slice/cri-containerd-3cf465884e63ef97704f0921a375de66e522c31c99109ec1f45b4e08be42a6f7.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcdc25419_28b5_42d7_83dd_dbe119f6bfd7.slice/cri-containerd-583107771adc01a5025c40de135e24c2292c911cd47d72010f7517436e67d9c6.scope
    698      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod940984d4_720d_4a2f_aab4_c704d5f16d9e.slice/cri-containerd-0e1e5571129c83b294b1fdc26cf58f47f6f9a2fc33ec9228675a04373a4f4539.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod940984d4_720d_4a2f_aab4_c704d5f16d9e.slice/cri-containerd-bb75ddb845f431b0e01644c37f54a4d6eb14c765aeeccf640bc0fb85f132ce60.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc74c01fd_bedb_47d6_88e1_53aab7007758.slice/cri-containerd-9642edca111992c0bcdc7790fcbe6e0c222676f195a32dffc66f6727123ba091.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc74c01fd_bedb_47d6_88e1_53aab7007758.slice/cri-containerd-0ef0f280529adbdc9f5b56316028c68682f9eb6d4ee64cae56db88605082ebbe.scope
    714      cgroup_device   multi                                          
