Node 0, zone      DMA     95     82     21     35     12      6      3      1      4      7     43 
Node 0, zone   Normal    526     59     17     27     16      5      1      1      2      1      8 
