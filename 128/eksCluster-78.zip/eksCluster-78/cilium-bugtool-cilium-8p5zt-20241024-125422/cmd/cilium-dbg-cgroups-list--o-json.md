[
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod37f9dc62_d9f4_465a_9d70_3ce4689b404e.slice/cri-containerd-eca33d61aaac027f5106eeb2e48984ed59a35d559ab4a932460f764385180708.scope"
      }
    ],
    "ips": [
      "10.78.0.93"
    ],
    "name": "coredns-cc6ccd49c-s6q7k",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode4451202_2428_4560_8274_1fb281c56032.slice/cri-containerd-2e27f26c5c5776c7ebfa33c10d250855f400d8936cf4768065bf75b057e7139c.scope"
      }
    ],
    "ips": [
      "10.78.0.82"
    ],
    "name": "coredns-cc6ccd49c-7f4xx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod048da8f2_bd0f_43b6_b53d_b8740678b0c2.slice/cri-containerd-90fb8c81fcca9e4241e8ced334ff72a210adfe2719a99b36076bbf153850db09.scope"
      }
    ],
    "ips": [
      "10.78.0.54"
    ],
    "name": "client-974f6c69d-4qm8n",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc74c01fd_bedb_47d6_88e1_53aab7007758.slice/cri-containerd-0ef0f280529adbdc9f5b56316028c68682f9eb6d4ee64cae56db88605082ebbe.scope"
      }
    ],
    "ips": [
      "10.78.0.120"
    ],
    "name": "client2-57cf4468f-24ss8",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54ac2c75_37e2_4d98_af95_39859996f906.slice/cri-containerd-934389901a200758226acb86a5d05e2782e6099436a33a31c2d84ed64c66db5c.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54ac2c75_37e2_4d98_af95_39859996f906.slice/cri-containerd-f84744c98c248d441b61057cf1327ae0156161d37a22692cb338cfcae35c32ea.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod54ac2c75_37e2_4d98_af95_39859996f906.slice/cri-containerd-1341627c00ef840607fb09f85c24c9d061ddb4fc52ccbb786c86f83ad76b23b4.scope"
      }
    ],
    "ips": [
      "10.78.0.121"
    ],
    "name": "clustermesh-apiserver-d5b46c785-qtbkj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcdc25419_28b5_42d7_83dd_dbe119f6bfd7.slice/cri-containerd-3cf465884e63ef97704f0921a375de66e522c31c99109ec1f45b4e08be42a6f7.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcdc25419_28b5_42d7_83dd_dbe119f6bfd7.slice/cri-containerd-f2f3abb91020e06412c078f40416b618d98ccd95dff2e6e9fa5f5ae5c4d6fc50.scope"
      }
    ],
    "ips": [
      "10.78.0.169"
    ],
    "name": "echo-same-node-86d9cc975c-8m24n",
    "namespace": "cilium-test-1"
  }
]

