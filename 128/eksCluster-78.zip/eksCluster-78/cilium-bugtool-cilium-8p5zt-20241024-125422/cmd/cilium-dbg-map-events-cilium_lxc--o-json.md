{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.055Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.058Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.103Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.109Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.140Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.391Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.415Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.472Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.485Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.521Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.094Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.159Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.181Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.215Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.224Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.388Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.394Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.446Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.471Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.496Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.041Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.048Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.071Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.103Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.123Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.146Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.170Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.419Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.434Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.482Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.524Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:53.540Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.032Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.033Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.077Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.107Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.140Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.152Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.176Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.451Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.462Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.504Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.528Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.571Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.969Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.973Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.022Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.035Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.067Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.283Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.315Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.355Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.409Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.426Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.801Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.837Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.843Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.884Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.919Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.930Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.168Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.193Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.234Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.306Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.348Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.770Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.778Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.827Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.829Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.864Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.097Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.108Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.161Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.165Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.200Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.553Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.592Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.596Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.634Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.646Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.672Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.946Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.958Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.003Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.020Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.042Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.441Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.478Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.509Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.530Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.570Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.596Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.809Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.833Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.866Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.901Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.929Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.165Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.199Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.202Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.246Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.259Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.290Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.524Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.550Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.590Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.625Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.656Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.014Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.049Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.056Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.098Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.115Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.138Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.378Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.401Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.425Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.427Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.430Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.116Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.118Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.152Z",
  "value": "id=227   sec_id=5206571 flags=0x0000 ifindex=20  mac=4A:91:FE:EE:E9:4E nodemac=B2:AB:10:76:68:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.179Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.195Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.451Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.457Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:37.144Z",
  "value": "id=1359  sec_id=5221613 flags=0x0000 ifindex=24  mac=4A:8F:E9:39:DB:74 nodemac=8A:FD:BE:43:59:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:37.153Z",
  "value": "id=788   sec_id=5238546 flags=0x0000 ifindex=22  mac=A2:24:B0:2F:94:BC nodemac=92:FB:5E:A9:81:62"
}

