Endpoint ID: 165
Path: /sys/fs/bpf/tc/globals/cilium_policy_00165

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 223
Path: /sys/fs/bpf/tc/globals/cilium_policy_00223

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6233332   77029     0        
Allow    Ingress     1          ANY          NONE         disabled    61908     747       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 227
Path: /sys/fs/bpf/tc/globals/cilium_policy_00227

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    383231   4469      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 708
Path: /sys/fs/bpf/tc/globals/cilium_policy_00708

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6106456   61147     0        
Allow    Ingress     1          ANY          NONE         disabled    5419840   57313     0        
Allow    Egress      0          ANY          NONE         disabled    6537584   64913     0        


Endpoint ID: 788
Path: /sys/fs/bpf/tc/globals/cilium_policy_00788

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1257
Path: /sys/fs/bpf/tc/globals/cilium_policy_01257

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3894     39        0        
Allow    Ingress     1          ANY          NONE         disabled    141082   1624      0        
Allow    Egress      0          ANY          NONE         disabled    19703    218       0        


Endpoint ID: 1359
Path: /sys/fs/bpf/tc/globals/cilium_policy_01359

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1490
Path: /sys/fs/bpf/tc/globals/cilium_policy_01490

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2002     21        0        
Allow    Ingress     1          ANY          NONE         disabled    141544   1631      0        
Allow    Egress      0          ANY          NONE         disabled    19466    215       0        


