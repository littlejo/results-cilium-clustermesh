filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc72a8feed21b7 direct-action not_in_hw id 3306 tag 405f4f3ffe1eaef3 jited 
