key: a2 00 00 00  value: 21 0d 00 00
key: e8 02 00 00  value: 3a 02 00 00
key: 72 04 00 00  value: 39 02 00 00
key: 60 05 00 00  value: 22 0d 00 00
key: e0 07 00 00  value: e5 0c 00 00
key: c7 0a 00 00  value: 83 02 00 00
key: 65 0b 00 00  value: 13 02 00 00
Found 7 elements
