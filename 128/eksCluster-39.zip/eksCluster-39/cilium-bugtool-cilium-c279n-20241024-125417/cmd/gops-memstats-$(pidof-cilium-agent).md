alloc: 71.86MB (75349056 bytes)
total-alloc: 3.08GB (3302748728 bytes)
sys: 223.07MB (233907540 bytes)
lookups: 0
mallocs: 74854125
frees: 74308430
heap-alloc: 71.86MB (75349056 bytes)
heap-sys: 176.88MB (185475072 bytes)
heap-idle: 59.60MB (62496768 bytes)
heap-in-use: 117.28MB (122978304 bytes)
heap-released: 4.63MB (4857856 bytes)
heap-objects: 545695
stack-in-use: 35.09MB (36798464 bytes)
stack-sys: 35.09MB (36798464 bytes)
stack-mspan-inuse: 1.99MB (2088480 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 728.52KB (746009 bytes)
gc-sys: 5.49MB (5760072 bytes)
next-gc: when heap-alloc >= 148.61MB (155831848 bytes)
last-gc: 2024-10-24 12:54:46.648397134 +0000 UTC
gc-pause-total: 17.490036ms
gc-pause: 119201
gc-pause-end: 1729774486648397134
num-gc: 101
num-forced-gc: 0
gc-cpu-fraction: 0.0005776051090011726
enable-gc: true
debug-gc: false
