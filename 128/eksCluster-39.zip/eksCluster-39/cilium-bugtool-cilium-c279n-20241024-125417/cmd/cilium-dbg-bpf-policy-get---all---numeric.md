Endpoint ID: 162
Path: /sys/fs/bpf/tc/globals/cilium_policy_00162

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 537
Path: /sys/fs/bpf/tc/globals/cilium_policy_00537

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 744
Path: /sys/fs/bpf/tc/globals/cilium_policy_00744

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3894     39        0        
Allow    Ingress     1          ANY          NONE         disabled    160168   1834      0        
Allow    Egress      0          ANY          NONE         disabled    20647    232       0        


Endpoint ID: 1138
Path: /sys/fs/bpf/tc/globals/cilium_policy_01138

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6222830   77060     0        
Allow    Ingress     1          ANY          NONE         disabled    66279     803       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1376
Path: /sys/fs/bpf/tc/globals/cilium_policy_01376

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2016
Path: /sys/fs/bpf/tc/globals/cilium_policy_02016

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    379594   4426      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2759
Path: /sys/fs/bpf/tc/globals/cilium_policy_02759

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6103770   61052     0        
Allow    Ingress     1          ANY          NONE         disabled    5008673   52707     0        
Allow    Egress      0          ANY          NONE         disabled    6518708   64794     0        


Endpoint ID: 2917
Path: /sys/fs/bpf/tc/globals/cilium_policy_02917

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2002     21        0        
Allow    Ingress     1          ANY          NONE         disabled    158914   1815      0        
Allow    Egress      0          ANY          NONE         disabled    20325    227       0        


