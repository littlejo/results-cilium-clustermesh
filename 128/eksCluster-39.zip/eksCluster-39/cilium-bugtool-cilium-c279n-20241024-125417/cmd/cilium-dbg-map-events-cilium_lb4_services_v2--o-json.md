{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:36.228Z",
  "value": "1 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:36.228Z",
  "value": "2 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:36.228Z",
  "value": "0 2 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.84.92:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:36.228Z",
  "value": "0 0 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:36.228Z",
  "value": "3 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:36.228Z",
  "value": "0 1 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:36.228Z",
  "value": "4 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:36.228Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:38.783Z",
  "value": "0 0 (4) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:38.783Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:38.783Z",
  "value": "0 0 (3) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:38.783Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.84.92:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:39.888Z",
  "value": "5 0 (2) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.84.92:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:39.888Z",
  "value": "0 1 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:44.476Z",
  "value": "0 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:44.476Z",
  "value": "0 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:44.531Z",
  "value": "6 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:44.531Z",
  "value": "7 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:44.531Z",
  "value": "0 2 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:44.531Z",
  "value": "8 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:44.531Z",
  "value": "9 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:26:44.531Z",
  "value": "0 2 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.60.224:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:35:04.983Z",
  "value": "0 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.60.224:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:35:25.469Z",
  "value": "0 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.60.224:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:35:30.515Z",
  "value": "10 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.60.224:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:35:30.515Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.60.224:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:10.340Z",
  "value": "10 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.60.224:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:10.340Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.60.224:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:16.363Z",
  "value": "10 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.60.224:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:16.363Z",
  "value": "11 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.60.224:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:16.363Z",
  "value": "0 2 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.60.224:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:16.439Z",
  "value": "11 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.60.224:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:16.439Z",
  "value": "10 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.60.224:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:16.439Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.60.224:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:16.913Z",
  "value": "11 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.60.224:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:16.913Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.60.224:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:42:16.914Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.47.107:8080 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:48:20.053Z",
  "value": "0 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.47.107:8080 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:48:32.170Z",
  "value": "0 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.47.107:8080 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:48:32.400Z",
  "value": "12 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.47.107:8080 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:48:32.400Z",
  "value": "0 1 (6) [0x0 0x0]"
}

