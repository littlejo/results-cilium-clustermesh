filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxce1c39a03e24e direct-action not_in_hw id 572 tag 2d075b196101ac5e jited 
