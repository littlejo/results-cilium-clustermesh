IP ADDRESS         LOCAL ENDPOINT INFO
172.31.239.188:0   (localhost)                                                                                        
172.31.230.158:0   (localhost)                                                                                        
10.39.0.95:0       id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49   
10.39.0.237:0      (localhost)                                                                                        
10.39.0.12:0       id=2759  sec_id=2625741 flags=0x0000 ifindex=18  mac=B2:21:2E:76:7E:98 nodemac=52:C7:AC:98:27:53   
10.39.0.228:0      id=744   sec_id=2682966 flags=0x0000 ifindex=14  mac=32:ED:19:92:6A:50 nodemac=92:C4:82:C4:AE:38   
10.39.0.203:0      id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD   
10.39.0.32:0       id=1138  sec_id=4     flags=0x0000 ifindex=10  mac=E2:22:E3:4A:5F:F6 nodemac=D6:C1:99:3C:81:E7     
10.39.0.205:0      id=2917  sec_id=2682966 flags=0x0000 ifindex=12  mac=56:4D:DD:46:ED:AD nodemac=62:7B:7F:8F:0B:A7   
10.39.0.234:0      id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13   
