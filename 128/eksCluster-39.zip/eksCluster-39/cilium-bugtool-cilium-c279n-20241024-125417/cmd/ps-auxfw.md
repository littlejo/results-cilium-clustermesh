USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3187  0.0  0.0 1228744 3780 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root        3185  0.0  0.0 1228744 3656 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3160  0.0  0.0 1228744 3596 ?        Ssl  12:54   0:00 /bin/gops stack 1
root        3153  0.0  0.4 1240432 15916 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3206  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3207  0.0  0.4 1240432 15916 ?       R    12:54   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  4.7  7.5 1538804 294676 ?      Ssl  12:26   1:19 cilium-agent --config-dir=/tmp/cilium/config-map
root         413  0.2  0.2 1229744 8588 ?        Sl   12:26   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
