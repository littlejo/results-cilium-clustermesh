1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:33:0f:40:4e:0f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.239.188/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2036sec preferred_lft 2036sec
    inet6 fe80::833:fff:fe40:4e0f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:69:79:5b:00:13 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.230.158/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::869:79ff:fe5b:13/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:59:05:0c:9c:70 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f059:5ff:fe0c:9c70/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:8d:a1:23:5b:97 brd ff:ff:ff:ff:ff:ff
    inet 10.39.0.237/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::848d:a1ff:fe23:5b97/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 96:35:03:f3:18:fc brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9435:3ff:fef3:18fc/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:c1:99:3c:81:e7 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d4c1:99ff:fe3c:81e7/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcab2236127194@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:7b:7f:8f:0b:a7 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::607b:7fff:fe8f:ba7/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce1c39a03e24e@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:c4:82:c4:ae:38 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::90c4:82ff:fec4:ae38/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcfd394afef60a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:c7:ac:98:27:53 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::50c7:acff:fe98:2753/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcbc56ea0407af@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:1d:1c:9b:d9:13 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::d81d:1cff:fe9b:d913/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc72a8feed21b7@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:f5:ee:42:71:dd brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::f5:eeff:fe42:71dd/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc623a4f3e0be5@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:71:49:1d:01:49 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::4c71:49ff:fe1d:149/64 scope link 
       valid_lft forever preferred_lft forever
