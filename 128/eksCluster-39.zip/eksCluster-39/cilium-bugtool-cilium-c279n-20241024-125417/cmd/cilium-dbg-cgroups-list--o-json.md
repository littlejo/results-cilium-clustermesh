[
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc84dcda2_9d16_4603_a548_cde70273bb50.slice/cri-containerd-d9caa9a52c515019f2da4ea8ecba5d62e39edb698575631b2f2d6f8298bffa03.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc84dcda2_9d16_4603_a548_cde70273bb50.slice/cri-containerd-0944ab17f9accb7d3dc0061855f1dd492aa4930475f06a74bb966ef9c352bf23.scope"
      }
    ],
    "ips": [
      "10.39.0.203"
    ],
    "name": "echo-same-node-86d9cc975c-8ss7n",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29034bf6_8711_4295_abc9_5adadaa6949c.slice/cri-containerd-2cec8e2aff02b3b2d8d881168a9d6e008a17f6c1ab9aafa24bdaeed27b229c49.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29034bf6_8711_4295_abc9_5adadaa6949c.slice/cri-containerd-4f9cd213097c1338d01e5b6fe9e22db6c74c6816c5abda8ed2d9a10422942273.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29034bf6_8711_4295_abc9_5adadaa6949c.slice/cri-containerd-2de68f865301eb99a6a25d82a04b170bf5688d9e04ceeb072ec1f662d7004707.scope"
      }
    ],
    "ips": [
      "10.39.0.12"
    ],
    "name": "clustermesh-apiserver-857ff66456-87ppd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7704,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbce0785d_d655_42c2_82b0_3532535b9459.slice/cri-containerd-5f072a473ec6a4ff7e65b929525e3eb293aa8496eeec5f27ddf90a4830a756e4.scope"
      }
    ],
    "ips": [
      "10.39.0.205"
    ],
    "name": "coredns-cc6ccd49c-qnkp2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod30fb8ca4_1255_4994_a5c1_8dc6c5a7fdd7.slice/cri-containerd-09abc519176d277e09dc0930e1cb9bb3448891c90f02412da8bb9ac8f10b34b6.scope"
      }
    ],
    "ips": [
      "10.39.0.95"
    ],
    "name": "client2-57cf4468f-4vj99",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7620,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod98ddb0df_64bd_4430_89f5_5f1667b39032.slice/cri-containerd-78b1670246e8ca04cfe1aa537c8beb678897173f7a7b48867e2e45f30a4dfb57.scope"
      }
    ],
    "ips": [
      "10.39.0.228"
    ],
    "name": "coredns-cc6ccd49c-pzrs5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda60d88c4_48c5_4300_9f5e_12f629422975.slice/cri-containerd-db7508ceb88e4817d1eff1867c40892cf34318e9bc6a829539babeb405b04e05.scope"
      }
    ],
    "ips": [
      "10.39.0.234"
    ],
    "name": "client-974f6c69d-s6846",
    "namespace": "cilium-test-1"
  }
]

