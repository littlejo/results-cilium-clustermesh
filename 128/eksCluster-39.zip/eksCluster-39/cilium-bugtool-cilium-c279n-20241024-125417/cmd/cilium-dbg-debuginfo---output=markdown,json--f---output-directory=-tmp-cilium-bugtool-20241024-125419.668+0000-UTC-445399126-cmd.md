markdown output at /tmp/cilium-bugtool-20241024-125419.668+0000-UTC-445399126/cmd/cilium-debuginfo-20241024-125450.692+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125419.668+0000-UTC-445399126/cmd/cilium-debuginfo-20241024-125450.692+0000-UTC.json
