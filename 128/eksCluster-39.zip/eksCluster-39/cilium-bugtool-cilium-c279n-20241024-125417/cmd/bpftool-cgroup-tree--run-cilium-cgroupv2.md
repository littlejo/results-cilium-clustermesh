CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9f7362ff_8949_46b5_b90a_b1b8a52b5732.slice/cri-containerd-12465c711284469096369610c0243f6365807d7a54329ff31a27773116e96f87.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9f7362ff_8949_46b5_b90a_b1b8a52b5732.slice/cri-containerd-763c954baae9dc8c8a4be65bc8e1b9aa73d062a8a2d6f472ee1a35ce5215b3bd.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbce0785d_d655_42c2_82b0_3532535b9459.slice/cri-containerd-6bd9a9fc5fa9d68c96032104b8c313d24c512858f518b4ed8753251a8692151e.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbce0785d_d655_42c2_82b0_3532535b9459.slice/cri-containerd-5f072a473ec6a4ff7e65b929525e3eb293aa8496eeec5f27ddf90a4830a756e4.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod98ddb0df_64bd_4430_89f5_5f1667b39032.slice/cri-containerd-ffd7bdcc7fe5ed97922c8e87910d4550adab1a814e3e702d56c132c00e13c9cd.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod98ddb0df_64bd_4430_89f5_5f1667b39032.slice/cri-containerd-78b1670246e8ca04cfe1aa537c8beb678897173f7a7b48867e2e45f30a4dfb57.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4096127c_3923_4d6d_8496_e58e812d64a3.slice/cri-containerd-0a428dd2e5340ab0ebeaa7de7e309504f8fcaf82f92817594fda0e8912dfa7eb.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4096127c_3923_4d6d_8496_e58e812d64a3.slice/cri-containerd-aa0837272305a9c90bb97ad47c99d8e5790bfeb4c90c49ab11e5e25d118b416c.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc84dcda2_9d16_4603_a548_cde70273bb50.slice/cri-containerd-d9caa9a52c515019f2da4ea8ecba5d62e39edb698575631b2f2d6f8298bffa03.scope
    736      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc84dcda2_9d16_4603_a548_cde70273bb50.slice/cri-containerd-4b9bcfc1705ee78e4b98b81cd63d887ab44d9498e925207fbf57da86ffe4372d.scope
    712      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc84dcda2_9d16_4603_a548_cde70273bb50.slice/cri-containerd-0944ab17f9accb7d3dc0061855f1dd492aa4930475f06a74bb966ef9c352bf23.scope
    732      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod004beead_991e_409c_8b6d_68917586109e.slice/cri-containerd-df048cc8c403ad3b161b0f6af5cc5d7e3627c26c8f1c28d1ba87cfec134c2f5c.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod004beead_991e_409c_8b6d_68917586109e.slice/cri-containerd-5a0a757da5a6725655e7192c2a3cac23634be6fe349d18a38274cd7efbfb12cf.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda60d88c4_48c5_4300_9f5e_12f629422975.slice/cri-containerd-a5a73476024f938a8a5c21c45fb8361716d827f9d0c81aee020ac795aceef64a.scope
    716      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda60d88c4_48c5_4300_9f5e_12f629422975.slice/cri-containerd-db7508ceb88e4817d1eff1867c40892cf34318e9bc6a829539babeb405b04e05.scope
    724      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29034bf6_8711_4295_abc9_5adadaa6949c.slice/cri-containerd-4f9cd213097c1338d01e5b6fe9e22db6c74c6816c5abda8ed2d9a10422942273.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29034bf6_8711_4295_abc9_5adadaa6949c.slice/cri-containerd-2cec8e2aff02b3b2d8d881168a9d6e008a17f6c1ab9aafa24bdaeed27b229c49.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29034bf6_8711_4295_abc9_5adadaa6949c.slice/cri-containerd-f865852561f1638cd9706d8038a21249fbd3aa5b68320cf425aace9c0b6d96ab.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29034bf6_8711_4295_abc9_5adadaa6949c.slice/cri-containerd-2de68f865301eb99a6a25d82a04b170bf5688d9e04ceeb072ec1f662d7004707.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod30fb8ca4_1255_4994_a5c1_8dc6c5a7fdd7.slice/cri-containerd-09abc519176d277e09dc0930e1cb9bb3448891c90f02412da8bb9ac8f10b34b6.scope
    728      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod30fb8ca4_1255_4994_a5c1_8dc6c5a7fdd7.slice/cri-containerd-10eb281760598b5b03adf0d1329a5eed34055aeb55294d0b6487647cabfefdfb.scope
    720      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3985ddca_f481_44bf_9734_55623cefc290.slice/cri-containerd-12957d22360fb91ca40742d0c95c77692ad147636931a76a9e97f0f565131696.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3985ddca_f481_44bf_9734_55623cefc290.slice/cri-containerd-317096d19be668d2a9486f7d999e60c9f9f1ad2b3465a536f547f098f0892ba9.scope
    87       cgroup_device   multi                                          
