 12:54:19 up 56 min,  0 users,  load average: 0.66, 0.71, 0.37
