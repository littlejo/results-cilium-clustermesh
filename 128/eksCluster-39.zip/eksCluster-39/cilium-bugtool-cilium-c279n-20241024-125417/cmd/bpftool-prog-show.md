29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T11:58:08+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T11:58:08+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T11:58:09+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T11:58:09+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:09+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:09+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T11:58:09+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T11:58:09+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T11:58:13+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T11:58:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T11:58:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T11:58:26+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:26:40+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
479: sched_cls  name tail_handle_ipv4  tag adb06efae36c9896  gpl
	loaded_at 2024-10-24T12:26:40+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
480: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:26:40+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
481: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:26:40+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
513: sched_cls  name tail_handle_ipv4  tag 246a26e2ba18635e  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 163
515: sched_cls  name tail_handle_ipv4_cont  tag af01fe53e8d8db67  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 167
517: sched_cls  name __send_drop_notify  tag effb79538ff9b0f5  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 169
518: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 171
522: sched_cls  name tail_ipv4_ct_ingress  tag 7699337bd5f6d3ce  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 172
523: sched_cls  name cil_from_container  tag 538288b833c1ba60  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 176
524: sched_cls  name tail_ipv4_ct_egress  tag 06263aa3e877c0cd  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 177
526: sched_cls  name tail_ipv4_to_endpoint  tag f1bf6b77cf851dbf  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 178
529: sched_cls  name tail_handle_ipv4_cont  tag 3d457da771a912b8  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 183
531: sched_cls  name handle_policy  tag d9adcf56197c9dd7  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 180
532: sched_cls  name tail_handle_arp  tag ae3c46221eb84fa9  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 186
534: sched_cls  name tail_ipv4_to_endpoint  tag d54db6b3cb5c8320  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 185
535: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 189
537: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 192
538: sched_cls  name tail_ipv4_ct_ingress  tag 91c129e8f9fe910c  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 191
539: sched_cls  name tail_handle_ipv4_from_host  tag a7937e38ecff2f9d  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 193
540: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 195
542: sched_cls  name __send_drop_notify  tag 66895c79e92206c5  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 197
545: sched_cls  name tail_handle_ipv4_from_host  tag a7937e38ecff2f9d  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 201
546: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 202
548: sched_cls  name __send_drop_notify  tag 66895c79e92206c5  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 204
549: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 205
550: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 207
552: sched_cls  name tail_handle_ipv4_from_host  tag a7937e38ecff2f9d  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 209
555: sched_cls  name __send_drop_notify  tag 66895c79e92206c5  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 212
556: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 213
557: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 215
558: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 216
560: sched_cls  name tail_handle_ipv4_from_host  tag a7937e38ecff2f9d  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 218
563: sched_cls  name __send_drop_notify  tag 66895c79e92206c5  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 221
564: sched_cls  name tail_handle_ipv4  tag ea1e1c4c80691e97  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 194
565: sched_cls  name tail_handle_arp  tag 6f340880cc387513  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 223
566: sched_cls  name cil_from_container  tag 3b5668b6d8703e68  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 126,76
	btf_id 224
567: sched_cls  name __send_drop_notify  tag 36e7b5ac58ae4cee  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 225
568: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 226
569: sched_cls  name handle_policy  tag 4f9b93f549d58158  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,126,82,83,125,41,80,100,39,84,75,40,37,38
	btf_id 227
570: sched_cls  name handle_policy  tag 9ed9d5036c427095  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 228
571: sched_cls  name tail_ipv4_ct_egress  tag 06263aa3e877c0cd  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 230
572: sched_cls  name cil_from_container  tag 2d075b196101ac5e  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 231
573: sched_cls  name __send_drop_notify  tag f1ceb2ef0c90dcf2  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 232
574: sched_cls  name tail_handle_ipv4  tag 921529ca832b517f  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,126
	btf_id 229
575: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,126
	btf_id 233
576: sched_cls  name tail_handle_ipv4_cont  tag f1b1245fd668914c  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,125,41,100,82,83,39,76,74,77,126,40,37,38,81
	btf_id 234
578: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 236
579: sched_cls  name tail_handle_arp  tag 5b6359d9194febba  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,126
	btf_id 237
580: sched_cls  name tail_ipv4_to_endpoint  tag c9930f8270186582  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,125,41,82,83,80,100,39,126,40,37,38
	btf_id 238
581: sched_cls  name tail_ipv4_ct_ingress  tag 7813a47851770a6a  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 239
582: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
585: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
586: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
589: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
590: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
593: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
594: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
597: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
637: sched_cls  name tail_ipv4_to_endpoint  tag c8606f9cce702100  gpl
	loaded_at 2024-10-24T12:42:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 253
638: sched_cls  name __send_drop_notify  tag 67ce82130f6f1b9b  gpl
	loaded_at 2024-10-24T12:42:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 254
639: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 255
641: sched_cls  name tail_ipv4_ct_ingress  tag c3b09d0d15017297  gpl
	loaded_at 2024-10-24T12:42:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 257
642: sched_cls  name tail_ipv4_ct_egress  tag 231c10440cda4add  gpl
	loaded_at 2024-10-24T12:42:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 258
643: sched_cls  name handle_policy  tag 40dd40f77885c8d7  gpl
	loaded_at 2024-10-24T12:42:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 259
644: sched_cls  name cil_from_container  tag 84f5c55a78294920  gpl
	loaded_at 2024-10-24T12:42:10+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 260
645: sched_cls  name tail_handle_arp  tag 739e29604ea3fd65  gpl
	loaded_at 2024-10-24T12:42:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 261
646: sched_cls  name tail_handle_ipv4_cont  tag 0ce4bc7019f7ce36  gpl
	loaded_at 2024-10-24T12:42:10+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 262
647: sched_cls  name tail_handle_ipv4  tag fbcea4eca6f836f7  gpl
	loaded_at 2024-10-24T12:42:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 263
648: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
651: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
664: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
667: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
668: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
671: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
709: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
712: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
713: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
716: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
717: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
720: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
721: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
724: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
725: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
728: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
729: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
732: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
733: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
736: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3289: sched_cls  name tail_handle_arp  tag f7d960b867e207c2  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,632
	btf_id 3085
3290: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,632
	btf_id 3086
3293: sched_cls  name tail_handle_ipv4_cont  tag b9fb569070f4e77e  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,631,41,154,82,83,39,76,74,77,632,40,37,38,81
	btf_id 3087
3294: sched_cls  name __send_drop_notify  tag 83bca89aa8f7962c  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3092
3297: sched_cls  name tail_ipv4_ct_ingress  tag 69c33607f3951aff  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,632,82,83,631,84
	btf_id 3095
3301: sched_cls  name handle_policy  tag eed8456d51460a7e  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,632,82,83,631,41,80,154,39,84,75,40,37,38
	btf_id 3096
3305: sched_cls  name tail_handle_ipv4  tag 477deba941f8e934  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,632
	btf_id 3102
3306: sched_cls  name cil_from_container  tag 405f4f3ffe1eaef3  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 632,76
	btf_id 3104
3307: sched_cls  name tail_ipv4_to_endpoint  tag 57c6ab5aafd3d1f3  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,631,41,82,83,80,154,39,632,40,37,38
	btf_id 3105
3309: sched_cls  name tail_ipv4_ct_egress  tag 89a397239a62ad45  gpl
	loaded_at 2024-10-24T12:51:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,632,82,83,631,84
	btf_id 3107
3344: sched_cls  name cil_from_container  tag ea23cc455e2a7872  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 641,76
	btf_id 3145
3345: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,643
	btf_id 3147
3346: sched_cls  name tail_ipv4_ct_egress  tag 1baf86ec31436283  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,641,82,83,642,84
	btf_id 3148
3347: sched_cls  name tail_handle_ipv4_cont  tag a4332e209dde9b5d  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,644,41,157,82,83,39,76,74,77,643,40,37,38,81
	btf_id 3149
3348: sched_cls  name tail_ipv4_ct_ingress  tag dd0d6ee0016fcb56  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,641,82,83,642,84
	btf_id 3151
3349: sched_cls  name tail_handle_ipv4  tag fda92a7c0f80187c  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,643
	btf_id 3150
3350: sched_cls  name tail_handle_arp  tag a11f2738283e368d  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,643
	btf_id 3153
3351: sched_cls  name __send_drop_notify  tag b72a38ff7671c309  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3154
3352: sched_cls  name cil_from_container  tag 788b602f2c0bb4aa  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 643,76
	btf_id 3155
3353: sched_cls  name tail_handle_ipv4_cont  tag 9fa78ad14b42499b  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,642,41,151,82,83,39,76,74,77,641,40,37,38,81
	btf_id 3152
3354: sched_cls  name tail_handle_arp  tag d1813c523211c379  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,641
	btf_id 3157
3355: sched_cls  name tail_ipv4_to_endpoint  tag 74ab8b26c01aa795  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,642,41,82,83,80,151,39,641,40,37,38
	btf_id 3158
3356: sched_cls  name __send_drop_notify  tag 3aff3f5863fe890e  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3159
3357: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,641
	btf_id 3160
3359: sched_cls  name tail_ipv4_ct_egress  tag c57a387baf93cc86  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,643,82,83,644,84
	btf_id 3156
3361: sched_cls  name handle_policy  tag 1e4a0af44b7bed88  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,643,82,83,644,41,80,157,39,84,75,40,37,38
	btf_id 3164
3362: sched_cls  name handle_policy  tag 1ea15b34eb9cd259  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,641,82,83,642,41,80,151,39,84,75,40,37,38
	btf_id 3162
3363: sched_cls  name tail_handle_ipv4  tag a39e0efcd363ad05  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,641
	btf_id 3165
3364: sched_cls  name tail_ipv4_to_endpoint  tag 785d56560bcfa534  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,644,41,82,83,80,157,39,643,40,37,38
	btf_id 3166
3365: sched_cls  name tail_ipv4_ct_ingress  tag 6f3741e99a158ac9  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,643,82,83,644,84
	btf_id 3167
