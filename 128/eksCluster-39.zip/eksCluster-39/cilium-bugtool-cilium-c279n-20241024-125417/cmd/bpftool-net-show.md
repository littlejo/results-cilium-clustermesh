xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 550
ens6(5) clsact/ingress cil_from_netdev-ens6 id 558
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 546
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 540
cilium_host(7) clsact/egress cil_from_host-cilium_host id 537
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 566
lxcab2236127194(12) clsact/ingress cil_from_container-lxcab2236127194 id 523
lxce1c39a03e24e(14) clsact/ingress cil_from_container-lxce1c39a03e24e id 572
lxcfd394afef60a(18) clsact/ingress cil_from_container-lxcfd394afef60a id 644
lxcbc56ea0407af(20) clsact/ingress cil_from_container-lxcbc56ea0407af id 3344
lxc72a8feed21b7(22) clsact/ingress cil_from_container-lxc72a8feed21b7 id 3306
lxc623a4f3e0be5(24) clsact/ingress cil_from_container-lxc623a4f3e0be5 id 3352

flow_dissector:

netfilter:

