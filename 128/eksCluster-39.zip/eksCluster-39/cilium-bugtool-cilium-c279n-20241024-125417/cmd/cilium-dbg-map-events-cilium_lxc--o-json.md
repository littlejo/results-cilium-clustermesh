{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.567Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:37.598Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.191Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.196Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.242Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.264Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.285Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.543Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.553Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.620Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.623Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:40.672Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.278Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.335Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.341Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.382Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.405Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.632Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.642Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.691Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.731Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.761Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.264Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.305Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.321Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.360Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.376Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.398Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.619Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.627Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.679Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.693Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.732Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.289Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.294Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.407Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.447Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.450Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.494Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.517Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.670Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.675Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.730Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.730Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.779Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.198Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.239Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.253Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.302Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.313Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.340Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.573Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.598Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.651Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.661Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.695Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.110Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.145Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.164Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.200Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.212Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.249Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.568Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.616Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.652Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.693Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.697Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.075Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.117Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.135Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.176Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.184Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.215Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.452Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.478Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.501Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.545Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.576Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.032Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.057Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.078Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.108Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.130Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.453Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.480Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.551Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.559Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.612Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.964Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.003Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.012Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.062Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.071Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.101Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.335Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.338Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.389Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.394Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.442Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.750Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.790Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.792Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.834Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.894Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.895Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.145Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.146Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.201Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.207Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.308Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.651Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.651Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.708Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.719Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.762Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.988Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.001Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.017Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.051Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.792Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.793Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.846Z",
  "value": "id=2016  sec_id=2646566 flags=0x0000 ifindex=22  mac=DA:87:D2:5B:1D:BD nodemac=02:F5:EE:42:71:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.854Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.884Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.175Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.188Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.929Z",
  "value": "id=1376  sec_id=2671313 flags=0x0000 ifindex=20  mac=4A:47:DB:8B:30:4E nodemac=DA:1D:1C:9B:D9:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.936Z",
  "value": "id=162   sec_id=2636403 flags=0x0000 ifindex=24  mac=22:8F:B2:CC:93:44 nodemac=4E:71:49:1D:01:49"
}

