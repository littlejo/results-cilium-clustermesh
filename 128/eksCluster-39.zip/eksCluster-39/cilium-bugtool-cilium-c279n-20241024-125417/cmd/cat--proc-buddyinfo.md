Node 0, zone      DMA    305    129     37      1    167    124     29     10      4      6     29 
Node 0, zone   Normal    280    128     17     20     28     17      4      2      3      5      5 
