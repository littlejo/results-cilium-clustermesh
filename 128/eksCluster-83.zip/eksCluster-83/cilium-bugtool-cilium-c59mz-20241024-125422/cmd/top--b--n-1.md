top - 12:54:24 up 31 min,  0 users,  load average: 0.96, 0.69, 0.38
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 13.8 us, 55.2 sy,  0.0 ni, 27.6 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   3836.2 total,    298.7 free,   1038.9 used,   2498.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2616.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 287356  77816 S  20.0   7.3   1:13.87 cilium-+
   3021 root      20   0 1240176  15696  10896 S   6.7   0.4   0:00.03 cilium-+
    395 root      20   0 1229744   8896   2864 S   0.0   0.2   0:04.47 cilium-+
   3050 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
   3073 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3086 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
