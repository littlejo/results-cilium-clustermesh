filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc4c4a903c3f25 direct-action not_in_hw id 576 tag 91f4784dc75ed454 jited 
