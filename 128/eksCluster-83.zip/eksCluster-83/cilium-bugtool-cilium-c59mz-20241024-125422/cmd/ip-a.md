1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:8f:a2:62:a9:9d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.242.249/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3497sec preferred_lft 3497sec
    inet6 fe80::88f:a2ff:fe62:a99d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:72:dd:79:67:d9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.235.206/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::872:ddff:fe79:67d9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:9a:e6:b2:cd:d5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f49a:e6ff:feb2:cdd5/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:c0:99:43:d3:f4 brd ff:ff:ff:ff:ff:ff
    inet 10.83.0.222/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::30c0:99ff:fe43:d3f4/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 36:dd:ad:bb:cb:06 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::34dd:adff:febb:cb06/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:6b:e1:7d:1a:b2 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a86b:e1ff:fe7d:1ab2/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc29cc0080d570@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:2b:8f:46:f8:9a brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::682b:8fff:fe46:f89a/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc4c4a903c3f25@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:63:7f:16:b9:05 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::c463:7fff:fe16:b905/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc1c9c3d2c0d4a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:e4:d6:a1:d6:ff brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a8e4:d6ff:fea1:d6ff/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc20ba33c4e28a@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:79:2e:b5:15:3e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4879:2eff:feb5:153e/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc8f9207652b82@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:17:20:cb:8e:62 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::1417:20ff:fecb:8e62/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcbaa264a179be@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:49:a6:e0:d3:8c brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::a449:a6ff:fee0:d38c/64 scope link 
       valid_lft forever preferred_lft forever
