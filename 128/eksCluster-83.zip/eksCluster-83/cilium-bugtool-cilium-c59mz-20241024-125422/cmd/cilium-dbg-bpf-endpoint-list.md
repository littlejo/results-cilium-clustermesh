IP ADDRESS         LOCAL ENDPOINT INFO
10.83.0.38:0       id=1686  sec_id=4     flags=0x0000 ifindex=10  mac=C6:CD:1D:A1:D2:EA nodemac=AA:6B:E1:7D:1A:B2     
10.83.0.34:0       id=2497  sec_id=5540297 flags=0x0000 ifindex=12  mac=7E:33:A1:41:E4:C6 nodemac=6A:2B:8F:46:F8:9A   
10.83.0.62:0       id=455   sec_id=5508177 flags=0x0000 ifindex=18  mac=82:66:AA:AD:86:CD nodemac=AA:E4:D6:A1:D6:FF   
10.83.0.95:0       id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62   
10.83.0.148:0      id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E   
10.83.0.253:0      id=2234  sec_id=5540297 flags=0x0000 ifindex=14  mac=D2:33:7B:1A:A9:9E nodemac=C6:63:7F:16:B9:05   
10.83.0.132:0      id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C   
172.31.235.206:0   (localhost)                                                                                        
172.31.242.249:0   (localhost)                                                                                        
10.83.0.222:0      (localhost)                                                                                        
