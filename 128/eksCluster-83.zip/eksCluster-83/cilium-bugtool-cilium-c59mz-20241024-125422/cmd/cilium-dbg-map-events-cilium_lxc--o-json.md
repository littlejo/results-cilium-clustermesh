{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.753Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:43.791Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.403Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.417Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.504Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.513Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.558Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.800Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.819Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.877Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.923Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.947Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.533Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.550Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.594Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.632Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.635Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.866Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.873Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.944Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.946Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.988Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.614Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.622Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.654Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.660Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.712Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.721Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.780Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.031Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.046Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.092Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.130Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.141Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.742Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.751Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.781Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.817Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.828Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.860Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.883Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.131Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.142Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.189Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.193Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.238Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.667Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.674Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.721Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.743Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.761Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.109Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.115Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.203Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.240Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:05.243Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.638Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.648Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.696Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.714Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.740Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.756Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.988Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.017Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.071Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.080Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.110Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.499Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.538Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.540Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.590Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.600Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.627Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.879Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.886Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.939Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.961Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.983Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.450Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.524Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.567Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.567Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.571Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.819Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.844Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.869Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.921Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:14.927Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.419Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.420Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.479Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.488Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.519Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.744Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.752Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.794Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.824Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:17.839Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.131Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.171Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.176Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.224Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.236Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.261Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.558Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.564Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.646Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.689Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.722Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.990Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.035Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.042Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.092Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.097Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.131Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.360Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.369Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.384Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.416Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.098Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.101Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.133Z",
  "value": "id=1830  sec_id=5511223 flags=0x0000 ifindex=24  mac=EE:B0:CF:76:10:64 nodemac=A6:49:A6:E0:D3:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.171Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.182Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.500Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:29.504Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:38.267Z",
  "value": "id=749   sec_id=5568487 flags=0x0000 ifindex=22  mac=8E:3F:BE:2D:8F:5E nodemac=16:17:20:CB:8E:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:38.306Z",
  "value": "id=348   sec_id=5511752 flags=0x0000 ifindex=20  mac=CE:9D:9D:C4:0E:FD nodemac=4A:79:2E:B5:15:3E"
}

