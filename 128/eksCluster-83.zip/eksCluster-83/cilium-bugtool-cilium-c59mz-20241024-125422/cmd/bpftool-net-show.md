xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 555
ens6(5) clsact/ingress cil_from_netdev-ens6 id 562
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 549
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 544
cilium_host(7) clsact/egress cil_from_host-cilium_host id 541
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 587
lxc29cc0080d570(12) clsact/ingress cil_from_container-lxc29cc0080d570 id 522
lxc4c4a903c3f25(14) clsact/ingress cil_from_container-lxc4c4a903c3f25 id 576
lxc1c9c3d2c0d4a(18) clsact/ingress cil_from_container-lxc1c9c3d2c0d4a id 651
lxc20ba33c4e28a(20) clsact/ingress cil_from_container-lxc20ba33c4e28a id 3362
lxc8f9207652b82(22) clsact/ingress cil_from_container-lxc8f9207652b82 id 3368
lxcbaa264a179be(24) clsact/ingress cil_from_container-lxcbaa264a179be id 3310

flow_dissector:

netfilter:

