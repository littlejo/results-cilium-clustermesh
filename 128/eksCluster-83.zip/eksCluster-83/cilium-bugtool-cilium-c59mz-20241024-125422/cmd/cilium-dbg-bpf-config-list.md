KEY             VALUE
AgentLiveness   1916437509893
UTimeOffset     3378462011718750
