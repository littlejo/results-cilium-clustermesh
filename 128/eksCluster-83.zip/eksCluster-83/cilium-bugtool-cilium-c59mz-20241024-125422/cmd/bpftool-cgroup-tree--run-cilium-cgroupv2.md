CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc975711c_e868_4aff_986e_f5e318aa830e.slice/cri-containerd-fa26017c7f0afa5930ef7e29d3cfabb9c244aa83fb144737e39e441e817935e8.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc975711c_e868_4aff_986e_f5e318aa830e.slice/cri-containerd-85fa33913b7c50dad3e42a49063f812ba0964c5acdfa85574767c59f4e90b09f.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podebb4032a_1dd4_4342_9998_b6a50abd5856.slice/cri-containerd-70fa2159e16e8dffdb081ee180d87c4dd312047b28ba0c5329aabfcfafb64d80.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podebb4032a_1dd4_4342_9998_b6a50abd5856.slice/cri-containerd-de9996dbd9a08792bf1d2dcd5e1b3ddffe5061b2db1a25be2149a6464ee638d3.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod09fed711_985b_4f72_bb4c_607e4b714912.slice/cri-containerd-8daa8394b25d0d3111611c144c3b50f48b77389c3fd8f3f1dd784ad6dc4de34c.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod09fed711_985b_4f72_bb4c_607e4b714912.slice/cri-containerd-2578b89a492204f46708fa0eb97e2701761d297d537160e23776d3ab55aaf148.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a277a7e_d4f8_4b34_9c85_49f1cd3d325f.slice/cri-containerd-4b2d2a4673914d0f0522f349b1dad98fdf80ad1c50141c4a576407320d0814e1.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a277a7e_d4f8_4b34_9c85_49f1cd3d325f.slice/cri-containerd-0c3c1e415afdc34456dbf0500a1a588f9278924cea896942bc957c54192a05a0.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podae1687a7_969d_4314_99cf_47c02f09bdfe.slice/cri-containerd-987a501af505fa382f9e855d39ba7b63dbc6751f03c21e37868b038cbe02e16f.scope
    726      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podae1687a7_969d_4314_99cf_47c02f09bdfe.slice/cri-containerd-3338109e3e2b808c167fe55289d125bed8d10cb67ebc549a8c9655fe35d0e7b5.scope
    738      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podae1687a7_969d_4314_99cf_47c02f09bdfe.slice/cri-containerd-fb43398f7503f4747030e51780077e80a4f9a71d2add485693d5fc9e0ac44b23.scope
    742      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7999dfbb_72e3_4f2c_a250_9d6db20550e4.slice/cri-containerd-28cc8f3a4471f6fc36b63881d37434e775d21189c57690772c3b7c698ad73ccc.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7999dfbb_72e3_4f2c_a250_9d6db20550e4.slice/cri-containerd-2874b803a9b68949c0a7f633e159395d46a95ced9ef49c07ba8ffe275e23832e.scope
    730      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aee2efe_4dce_44f8_9deb_c401946eddea.slice/cri-containerd-9996630e807abb52b6101998086a3fc7ca0bbd2ae5d5c5a99b15c91bd00da2d4.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aee2efe_4dce_44f8_9deb_c401946eddea.slice/cri-containerd-e634ac7d04684f158941864aa57d17f2dff0041b9998bd26bc900420fee76aff.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aee2efe_4dce_44f8_9deb_c401946eddea.slice/cri-containerd-901015b107fc766959446466cf5c439e244070bf509221c4d11dc038c388119a.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aee2efe_4dce_44f8_9deb_c401946eddea.slice/cri-containerd-e071e33338a57d2cc77a5ca61af93d7933bf91760ed134e818c0f8c07b6af06e.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2e68ed4c_d515_48cc_8b72_4dca46d842d6.slice/cri-containerd-0ff315375633bd3b4bb4fe03fcfd545a0edcadc236edcceb9b10c954d316f11c.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2e68ed4c_d515_48cc_8b72_4dca46d842d6.slice/cri-containerd-33149d92eae776bf4e0c7aea7f3ef3fda2a1a61e916be9acad3ba4949b582ee9.scope
    734      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a7add64_0f0b_44d2_b0fb_53547ef5099f.slice/cri-containerd-d95ed68029bd397a0606836e6fbc226962405040f42d578bc73e89971f71d10d.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a7add64_0f0b_44d2_b0fb_53547ef5099f.slice/cri-containerd-2cc365d5f0e3fb171479566e0151800f4398ad55e5f25f077a045637ba93fe67.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5be1e09b_9cad_49a4_ac6a_ba98158b5f48.slice/cri-containerd-3042dabee47fae9d51c8e3e92fe057ee069094abb38c32ac9155484cd8fb889f.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5be1e09b_9cad_49a4_ac6a_ba98158b5f48.slice/cri-containerd-636fe74b226711d4b305306472ed1ceb5a53f1e880cf7aaf38e01341bb3eab65.scope
    109      cgroup_device   multi                                          
