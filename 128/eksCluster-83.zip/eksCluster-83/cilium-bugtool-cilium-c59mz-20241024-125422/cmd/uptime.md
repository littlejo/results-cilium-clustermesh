 12:54:24 up 31 min,  0 users,  load average: 0.96, 0.69, 0.38
