markdown output at /tmp/cilium-bugtool-20241024-125424.084+0000-UTC-1601781873/cmd/cilium-debuginfo-20241024-125425.578+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125424.084+0000-UTC-1601781873/cmd/cilium-debuginfo-20241024-125425.578+0000-UTC.json
