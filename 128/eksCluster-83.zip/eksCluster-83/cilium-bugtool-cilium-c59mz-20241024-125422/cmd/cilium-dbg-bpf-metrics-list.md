REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     124614    10083010    677    bpf_overlay.c
Interface                   INGRESS     621259    241583842   1132   bpf_host.c
Policy denied               EGRESS      61        4514        1325   bpf_lxc.c
Policy denied               INGRESS     15        1182        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      121588    9851551     53     encap.h
Success                     EGRESS      140508    18242175    1308   bpf_lxc.c
Success                     EGRESS      48504     3927769     1694   bpf_host.c
Success                     EGRESS      7800      1295113     86     l3.h
Success                     INGRESS     162285    18340469    86     l3.h
Success                     INGRESS     246826    25833293    235    trace.h
Unsupported L3 protocol     EGRESS      71        5354        1492   bpf_lxc.c
