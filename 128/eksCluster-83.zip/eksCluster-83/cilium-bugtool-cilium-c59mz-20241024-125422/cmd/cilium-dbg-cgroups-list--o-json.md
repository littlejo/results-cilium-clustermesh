[
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7999dfbb_72e3_4f2c_a250_9d6db20550e4.slice/cri-containerd-2874b803a9b68949c0a7f633e159395d46a95ced9ef49c07ba8ffe275e23832e.scope"
      }
    ],
    "ips": [
      "10.83.0.148"
    ],
    "name": "client-974f6c69d-wjnhs",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podebb4032a_1dd4_4342_9998_b6a50abd5856.slice/cri-containerd-70fa2159e16e8dffdb081ee180d87c4dd312047b28ba0c5329aabfcfafb64d80.scope"
      }
    ],
    "ips": [
      "10.83.0.253"
    ],
    "name": "coredns-cc6ccd49c-7fn8w",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2e68ed4c_d515_48cc_8b72_4dca46d842d6.slice/cri-containerd-33149d92eae776bf4e0c7aea7f3ef3fda2a1a61e916be9acad3ba4949b582ee9.scope"
      }
    ],
    "ips": [
      "10.83.0.95"
    ],
    "name": "client2-57cf4468f-5bct4",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a277a7e_d4f8_4b34_9c85_49f1cd3d325f.slice/cri-containerd-4b2d2a4673914d0f0522f349b1dad98fdf80ad1c50141c4a576407320d0814e1.scope"
      }
    ],
    "ips": [
      "10.83.0.34"
    ],
    "name": "coredns-cc6ccd49c-wrtxq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podae1687a7_969d_4314_99cf_47c02f09bdfe.slice/cri-containerd-fb43398f7503f4747030e51780077e80a4f9a71d2add485693d5fc9e0ac44b23.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podae1687a7_969d_4314_99cf_47c02f09bdfe.slice/cri-containerd-3338109e3e2b808c167fe55289d125bed8d10cb67ebc549a8c9655fe35d0e7b5.scope"
      }
    ],
    "ips": [
      "10.83.0.132"
    ],
    "name": "echo-same-node-86d9cc975c-llmmr",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aee2efe_4dce_44f8_9deb_c401946eddea.slice/cri-containerd-901015b107fc766959446466cf5c439e244070bf509221c4d11dc038c388119a.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aee2efe_4dce_44f8_9deb_c401946eddea.slice/cri-containerd-9996630e807abb52b6101998086a3fc7ca0bbd2ae5d5c5a99b15c91bd00da2d4.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4aee2efe_4dce_44f8_9deb_c401946eddea.slice/cri-containerd-e071e33338a57d2cc77a5ca61af93d7933bf91760ed134e818c0f8c07b6af06e.scope"
      }
    ],
    "ips": [
      "10.83.0.62"
    ],
    "name": "clustermesh-apiserver-c59f74474-mdfp9",
    "namespace": "kube-system"
  }
]

