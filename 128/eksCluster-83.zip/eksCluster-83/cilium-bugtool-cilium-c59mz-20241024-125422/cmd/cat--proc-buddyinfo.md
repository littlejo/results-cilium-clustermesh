Node 0, zone      DMA     39     50     14     14     14     11      9      2      1      4     43 
Node 0, zone   Normal    219     37      1      2      3      0      2      2      3      4      7 
