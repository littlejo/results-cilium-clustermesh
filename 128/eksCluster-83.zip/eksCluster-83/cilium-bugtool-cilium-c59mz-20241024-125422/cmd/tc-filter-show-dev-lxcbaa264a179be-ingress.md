filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcbaa264a179be direct-action not_in_hw id 3310 tag 6f9c794e7c8021fc jited 
