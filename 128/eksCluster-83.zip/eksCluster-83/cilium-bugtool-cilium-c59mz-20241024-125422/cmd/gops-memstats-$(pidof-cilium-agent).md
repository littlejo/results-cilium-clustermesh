alloc: 84.51MB (88613680 bytes)
total-alloc: 2.96GB (3174545024 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 73330309
frees: 72538172
heap-alloc: 84.51MB (88613680 bytes)
heap-sys: 172.66MB (181043200 bytes)
heap-idle: 51.51MB (54009856 bytes)
heap-in-use: 121.15MB (127033344 bytes)
heap-released: 11.62MB (12189696 bytes)
heap-objects: 792137
stack-in-use: 35.34MB (37060608 bytes)
stack-sys: 35.34MB (37060608 bytes)
stack-mspan-inuse: 2.06MB (2157280 bytes)
stack-mspan-sys: 2.80MB (2937600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 979.05KB (1002545 bytes)
gc-sys: 5.47MB (5735496 bytes)
next-gc: when heap-alloc >= 147.25MB (154405128 bytes)
last-gc: 2024-10-24 12:54:03.704562206 +0000 UTC
gc-pause-total: 16.746712ms
gc-pause: 85128
gc-pause-end: 1729774443704562206
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006302391687413583
enable-gc: true
debug-gc: false
