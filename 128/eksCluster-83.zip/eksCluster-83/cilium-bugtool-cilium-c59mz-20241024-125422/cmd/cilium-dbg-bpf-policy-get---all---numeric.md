Endpoint ID: 209
Path: /sys/fs/bpf/tc/globals/cilium_policy_00209

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 348
Path: /sys/fs/bpf/tc/globals/cilium_policy_00348

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 455
Path: /sys/fs/bpf/tc/globals/cilium_policy_00455

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5501446   57075     0        
Allow    Ingress     1          ANY          NONE         disabled    5049378   53161     0        
Allow    Egress      0          ANY          NONE         disabled    6207993   63235     0        


Endpoint ID: 749
Path: /sys/fs/bpf/tc/globals/cilium_policy_00749

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1686
Path: /sys/fs/bpf/tc/globals/cilium_policy_01686

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6200774   76782     0        
Allow    Ingress     1          ANY          NONE         disabled    56239     681       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1830
Path: /sys/fs/bpf/tc/globals/cilium_policy_01830

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    354566   4137      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2234
Path: /sys/fs/bpf/tc/globals/cilium_policy_02234

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    201887   1823      0        
Allow    Ingress     1          ANY          NONE         disabled    135145   1551      0        
Allow    Egress      0          ANY          NONE         disabled    65125    640       0        


Endpoint ID: 2497
Path: /sys/fs/bpf/tc/globals/cilium_policy_02497

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    203763   1839      0        
Allow    Ingress     1          ANY          NONE         disabled    135460   1560      0        
Allow    Egress      0          ANY          NONE         disabled    65271    645       0        


