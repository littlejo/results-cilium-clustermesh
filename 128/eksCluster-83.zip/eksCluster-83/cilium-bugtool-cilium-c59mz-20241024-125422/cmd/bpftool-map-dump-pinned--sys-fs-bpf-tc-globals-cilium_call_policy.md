key: 5c 01 00 00  value: 26 0d 00 00
key: c7 01 00 00  value: 85 02 00 00
key: ed 02 00 00  value: 24 0d 00 00
key: 96 06 00 00  value: 45 02 00 00
key: 26 07 00 00  value: ec 0c 00 00
key: ba 08 00 00  value: 35 02 00 00
key: c1 09 00 00  value: 19 02 00 00
Found 7 elements
