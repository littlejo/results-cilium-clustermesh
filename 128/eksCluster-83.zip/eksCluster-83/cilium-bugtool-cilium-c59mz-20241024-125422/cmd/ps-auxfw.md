USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3021  0.0  0.3 1240176 15696 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3038  0.0  0.0   6408  1632 ?        R    12:54   0:00  \_ ps auxfw
root        3040  0.0  0.0    368     4 ?        R    12:54   0:00  \_ hostname
root           1  5.1  7.2 1539060 286120 ?      Ssl  12:30   1:13 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.3  0.2 1229744 8896 ?        Sl   12:30   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
