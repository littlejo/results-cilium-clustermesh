markdown output at /tmp/cilium-bugtool-20241024-125416.63+0000-UTC-914659198/cmd/cilium-debuginfo-20241024-125447.498+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125416.63+0000-UTC-914659198/cmd/cilium-debuginfo-20241024-125447.498+0000-UTC.json
