xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 568
ens6(5) clsact/ingress cil_from_netdev-ens6 id 579
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 561
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 555
cilium_host(7) clsact/egress cil_from_host-cilium_host id 554
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 516
lxc635a178febee(12) clsact/ingress cil_from_container-lxc635a178febee id 532
lxcc9ecc81880ad(14) clsact/ingress cil_from_container-lxcc9ecc81880ad id 512
lxca34e1be851b5(18) clsact/ingress cil_from_container-lxca34e1be851b5 id 622
lxcf2683e3fb418(20) clsact/ingress cil_from_container-lxcf2683e3fb418 id 3349
lxcc7261f74c8c1(22) clsact/ingress cil_from_container-lxcc7261f74c8c1 id 3293
lxcdb7b07b94339(24) clsact/ingress cil_from_container-lxcdb7b07b94339 id 3343

flow_dissector:

netfilter:

