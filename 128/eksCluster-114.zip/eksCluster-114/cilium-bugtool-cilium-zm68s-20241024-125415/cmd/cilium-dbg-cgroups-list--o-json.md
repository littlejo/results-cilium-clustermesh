[
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod02705c2e_2f0c_4c41_8441_a6ac85c9026b.slice/cri-containerd-e0a4f20a7095896a97ec7c67ddb907d29bfb6b120b58d36e0c85d2d00725d1df.scope"
      }
    ],
    "ips": [
      "10.114.0.185"
    ],
    "name": "coredns-cc6ccd49c-v7pqt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod022bc25f_31b3_4ae0_b1f0_c06572af58d9.slice/cri-containerd-8163bfd3af7e1006484876c7c4d712ed886febc54f788263b9976dcf055c1089.scope"
      }
    ],
    "ips": [
      "10.114.0.162"
    ],
    "name": "coredns-cc6ccd49c-njlxl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod894f079d_3711_4b10_a8df_d0385007df84.slice/cri-containerd-6f4d021419a7a1150bef9c03c8cdcf634f51380b9e21c60911072f7fcd956324.scope"
      }
    ],
    "ips": [
      "10.114.0.232"
    ],
    "name": "client-974f6c69d-7t6p6",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d1a8dc8_334b_4fee_b513_fcef18aa3e5e.slice/cri-containerd-8f54615c6bd621b12ba79d7e85bf0484621f176a3d0a74f99b1028407171d9d6.scope"
      }
    ],
    "ips": [
      "10.114.0.143"
    ],
    "name": "client2-57cf4468f-mfppx",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod588973e7_6e92_4339_b8d2_7f1c72f1f45c.slice/cri-containerd-5edd9d138eb8d59ee47aa4e59c8be0d1b8b36ef59716e850db929018cf67d1c0.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod588973e7_6e92_4339_b8d2_7f1c72f1f45c.slice/cri-containerd-1a41a4f5aecf8b464c374150a68f230eed11fc540cc50272094cecdb6bf9876b.scope"
      }
    ],
    "ips": [
      "10.114.0.79"
    ],
    "name": "echo-same-node-86d9cc975c-td2p5",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podadc3a404_9370_43dc_8abe_80ca99d18544.slice/cri-containerd-c59eb394af2aec2fad10fd2bbef49d482e36d65e397146242bc253714b24228a.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podadc3a404_9370_43dc_8abe_80ca99d18544.slice/cri-containerd-ee1ea25f567b08eac21de00eab1a459a17781345cd40b151d74df9c88f2de88e.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podadc3a404_9370_43dc_8abe_80ca99d18544.slice/cri-containerd-d8ad979346dc2dec3af1fd7917df6b7860423be47814452d5b825964a5458813.scope"
      }
    ],
    "ips": [
      "10.114.0.208"
    ],
    "name": "clustermesh-apiserver-75ccccb79-5mcmq",
    "namespace": "kube-system"
  }
]

