Endpoint ID: 337
Path: /sys/fs/bpf/tc/globals/cilium_policy_00337

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6212248   76916     0        
Allow    Ingress     1          ANY          NONE         disabled    61399     744       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 347
Path: /sys/fs/bpf/tc/globals/cilium_policy_00347

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377024   4394      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 417
Path: /sys/fs/bpf/tc/globals/cilium_policy_00417

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 616
Path: /sys/fs/bpf/tc/globals/cilium_policy_00616

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5989695   60695     0        
Allow    Ingress     1          ANY          NONE         disabled    5716960   60538     0        
Allow    Egress      0          ANY          NONE         disabled    7648216   74563     0        


Endpoint ID: 945
Path: /sys/fs/bpf/tc/globals/cilium_policy_00945

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2160     23        0        
Allow    Ingress     1          ANY          NONE         disabled    123445   1409      0        
Allow    Egress      0          ANY          NONE         disabled    18784    206       0        


Endpoint ID: 1458
Path: /sys/fs/bpf/tc/globals/cilium_policy_01458

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1481
Path: /sys/fs/bpf/tc/globals/cilium_policy_01481

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2187
Path: /sys/fs/bpf/tc/globals/cilium_policy_02187

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3736     37        0        
Allow    Ingress     1          ANY          NONE         disabled    123313   1407      0        
Allow    Egress      0          ANY          NONE         disabled    17705    193       0        


