1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:3e:d0:4e:29:fd brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.147.106/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3551sec preferred_lft 3551sec
    inet6 fe80::43e:d0ff:fe4e:29fd/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:0a:02:55:4e:ab brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.147.61/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::40a:2ff:fe55:4eab/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:0e:77:42:ca:4d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::100e:77ff:fe42:ca4d/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:26:75:3c:36:13 brd ff:ff:ff:ff:ff:ff
    inet 10.114.0.84/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::6c26:75ff:fe3c:3613/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether c2:c2:ec:cf:fd:78 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c0c2:ecff:fecf:fd78/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:49:e9:4b:80:23 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::449:e9ff:fe4b:8023/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc635a178febee@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:c4:0c:82:96:0c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::5cc4:cff:fe82:960c/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcc9ecc81880ad@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:1f:b6:e0:51:52 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::701f:b6ff:fee0:5152/64 scope link 
       valid_lft forever preferred_lft forever
18: lxca34e1be851b5@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:71:b5:52:98:ef brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::8871:b5ff:fe52:98ef/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcf2683e3fb418@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:31:2d:82:f7:4c brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::d031:2dff:fe82:f74c/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcc7261f74c8c1@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:5d:7f:cc:b1:d6 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::445d:7fff:fecc:b1d6/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcdb7b07b94339@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:a4:ff:bc:64:c9 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::f0a4:ffff:febc:64c9/64 scope link 
       valid_lft forever preferred_lft forever
