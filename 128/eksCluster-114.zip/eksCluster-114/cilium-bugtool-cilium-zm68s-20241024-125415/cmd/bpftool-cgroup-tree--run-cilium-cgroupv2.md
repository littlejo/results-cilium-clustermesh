CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod02705c2e_2f0c_4c41_8441_a6ac85c9026b.slice/cri-containerd-588d6c1567bf73226536d21f1fa946534bfea6625b4eea2ea0210b360aed1569.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod02705c2e_2f0c_4c41_8441_a6ac85c9026b.slice/cri-containerd-e0a4f20a7095896a97ec7c67ddb907d29bfb6b120b58d36e0c85d2d00725d1df.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf67d1c82_d004_4a76_97bf_76bf75ad4e53.slice/cri-containerd-b83de323fb8dd817004fecad1b7fd5bf9898d77679fab9c2990dfd321b3fc396.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf67d1c82_d004_4a76_97bf_76bf75ad4e53.slice/cri-containerd-e4c58726eb131c258d97321eaa8c074fe5d0ee53eaaa7a996e80481a7ce2a72e.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod022bc25f_31b3_4ae0_b1f0_c06572af58d9.slice/cri-containerd-88797ed7dcde9f0677df9eaa25d6fbc4c98bb387703c397880f81a9eab1d4471.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod022bc25f_31b3_4ae0_b1f0_c06572af58d9.slice/cri-containerd-8163bfd3af7e1006484876c7c4d712ed886febc54f788263b9976dcf055c1089.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9048ee4a_469d_4643_9821_cca5863f4d82.slice/cri-containerd-5f895e76bceebbbbb7fb1b092a7c6e868ac83583d74a98871017d8075dec9d1c.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9048ee4a_469d_4643_9821_cca5863f4d82.slice/cri-containerd-1856af0b8db8591662edab3a9def767e4eee65fed50767cf3292d1331827b244.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod894f079d_3711_4b10_a8df_d0385007df84.slice/cri-containerd-5c407cfb705aaba4c077d31d164a54367c5cd823d8093fd7bf388eae64a78cfe.scope
    695      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod894f079d_3711_4b10_a8df_d0385007df84.slice/cri-containerd-6f4d021419a7a1150bef9c03c8cdcf634f51380b9e21c60911072f7fcd956324.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec26dedb_f710_41c7_8dbf_a841ca12d4fa.slice/cri-containerd-86f83e962e8b1561601c592704be2206a186f5cc089ffd79661d8b16e617ea07.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec26dedb_f710_41c7_8dbf_a841ca12d4fa.slice/cri-containerd-e0b95e893bff19cc927c6617d078f463a0548f1d7ddf3be88bde8ffab8e06836.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c08aa0b_0907_4c5e_8c51_e5d359283efc.slice/cri-containerd-11a3e5c36cb0d7aede7ad3a59011ee968f85232a1924788fdc530ea95a85678a.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c08aa0b_0907_4c5e_8c51_e5d359283efc.slice/cri-containerd-f8bf8cbe4a8db5a3438169737b6a4cb8b652288a4e9529a03693a86a768d151c.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod588973e7_6e92_4339_b8d2_7f1c72f1f45c.slice/cri-containerd-1a41a4f5aecf8b464c374150a68f230eed11fc540cc50272094cecdb6bf9876b.scope
    715      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod588973e7_6e92_4339_b8d2_7f1c72f1f45c.slice/cri-containerd-5edd9d138eb8d59ee47aa4e59c8be0d1b8b36ef59716e850db929018cf67d1c0.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod588973e7_6e92_4339_b8d2_7f1c72f1f45c.slice/cri-containerd-007e76224906561e92db92cc5c0ee12a4bf7599272ef7928cf0719a6ba7be141.scope
    699      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podadc3a404_9370_43dc_8abe_80ca99d18544.slice/cri-containerd-ee1ea25f567b08eac21de00eab1a459a17781345cd40b151d74df9c88f2de88e.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podadc3a404_9370_43dc_8abe_80ca99d18544.slice/cri-containerd-10f2880d5d80ff5629481e268ecb6c35bb13ed4b286bffb92fccc41a2eb49c6c.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podadc3a404_9370_43dc_8abe_80ca99d18544.slice/cri-containerd-d8ad979346dc2dec3af1fd7917df6b7860423be47814452d5b825964a5458813.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podadc3a404_9370_43dc_8abe_80ca99d18544.slice/cri-containerd-c59eb394af2aec2fad10fd2bbef49d482e36d65e397146242bc253714b24228a.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d1a8dc8_334b_4fee_b513_fcef18aa3e5e.slice/cri-containerd-8f54615c6bd621b12ba79d7e85bf0484621f176a3d0a74f99b1028407171d9d6.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3d1a8dc8_334b_4fee_b513_fcef18aa3e5e.slice/cri-containerd-5480c463e81206d599f79018e911bf91161aca802f48cbd66b82b27169ed7c37.scope
    703      cgroup_device   multi                                          
