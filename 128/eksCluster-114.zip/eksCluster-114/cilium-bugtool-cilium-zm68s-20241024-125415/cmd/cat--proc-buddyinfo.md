Node 0, zone      DMA      2     42     39     45      6      4      6      4      1      3     39 
Node 0, zone   Normal    296     16     15      1     11      9      2      2      1      2      8 
