key: 51 01 00 00  value: 09 02 00 00
key: 5b 01 00 00  value: d8 0c 00 00
key: a1 01 00 00  value: 1e 0d 00 00
key: 68 02 00 00  value: 75 02 00 00
key: b1 03 00 00  value: 1b 02 00 00
key: b2 05 00 00  value: 11 0d 00 00
key: 8b 08 00 00  value: 01 02 00 00
Found 7 elements
