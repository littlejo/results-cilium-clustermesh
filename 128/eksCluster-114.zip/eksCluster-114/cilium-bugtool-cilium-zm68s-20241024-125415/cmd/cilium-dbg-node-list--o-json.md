[
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.126.0.169"
      },
      "ipv6": {}
    },
    "name": "cmesh127/ip-172-31-163-49.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.126.0.0/24",
        "enabled": true,
        "ip": "172.31.163.49"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.126.0.78"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.65.0.223"
      },
      "ipv6": {}
    },
    "name": "cmesh66/ip-172-31-227-156.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.65.0.0/24",
        "enabled": true,
        "ip": "172.31.227.156"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.65.0.209"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.17.0.68"
      },
      "ipv6": {}
    },
    "name": "cmesh18/ip-172-31-234-150.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.17.0.0/24",
        "enabled": true,
        "ip": "172.31.234.150"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.17.0.179"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.37.0.66"
      },
      "ipv6": {}
    },
    "name": "cmesh38/ip-172-31-200-64.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.37.0.0/24",
        "enabled": true,
        "ip": "172.31.200.64"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.37.0.201"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.45.0.59"
      },
      "ipv6": {}
    },
    "name": "cmesh46/ip-172-31-217-21.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.45.0.0/24",
        "enabled": true,
        "ip": "172.31.217.21"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.45.0.10"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.89.0.6"
      },
      "ipv6": {}
    },
    "name": "cmesh90/ip-172-31-223-204.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.89.0.0/24",
        "enabled": true,
        "ip": "172.31.223.204"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.89.0.17"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.102.0.170"
      },
      "ipv6": {}
    },
    "name": "cmesh103/ip-172-31-176-47.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.102.0.0/24",
        "enabled": true,
        "ip": "172.31.176.47"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.102.0.53"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.53.0.48"
      },
      "ipv6": {}
    },
    "name": "cmesh54/ip-172-31-215-117.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.53.0.0/24",
        "enabled": true,
        "ip": "172.31.215.117"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.53.0.137"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.75.0.100"
      },
      "ipv6": {}
    },
    "name": "cmesh76/ip-172-31-199-151.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.75.0.0/24",
        "enabled": true,
        "ip": "172.31.199.151"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.75.0.213"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.22.0.239"
      },
      "ipv6": {}
    },
    "name": "cmesh23/ip-172-31-176-217.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.22.0.0/24",
        "enabled": true,
        "ip": "172.31.176.217"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.22.0.18"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.117.0.217"
      },
      "ipv6": {}
    },
    "name": "cmesh118/ip-172-31-202-9.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.117.0.0/24",
        "enabled": true,
        "ip": "172.31.202.9"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.117.0.185"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.0.0.122"
      },
      "ipv6": {}
    },
    "name": "cmesh1/ip-172-31-177-192.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.0.0.0/24",
        "enabled": true,
        "ip": "172.31.177.192"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.0.0.109"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.7.0.62"
      },
      "ipv6": {}
    },
    "name": "cmesh8/ip-172-31-253-200.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.7.0.0/24",
        "enabled": true,
        "ip": "172.31.253.200"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.7.0.192"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.28.0.79"
      },
      "ipv6": {}
    },
    "name": "cmesh29/ip-172-31-133-133.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.28.0.0/24",
        "enabled": true,
        "ip": "172.31.133.133"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.28.0.64"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.99.0.20"
      },
      "ipv6": {}
    },
    "name": "cmesh100/ip-172-31-222-193.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.99.0.0/24",
        "enabled": true,
        "ip": "172.31.222.193"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.99.0.46"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.35.0.179"
      },
      "ipv6": {}
    },
    "name": "cmesh36/ip-172-31-215-246.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.35.0.0/24",
        "enabled": true,
        "ip": "172.31.215.246"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.35.0.188"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.110.0.158"
      },
      "ipv6": {}
    },
    "name": "cmesh111/ip-172-31-132-102.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.110.0.0/24",
        "enabled": true,
        "ip": "172.31.132.102"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.110.0.37"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.63.0.48"
      },
      "ipv6": {}
    },
    "name": "cmesh64/ip-172-31-235-106.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.63.0.0/24",
        "enabled": true,
        "ip": "172.31.235.106"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.63.0.98"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.112.0.63"
      },
      "ipv6": {}
    },
    "name": "cmesh113/ip-172-31-177-209.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.112.0.0/24",
        "enabled": true,
        "ip": "172.31.177.209"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.112.0.8"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.106.0.232"
      },
      "ipv6": {}
    },
    "name": "cmesh107/ip-172-31-157-200.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.106.0.0/24",
        "enabled": true,
        "ip": "172.31.157.200"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.106.0.179"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.1.0.17"
      },
      "ipv6": {}
    },
    "name": "cmesh2/ip-172-31-242-222.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.1.0.0/24",
        "enabled": true,
        "ip": "172.31.242.222"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.1.0.101"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.118.0.190"
      },
      "ipv6": {}
    },
    "name": "cmesh119/ip-172-31-185-179.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.118.0.0/24",
        "enabled": true,
        "ip": "172.31.185.179"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.118.0.159"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.29.0.179"
      },
      "ipv6": {}
    },
    "name": "cmesh30/ip-172-31-224-108.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.29.0.0/24",
        "enabled": true,
        "ip": "172.31.224.108"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.29.0.29"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.74.0.248"
      },
      "ipv6": {}
    },
    "name": "cmesh75/ip-172-31-140-172.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.74.0.0/24",
        "enabled": true,
        "ip": "172.31.140.172"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.74.0.236"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.62.0.204"
      },
      "ipv6": {}
    },
    "name": "cmesh63/ip-172-31-179-183.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.62.0.0/24",
        "enabled": true,
        "ip": "172.31.179.183"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.62.0.248"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.120.0.212"
      },
      "ipv6": {}
    },
    "name": "cmesh121/ip-172-31-168-52.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.120.0.0/24",
        "enabled": true,
        "ip": "172.31.168.52"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.120.0.219"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.71.0.144"
      },
      "ipv6": {}
    },
    "name": "cmesh72/ip-172-31-232-106.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.71.0.0/24",
        "enabled": true,
        "ip": "172.31.232.106"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.71.0.211"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.33.0.201"
      },
      "ipv6": {}
    },
    "name": "cmesh34/ip-172-31-207-135.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.33.0.0/24",
        "enabled": true,
        "ip": "172.31.207.135"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.33.0.213"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.16.0.148"
      },
      "ipv6": {}
    },
    "name": "cmesh17/ip-172-31-142-66.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.16.0.0/24",
        "enabled": true,
        "ip": "172.31.142.66"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.16.0.187"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.58.0.131"
      },
      "ipv6": {}
    },
    "name": "cmesh59/ip-172-31-169-93.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.58.0.0/24",
        "enabled": true,
        "ip": "172.31.169.93"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.58.0.94"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.14.0.75"
      },
      "ipv6": {}
    },
    "name": "cmesh15/ip-172-31-140-198.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.14.0.0/24",
        "enabled": true,
        "ip": "172.31.140.198"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.14.0.172"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.107.0.215"
      },
      "ipv6": {}
    },
    "name": "cmesh108/ip-172-31-218-198.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.107.0.0/24",
        "enabled": true,
        "ip": "172.31.218.198"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.107.0.109"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.9.0.205"
      },
      "ipv6": {}
    },
    "name": "cmesh10/ip-172-31-244-235.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.9.0.0/24",
        "enabled": true,
        "ip": "172.31.244.235"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.9.0.250"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.94.0.69"
      },
      "ipv6": {}
    },
    "name": "cmesh95/ip-172-31-159-1.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.94.0.0/24",
        "enabled": true,
        "ip": "172.31.159.1"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.94.0.26"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.67.0.91"
      },
      "ipv6": {}
    },
    "name": "cmesh68/ip-172-31-214-255.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.67.0.0/24",
        "enabled": true,
        "ip": "172.31.214.255"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.67.0.199"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.12.0.109"
      },
      "ipv6": {}
    },
    "name": "cmesh13/ip-172-31-163-37.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.12.0.0/24",
        "enabled": true,
        "ip": "172.31.163.37"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.12.0.145"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.54.0.4"
      },
      "ipv6": {}
    },
    "name": "cmesh55/ip-172-31-188-31.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.54.0.0/24",
        "enabled": true,
        "ip": "172.31.188.31"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.54.0.96"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.104.0.102"
      },
      "ipv6": {}
    },
    "name": "cmesh105/ip-172-31-180-41.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.104.0.0/24",
        "enabled": true,
        "ip": "172.31.180.41"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.104.0.119"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.41.0.253"
      },
      "ipv6": {}
    },
    "name": "cmesh42/ip-172-31-252-73.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.41.0.0/24",
        "enabled": true,
        "ip": "172.31.252.73"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.41.0.85"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.49.0.70"
      },
      "ipv6": {}
    },
    "name": "cmesh50/ip-172-31-199-247.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.49.0.0/24",
        "enabled": true,
        "ip": "172.31.199.247"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.49.0.117"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.20.0.232"
      },
      "ipv6": {}
    },
    "name": "cmesh21/ip-172-31-129-74.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.20.0.0/24",
        "enabled": true,
        "ip": "172.31.129.74"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.20.0.76"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.68.0.50"
      },
      "ipv6": {}
    },
    "name": "cmesh69/ip-172-31-135-109.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.68.0.0/24",
        "enabled": true,
        "ip": "172.31.135.109"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.68.0.27"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.13.0.218"
      },
      "ipv6": {}
    },
    "name": "cmesh14/ip-172-31-205-246.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.13.0.0/24",
        "enabled": true,
        "ip": "172.31.205.246"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.13.0.179"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.38.0.220"
      },
      "ipv6": {}
    },
    "name": "cmesh39/ip-172-31-144-72.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.38.0.0/24",
        "enabled": true,
        "ip": "172.31.144.72"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.38.0.136"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.103.0.161"
      },
      "ipv6": {}
    },
    "name": "cmesh104/ip-172-31-218-118.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.103.0.0/24",
        "enabled": true,
        "ip": "172.31.218.118"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.103.0.123"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.116.0.19"
      },
      "ipv6": {}
    },
    "name": "cmesh117/ip-172-31-173-250.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.116.0.0/24",
        "enabled": true,
        "ip": "172.31.173.250"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.116.0.18"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.86.0.160"
      },
      "ipv6": {}
    },
    "name": "cmesh87/ip-172-31-134-118.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.86.0.0/24",
        "enabled": true,
        "ip": "172.31.134.118"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.86.0.191"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.23.0.190"
      },
      "ipv6": {}
    },
    "name": "cmesh24/ip-172-31-212-95.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.23.0.0/24",
        "enabled": true,
        "ip": "172.31.212.95"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.23.0.148"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.84.0.20"
      },
      "ipv6": {}
    },
    "name": "cmesh85/ip-172-31-140-202.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.84.0.0/24",
        "enabled": true,
        "ip": "172.31.140.202"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.84.0.235"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.81.0.11"
      },
      "ipv6": {}
    },
    "name": "cmesh82/ip-172-31-255-56.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.81.0.0/24",
        "enabled": true,
        "ip": "172.31.255.56"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.81.0.173"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.56.0.158"
      },
      "ipv6": {}
    },
    "name": "cmesh57/ip-172-31-140-56.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.56.0.0/24",
        "enabled": true,
        "ip": "172.31.140.56"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.56.0.114"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.57.0.115"
      },
      "ipv6": {}
    },
    "name": "cmesh58/ip-172-31-202-14.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.57.0.0/24",
        "enabled": true,
        "ip": "172.31.202.14"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.57.0.212"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.90.0.16"
      },
      "ipv6": {}
    },
    "name": "cmesh91/ip-172-31-138-25.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.90.0.0/24",
        "enabled": true,
        "ip": "172.31.138.25"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.90.0.247"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.127.0.151"
      },
      "ipv6": {}
    },
    "name": "cmesh128/ip-172-31-221-249.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.127.0.0/24",
        "enabled": true,
        "ip": "172.31.221.249"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.127.0.127"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.15.0.77"
      },
      "ipv6": {}
    },
    "name": "cmesh16/ip-172-31-242-159.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.15.0.0/24",
        "enabled": true,
        "ip": "172.31.242.159"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.15.0.132"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.113.0.150"
      },
      "ipv6": {}
    },
    "name": "cmesh114/ip-172-31-246-108.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.113.0.0/24",
        "enabled": true,
        "ip": "172.31.246.108"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.113.0.158"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.111.0.170"
      },
      "ipv6": {}
    },
    "name": "cmesh112/ip-172-31-253-175.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.111.0.0/24",
        "enabled": true,
        "ip": "172.31.253.175"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.111.0.239"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.11.0.137"
      },
      "ipv6": {}
    },
    "name": "cmesh12/ip-172-31-243-27.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.11.0.0/24",
        "enabled": true,
        "ip": "172.31.243.27"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.11.0.2"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.44.0.197"
      },
      "ipv6": {}
    },
    "name": "cmesh45/ip-172-31-160-162.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.44.0.0/24",
        "enabled": true,
        "ip": "172.31.160.162"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.44.0.216"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.40.0.174"
      },
      "ipv6": {}
    },
    "name": "cmesh41/ip-172-31-148-47.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.40.0.0/24",
        "enabled": true,
        "ip": "172.31.148.47"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.40.0.74"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.25.0.215"
      },
      "ipv6": {}
    },
    "name": "cmesh26/ip-172-31-248-30.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.25.0.0/24",
        "enabled": true,
        "ip": "172.31.248.30"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.25.0.6"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.47.0.107"
      },
      "ipv6": {}
    },
    "name": "cmesh48/ip-172-31-195-85.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.47.0.0/24",
        "enabled": true,
        "ip": "172.31.195.85"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.47.0.219"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.95.0.193"
      },
      "ipv6": {}
    },
    "name": "cmesh96/ip-172-31-229-144.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.95.0.0/24",
        "enabled": true,
        "ip": "172.31.229.144"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.95.0.179"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.4.0.168"
      },
      "ipv6": {}
    },
    "name": "cmesh5/ip-172-31-147-80.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.4.0.0/24",
        "enabled": true,
        "ip": "172.31.147.80"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.4.0.183"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.46.0.148"
      },
      "ipv6": {}
    },
    "name": "cmesh47/ip-172-31-188-57.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.46.0.0/24",
        "enabled": true,
        "ip": "172.31.188.57"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.46.0.151"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.34.0.204"
      },
      "ipv6": {}
    },
    "name": "cmesh35/ip-172-31-166-19.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.34.0.0/24",
        "enabled": true,
        "ip": "172.31.166.19"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.34.0.135"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.42.0.63"
      },
      "ipv6": {}
    },
    "name": "cmesh43/ip-172-31-184-21.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.42.0.0/24",
        "enabled": true,
        "ip": "172.31.184.21"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.42.0.128"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.98.0.155"
      },
      "ipv6": {}
    },
    "name": "cmesh99/ip-172-31-148-120.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.98.0.0/24",
        "enabled": true,
        "ip": "172.31.148.120"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.98.0.73"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.108.0.239"
      },
      "ipv6": {}
    },
    "name": "cmesh109/ip-172-31-187-16.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.108.0.0/24",
        "enabled": true,
        "ip": "172.31.187.16"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.108.0.118"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.115.0.48"
      },
      "ipv6": {}
    },
    "name": "cmesh116/ip-172-31-250-53.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.115.0.0/24",
        "enabled": true,
        "ip": "172.31.250.53"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.115.0.135"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.124.0.214"
      },
      "ipv6": {}
    },
    "name": "cmesh125/ip-172-31-164-231.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.124.0.0/24",
        "enabled": true,
        "ip": "172.31.164.231"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.124.0.223"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.2.0.117"
      },
      "ipv6": {}
    },
    "name": "cmesh3/ip-172-31-165-27.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.2.0.0/24",
        "enabled": true,
        "ip": "172.31.165.27"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.2.0.133"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.96.0.14"
      },
      "ipv6": {}
    },
    "name": "cmesh97/ip-172-31-163-67.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.96.0.0/24",
        "enabled": true,
        "ip": "172.31.163.67"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.96.0.60"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.66.0.77"
      },
      "ipv6": {}
    },
    "name": "cmesh67/ip-172-31-169-129.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.66.0.0/24",
        "enabled": true,
        "ip": "172.31.169.129"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.66.0.229"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.60.0.215"
      },
      "ipv6": {}
    },
    "name": "cmesh61/ip-172-31-181-22.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.60.0.0/24",
        "enabled": true,
        "ip": "172.31.181.22"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.60.0.134"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.88.0.25"
      },
      "ipv6": {}
    },
    "name": "cmesh89/ip-172-31-158-24.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.88.0.0/24",
        "enabled": true,
        "ip": "172.31.158.24"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.88.0.78"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.119.0.181"
      },
      "ipv6": {}
    },
    "name": "cmesh120/ip-172-31-233-58.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.119.0.0/24",
        "enabled": true,
        "ip": "172.31.233.58"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.119.0.204"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.5.0.26"
      },
      "ipv6": {}
    },
    "name": "cmesh6/ip-172-31-225-184.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.5.0.0/24",
        "enabled": true,
        "ip": "172.31.225.184"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.5.0.15"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.31.0.153"
      },
      "ipv6": {}
    },
    "name": "cmesh32/ip-172-31-219-96.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.31.0.0/24",
        "enabled": true,
        "ip": "172.31.219.96"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.31.0.144"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.52.0.92"
      },
      "ipv6": {}
    },
    "name": "cmesh53/ip-172-31-160-21.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.52.0.0/24",
        "enabled": true,
        "ip": "172.31.160.21"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.52.0.54"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.87.0.197"
      },
      "ipv6": {}
    },
    "name": "cmesh88/ip-172-31-210-124.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.87.0.0/24",
        "enabled": true,
        "ip": "172.31.210.124"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.87.0.111"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.125.0.61"
      },
      "ipv6": {}
    },
    "name": "cmesh126/ip-172-31-251-94.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.125.0.0/24",
        "enabled": true,
        "ip": "172.31.251.94"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.125.0.49"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.77.0.189"
      },
      "ipv6": {}
    },
    "name": "cmesh78/ip-172-31-230-165.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.77.0.0/24",
        "enabled": true,
        "ip": "172.31.230.165"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.77.0.43"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.122.0.213"
      },
      "ipv6": {}
    },
    "name": "cmesh123/ip-172-31-191-30.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.122.0.0/24",
        "enabled": true,
        "ip": "172.31.191.30"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.122.0.137"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.93.0.170"
      },
      "ipv6": {}
    },
    "name": "cmesh94/ip-172-31-237-87.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.93.0.0/24",
        "enabled": true,
        "ip": "172.31.237.87"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.93.0.39"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.39.0.32"
      },
      "ipv6": {}
    },
    "name": "cmesh40/ip-172-31-239-188.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.39.0.0/24",
        "enabled": true,
        "ip": "172.31.239.188"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.39.0.237"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.61.0.132"
      },
      "ipv6": {}
    },
    "name": "cmesh62/ip-172-31-248-119.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.61.0.0/24",
        "enabled": true,
        "ip": "172.31.248.119"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.61.0.12"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.8.0.168"
      },
      "ipv6": {}
    },
    "name": "cmesh9/ip-172-31-185-116.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.8.0.0/24",
        "enabled": true,
        "ip": "172.31.185.116"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.8.0.245"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.72.0.118"
      },
      "ipv6": {}
    },
    "name": "cmesh73/ip-172-31-146-114.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.72.0.0/24",
        "enabled": true,
        "ip": "172.31.146.114"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.72.0.66"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.91.0.92"
      },
      "ipv6": {}
    },
    "name": "cmesh92/ip-172-31-229-17.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.91.0.0/24",
        "enabled": true,
        "ip": "172.31.229.17"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.91.0.52"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.32.0.192"
      },
      "ipv6": {}
    },
    "name": "cmesh33/ip-172-31-176-93.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.32.0.0/24",
        "enabled": true,
        "ip": "172.31.176.93"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.32.0.60"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.83.0.38"
      },
      "ipv6": {}
    },
    "name": "cmesh84/ip-172-31-242-249.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.83.0.0/24",
        "enabled": true,
        "ip": "172.31.242.249"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.83.0.222"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.18.0.42"
      },
      "ipv6": {}
    },
    "name": "cmesh19/ip-172-31-181-251.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.18.0.0/24",
        "enabled": true,
        "ip": "172.31.181.251"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.18.0.163"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.123.0.192"
      },
      "ipv6": {}
    },
    "name": "cmesh124/ip-172-31-210-235.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.123.0.0/24",
        "enabled": true,
        "ip": "172.31.210.235"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.123.0.29"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.105.0.104"
      },
      "ipv6": {}
    },
    "name": "cmesh106/ip-172-31-254-105.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.105.0.0/24",
        "enabled": true,
        "ip": "172.31.254.105"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.105.0.155"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.43.0.4"
      },
      "ipv6": {}
    },
    "name": "cmesh44/ip-172-31-194-195.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.43.0.0/24",
        "enabled": true,
        "ip": "172.31.194.195"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.43.0.132"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.30.0.42"
      },
      "ipv6": {}
    },
    "name": "cmesh31/ip-172-31-181-129.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.30.0.0/24",
        "enabled": true,
        "ip": "172.31.181.129"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.30.0.47"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.78.0.109"
      },
      "ipv6": {}
    },
    "name": "cmesh79/ip-172-31-190-99.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.78.0.0/24",
        "enabled": true,
        "ip": "172.31.190.99"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.78.0.246"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.55.0.52"
      },
      "ipv6": {}
    },
    "name": "cmesh56/ip-172-31-225-88.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.55.0.0/24",
        "enabled": true,
        "ip": "172.31.225.88"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.55.0.120"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.3.0.13"
      },
      "ipv6": {}
    },
    "name": "cmesh4/ip-172-31-217-24.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.3.0.0/24",
        "enabled": true,
        "ip": "172.31.217.24"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.3.0.236"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.6.0.139"
      },
      "ipv6": {}
    },
    "name": "cmesh7/ip-172-31-153-241.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.6.0.0/24",
        "enabled": true,
        "ip": "172.31.153.241"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.6.0.210"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.92.0.213"
      },
      "ipv6": {}
    },
    "name": "cmesh93/ip-172-31-142-217.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.92.0.0/24",
        "enabled": true,
        "ip": "172.31.142.217"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.92.0.230"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.10.0.179"
      },
      "ipv6": {}
    },
    "name": "cmesh11/ip-172-31-158-205.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.10.0.0/24",
        "enabled": true,
        "ip": "172.31.158.205"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.10.0.123"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.97.0.112"
      },
      "ipv6": {}
    },
    "name": "cmesh98/ip-172-31-206-223.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.97.0.0/24",
        "enabled": true,
        "ip": "172.31.206.223"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.97.0.160"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.50.0.237"
      },
      "ipv6": {}
    },
    "name": "cmesh51/ip-172-31-162-244.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.50.0.0/24",
        "enabled": true,
        "ip": "172.31.162.244"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.50.0.234"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.26.0.207"
      },
      "ipv6": {}
    },
    "name": "cmesh27/ip-172-31-172-234.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.26.0.0/24",
        "enabled": true,
        "ip": "172.31.172.234"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.26.0.236"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.109.0.24"
      },
      "ipv6": {}
    },
    "name": "cmesh110/ip-172-31-225-210.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.109.0.0/24",
        "enabled": true,
        "ip": "172.31.225.210"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.109.0.182"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.36.0.190"
      },
      "ipv6": {}
    },
    "name": "cmesh37/ip-172-31-135-11.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.36.0.0/24",
        "enabled": true,
        "ip": "172.31.135.11"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.36.0.208"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.76.0.156"
      },
      "ipv6": {}
    },
    "name": "cmesh77/ip-172-31-131-33.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.76.0.0/24",
        "enabled": true,
        "ip": "172.31.131.33"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.76.0.110"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.80.0.247"
      },
      "ipv6": {}
    },
    "name": "cmesh81/ip-172-31-181-241.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.80.0.0/24",
        "enabled": true,
        "ip": "172.31.181.241"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.80.0.25"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.21.0.146"
      },
      "ipv6": {}
    },
    "name": "cmesh22/ip-172-31-194-30.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.21.0.0/24",
        "enabled": true,
        "ip": "172.31.194.30"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.21.0.241"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.59.0.193"
      },
      "ipv6": {}
    },
    "name": "cmesh60/ip-172-31-194-250.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.59.0.0/24",
        "enabled": true,
        "ip": "172.31.194.250"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.59.0.123"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.121.0.129"
      },
      "ipv6": {}
    },
    "name": "cmesh122/ip-172-31-201-135.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.121.0.0/24",
        "enabled": true,
        "ip": "172.31.201.135"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.121.0.166"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.73.0.6"
      },
      "ipv6": {}
    },
    "name": "cmesh74/ip-172-31-193-203.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.73.0.0/24",
        "enabled": true,
        "ip": "172.31.193.203"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.73.0.20"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.69.0.125"
      },
      "ipv6": {}
    },
    "name": "cmesh70/ip-172-31-223-68.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.69.0.0/24",
        "enabled": true,
        "ip": "172.31.223.68"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.69.0.131"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.85.0.109"
      },
      "ipv6": {}
    },
    "name": "cmesh86/ip-172-31-217-206.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.85.0.0/24",
        "enabled": true,
        "ip": "172.31.217.206"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.85.0.137"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.24.0.141"
      },
      "ipv6": {}
    },
    "name": "cmesh25/ip-172-31-182-187.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.24.0.0/24",
        "enabled": true,
        "ip": "172.31.182.187"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.24.0.62"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.27.0.98"
      },
      "ipv6": {}
    },
    "name": "cmesh28/ip-172-31-229-65.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.27.0.0/24",
        "enabled": true,
        "ip": "172.31.229.65"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.27.0.137"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.82.0.219"
      },
      "ipv6": {}
    },
    "name": "cmesh83/ip-172-31-156-172.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.82.0.0/24",
        "enabled": true,
        "ip": "172.31.156.172"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.82.0.97"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.64.0.145"
      },
      "ipv6": {}
    },
    "name": "cmesh65/ip-172-31-185-56.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.64.0.0/24",
        "enabled": true,
        "ip": "172.31.185.56"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.64.0.98"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.101.0.134"
      },
      "ipv6": {}
    },
    "name": "cmesh102/ip-172-31-205-43.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.101.0.0/24",
        "enabled": true,
        "ip": "172.31.205.43"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.101.0.219"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.79.0.28"
      },
      "ipv6": {}
    },
    "name": "cmesh80/ip-172-31-210-91.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.79.0.0/24",
        "enabled": true,
        "ip": "172.31.210.91"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.79.0.161"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.19.0.176"
      },
      "ipv6": {}
    },
    "name": "cmesh20/ip-172-31-214-60.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.19.0.0/24",
        "enabled": true,
        "ip": "172.31.214.60"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.19.0.104"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.70.0.183"
      },
      "ipv6": {}
    },
    "name": "cmesh71/ip-172-31-151-89.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.70.0.0/24",
        "enabled": true,
        "ip": "172.31.151.89"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.70.0.139"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.114.0.7"
      },
      "ipv6": {}
    },
    "name": "cmesh115/ip-172-31-147-106.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.114.0.0/24",
        "enabled": true,
        "ip": "172.31.147.106"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.114.0.84"
      }
    ],
    "source": "local"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.48.0.27"
      },
      "ipv6": {}
    },
    "name": "cmesh49/ip-172-31-162-33.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.48.0.0/24",
        "enabled": true,
        "ip": "172.31.162.33"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.48.0.115"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.100.0.151"
      },
      "ipv6": {}
    },
    "name": "cmesh101/ip-172-31-164-193.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.100.0.0/24",
        "enabled": true,
        "ip": "172.31.164.193"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.100.0.2"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.51.0.227"
      },
      "ipv6": {}
    },
    "name": "cmesh52/ip-172-31-228-238.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.51.0.0/24",
        "enabled": true,
        "ip": "172.31.228.238"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.51.0.143"
      }
    ],
    "source": "clustermesh"
  }
]

