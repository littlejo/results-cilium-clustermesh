29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:20+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:23:20+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:23:21+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:23:21+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:23:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:23:21+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:23:21+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:23:26+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:23:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:23:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:23:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
479: sched_cls  name tail_handle_ipv4  tag cc7d2429f45c3a15  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
480: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
481: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:32:52+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
504: sched_cls  name tail_ipv4_to_endpoint  tag 642a381ea957c66f  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,107,41,82,83,80,106,39,108,40,37,38
	btf_id 153
505: sched_cls  name tail_handle_arp  tag f1792d265b73e975  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 154
506: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 155
507: sched_cls  name tail_handle_ipv4  tag df77c10da03ebeb0  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 156
508: sched_cls  name tail_handle_ipv4_cont  tag f39a591dd8a02e42  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,107,41,106,82,83,39,76,74,77,108,40,37,38,81
	btf_id 157
509: sched_cls  name __send_drop_notify  tag 09d250b09ad44e0f  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 158
510: sched_cls  name tail_ipv4_ct_ingress  tag 53ee1e932f560303  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 159
512: sched_cls  name cil_from_container  tag 1ad6c5bb55906119  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,76
	btf_id 161
513: sched_cls  name handle_policy  tag 70901f32b454c0c0  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,108,82,83,107,41,80,106,39,84,75,40,37,38
	btf_id 162
514: sched_cls  name tail_ipv4_ct_egress  tag efaa9a41041360bc  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 163
515: sched_cls  name tail_handle_ipv4_cont  tag afc89b48ca383164  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,110,41,101,82,83,39,76,74,77,109,40,37,38,81
	btf_id 165
516: sched_cls  name cil_from_container  tag 797a1da89b0b2731  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 109,76
	btf_id 166
517: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 167
518: sched_cls  name tail_ipv4_to_endpoint  tag be1332ef5c14f0f8  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,110,41,82,83,80,101,39,109,40,37,38
	btf_id 168
519: sched_cls  name tail_handle_arp  tag 5606eb969f650b1a  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 169
520: sched_cls  name __send_drop_notify  tag d7725cddd6e8d9b6  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 170
521: sched_cls  name handle_policy  tag f65094517d11171a  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,109,82,83,110,41,80,101,39,84,75,40,37,38
	btf_id 171
522: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 172
523: sched_cls  name tail_handle_ipv4  tag 00f3bcaf0096c5de  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 173
524: sched_cls  name tail_ipv4_ct_ingress  tag be646dfb573730a1  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 174
527: sched_cls  name tail_handle_ipv4_cont  tag 60699310f3b7d81c  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,100,82,83,39,76,74,77,111,40,37,38,81
	btf_id 178
528: sched_cls  name tail_handle_arp  tag 84028aac365d6df0  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 179
529: sched_cls  name __send_drop_notify  tag 74e730a3513d627f  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 180
530: sched_cls  name tail_ipv4_ct_ingress  tag 98a7e0dde55cee4e  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 181
531: sched_cls  name tail_ipv4_to_endpoint  tag 31c9bcc33437af66  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,100,39,111,40,37,38
	btf_id 182
532: sched_cls  name cil_from_container  tag d4a95dde671ecbad  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 183
533: sched_cls  name tail_handle_ipv4  tag 6e78bb731737708a  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 184
534: sched_cls  name tail_ipv4_ct_egress  tag efaa9a41041360bc  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 185
535: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
538: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
539: sched_cls  name handle_policy  tag 9ec98b52b9062362  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,112,41,80,100,39,84,75,40,37,38
	btf_id 186
540: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 187
541: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
544: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
545: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
548: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
549: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
552: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:32:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
554: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 190
555: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 191
556: sched_cls  name __send_drop_notify  tag 62855406fa2afcb0  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
557: sched_cls  name tail_handle_ipv4_from_host  tag 16ef7f4a0fe42136  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 193
558: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 194
561: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 198
562: sched_cls  name __send_drop_notify  tag 62855406fa2afcb0  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
563: sched_cls  name tail_handle_ipv4_from_host  tag 16ef7f4a0fe42136  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 200
564: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 201
568: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 206
571: sched_cls  name __send_drop_notify  tag 62855406fa2afcb0  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 209
572: sched_cls  name tail_handle_ipv4_from_host  tag 16ef7f4a0fe42136  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 210
573: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 211
575: sched_cls  name __send_drop_notify  tag 62855406fa2afcb0  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 214
576: sched_cls  name tail_handle_ipv4_from_host  tag 16ef7f4a0fe42136  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 215
577: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 216
579: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:32:56+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 218
620: sched_cls  name tail_handle_ipv4_cont  tag fc7c944bf6d60839  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,136,41,135,82,83,39,76,74,77,137,40,37,38,81
	btf_id 233
622: sched_cls  name cil_from_container  tag abbbcbaeed101dba  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 137,76
	btf_id 235
623: sched_cls  name __send_drop_notify  tag 0db65ae428c7af35  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 236
624: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,137
	btf_id 237
625: sched_cls  name tail_ipv4_ct_ingress  tag f33cb93ba776b71d  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 238
626: sched_cls  name tail_ipv4_to_endpoint  tag fb178ff1b5fdcbea  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,136,41,82,83,80,135,39,137,40,37,38
	btf_id 239
627: sched_cls  name tail_handle_arp  tag 88d3354044858d42  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,137
	btf_id 240
628: sched_cls  name tail_ipv4_ct_egress  tag 0194a5470dc8e61c  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 241
629: sched_cls  name handle_policy  tag e6552ddde122dfe2  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,137,82,83,136,41,80,135,39,84,75,40,37,38
	btf_id 242
630: sched_cls  name tail_handle_ipv4  tag c557e18ec91febe7  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,137
	btf_id 243
631: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
634: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
647: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
650: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
655: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:40:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
658: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:40:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
692: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
695: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
696: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
699: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
700: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
703: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
704: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
707: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
708: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
711: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
712: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
715: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
716: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
719: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3284: sched_cls  name tail_handle_ipv4_cont  tag 1015616e96be8b63  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,628,41,148,82,83,39,76,74,77,627,40,37,38,81
	btf_id 3078
3285: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,627
	btf_id 3079
3288: sched_cls  name handle_policy  tag 74c7b0336763c320  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,627,82,83,628,41,80,148,39,84,75,40,37,38
	btf_id 3080
3290: sched_cls  name tail_handle_arp  tag 399098723cd0e866  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,627
	btf_id 3085
3292: sched_cls  name tail_ipv4_ct_ingress  tag f5c92403f2d700c2  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3086
3293: sched_cls  name cil_from_container  tag 5fcd4b15c98c1035  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 627,76
	btf_id 3088
3296: sched_cls  name tail_ipv4_to_endpoint  tag e03d5e83afd00f15  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,628,41,82,83,80,148,39,627,40,37,38
	btf_id 3091
3300: sched_cls  name __send_drop_notify  tag efc4f8bb4a6b2af7  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3096
3302: sched_cls  name tail_handle_ipv4  tag dbdf2a99561288d8  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,627
	btf_id 3097
3303: sched_cls  name tail_ipv4_ct_egress  tag 30b4e1591f52edfa  gpl
	loaded_at 2024-10-24T12:51:21+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,627,82,83,628,84
	btf_id 3099
3338: sched_cls  name tail_handle_ipv4  tag 4eeddc7d7cc35224  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,637
	btf_id 3138
3339: sched_cls  name __send_drop_notify  tag e34667a89c4073c8  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3140
3340: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,637
	btf_id 3141
3342: sched_cls  name tail_handle_arp  tag 819bc30452b18f0a  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,637
	btf_id 3143
3343: sched_cls  name cil_from_container  tag 81d5917a30b44079  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 637,76
	btf_id 3144
3344: sched_cls  name tail_handle_ipv4_cont  tag f9f168a76fb981ba  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,638,41,151,82,83,39,76,74,77,637,40,37,38,81
	btf_id 3145
3345: sched_cls  name handle_policy  tag 126b091a60892855  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,640,82,83,639,41,80,145,39,84,75,40,37,38
	btf_id 3139
3346: sched_cls  name tail_ipv4_ct_egress  tag 33c68068f92b8dcd  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3146
3347: sched_cls  name tail_handle_ipv4  tag 22ca40f9dbbae283  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,640
	btf_id 3147
3349: sched_cls  name cil_from_container  tag ef630bfef7bc2762  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 640,76
	btf_id 3150
3350: sched_cls  name tail_handle_arp  tag 1a077db21aea7c9d  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,640
	btf_id 3151
3351: sched_cls  name tail_ipv4_ct_egress  tag 9309eb74618d343e  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3152
3352: sched_cls  name tail_ipv4_to_endpoint  tag a92359433ee1d290  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,638,41,82,83,80,151,39,637,40,37,38
	btf_id 3148
3353: sched_cls  name tail_ipv4_ct_ingress  tag 201feae2776dd675  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,637,82,83,638,84
	btf_id 3153
3354: sched_cls  name tail_ipv4_ct_ingress  tag fd7bb26835fc7d7c  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,640,82,83,639,84
	btf_id 3154
3355: sched_cls  name tail_handle_ipv4_cont  tag 486104037fc60d4d  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,639,41,145,82,83,39,76,74,77,640,40,37,38,81
	btf_id 3156
3356: sched_cls  name __send_drop_notify  tag d64db6924f16d1ed  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3157
3357: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,640
	btf_id 3158
3358: sched_cls  name handle_policy  tag 81393cdcb6a52a5a  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,637,82,83,638,41,80,151,39,84,75,40,37,38
	btf_id 3155
3359: sched_cls  name tail_ipv4_to_endpoint  tag 897610370e71480f  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,639,41,82,83,80,145,39,640,40,37,38
	btf_id 3159
