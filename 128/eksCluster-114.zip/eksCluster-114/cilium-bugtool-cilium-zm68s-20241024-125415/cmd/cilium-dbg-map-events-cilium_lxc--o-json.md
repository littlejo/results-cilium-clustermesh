{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.116Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.118Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.180Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.181Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.217Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.434Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.445Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.501Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.508Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.558Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.113Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.113Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.160Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.176Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.202Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.411Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.424Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.484Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.500Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.527Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.122Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.129Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.152Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.186Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.268Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.306Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.314Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.543Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.546Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.592Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.615Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.648Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.167Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.168Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.210Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.221Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.265Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.273Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.304Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.555Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.561Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.604Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.622Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.653Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.019Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.068Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.069Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.135Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.170Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.211Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.415Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.422Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.469Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.473Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:58.519Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.942Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.957Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.003Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.015Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.040Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.266Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.273Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.331Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.340Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.377Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.742Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.776Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.788Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.813Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.862Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.862Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.865Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.122Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.137Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.245Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.299Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.301Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.683Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.721Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.722Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.771Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.771Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.809Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.026Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.043Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.100Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.111Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:08.151Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.592Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.625Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.646Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.682Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.686Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.954Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.954Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.015Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.022Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:11.056Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.374Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.411Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.416Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.461Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.496Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.517Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.747Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.748Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.791Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.836Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.851Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.198Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.236Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.239Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.283Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.298Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.331Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.597Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.613Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.625Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.655Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.301Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.378Z",
  "value": "id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.380Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.380Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.432Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.636Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.648Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.304Z",
  "value": "id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.305Z",
  "value": "id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C"
}

