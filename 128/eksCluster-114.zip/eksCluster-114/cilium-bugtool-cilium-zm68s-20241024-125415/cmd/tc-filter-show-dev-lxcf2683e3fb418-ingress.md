filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf2683e3fb418 direct-action not_in_hw id 3349 tag ef630bfef7bc2762 jited 
