KEY             VALUE
AgentLiveness   1889425187516
UTimeOffset     3378462105468750
