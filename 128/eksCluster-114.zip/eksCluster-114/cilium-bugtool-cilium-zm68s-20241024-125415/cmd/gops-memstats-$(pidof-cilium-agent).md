alloc: 114.28MB (119830072 bytes)
total-alloc: 3.12GB (3350980008 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 75791290
frees: 74679281
heap-alloc: 114.28MB (119830072 bytes)
heap-sys: 176.70MB (185286656 bytes)
heap-idle: 36.77MB (38551552 bytes)
heap-in-use: 139.94MB (146735104 bytes)
heap-released: 7.65MB (8019968 bytes)
heap-objects: 1112009
stack-in-use: 35.25MB (36962304 bytes)
stack-sys: 35.25MB (36962304 bytes)
stack-mspan-inuse: 2.19MB (2297440 bytes)
stack-mspan-sys: 2.77MB (2904960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 976.92KB (1000369 bytes)
gc-sys: 5.53MB (5803152 bytes)
next-gc: when heap-alloc >= 150.91MB (158239400 bytes)
last-gc: 2024-10-24 12:54:21.291404228 +0000 UTC
gc-pause-total: 17.063536ms
gc-pause: 538379
gc-pause-end: 1729774461291404228
num-gc: 98
num-forced-gc: 0
gc-cpu-fraction: 0.0007043950901580298
enable-gc: true
debug-gc: false
