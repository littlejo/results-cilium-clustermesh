top - 12:54:16 up 30 min,  0 users,  load average: 0.29, 0.34, 0.20
Tasks:  10 total,   2 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 19.4 us, 48.4 sy,  0.0 ni, 29.0 id,  0.0 wa,  0.0 hi,  3.2 si,  0.0 st
MiB Mem :   3836.2 total,    286.4 free,   1053.5 used,   2496.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2601.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 287528  78492 S  12.5   7.3   1:05.58 cilium-+
   3307 root      20   0 1243764  19336  13824 R  12.5   0.5   0:00.02 hubble
   3217 root      20   0 1240432  15708  10832 S   6.2   0.4   0:00.03 cilium-+
    394 root      20   0 1229744   9040   2924 S   0.0   0.2   0:04.36 cilium-+
   3211 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3222 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
   3223 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3278 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3296 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
   3302 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
