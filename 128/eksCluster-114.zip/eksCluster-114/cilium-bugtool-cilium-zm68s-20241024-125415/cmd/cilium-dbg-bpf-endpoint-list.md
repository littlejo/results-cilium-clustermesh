IP ADDRESS         LOCAL ENDPOINT INFO
10.114.0.84:0      (localhost)                                                                                        
10.114.0.79:0      id=347   sec_id=7595293 flags=0x0000 ifindex=22  mac=F6:67:EF:B5:82:9B nodemac=46:5D:7F:CC:B1:D6   
10.114.0.232:0     id=1458  sec_id=7556809 flags=0x0000 ifindex=20  mac=32:B6:95:87:EB:20 nodemac=D2:31:2D:82:F7:4C   
10.114.0.162:0     id=945   sec_id=7550890 flags=0x0000 ifindex=12  mac=4A:E5:45:DF:E1:EC nodemac=5E:C4:0C:82:96:0C   
172.31.147.61:0    (localhost)                                                                                        
10.114.0.7:0       id=337   sec_id=4     flags=0x0000 ifindex=10  mac=2E:C9:F1:D8:61:3E nodemac=06:49:E9:4B:80:23     
172.31.147.106:0   (localhost)                                                                                        
10.114.0.185:0     id=2187  sec_id=7550890 flags=0x0000 ifindex=14  mac=02:87:28:17:5D:6F nodemac=72:1F:B6:E0:51:52   
10.114.0.143:0     id=417   sec_id=7554089 flags=0x0000 ifindex=24  mac=52:42:0C:D4:20:0D nodemac=F2:A4:FF:BC:64:C9   
10.114.0.208:0     id=616   sec_id=7552227 flags=0x0000 ifindex=18  mac=0A:C5:16:8C:40:ED nodemac=8A:71:B5:52:98:EF   
