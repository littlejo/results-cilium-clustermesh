Total: 589
TCP:   3519 (estab 316, closed 3184, orphaned 0, timewait 2718)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  335       323       12       
INET	  345       329       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                  Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                           127.0.0.1:42301      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=43)) ino:32166 sk:1 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.202.14%ens5:68         0.0.0.0:*    uid:192 ino:108387 sk:2 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                             0.0.0.0:8472       0.0.0.0:*    ino:31247 sk:3 cgroup:/ <->                                                  
UNCONN 0      0                           127.0.0.1:323        0.0.0.0:*    ino:15569 sk:4 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                                [::]:8472          [::]:*    ino:31246 sk:5 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                               [::1]:323           [::]:*    ino:15570 sk:6 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::899:fff:fe95:59d9]%ens5:546           [::]:*    uid:192 ino:14242 sk:7 cgroup:unreachable:bd0 v6only:1 <->                   
