 12:54:21 up 32 min,  0 users,  load average: 0.31, 0.40, 0.23
