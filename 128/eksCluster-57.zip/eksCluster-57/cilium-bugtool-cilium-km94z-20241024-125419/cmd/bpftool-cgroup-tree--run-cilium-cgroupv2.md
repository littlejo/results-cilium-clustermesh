CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod762fb8a9_9890_4aa5_88b0_5f80a98f1750.slice/cri-containerd-dd31f9f8615f3c306ed9aa166aab8ea4e058c74714e597b5fcecce9699620f25.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod762fb8a9_9890_4aa5_88b0_5f80a98f1750.slice/cri-containerd-b664156955983b19e633c0016ed43d4f6b3486886369ad0f7b9217d2e2e6766d.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0065c761_6527_44d7_9901_62003b003a2c.slice/cri-containerd-6f304da049653f7d56f384cf327a187d694280f394d8fb0c3545b10b8699e810.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0065c761_6527_44d7_9901_62003b003a2c.slice/cri-containerd-8e50607e598dcabbbc6927a3da0c42772c83a646d8e425962800f0f0d6bfc49d.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2eaee213_18ad_4103_8629_b75120e23e45.slice/cri-containerd-8a7844e616d6f5ab94bf98cb1722c93df557871814ad992c383f2085099e5bae.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2eaee213_18ad_4103_8629_b75120e23e45.slice/cri-containerd-52525860d831f056a2a09a0678ffd66baa96004c2d76f5195e7a87d60c999fde.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf2737c02_268c_47cc_93a6_d0681550e1f2.slice/cri-containerd-77b54c04d6cf7d4cd875507abdb534f4049152bff42d54898e8ab74588a11a39.scope
    537      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf2737c02_268c_47cc_93a6_d0681550e1f2.slice/cri-containerd-2faa446f397d4061db317cab427f5b92c3c7e596652bbfd0dca4bf9b6b97d21c.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod81eb26dc_0316_4c3b_9f7a_fe3809e00a5a.slice/cri-containerd-414258222e8b91b4cd53ee201c8562ee15e7a111fc301ce7eef136512423a4d8.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod81eb26dc_0316_4c3b_9f7a_fe3809e00a5a.slice/cri-containerd-2d9666eb336628fd50af12432068316c5f7ce1de61cc3e5f44e89c1e0b515aa1.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4642dbed_3534_4b7c_a075_db9238c0ef37.slice/cri-containerd-a9573a2e22d4dd4693462ccc8e9f9e740dd525e41ff74d69abaa0e6f18616f82.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4642dbed_3534_4b7c_a075_db9238c0ef37.slice/cri-containerd-039da2c68ed7c8ada11912d6e24c4b9f64add013249f4272e33050ff0abec224.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb2459815_2ff7_4814_9827_66271cd07cf1.slice/cri-containerd-b1f6673678bda977024446d6387703526c985ce268c44a5403d68f5e5d83a03b.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb2459815_2ff7_4814_9827_66271cd07cf1.slice/cri-containerd-24a6058af79336edd75b6a92f10224894139bce2052b18c3f29dccd165ecfe6f.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1d275436_860c_4989_80a7_7d9a809c19fd.slice/cri-containerd-5fcf45972cf3c5d555a91770e759a6509892c905408c4c0ca17b05f0adef950e.scope
    705      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1d275436_860c_4989_80a7_7d9a809c19fd.slice/cri-containerd-cc7ce10b71aafe5d610dc8db5423b2a8b200978942d5e574cebc506cbdaba3c5.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1d275436_860c_4989_80a7_7d9a809c19fd.slice/cri-containerd-5dcb8f22a5343d0f6710e3c94050a8dc4b32077911a099e00fb1ffae6b5c7890.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10bbefa2_b0a4_403d_b867_9ac6f39ab0bf.slice/cri-containerd-a2bca153034bfb0d8ca439e6570eee6f84038f140dffb3d73a5c50e024036afa.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10bbefa2_b0a4_403d_b867_9ac6f39ab0bf.slice/cri-containerd-611d787ac7bdd554890995a411e49380d65d440431c85dabd849df64b04b7c3e.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10bbefa2_b0a4_403d_b867_9ac6f39ab0bf.slice/cri-containerd-cc275ac7dc48c6bf48236c444e88eab0e9a71d9874666317fb7317df4e06e67f.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10bbefa2_b0a4_403d_b867_9ac6f39ab0bf.slice/cri-containerd-1c3610ef9aa7d2ced4268664ccc17ec64af3be626c0c8403cfb317c0071988b0.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podee6f02fb_ee05_4d35_8df8_3d4ccc65ea64.slice/cri-containerd-2a1ee0120da01061e8696197e45ad2c3b3ef9aae23064beae56bfa942ebf3961.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podee6f02fb_ee05_4d35_8df8_3d4ccc65ea64.slice/cri-containerd-cc969602eb95b0c396469696d4012e266182ea88b9ad2b5982aa64d78f5dd81e.scope
    701      cgroup_device   multi                                          
