35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:48+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T12:21:48+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T12:21:49+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T12:21:49+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T12:21:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T12:21:49+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T12:21:49+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T12:21:53+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:22:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:22:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T12:22:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:28:35+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
485: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:28:35+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 125
486: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:28:35+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
487: sched_cls  name tail_handle_ipv4  tag 92b7342e464782bf  gpl
	loaded_at 2024-10-24T12:28:35+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
510: sched_cls  name tail_ipv4_to_endpoint  tag cb1c9edf25739e32  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,107,41,82,83,80,106,39,108,40,37,38
	btf_id 153
511: sched_cls  name tail_handle_arp  tag ba93f40b8cd59906  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 154
512: sched_cls  name tail_handle_ipv4  tag 79e44f5ed0c46c04  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 155
514: sched_cls  name tail_ipv4_ct_egress  tag 688c24d066b1eadb  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 157
515: sched_cls  name __send_drop_notify  tag 4e71261368283539  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 158
516: sched_cls  name handle_policy  tag 5a88a138e3479408  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,108,82,83,107,41,80,106,39,84,75,40,37,38
	btf_id 159
517: sched_cls  name tail_ipv4_ct_ingress  tag b896af4268104c88  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 160
518: sched_cls  name tail_handle_ipv4_cont  tag 904d283e065838d0  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,107,41,106,82,83,39,76,74,77,108,40,37,38,81
	btf_id 161
519: sched_cls  name cil_from_container  tag fa835ca6587de5ec  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,76
	btf_id 162
520: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 163
521: sched_cls  name tail_ipv4_to_endpoint  tag a999e04f93d9cd62  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,110,41,82,83,80,101,39,109,40,37,38
	btf_id 165
522: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 166
523: sched_cls  name tail_handle_arp  tag 8b6d37498b0919a6  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 167
525: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 169
526: sched_cls  name tail_handle_ipv4  tag fc16bbb5cc0bddea  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 170
527: sched_cls  name handle_policy  tag 894bbd8a4ea547b7  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,109,82,83,110,41,80,101,39,84,75,40,37,38
	btf_id 171
528: sched_cls  name tail_handle_ipv4_cont  tag d3899cd86aa159a9  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,110,41,101,82,83,39,76,74,77,109,40,37,38,81
	btf_id 172
529: sched_cls  name tail_ipv4_ct_ingress  tag ae0ac25ff2a1cea2  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 173
530: sched_cls  name __send_drop_notify  tag a50cb7612ab6161e  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 174
531: sched_cls  name cil_from_container  tag 96a73a259df792a6  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 109,76
	btf_id 175
533: sched_cls  name cil_from_container  tag 7a3bfe9310f5c297  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 178
534: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
537: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
538: sched_cls  name tail_handle_ipv4_cont  tag fc0dd42889af0c9b  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,111,41,100,82,83,39,76,74,77,112,40,37,38,81
	btf_id 179
539: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
542: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
543: sched_cls  name tail_ipv4_to_endpoint  tag 703c6686dd5d3a52  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,111,41,82,83,80,100,39,112,40,37,38
	btf_id 180
544: sched_cls  name handle_policy  tag 3b46544397d54ce6  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,111,41,80,100,39,84,75,40,37,38
	btf_id 181
545: sched_cls  name tail_ipv4_ct_egress  tag 688c24d066b1eadb  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 182
546: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 183
547: sched_cls  name tail_handle_ipv4  tag d3ce272960bf42a5  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 184
548: sched_cls  name tail_ipv4_ct_ingress  tag 0b402ad37ddd35c1  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 185
549: sched_cls  name tail_handle_arp  tag 36b674649668026a  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 186
550: sched_cls  name __send_drop_notify  tag 19b1071d410dba12  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 187
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:28:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
559: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 189
562: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 192
563: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 193
564: sched_cls  name tail_handle_ipv4_from_host  tag 5af090c0ac2130b2  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 194
565: sched_cls  name __send_drop_notify  tag 2658cc25936d6875  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 195
566: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 197
568: sched_cls  name tail_handle_ipv4_from_host  tag 5af090c0ac2130b2  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 199
569: sched_cls  name __send_drop_notify  tag 2658cc25936d6875  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 200
570: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 201
573: sched_cls  name __send_drop_notify  tag 2658cc25936d6875  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
574: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 206
575: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 207
579: sched_cls  name tail_handle_ipv4_from_host  tag 5af090c0ac2130b2  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 211
580: sched_cls  name tail_handle_ipv4_from_host  tag 5af090c0ac2130b2  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 213
581: sched_cls  name __send_drop_notify  tag 2658cc25936d6875  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 214
582: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 215
583: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:28:39+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 216
626: sched_cls  name tail_ipv4_ct_egress  tag e0caec964f26ebc6  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 233
628: sched_cls  name __send_drop_notify  tag c42f1032ea14521d  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 235
629: sched_cls  name tail_handle_ipv4  tag a1a12ffa6d4555e2  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 236
630: sched_cls  name tail_ipv4_to_endpoint  tag 9dd3ea51ab59e3b6  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 237
631: sched_cls  name handle_policy  tag cfacb0fdb9e633be  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 238
632: sched_cls  name tail_handle_ipv4_cont  tag 0d3116f3472d9768  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 239
633: sched_cls  name tail_ipv4_ct_ingress  tag 6ef4a5c55185da64  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 240
634: sched_cls  name tail_handle_arp  tag fbcc4e7e77294a33  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 241
635: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 242
636: sched_cls  name cil_from_container  tag d688ae55c900e26d  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 243
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:41:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
698: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
701: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
702: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
705: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
706: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
709: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
710: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
713: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
714: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
717: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
718: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
721: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
722: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
725: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3256: sched_cls  name tail_ipv4_ct_egress  tag 8e1e86920d2db043  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,621,82,83,622,84
	btf_id 3041
3260: sched_cls  name handle_policy  tag 44c8a0c1489b9bec  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,621,82,83,622,41,80,149,39,84,75,40,37,38
	btf_id 3042
3263: sched_cls  name tail_ipv4_to_endpoint  tag aa5a20980cbaf0f3  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,622,41,82,83,80,149,39,621,40,37,38
	btf_id 3048
3264: sched_cls  name tail_handle_arp  tag 867bc789e2c7e834  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,621
	btf_id 3051
3265: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,621
	btf_id 3052
3266: sched_cls  name cil_from_container  tag cb7e10d4d16a8a7d  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 621,76
	btf_id 3053
3267: sched_cls  name __send_drop_notify  tag 419b73b360e4c978  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3054
3269: sched_cls  name tail_handle_ipv4_cont  tag b78ac1546121a574  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,622,41,149,82,83,39,76,74,77,621,40,37,38,81
	btf_id 3056
3270: sched_cls  name tail_ipv4_ct_ingress  tag 56dd90663250f232  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,621,82,83,622,84
	btf_id 3057
3271: sched_cls  name tail_handle_ipv4  tag 11e73232f03bb1ff  gpl
	loaded_at 2024-10-24T12:51:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,621
	btf_id 3058
3311: sched_cls  name tail_handle_ipv4_cont  tag 50fa7a91adb18e45  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,631,41,145,82,83,39,76,74,77,632,40,37,38,81
	btf_id 3101
3312: sched_cls  name tail_handle_arp  tag 9b9d922421d2500d  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,632
	btf_id 3104
3313: sched_cls  name tail_ipv4_ct_egress  tag 707bd28858264f2c  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,632,82,83,631,84
	btf_id 3105
3314: sched_cls  name handle_policy  tag b024cd441d91b952  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,634,82,83,633,41,80,148,39,84,75,40,37,38
	btf_id 3103
3315: sched_cls  name __send_drop_notify  tag 4717e1e5a51bf2ae  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3107
3316: sched_cls  name handle_policy  tag b3fd14d39937ee22  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,632,82,83,631,41,80,145,39,84,75,40,37,38
	btf_id 3106
3317: sched_cls  name __send_drop_notify  tag d2fe02a46ca79511  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3109
3318: sched_cls  name tail_ipv4_ct_egress  tag c55758a1c5932fa3  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3108
3319: sched_cls  name cil_from_container  tag 6866828518855a2f  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 632,76
	btf_id 3110
3320: sched_cls  name tail_ipv4_to_endpoint  tag c335d316afe1254b  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,633,41,82,83,80,148,39,634,40,37,38
	btf_id 3111
3321: sched_cls  name cil_from_container  tag a0557422ec4194c1  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 634,76
	btf_id 3113
3322: sched_cls  name tail_ipv4_to_endpoint  tag 3d43c13dffe5031e  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,631,41,82,83,80,145,39,632,40,37,38
	btf_id 3112
3324: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,632
	btf_id 3116
3325: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,634
	btf_id 3115
3327: sched_cls  name tail_handle_ipv4_cont  tag d69f743d97a8c49f  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,633,41,148,82,83,39,76,74,77,634,40,37,38,81
	btf_id 3118
3328: sched_cls  name tail_ipv4_ct_ingress  tag 8c811643e6f75125  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,632,82,83,631,84
	btf_id 3119
3329: sched_cls  name tail_handle_ipv4  tag 052b54d876e8a20f  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,632
	btf_id 3121
3330: sched_cls  name tail_ipv4_ct_ingress  tag 86eb211b8e3e5866  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3120
3331: sched_cls  name tail_handle_arp  tag a622bdbf45715903  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,634
	btf_id 3122
3332: sched_cls  name tail_handle_ipv4  tag 661c1ba1803dd2a2  gpl
	loaded_at 2024-10-24T12:51:39+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,634
	btf_id 3123
