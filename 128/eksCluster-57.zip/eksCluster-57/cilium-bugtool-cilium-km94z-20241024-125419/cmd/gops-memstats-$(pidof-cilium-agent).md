alloc: 109.64MB (114968144 bytes)
total-alloc: 3.09GB (3313760992 bytes)
sys: 223.32MB (234169684 bytes)
lookups: 0
mallocs: 75297198
frees: 74331684
heap-alloc: 109.64MB (114968144 bytes)
heap-sys: 176.48MB (185057280 bytes)
heap-idle: 37.72MB (39550976 bytes)
heap-in-use: 138.77MB (145506304 bytes)
heap-released: 5.16MB (5414912 bytes)
heap-objects: 965514
stack-in-use: 35.47MB (37191680 bytes)
stack-sys: 35.47MB (37191680 bytes)
stack-mspan-inuse: 2.17MB (2280000 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 982.78KB (1006369 bytes)
gc-sys: 5.54MB (5805200 bytes)
next-gc: when heap-alloc >= 151.31MB (158664184 bytes)
last-gc: 2024-10-24 12:54:28.988725627 +0000 UTC
gc-pause-total: 27.76716ms
gc-pause: 110875
gc-pause-end: 1729774468988725627
num-gc: 100
num-forced-gc: 0
gc-cpu-fraction: 0.0006226174487945357
enable-gc: true
debug-gc: false
