filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcbedf0f6e7ad1 direct-action not_in_hw id 533 tag 7a3bfe9310f5c297 jited 
