1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:99:0f:95:59:d9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.202.14/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3454sec preferred_lft 3454sec
    inet6 fe80::899:fff:fe95:59d9/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:d3:c2:f0:a3:2d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.206.255/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8d3:c2ff:fef0:a32d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:af:f6:b0:d0:b7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c8af:f6ff:feb0:d0b7/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:18:8e:c9:c6:8c brd ff:ff:ff:ff:ff:ff
    inet 10.57.0.212/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e818:8eff:fec9:c68c/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 92:4f:ff:64:1c:9e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::904f:ffff:fe64:1c9e/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:58:6b:5c:68:42 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::7c58:6bff:fe5c:6842/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcbedf0f6e7ad1@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:b8:81:8c:66:ec brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::38b8:81ff:fe8c:66ec/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcea4654524650@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:68:ee:eb:d6:7f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e868:eeff:feeb:d67f/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc01eb00873fcd@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:d8:8c:d2:12:61 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::8cd8:8cff:fed2:1261/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc74c2f2a9b26c@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:13:fc:5f:78:1e brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::6413:fcff:fe5f:781e/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc64b0e760812f@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:46:20:4c:37:a8 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::e046:20ff:fe4c:37a8/64 scope link 
       valid_lft forever preferred_lft forever
24: lxc273ef6851812@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:0f:c3:05:7a:90 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::200f:c3ff:fe05:7a90/64 scope link 
       valid_lft forever preferred_lft forever
