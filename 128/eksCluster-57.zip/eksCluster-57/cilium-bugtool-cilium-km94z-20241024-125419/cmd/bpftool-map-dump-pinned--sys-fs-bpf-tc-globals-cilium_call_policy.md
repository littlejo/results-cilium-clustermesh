key: 10 00 00 00  value: 20 02 00 00
key: e1 00 00 00  value: 04 02 00 00
key: 0b 01 00 00  value: bc 0c 00 00
key: dd 01 00 00  value: f2 0c 00 00
key: ee 02 00 00  value: f4 0c 00 00
key: d7 08 00 00  value: 0f 02 00 00
key: e8 09 00 00  value: 77 02 00 00
Found 7 elements
