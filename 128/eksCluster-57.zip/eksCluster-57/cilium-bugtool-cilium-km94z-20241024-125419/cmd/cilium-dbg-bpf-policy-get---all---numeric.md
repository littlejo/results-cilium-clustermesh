Endpoint ID: 16
Path: /sys/fs/bpf/tc/globals/cilium_policy_00016

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    279421   2520      0        
Allow    Ingress     1          ANY          NONE         disabled    148063   1698      0        
Allow    Egress      0          ANY          NONE         disabled    71115    699       0        


Endpoint ID: 225
Path: /sys/fs/bpf/tc/globals/cilium_policy_00225

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    287903   2600      0        
Allow    Ingress     1          ANY          NONE         disabled    150088   1724      0        
Allow    Egress      0          ANY          NONE         disabled    69016    680       0        


Endpoint ID: 267
Path: /sys/fs/bpf/tc/globals/cilium_policy_00267

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    378066   4426      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 477
Path: /sys/fs/bpf/tc/globals/cilium_policy_00477

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 750
Path: /sys/fs/bpf/tc/globals/cilium_policy_00750

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1046
Path: /sys/fs/bpf/tc/globals/cilium_policy_01046

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2263
Path: /sys/fs/bpf/tc/globals/cilium_policy_02263

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6240270   77141     0        
Allow    Ingress     1          ANY          NONE         disabled    61138     737       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2536
Path: /sys/fs/bpf/tc/globals/cilium_policy_02536

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6078545   61265     0        
Allow    Ingress     1          ANY          NONE         disabled    5306688   55900     0        
Allow    Egress      0          ANY          NONE         disabled    7200248   70820     0        


