top - 12:54:21 up 32 min,  0 users,  load average: 0.31, 0.40, 0.23
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 14.3 us, 28.6 sy,  0.0 ni, 57.1 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    290.0 free,   1049.5 used,   2496.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2605.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3116 root      20   0 1240432  16396  11164 S   6.7   0.4   0:00.03 cilium-+
      1 root      20   0 1539060 291320  79464 S   0.0   7.4   1:11.91 cilium-+
    394 root      20   0 1229744  10068   3836 S   0.0   0.3   0:04.52 cilium-+
   3066 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3114 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3115 root      20   0 1229000   3776   3104 S   0.0   0.1   0:00.00 gops
   3121 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3130 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3181 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3200 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
