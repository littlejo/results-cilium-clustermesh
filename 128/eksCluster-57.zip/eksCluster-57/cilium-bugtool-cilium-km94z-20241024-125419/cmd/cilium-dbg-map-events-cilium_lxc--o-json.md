{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.449Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.521Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:41.535Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.072Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.102Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.156Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.170Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.199Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.413Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.425Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.475Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.506Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.543Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.151Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.205Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.261Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.274Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.298Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.462Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.475Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.552Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.578Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:51.601Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.094Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.095Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.141Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.148Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.192Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.207Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.232Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.466Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.468Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.524Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.533Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:57.574Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.100Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.108Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.136Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.150Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.199Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.201Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.233Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.532Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.554Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.604Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.629Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.656Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.003Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.049Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.057Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.109Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.132Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.147Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.382Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.415Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.459Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.487Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.513Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.865Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.901Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.911Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.950Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.957Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.230Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.238Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.292Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.297Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.347Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.762Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.773Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.819Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.823Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:12.858Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.058Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.085Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.124Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.153Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.170Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.568Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.595Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.633Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.649Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.675Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.907Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.923Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.962Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:15.989Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.012Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.439Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.522Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.574Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.585Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.585Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.616Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.829Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.846Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.905Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.912Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.942Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.258Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.264Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.315Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.319Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.350Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.568Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.587Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.632Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.655Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:21.672Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.010Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.018Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.066Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.068Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.106Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.412Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.476Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.519Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.527Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.533Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.164Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.167Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.203Z",
  "value": "id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.269Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.276Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.540Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:30.541Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:39.240Z",
  "value": "id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:39.252Z",
  "value": "id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8"
}

