[
  {
    "containers": [
      {
        "cgroup-id": 9982,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1d275436_860c_4989_80a7_7d9a809c19fd.slice/cri-containerd-5dcb8f22a5343d0f6710e3c94050a8dc4b32077911a099e00fb1ffae6b5c7890.scope"
      },
      {
        "cgroup-id": 10066,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1d275436_860c_4989_80a7_7d9a809c19fd.slice/cri-containerd-cc7ce10b71aafe5d610dc8db5423b2a8b200978942d5e574cebc506cbdaba3c5.scope"
      }
    ],
    "ips": [
      "10.57.0.7"
    ],
    "name": "echo-same-node-86d9cc975c-m6wrl",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9814,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podee6f02fb_ee05_4d35_8df8_3d4ccc65ea64.slice/cri-containerd-2a1ee0120da01061e8696197e45ad2c3b3ef9aae23064beae56bfa942ebf3961.scope"
      }
    ],
    "ips": [
      "10.57.0.211"
    ],
    "name": "client-974f6c69d-rjx7r",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9898,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod81eb26dc_0316_4c3b_9f7a_fe3809e00a5a.slice/cri-containerd-2d9666eb336628fd50af12432068316c5f7ce1de61cc3e5f44e89c1e0b515aa1.scope"
      }
    ],
    "ips": [
      "10.57.0.205"
    ],
    "name": "client2-57cf4468f-jkf85",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9142,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10bbefa2_b0a4_403d_b867_9ac6f39ab0bf.slice/cri-containerd-cc275ac7dc48c6bf48236c444e88eab0e9a71d9874666317fb7317df4e06e67f.scope"
      },
      {
        "cgroup-id": 9226,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10bbefa2_b0a4_403d_b867_9ac6f39ab0bf.slice/cri-containerd-1c3610ef9aa7d2ced4268664ccc17ec64af3be626c0c8403cfb317c0071988b0.scope"
      },
      {
        "cgroup-id": 9058,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10bbefa2_b0a4_403d_b867_9ac6f39ab0bf.slice/cri-containerd-a2bca153034bfb0d8ca439e6570eee6f84038f140dffb3d73a5c50e024036afa.scope"
      }
    ],
    "ips": [
      "10.57.0.130"
    ],
    "name": "clustermesh-apiserver-8469fc47b7-f9gct",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7666,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod762fb8a9_9890_4aa5_88b0_5f80a98f1750.slice/cri-containerd-dd31f9f8615f3c306ed9aa166aab8ea4e058c74714e597b5fcecce9699620f25.scope"
      }
    ],
    "ips": [
      "10.57.0.227"
    ],
    "name": "coredns-cc6ccd49c-sg4fz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7582,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf2737c02_268c_47cc_93a6_d0681550e1f2.slice/cri-containerd-2faa446f397d4061db317cab427f5b92c3c7e596652bbfd0dca4bf9b6b97d21c.scope"
      }
    ],
    "ips": [
      "10.57.0.22"
    ],
    "name": "coredns-cc6ccd49c-qhjdq",
    "namespace": "kube-system"
  }
]

