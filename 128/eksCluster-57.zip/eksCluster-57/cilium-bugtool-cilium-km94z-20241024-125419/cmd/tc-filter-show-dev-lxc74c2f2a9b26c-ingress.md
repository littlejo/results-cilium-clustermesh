filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc74c2f2a9b26c direct-action not_in_hw id 3319 tag 6866828518855a2f jited 
