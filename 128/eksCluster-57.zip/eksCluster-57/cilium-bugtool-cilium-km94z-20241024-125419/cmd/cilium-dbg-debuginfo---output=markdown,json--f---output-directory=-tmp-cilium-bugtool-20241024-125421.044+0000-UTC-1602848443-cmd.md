markdown output at /tmp/cilium-bugtool-20241024-125421.044+0000-UTC-1602848443/cmd/cilium-debuginfo-20241024-125451.661+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125421.044+0000-UTC-1602848443/cmd/cilium-debuginfo-20241024-125451.661+0000-UTC.json
