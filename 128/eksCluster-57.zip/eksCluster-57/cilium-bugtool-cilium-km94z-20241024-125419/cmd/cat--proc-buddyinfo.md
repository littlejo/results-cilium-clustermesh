Node 0, zone      DMA    174    133     47     44     14     12      6      4      2      3     38 
Node 0, zone   Normal    605    102      3     13      8      4      3      1      2      3      7 
