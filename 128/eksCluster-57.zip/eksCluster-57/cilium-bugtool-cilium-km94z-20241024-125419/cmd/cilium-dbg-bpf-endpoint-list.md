IP ADDRESS         LOCAL ENDPOINT INFO
10.57.0.205:0      id=477   sec_id=3815889 flags=0x0000 ifindex=22  mac=42:14:2F:31:B9:5C nodemac=E2:46:20:4C:37:A8   
10.57.0.22:0       id=16    sec_id=3847491 flags=0x0000 ifindex=12  mac=A6:D7:5A:48:74:0C nodemac=3A:B8:81:8C:66:EC   
10.57.0.227:0      id=225   sec_id=3847491 flags=0x0000 ifindex=14  mac=F6:AD:D5:99:29:D1 nodemac=EA:68:EE:EB:D6:7F   
10.57.0.211:0      id=750   sec_id=3822030 flags=0x0000 ifindex=20  mac=C2:E0:2E:43:BD:54 nodemac=66:13:FC:5F:78:1E   
10.57.0.212:0      (localhost)                                                                                        
172.31.206.255:0   (localhost)                                                                                        
10.57.0.115:0      id=2263  sec_id=4     flags=0x0000 ifindex=10  mac=E6:EA:36:16:32:3E nodemac=7E:58:6B:5C:68:42     
172.31.202.14:0    (localhost)                                                                                        
10.57.0.130:0      id=2536  sec_id=3829740 flags=0x0000 ifindex=18  mac=8E:F6:16:B7:69:7D nodemac=8E:D8:8C:D2:12:61   
10.57.0.7:0        id=267   sec_id=3828011 flags=0x0000 ifindex=24  mac=36:26:9E:CD:47:A7 nodemac=22:0F:C3:05:7A:90   
