Node 0, zone      DMA      1    130     33     52     26      3     22     19      8      6     33 
Node 0, zone   Normal    731    160      6     23     21      4      1      2      2      2      7 
