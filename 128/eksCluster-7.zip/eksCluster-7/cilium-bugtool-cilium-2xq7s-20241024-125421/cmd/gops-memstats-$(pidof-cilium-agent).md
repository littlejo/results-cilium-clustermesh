alloc: 83.72MB (87781880 bytes)
total-alloc: 3.14GB (3370052128 bytes)
sys: 227.07MB (238101844 bytes)
lookups: 0
mallocs: 76018971
frees: 75357081
heap-alloc: 83.72MB (87781880 bytes)
heap-sys: 180.64MB (189415424 bytes)
heap-idle: 52.16MB (54689792 bytes)
heap-in-use: 128.48MB (134725632 bytes)
heap-released: 10.49MB (11001856 bytes)
heap-objects: 661890
stack-in-use: 35.31MB (37027840 bytes)
stack-sys: 35.31MB (37027840 bytes)
stack-mspan-inuse: 2.13MB (2231360 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 748.14KB (766097 bytes)
gc-sys: 5.52MB (5788792 bytes)
next-gc: when heap-alloc >= 150.57MB (157879208 bytes)
last-gc: 2024-10-24 12:54:41.6553089 +0000 UTC
gc-pause-total: 26.166397ms
gc-pause: 93217
gc-pause-end: 1729774481655308900
num-gc: 103
num-forced-gc: 0
gc-cpu-fraction: 0.0005825249953482784
enable-gc: true
debug-gc: false
