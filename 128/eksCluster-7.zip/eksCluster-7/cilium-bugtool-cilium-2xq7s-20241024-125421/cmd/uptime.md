 12:54:24 up 56 min,  0 users,  load average: 0.82, 0.55, 0.26
