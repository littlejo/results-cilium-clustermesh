IP ADDRESS         LOCAL ENDPOINT INFO
10.7.0.62:0        id=54    sec_id=4     flags=0x0000 ifindex=10  mac=72:6E:B8:D8:3E:99 nodemac=AA:DB:59:C5:D4:F7    
10.7.0.117:0       id=1808  sec_id=567872 flags=0x0000 ifindex=14  mac=0A:D3:AC:F2:80:DD nodemac=36:43:E7:54:7F:01   
172.31.234.14:0    (localhost)                                                                                       
10.7.0.192:0       (localhost)                                                                                       
10.7.0.228:0       id=732   sec_id=567872 flags=0x0000 ifindex=12  mac=96:9D:8F:2D:16:DC nodemac=62:21:6C:0C:4A:77   
10.7.0.87:0        id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE   
172.31.253.200:0   (localhost)                                                                                       
10.7.0.37:0        id=2773  sec_id=554602 flags=0x0000 ifindex=18  mac=32:3C:05:B5:6E:47 nodemac=FA:D9:0C:EE:2F:1E   
10.7.0.254:0       id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89   
10.7.0.122:0       id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB   
