CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5d4bcd2f_09fc_46cf_a6d5_bf4dd3ef5708.slice/cri-containerd-9dd7cfa45cb2db5111d628854be81527da35bb7595f40b07b8e6f4e277bbc1a5.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5d4bcd2f_09fc_46cf_a6d5_bf4dd3ef5708.slice/cri-containerd-4cad11f3a106673815834baa381cd8fd9bc59e37b8cc5cc7ce05e1a1c4120f8c.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfee85b33_6042_4679_b0b2_9da83ccb0db7.slice/cri-containerd-a689b9412d2643abf128a3987867250ef042fc96069bd613bc9fb54adb601a6b.scope
    526      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfee85b33_6042_4679_b0b2_9da83ccb0db7.slice/cri-containerd-c3360e8cf507842be658dbcdb4ddac21dbfeae34eafbcb6110cc81623f065e94.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod59034a2c_d47a_4a7b_8dfb_877c4cddd001.slice/cri-containerd-b055bce26016be2da6cbb67ad4eae73e9899f6fd0d2fc105866253358da539c2.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod59034a2c_d47a_4a7b_8dfb_877c4cddd001.slice/cri-containerd-f01c382ec9c6dd2138e80beedd4915358e26428ccdc8d95d5369cd761c95353a.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd34cd8b5_925b_44ab_bdf4_261837eb7a40.slice/cri-containerd-c9081b8096e3ca5afb84da30d3b150d822ff52350a8bab482441a0669dd6e335.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd34cd8b5_925b_44ab_bdf4_261837eb7a40.slice/cri-containerd-204230eaf839bff181d7bbbdc00093f21f9a16b01b6b665aba311be583589de9.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e1b61e7_a7b1_440a_bcaf_0d46327741c2.slice/cri-containerd-33ef80fba0dd157c360b0ad6e2bfbc6c94db07933d9fd053879a85f6edea8d97.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e1b61e7_a7b1_440a_bcaf_0d46327741c2.slice/cri-containerd-684b7170874042e4515259ad34aa6ea5ac8c2ff14276cb9deafc800844d0a839.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e1b61e7_a7b1_440a_bcaf_0d46327741c2.slice/cri-containerd-18ae7d0c2bee63748d26636868a44d167311fd25dbe122e92b90602438c6bdd4.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e1b61e7_a7b1_440a_bcaf_0d46327741c2.slice/cri-containerd-3ac9e04d2d57ec85e3b7081e3dbec283af72beac9eeb43aaaf877133de30943a.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod452b61af_3cb4_4a28_bc86_47b47e9001e2.slice/cri-containerd-2cd5f2107bdb2c584e2e5adb8d8607efab6b835fcd027e6035a917b93a03263f.scope
    699      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod452b61af_3cb4_4a28_bc86_47b47e9001e2.slice/cri-containerd-0e52d8ed22467797fac1503c6e3d63712b0951e0776ea48655bcb22da254e7be.scope
    707      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5a2a887b_21d6_48eb_902a_7970091a0e03.slice/cri-containerd-d1f4a9df69af8e77c1811ffcafc7f4c45c6cf9fe8f68d440f852076bed108a7d.scope
    703      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5a2a887b_21d6_48eb_902a_7970091a0e03.slice/cri-containerd-f4d7515a8b15df6ea99d5c704e8263b42ea0d2bd7d413676c1062d603761c62c.scope
    711      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b92616e_d34e_4e1f_a981_d1c376a4d47c.slice/cri-containerd-b1b14f72cc3cff093c9226f2ff0a81f45a9e1d8f6555d99a1ecb64c73ac8c8eb.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b92616e_d34e_4e1f_a981_d1c376a4d47c.slice/cri-containerd-fb0128c5517f6c9d8f55b61023f61e4d2ae15795a6c0dee43448e7f5293caeaa.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0d24a71_4cd4_49d2_b0fe_e4b2200f18c0.slice/cri-containerd-e6399579644f5325f1f93d3c5057f7d24f0a2bae1fcd73723135aa708a852af8.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0d24a71_4cd4_49d2_b0fe_e4b2200f18c0.slice/cri-containerd-694ecf56c88257391dac72cb3826d34142e544e5ed2dcaf8b53b9d17a6a21f87.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ba5f9cf_36de_483b_acae_7457b28b58c2.slice/cri-containerd-cf2d2520a25dbaacab99b54b4cf1c90f4b82d1945dac13ac569738f497f48a28.scope
    719      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ba5f9cf_36de_483b_acae_7457b28b58c2.slice/cri-containerd-681fee3315632a8622deb6ede112ceacdd8fd3b6980126961891ba31ea7d9265.scope
    695      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ba5f9cf_36de_483b_acae_7457b28b58c2.slice/cri-containerd-a138651de9c64e283cded4be26b986db80a08f0f4db38bfcadd23396b09a911b.scope
    715      cgroup_device   multi                                          
