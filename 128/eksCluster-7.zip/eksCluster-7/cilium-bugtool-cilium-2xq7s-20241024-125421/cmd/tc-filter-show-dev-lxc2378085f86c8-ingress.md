filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc2378085f86c8 direct-action not_in_hw id 3262 tag 97e3d294ea0410a6 jited 
