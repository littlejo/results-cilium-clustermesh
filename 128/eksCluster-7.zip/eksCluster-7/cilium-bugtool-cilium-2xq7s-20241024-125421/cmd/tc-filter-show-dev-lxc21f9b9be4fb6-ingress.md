filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc21f9b9be4fb6 direct-action not_in_hw id 3320 tag 8ffdf1c89b7bb3bb jited 
