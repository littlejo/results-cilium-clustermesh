{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.402Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:42.406Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.928Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.951Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.985Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.045Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.070Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.274Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.308Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.406Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.417Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:47.450Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.065Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.102Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.129Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.161Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.178Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.452Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.463Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.587Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.603Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:50.672Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.150Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.158Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.199Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.231Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.275Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.285Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.340Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.559Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.572Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.632Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.657Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:56.693Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.342Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.352Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.446Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.488Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.537Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.563Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:01.606Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.795Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.818Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.885Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.909Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:02.937Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.341Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.355Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.419Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.431Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.469Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.655Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.665Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.724Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.738Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.782Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.198Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.219Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.296Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.299Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.332Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.604Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.606Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.675Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.690Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:09.722Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.086Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.129Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.147Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.199Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.217Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.236Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.489Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.546Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.584Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.588Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.592Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.107Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.116Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.153Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.171Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.196Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.427Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.433Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.495Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.522Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.548Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.013Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.124Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.140Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.217Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.249Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.272Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.508Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.515Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.555Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.588Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:20.614Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.942Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.979Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.004Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.041Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.047Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.313Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.343Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.376Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.438Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:24.443Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.736Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.788Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.791Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.861Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.903Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:26.922Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.282Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.315Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.325Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.350Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.372Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.119Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.123Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.173Z",
  "value": "id=447   sec_id=539021 flags=0x0000 ifindex=20  mac=72:37:A7:E7:42:FF nodemac=62:92:B6:FB:8B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.224Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.229Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.510Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:32.524Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:41.315Z",
  "value": "id=2486  sec_id=540191 flags=0x0000 ifindex=24  mac=AE:C3:9D:72:CF:0F nodemac=9A:FA:71:E4:CC:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:41.317Z",
  "value": "id=864   sec_id=525015 flags=0x0000 ifindex=22  mac=0E:17:53:0B:EA:4A nodemac=9A:05:06:C5:0C:EE"
}

