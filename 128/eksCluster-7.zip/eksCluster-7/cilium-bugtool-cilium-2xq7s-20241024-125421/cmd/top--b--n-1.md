top - 12:54:24 up 56 min,  0 users,  load average: 2.99, 1.00, 0.41
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 51.6 us, 41.9 sy,  0.0 ni,  3.2 id,  0.0 wa,  0.0 hi,  3.2 si,  0.0 st
MiB Mem :   3836.2 total,    238.8 free,   1100.9 used,   2496.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2554.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538804 297596  78912 S   6.7   7.6   1:20.59 cilium-+
   3108 root      20   0 1240432  16756  11548 S   6.7   0.4   0:00.03 cilium-+
    396 root      20   0 1229744  10016   3836 S   0.0   0.3   0:04.59 cilium-+
   3091 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   3099 root      20   0 1228744   3716   3040 S   0.0   0.1   0:00.00 gops
   3134 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3152 root      20   0 1228744   3656   2976 S   0.0   0.1   0:00.00 gops
