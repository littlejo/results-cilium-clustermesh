USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3108  0.0  0.4 1240432 16756 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3122  0.0  0.0   6408  1640 ?        R    12:54   0:00  \_ ps auxfw
root        3099  0.0  0.0 1228744 3716 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3091  0.0  0.1 1228744 4040 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  4.4  7.5 1538804 297596 ?      Ssl  12:24   1:20 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.2  0.2 1229744 10016 ?       Sl   12:24   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
