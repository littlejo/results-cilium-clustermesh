Total: 572
TCP:   3515 (estab 312, closed 3184, orphaned 0, timewait 2721)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  331       317       14       
INET	  341       323       18       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.253.200%ens5:68         0.0.0.0:*    uid:192 ino:64539 sk:bdf cgroup:unreachable:bd0 <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:58622 sk:be0 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15595 sk:be1 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:33865      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:58492 sk:be2 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:58621 sk:be3 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15596 sk:be4 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::899:b0ff:fedd:df21]%ens5:546           [::]:*    uid:192 ino:15244 sk:be5 cgroup:unreachable:bd0 v6only:1 <->                   
