[
  {
    "containers": [
      {
        "cgroup-id": 9180,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e1b61e7_a7b1_440a_bcaf_0d46327741c2.slice/cri-containerd-684b7170874042e4515259ad34aa6ea5ac8c2ff14276cb9deafc800844d0a839.scope"
      },
      {
        "cgroup-id": 9096,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e1b61e7_a7b1_440a_bcaf_0d46327741c2.slice/cri-containerd-33ef80fba0dd157c360b0ad6e2bfbc6c94db07933d9fd053879a85f6edea8d97.scope"
      },
      {
        "cgroup-id": 9264,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e1b61e7_a7b1_440a_bcaf_0d46327741c2.slice/cri-containerd-3ac9e04d2d57ec85e3b7081e3dbec283af72beac9eeb43aaaf877133de30943a.scope"
      }
    ],
    "ips": [
      "10.7.0.37"
    ],
    "name": "clustermesh-apiserver-84446fc7f7-w457j",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9852,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod452b61af_3cb4_4a28_bc86_47b47e9001e2.slice/cri-containerd-0e52d8ed22467797fac1503c6e3d63712b0951e0776ea48655bcb22da254e7be.scope"
      }
    ],
    "ips": [
      "10.7.0.87"
    ],
    "name": "client-974f6c69d-4w9h8",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10020,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ba5f9cf_36de_483b_acae_7457b28b58c2.slice/cri-containerd-a138651de9c64e283cded4be26b986db80a08f0f4db38bfcadd23396b09a911b.scope"
      },
      {
        "cgroup-id": 10104,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ba5f9cf_36de_483b_acae_7457b28b58c2.slice/cri-containerd-cf2d2520a25dbaacab99b54b4cf1c90f4b82d1945dac13ac569738f497f48a28.scope"
      }
    ],
    "ips": [
      "10.7.0.254"
    ],
    "name": "echo-same-node-86d9cc975c-jm2tx",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7668,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfee85b33_6042_4679_b0b2_9da83ccb0db7.slice/cri-containerd-c3360e8cf507842be658dbcdb4ddac21dbfeae34eafbcb6110cc81623f065e94.scope"
      }
    ],
    "ips": [
      "10.7.0.228"
    ],
    "name": "coredns-cc6ccd49c-wtmrl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7752,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd34cd8b5_925b_44ab_bdf4_261837eb7a40.slice/cri-containerd-c9081b8096e3ca5afb84da30d3b150d822ff52350a8bab482441a0669dd6e335.scope"
      }
    ],
    "ips": [
      "10.7.0.117"
    ],
    "name": "coredns-cc6ccd49c-jvnxc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9936,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5a2a887b_21d6_48eb_902a_7970091a0e03.slice/cri-containerd-f4d7515a8b15df6ea99d5c704e8263b42ea0d2bd7d413676c1062d603761c62c.scope"
      }
    ],
    "ips": [
      "10.7.0.122"
    ],
    "name": "client2-57cf4468f-mbvzj",
    "namespace": "cilium-test-1"
  }
]

