1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:99:b0:dd:df:21 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.253.200/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2024sec preferred_lft 2024sec
    inet6 fe80::899:b0ff:fedd:df21/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:6f:ba:bc:4f:11 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.234.14/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::86f:baff:febc:4f11/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:5a:84:be:15:23 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2c5a:84ff:febe:1523/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:f1:a0:e0:5e:93 brd ff:ff:ff:ff:ff:ff
    inet 10.7.0.192/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::20f1:a0ff:fee0:5e93/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether da:1f:e2:be:22:17 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d81f:e2ff:febe:2217/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:db:59:c5:d4:f7 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a8db:59ff:fec5:d4f7/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc8b4891a9f1fa@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:21:6c:0c:4a:77 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::6021:6cff:fe0c:4a77/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcc096a4a4e16b@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:43:e7:54:7f:01 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::3443:e7ff:fe54:7f01/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc72046b2d6a4d@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:d9:0c:ee:2f:1e brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::f8d9:cff:feee:2f1e/64 scope link 
       valid_lft forever preferred_lft forever
20: lxc2378085f86c8@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:92:b6:fb:8b:89 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::6092:b6ff:fefb:8b89/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc21f9b9be4fb6@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:05:06:c5:0c:ee brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::9805:6ff:fec5:cee/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcab57d785d5d6@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:fa:71:e4:cc:bb brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::98fa:71ff:fee4:ccbb/64 scope link 
       valid_lft forever preferred_lft forever
