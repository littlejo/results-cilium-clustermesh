key: 36 00 00 00  value: 07 02 00 00
key: bf 01 00 00  value: c9 0c 00 00
key: dc 02 00 00  value: 1f 02 00 00
key: 60 03 00 00  value: fa 0c 00 00
key: 10 07 00 00  value: 00 02 00 00
key: b6 09 00 00  value: 09 0d 00 00
key: d5 0a 00 00  value: 71 02 00 00
Found 7 elements
