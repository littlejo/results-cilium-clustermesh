KEY             VALUE
AgentLiveness   3417366277499
UTimeOffset     3378459134765625
