xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 570
ens6(5) clsact/ingress cil_from_netdev-ens6 id 574
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 562
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 556
cilium_host(7) clsact/egress cil_from_host-cilium_host id 554
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 479
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 520
lxc8b4891a9f1fa(12) clsact/ingress cil_from_container-lxc8b4891a9f1fa id 540
lxcc096a4a4e16b(14) clsact/ingress cil_from_container-lxcc096a4a4e16b id 510
lxc72046b2d6a4d(18) clsact/ingress cil_from_container-lxc72046b2d6a4d id 630
lxc2378085f86c8(20) clsact/ingress cil_from_container-lxc2378085f86c8 id 3262
lxc21f9b9be4fb6(22) clsact/ingress cil_from_container-lxc21f9b9be4fb6 id 3320
lxcab57d785d5d6(24) clsact/ingress cil_from_container-lxcab57d785d5d6 id 3328

flow_dissector:

netfilter:

