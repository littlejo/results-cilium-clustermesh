Endpoint ID: 54
Path: /sys/fs/bpf/tc/globals/cilium_policy_00054

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6216328   77110     0        
Allow    Ingress     1          ANY          NONE         disabled    63182     763       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 447
Path: /sys/fs/bpf/tc/globals/cilium_policy_00447

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    382526   4470      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 732
Path: /sys/fs/bpf/tc/globals/cilium_policy_00732

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    263682   2379      0        
Allow    Ingress     1          ANY          NONE         disabled    173125   1993      0        
Allow    Egress      0          ANY          NONE         disabled    69941    691       0        


Endpoint ID: 864
Path: /sys/fs/bpf/tc/globals/cilium_policy_00864

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1808
Path: /sys/fs/bpf/tc/globals/cilium_policy_01808

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    277110   2501      0        
Allow    Ingress     1          ANY          NONE         disabled    173059   1992      0        
Allow    Egress      0          ANY          NONE         disabled    69853    695       0        


Endpoint ID: 1868
Path: /sys/fs/bpf/tc/globals/cilium_policy_01868

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2486
Path: /sys/fs/bpf/tc/globals/cilium_policy_02486

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2773
Path: /sys/fs/bpf/tc/globals/cilium_policy_02773

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6000370   60820     0        
Allow    Ingress     1          ANY          NONE         disabled    5732982   60715     0        
Allow    Egress      0          ANY          NONE         disabled    7665808   74972     0        


