Node 0, zone      DMA     90     17      1      0      2      1      2      1      1      3     46 
Node 0, zone   Normal    349     55     43     15      9      4      2      1      1      2      8 
