Total: 577
TCP:   4461 (estab 298, closed 4144, orphaned 0, timewait 3683)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  317       306       11       
INET	  327       312       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                   172.31.200.64%ens5:68         0.0.0.0:*    uid:192 ino:64680 sk:f60 cgroup:unreachable:bd0 <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:60293 sk:f61 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:13898 sk:f62 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:34445      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:60116 sk:f63 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:60292 sk:f64 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:13899 sk:f65 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::878:1bff:fefb:2d93]%ens5:546           [::]:*    uid:192 ino:14103 sk:f66 cgroup:unreachable:bd0 v6only:1 <->                   
