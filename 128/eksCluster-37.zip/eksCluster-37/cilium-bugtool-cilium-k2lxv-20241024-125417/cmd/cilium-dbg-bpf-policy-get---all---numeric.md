Endpoint ID: 334
Path: /sys/fs/bpf/tc/globals/cilium_policy_00334

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3464     34        0        
Allow    Ingress     1          ANY          NONE         disabled    158943   1826      0        
Allow    Egress      0          ANY          NONE         disabled    20964    235       0        


Endpoint ID: 378
Path: /sys/fs/bpf/tc/globals/cilium_policy_00378

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 482
Path: /sys/fs/bpf/tc/globals/cilium_policy_00482

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    349426   4073      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1032
Path: /sys/fs/bpf/tc/globals/cilium_policy_01032

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5487080   56593     0        
Allow    Ingress     1          ANY          NONE         disabled    5028385   52877     0        
Allow    Egress      0          ANY          NONE         disabled    5680673   58391     0        


Endpoint ID: 1591
Path: /sys/fs/bpf/tc/globals/cilium_policy_01591

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2349
Path: /sys/fs/bpf/tc/globals/cilium_policy_02349

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2715
Path: /sys/fs/bpf/tc/globals/cilium_policy_02715

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2432     26        0        
Allow    Ingress     1          ANY          NONE         disabled    157549   1805      0        
Allow    Egress      0          ANY          NONE         disabled    19890    221       0        


Endpoint ID: 3568
Path: /sys/fs/bpf/tc/globals/cilium_policy_03568

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6177001   76448     0        
Allow    Ingress     1          ANY          NONE         disabled    61305     740       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


