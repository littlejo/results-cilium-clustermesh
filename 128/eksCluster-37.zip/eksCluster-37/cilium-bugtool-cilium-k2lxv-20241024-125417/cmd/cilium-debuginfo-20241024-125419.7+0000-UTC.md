# Cilium debug information

#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=8) {
  (string) (len=11) "10.37.0.234": (string) (len=45) "cilium-test-1/echo-same-node-86d9cc975c-5h7dv",
  (string) (len=11) "10.37.0.201": (string) (len=6) "router",
  (string) (len=10) "10.37.0.66": (string) (len=6) "health",
  (string) (len=11) "10.37.0.150": (string) (len=35) "kube-system/coredns-cc6ccd49c-jbv8k",
  (string) (len=11) "10.37.0.196": (string) (len=35) "kube-system/coredns-cc6ccd49c-xvs9h",
  (string) (len=11) "10.37.0.233": (string) (len=36) "cilium-test-1/client-974f6c69d-xp8hz",
  (string) (len=11) "10.37.0.232": (string) (len=49) "kube-system/clustermesh-apiserver-8dd778c48-4wt79",
  (string) (len=11) "10.37.0.185": (string) (len=37) "cilium-test-1/client2-57cf4468f-k9x5v"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.200.64": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40023e8580)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001057a40,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001057a40,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=6) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4000af7a20)(frontends:[10.100.3.106]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.Service)(0x4009c0a8f0)(frontends:[10.100.241.43]/ports=[http]/selector=map[name:echo-same-node]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4000da53f0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4000da54a0)(frontends:[10.100.175.29]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4000da5600)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4000af7970)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x400121d920)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x400215da00)(172.31.178.251:443/TCP,172.31.203.205:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x400121d928)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-xdfnq": (*k8s.Endpoints)(0x40010a2410)(172.31.200.64:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x400121d930)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-cxbfw": (*k8s.Endpoints)(0x40020e71e0)(10.37.0.150:53/TCP[eu-west-3b],10.37.0.150:53/UDP[eu-west-3b],10.37.0.150:9153/TCP[eu-west-3b],10.37.0.196:53/TCP[eu-west-3b],10.37.0.196:53/UDP[eu-west-3b],10.37.0.196:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40014bc498)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-g4ctb": (*k8s.Endpoints)(0x400117d930)(10.37.0.232:2379/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.EndpointSlices)(0x4000fde4c8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-7vcj9": (*k8s.Endpoints)(0x4007773040)(10.37.0.234:8080/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40025c68c0)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40023aabe0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4009242150
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40023b2de0,
  gcExited: (chan struct {}) 0x40023b2e40,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4002513200)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001994a00)({
      MetricVec: (*prometheus.MetricVec)(0x4001d341e0)({
       metricMap: (*prometheus.metricMap)(0x4001d34210)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025c50e0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4002513280)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001994a08)({
      MetricVec: (*prometheus.MetricVec)(0x4001d34270)({
       metricMap: (*prometheus.metricMap)(0x4001d342a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025c5140)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4002513300)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001994a10)({
      MetricVec: (*prometheus.MetricVec)(0x4001d34330)({
       metricMap: (*prometheus.metricMap)(0x4001d34360)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025c51a0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4002513380)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001994a18)({
      MetricVec: (*prometheus.MetricVec)(0x4001d343c0)({
       metricMap: (*prometheus.metricMap)(0x4001d343f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025c5200)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4002513400)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001994a20)({
      MetricVec: (*prometheus.MetricVec)(0x4001d34450)({
       metricMap: (*prometheus.metricMap)(0x4001d34480)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025c5260)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4002513480)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001994a28)({
      MetricVec: (*prometheus.MetricVec)(0x4001d344e0)({
       metricMap: (*prometheus.metricMap)(0x4001d34510)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025c52c0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4002513500)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001994a30)({
      MetricVec: (*prometheus.MetricVec)(0x4001d345a0)({
       metricMap: (*prometheus.metricMap)(0x4001d345d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025c5320)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4002513580)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001994a38)({
      MetricVec: (*prometheus.MetricVec)(0x4001d34630)({
       metricMap: (*prometheus.metricMap)(0x4001d34660)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025c5380)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4002513600)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001994a40)({
      MetricVec: (*prometheus.MetricVec)(0x4001d346c0)({
       metricMap: (*prometheus.metricMap)(0x4001d346f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025c53e0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40025c68c0)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40025c7a40)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001d29278)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 353ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Cilium environment keys

```
hubble-drop-events:false
multicast-enabled:false
disable-external-ip-mitigation:false
remove-cilium-node-taints:true
encryption-strict-mode-cidr:
disable-envoy-version-check:false
enable-ingress-controller:false
bpf-lb-service-backend-map-max:0
auto-create-cilium-node-resource:true
enable-cilium-api-server-access:
envoy-secrets-namespace:
mesh-auth-mutual-listener-port:0
enable-envoy-config:false
enable-ipv6:false
monitor-aggregation-flags:all
force-device-detection:false
enable-cilium-endpoint-slice:false
enable-svc-source-range-check:true
devices:
bpf-nat-global-max:524288
preallocate-bpf-maps:false
tofqdns-enable-dns-compression:true
hubble-prefer-ipv6:false
k8s-service-cache-size:128
cni-chaining-mode:none
bpf-ct-timeout-service-tcp:2h13m20s
node-labels:
monitor-aggregation-interval:5s
iptables-random-fully:false
hubble-redact-kafka-apikey:false
egress-gateway-reconciliation-trigger-interval:1s
derive-masq-ip-addr-from-device:
config:
mesh-auth-signal-backoff-duration:1s
log-system-load:false
trace-payloadlen:128
bpf-policy-map-max:16384
l2-announcements-lease-duration:15s
bpf-lb-rss-ipv6-src-cidr:
enable-bpf-tproxy:false
enable-sctp:false
node-port-bind-protection:true
cluster-pool-ipv4-cidr:10.37.0.0/16
enable-ip-masq-agent:false
label-prefix-file:
cgroup-root:/run/cilium/cgroupv2
use-full-tls-context:false
hubble-drop-events-interval:2m0s
ingress-secrets-namespace:
pprof-address:localhost
procfs:/host/proc
enable-ipip-termination:false
encryption-strict-mode-allow-remote-node-identities:false
enable-icmp-rules:true
enable-l7-proxy:true
cni-chaining-target:
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
enable-encryption-strict-mode:false
enable-bbr:false
bpf-lb-mode:snat
enable-policy:default
max-connected-clusters:255
arping-refresh-period:30s
hubble-export-fieldmask:
ipv4-service-range:auto
enable-active-connection-tracking:false
ipv4-range:auto
enable-local-node-route:true
kvstore-max-consecutive-quorum-errors:2
fixed-identity-mapping:
synchronize-k8s-nodes:true
bpf-filter-priority:1
proxy-prometheus-port:0
proxy-portrange-min:10000
monitor-aggregation:medium
local-router-ipv6:
bgp-announce-lb-ip:false
l2-announcements-retry-period:2s
mesh-auth-spire-admin-socket:
enable-node-port:false
enable-host-firewall:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
proxy-xff-num-trusted-hops-egress:0
agent-health-port:9879
bpf-lb-source-range-map-max:0
prepend-iptables-chains:true
disable-endpoint-crd:false
enable-custom-calls:false
cni-log-file:/var/run/cilium/cilium-cni.log
hubble-recorder-sink-queue-size:1024
clustermesh-config:/var/lib/cilium/clustermesh/
clustermesh-ip-identities-sync-timeout:1m0s
enable-cilium-health-api-server-access:
bypass-ip-availability-upon-restore:false
ipam-cilium-node-update-rate:15s
identity-heartbeat-timeout:30m0s
srv6-encap-mode:reduced
set-cilium-is-up-condition:true
proxy-portrange-max:20000
monitor-queue-size:0
clustermesh-sync-timeout:1m0s
bpf-ct-timeout-regular-tcp-syn:1m0s
vlan-bpf-bypass:
hubble-flowlogs-config-path:
max-internal-timer-delay:0s
kube-proxy-replacement-healthz-bind-address:
enable-metrics:true
vtep-endpoint:
read-cni-conf:
enable-k8s-endpoint-slice:true
install-no-conntrack-iptables-rules:false
operator-prometheus-serve-addr::9963
http-idle-timeout:0
endpoint-queue-size:25
bpf-lb-external-clusterip:false
tofqdns-idle-connection-grace-period:0s
enable-tcx:true
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
hubble-export-allowlist:
dnsproxy-socket-linger-timeout:10
hubble-redact-http-urlquery:false
node-port-range:
enable-l2-neigh-discovery:true
iptables-lock-timeout:5s
unmanaged-pod-watcher-interval:15
container-ip-local-reserved-ports:auto
enable-nat46x64-gateway:false
cluster-pool-ipv4-mask-size:24
enable-bandwidth-manager:false
bpf-ct-global-any-max:262144
cluster-health-port:4240
dns-max-ips-per-restored-rule:1000
proxy-max-requests-per-connection:0
enable-ipsec:false
enable-route-mtu-for-cni-chaining:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
kvstore-periodic-sync:5m0s
enable-unreachable-routes:false
bpf-lb-algorithm:random
k8s-require-ipv4-pod-cidr:false
enable-service-topology:false
ipv4-native-routing-cidr:
k8s-client-connection-timeout:30s
nodes-gc-interval:5m0s
agent-liveness-update-interval:1s
enable-l2-pod-announcements:false
max-controller-interval:0
egress-gateway-policy-map-max:16384
vtep-mask:
ipam:cluster-pool
envoy-log:
direct-routing-skip-unreachable:false
allow-localhost:auto
mesh-auth-mutual-connect-timeout:5s
conntrack-gc-max-interval:0s
enable-high-scale-ipcache:false
crd-wait-timeout:5m0s
enable-monitor:true
enable-gateway-api:false
api-rate-limit:
enable-ipv6-masquerade:true
bpf-lb-affinity-map-max:0
local-router-ipv4:
k8s-namespace:kube-system
exclude-local-address:
bpf-ct-global-tcp-max:524288
k8s-client-connection-keep-alive:30s
annotate-k8s-node:false
mesh-auth-queue-size:1024
l2-pod-announcements-interface:
state-dir:/var/run/cilium
k8s-kubeconfig-path:
enable-tracing:false
bpf-ct-timeout-regular-any:1m0s
k8s-client-burst:20
enable-bpf-clock-probe:false
bpf-fragments-map-max:8192
enable-vtep:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
hubble-event-buffer-capacity:4095
enable-ipv4-big-tcp:false
policy-accounting:true
bgp-config-path:/var/lib/cilium/bgp/config.yaml
identity-change-grace-period:5s
hubble-export-file-max-size-mb:10
enable-k8s-networkpolicy:true
dnsproxy-insecure-skip-transparent-mode-check:false
bpf-map-event-buffers:
wireguard-persistent-keepalive:0s
bpf-node-map-max:16384
enable-wireguard-userspace-fallback:false
k8s-sync-timeout:3m0s
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
ipam-default-ip-pool:default
enable-ipv4-masquerade:true
tofqdns-pre-cache:
local-max-addr-scope:252
tofqdns-max-deferred-connection-deletes:10000
bpf-lb-sock-hostns-only:false
bpf-ct-timeout-regular-tcp-fin:10s
enable-runtime-device-detection:true
identity-gc-interval:15m0s
enable-mke:false
enable-ipsec-xfrm-state-caching:true
hubble-export-denylist:
node-port-acceleration:disabled
log-opt:
hubble-export-file-max-backups:5
operator-api-serve-addr:127.0.0.1:9234
bpf-map-dynamic-size-ratio:0.0025
ipv6-node:auto
cmdref:
enable-bgp-control-plane:false
encrypt-interface:
enable-srv6:false
hubble-redact-enabled:false
ipv6-native-routing-cidr:
agent-labels:
exclude-node-label-patterns:
k8s-service-proxy-name:
proxy-connect-timeout:2
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bpf-events-policy-verdict-enabled:true
proxy-max-connection-duration-seconds:0
hubble-disable-tls:false
proxy-admin-port:0
nodeport-addresses:
hubble-skip-unknown-cgroup-ids:true
socket-path:/var/run/cilium/cilium.sock
ipv6-service-range:auto
hubble-drop-events-reasons:auth_required,policy_denied
enable-health-checking:true
enable-health-check-nodeport:true
mesh-auth-gc-interval:5m0s
proxy-idle-timeout-seconds:60
dnsproxy-lock-timeout:500ms
external-envoy-proxy:true
enable-local-redirect-policy:false
identity-allocation-mode:crd
ipsec-key-rotation-duration:5m0s
bpf-root:/sys/fs/bpf
bpf-lb-maglev-table-size:16381
labels:
bpf-lb-sock:false
enable-wireguard:false
bpf-ct-timeout-regular-tcp:2h13m20s
conntrack-gc-interval:0s
bpf-lb-dsr-dispatch:opt
policy-audit-mode:false
enable-pmtu-discovery:false
dnsproxy-lock-count:131
routing-mode:tunnel
dnsproxy-concurrency-processing-grace-period:0s
kvstore:
hubble-export-file-compress:false
use-cilium-internal-ip-for-ipsec:false
bpf-neigh-global-max:524288
envoy-keep-cap-netbindservice:false
enable-ipv4-egress-gateway:false
restore:true
enable-l2-announcements:false
service-no-backend-response:reject
enable-ipv4:true
l2-announcements-renew-deadline:5s
bpf-lb-maglev-map-max:0
dnsproxy-enable-transparent-mode:true
tofqdns-dns-reject-response-code:refused
prometheus-serve-addr:
kvstore-lease-ttl:15m0s
log-driver:
node-port-algorithm:random
proxy-gid:1337
custom-cni-conf:false
http-retry-timeout:0
bpf-events-trace-enabled:true
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-endpoint-health-checking:true
disable-iptables-feeder-rules:
enable-node-selector-labels:false
k8s-api-server:
envoy-base-id:0
ipv4-service-loopback-address:169.254.42.1
enable-bpf-masquerade:false
hubble-socket-path:/var/run/cilium/hubble.sock
hubble-recorder-storage-path:/var/run/cilium/pcaps
ipsec-key-file:
egress-masquerade-interfaces:ens+
bpf-lb-sock-terminate-pod-connections:false
enable-identity-mark:true
hubble-metrics-server:
metrics:
bpf-auth-map-max:524288
hubble-redact-http-headers-allow:
bpf-lb-map-max:65536
hubble-event-queue-size:0
allow-icmp-frag-needed:true
endpoint-gc-interval:5m0s
bpf-ct-timeout-service-any:1m0s
vtep-cidr:
enable-masquerade-to-route-source:false
version:false
enable-ipsec-encrypted-overlay:false
enable-endpoint-routes:false
dnsproxy-concurrency-limit:0
enable-ipsec-key-watcher:true
enable-hubble:true
static-cnp-path:
http-retry-count:3
kvstore-opt:
cilium-endpoint-gc-interval:5m0s
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
kube-proxy-replacement:false
bpf-lb-service-map-max:0
join-cluster:false
enable-well-known-identities:false
nat-map-stats-entries:32
mesh-auth-rotated-identities-queue-size:1024
set-cilium-node-taints:true
bpf-lb-rss-ipv4-src-cidr:
clustermesh-enable-endpoint-sync:false
lib-dir:/var/lib/cilium
bgp-announce-pod-cidr:false
egress-multi-home-ip-rule-compat:false
controller-group-metrics:
k8s-client-qps:10
http-max-grpc-timeout:0
enable-ipv6-ndp:false
enable-health-check-loadbalancer-ip:false
gops-port:9890
enable-stale-cilium-endpoint-cleanup:true
vtep-mac:
clustermesh-enable-mcs-api:false
ipam-multi-pool-pre-allocation:
k8s-require-ipv6-pod-cidr:false
route-metric:0
http-normalize-path:true
allocator-list-timeout:3m0s
kvstore-connectivity-timeout:2m0s
config-dir:/tmp/cilium/config-map
ip-masq-agent-config-path:/etc/config/ip-masq-agent
dns-policy-unload-on-shutdown:false
ipv4-pod-subnets:
debug:false
hubble-redact-http-headers-deny:
enable-ipv4-fragment-tracking:true
bpf-events-drop-enabled:true
hubble-export-file-path:
ipv6-pod-subnets:
tunnel-port:0
enable-auto-protect-node-port-range:true
enable-recorder:false
enable-k8s-terminating-endpoint:true
policy-trigger-interval:1s
cflags:
ipv4-node:auto
bpf-policy-map-full-reconciliation-interval:15m0s
config-sources:config-map:kube-system/cilium-config
enable-xt-socket-fallback:true
ipv6-range:auto
hubble-metrics:
proxy-xff-num-trusted-hops-ingress:0
pprof-port:6060
envoy-config-retry-interval:15s
tunnel-protocol:vxlan
hubble-redact-http-userinfo:true
ipv6-mcast-device:
cluster-name:cmesh38
enable-host-port:false
pprof:false
hubble-listen-address::4244
cni-exclusive:true
nat-map-stats-interval:30s
bpf-lb-dsr-l4-xlate:frontend
fqdn-regex-compile-lru-size:1024
debug-verbose:
hubble-monitor-events:
mtu:0
ipv6-cluster-alloc-cidr:f00d::/64
datapath-mode:veth
tofqdns-endpoint-max-ip-per-hostname:50
enable-host-legacy-routing:false
tofqdns-proxy-port:0
mesh-auth-enabled:true
endpoint-bpf-prog-watchdog-interval:30s
install-iptables-rules:true
mke-cgroup-mount:
enable-k8s-api-discovery:false
policy-cidr-match-mode:
enable-xdp-prefilter:false
cni-external-routing:false
direct-routing-device:
trace-sock:true
auto-direct-node-routes:false
enable-session-affinity:false
cluster-id:38
bpf-sock-rev-map-max:262144
enable-external-ips:false
bpf-lb-rev-nat-map-max:0
tofqdns-proxy-response-max-delay:100ms
tofqdns-min-ttl:0
enable-hubble-recorder-api:true
encrypt-node:false
enable-k8s:true
policy-queue-size:100
enable-ipv6-big-tcp:false
k8s-heartbeat-timeout:30s
node-port-mode:snat
identity-restore-grace-period:30s
bpf-lb-acceleration:disabled
keep-config:false
bpf-ct-timeout-service-tcp-grace:1m0s
http-request-timeout:3600
certificates-directory:/var/run/cilium/certs
gateway-api-secrets-namespace:
envoy-config-timeout:2m0s
```


#### Service list

```
ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.178.251:443 (active)   
                                         2 => 172.31.203.205:443 (active)   
2    10.100.175.29:443    ClusterIP      1 => 172.31.200.64:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.37.0.150:9153 (active)     
                                         2 => 10.37.0.196:9153 (active)     
4    10.100.0.10:53       ClusterIP      1 => 10.37.0.150:53 (active)       
                                         2 => 10.37.0.196:53 (active)       
5    10.100.3.106:2379    ClusterIP      1 => 10.37.0.232:2379 (active)     
6    10.100.241.43:8080   ClusterIP      1 => 10.37.0.234:8080 (active)     
```

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 34107777                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 34107777                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 34107777                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400dc00000 rw-p 00000000 00:00 0 
400dc00000-4010000000 ---p 00000000 00:00 0 
ffff62c95000-ffff62f4b000 rw-p 00000000 00:00 0 
ffff62f53000-ffff630b4000 rw-p 00000000 00:00 0 
ffff630b4000-ffff630f5000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff630f5000-ffff63136000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff63136000-ffff63138000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff63138000-ffff6313a000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6313a000-ffff63701000 rw-p 00000000 00:00 0 
ffff63701000-ffff63801000 rw-p 00000000 00:00 0 
ffff63801000-ffff63812000 rw-p 00000000 00:00 0 
ffff63812000-ffff65812000 rw-p 00000000 00:00 0 
ffff65812000-ffff65892000 ---p 00000000 00:00 0 
ffff65892000-ffff65893000 rw-p 00000000 00:00 0 
ffff65893000-ffff85892000 ---p 00000000 00:00 0 
ffff85892000-ffff85893000 rw-p 00000000 00:00 0 
ffff85893000-ffffa5822000 ---p 00000000 00:00 0 
ffffa5822000-ffffa5823000 rw-p 00000000 00:00 0 
ffffa5823000-ffffa9814000 ---p 00000000 00:00 0 
ffffa9814000-ffffa9815000 rw-p 00000000 00:00 0 
ffffa9815000-ffffaa012000 ---p 00000000 00:00 0 
ffffaa012000-ffffaa013000 rw-p 00000000 00:00 0 
ffffaa013000-ffffaa112000 ---p 00000000 00:00 0 
ffffaa112000-ffffaa172000 rw-p 00000000 00:00 0 
ffffaa172000-ffffaa174000 r--p 00000000 00:00 0                          [vvar]
ffffaa174000-ffffaa175000 r-xp 00000000 00:00 0                          [vdso]
ffffd1547000-ffffd1568000 rw-p 00000000 00:00 0                          [stack]

```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                    IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                      
334        Disabled           Disabled          2534455    k8s:eks.amazonaws.com/component=coredns                                               10.37.0.150   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh38                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=kube-dns                                                                                        
378        Disabled           Disabled          2552834    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.37.0.185   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh38                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client2                                                             
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                               
                                                           k8s:kind=client                                                                                             
                                                           k8s:name=client2                                                                                            
                                                           k8s:other=client                                                                                            
482        Disabled           Disabled          2494625    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.37.0.234   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh38                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node                                                      
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                               
                                                           k8s:kind=echo                                                                                               
                                                           k8s:name=echo-same-node                                                                                     
                                                           k8s:other=echo                                                                                              
1032       Disabled           Disabled          2514859    k8s:app.kubernetes.io/name=clustermesh-apiserver                                      10.37.0.232   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                        
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh38                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                               
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=clustermesh-apiserver                                                                           
1591       Disabled           Disabled          2507919    k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.37.0.233   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh38                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client                                                              
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                               
                                                           k8s:kind=client                                                                                             
                                                           k8s:name=client                                                                                             
2349       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                     ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                       
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                                 
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                  
                                                           reserved:host                                                                                               
2715       Disabled           Disabled          2534455    k8s:eks.amazonaws.com/component=coredns                                               10.37.0.196   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh38                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=kube-dns                                                                                        
3568       Disabled           Disabled          4          reserved:health                                                                       10.37.0.66    ready   
```

#### BPF Policy Get 334

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3464     34        0        
Allow    Ingress     1          ANY          NONE         disabled    158943   1826      0        
Allow    Egress      0          ANY          NONE         disabled    20898    234       0        

```


#### BPF CT List 334

```
Invalid argument: unknown type 334
```


#### Endpoint Get 334

```
[
  {
    "id": 334,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-334-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "33ce602d-f225-4432-8160-ca990f9b7615"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-334",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:51:38.486Z",
            "success-count": 6
          },
          "uuid": "2650fc53-f8f6-41f5-b35d-ca5c500b203a"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-jbv8k",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:26:38.483Z",
            "success-count": 1
          },
          "uuid": "d36771a1-202d-44ed-bd66-ad13da5cce38"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-334",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:41:41.708Z",
            "success-count": 2
          },
          "uuid": "6d469980-5336-4b03-9738-14bf45e32a5b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (334)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:18.623Z",
            "success-count": 168
          },
          "uuid": "08af9805-966f-4896-810b-cc1fd2ce6fa0"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "c617ddfa50fbc18ff78c98bec4f4c466da8d31d90a97a31ad2aa3abfc641592a:eth0",
        "container-id": "c617ddfa50fbc18ff78c98bec4f4c466da8d31d90a97a31ad2aa3abfc641592a",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-jbv8k",
        "pod-name": "kube-system/coredns-cc6ccd49c-jbv8k"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2534455,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.37.0.150",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "8e:b3:18:80:e3:2b",
        "interface-index": 12,
        "interface-name": "lxcf2de17267b88",
        "mac": "32:d2:97:4d:bf:e7"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2534455,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2534455,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 334

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 334

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:43:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:43:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:43:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:35:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:35:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:35:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:35:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:35:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:35:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:35:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:35:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:26:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-24T12:26:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:26:41Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-24T12:26:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:26:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T12:26:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-24T12:26:38Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:26:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T12:26:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:26:38Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:26:38Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2534455

```
ID        LABELS
2534455   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh38
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 378

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 378

```
Invalid argument: unknown type 378
```


#### Endpoint Get 378

```
[
  {
    "id": 378,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-378-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b669b375-f924-47a1-af5d-cc89b56f5523"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-378",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:22.039Z",
            "success-count": 2
          },
          "uuid": "c9ff32a9-5604-4e2a-b959-2b3ba6380741"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client2-57cf4468f-k9x5v",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:22.030Z",
            "success-count": 1
          },
          "uuid": "65b74d0c-2b2a-4d5e-8d9e-74efb19204c4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-378",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:22.109Z",
            "success-count": 1
          },
          "uuid": "a3833cf7-b936-492b-b1b6-a9319416eedb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (378)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:12.063Z",
            "success-count": 37
          },
          "uuid": "cb0aeb81-cde8-475f-8166-1cbb94c98de0"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "aee757db6b569917b9431c3feb0c8693362b8355730a3d8c184d3407a3f791b1:eth0",
        "container-id": "aee757db6b569917b9431c3feb0c8693362b8355730a3d8c184d3407a3f791b1",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client2-57cf4468f-k9x5v",
        "pod-name": "cilium-test-1/client2-57cf4468f-k9x5v"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2552834,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=57cf4468f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:41Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.37.0.185",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "62:5e:3d:ec:4f:cd",
        "interface-index": 22,
        "interface-name": "lxcbedcb7223af4",
        "mac": "66:8a:62:07:6e:3b"
      },
      "policy": {
        "proxy-policy-revision": 129,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2552834,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2552834,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 378

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 378

```
Timestamp              Status   State                   Message
2024-10-24T12:51:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:27Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:27Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added

```


#### Identity get 2552834

```
ID        LABELS
2552834   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh38
          k8s:io.cilium.k8s.policy.serviceaccount=client2
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=client
          k8s:name=client2
          k8s:other=client

```


#### BPF Policy Get 482

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    347384   4049      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 482

```
Invalid argument: unknown type 482
```


#### Endpoint Get 482

```
[
  {
    "id": 482,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-482-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "1735627d-d886-45de-8feb-7c46b98ebf47"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-482",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:22.121Z",
            "success-count": 2
          },
          "uuid": "0c094767-445a-4492-b457-ee7cd5e980ba"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-5h7dv",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:22.119Z",
            "success-count": 1
          },
          "uuid": "b44f521d-032f-4dd8-a9c8-3ff69ab587be"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-482",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:22.162Z",
            "success-count": 1
          },
          "uuid": "7dfac201-b055-469c-8924-f34e68210377"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (482)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:12.173Z",
            "success-count": 37
          },
          "uuid": "9905b6ad-5575-4631-b319-e6dd4c24d582"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "4dcbb184c9c9b318a8d74f6ab4e7babe9851e4323582dc04803d32f37dd64da9:eth0",
        "container-id": "4dcbb184c9c9b318a8d74f6ab4e7babe9851e4323582dc04803d32f37dd64da9",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "echo-same-node-86d9cc975c-5h7dv",
        "pod-name": "cilium-test-1/echo-same-node-86d9cc975c-5h7dv"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2494625,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=86d9cc975c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:32Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns-53",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "dns-udp-53",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "http-8080",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.37.0.234",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "b6:9d:16:7d:bb:dc",
        "interface-index": 24,
        "interface-name": "lxcf9b92545e465",
        "mac": "1e:a4:9d:99:f4:7f"
      },
      "policy": {
        "proxy-policy-revision": 126,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2494625,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 126,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2494625,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 126
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 482

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 482

```
Timestamp              Status   State                   Message
2024-10-24T12:51:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:24Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:49:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:49:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:49:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:49:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:48:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:48:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:48:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests

```


#### Identity get 2494625

```
ID        LABELS
2494625   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh38
          k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=echo
          k8s:name=echo-same-node
          k8s:other=echo

```


#### BPF Policy Get 1032

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5449383   56345     0        
Allow    Ingress     1          ANY          NONE         disabled    5028385   52877     0        
Allow    Egress      0          ANY          NONE         disabled    5650917   58062     0        

```


#### BPF CT List 1032

```
Invalid argument: unknown type 1032
```


#### Endpoint Get 1032

```
[
  {
    "id": 1032,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1032-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ab3d61ac-71d5-4191-b31c-15ed7afb30ca"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1032",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:52:15.303Z",
            "success-count": 3
          },
          "uuid": "55d043a3-5707-443e-ad1d-aff034ee628c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-8dd778c48-4wt79",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:42:15.302Z",
            "success-count": 1
          },
          "uuid": "7bd86d82-01ac-4889-b123-c989b1c83238"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1032",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:42:15.336Z",
            "success-count": 1
          },
          "uuid": "3bf55792-e5d3-45ed-bfd0-465cda40dfea"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1032)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:15.380Z",
            "success-count": 74
          },
          "uuid": "1e670e4c-3a9b-4a0a-a35d-f0e70ab109c6"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "00a7b21f5a4e0e4c125bc10ad0451d9d2f5613a00cf9201ebc365de1219c30f5:eth0",
        "container-id": "00a7b21f5a4e0e4c125bc10ad0451d9d2f5613a00cf9201ebc365de1219c30f5",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-8dd778c48-4wt79",
        "pod-name": "kube-system/clustermesh-apiserver-8dd778c48-4wt79"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2514859,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=8dd778c48"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.37.0.232",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "92:a5:2a:f5:ac:c5",
        "interface-index": 18,
        "interface-name": "lxc2e8d609efb85",
        "mac": "a2:4a:f8:2c:77:2b"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2514859,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2514859,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1032

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1032

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:43:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:43:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:43:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:42:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:42:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:42:15Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:42:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:42:15Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:42:15Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2514859

```
ID        LABELS
2514859   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh38
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1591

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1591

```
Invalid argument: unknown type 1591
```


#### Endpoint Get 1591

```
[
  {
    "id": 1591,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1591-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "864a5b99-a17d-4a03-8e45-4417b12a25f1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1591",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:53:20.470Z",
            "success-count": 2
          },
          "uuid": "592f33ce-0451-4bf3-816f-fd811c6aee15"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client-974f6c69d-xp8hz",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.456Z",
            "success-count": 1
          },
          "uuid": "ff7cfb85-1b05-4e52-a6a4-58860003d6f0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1591",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:48:20.508Z",
            "success-count": 1
          },
          "uuid": "5a71b96f-ebdb-4e65-b3c5-8cacbb5d1cf0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1591)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:20.500Z",
            "success-count": 38
          },
          "uuid": "2b0b6ce8-4393-49f6-8fb4-84ff65727552"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "33a4a39c7f4c13297fe0d13be2c16f962f166a3475433e64d685efde28c59a49:eth0",
        "container-id": "33a4a39c7f4c13297fe0d13be2c16f962f166a3475433e64d685efde28c59a49",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client-974f6c69d-xp8hz",
        "pod-name": "cilium-test-1/client-974f6c69d-xp8hz"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2507919,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=974f6c69d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T12:51:41Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.37.0.233",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ee:2f:1a:17:d1:0f",
        "interface-index": 20,
        "interface-name": "lxcf109154354ca",
        "mac": "26:91:af:7b:95:79"
      },
      "policy": {
        "proxy-policy-revision": 129,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2507919,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2507919,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1591

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1591

```
Timestamp              Status   State                   Message
2024-10-24T12:51:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:27Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:14Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:51:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:51:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:51:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:51:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:51:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:53Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T12:50:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:50:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T12:50:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T12:50:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T12:50:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests

```


#### Identity get 2507919

```
ID        LABELS
2507919   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
          k8s:io.cilium.k8s.policy.cluster=cmesh38
          k8s:io.cilium.k8s.policy.serviceaccount=client
          k8s:io.kubernetes.pod.namespace=cilium-test-1
          k8s:kind=client
          k8s:name=client

```


#### BPF Policy Get 2349

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2349

```
Invalid argument: unknown type 2349
```


#### Endpoint Get 2349

```
[
  {
    "id": 2349,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2349-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "87641283-32b0-494c-8083-06b294f2c79b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2349",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:51:37.250Z",
            "success-count": 6
          },
          "uuid": "2fb3cafa-c741-4305-b881-b364ad441c85"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2349",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:41:38.375Z",
            "success-count": 2
          },
          "uuid": "1aba7c1c-09fc-45e6-ba30-3cea0d84f802"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "12:81:db:1c:ff:ec",
        "interface-name": "cilium_host",
        "mac": "12:81:db:1c:ff:ec"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2349

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2349

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:43:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:43:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:43:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:35:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:35:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:35:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:35:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:35:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:35:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:35:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:35:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:26:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:26:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:26:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:26:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:26:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:26:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:26:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:26:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:26:37Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:26:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:26:37Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:26:37Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 2715

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2432     26        0        
Allow    Ingress     1          ANY          NONE         disabled    157549   1805      0        
Allow    Egress      0          ANY          NONE         disabled    19890    221       0        

```


#### BPF CT List 2715

```
Invalid argument: unknown type 2715
```


#### Endpoint Get 2715

```
[
  {
    "id": 2715,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2715-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5de1512b-6d68-4a22-a8e8-3379521b489c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2715",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:51:38.572Z",
            "success-count": 6
          },
          "uuid": "fe18e3a8-ff70-4451-ace0-9194215ffe21"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-xvs9h",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:26:38.569Z",
            "success-count": 1
          },
          "uuid": "24c8759b-db4d-47ed-ad4e-a939ba404df7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2715",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:41:41.779Z",
            "success-count": 2
          },
          "uuid": "aac75b5a-665f-4982-a9b4-41b9eef780b3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2715)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:54:18.696Z",
            "success-count": 168
          },
          "uuid": "c21acb22-1a8f-4263-ae46-f83043652a39"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "656b3e6142bf20f37f5ed2df3c21770b1a255a711b340244a0d20e06c41a2bd2:eth0",
        "container-id": "656b3e6142bf20f37f5ed2df3c21770b1a255a711b340244a0d20e06c41a2bd2",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-xvs9h",
        "pod-name": "kube-system/coredns-cc6ccd49c-xvs9h"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2534455,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.37.0.196",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "96:ea:ec:43:03:1d",
        "interface-index": 14,
        "interface-name": "lxc75e80a3935c8",
        "mac": "02:97:bb:28:71:7c"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2534455,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2534455,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2715

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2715

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:43:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:43:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:43:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:35:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:35:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:35:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:35:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:35:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:35:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:35:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:35:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:26:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:26:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:26:41Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:26:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:26:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:26:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:26:38Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:26:38Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2534455

```
ID        LABELS
2534455   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh38
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3568

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6178624   76468     0        
Allow    Ingress     1          ANY          NONE         disabled    61305     740       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        

```


#### BPF CT List 3568

```
Invalid argument: unknown type 3568
```


#### Endpoint Get 3568

```
[
  {
    "id": 3568,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3568-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "56f0f3ff-1539-4b8e-a7eb-2b0557439b14"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3568",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:51:38.331Z",
            "success-count": 6
          },
          "uuid": "d6a386fb-96c2-4ae9-bb27-39e7c613d519"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3568",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T12:41:41.708Z",
            "success-count": 2
          },
          "uuid": "3b4af312-e833-4e0a-8f5c-a4c14a516b74"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T12:48:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.37.0.66",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "22:f4:55:69:4a:f9",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "06:f0:52:5c:86:1d"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 129,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 129
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3568

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3568

```
Timestamp              Status   State                   Message
2024-10-24T12:48:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:48:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:48:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:48:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:48:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:48:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:48:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:48:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T12:43:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T12:43:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T12:43:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:43:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:43:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:43:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:43:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:35:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:35:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:35:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:35:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:35:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:35:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:35:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:35:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:26:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T12:26:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T12:26:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T12:26:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T12:26:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T12:26:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T12:26:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T12:26:38Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T12:26:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T12:26:38Z   OK       ready                   Set identity for this endpoint
2024-10-24T12:26:37Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Policy get

```
:
 []
Revision: 129

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.37.0.0/24, 
Allocated addresses:
  10.37.0.150 (kube-system/coredns-cc6ccd49c-jbv8k)
  10.37.0.185 (cilium-test-1/client2-57cf4468f-k9x5v)
  10.37.0.196 (kube-system/coredns-cc6ccd49c-xvs9h)
  10.37.0.201 (router)
  10.37.0.232 (kube-system/clustermesh-apiserver-8dd778c48-4wt79)
  10.37.0.233 (cilium-test-1/client-974f6c69d-xp8hz)
  10.37.0.234 (cilium-test-1/echo-same-node-86d9cc975c-5h7dv)
  10.37.0.66 (health)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 863c5ef5edc52fed
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      177/177 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   45s ago        never        0       no error   
  ct-map-pressure                                                    17s ago        never        0       no error   
  daemon-validate-config                                             20s ago        never        0       no error   
  dns-garbage-collector-job                                          49s ago        never        0       no error   
  endpoint-1032-regeneration-recovery                                never          never        0       no error   
  endpoint-1591-regeneration-recovery                                never          never        0       no error   
  endpoint-2349-regeneration-recovery                                never          never        0       no error   
  endpoint-2715-regeneration-recovery                                never          never        0       no error   
  endpoint-334-regeneration-recovery                                 never          never        0       no error   
  endpoint-3568-regeneration-recovery                                never          never        0       no error   
  endpoint-378-regeneration-recovery                                 never          never        0       no error   
  endpoint-482-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                        2m49s ago      never        0       no error   
  ep-bpf-prog-watchdog                                               17s ago        never        0       no error   
  ipcache-inject-labels                                              47s ago        never        0       no error   
  k8s-heartbeat                                                      20s ago        never        0       no error   
  link-cache                                                         17s ago        never        0       no error   
  local-identity-checkpoint                                          2m27s ago      never        0       no error   
  node-neighbor-link-updater                                         7s ago         never        0       no error   
  remote-etcd-cmesh1                                                 11m15s ago     never        0       no error   
  remote-etcd-cmesh10                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh100                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh101                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh102                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh103                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh104                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh105                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh106                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh107                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh108                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh109                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh11                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh110                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh111                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh112                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh113                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh114                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh115                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh116                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh117                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh118                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh119                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh12                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh120                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh121                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh122                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh123                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh124                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh125                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh126                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh127                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh128                                               11m15s ago     never        0       no error   
  remote-etcd-cmesh13                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh14                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh15                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh16                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh17                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh18                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh19                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh2                                                 11m15s ago     never        0       no error   
  remote-etcd-cmesh20                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh21                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh22                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh23                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh24                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh25                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh26                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh27                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh28                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh29                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh3                                                 11m15s ago     never        0       no error   
  remote-etcd-cmesh30                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh31                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh32                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh33                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh34                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh35                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh36                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh37                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh39                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh4                                                 11m15s ago     never        0       no error   
  remote-etcd-cmesh40                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh41                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh42                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh43                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh44                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh45                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh46                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh47                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh48                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh49                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh5                                                 11m15s ago     never        0       no error   
  remote-etcd-cmesh50                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh51                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh52                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh53                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh54                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh55                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh56                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh57                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh58                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh59                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh6                                                 11m15s ago     never        0       no error   
  remote-etcd-cmesh60                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh61                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh62                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh63                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh64                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh65                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh66                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh67                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh68                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh69                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh7                                                 11m15s ago     never        0       no error   
  remote-etcd-cmesh70                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh71                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh72                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh73                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh74                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh75                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh76                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh77                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh78                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh79                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh8                                                 11m15s ago     never        0       no error   
  remote-etcd-cmesh80                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh81                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh82                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh83                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh84                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh85                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh86                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh87                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh88                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh89                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh9                                                 11m15s ago     never        0       no error   
  remote-etcd-cmesh90                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh91                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh92                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh93                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh94                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh95                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh96                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh97                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh98                                                11m15s ago     never        0       no error   
  remote-etcd-cmesh99                                                11m15s ago     never        0       no error   
  resolve-identity-1032                                              2m9s ago       never        0       no error   
  resolve-identity-1591                                              1m3s ago       never        0       no error   
  resolve-identity-2349                                              2m47s ago      never        0       no error   
  resolve-identity-2715                                              2m45s ago      never        0       no error   
  resolve-identity-334                                               2m45s ago      never        0       no error   
  resolve-identity-3568                                              2m46s ago      never        0       no error   
  resolve-identity-378                                               1m2s ago       never        0       no error   
  resolve-identity-482                                               1m2s ago       never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-xp8hz                6m4s ago       never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-k9x5v               6m2s ago       never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-5h7dv       6m2s ago       never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-8dd778c48-4wt79   12m9s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-jbv8k                 27m45s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-xvs9h                 27m45s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                     27m47s ago     never        0       no error   
  sync-policymap-1032                                                12m9s ago      never        0       no error   
  sync-policymap-1591                                                6m3s ago       never        0       no error   
  sync-policymap-2349                                                12m46s ago     never        0       no error   
  sync-policymap-2715                                                12m42s ago     never        0       no error   
  sync-policymap-334                                                 12m42s ago     never        0       no error   
  sync-policymap-3568                                                12m42s ago     never        0       no error   
  sync-policymap-378                                                 6m2s ago       never        0       no error   
  sync-policymap-482                                                 6m2s ago       never        0       no error   
  sync-to-k8s-ciliumendpoint (1032)                                  9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1591)                                  13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2715)                                  15s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (334)                                   15s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (378)                                   12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (482)                                   12s ago        never        0       no error   
  sync-utime                                                         47s ago        never        0       no error   
  write-cni-file                                                     27m50s ago     never        0       no error   
Proxy Status:            OK, ip 10.37.0.201, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 2490368, max 2555903
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 156.21   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```
