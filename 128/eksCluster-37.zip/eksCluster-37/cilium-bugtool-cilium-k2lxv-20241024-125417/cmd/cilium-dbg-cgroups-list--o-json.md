[
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc725ee41_fff6_42f6_8ecb_0550ee427441.slice/cri-containerd-292b240fc884cd73c2f1337435f91d27548179a18a09151be82a9f6573434a8b.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc725ee41_fff6_42f6_8ecb_0550ee427441.slice/cri-containerd-9df21c0ecc78cf3bc5a9c4140639d2b1c8257c19a63abc7a2cdf3054f6397aaa.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc725ee41_fff6_42f6_8ecb_0550ee427441.slice/cri-containerd-e505d952838fa2fef60a805e944c705ecb895ffdd871841afb2636b3de4acd19.scope"
      }
    ],
    "ips": [
      "10.37.0.232"
    ],
    "name": "clustermesh-apiserver-8dd778c48-4wt79",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7620,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf98813fd_dc8a_431a_92e2_29e8202d6373.slice/cri-containerd-7abfcae7a13bb594e26d41b7d7a6bc4b408d57f9c6f2fdf40b912ee998ba81ff.scope"
      }
    ],
    "ips": [
      "10.37.0.150"
    ],
    "name": "coredns-cc6ccd49c-jbv8k",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7704,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf427bdbc_1e46_4568_8a94_89a0a771491d.slice/cri-containerd-753988bcc0ccbe31c197d45df2b2c63e245644ccc914d6963e58a51082a39348.scope"
      }
    ],
    "ips": [
      "10.37.0.196"
    ],
    "name": "coredns-cc6ccd49c-xvs9h",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c4a5dba_c986_4cbd_b18b_18f04a9b3d31.slice/cri-containerd-27432c1445c281b41a53f3914b3feabd95982376ea911e5ff1a37a3bdc0caebb.scope"
      }
    ],
    "ips": [
      "10.37.0.233"
    ],
    "name": "client-974f6c69d-xp8hz",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4957e479_11f5_4b14_b3b0_d0750b70c770.slice/cri-containerd-820a3cceeb7e958c236728287c326bba2defcd7b3c0a5bda4f5902c66bdd5add.scope"
      },
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4957e479_11f5_4b14_b3b0_d0750b70c770.slice/cri-containerd-a62781635b7bbaf69804065d8d7f63e3ed1e394dbeeb3be621081e7ca611681e.scope"
      }
    ],
    "ips": [
      "10.37.0.234"
    ],
    "name": "echo-same-node-86d9cc975c-5h7dv",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2f1896d6_8d4b_44d1_89a0_3208e979dbd4.slice/cri-containerd-fc97515dbc247df4dcffae708bb34b26999d611325e17baadc15f6ebeab34801.scope"
      }
    ],
    "ips": [
      "10.37.0.185"
    ],
    "name": "client2-57cf4468f-k9x5v",
    "namespace": "cilium-test-1"
  }
]

