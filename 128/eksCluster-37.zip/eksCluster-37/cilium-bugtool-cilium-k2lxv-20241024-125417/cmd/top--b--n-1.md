top - 12:54:19 up 56 min,  0 users,  load average: 0.33, 0.50, 0.27
Tasks:   5 total,   1 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 33.3 us, 23.3 sy,  0.0 ni, 43.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    296.5 free,   1044.1 used,   2495.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2611.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 286864  79288 S  26.7   7.3   1:11.11 cilium-+
   3108 root      20   0 1240432  15732  10768 S   6.7   0.4   0:00.03 cilium-+
    398 root      20   0 1229744  10104   3836 S   0.0   0.3   0:04.49 cilium-+
   3134 root      20   0    6576   2412   2088 R   0.0   0.1   0:00.00 top
   3157 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
