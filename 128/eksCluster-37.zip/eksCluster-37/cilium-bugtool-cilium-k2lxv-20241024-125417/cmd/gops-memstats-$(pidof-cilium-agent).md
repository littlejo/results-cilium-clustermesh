alloc: 79.34MB (83194840 bytes)
total-alloc: 2.98GB (3197336152 bytes)
sys: 227.32MB (238363988 bytes)
lookups: 0
mallocs: 73455175
frees: 72748727
heap-alloc: 79.34MB (83194840 bytes)
heap-sys: 180.75MB (189530112 bytes)
heap-idle: 59.97MB (62881792 bytes)
heap-in-use: 120.78MB (126648320 bytes)
heap-released: 20.90MB (21913600 bytes)
heap-objects: 706448
stack-in-use: 35.25MB (36962304 bytes)
stack-sys: 35.25MB (36962304 bytes)
stack-mspan-inuse: 2.06MB (2160480 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 999.21KB (1023193 bytes)
gc-sys: 5.47MB (5739616 bytes)
next-gc: when heap-alloc >= 146.57MB (153686920 bytes)
last-gc: 2024-10-24 12:54:05.359752523 +0000 UTC
gc-pause-total: 22.064118ms
gc-pause: 136581
gc-pause-end: 1729774445359752523
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.000572143301846687
enable-gc: true
debug-gc: false
