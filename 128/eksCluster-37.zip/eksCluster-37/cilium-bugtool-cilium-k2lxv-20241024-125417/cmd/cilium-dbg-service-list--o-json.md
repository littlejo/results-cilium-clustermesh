[
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "172.31.200.64",
          "nodeName": "ip-172-31-200-64.eu-west-3.compute.internal",
          "port": 4244,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Local",
        "name": "hubble-peer",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.175.29",
        "port": 443,
        "scope": "external"
      },
      "id": 2
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "172.31.200.64",
            "nodeName": "ip-172-31-200-64.eu-west-3.compute.internal",
            "port": 4244,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Local",
          "name": "hubble-peer",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.175.29",
          "port": 443,
          "scope": "external"
        },
        "id": 2
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.37.0.150",
          "nodeName": "ip-172-31-200-64.eu-west-3.compute.internal",
          "port": 9153,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.37.0.196",
          "nodeName": "ip-172-31-200-64.eu-west-3.compute.internal",
          "port": 9153,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.0.10",
        "port": 9153,
        "scope": "external"
      },
      "id": 3
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.37.0.150",
            "nodeName": "ip-172-31-200-64.eu-west-3.compute.internal",
            "port": 9153,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.37.0.196",
            "nodeName": "ip-172-31-200-64.eu-west-3.compute.internal",
            "port": 9153,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.0.10",
          "port": 9153,
          "scope": "external"
        },
        "id": 3
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.37.0.150",
          "nodeName": "ip-172-31-200-64.eu-west-3.compute.internal",
          "port": 53,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.37.0.196",
          "nodeName": "ip-172-31-200-64.eu-west-3.compute.internal",
          "port": 53,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.0.10",
        "port": 53,
        "scope": "external"
      },
      "id": 4
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.37.0.150",
            "nodeName": "ip-172-31-200-64.eu-west-3.compute.internal",
            "port": 53,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.37.0.196",
            "nodeName": "ip-172-31-200-64.eu-west-3.compute.internal",
            "port": 53,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.0.10",
          "port": 53,
          "scope": "external"
        },
        "id": 4
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.37.0.232",
          "nodeName": "ip-172-31-200-64.eu-west-3.compute.internal",
          "port": 2379,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "clustermesh-apiserver",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.3.106",
        "port": 2379,
        "scope": "external"
      },
      "id": 5
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.37.0.232",
            "nodeName": "ip-172-31-200-64.eu-west-3.compute.internal",
            "port": 2379,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "clustermesh-apiserver",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.3.106",
          "port": 2379,
          "scope": "external"
        },
        "id": 5
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.37.0.234",
          "nodeName": "ip-172-31-200-64.eu-west-3.compute.internal",
          "port": 8080,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "echo-same-node",
        "namespace": "cilium-test-1",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.241.43",
        "port": 8080,
        "scope": "external"
      },
      "id": 6
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.37.0.234",
            "nodeName": "ip-172-31-200-64.eu-west-3.compute.internal",
            "port": 8080,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "echo-same-node",
          "namespace": "cilium-test-1",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.241.43",
          "port": 8080,
          "scope": "external"
        },
        "id": 6
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "172.31.178.251",
          "port": 443,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "172.31.203.205",
          "port": 443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kubernetes",
        "namespace": "default",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.0.1",
        "port": 443,
        "scope": "external"
      },
      "id": 1
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "172.31.178.251",
            "port": 443,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "172.31.203.205",
            "port": 443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kubernetes",
          "namespace": "default",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.0.1",
          "port": 443,
          "scope": "external"
        },
        "id": 1
      }
    }
  }
]

