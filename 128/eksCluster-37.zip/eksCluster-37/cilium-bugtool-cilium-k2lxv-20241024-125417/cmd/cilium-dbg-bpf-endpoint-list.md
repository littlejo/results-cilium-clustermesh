IP ADDRESS         LOCAL ENDPOINT INFO
10.37.0.234:0      id=482   sec_id=2494625 flags=0x0000 ifindex=24  mac=1E:A4:9D:99:F4:7F nodemac=B6:9D:16:7D:BB:DC   
10.37.0.66:0       id=3568  sec_id=4     flags=0x0000 ifindex=10  mac=06:F0:52:5C:86:1D nodemac=22:F4:55:69:4A:F9     
172.31.243.255:0   (localhost)                                                                                        
10.37.0.201:0      (localhost)                                                                                        
10.37.0.185:0      id=378   sec_id=2552834 flags=0x0000 ifindex=22  mac=66:8A:62:07:6E:3B nodemac=62:5E:3D:EC:4F:CD   
172.31.200.64:0    (localhost)                                                                                        
10.37.0.150:0      id=334   sec_id=2534455 flags=0x0000 ifindex=12  mac=32:D2:97:4D:BF:E7 nodemac=8E:B3:18:80:E3:2B   
10.37.0.232:0      id=1032  sec_id=2514859 flags=0x0000 ifindex=18  mac=A2:4A:F8:2C:77:2B nodemac=92:A5:2A:F5:AC:C5   
10.37.0.196:0      id=2715  sec_id=2534455 flags=0x0000 ifindex=14  mac=02:97:BB:28:71:7C nodemac=96:EA:EC:43:03:1D   
10.37.0.233:0      id=1591  sec_id=2507919 flags=0x0000 ifindex=20  mac=26:91:AF:7B:95:79 nodemac=EE:2F:1A:17:D1:0F   
