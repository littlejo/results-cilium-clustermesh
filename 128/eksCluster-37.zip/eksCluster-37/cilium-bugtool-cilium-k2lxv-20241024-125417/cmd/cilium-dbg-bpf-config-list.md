KEY             VALUE
AgentLiveness   3368629839446
UTimeOffset     3378459164062500
