1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:78:1b:fb:2d:93 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.200.64/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2042sec preferred_lft 2042sec
    inet6 fe80::878:1bff:fefb:2d93/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:36:09:00:6e:17 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.243.255/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::836:9ff:fe00:6e17/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:f1:f5:9a:0a:ef brd ff:ff:ff:ff:ff:ff
    inet6 fe80::18f1:f5ff:fe9a:aef/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:81:db:1c:ff:ec brd ff:ff:ff:ff:ff:ff
    inet 10.37.0.201/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::1081:dbff:fe1c:ffec/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 4e:17:28:2c:61:37 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4c17:28ff:fe2c:6137/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:f4:55:69:4a:f9 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::20f4:55ff:fe69:4af9/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf2de17267b88@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:b3:18:80:e3:2b brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8cb3:18ff:fe80:e32b/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc75e80a3935c8@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:ea:ec:43:03:1d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::94ea:ecff:fe43:31d/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc2e8d609efb85@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:a5:2a:f5:ac:c5 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::90a5:2aff:fef5:acc5/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcf109154354ca@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:2f:1a:17:d1:0f brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::ec2f:1aff:fe17:d10f/64 scope link 
       valid_lft forever preferred_lft forever
22: lxcbedcb7223af4@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:5e:3d:ec:4f:cd brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::605e:3dff:feec:4fcd/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcf9b92545e465@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:9d:16:7d:bb:dc brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::b49d:16ff:fe7d:bbdc/64 scope link 
       valid_lft forever preferred_lft forever
