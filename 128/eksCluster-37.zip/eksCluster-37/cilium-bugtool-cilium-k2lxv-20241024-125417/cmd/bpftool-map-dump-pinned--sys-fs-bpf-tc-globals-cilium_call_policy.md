key: 4e 01 00 00  value: 1c 02 00 00
key: 7a 01 00 00  value: 05 0d 00 00
key: e2 01 00 00  value: c8 0c 00 00
key: 08 04 00 00  value: 79 02 00 00
key: 37 06 00 00  value: 03 0d 00 00
key: 9b 0a 00 00  value: 03 02 00 00
key: f0 0d 00 00  value: 12 02 00 00
Found 7 elements
