32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T11:58:14+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T11:58:15+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T11:58:15+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T11:58:15+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T11:58:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T11:58:15+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T11:58:15+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T11:58:20+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T11:58:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T11:58:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T11:58:30+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name tail_handle_ipv4  tag ecc6e22675294b2b  gpl
	loaded_at 2024-10-24T12:26:39+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
482: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T12:26:39+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
483: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T12:26:39+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T12:26:39+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
507: sched_cls  name tail_handle_arp  tag 86412ebcfa6c060c  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 153
508: sched_cls  name tail_handle_ipv4_cont  tag f33ed989baa34e34  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 154
510: sched_cls  name tail_ipv4_ct_egress  tag 6e9f71b905207042  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 156
511: sched_cls  name tail_ipv4_ct_ingress  tag f520d39d9407d7d9  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 157
512: sched_cls  name cil_from_container  tag a3df2adde019ad6e  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,76
	btf_id 158
513: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 159
514: sched_cls  name __send_drop_notify  tag 6f95fabc3c18eea3  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 160
515: sched_cls  name handle_policy  tag eac7ab541d2fa32e  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 161
516: sched_cls  name tail_handle_ipv4  tag f112b6ad1378ec50  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 162
517: sched_cls  name tail_ipv4_to_endpoint  tag 4cfedb72bbd831a5  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 163
518: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 165
519: sched_cls  name __send_drop_notify  tag 7c0fe094a820cc9b  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 166
520: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
523: sched_cls  name tail_handle_arp  tag 7ec5e5aa8ed712c1  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 167
524: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
525: sched_cls  name tail_handle_ipv4_cont  tag 28f1542a4f574eea  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,109,41,101,82,83,39,76,74,77,110,40,37,38,81
	btf_id 168
526: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
529: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
530: sched_cls  name handle_policy  tag ed7d21a0d0964e50  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,110,82,83,109,41,80,101,39,84,75,40,37,38
	btf_id 169
531: sched_cls  name tail_handle_ipv4  tag f3e4b2e338cde435  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 170
532: sched_cls  name cil_from_container  tag 713ff2a8430c93f6  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 110,76
	btf_id 171
534: sched_cls  name tail_ipv4_ct_ingress  tag d32bbd3090f09bfd  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 173
535: sched_cls  name tail_ipv4_to_endpoint  tag 57a3080a8e140b64  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,109,41,82,83,80,101,39,110,40,37,38
	btf_id 174
536: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 175
538: sched_cls  name tail_handle_arp  tag b669687241c5a2a1  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 178
539: sched_cls  name tail_handle_ipv4_cont  tag ec6d63fd2af32d40  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,114,41,100,82,83,39,76,74,77,113,40,37,38,81
	btf_id 179
540: sched_cls  name handle_policy  tag 0f6e74b81bcb3c67  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,114,41,80,100,39,84,75,40,37,38
	btf_id 180
541: sched_cls  name tail_ipv4_to_endpoint  tag 771a83fb7c1c20c9  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,114,41,82,83,80,100,39,113,40,37,38
	btf_id 181
542: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 182
543: sched_cls  name __send_drop_notify  tag 920c2f3805de750d  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 183
544: sched_cls  name tail_ipv4_ct_ingress  tag 4c68f58ca89810da  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,114,84
	btf_id 184
545: sched_cls  name cil_from_container  tag 67b48acc7ea8647f  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 185
546: sched_cls  name tail_ipv4_ct_egress  tag 6e9f71b905207042  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,114,84
	btf_id 186
547: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
550: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
551: sched_cls  name tail_handle_ipv4  tag cebdb43ab8d9d4e3  gpl
	loaded_at 2024-10-24T12:26:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 187
552: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:26:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
555: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:26:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
556: sched_cls  name tail_handle_ipv4_from_host  tag 9127933fdc704e8a  gpl
	loaded_at 2024-10-24T12:26:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 189
557: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 190
559: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:26:42+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 192
561: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T12:26:42+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 194
562: sched_cls  name __send_drop_notify  tag 04b3627830d5ccc1  gpl
	loaded_at 2024-10-24T12:26:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 195
565: sched_cls  name __send_drop_notify  tag 04b3627830d5ccc1  gpl
	loaded_at 2024-10-24T12:26:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
566: sched_cls  name tail_handle_ipv4_from_host  tag 9127933fdc704e8a  gpl
	loaded_at 2024-10-24T12:26:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 200
567: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 201
569: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 203
570: sched_cls  name __send_drop_notify  tag 04b3627830d5ccc1  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
571: sched_cls  name tail_handle_ipv4_from_host  tag 9127933fdc704e8a  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 206
572: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 207
575: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 210
577: sched_cls  name __send_drop_notify  tag 04b3627830d5ccc1  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 213
578: sched_cls  name tail_handle_ipv4_from_host  tag 9127933fdc704e8a  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 214
579: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 215
582: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T12:26:43+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 218
624: sched_cls  name tail_ipv4_ct_ingress  tag 8f441fa3ac8654be  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 234
625: sched_cls  name tail_ipv4_to_endpoint  tag a5697ce1755f744c  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,136,41,82,83,80,135,39,137,40,37,38
	btf_id 235
626: sched_cls  name tail_ipv4_ct_egress  tag f9e2402ea77e3878  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 236
627: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,137
	btf_id 237
628: sched_cls  name tail_handle_ipv4_cont  tag 4ec49262627c2d60  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,136,41,135,82,83,39,76,74,77,137,40,37,38,81
	btf_id 238
629: sched_cls  name __send_drop_notify  tag b12174837fef07ee  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 239
630: sched_cls  name cil_from_container  tag 40cda94c532195de  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 137,76
	btf_id 240
631: sched_cls  name tail_handle_arp  tag 8eceb8130c232d7b  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,137
	btf_id 241
632: sched_cls  name tail_handle_ipv4  tag 1ce56043ac18204e  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,137
	btf_id 242
633: sched_cls  name handle_policy  tag fad0a79d36429ebf  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,137,82,83,136,41,80,135,39,84,75,40,37,38
	btf_id 243
634: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
637: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
658: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
661: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:42:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
673: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
676: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
699: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
702: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
703: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
706: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
707: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
710: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
711: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
714: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
715: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
718: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
719: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
722: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T12:48:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3264: sched_cls  name tail_handle_ipv4_cont  tag 35eb8101f4b8195e  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,623,41,152,82,83,39,76,74,77,624,40,37,38,81
	btf_id 3053
3265: sched_cls  name tail_ipv4_ct_egress  tag d85bb8c9cd511879  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,624,82,83,623,84
	btf_id 3054
3266: sched_cls  name cil_from_container  tag ced5b5d63d46e2e4  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 624,76
	btf_id 3055
3268: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,624
	btf_id 3057
3269: sched_cls  name __send_drop_notify  tag 1e2d222f8133890a  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3060
3272: sched_cls  name handle_policy  tag ffff1d9e7d679907  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,624,82,83,623,41,80,152,39,84,75,40,37,38
	btf_id 3061
3275: sched_cls  name tail_ipv4_to_endpoint  tag a348c5cbf5802b64  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,623,41,82,83,80,152,39,624,40,37,38
	btf_id 3064
3276: sched_cls  name tail_handle_arp  tag 5f417d3483fa8a89  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,624
	btf_id 3067
3277: sched_cls  name tail_ipv4_ct_ingress  tag 716d2b711140a42e  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,624,82,83,623,84
	btf_id 3068
3280: sched_cls  name tail_handle_ipv4  tag 74750d9bfdbc957f  gpl
	loaded_at 2024-10-24T12:51:32+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,624
	btf_id 3069
3319: sched_cls  name tail_handle_ipv4  tag aca526ca3627d5f3  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,636
	btf_id 3115
3320: sched_cls  name cil_from_container  tag 6b739ff6b83f4072  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 636,76
	btf_id 3116
3321: sched_cls  name tail_ipv4_to_endpoint  tag a4668ba0bb436416  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,633,41,82,83,80,145,39,634,40,37,38
	btf_id 3114
3322: sched_cls  name tail_handle_arp  tag 67289c70859c260c  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,634
	btf_id 3118
3324: sched_cls  name tail_handle_ipv4_cont  tag 90d0c806be7da299  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,635,41,149,82,83,39,76,74,77,636,40,37,38,81
	btf_id 3117
3325: sched_cls  name tail_ipv4_ct_ingress  tag 91ed10908cb20f2b  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3120
3326: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,634
	btf_id 3122
3327: sched_cls  name cil_from_container  tag cf6a1fb991acfaf7  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 634,76
	btf_id 3123
3328: sched_cls  name tail_ipv4_to_endpoint  tag bf092391ecb86dbc  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,635,41,82,83,80,149,39,636,40,37,38
	btf_id 3121
3329: sched_cls  name tail_handle_arp  tag 6dc87533d8e45e11  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,636
	btf_id 3125
3331: sched_cls  name handle_policy  tag 32ccb6950a8a02e1  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,634,82,83,633,41,80,145,39,84,75,40,37,38
	btf_id 3124
3332: sched_cls  name __send_drop_notify  tag 892a171579f1fdc2  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3128
3333: sched_cls  name handle_policy  tag 35046588448840dd  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,636,82,83,635,41,80,149,39,84,75,40,37,38
	btf_id 3127
3334: sched_cls  name tail_ipv4_ct_egress  tag 9184a500f1846403  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3130
3335: sched_cls  name tail_ipv4_ct_egress  tag 36a97c8f83a0eab0  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,634,82,83,633,84
	btf_id 3129
3336: sched_cls  name __send_drop_notify  tag b9c6dd89f5cb4e76  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 3131
3337: sched_cls  name tail_ipv4_ct_ingress  tag eff157d68078cd82  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,636,82,83,635,84
	btf_id 3133
3338: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,636
	btf_id 3134
3339: sched_cls  name tail_handle_ipv4  tag 10a45d2fecacba13  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,634
	btf_id 3132
3340: sched_cls  name tail_handle_ipv4_cont  tag 78d874a2ae8523c1  gpl
	loaded_at 2024-10-24T12:51:41+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,633,41,145,82,83,39,76,74,77,634,40,37,38,81
	btf_id 3135
