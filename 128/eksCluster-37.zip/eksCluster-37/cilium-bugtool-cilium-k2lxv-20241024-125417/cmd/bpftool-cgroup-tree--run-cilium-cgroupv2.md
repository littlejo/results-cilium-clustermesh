CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf98813fd_dc8a_431a_92e2_29e8202d6373.slice/cri-containerd-7abfcae7a13bb594e26d41b7d7a6bc4b408d57f9c6f2fdf40b912ee998ba81ff.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf98813fd_dc8a_431a_92e2_29e8202d6373.slice/cri-containerd-c617ddfa50fbc18ff78c98bec4f4c466da8d31d90a97a31ad2aa3abfc641592a.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c114af3_2ff7_4faf_b58d_262597cf2332.slice/cri-containerd-b2c6ebac584de6c24b85b0049f45e35b68ce00647ef1d76af11874443ae80943.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c114af3_2ff7_4faf_b58d_262597cf2332.slice/cri-containerd-97e6357e89afa89009f82c005f2a13dd9cdd6653362996e9fc9991cadedb3de2.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b195326_e17c_402a_a013_5ea5c039035b.slice/cri-containerd-7529ad35b0e43a6e7b6fa2213136c23f3f08ac8a04849c80a55796780c6e8acd.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b195326_e17c_402a_a013_5ea5c039035b.slice/cri-containerd-f6a79444456bf1bdbeff65ed4725f44785fbf7b978f8268e550f64d25dcebbd6.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf427bdbc_1e46_4568_8a94_89a0a771491d.slice/cri-containerd-656b3e6142bf20f37f5ed2df3c21770b1a255a711b340244a0d20e06c41a2bd2.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf427bdbc_1e46_4568_8a94_89a0a771491d.slice/cri-containerd-753988bcc0ccbe31c197d45df2b2c63e245644ccc914d6963e58a51082a39348.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc725ee41_fff6_42f6_8ecb_0550ee427441.slice/cri-containerd-e505d952838fa2fef60a805e944c705ecb895ffdd871841afb2636b3de4acd19.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc725ee41_fff6_42f6_8ecb_0550ee427441.slice/cri-containerd-9df21c0ecc78cf3bc5a9c4140639d2b1c8257c19a63abc7a2cdf3054f6397aaa.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc725ee41_fff6_42f6_8ecb_0550ee427441.slice/cri-containerd-00a7b21f5a4e0e4c125bc10ad0451d9d2f5613a00cf9201ebc365de1219c30f5.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc725ee41_fff6_42f6_8ecb_0550ee427441.slice/cri-containerd-292b240fc884cd73c2f1337435f91d27548179a18a09151be82a9f6573434a8b.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2f1896d6_8d4b_44d1_89a0_3208e979dbd4.slice/cri-containerd-fc97515dbc247df4dcffae708bb34b26999d611325e17baadc15f6ebeab34801.scope
    710      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2f1896d6_8d4b_44d1_89a0_3208e979dbd4.slice/cri-containerd-aee757db6b569917b9431c3feb0c8693362b8355730a3d8c184d3407a3f791b1.scope
    702      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod385f0058_4f49_423f_b408_e232d8b9eaed.slice/cri-containerd-00712c3f3cb8a0bb0c470a5ce0e9f7085da44eda384b4cd2ed6a73aefbda56d5.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod385f0058_4f49_423f_b408_e232d8b9eaed.slice/cri-containerd-e3fa1d9ac6b7b59cfb327510b3ef900b20c5341158e9d5308b8c626368dc44ed.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3494d0e_9f92_46c7_8d91_69f5b75742b5.slice/cri-containerd-ea0de3180f12506f031521680988811811a88e241b7eea029e60b9a9e87d5eda.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3494d0e_9f92_46c7_8d91_69f5b75742b5.slice/cri-containerd-f973fe1d18d129dfd9fbeaf7537005cb38be2c54c97609ea7477bd786f86c798.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c4a5dba_c986_4cbd_b18b_18f04a9b3d31.slice/cri-containerd-27432c1445c281b41a53f3914b3feabd95982376ea911e5ff1a37a3bdc0caebb.scope
    714      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c4a5dba_c986_4cbd_b18b_18f04a9b3d31.slice/cri-containerd-33a4a39c7f4c13297fe0d13be2c16f962f166a3475433e64d685efde28c59a49.scope
    676      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4957e479_11f5_4b14_b3b0_d0750b70c770.slice/cri-containerd-4dcbb184c9c9b318a8d74f6ab4e7babe9851e4323582dc04803d32f37dd64da9.scope
    706      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4957e479_11f5_4b14_b3b0_d0750b70c770.slice/cri-containerd-820a3cceeb7e958c236728287c326bba2defcd7b3c0a5bda4f5902c66bdd5add.scope
    722      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4957e479_11f5_4b14_b3b0_d0750b70c770.slice/cri-containerd-a62781635b7bbaf69804065d8d7f63e3ed1e394dbeeb3be621081e7ca611681e.scope
    718      cgroup_device   multi                                          
