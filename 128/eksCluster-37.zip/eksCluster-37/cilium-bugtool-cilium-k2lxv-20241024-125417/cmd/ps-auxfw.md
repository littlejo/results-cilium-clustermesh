USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3108  0.0  0.4 1240432 15732 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3121  0.0  0.0      0     0 ?        R    12:54   0:00  \_ [cat]
root        3122  0.0  0.0   6408  1644 ?        R    12:54   0:00  \_ ps auxfw
root           1  4.2  7.3 1539060 286864 ?      Ssl  12:26   1:11 cilium-agent --config-dir=/tmp/cilium/config-map
root         398  0.2  0.2 1229744 10104 ?       Sl   12:26   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
