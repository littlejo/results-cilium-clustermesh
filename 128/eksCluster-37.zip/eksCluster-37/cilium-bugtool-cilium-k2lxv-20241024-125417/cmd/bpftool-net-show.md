xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 575
ens6(5) clsact/ingress cil_from_netdev-ens6 id 582
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 569
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 559
cilium_host(7) clsact/egress cil_from_host-cilium_host id 561
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 532
lxcf2de17267b88(12) clsact/ingress cil_from_container-lxcf2de17267b88 id 545
lxc75e80a3935c8(14) clsact/ingress cil_from_container-lxc75e80a3935c8 id 512
lxc2e8d609efb85(18) clsact/ingress cil_from_container-lxc2e8d609efb85 id 630
lxcf109154354ca(20) clsact/ingress cil_from_container-lxcf109154354ca id 3327
lxcbedcb7223af4(22) clsact/ingress cil_from_container-lxcbedcb7223af4 id 3320
lxcf9b92545e465(24) clsact/ingress cil_from_container-lxcf9b92545e465 id 3266

flow_dissector:

netfilter:

