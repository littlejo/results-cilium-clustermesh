 12:54:18 up 56 min,  0 users,  load average: 0.33, 0.50, 0.27
