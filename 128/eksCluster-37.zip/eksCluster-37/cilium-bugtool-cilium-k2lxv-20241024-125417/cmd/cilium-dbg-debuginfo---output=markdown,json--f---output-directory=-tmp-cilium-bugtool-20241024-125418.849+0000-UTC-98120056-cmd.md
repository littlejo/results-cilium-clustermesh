markdown output at /tmp/cilium-bugtool-20241024-125418.849+0000-UTC-98120056/cmd/cilium-debuginfo-20241024-125419.7+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125418.849+0000-UTC-98120056/cmd/cilium-debuginfo-20241024-125419.7+0000-UTC.json
