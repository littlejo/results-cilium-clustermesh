key: 0a 00 00 00  value: 0a 25 00 ea 1f 90 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f cb cd 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 25 00 e8 09 4b 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 25 00 c4 23 c1 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f b2 fb 01 bb 00 00  00 00 00 00
key: 03 00 00 00  value: ac 1f c8 40 10 94 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 25 00 96 00 35 00 00  00 00 00 00
key: 04 00 00 00  value: 0a 25 00 96 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 25 00 c4 00 35 00 00  00 00 00 00
Found 9 elements
