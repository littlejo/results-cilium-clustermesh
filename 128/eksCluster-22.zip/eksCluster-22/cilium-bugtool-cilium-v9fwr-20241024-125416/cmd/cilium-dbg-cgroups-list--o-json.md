[
  {
    "containers": [
      {
        "cgroup-id": 9804,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31d4301b_0897_4dff_a0ab_b16ead4d002e.slice/cri-containerd-cdc21ccfe1276637a76424a2c4a7c35a138e5a4964bdb69851f17fcdc7150630.scope"
      }
    ],
    "ips": [
      "10.22.0.155"
    ],
    "name": "client2-57cf4468f-9rlvc",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9132,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod951130a2_1127_4023_b110_000173357237.slice/cri-containerd-c3f388c422c831c1f63173e5fd7e49d1da6c75649a93037e00f13c65b99c0120.scope"
      },
      {
        "cgroup-id": 9048,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod951130a2_1127_4023_b110_000173357237.slice/cri-containerd-c5acdec5c583305427e2265cb7462a048ed2d2a2ae92b90f100acd99f6dca350.scope"
      },
      {
        "cgroup-id": 9216,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod951130a2_1127_4023_b110_000173357237.slice/cri-containerd-99ffe02160c2a0a458ef1a8d58eaa06f3ab2acdeadd797e6b65d7cf70be3ccbb.scope"
      }
    ],
    "ips": [
      "10.22.0.127"
    ],
    "name": "clustermesh-apiserver-6b84ff7fcd-td2tk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7572,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf77fe222_e26f_492c_be87_fac9b348637f.slice/cri-containerd-0af58d491a64704459e0fa896d976f50ba6da76c4389efcf4c7913d9d5b09653.scope"
      }
    ],
    "ips": [
      "10.22.0.74"
    ],
    "name": "coredns-cc6ccd49c-mqwhp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9888,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod27f589cc_2303_4873_b987_33a7b3cd8bc6.slice/cri-containerd-cbabbf06541e16d827a10268a7de35f2e49a523e726478e2c3648c8308cc4566.scope"
      }
    ],
    "ips": [
      "10.22.0.69"
    ],
    "name": "client-974f6c69d-nttms",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9972,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda475318b_8e4f_4ba6_88c7_705daeb0a16d.slice/cri-containerd-52226c025660997a8157f535236eb7251280f839f71096f06b2711c0c4a7425a.scope"
      },
      {
        "cgroup-id": 10056,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda475318b_8e4f_4ba6_88c7_705daeb0a16d.slice/cri-containerd-2c7e0cf53e03e96d2e63d29ede1938e02c9a5d82665118e18316cb0bf8bc2344.scope"
      }
    ],
    "ips": [
      "10.22.0.48"
    ],
    "name": "echo-same-node-86d9cc975c-h8jzp",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 7656,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod41763cc9_1f57_4b1c_9b03_62336452f0ef.slice/cri-containerd-f36c4cddf9f6feed12a081134c822dc15a30377de5bce64a5745c854ca7fbb52.scope"
      }
    ],
    "ips": [
      "10.22.0.172"
    ],
    "name": "coredns-cc6ccd49c-t88kn",
    "namespace": "kube-system"
  }
]

