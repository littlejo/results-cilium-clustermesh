key: a8 00 00 00  value: c9 0c 00 00
key: 1e 02 00 00  value: f8 0c 00 00
key: fb 03 00 00  value: 64 02 00 00
key: e5 06 00 00  value: 0f 02 00 00
key: 29 0a 00 00  value: ff 0c 00 00
key: b2 0a 00 00  value: 15 02 00 00
key: f9 0c 00 00  value: 28 02 00 00
Found 7 elements
