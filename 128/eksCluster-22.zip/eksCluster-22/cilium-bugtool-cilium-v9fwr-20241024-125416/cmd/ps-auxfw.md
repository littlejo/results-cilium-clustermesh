USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3238  0.0  0.0 1229000 3780 ?        Ssl  12:54   0:00 /bin/gops pprof-heap 1
root        3234  0.0  0.4 1240176 16460 ?       Ssl  12:54   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3262  0.0  0.0   6408  1652 ?        R    12:54   0:00  \_ ps auxfw
root        3228  0.0  0.1 1229000 4056 ?        Ssl  12:54   0:00 /bin/gops pprof-cpu 1
root           1  4.4  7.5 1539132 298088 ?      Ssl  12:25   1:15 cilium-agent --config-dir=/tmp/cilium/config-map
root         417  0.2  0.2 1229488 8888 ?        Sl   12:25   0:04 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
