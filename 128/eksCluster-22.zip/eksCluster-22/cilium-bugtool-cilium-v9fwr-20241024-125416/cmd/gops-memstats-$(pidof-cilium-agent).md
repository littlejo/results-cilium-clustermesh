alloc: 91.85MB (96316536 bytes)
total-alloc: 3.17GB (3408918816 bytes)
sys: 219.39MB (230049108 bytes)
lookups: 0
mallocs: 76193496
frees: 75366772
heap-alloc: 91.85MB (96316536 bytes)
heap-sys: 171.05MB (179355648 bytes)
heap-idle: 41.94MB (43974656 bytes)
heap-in-use: 129.11MB (135380992 bytes)
heap-released: 1.50MB (1572864 bytes)
heap-objects: 826724
stack-in-use: 36.91MB (38699008 bytes)
stack-sys: 36.91MB (38699008 bytes)
stack-mspan-inuse: 2.14MB (2246080 bytes)
stack-mspan-sys: 2.83MB (2970240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1004.39KB (1028497 bytes)
gc-sys: 5.50MB (5772264 bytes)
next-gc: when heap-alloc >= 149.42MB (156678824 bytes)
last-gc: 2024-10-24 12:54:28.792448384 +0000 UTC
gc-pause-total: 28.875496ms
gc-pause: 82947
gc-pause-end: 1729774468792448384
num-gc: 103
num-forced-gc: 0
gc-cpu-fraction: 0.0006126988151604174
enable-gc: true
debug-gc: false
