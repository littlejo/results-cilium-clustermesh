top - 12:54:17 up 33 min,  0 users,  load average: 0.56, 0.55, 0.33
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 10.7 us, 28.6 sy,  0.0 ni, 60.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    280.6 free,   1059.0 used,   2496.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2596.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539132 298088  78080 S  13.3   7.6   1:15.63 cilium-+
   3234 root      20   0 1240432  16460  11228 S   6.7   0.4   0:00.03 cilium-+
    417 root      20   0 1229488   8888   2928 S   0.0   0.2   0:04.43 cilium-+
   3228 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   3238 root      20   0 1229000   3780   3104 S   0.0   0.1   0:00.00 gops
   3274 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3292 root      20   0 1228744   3716   3040 S   0.0   0.1   0:00.00 gops
