Endpoint ID: 168
Path: /sys/fs/bpf/tc/globals/cilium_policy_00168

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    377877   4415      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 171
Path: /sys/fs/bpf/tc/globals/cilium_policy_00171

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 542
Path: /sys/fs/bpf/tc/globals/cilium_policy_00542

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1019
Path: /sys/fs/bpf/tc/globals/cilium_policy_01019

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6090297   60203     0        
Allow    Ingress     1          ANY          NONE         disabled    5521784   56574     0        
Allow    Egress      0          ANY          NONE         disabled    5886632   59111     0        


Endpoint ID: 1765
Path: /sys/fs/bpf/tc/globals/cilium_policy_01765

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2686     29        0        
Allow    Ingress     1          ANY          NONE         disabled    163869   1881      0        
Allow    Egress      0          ANY          NONE         disabled    20848    232       0        


Endpoint ID: 2601
Path: /sys/fs/bpf/tc/globals/cilium_policy_02601

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2738
Path: /sys/fs/bpf/tc/globals/cilium_policy_02738

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3210     31        0        
Allow    Ingress     1          ANY          NONE         disabled    164870   1891      0        
Allow    Egress      0          ANY          NONE         disabled    21336    240       0        


Endpoint ID: 3321
Path: /sys/fs/bpf/tc/globals/cilium_policy_03321

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6224784   76926     0        
Allow    Ingress     1          ANY          NONE         disabled    65144     780       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


