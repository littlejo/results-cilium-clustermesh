CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod41763cc9_1f57_4b1c_9b03_62336452f0ef.slice/cri-containerd-f36c4cddf9f6feed12a081134c822dc15a30377de5bce64a5745c854ca7fbb52.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod41763cc9_1f57_4b1c_9b03_62336452f0ef.slice/cri-containerd-ae1ba761e06332d0b39f5d21502a1001376e8288fc21e10bdc040596a26be134.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda3b3240a_c020_4aea_b926_4e6087b56e16.slice/cri-containerd-465a1e4a2de5ca355e88c0ea6b35166dd236fa2237f06cf86e6b500fddcfa5e5.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda3b3240a_c020_4aea_b926_4e6087b56e16.slice/cri-containerd-609f5575971a5a3e69013e9b06155cabec5aa7754dab66839952325ac40d2d50.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf77fe222_e26f_492c_be87_fac9b348637f.slice/cri-containerd-538b5ced87a56b7cb7de6069999f4483bcb2c2c5af9d084739bfbd2494c00766.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf77fe222_e26f_492c_be87_fac9b348637f.slice/cri-containerd-0af58d491a64704459e0fa896d976f50ba6da76c4389efcf4c7913d9d5b09653.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5c21c3d1_3967_43a5_ade6_e620f8796eea.slice/cri-containerd-b9e62164acb727f846a648006a61c468a7eb079e5b2419daf3a8cd758dfa1fe4.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5c21c3d1_3967_43a5_ade6_e620f8796eea.slice/cri-containerd-7ff65d8a41a04a68303080c59823a781dbacc288e09b20dc9005709732d876c9.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda475318b_8e4f_4ba6_88c7_705daeb0a16d.slice/cri-containerd-45294beb28d055cd59ef2b770c39d9faaeb4fd74a4a70f2101c98da5164615aa.scope
    688      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda475318b_8e4f_4ba6_88c7_705daeb0a16d.slice/cri-containerd-2c7e0cf53e03e96d2e63d29ede1938e02c9a5d82665118e18316cb0bf8bc2344.scope
    708      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda475318b_8e4f_4ba6_88c7_705daeb0a16d.slice/cri-containerd-52226c025660997a8157f535236eb7251280f839f71096f06b2711c0c4a7425a.scope
    704      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod951130a2_1127_4023_b110_000173357237.slice/cri-containerd-c5acdec5c583305427e2265cb7462a048ed2d2a2ae92b90f100acd99f6dca350.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod951130a2_1127_4023_b110_000173357237.slice/cri-containerd-b35b82f96c4c9179d85e24b8359a9c25e0ff51003927a8060478df07f6561bc4.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod951130a2_1127_4023_b110_000173357237.slice/cri-containerd-99ffe02160c2a0a458ef1a8d58eaa06f3ab2acdeadd797e6b65d7cf70be3ccbb.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod951130a2_1127_4023_b110_000173357237.slice/cri-containerd-c3f388c422c831c1f63173e5fd7e49d1da6c75649a93037e00f13c65b99c0120.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod27f589cc_2303_4873_b987_33a7b3cd8bc6.slice/cri-containerd-4071ab8cdefbc53df3e8c1be8ad59d4ea85090cba5d4be6ad23dfc242591ffb2.scope
    662      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod27f589cc_2303_4873_b987_33a7b3cd8bc6.slice/cri-containerd-cbabbf06541e16d827a10268a7de35f2e49a523e726478e2c3648c8308cc4566.scope
    696      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f0f0195_9bc2_4e16_b787_4cd2198baa0a.slice/cri-containerd-f158f86cce9e84bca82aea806a633319ce664aea7f106ba0a2a550782252060c.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f0f0195_9bc2_4e16_b787_4cd2198baa0a.slice/cri-containerd-0ea03fe0aae327512195482dc446764e43b1dd053258f00a1e8929d88d6dea40.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod24531775_6f90_431f_a668_4bb79aea6748.slice/cri-containerd-f86c4aa5ded88a827a74223e3d8a750b19a129f9871f56dd66b65ca3e9b4cd47.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod24531775_6f90_431f_a668_4bb79aea6748.slice/cri-containerd-b80c86eb968c138501123325b8915241ad5f0fde0d7a597ad3e46ceebeeda09e.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31d4301b_0897_4dff_a0ab_b16ead4d002e.slice/cri-containerd-7f621ce1b5ee2a3bdadc50eaa93924df6eda3c2739461431e80cf180808d33f4.scope
    692      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31d4301b_0897_4dff_a0ab_b16ead4d002e.slice/cri-containerd-cdc21ccfe1276637a76424a2c4a7c35a138e5a4964bdb69851f17fcdc7150630.scope
    700      cgroup_device   multi                                          
