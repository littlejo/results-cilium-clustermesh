Node 0, zone      DMA    413    111     20     34     21      6      3      0      2      1     40 
Node 0, zone   Normal    114     23     34      2      3      2      1      6      1      2      8 
