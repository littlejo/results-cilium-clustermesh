markdown output at /tmp/cilium-bugtool-20241024-125417.749+0000-UTC-4028254728/cmd/cilium-debuginfo-20241024-125448.604+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125417.749+0000-UTC-4028254728/cmd/cilium-debuginfo-20241024-125448.604+0000-UTC.json
