IP ADDRESS         LOCAL ENDPOINT INFO
10.22.0.172:0      id=2738  sec_id=1529491 flags=0x0000 ifindex=14  mac=92:0A:4F:6D:2E:53 nodemac=62:2E:3D:E3:F1:C6   
10.22.0.74:0       id=1765  sec_id=1529491 flags=0x0000 ifindex=12  mac=7A:F3:88:FF:CB:87 nodemac=76:78:03:6D:3F:34   
10.22.0.18:0       (localhost)                                                                                        
10.22.0.69:0       id=542   sec_id=1512039 flags=0x0000 ifindex=20  mac=52:3F:98:41:56:45 nodemac=1A:84:02:CE:BE:81   
172.31.186.215:0   (localhost)                                                                                        
10.22.0.48:0       id=168   sec_id=1516153 flags=0x0000 ifindex=22  mac=8E:B3:9C:A6:55:F4 nodemac=4E:12:96:98:D4:7E   
10.22.0.155:0      id=2601  sec_id=1529146 flags=0x0000 ifindex=24  mac=46:42:71:A2:DD:33 nodemac=B2:31:36:09:23:C9   
10.22.0.239:0      id=3321  sec_id=4     flags=0x0000 ifindex=10  mac=2A:1D:0F:72:1A:EE nodemac=CA:76:3E:9A:6D:A6     
10.22.0.127:0      id=1019  sec_id=1516940 flags=0x0000 ifindex=18  mac=CE:0D:B7:AD:5F:E4 nodemac=F6:B3:47:86:F3:51   
172.31.176.217:0   (localhost)                                                                                        
