Total: 581
TCP:   4214 (estab 303, closed 3892, orphaned 0, timewait 3426)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  322       312       10       
INET	  332       318       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                  Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                           127.0.0.1:34667      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:28385 sk:e9b fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                 172.31.176.217%ens5:68         0.0.0.0:*    uid:192 ino:89680 sk:e9c cgroup:unreachable:bd0 <->                            
UNCONN 0      0                             0.0.0.0:8472       0.0.0.0:*    ino:29428 sk:e9d cgroup:/ <->                                                  
UNCONN 0      0                           127.0.0.1:323        0.0.0.0:*    ino:15432 sk:e9e cgroup:unreachable:e8e <->                                    
UNCONN 0      0                                [::]:8472          [::]:*    ino:29427 sk:e9f cgroup:/ v6only:1 <->                                         
UNCONN 0      0                               [::1]:323           [::]:*    ino:15433 sk:ea0 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::4e6:bcff:feb2:381]%ens5:546           [::]:*    uid:192 ino:16420 sk:ea1 cgroup:unreachable:bd0 v6only:1 <->                   
