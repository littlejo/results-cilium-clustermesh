xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 499
ens6(5) clsact/ingress cil_from_netdev-ens6 id 506
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 489
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 487
cilium_host(7) clsact/egress cil_from_host-cilium_host id 483
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 536
lxca8bfe9450bd7(12) clsact/ingress cil_from_container-lxca8bfe9450bd7 id 514
lxc4a92ba3ef1f5(14) clsact/ingress cil_from_container-lxc4a92ba3ef1f5 id 540
lxc2540f8cec43e(18) clsact/ingress cil_from_container-lxc2540f8cec43e id 619
lxcf2a5a67dfb89(20) clsact/ingress cil_from_container-lxcf2a5a67dfb89 id 3331
lxce020d980e2b0(22) clsact/ingress cil_from_container-lxce020d980e2b0 id 3265
lxc9f307af17766(24) clsact/ingress cil_from_container-lxc9f307af17766 id 3321

flow_dissector:

netfilter:

