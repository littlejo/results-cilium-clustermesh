filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc9f307af17766 direct-action not_in_hw id 3321 tag efd1a94434abd624 jited 
