key: 08 00 00 00  value: 0a 50 00 93 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 50 00 93 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f b5 f1 10 94 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 50 00 2f 00 35 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 50 00 0c 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 50 00 2f 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f f3 85 01 bb 00 00  00 00 00 00
key: 0c 00 00 00  value: 0a 50 00 df 1f 90 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f a1 03 01 bb 00 00  00 00 00 00
Found 9 elements
