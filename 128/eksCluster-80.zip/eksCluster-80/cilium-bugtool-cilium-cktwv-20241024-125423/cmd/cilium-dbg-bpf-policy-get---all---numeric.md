Endpoint ID: 474
Path: /sys/fs/bpf/tc/globals/cilium_policy_00474

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    382047   4458      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1169
Path: /sys/fs/bpf/tc/globals/cilium_policy_01169

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2438     26        0        
Allow    Ingress     1          ANY          NONE         disabled    141346   1628      0        
Allow    Egress      0          ANY          NONE         disabled    19826    220       0        


Endpoint ID: 1306
Path: /sys/fs/bpf/tc/globals/cilium_policy_01306

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3458     34        0        
Allow    Ingress     1          ANY          NONE         disabled    141109   1620      0        
Allow    Egress      0          ANY          NONE         disabled    19185    212       0        


Endpoint ID: 1428
Path: /sys/fs/bpf/tc/globals/cilium_policy_01428

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1706
Path: /sys/fs/bpf/tc/globals/cilium_policy_01706

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2056
Path: /sys/fs/bpf/tc/globals/cilium_policy_02056

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2400
Path: /sys/fs/bpf/tc/globals/cilium_policy_02400

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6095523   61671     0        
Allow    Ingress     1          ANY          NONE         disabled    5452711   57589     0        
Allow    Egress      0          ANY          NONE         disabled    7430415   72690     0        


Endpoint ID: 2435
Path: /sys/fs/bpf/tc/globals/cilium_policy_02435

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6239766   77125     0        
Allow    Ingress     1          ANY          NONE         disabled    61834     746       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


