alloc: 135.11MB (141675040 bytes)
total-alloc: 3.09GB (3321752912 bytes)
sys: 219.32MB (229975380 bytes)
lookups: 0
mallocs: 75409377
frees: 74018580
heap-alloc: 135.11MB (141675040 bytes)
heap-sys: 172.73MB (181125120 bytes)
heap-idle: 16.86MB (17678336 bytes)
heap-in-use: 155.88MB (163446784 bytes)
heap-released: 4.20MB (4399104 bytes)
heap-objects: 1390797
stack-in-use: 35.22MB (36929536 bytes)
stack-sys: 35.22MB (36929536 bytes)
stack-mspan-inuse: 2.45MB (2565440 bytes)
stack-mspan-sys: 2.79MB (2921280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 984.78KB (1008417 bytes)
gc-sys: 5.52MB (5786672 bytes)
next-gc: when heap-alloc >= 146.43MB (153540040 bytes)
last-gc: 2024-10-24 12:54:17.212100475 +0000 UTC
gc-pause-total: 15.229943ms
gc-pause: 79066
gc-pause-end: 1729774457212100475
num-gc: 99
num-forced-gc: 0
gc-cpu-fraction: 0.0006739335019456199
enable-gc: true
debug-gc: false
