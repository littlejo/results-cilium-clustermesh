markdown output at /tmp/cilium-bugtool-20241024-125424.806+0000-UTC-3250070816/cmd/cilium-debuginfo-20241024-125455.286+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-125424.806+0000-UTC-3250070816/cmd/cilium-debuginfo-20241024-125455.286+0000-UTC.json
