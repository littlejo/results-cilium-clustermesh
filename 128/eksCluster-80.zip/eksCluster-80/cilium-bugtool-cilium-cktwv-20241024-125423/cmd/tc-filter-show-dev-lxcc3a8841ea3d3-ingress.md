filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc3a8841ea3d3 direct-action not_in_hw id 3302 tag 5ab3e7d2bbf913c3 jited 
