1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ad:e0:5a:2d:e5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.181.241/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3490sec preferred_lft 3490sec
    inet6 fe80::4ad:e0ff:fe5a:2de5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:5a:d5:a2:b7:a9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.151.28/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::45a:d5ff:fea2:b7a9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:48:7f:36:07:dc brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b048:7fff:fe36:7dc/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:dc:38:66:2e:ed brd ff:ff:ff:ff:ff:ff
    inet 10.80.0.25/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::dcdc:38ff:fe66:2eed/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3a:54:8a:f5:3a:e9 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3854:8aff:fef5:3ae9/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:0b:9a:0f:95:47 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c00b:9aff:fe0f:9547/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc40096e98f65c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:ac:45:02:b2:1f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b8ac:45ff:fe02:b21f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc453043ab0c75@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:4a:a0:1b:31:cb brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::7c4a:a0ff:fe1b:31cb/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcc615fe57cbaa@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:99:b9:af:87:d3 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::899:b9ff:feaf:87d3/64 scope link 
       valid_lft forever preferred_lft forever
20: lxcdaae8e518c59@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:c0:ad:ad:00:8d brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::54c0:adff:fead:8d/64 scope link 
       valid_lft forever preferred_lft forever
22: lxc3c945f460ca3@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:50:5b:40:1b:20 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::8850:5bff:fe40:1b20/64 scope link 
       valid_lft forever preferred_lft forever
24: lxcc3a8841ea3d3@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:97:39:49:ff:df brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::497:39ff:fe49:ffdf/64 scope link 
       valid_lft forever preferred_lft forever
