CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod334a1f76_387a_449a_a1a9_315d44d8f1aa.slice/cri-containerd-1aa4a00401943f302135e47143f69f1ccb73036ef0991df15f5dd5832636b9d6.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod334a1f76_387a_449a_a1a9_315d44d8f1aa.slice/cri-containerd-18ffbd2a16b6ec45025285da219d79fe64fc297036faff3c8bd9db30b1b81117.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod15326643_0c0f_402e_93ca_b7d4a2c6ad33.slice/cri-containerd-8c06d2e75d5dbb39585515f6b758fa1c5b6f3b85d0040387bfff0face9d01dc1.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod15326643_0c0f_402e_93ca_b7d4a2c6ad33.slice/cri-containerd-2a6715ec635fd7bc1e099d7b794d938df18154c4435badbd7967f4240cb30591.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf7d0db6e_81e2_40d4_ab7a_c78e0112285e.slice/cri-containerd-16be1307b8da9701f4ed0bf08b9dc000d84ec3d05c665667e1badf85456f4f3b.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf7d0db6e_81e2_40d4_ab7a_c78e0112285e.slice/cri-containerd-febc78ebe2c6efe3b3bbde3b583b804a33399dd82d064852f0eea12409b4a950.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36ae570f_9d4b_4f87_8a5b_16fc978fbdcf.slice/cri-containerd-dbb882d2b03cb96882e3baba12136d83af072b6cbad35d04877ee788a93aab53.scope
    525      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36ae570f_9d4b_4f87_8a5b_16fc978fbdcf.slice/cri-containerd-0793ea7a059acd7376b5e17592e45393ecba2d0ed2cf4a28ad20b3e8dd76a452.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa296308_7894_4671_b1dc_2eb9bde6dd56.slice/cri-containerd-b200004d2e685697c77e50d915e0a81959f4b09754eb12b84c16d25ed1b72c23.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa296308_7894_4671_b1dc_2eb9bde6dd56.slice/cri-containerd-3c8344c27f5413af888b568d7d50893201cee0844132ce59df88815f2896e335.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa296308_7894_4671_b1dc_2eb9bde6dd56.slice/cri-containerd-3e2500b23af857e88eecd2b943825938434a661ce6734c9e1e729b4e6bcf607b.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa296308_7894_4671_b1dc_2eb9bde6dd56.slice/cri-containerd-b7708d417cf102d7d1fe910c50c2fafcf8cc2aadaee0fe949c5e035db22433a4.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfffbf8e6_4cdd_4073_9d34_f18be0966951.slice/cri-containerd-fe8f72b4bd1afb9d16beee915280228afccb540f25e9dfce305dd82b7ad638d0.scope
    725      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfffbf8e6_4cdd_4073_9d34_f18be0966951.slice/cri-containerd-c65b4b6155920881e3a0cbd0835878a9febccbcf5ba77e595a3f9a61627c86ca.scope
    721      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfffbf8e6_4cdd_4073_9d34_f18be0966951.slice/cri-containerd-186f5deea417aebc6374ac053f9a5799acaff2e3516392c7a29fe91729787dca.scope
    709      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9110c826_1af0_4242_b2eb_6754ecc01d8b.slice/cri-containerd-b6ec6a5734f08bf5bc72ad4f83e86778e6d763297b2bb0c1dc5502155af4e6d5.scope
    690      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9110c826_1af0_4242_b2eb_6754ecc01d8b.slice/cri-containerd-27c7dee281f1c9fb0d1ef9015869b1ae9576ddad59da4813b2c1fbb2b7153783.scope
    717      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1b65bc87_5e11_47fe_a4bd_6c220113ca1b.slice/cri-containerd-56a48ef985331e77e04246743cbbc8898c33cd8603042011133b80c108219ae1.scope
    694      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1b65bc87_5e11_47fe_a4bd_6c220113ca1b.slice/cri-containerd-ecfd2568d21c91feded49b069146a6b388363272264a83515979c42630c05681.scope
    713      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod143ce663_3c35_4541_8787_535f9cb84bd2.slice/cri-containerd-5bf95d75943028356e823f30855de18eef877a3bf21eb38a7c78c0f8af2d2e13.scope
    113      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod143ce663_3c35_4541_8787_535f9cb84bd2.slice/cri-containerd-1eaaf711763eb48dc309aeec378f48c8d57a8592d8af395028cd3fb9e5633806.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4df2d618_5dc2_457e_a424_fdf8506efd1b.slice/cri-containerd-4f5f3bb83e13fbfffaa02a8dfe902e9afa19986cd1defaa69437a22e2cd18634.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4df2d618_5dc2_457e_a424_fdf8506efd1b.slice/cri-containerd-5f20498f3abc17eae120472444fc6de47653ac77c5b397a0381d5973a9ecb80c.scope
    105      cgroup_device   multi                                          
