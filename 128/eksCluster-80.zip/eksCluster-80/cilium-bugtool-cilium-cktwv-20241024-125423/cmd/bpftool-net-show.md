xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 577
ens6(5) clsact/ingress cil_from_netdev-ens6 id 585
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 569
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 565
cilium_host(7) clsact/egress cil_from_host-cilium_host id 561
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 512
lxc40096e98f65c(12) clsact/ingress cil_from_container-lxc40096e98f65c id 533
lxc453043ab0c75(14) clsact/ingress cil_from_container-lxc453043ab0c75 id 541
lxcc615fe57cbaa(18) clsact/ingress cil_from_container-lxcc615fe57cbaa id 627
lxcdaae8e518c59(20) clsact/ingress cil_from_container-lxcdaae8e518c59 id 3350
lxc3c945f460ca3(22) clsact/ingress cil_from_container-lxc3c945f460ca3 id 3355
lxcc3a8841ea3d3(24) clsact/ingress cil_from_container-lxcc3a8841ea3d3 id 3302

flow_dissector:

netfilter:

