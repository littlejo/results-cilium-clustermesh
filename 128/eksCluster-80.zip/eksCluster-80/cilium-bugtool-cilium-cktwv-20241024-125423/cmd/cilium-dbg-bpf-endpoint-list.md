IP ADDRESS         LOCAL ENDPOINT INFO
10.80.0.25:0       (localhost)                                                                                        
10.80.0.147:0      id=1306  sec_id=5343588 flags=0x0000 ifindex=14  mac=AE:90:A3:9D:0B:52 nodemac=7E:4A:A0:1B:31:CB   
10.80.0.247:0      id=2435  sec_id=4     flags=0x0000 ifindex=10  mac=CE:75:14:B1:88:BA nodemac=C2:0B:9A:0F:95:47     
10.80.0.163:0      id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20   
10.80.0.223:0      id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF   
10.80.0.47:0       id=1169  sec_id=5343588 flags=0x0000 ifindex=12  mac=C2:63:39:CF:75:19 nodemac=BA:AC:45:02:B2:1F   
10.80.0.12:0       id=2400  sec_id=5334201 flags=0x0000 ifindex=18  mac=72:87:3D:48:DB:5D nodemac=0A:99:B9:AF:87:D3   
10.80.0.59:0       id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D   
172.31.151.28:0    (localhost)                                                                                        
172.31.181.241:0   (localhost)                                                                                        
