top - 12:54:25 up 32 min,  0 users,  load average: 0.65, 0.37, 0.20
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 17.2 us, 17.2 sy,  0.0 ni, 62.1 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   3836.2 total,    285.7 free,   1054.2 used,   2496.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2600.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1539060 295528  78812 S   0.0   7.5   1:05.98 cilium-+
    413 root      20   0 1229744   9100   2924 S   0.0   0.2   0:04.38 cilium-+
   3226 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   3231 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   3252 root      20   0 1240432  15380  10576 S   0.0   0.4   0:00.02 cilium-+
   3278 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   3296 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
