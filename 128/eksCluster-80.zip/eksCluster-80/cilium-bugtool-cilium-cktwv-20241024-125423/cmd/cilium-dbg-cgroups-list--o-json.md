[
  {
    "containers": [
      {
        "cgroup-id": 9809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1b65bc87_5e11_47fe_a4bd_6c220113ca1b.slice/cri-containerd-ecfd2568d21c91feded49b069146a6b388363272264a83515979c42630c05681.scope"
      }
    ],
    "ips": [
      "10.80.0.163"
    ],
    "name": "client2-57cf4468f-mlh2w",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9893,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9110c826_1af0_4242_b2eb_6754ecc01d8b.slice/cri-containerd-27c7dee281f1c9fb0d1ef9015869b1ae9576ddad59da4813b2c1fbb2b7153783.scope"
      }
    ],
    "ips": [
      "10.80.0.59"
    ],
    "name": "client-974f6c69d-6qw4f",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 10061,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfffbf8e6_4cdd_4073_9d34_f18be0966951.slice/cri-containerd-fe8f72b4bd1afb9d16beee915280228afccb540f25e9dfce305dd82b7ad638d0.scope"
      },
      {
        "cgroup-id": 9977,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfffbf8e6_4cdd_4073_9d34_f18be0966951.slice/cri-containerd-c65b4b6155920881e3a0cbd0835878a9febccbcf5ba77e595a3f9a61627c86ca.scope"
      }
    ],
    "ips": [
      "10.80.0.223"
    ],
    "name": "echo-same-node-86d9cc975c-zrzlx",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9137,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa296308_7894_4671_b1dc_2eb9bde6dd56.slice/cri-containerd-3c8344c27f5413af888b568d7d50893201cee0844132ce59df88815f2896e335.scope"
      },
      {
        "cgroup-id": 9221,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa296308_7894_4671_b1dc_2eb9bde6dd56.slice/cri-containerd-b7708d417cf102d7d1fe910c50c2fafcf8cc2aadaee0fe949c5e035db22433a4.scope"
      },
      {
        "cgroup-id": 9053,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa296308_7894_4671_b1dc_2eb9bde6dd56.slice/cri-containerd-b200004d2e685697c77e50d915e0a81959f4b09754eb12b84c16d25ed1b72c23.scope"
      }
    ],
    "ips": [
      "10.80.0.12"
    ],
    "name": "clustermesh-apiserver-757647ffcf-xhq2t",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7577,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36ae570f_9d4b_4f87_8a5b_16fc978fbdcf.slice/cri-containerd-0793ea7a059acd7376b5e17592e45393ecba2d0ed2cf4a28ad20b3e8dd76a452.scope"
      }
    ],
    "ips": [
      "10.80.0.47"
    ],
    "name": "coredns-cc6ccd49c-twwh7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7661,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf7d0db6e_81e2_40d4_ab7a_c78e0112285e.slice/cri-containerd-16be1307b8da9701f4ed0bf08b9dc000d84ec3d05c665667e1badf85456f4f3b.scope"
      }
    ],
    "ips": [
      "10.80.0.147"
    ],
    "name": "coredns-cc6ccd49c-rpmrh",
    "namespace": "kube-system"
  }
]

