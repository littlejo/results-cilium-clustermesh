key: da 01 00 00  value: db 0c 00 00
key: 91 04 00 00  value: 11 02 00 00
key: 1a 05 00 00  value: 24 02 00 00
key: 94 05 00 00  value: 15 0d 00 00
key: 08 08 00 00  value: 1a 0d 00 00
key: 60 09 00 00  value: 76 02 00 00
key: 83 09 00 00  value: 04 02 00 00
Found 7 elements
