Total: 574
TCP:   3255 (estab 297, closed 2939, orphaned 0, timewait 2477)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  316       307       9        
INET	  326       313       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.181.241%ens5:68         0.0.0.0:*    uid:192 ino:124314 sk:ae0 cgroup:unreachable:bd0 <->                           
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:33254 sk:ae1 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15381 sk:ae2 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                            127.0.0.1:35557      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=41)) ino:32576 sk:ae3 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:33253 sk:ae4 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15382 sk:ae5 cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::4ad:e0ff:fe5a:2de5]%ens5:546           [::]:*    uid:192 ino:16479 sk:ae6 cgroup:unreachable:bd0 v6only:1 <->                   
