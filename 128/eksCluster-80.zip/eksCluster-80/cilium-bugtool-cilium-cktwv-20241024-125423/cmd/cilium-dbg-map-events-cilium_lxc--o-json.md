{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.581Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.592Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.618Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.899Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.927Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.972Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:45.986Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:46.023Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.618Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.627Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.672Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.685Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.712Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.914Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.926Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:48.998Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.037Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:49.108Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.666Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.674Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.712Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.729Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.771Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.785Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:54.808Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.038Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.050Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.105Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.114Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:55.154Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.777Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.780Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.816Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.849Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.891Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.898Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:50:59.931Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.186Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.215Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.250Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.310Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:00.393Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.697Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.761Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.779Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.808Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.823Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:03.849Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.071Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.097Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.139Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.169Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:04.184Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.580Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.629Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.657Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.689Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.696Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.729Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.976Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:06.980Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.043Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.059Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:07.106Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.494Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.527Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.537Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.581Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.592Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.622Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.850Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.875Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.914Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.930Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:10.973Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.346Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.387Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.402Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.444Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.445Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.491Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.702Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.719Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.773Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.818Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:13.882Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.226Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.265Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.283Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.312Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.332Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.356Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.560Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.610Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.617Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.662Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:16.683Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.944Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.994Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:18.995Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.041Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.049Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.083Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.314Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.315Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.417Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.511Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:19.520Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.741Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.774Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.791Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.819Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.856Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:22.861Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.084Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.089Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.108Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.112Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:23.130Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.818Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.822Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.866Z",
  "value": "id=474   sec_id=5353284 flags=0x0000 ifindex=24  mac=7A:41:A4:A9:31:86 nodemac=06:97:39:49:FF:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.872Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:27.903Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.209Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:28.209Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.887Z",
  "value": "id=2056  sec_id=5359114 flags=0x0000 ifindex=22  mac=2A:53:9A:80:53:5D nodemac=8A:50:5B:40:1B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T12:51:36.887Z",
  "value": "id=1428  sec_id=5320651 flags=0x0000 ifindex=20  mac=8E:F1:A7:C3:1E:F6 nodemac=56:C0:AD:AD:00:8D"
}

