Node 0, zone      DMA    403     94     34     32     21     12     12      6      3      4     39 
Node 0, zone   Normal    733    117     41     26     18     13      8      2      3      2      6 
