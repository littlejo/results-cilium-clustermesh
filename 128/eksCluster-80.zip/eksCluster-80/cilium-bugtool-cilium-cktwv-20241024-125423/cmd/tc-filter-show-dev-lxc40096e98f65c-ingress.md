filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc40096e98f65c direct-action not_in_hw id 533 tag b781d79b2d6e2a00 jited 
